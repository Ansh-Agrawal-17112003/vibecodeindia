export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_tools: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          id: string
          is_demo: boolean
          logo_url: string | null
          name: string
          pricing: string | null
          slug: string
          submitted_by: string
          tagline: string
          updated_at: string
          upvote_count: number
          url: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_demo?: boolean
          logo_url?: string | null
          name: string
          pricing?: string | null
          slug: string
          submitted_by: string
          tagline: string
          updated_at?: string
          upvote_count?: number
          url: string
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_demo?: boolean
          logo_url?: string | null
          name?: string
          pricing?: string | null
          slug?: string
          submitted_by?: string
          tagline?: string
          updated_at?: string
          upvote_count?: number
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_tools_submitted_by_fkey"
            columns: ["submitted_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      bug_reports: {
        Row: {
          created_at: string
          description: string
          id: string
          page_url: string | null
          reporter_id: string | null
          status: string
          title: string
          user_agent: string | null
        }
        Insert: {
          created_at?: string
          description: string
          id?: string
          page_url?: string | null
          reporter_id?: string | null
          status?: string
          title: string
          user_agent?: string | null
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          page_url?: string | null
          reporter_id?: string | null
          status?: string
          title?: string
          user_agent?: string | null
        }
        Relationships: []
      }
      builder_details: {
        Row: {
          ai_tools: string[]
          builder_type: Database["public"]["Enums"]["builder_type"] | null
          created_at: string
          experience_level:
            | Database["public"]["Enums"]["experience_level"]
            | null
          github_url: string | null
          linkedin_url: string | null
          profile_id: string
          skills: string[]
          title: string | null
          verified: boolean
          website_url: string | null
        }
        Insert: {
          ai_tools?: string[]
          builder_type?: Database["public"]["Enums"]["builder_type"] | null
          created_at?: string
          experience_level?:
            | Database["public"]["Enums"]["experience_level"]
            | null
          github_url?: string | null
          linkedin_url?: string | null
          profile_id: string
          skills?: string[]
          title?: string | null
          verified?: boolean
          website_url?: string | null
        }
        Update: {
          ai_tools?: string[]
          builder_type?: Database["public"]["Enums"]["builder_type"] | null
          created_at?: string
          experience_level?:
            | Database["public"]["Enums"]["experience_level"]
            | null
          github_url?: string | null
          linkedin_url?: string | null
          profile_id?: string
          skills?: string[]
          title?: string | null
          verified?: boolean
          website_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "builder_details_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      builder_levels: {
        Row: {
          badge_color: string
          badge_emoji: string
          id: number
          max_xp: number | null
          min_xp: number
          name: string
          sort_order: number
        }
        Insert: {
          badge_color: string
          badge_emoji: string
          id?: number
          max_xp?: number | null
          min_xp: number
          name: string
          sort_order: number
        }
        Update: {
          badge_color?: string
          badge_emoji?: string
          id?: number
          max_xp?: number | null
          min_xp?: number
          name?: string
          sort_order?: number
        }
        Relationships: []
      }
      communities: {
        Row: {
          banner_url: string | null
          category: string | null
          created_at: string
          created_by: string | null
          description: string
          hue: number
          icon: string | null
          icon_url: string | null
          id: string
          is_demo: boolean
          is_official: boolean
          member_count: number
          name: string
          online_count: number
          posts_this_week: number
          price_inr: number
          pricing_type: string
          privacy: string
          rules: string | null
          slug: string
          status: string
          stream_channel_id: string | null
          trial_days: number
          updated_at: string
          welcome_message: string | null
        }
        Insert: {
          banner_url?: string | null
          category?: string | null
          created_at?: string
          created_by?: string | null
          description: string
          hue?: number
          icon?: string | null
          icon_url?: string | null
          id?: string
          is_demo?: boolean
          is_official?: boolean
          member_count?: number
          name: string
          online_count?: number
          posts_this_week?: number
          price_inr?: number
          pricing_type?: string
          privacy?: string
          rules?: string | null
          slug: string
          status?: string
          stream_channel_id?: string | null
          trial_days?: number
          updated_at?: string
          welcome_message?: string | null
        }
        Update: {
          banner_url?: string | null
          category?: string | null
          created_at?: string
          created_by?: string | null
          description?: string
          hue?: number
          icon?: string | null
          icon_url?: string | null
          id?: string
          is_demo?: boolean
          is_official?: boolean
          member_count?: number
          name?: string
          online_count?: number
          posts_this_week?: number
          price_inr?: number
          pricing_type?: string
          privacy?: string
          rules?: string | null
          slug?: string
          status?: string
          stream_channel_id?: string | null
          trial_days?: number
          updated_at?: string
          welcome_message?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "communities_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      community_channels: {
        Row: {
          community_id: string
          created_at: string
          description: string | null
          id: string
          name: string
          position: number
          slug: string
          stream_channel_id: string
        }
        Insert: {
          community_id: string
          created_at?: string
          description?: string | null
          id?: string
          name: string
          position?: number
          slug: string
          stream_channel_id: string
        }
        Update: {
          community_id?: string
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          position?: number
          slug?: string
          stream_channel_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_channels_community_id_fkey"
            columns: ["community_id"]
            isOneToOne: false
            referencedRelation: "communities"
            referencedColumns: ["id"]
          },
        ]
      }
      community_invites: {
        Row: {
          community_id: string
          created_at: string
          created_by: string | null
          expires_at: string | null
          id: string
          max_uses: number | null
          token: string
          uses: number
        }
        Insert: {
          community_id: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          max_uses?: number | null
          token: string
          uses?: number
        }
        Update: {
          community_id?: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          max_uses?: number | null
          token?: string
          uses?: number
        }
        Relationships: [
          {
            foreignKeyName: "community_invites_community_id_fkey"
            columns: ["community_id"]
            isOneToOne: false
            referencedRelation: "communities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "community_invites_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      community_lectures: {
        Row: {
          channel_id: string | null
          community_id: string
          created_at: string
          description: string | null
          duration_sec: number | null
          id: string
          is_published: boolean
          tags: string[]
          thumbnail_url: string | null
          title: string
          updated_at: string
          uploader_id: string
          video_url: string | null
          view_count: number
        }
        Insert: {
          channel_id?: string | null
          community_id: string
          created_at?: string
          description?: string | null
          duration_sec?: number | null
          id?: string
          is_published?: boolean
          tags?: string[]
          thumbnail_url?: string | null
          title: string
          updated_at?: string
          uploader_id: string
          video_url?: string | null
          view_count?: number
        }
        Update: {
          channel_id?: string | null
          community_id?: string
          created_at?: string
          description?: string | null
          duration_sec?: number | null
          id?: string
          is_published?: boolean
          tags?: string[]
          thumbnail_url?: string | null
          title?: string
          updated_at?: string
          uploader_id?: string
          video_url?: string | null
          view_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "community_lectures_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "community_channels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "community_lectures_community_id_fkey"
            columns: ["community_id"]
            isOneToOne: false
            referencedRelation: "communities"
            referencedColumns: ["id"]
          },
        ]
      }
      community_members: {
        Row: {
          banned: boolean
          community_id: string
          id: string
          joined_at: string
          muted_until: string | null
          paid_until: string | null
          profile_id: string
          role: string
          status: string
        }
        Insert: {
          banned?: boolean
          community_id: string
          id?: string
          joined_at?: string
          muted_until?: string | null
          paid_until?: string | null
          profile_id: string
          role?: string
          status?: string
        }
        Update: {
          banned?: boolean
          community_id?: string
          id?: string
          joined_at?: string
          muted_until?: string | null
          paid_until?: string | null
          profile_id?: string
          role?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_members_community_id_fkey"
            columns: ["community_id"]
            isOneToOne: false
            referencedRelation: "communities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "community_members_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      community_payment_requests: {
        Row: {
          amount_inr: number
          community_id: string
          created_at: string
          id: string
          profile_id: string
          reject_reason: string | null
          screenshot_url: string | null
          status: string
          submitted_at: string
          transaction_reference: string
          updated_at: string
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          amount_inr: number
          community_id: string
          created_at?: string
          id?: string
          profile_id: string
          reject_reason?: string | null
          screenshot_url?: string | null
          status?: string
          submitted_at?: string
          transaction_reference: string
          updated_at?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          amount_inr?: number
          community_id?: string
          created_at?: string
          id?: string
          profile_id?: string
          reject_reason?: string | null
          screenshot_url?: string | null
          status?: string
          submitted_at?: string
          transaction_reference?: string
          updated_at?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "community_payment_requests_community_id_fkey"
            columns: ["community_id"]
            isOneToOne: false
            referencedRelation: "communities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "community_payment_requests_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "community_payment_requests_verified_by_fkey"
            columns: ["verified_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      companies: {
        Row: {
          created_at: string
          description: string | null
          employee_count: string | null
          id: string
          industry: string | null
          location: string | null
          logo_url: string | null
          name: string
          owner_profile_id: string
          plan: string
          plan_expires_at: string | null
          plan_started_at: string | null
          verified: boolean
          website: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          employee_count?: string | null
          id?: string
          industry?: string | null
          location?: string | null
          logo_url?: string | null
          name: string
          owner_profile_id: string
          plan?: string
          plan_expires_at?: string | null
          plan_started_at?: string | null
          verified?: boolean
          website?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          employee_count?: string | null
          id?: string
          industry?: string | null
          location?: string | null
          logo_url?: string | null
          name?: string
          owner_profile_id?: string
          plan?: string
          plan_expires_at?: string | null
          plan_started_at?: string | null
          verified?: boolean
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "companies_owner_profile_id_fkey"
            columns: ["owner_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          created_at: string
          id: string
          last_message: string | null
          last_message_at: string | null
          user_a: string
          user_b: string
        }
        Insert: {
          created_at?: string
          id?: string
          last_message?: string | null
          last_message_at?: string | null
          user_a: string
          user_b: string
        }
        Update: {
          created_at?: string
          id?: string
          last_message?: string | null
          last_message_at?: string | null
          user_a?: string
          user_b?: string
        }
        Relationships: []
      }
      early_access_signups: {
        Row: {
          created_at: string
          email: string
          id: string
          source: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          source?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          source?: string | null
        }
        Relationships: []
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_id: string | null
          metadata: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email?: string
          status?: string
          template_name?: string
        }
        Relationships: []
      }
      email_send_state: {
        Row: {
          auth_email_ttl_minutes: number
          batch_size: number
          id: number
          retry_after_until: string | null
          send_delay_ms: number
          transactional_email_ttl_minutes: number
          updated_at: string
        }
        Insert: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Update: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      email_unsubscribe_tokens: {
        Row: {
          created_at: string
          email: string
          id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          token: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: []
      }
      follows: {
        Row: {
          created_at: string
          follower_id: string
          following_id: string
        }
        Insert: {
          created_at?: string
          follower_id: string
          following_id: string
        }
        Update: {
          created_at?: string
          follower_id?: string
          following_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "follows_follower_id_fkey"
            columns: ["follower_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "follows_following_id_fkey"
            columns: ["following_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      founder_emails: {
        Row: {
          created_at: string
          email: string
        }
        Insert: {
          created_at?: string
          email: string
        }
        Update: {
          created_at?: string
          email?: string
        }
        Relationships: []
      }
      job_applications: {
        Row: {
          applicant_id: string
          application_priority: number | null
          applied_at: string
          cover_note: string | null
          id: string
          job_id: string
          resume_url: string | null
          status: Database["public"]["Enums"]["application_status"]
        }
        Insert: {
          applicant_id: string
          application_priority?: number | null
          applied_at?: string
          cover_note?: string | null
          id?: string
          job_id: string
          resume_url?: string | null
          status?: Database["public"]["Enums"]["application_status"]
        }
        Update: {
          applicant_id?: string
          application_priority?: number | null
          applied_at?: string
          cover_note?: string | null
          id?: string
          job_id?: string
          resume_url?: string | null
          status?: Database["public"]["Enums"]["application_status"]
        }
        Relationships: [
          {
            foreignKeyName: "job_applications_applicant_id_fkey"
            columns: ["applicant_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_applications_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      jobs: {
        Row: {
          company_id: string | null
          created_at: string
          description: string | null
          experience_level:
            | Database["public"]["Enums"]["experience_level"]
            | null
          id: string
          job_type: Database["public"]["Enums"]["job_type"]
          location: string | null
          nice_to_have: string[]
          posted_by: string
          remote_type: Database["public"]["Enums"]["remote_type"]
          requirements: string[]
          salary_max: number | null
          salary_min: number | null
          status: Database["public"]["Enums"]["job_status"]
          title: string
          tools_required: string[]
        }
        Insert: {
          company_id?: string | null
          created_at?: string
          description?: string | null
          experience_level?:
            | Database["public"]["Enums"]["experience_level"]
            | null
          id?: string
          job_type?: Database["public"]["Enums"]["job_type"]
          location?: string | null
          nice_to_have?: string[]
          posted_by: string
          remote_type?: Database["public"]["Enums"]["remote_type"]
          requirements?: string[]
          salary_max?: number | null
          salary_min?: number | null
          status?: Database["public"]["Enums"]["job_status"]
          title: string
          tools_required?: string[]
        }
        Update: {
          company_id?: string | null
          created_at?: string
          description?: string | null
          experience_level?:
            | Database["public"]["Enums"]["experience_level"]
            | null
          id?: string
          job_type?: Database["public"]["Enums"]["job_type"]
          location?: string | null
          nice_to_have?: string[]
          posted_by?: string
          remote_type?: Database["public"]["Enums"]["remote_type"]
          requirements?: string[]
          salary_max?: number | null
          salary_min?: number | null
          status?: Database["public"]["Enums"]["job_status"]
          title?: string
          tools_required?: string[]
        }
        Relationships: [
          {
            foreignKeyName: "jobs_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_posted_by_fkey"
            columns: ["posted_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      lecture_views: {
        Row: {
          created_at: string
          id: string
          last_position_sec: number
          lecture_id: string
          updated_at: string
          viewer_id: string
          watched_sec: number
        }
        Insert: {
          created_at?: string
          id?: string
          last_position_sec?: number
          lecture_id: string
          updated_at?: string
          viewer_id: string
          watched_sec?: number
        }
        Update: {
          created_at?: string
          id?: string
          last_position_sec?: number
          lecture_id?: string
          updated_at?: string
          viewer_id?: string
          watched_sec?: number
        }
        Relationships: [
          {
            foreignKeyName: "lecture_views_lecture_id_fkey"
            columns: ["lecture_id"]
            isOneToOne: false
            referencedRelation: "community_lectures"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          attachment_name: string | null
          attachment_type: string | null
          attachment_url: string | null
          body: string | null
          conversation_id: string
          created_at: string
          edited_at: string | null
          id: string
          read_at: string | null
          recipient_id: string
          reply_to_id: string | null
          sender_id: string
        }
        Insert: {
          attachment_name?: string | null
          attachment_type?: string | null
          attachment_url?: string | null
          body?: string | null
          conversation_id: string
          created_at?: string
          edited_at?: string | null
          id?: string
          read_at?: string | null
          recipient_id: string
          reply_to_id?: string | null
          sender_id: string
        }
        Update: {
          attachment_name?: string | null
          attachment_type?: string | null
          attachment_url?: string | null
          body?: string | null
          conversation_id?: string
          created_at?: string
          edited_at?: string | null
          id?: string
          read_at?: string | null
          recipient_id?: string
          reply_to_id?: string | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_reply_to_id_fkey"
            columns: ["reply_to_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      mirror_config: {
        Row: {
          key: string
          value: string
        }
        Insert: {
          key: string
          value: string
        }
        Update: {
          key?: string
          value?: string
        }
        Relationships: []
      }
      mirror_outbox: {
        Row: {
          attempts: number
          created_at: string
          id: number
          last_error: string | null
          op: string
          payload: Json
          row_pk: string
          sent_at: string | null
          table_name: string
        }
        Insert: {
          attempts?: number
          created_at?: string
          id?: number
          last_error?: string | null
          op: string
          payload: Json
          row_pk: string
          sent_at?: string | null
          table_name: string
        }
        Update: {
          attempts?: number
          created_at?: string
          id?: number
          last_error?: string | null
          op?: string
          payload?: Json
          row_pk?: string
          sent_at?: string | null
          table_name?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          actor_id: string | null
          body: string | null
          created_at: string
          id: string
          link: string | null
          read_at: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          actor_id?: string | null
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          actor_id?: string | null
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      og_claim_stats: {
        Row: {
          id: boolean
          next_number: number
          remaining: number
          taken: number
          updated_at: string
        }
        Insert: {
          id?: boolean
          next_number?: number
          remaining?: number
          taken?: number
          updated_at?: string
        }
        Update: {
          id?: boolean
          next_number?: number
          remaining?: number
          taken?: number
          updated_at?: string
        }
        Relationships: []
      }
      og_members: {
        Row: {
          activated_at: string | null
          ai_content: Json | null
          builder_type: string | null
          city: string | null
          email: string
          free_pro_granted: boolean
          free_pro_until: string | null
          full_name: string
          github_url: string | null
          id: string
          ip_address: string | null
          linkedin_url: string | null
          og_number: number | null
          og_status: string
          other_tools: string[] | null
          primary_tool: string | null
          profile_id: string | null
          referral_source: string | null
          show_on_wall: boolean
          signed_up_at: string
          state: string | null
          twitter_url: string | null
          user_agent: string | null
          username: string | null
          wall_tagline: string | null
          what_building: string | null
        }
        Insert: {
          activated_at?: string | null
          ai_content?: Json | null
          builder_type?: string | null
          city?: string | null
          email: string
          free_pro_granted?: boolean
          free_pro_until?: string | null
          full_name: string
          github_url?: string | null
          id?: string
          ip_address?: string | null
          linkedin_url?: string | null
          og_number?: number | null
          og_status?: string
          other_tools?: string[] | null
          primary_tool?: string | null
          profile_id?: string | null
          referral_source?: string | null
          show_on_wall?: boolean
          signed_up_at?: string
          state?: string | null
          twitter_url?: string | null
          user_agent?: string | null
          username?: string | null
          wall_tagline?: string | null
          what_building?: string | null
        }
        Update: {
          activated_at?: string | null
          ai_content?: Json | null
          builder_type?: string | null
          city?: string | null
          email?: string
          free_pro_granted?: boolean
          free_pro_until?: string | null
          full_name?: string
          github_url?: string | null
          id?: string
          ip_address?: string | null
          linkedin_url?: string | null
          og_number?: number | null
          og_status?: string
          other_tools?: string[] | null
          primary_tool?: string | null
          profile_id?: string | null
          referral_source?: string | null
          show_on_wall?: boolean
          signed_up_at?: string
          state?: string | null
          twitter_url?: string | null
          user_agent?: string | null
          username?: string | null
          wall_tagline?: string | null
          what_building?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "og_members_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      og_waitlist: {
        Row: {
          email: string
          id: string
          joined_at: string
          name: string | null
        }
        Insert: {
          email: string
          id?: string
          joined_at?: string
          name?: string | null
        }
        Update: {
          email?: string
          id?: string
          joined_at?: string
          name?: string | null
        }
        Relationships: []
      }
      payment_otps: {
        Row: {
          amount: number
          created_at: string
          expires_at: string
          id: string
          otp_code: string
          purpose: string
          reference: string
          status: string
          user_id: string
          verified_at: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          expires_at: string
          id?: string
          otp_code: string
          purpose: string
          reference: string
          status?: string
          user_id: string
          verified_at?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          expires_at?: string
          id?: string
          otp_code?: string
          purpose?: string
          reference?: string
          status?: string
          user_id?: string
          verified_at?: string | null
        }
        Relationships: []
      }
      platform_settings: {
        Row: {
          key: string
          updated_at: string
          updated_by: string | null
          value: string | null
        }
        Insert: {
          key: string
          updated_at?: string
          updated_by?: string | null
          value?: string | null
        }
        Update: {
          key?: string
          updated_at?: string
          updated_by?: string | null
          value?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "platform_settings_updated_by_fkey"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      post_bookmarks: {
        Row: {
          created_at: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_bookmarks_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      post_comments: {
        Row: {
          author_id: string
          body: string
          created_at: string
          edited_at: string | null
          id: string
          parent_comment_id: string | null
          post_id: string
        }
        Insert: {
          author_id: string
          body: string
          created_at?: string
          edited_at?: string | null
          id?: string
          parent_comment_id?: string | null
          post_id: string
        }
        Update: {
          author_id?: string
          body?: string
          created_at?: string
          edited_at?: string | null
          id?: string
          parent_comment_id?: string | null
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_comments_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "post_comments_parent_comment_id_fkey"
            columns: ["parent_comment_id"]
            isOneToOne: false
            referencedRelation: "post_comments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "post_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      post_feed_scores: {
        Row: {
          boost_score: number | null
          engagement_score: number | null
          last_calculated: string
          post_id: string
          recency_score: number | null
          total_score: number | null
        }
        Insert: {
          boost_score?: number | null
          engagement_score?: number | null
          last_calculated?: string
          post_id: string
          recency_score?: number | null
          total_score?: number | null
        }
        Update: {
          boost_score?: number | null
          engagement_score?: number | null
          last_calculated?: string
          post_id?: string
          recency_score?: number | null
          total_score?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "post_feed_scores_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: true
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      post_likes: {
        Row: {
          created_at: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_likes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "post_likes_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      post_reactions: {
        Row: {
          created_at: string
          post_id: string
          reaction_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          post_id: string
          reaction_type?: string
          user_id: string
        }
        Update: {
          created_at?: string
          post_id?: string
          reaction_type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_reactions_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "post_reactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      post_reports: {
        Row: {
          created_at: string
          details: string | null
          id: string
          post_id: string
          reason: string
          reporter_id: string
          status: string
        }
        Insert: {
          created_at?: string
          details?: string | null
          id?: string
          post_id: string
          reason: string
          reporter_id: string
          status?: string
        }
        Update: {
          created_at?: string
          details?: string | null
          id?: string
          post_id?: string
          reason?: string
          reporter_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_reports_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      posts: {
        Row: {
          author_id: string
          body: string | null
          bot_engaged_at: string | null
          comment_count: number
          created_at: string
          edited_at: string | null
          id: string
          image_urls: string[]
          is_deleted: boolean
          kind: string
          like_count: number
          project_id: string | null
          reaction_counts: Json
          ref_id: string | null
          ref_table: string | null
          repost_count: number
          repost_of: string | null
          updated_at: string
        }
        Insert: {
          author_id: string
          body?: string | null
          bot_engaged_at?: string | null
          comment_count?: number
          created_at?: string
          edited_at?: string | null
          id?: string
          image_urls?: string[]
          is_deleted?: boolean
          kind: string
          like_count?: number
          project_id?: string | null
          reaction_counts?: Json
          ref_id?: string | null
          ref_table?: string | null
          repost_count?: number
          repost_of?: string | null
          updated_at?: string
        }
        Update: {
          author_id?: string
          body?: string | null
          bot_engaged_at?: string | null
          comment_count?: number
          created_at?: string
          edited_at?: string | null
          id?: string
          image_urls?: string[]
          is_deleted?: boolean
          kind?: string
          like_count?: number
          project_id?: string | null
          reaction_counts?: Json
          ref_id?: string | null
          ref_table?: string | null
          repost_count?: number
          repost_of?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "posts_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_repost_of_fkey"
            columns: ["repost_of"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_views: {
        Row: {
          id: string
          source: string | null
          viewed_at: string
          viewed_profile_id: string
          viewer_id: string | null
          viewer_title: string | null
        }
        Insert: {
          id?: string
          source?: string | null
          viewed_at?: string
          viewed_profile_id: string
          viewer_id?: string | null
          viewer_title?: string | null
        }
        Update: {
          id?: string
          source?: string | null
          viewed_at?: string
          viewed_profile_id?: string
          viewer_id?: string | null
          viewer_title?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profile_views_viewed_profile_id_fkey"
            columns: ["viewed_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_views_viewer_id_fkey"
            columns: ["viewer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          accent_color: string
          ai_content: Json | null
          availability_status:
            | Database["public"]["Enums"]["availability_status"]
            | null
          avatar_url: string | null
          banner_url: string | null
          bio: string | null
          boost_expires_at: string | null
          boost_reset_date: string | null
          boost_started_at: string | null
          boosted_until: string | null
          created_at: string
          current_level: string
          display_name: string | null
          follower_count: number
          following_count: number
          github_url: string | null
          id: string
          is_boosted: boolean | null
          is_demo: boolean
          is_og_founder: boolean
          is_og_member: boolean | null
          is_seed: boolean
          is_verified: boolean | null
          last_login_date: string | null
          linkedin_url: string | null
          location: string | null
          login_streak: number
          longest_streak: number
          monthly_boosts_limit: number | null
          monthly_boosts_used: number | null
          notify_streak_reminder: boolean
          notify_weekly_digest: boolean
          notify_winback: boolean
          og_founder_since: string | null
          og_founder_until: string | null
          og_number: number | null
          onboarded_at: string | null
          pro_until: string | null
          roles: string[]
          search_appearances_week: number | null
          streak_badges: string[]
          subscription_plan: string | null
          subscription_status: string | null
          total_profile_views: number | null
          total_xp: number
          updated_at: string
          username: string | null
          vibecoin_balance: number
          website_url: string | null
          weekly_profile_views: number | null
          x_url: string | null
        }
        Insert: {
          accent_color?: string
          ai_content?: Json | null
          availability_status?:
            | Database["public"]["Enums"]["availability_status"]
            | null
          avatar_url?: string | null
          banner_url?: string | null
          bio?: string | null
          boost_expires_at?: string | null
          boost_reset_date?: string | null
          boost_started_at?: string | null
          boosted_until?: string | null
          created_at?: string
          current_level?: string
          display_name?: string | null
          follower_count?: number
          following_count?: number
          github_url?: string | null
          id: string
          is_boosted?: boolean | null
          is_demo?: boolean
          is_og_founder?: boolean
          is_og_member?: boolean | null
          is_seed?: boolean
          is_verified?: boolean | null
          last_login_date?: string | null
          linkedin_url?: string | null
          location?: string | null
          login_streak?: number
          longest_streak?: number
          monthly_boosts_limit?: number | null
          monthly_boosts_used?: number | null
          notify_streak_reminder?: boolean
          notify_weekly_digest?: boolean
          notify_winback?: boolean
          og_founder_since?: string | null
          og_founder_until?: string | null
          og_number?: number | null
          onboarded_at?: string | null
          pro_until?: string | null
          roles?: string[]
          search_appearances_week?: number | null
          streak_badges?: string[]
          subscription_plan?: string | null
          subscription_status?: string | null
          total_profile_views?: number | null
          total_xp?: number
          updated_at?: string
          username?: string | null
          vibecoin_balance?: number
          website_url?: string | null
          weekly_profile_views?: number | null
          x_url?: string | null
        }
        Update: {
          accent_color?: string
          ai_content?: Json | null
          availability_status?:
            | Database["public"]["Enums"]["availability_status"]
            | null
          avatar_url?: string | null
          banner_url?: string | null
          bio?: string | null
          boost_expires_at?: string | null
          boost_reset_date?: string | null
          boost_started_at?: string | null
          boosted_until?: string | null
          created_at?: string
          current_level?: string
          display_name?: string | null
          follower_count?: number
          following_count?: number
          github_url?: string | null
          id?: string
          is_boosted?: boolean | null
          is_demo?: boolean
          is_og_founder?: boolean
          is_og_member?: boolean | null
          is_seed?: boolean
          is_verified?: boolean | null
          last_login_date?: string | null
          linkedin_url?: string | null
          location?: string | null
          login_streak?: number
          longest_streak?: number
          monthly_boosts_limit?: number | null
          monthly_boosts_used?: number | null
          notify_streak_reminder?: boolean
          notify_weekly_digest?: boolean
          notify_winback?: boolean
          og_founder_since?: string | null
          og_founder_until?: string | null
          og_number?: number | null
          onboarded_at?: string | null
          pro_until?: string | null
          roles?: string[]
          search_appearances_week?: number | null
          streak_badges?: string[]
          subscription_plan?: string | null
          subscription_status?: string | null
          total_profile_views?: number | null
          total_xp?: number
          updated_at?: string
          username?: string | null
          vibecoin_balance?: number
          website_url?: string | null
          weekly_profile_views?: number | null
          x_url?: string | null
        }
        Relationships: []
      }
      projects: {
        Row: {
          builder_id: string
          case_study: string | null
          cover_image_url: string | null
          created_at: string
          featured_until: string | null
          github_url: string | null
          id: string
          industry: string | null
          is_demo: boolean
          live_demo_url: string | null
          problem_solved: string | null
          solution: string | null
          tags: string[]
          title: string
          tools_used: string[]
          upvote_count: number
        }
        Insert: {
          builder_id: string
          case_study?: string | null
          cover_image_url?: string | null
          created_at?: string
          featured_until?: string | null
          github_url?: string | null
          id?: string
          industry?: string | null
          is_demo?: boolean
          live_demo_url?: string | null
          problem_solved?: string | null
          solution?: string | null
          tags?: string[]
          title: string
          tools_used?: string[]
          upvote_count?: number
        }
        Update: {
          builder_id?: string
          case_study?: string | null
          cover_image_url?: string | null
          created_at?: string
          featured_until?: string | null
          github_url?: string | null
          id?: string
          industry?: string | null
          is_demo?: boolean
          live_demo_url?: string | null
          problem_solved?: string | null
          solution?: string | null
          tags?: string[]
          title?: string
          tools_used?: string[]
          upvote_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "projects_builder_id_fkey"
            columns: ["builder_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      prompts: {
        Row: {
          author_id: string
          body: string
          category: string | null
          created_at: string
          id: string
          is_demo: boolean
          model: string | null
          preview: string | null
          title: string
          updated_at: string
          upvote_count: number
        }
        Insert: {
          author_id: string
          body: string
          category?: string | null
          created_at?: string
          id?: string
          is_demo?: boolean
          model?: string | null
          preview?: string | null
          title: string
          updated_at?: string
          upvote_count?: number
        }
        Update: {
          author_id?: string
          body?: string
          category?: string | null
          created_at?: string
          id?: string
          is_demo?: boolean
          model?: string | null
          preview?: string | null
          title?: string
          updated_at?: string
          upvote_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "prompts_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      real_value_moments: {
        Row: {
          amount_inr: number | null
          created_at: string
          description: string | null
          evidence_url: string | null
          featured: boolean
          hours_saved: number | null
          id: string
          kind: Database["public"]["Enums"]["rvm_kind"]
          source: string
          source_ref: string | null
          title: string
          user_id: string
          verified: boolean
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          amount_inr?: number | null
          created_at?: string
          description?: string | null
          evidence_url?: string | null
          featured?: boolean
          hours_saved?: number | null
          id?: string
          kind: Database["public"]["Enums"]["rvm_kind"]
          source?: string
          source_ref?: string | null
          title: string
          user_id: string
          verified?: boolean
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          amount_inr?: number | null
          created_at?: string
          description?: string | null
          evidence_url?: string | null
          featured?: boolean
          hours_saved?: number | null
          id?: string
          kind?: Database["public"]["Enums"]["rvm_kind"]
          source?: string
          source_ref?: string | null
          title?: string
          user_id?: string
          verified?: boolean
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: []
      }
      reviews: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          rating: number
          reviewed_profile_id: string | null
          reviewed_service_id: string | null
          reviewer_id: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          rating: number
          reviewed_profile_id?: string | null
          reviewed_service_id?: string | null
          reviewer_id: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          rating?: number
          reviewed_profile_id?: string | null
          reviewed_service_id?: string | null
          reviewer_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reviews_reviewed_profile_id_fkey"
            columns: ["reviewed_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_reviewed_service_id_fkey"
            columns: ["reviewed_service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_reviewer_id_fkey"
            columns: ["reviewer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      saved_jobs: {
        Row: {
          created_at: string
          job_id: string
          profile_id: string
        }
        Insert: {
          created_at?: string
          job_id: string
          profile_id: string
        }
        Update: {
          created_at?: string
          job_id?: string
          profile_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "saved_jobs_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "saved_jobs_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      search_appearances: {
        Row: {
          appeared_at: string
          id: string
          position_shown: number | null
          profile_id: string
          search_query: string | null
          was_clicked: boolean | null
        }
        Insert: {
          appeared_at?: string
          id?: string
          position_shown?: number | null
          profile_id: string
          search_query?: string | null
          was_clicked?: boolean | null
        }
        Update: {
          appeared_at?: string
          id?: string
          position_shown?: number | null
          profile_id?: string
          search_query?: string | null
          was_clicked?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "search_appearances_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      search_usage: {
        Row: {
          created_at: string
          id: string
          month_year: string
          profile_id: string
          search_count: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          month_year: string
          profile_id: string
          search_count?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          month_year?: string
          profile_id?: string
          search_count?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "search_usage_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      services: {
        Row: {
          builder_id: string
          category: string | null
          cover_image_url: string | null
          created_at: string
          description: string | null
          id: string
          packages: Json
          rating_avg: number
          title: string
        }
        Insert: {
          builder_id: string
          category?: string | null
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          id?: string
          packages?: Json
          rating_avg?: number
          title: string
        }
        Update: {
          builder_id?: string
          category?: string | null
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          id?: string
          packages?: Json
          rating_avg?: number
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "services_builder_id_fkey"
            columns: ["builder_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_requests: {
        Row: {
          amount: number
          id: string
          payment_screenshot_url: string | null
          profile_id: string
          rejection_reason: string | null
          requested_plan: string
          status: string
          submitted_at: string
          transaction_reference: string | null
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          amount: number
          id?: string
          payment_screenshot_url?: string | null
          profile_id: string
          rejection_reason?: string | null
          requested_plan: string
          status?: string
          submitted_at?: string
          transaction_reference?: string | null
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          amount?: number
          id?: string
          payment_screenshot_url?: string | null
          profile_id?: string
          rejection_reason?: string | null
          requested_plan?: string
          status?: string
          submitted_at?: string
          transaction_reference?: string | null
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subscription_requests_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscription_requests_verified_by_fkey"
            columns: ["verified_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          created_at: string
          current_period_end: string | null
          current_period_start: string
          id: string
          plan: string
          profile_id: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string
          id?: string
          plan?: string
          profile_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string
          id?: string
          plan?: string
          profile_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      suppressed_emails: {
        Row: {
          created_at: string
          email: string
          id: string
          metadata: Json | null
          reason: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          metadata?: Json | null
          reason: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          metadata?: Json | null
          reason?: string
        }
        Relationships: []
      }
      templates: {
        Row: {
          author_id: string
          category: string | null
          cover_image_url: string | null
          created_at: string
          description: string | null
          downloads: number
          framework: string | null
          id: string
          is_demo: boolean
          price_label: string | null
          slug: string
          stack: string[]
          title: string
          updated_at: string
        }
        Insert: {
          author_id: string
          category?: string | null
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          downloads?: number
          framework?: string | null
          id?: string
          is_demo?: boolean
          price_label?: string | null
          slug: string
          stack?: string[]
          title: string
          updated_at?: string
        }
        Update: {
          author_id?: string
          category?: string | null
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          downloads?: number
          framework?: string | null
          id?: string
          is_demo?: boolean
          price_label?: string | null
          slug?: string
          stack?: string[]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "templates_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      upvotes: {
        Row: {
          created_at: string
          profile_id: string
          target_id: string
          target_type: Database["public"]["Enums"]["upvote_target"]
        }
        Insert: {
          created_at?: string
          profile_id: string
          target_id: string
          target_type: Database["public"]["Enums"]["upvote_target"]
        }
        Update: {
          created_at?: string
          profile_id?: string
          target_id?: string
          target_type?: Database["public"]["Enums"]["upvote_target"]
        }
        Relationships: [
          {
            foreignKeyName: "upvotes_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vibecoin_redemptions: {
        Row: {
          admin_note: string | null
          amount_coins: number
          amount_inr: number
          id: string
          paid_at: string | null
          profile_id: string
          requested_at: string
          status: string
          updated_at: string
          upi_id: string
        }
        Insert: {
          admin_note?: string | null
          amount_coins: number
          amount_inr: number
          id?: string
          paid_at?: string | null
          profile_id: string
          requested_at?: string
          status?: string
          updated_at?: string
          upi_id: string
        }
        Update: {
          admin_note?: string | null
          amount_coins?: number
          amount_inr?: number
          id?: string
          paid_at?: string | null
          profile_id?: string
          requested_at?: string
          status?: string
          updated_at?: string
          upi_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vibecoin_redemptions_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      vibecoin_transactions: {
        Row: {
          amount: number
          created_at: string
          id: string
          profile_id: string
          reason: string
          reference_id: string | null
          type: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          profile_id: string
          reason: string
          reference_id?: string | null
          type: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          profile_id?: string
          reason?: string
          reference_id?: string | null
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "vibecoin_transactions_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      weekly_mission_participants: {
        Row: {
          coins_awarded: number
          completed_at: string
          got_bonus: boolean
          id: string
          mission_id: string
          user_id: string
        }
        Insert: {
          coins_awarded?: number
          completed_at?: string
          got_bonus?: boolean
          id?: string
          mission_id: string
          user_id: string
        }
        Update: {
          coins_awarded?: number
          completed_at?: string
          got_bonus?: boolean
          id?: string
          mission_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "weekly_mission_participants_mission_id_fkey"
            columns: ["mission_id"]
            isOneToOne: false
            referencedRelation: "weekly_missions"
            referencedColumns: ["id"]
          },
        ]
      }
      weekly_missions: {
        Row: {
          bonus_coins: number
          bonus_first_n: number
          created_at: string
          cta_href: string
          cta_label: string
          description: string
          id: string
          reward_coins: number
          title: string
          week_start: string
        }
        Insert: {
          bonus_coins?: number
          bonus_first_n?: number
          created_at?: string
          cta_href?: string
          cta_label?: string
          description: string
          id?: string
          reward_coins?: number
          title: string
          week_start: string
        }
        Update: {
          bonus_coins?: number
          bonus_first_n?: number
          created_at?: string
          cta_href?: string
          cta_label?: string
          description?: string
          id?: string
          reward_coins?: number
          title?: string
          week_start?: string
        }
        Relationships: []
      }
      workflows: {
        Row: {
          author_id: string
          category: string | null
          cover_image_url: string | null
          created_at: string
          description: string
          id: string
          is_demo: boolean
          title: string
          tools: string[]
          updated_at: string
          upvote_count: number
        }
        Insert: {
          author_id: string
          category?: string | null
          cover_image_url?: string | null
          created_at?: string
          description: string
          id?: string
          is_demo?: boolean
          title: string
          tools?: string[]
          updated_at?: string
          upvote_count?: number
        }
        Update: {
          author_id?: string
          category?: string | null
          cover_image_url?: string | null
          created_at?: string
          description?: string
          id?: string
          is_demo?: boolean
          title?: string
          tools?: string[]
          updated_at?: string
          upvote_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "workflows_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      xp_transactions: {
        Row: {
          action_type: string
          created_at: string
          id: string
          profile_id: string
          reference_id: string | null
          reference_type: string | null
          xp_earned: number
        }
        Insert: {
          action_type: string
          created_at?: string
          id?: string
          profile_id: string
          reference_id?: string | null
          reference_type?: string | null
          xp_earned: number
        }
        Update: {
          action_type?: string
          created_at?: string
          id?: string
          profile_id?: string
          reference_id?: string | null
          reference_type?: string | null
          xp_earned?: number
        }
        Relationships: [
          {
            foreignKeyName: "xp_transactions_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      og_spots_remaining: {
        Row: {
          next_number: number | null
          remaining: number | null
          taken: number | null
        }
        Insert: {
          next_number?: number | null
          remaining?: number | null
          taken?: number | null
        }
        Update: {
          next_number?: number | null
          remaining?: number | null
          taken?: number | null
        }
        Relationships: []
      }
      og_wall_public: {
        Row: {
          ai_content: Json | null
          builder_type: string | null
          city: string | null
          full_name: string | null
          github_url: string | null
          id: string | null
          linkedin_url: string | null
          og_number: number | null
          other_tools: string[] | null
          primary_tool: string | null
          profile_id: string | null
          signed_up_at: string | null
          state: string | null
          twitter_url: string | null
          username: string | null
          wall_tagline: string | null
          what_building: string | null
        }
        Insert: {
          ai_content?: Json | null
          builder_type?: string | null
          city?: string | null
          full_name?: string | null
          github_url?: string | null
          id?: string | null
          linkedin_url?: string | null
          og_number?: number | null
          other_tools?: string[] | null
          primary_tool?: string | null
          profile_id?: string | null
          signed_up_at?: string | null
          state?: string | null
          twitter_url?: string | null
          username?: string | null
          wall_tagline?: string | null
          what_building?: string | null
        }
        Update: {
          ai_content?: Json | null
          builder_type?: string | null
          city?: string | null
          full_name?: string | null
          github_url?: string | null
          id?: string | null
          linkedin_url?: string | null
          og_number?: number | null
          other_tools?: string[] | null
          primary_tool?: string | null
          profile_id?: string | null
          signed_up_at?: string | null
          state?: string | null
          twitter_url?: string | null
          username?: string | null
          wall_tagline?: string | null
          what_building?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "og_members_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      _notif_name: { Args: { _uid: string }; Returns: string }
      _notif_push: {
        Args: {
          _actor_id: string
          _body: string
          _link: string
          _title: string
          _type: string
          _user_id: string
        }
        Returns: undefined
      }
      activate_og_pro_benefits: {
        Args: { p_user_id: string }
        Returns: undefined
      }
      activate_profile_boost: { Args: { p_user_id: string }; Returns: Json }
      admin_list_early_access_readiness: {
        Args: never
        Returns: {
          avatar_url: string
          display_name: string
          email: string
          has_account: boolean
          is_og_founder: boolean
          last_login_date: string
          og_founder_until: string
          plan: string
          signed_up_at: string
          subscription_end: string
          user_id: string
          username: string
          vibecoin_balance: number
        }[]
      }
      award_vibecoins: {
        Args: {
          _amount: number
          _reason: string
          _reference_id?: string
          _type: string
        }
        Returns: number
      }
      award_xp: {
        Args: {
          _action_type: string
          _reference_id?: string
          _reference_type?: string
          _xp: number
        }
        Returns: {
          new_level: string
          new_total_xp: number
        }[]
      }
      calculate_post_score: { Args: { p_post_id: string }; Returns: number }
      can_watch_community: {
        Args: { _community_id: string; _user_id: string }
        Returns: boolean
      }
      check_daily_login: {
        Args: never
        Returns: {
          milestone: string
          streak: number
          xp_awarded: number
        }[]
      }
      claim_og_founder_access: { Args: never; Returns: Json }
      claim_og_spot: {
        Args: { payload: Json }
        Returns: {
          already_claimed: boolean
          next_number: number
          og_number: number
          remaining: number
          taken: number
        }[]
      }
      complete_mission: { Args: { _mission_id: string }; Returns: Json }
      convert_early_access_if_ready: { Args: never; Returns: Json }
      delete_email: {
        Args: { message_id: number; queue_name: string }
        Returns: boolean
      }
      email_queue_dispatch: { Args: never; Returns: undefined }
      enqueue_email: {
        Args: { payload: Json; queue_name: string }
        Returns: number
      }
      expire_boosts: { Args: never; Returns: undefined }
      get_community_invite: {
        Args: { _token: string }
        Returns: {
          community_id: string
          created_at: string
          created_by: string
          expires_at: string
          id: string
          max_uses: number
          token: string
          uses: number
        }[]
      }
      get_content_analytics: {
        Args: { p_days?: number; p_user: string }
        Returns: Json
      }
      get_hiring_analytics: {
        Args: { p_company: string; p_days?: number }
        Returns: Json
      }
      get_or_create_conversation: { Args: { _other: string }; Returns: string }
      get_profile_analytics: {
        Args: { p_days?: number; p_user: string }
        Returns: Json
      }
      get_public_platform_settings: {
        Args: never
        Returns: {
          key: string
          value: string
        }[]
      }
      get_ranked_builders: {
        Args: {
          p_availability?: string
          p_location?: string
          p_tools?: string[]
        }
        Returns: {
          accent_color: string
          ai_content: Json | null
          availability_status:
            | Database["public"]["Enums"]["availability_status"]
            | null
          avatar_url: string | null
          banner_url: string | null
          bio: string | null
          boost_expires_at: string | null
          boost_reset_date: string | null
          boost_started_at: string | null
          boosted_until: string | null
          created_at: string
          current_level: string
          display_name: string | null
          follower_count: number
          following_count: number
          github_url: string | null
          id: string
          is_boosted: boolean | null
          is_demo: boolean
          is_og_founder: boolean
          is_og_member: boolean | null
          is_seed: boolean
          is_verified: boolean | null
          last_login_date: string | null
          linkedin_url: string | null
          location: string | null
          login_streak: number
          longest_streak: number
          monthly_boosts_limit: number | null
          monthly_boosts_used: number | null
          notify_streak_reminder: boolean
          notify_weekly_digest: boolean
          notify_winback: boolean
          og_founder_since: string | null
          og_founder_until: string | null
          og_number: number | null
          onboarded_at: string | null
          pro_until: string | null
          roles: string[]
          search_appearances_week: number | null
          streak_badges: string[]
          subscription_plan: string | null
          subscription_status: string | null
          total_profile_views: number | null
          total_xp: number
          updated_at: string
          username: string | null
          vibecoin_balance: number
          website_url: string | null
          weekly_profile_views: number | null
          x_url: string | null
        }[]
        SetofOptions: {
          from: "*"
          to: "profiles"
          isOneToOne: false
          isSetofReturn: true
        }
      }
      get_viewer_breakdown: {
        Args: { p_days?: number; p_user: string }
        Returns: Json
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      increment_profile_views: {
        Args: { p_profile_id: string }
        Returns: undefined
      }
      increment_search_usage: { Args: never; Returns: number }
      is_community_admin: {
        Args: { _community_id: string; _user_id: string }
        Returns: boolean
      }
      is_community_member: {
        Args: { _community_id: string; _user_id: string }
        Returns: boolean
      }
      is_community_owner_or_moderator: {
        Args: { _community_id: string; _user_id: string }
        Returns: boolean
      }
      join_community_by_invite: {
        Args: { _community_id: string; _token: string }
        Returns: string
      }
      mirror_backfill_all: { Args: never; Returns: number }
      move_to_dlq: {
        Args: {
          dlq_name: string
          message_id: number
          payload: Json
          source_queue: string
        }
        Returns: number
      }
      read_email_batch: {
        Args: { batch_size: number; queue_name: string; vt: number }
        Returns: {
          message: Json
          msg_id: number
          read_ct: number
        }[]
      }
      rvm_weekly_count: {
        Args: never
        Returns: {
          total: number
          verified: number
          week_start: string
        }[]
      }
    }
    Enums: {
      app_role: "builder" | "hirer" | "admin" | "super_admin"
      application_status:
        | "applied"
        | "reviewed"
        | "shortlisted"
        | "rejected"
        | "hired"
      availability_status: "available" | "open_to_work" | "unavailable"
      builder_type: "freelancer" | "agency" | "student" | "founder"
      experience_level: "junior" | "mid" | "senior" | "lead"
      job_status: "active" | "closed"
      job_type: "full-time" | "part-time" | "freelance" | "internship"
      remote_type: "remote" | "hybrid" | "onsite"
      rvm_kind:
        | "hire"
        | "freelance"
        | "collab"
        | "feature"
        | "prompt_saved_time"
        | "cashout"
        | "followers_boost"
        | "other"
      upvote_target: "project" | "prompt" | "workflow"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["builder", "hirer", "admin", "super_admin"],
      application_status: [
        "applied",
        "reviewed",
        "shortlisted",
        "rejected",
        "hired",
      ],
      availability_status: ["available", "open_to_work", "unavailable"],
      builder_type: ["freelancer", "agency", "student", "founder"],
      experience_level: ["junior", "mid", "senior", "lead"],
      job_status: ["active", "closed"],
      job_type: ["full-time", "part-time", "freelance", "internship"],
      remote_type: ["remote", "hybrid", "onsite"],
      rvm_kind: [
        "hire",
        "freelance",
        "collab",
        "feature",
        "prompt_saved_time",
        "cashout",
        "followers_boost",
        "other",
      ],
      upvote_target: ["project", "prompt", "workflow"],
    },
  },
} as const
