"use client";

import { motion, useInView, Transition } from "framer-motion";
import { useRef, ReactNode } from "react";
import { cn } from "@/lib/utils";

interface Props {
  children: string;
  className?: string;
  textClassName?: string;
  flipTextClassName?: string;
  rotateDirection?: "top" | "bottom" | "left" | "right";
  staggerDuration?: number;
  staggerFrom?: "first" | "last" | "center";
  transition?: Transition;
  accentWords?: string[];
  accentColor?: string;
  suffix?: ReactNode;
}

export default function Text3DFlip({
  children,
  className,
  textClassName,
  flipTextClassName,
  rotateDirection = "top",
  staggerDuration = 0.04,
  staggerFrom = "first",
  transition = { type: "spring", damping: 25, stiffness: 160 },
  accentWords,
  accentColor,
  suffix,
}: Props) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-15% 0px" });
  const words = children.split(" ");

  const getDelay = (i: number) => {
    if (staggerFrom === "last") return (words.length - 1 - i) * staggerDuration;
    if (staggerFrom === "center")
      return Math.abs(i - Math.floor(words.length / 2)) * staggerDuration;
    return i * staggerDuration;
  };

  const isX = rotateDirection === "top" || rotateDirection === "bottom";
  const sign = rotateDirection === "top" || rotateDirection === "left" ? -1 : 1;

  return (
    <span
      ref={ref}
      className={cn("inline-block", className)}
      style={{ perspective: 1000 }}
    >
      {words.map((w, i) => {
        const clean = w.replace(/[.,!?;:]/g, "");
        const isAccent = accentWords?.some(
          (a) => a.toLowerCase() === clean.toLowerCase(),
        );
        return (
          <span
            key={`${w}-${i}`}
            className="inline-block align-bottom"
            style={{ perspective: 1000 }}
          >
            <motion.span
              className={cn(
                "inline-block",
                isAccent ? flipTextClassName : textClassName,
              )}
              style={{
                transformOrigin: "50% 100%",
                color: isAccent ? accentColor : undefined,
                willChange: "transform, opacity",
              }}
              initial={{
                rotateX: isX ? sign * 90 : 0,
                rotateY: !isX ? sign * 90 : 0,
                opacity: 0,
                y: isX ? sign * -8 : 0,
              }}
              animate={
                inView
                  ? { rotateX: 0, rotateY: 0, opacity: 1, y: 0 }
                  : undefined
              }
              transition={{ ...transition, delay: getDelay(i) }}
            >
              {w}
            </motion.span>
            {i < words.length - 1 ? "\u00A0" : ""}
          </span>
        );
      })}
      {suffix}
    </span>
  );
}
