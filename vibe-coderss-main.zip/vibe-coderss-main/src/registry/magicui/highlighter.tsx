"use client";

import { annotate } from "rough-notation";
import type { RoughAnnotation, RoughAnnotationConfig } from "rough-notation/lib/model";
import { useEffect, useRef, type ReactNode } from "react";

type Action = "highlight" | "underline" | "box" | "circle" | "strike-through" | "crossed-off" | "bracket";

interface HighlighterProps {
  children: ReactNode;
  action?: Action;
  color?: string;
  strokeWidth?: number;
  animationDuration?: number;
  iterations?: number;
  padding?: number;
  multiline?: boolean;
  /** If true, only animate when scrolled into view. Default true. */
  isView?: boolean;
  className?: string;
}

/**
 * Magic UI Highlighter — rough-notation wrapper.
 * Annotates the wrapped inline text with a hand-drawn accent when it enters view.
 */
export function Highlighter({
  children,
  action = "highlight",
  color = "#ffd1a4",
  strokeWidth = 1.5,
  animationDuration = 700,
  iterations = 2,
  padding = 2,
  multiline = true,
  isView = true,
  className,
}: HighlighterProps) {
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    // Mobile-only: skip annotation on tablet/desktop (>= 768px)
    if (typeof window !== "undefined" && window.matchMedia("(min-width: 768px)").matches) return;

    const config: RoughAnnotationConfig = {
      type: action,
      color,
      strokeWidth,
      animationDuration,
      iterations,
      padding,
      multiline,
    };
    const annotation: RoughAnnotation = annotate(el, config);

    let observer: IntersectionObserver | null = null;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const show = () => {
      timer = setTimeout(() => annotation.show(), 120);
    };

    if (isView && typeof IntersectionObserver !== "undefined") {
      observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            if (e.isIntersecting) {
              show();
              observer?.disconnect();
            }
          });
        },
        { threshold: 0.35 },
      );
      observer.observe(el);
    } else {
      show();
    }

    return () => {
      if (timer) clearTimeout(timer);
      observer?.disconnect();
      try {
        annotation.remove();
      } catch {
        /* noop */
      }
    };
  }, [action, color, strokeWidth, animationDuration, iterations, padding, multiline, isView]);

  return (
    <span ref={ref} className={className} style={{ position: "relative" }}>
      {children}
    </span>
  );
}

export default Highlighter;
