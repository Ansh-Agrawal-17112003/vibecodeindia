"use client";

import { motion, MotionProps, useInView } from "framer-motion";
import { useEffect, useRef, useState, ReactNode, ReactElement, Children, isValidElement, cloneElement, ElementType } from "react";
import { cn } from "@/lib/utils";

/* ------- TypingAnimation: types out its text char by char when in view ------- */
interface TypingAnimationProps extends MotionProps {
  children: string;
  className?: string;
  duration?: number; // ms per character
  delay?: number; // ms before start
  as?: ElementType;
  onDone?: () => void;
  startedAt?: number; // relative start offset (ms) passed by Terminal
  play?: boolean; // Terminal will control this
}

export function TypingAnimation({
  children,
  className,
  duration = 55,
  delay = 0,
  as: Tag = "span",
  onDone,
  play = true,
}: TypingAnimationProps) {
  const [displayed, setDisplayed] = useState("");
  const text = typeof children === "string" ? children : "";

  useEffect(() => {
    if (!play) {
      setDisplayed("");
      return;
    }
    let i = 0;
    let raf: number;
    let cancelled = false;

    const startTimer = setTimeout(() => {
      const tick = () => {
        if (cancelled) return;
        i += 1;
        setDisplayed(text.slice(0, i));
        if (i < text.length) {
          raf = window.setTimeout(tick, duration) as unknown as number;
        } else {
          onDone?.();
        }
      };
      tick();
    }, delay);

    return () => {
      cancelled = true;
      clearTimeout(startTimer);
      clearTimeout(raf);
    };
  }, [play, text, duration, delay, onDone]);

  const Component = Tag as any;
  return (
    <Component className={cn("block font-mono text-[13px] leading-[1.7] tracking-tight", className)}>
      {displayed}
      {play && displayed.length < text.length && (
        <span className="ml-0.5 inline-block h-[1em] w-[7px] -mb-[2px] bg-current opacity-70 animate-[terminal-blink_1s_steps(2)_infinite]" />
      )}
    </Component>
  );
}

/* ------- AnimatedSpan: fades / slides in when Terminal cues it ------- */
interface AnimatedSpanProps {
  children: ReactNode;
  className?: string;
  play?: boolean;
  delay?: number;
}

export function AnimatedSpan({ children, className, play = true, delay = 0 }: AnimatedSpanProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={play ? { opacity: 1, y: 0 } : { opacity: 0, y: 4 }}
      transition={{ duration: 0.22, ease: "easeOut", delay: delay / 1000 }}
      className={cn("block font-mono text-[13px] leading-[1.7] tracking-tight", className)}
    >
      {children}
    </motion.div>
  );
}

/* ------- Terminal: chrome + sequenced playback of children -------
   Renders each child one at a time, waiting for TypingAnimation lines
   to finish typing and giving AnimatedSpan lines a fixed step delay. */
interface TerminalProps {
  children: ReactNode;
  className?: string;
  title?: string;
  restartKey?: string | number;
}

export function Terminal({ children, className, title = "~/vibecode/og-claim", restartKey }: TerminalProps) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-20% 0px" });
  const kids = Children.toArray(children).filter(isValidElement) as ReactElement[];
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (!inView) return;
    setStep(0);
  }, [inView, restartKey]);

  // Auto-advance AnimatedSpan lines; TypingAnimation advances itself via onDone.
  useEffect(() => {
    if (!inView) return;
    const current = kids[step];
    if (!current) return;
    const isTyping = (current.type as any) === TypingAnimation;
    if (isTyping) return; // will call onDone
    const t = setTimeout(() => setStep((s) => Math.min(s + 1, kids.length)), 220);
    return () => clearTimeout(t);
  }, [step, inView, kids]);

  return (
    <div
      ref={ref}
      className={cn(
        "relative mx-auto w-full max-w-[720px] overflow-hidden rounded-[16px] border-[1.5px]",
        className,
      )}
      style={{
        background: "#0B0B0C",
        borderColor: "#0F0F0F",
        boxShadow: "6px 6px 0 0 #0F0F0F",
      }}
    >
      {/* chrome */}
      <div
        className="flex items-center gap-2 border-b px-4 py-3"
        style={{ borderColor: "#1c1c1e", background: "#111112" }}
      >
        <span className="h-3 w-3 rounded-full" style={{ background: "#ff5f57" }} />
        <span className="h-3 w-3 rounded-full" style={{ background: "#febc2e" }} />
        <span className="h-3 w-3 rounded-full" style={{ background: "#28c840" }} />
        <span className="ml-3 font-mono text-[11px] tracking-tight text-white/50">{title}</span>
      </div>

      {/* body */}
      <div className="min-h-[280px] px-5 py-4 text-white">
        {kids.map((child, i) => {
          const play = i <= step && inView;
          if ((child.type as any) === TypingAnimation) {
            return cloneElement(child as ReactElement<TypingAnimationProps>, {
              key: i,
              play,
              onDone: () => setStep((s) => (s === i ? s + 1 : s)),
            });
          }
          if ((child.type as any) === AnimatedSpan) {
            return cloneElement(child as ReactElement<AnimatedSpanProps>, { key: i, play });
          }
          return play ? child : null;
        })}
      </div>

      <style>{`
        @keyframes terminal-blink { 50% { opacity: 0; } }
      `}</style>
    </div>
  );
}
