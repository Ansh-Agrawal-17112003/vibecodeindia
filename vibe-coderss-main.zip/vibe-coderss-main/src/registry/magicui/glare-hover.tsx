"use client";

import { useRef, type CSSProperties, type ReactNode } from "react";

/**
 * GlareHover — diagonal light sweep on hover.
 * Pure CSS, no deps. Safe in SSR (no window access).
 */
export function GlareHover({
  children,
  className = "",
  duration = 700,
  glareColor = "rgba(255,255,255,0.55)",
  angle = 20,
  width = 55,
  auto = false,
  style,
}: {
  children: ReactNode;
  className?: string;
  /** ms */
  duration?: number;
  glareColor?: string;
  /** skew angle in deg */
  angle?: number;
  /** glare band width in % */
  width?: number;
  /** run continuously without hover */
  auto?: boolean;
  style?: CSSProperties;
}) {
  const ref = useRef<HTMLDivElement>(null);

  const glareStyle: CSSProperties = {
    position: "absolute",
    inset: 0,
    pointerEvents: "none",
    background: `linear-gradient(105deg, transparent 40%, ${glareColor} 50%, transparent 60%)`,
    backgroundSize: `${width * 4}% 100%`,
    backgroundPosition: "150% 0",
    backgroundRepeat: "no-repeat",
    transform: `skewX(-${angle}deg)`,
    transition: `background-position ${duration}ms cubic-bezier(0.22,1,0.36,1)`,
    mixBlendMode: "screen",
    zIndex: 2,
    animation: auto ? `glare-auto-sweep ${duration * 4}ms ease-in-out infinite` : undefined,
  };

  const sweep = (e: React.PointerEvent | React.TouchEvent, dir: "in" | "out") => {
    const el = (e.currentTarget as HTMLElement).querySelector<HTMLElement>("[data-glare]");
    if (el && !auto) el.style.backgroundPosition = dir === "in" ? "-150% 0" : "150% 0";
  };

  return (
    <div
      ref={ref}
      className={`relative isolate overflow-hidden ${className}`}
      style={style}
      onPointerEnter={(e) => sweep(e, "in")}
      onPointerLeave={(e) => sweep(e, "out")}
      onPointerDown={(e) => sweep(e, "in")}
      onPointerUp={(e) => sweep(e, "out")}
      onPointerCancel={(e) => sweep(e, "out")}
      onTouchStart={(e) => sweep(e, "in")}
      onTouchEnd={(e) => sweep(e, "out")}
    >
      {children}
      <span data-glare aria-hidden style={glareStyle} />
      <style>{`
        @keyframes glare-auto-sweep {
          0%   { background-position: 150% 0; }
          45%  { background-position: -150% 0; }
          100% { background-position: -150% 0; }
        }
      `}</style>
    </div>
  );
}

export default GlareHover;
