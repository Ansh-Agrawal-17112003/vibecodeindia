export type Blog = {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  author: string;
  authorRole: string;
  readMinutes: number;
  publishedAt: string;
  cover: string;
  tags: string[];
  body: string[]; // paragraphs
};

const TOPICS: { title: string; category: string; tags: string[]; excerpt: string; angle: string }[] = [
  { title: "How Vibe Coders Are Redefining Indian Startups in 2026", category: "Community", tags: ["India", "Startups", "Vibe Coding"], excerpt: "A new wave of AI-first indie builders is out-shipping funded teams. Here's how.", angle: "Indian indie AI builders shipping faster than funded teams" },
  { title: "Prompt Engineering Is Dead. Long Live Prompt Architecture.", category: "AI", tags: ["Prompts", "LLM", "Engineering"], excerpt: "Why single prompts don't scale and how to design multi-stage prompt systems.", angle: "moving from clever prompts to layered prompt systems" },
  { title: "The n8n Playbook: 12 Workflows Every Solo Founder Should Steal", category: "Workflows", tags: ["n8n", "Automation", "Solo Founder"], excerpt: "Practical automations that replace three virtual assistants.", angle: "n8n automations that save hours weekly for solo founders" },
  { title: "Cursor vs Windsurf vs Zed: The 2026 AI IDE Showdown", category: "Tools", tags: ["Cursor", "Windsurf", "IDE"], excerpt: "We coded the same SaaS in all three. Here's what actually shipped.", angle: "head to head test of AI IDEs with a real SaaS project" },
  { title: "From Zero to ₹1 Lakh MRR With Only Lovable and Supabase", category: "Founder", tags: ["MRR", "Lovable", "Supabase"], excerpt: "A four-month build log from a Kanpur builder who quit his TCS job.", angle: "TCS engineer quitting to build a micro SaaS to 1 lakh MRR" },
  { title: "Designing for Trust: Neo-Brutalism Isn't a Trend, It's a Message", category: "Design", tags: ["UI", "Neo-Brutalism", "Branding"], excerpt: "Why bold borders and hard shadows convert better than glassmorphism.", angle: "why brutalist design converts better in 2026" },
  { title: "The Rise of Micro-SaaS: Why ₹49/month Products Are Winning", category: "SaaS", tags: ["Micro SaaS", "Pricing", "India"], excerpt: "Small ticket, big volume. The Indian pricing sweet spot revealed.", angle: "why sub-100 rupee SaaS is winning in India" },
  { title: "Hiring AI Builders: A Field Guide for Indian Startups", category: "Hiring", tags: ["Hiring", "Talent", "Startups"], excerpt: "How to identify real builders vs. framework tourists in 30 minutes.", angle: "spotting real AI talent in interviews" },
  { title: "Supabase RLS: 7 Patterns That Will Save Your SaaS", category: "Backend", tags: ["Supabase", "RLS", "Security"], excerpt: "The exact policies we use in production for multi-tenant apps.", angle: "battle tested Supabase RLS patterns" },
  { title: "Why Every Indian Developer Should Own a .in Domain by 2027", category: "India", tags: ["Domain", "Branding", "India"], excerpt: "The identity shift happening across the Indian builder ecosystem.", angle: "importance of Indian domain identity" },
  { title: "Vibe Coding in Public: A 30-Day Twitter Growth Experiment", category: "Growth", tags: ["Twitter", "Build in Public", "Growth"], excerpt: "0 to 12,400 followers by shipping features live. The exact playbook.", angle: "30 day build in public experiment on Twitter" },
  { title: "The Future of Freelance: How AI Is Turning Coders Into Studios", category: "Freelance", tags: ["Freelance", "AI", "Services"], excerpt: "One person, ten deliverables a day. The new agency of one.", angle: "AI turning freelancers into one person studios" },
  { title: "Chennai to Cursor: The Untold Story of India's AI Migration", category: "Community", tags: ["India", "Chennai", "AI"], excerpt: "Inside the underground meetups reshaping the South Indian tech scene.", angle: "AI meetups reshaping Chennai and Bangalore tech scene" },
  { title: "Building an MVP in 48 Hours With Lovable Cloud", category: "Tutorial", tags: ["MVP", "Lovable Cloud", "Speed"], excerpt: "A blow-by-blow account of a weekend build that got 300 signups.", angle: "weekend MVP that got real traction" },
  { title: "The Unspoken Rules of Being a Great AI Community Manager", category: "Community", tags: ["Community", "Discord", "Ops"], excerpt: "Lessons from running a 40,000-member builder Discord.", angle: "running large builder communities on Discord" },
  { title: "Why We Ditched Notion for Custom Dashboards Built in a Day", category: "Tools", tags: ["Notion", "Dashboards", "Internal Tools"], excerpt: "Notion is a great start, but here's when to graduate.", angle: "outgrowing Notion for custom dashboards" },
  { title: "AI Agents Are Coming for Consultancies (Not Devs)", category: "AI", tags: ["Agents", "Consulting", "Future"], excerpt: "The consulting industry is quietly being rebuilt from the inside.", angle: "AI agents disrupting consulting more than devs" },
  { title: "The Best Open Source Templates for Indian SaaS in 2026", category: "Templates", tags: ["Open Source", "Templates", "SaaS"], excerpt: "Handpicked starters with UPI, GST invoicing, and Aadhar-ready flows.", angle: "open source templates tuned for Indian SaaS" },
  { title: "How to Price Your First Digital Product Without Second-Guessing", category: "Business", tags: ["Pricing", "Product", "Business"], excerpt: "The three-tier framework used by 90% of profitable indie hackers.", angle: "pricing framework for digital products" },
  { title: "Realtime Made Simple: WebSockets, Supabase, and the Edge", category: "Backend", tags: ["Realtime", "Supabase", "Edge"], excerpt: "Everything you need to build feels-instant experiences.", angle: "building real time apps on the edge" },
  { title: "The Silent Revolution of Vernacular AI Products in India", category: "India", tags: ["Vernacular", "AI", "India"], excerpt: "Hindi, Tamil, Telugu — the next billion users are non-English.", angle: "vernacular language AI products for India" },
  { title: "Design Systems for Solo Devs: Less Is Actually More", category: "Design", tags: ["Design System", "Solo", "UI"], excerpt: "You don't need shadcn plus Material plus Radix plus everything.", angle: "lean design systems for solo builders" },
  { title: "Why Founders Are Ditching VC Money for Community Capital", category: "Founder", tags: ["VC", "Community", "Funding"], excerpt: "Crowdfunded launches, revenue-share models, and the death of dilution.", angle: "community funding replacing VC for indie founders" },
  { title: "Every Vibe Coder Needs a Personal Brand. Here's How to Start.", category: "Growth", tags: ["Personal Brand", "Marketing", "Growth"], excerpt: "Ten minutes a day, forever. The compounding advantage of showing up.", angle: "building a personal brand as a builder" },
  { title: "The State of AI Coding in India: A 2026 Data Report", category: "Report", tags: ["Report", "Data", "India"], excerpt: "We surveyed 5,200 Indian AI builders. The results surprised even us.", angle: "state of AI coding in India report" },
];

const AUTHORS = [
  { name: "Aarav Mehta", role: "Editor, VibeCoder" },
  { name: "Diya Kapoor", role: "Community Lead" },
  { name: "Kabir Sharma", role: "Growth Writer" },
  { name: "Anaya Iyer", role: "Product Analyst" },
  { name: "Rohan Verma", role: "Staff Engineer" },
  { name: "Ishaan Rao", role: "Design Lead" },
  { name: "Meera Nair", role: "Founder in Residence" },
  { name: "Vihaan Gupta", role: "Backend Wizard" },
];

function slugify(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function paragraphsFor(t: (typeof TOPICS)[number], i: number): string[] {
  const a = AUTHORS[i % AUTHORS.length];
  const topic = t.angle;
  return [
    `There's a quiet shift happening across the Indian AI builder ecosystem, and if you've been paying attention on Twitter, in Telegram groups, or inside Discord servers stitched together by weekend hackers, you've probably felt it too. This piece is about ${topic} and why it matters more than most people realize. It isn't a trend report. It's a field note from the trenches, written for the builder who wakes up at 5am to ship one more feature before the day job begins.`,
    `A year ago, the conversation around ${t.category.toLowerCase()} was dominated by imported playbooks. Everyone quoted the same American founders, referenced the same Y Combinator essays, and tried to force-fit the Bay Area operating model onto a country of 1.4 billion where a solo dev in Jaipur can now out-ship a Series A team in San Francisco. That mimicry is finally breaking. What's emerging in its place is a distinctly Indian style of building — pragmatic, frugal, distribution-first, and ruthlessly focused on real user problems.`,
    `The core insight behind ${t.title} is deceptively simple: leverage has changed. Ten years ago, leverage meant capital, headcount, and enterprise partnerships. Today, leverage is a well-designed prompt, a Cursor window, a Supabase project, and an audience of 2,000 curious people on X who trust you enough to try your beta. When those four ingredients combine, a single builder can produce work that used to require a full product team. This is not hype. It's already the operating reality for hundreds of the ${t.tags[0].toLowerCase()} builders we talk to every week inside VibeCoder.`,
    `Consider the mechanics. A solo founder wakes up, opens Cursor, describes the feature in plain English, watches the diff render in real time, tests locally, pushes to production via a one-line command, and shares a Loom on Twitter before lunch. The same feature, three years ago, took two engineers a sprint. That compression of time isn't just a speed boost — it fundamentally changes what a "startup" even means. A startup is now a person with taste, a distribution channel, and an appetite to ship in public.`,
    `Of course, speed without judgement is dangerous. The failure mode we see most often in the ${t.category.toLowerCase()} space is builders shipping ten mediocre things instead of one great one. The AI tools will happily generate infinite variations, but they can't decide which variation matters. That's still your job. The best builders we've studied — the ones profiled repeatedly on VibeCoder — spend more time deleting code than writing it. They treat AI as an intern with infinite patience, not as an oracle with infinite wisdom.`,
    `There's also a cultural piece worth naming. Indian developers have historically been positioned as service providers to the world — brilliant executors of someone else's product vision. That's changing. The rise of ${t.tags[1]?.toLowerCase() ?? "independent building"} means Indian builders are now shipping products that Indians actually use, priced in rupees, marketed in vernacular languages, and supported over WhatsApp. This is a return to first principles: build what your neighbours need, charge them a fair price, and iterate until they love it.`,
    `The ecosystem infrastructure has caught up too. UPI killed payment friction. Supabase and Lovable Cloud killed backend friction. Cursor and Claude killed coding friction. Twitter and Telegram killed distribution friction. What's left is the hardest part — knowing what to build, why it matters, and having the emotional stamina to keep shipping when nobody claps for the first six months. That stamina is the actual moat, and no AI model will ever automate it.`,
    `Practically speaking, if you're reading this and wondering how to apply ${t.angle} to your own work this week, start small. Pick one workflow in your day that feels slow, ugly, or manual. Write a one-page brief describing the outcome you want. Open your favourite AI IDE, generate the first draft, then refine it by hand. Ship it to a private group of ten trusted users before you touch marketing. Collect feedback for three days. Iterate. Only when the ten trust you should you go wider. This tight loop — build, ship, listen, refine — is the entire game.`,
    `We've watched dozens of builders inside the VibeCoder community follow this exact pattern and reach ₹1 lakh MRR within six months of their first commit. Not because they were smarter, but because they refused to break the loop. They didn't chase fundraising. They didn't rewrite their stack four times. They didn't optimise for hypothetical enterprise deals. They talked to real users, shipped real fixes, and let compounding do the rest.`,
    `Zoom out and the pattern becomes even clearer. India is producing a generation of builders who treat code as a medium of expression rather than a corporate asset. They open-source aggressively, share revenue numbers publicly, teach on YouTube in Hinglish, and mentor juniors on Discord voice channels for free. This generosity isn't idealism — it's strategy. Every insight shared strengthens the ecosystem, which raises the floor for everyone, which brings more users onto the platforms we all build on.`,
    `If there's one prediction worth making, it's this: by the end of 2027, the majority of successful new Indian software companies will have started as a single-person project shipped from a bedroom in a tier-2 city. They will bypass traditional VC. They will bypass traditional hiring. They will bypass traditional PR. And they will win, quietly, one paying user at a time, until the industry looks up and realises the centre of gravity has moved.`,
    `That's what ${t.title.split(":")[0]} is really about — not a tool, not a framework, not even a business model, but a permission structure for a new kind of builder to exist in India. VibeCoder is trying to be the connective tissue for that generation. If you're reading this, you're already part of it. Ship something small this week, share it in the community, and let the loop begin.`,
    `— ${a.name}, ${a.role}. Have a story to tell, a workflow to share, or a launch to announce? Submit it via the VibeCoder submissions page and we'll consider it for a future issue. Every one of the 25 essays in this series is written for you, the person still coding at midnight because you can't imagine doing anything else.`,
  ];
}

export const BLOGS: Blog[] = TOPICS.map((t, i) => {
  const slug = slugify(t.title);
  const cover = `https://images.unsplash.com/photo-${["1518770660439-4636190af475","1526374965328-7f61d4dc18c5","1517430816045-df4b7de11d1d","1531482615713-2afd69097998","1551288049-bebda4e38f71","1522252234503-e356532cafd5","1498050108023-c5249f4df085","1504384308090-c894fdcc538d","1573164713714-d95e436ab8d6","1519389950473-47ba0277781c","1531403009284-440f080d1e12","1461749280684-dccba630e2f6","1487014679447-9f8336841d58","1509395176047-4a66953fd231","1451187580459-43490279c0fa","1519389950473-47ba0277781c","1526378722484-bd91ca387e72","1554774853-aae0a22c8aa4","1509228468518-180dd4864904","1508385082359-f38ae991e8f2","1517245386807-bb43f82c33c4","1547658719-da2b51169166","1454165804606-c3d57bc86b40","1544197150-b99a580bb7a8","1494790108377-be9c29b29330"][i]}?w=1200&h=630&fit=crop&auto=format`;
  return {
    id: String(i + 1),
    slug,
    title: t.title,
    excerpt: t.excerpt,
    category: t.category,
    author: AUTHORS[i % AUTHORS.length].name,
    authorRole: AUTHORS[i % AUTHORS.length].role,
    readMinutes: 6 + (i % 5),
    publishedAt: new Date(2026, 5, 28 - i).toISOString(),
    cover,
    tags: t.tags,
    body: paragraphsFor(t, i),
  };
});

export function getBlogBySlug(slug: string) {
  return BLOGS.find((b) => b.slug === slug);
}
