// XP + Level catalog. Keep in sync with public.builder_levels table.

export const XP_VALUES = {
  PROFILE_CREATED: 100,
  PROJECT_UPLOADED: 250,
  PROMPT_SHARED: 150,
  WORKFLOW_SHARED: 200,
  PROJECT_UPVOTED: 10,
  FOLLOWER_GAINED: 15,
  COMMUNITY_POST: 20,
  COMMENT_POSTED: 10,
  DAILY_LOGIN: 25,
  LOGIN_STREAK_7: 100,
  LOGIN_STREAK_30: 500,
  LOGIN_STREAK_100: 1000,
  REFERRAL_CONVERTED: 300,
  SERVICE_COMPLETED: 500,
  HIRED_VIA_VIBECODE: 1000,
  DAILY_CHALLENGE_WIN: 100,
  BUILDER_OF_WEEK: 1000,
} as const;

export type LevelInfo = {
  name: string;
  min: number;
  max: number | null;
  emoji: string;
  color: string;
};

export const LEVELS: LevelInfo[] = [
  { name: "Vibe Starter", min: 0, max: 499, emoji: "🌱", color: "#9CA3AF" },
  { name: "Vibe Builder", min: 500, max: 1999, emoji: "⚡", color: "#3B82F6" },
  { name: "Vibe Maker", min: 2000, max: 4999, emoji: "🔥", color: "#F97316" },
  { name: "Vibe Pro", min: 5000, max: 14999, emoji: "🚀", color: "#8B5CF6" },
  { name: "Vibe Legend", min: 15000, max: 49999, emoji: "💎", color: "#EAB308" },
  { name: "Vibe Master", min: 50000, max: null, emoji: "👑", color: "#E8623A" },
];

export function levelFor(xp: number): LevelInfo {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (xp >= LEVELS[i].min) return LEVELS[i];
  }
  return LEVELS[0];
}

export function nextLevel(xp: number): LevelInfo | null {
  const cur = levelFor(xp);
  const i = LEVELS.findIndex((l) => l.name === cur.name);
  return LEVELS[i + 1] ?? null;
}

export function progressToNext(xp: number): { pct: number; needed: number; next: LevelInfo | null } {
  const cur = levelFor(xp);
  const next = nextLevel(xp);
  if (!next) return { pct: 100, needed: 0, next: null };
  const span = next.min - cur.min;
  const gained = xp - cur.min;
  return { pct: Math.min(100, Math.round((gained / span) * 100)), needed: next.min - xp, next };
}

export const QUICK_XP_ACTIONS = [
  { label: "Upload a project", xp: XP_VALUES.PROJECT_UPLOADED, to: "/submit-project" as const },
  { label: "Share a prompt", xp: XP_VALUES.PROMPT_SHARED, to: "/submit" as const },
  { label: "Share a workflow", xp: XP_VALUES.WORKFLOW_SHARED, to: "/submit" as const },
  { label: "Post in a community", xp: XP_VALUES.COMMUNITY_POST, to: "/communities" as const },
];
