import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider, Small } from './_brand'

interface InviteEmailProps {
  siteName: string
  siteUrl: string
  confirmationUrl: string
}

export const InviteEmail = ({ confirmationUrl }: InviteEmailProps) => (
  <BrandLayout
    preview="You've been invited to VibeCoder"
    eyebrow="You're invited"
  >
    <H1>You're in 🚀</H1>
    <P>
      Someone from the VibeCoder team invited you to join India's largest
      community of vibe coders — builders shipping real products with AI.
    </P>
    <P>
      Accept the invite to claim your handle, complete your profile, and start
      posting your builds.
    </P>
    <CTA href={confirmationUrl}>Accept invite →</CTA>
    <Small>
      Link not working? Paste this URL in your browser:
      <br />
      {confirmationUrl}
    </Small>
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      Not expecting this invite? You can safely ignore this email.
    </P>
  </BrandLayout>
)

export default InviteEmail
