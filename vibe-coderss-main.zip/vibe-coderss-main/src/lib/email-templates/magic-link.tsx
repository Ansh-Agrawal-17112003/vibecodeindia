import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider, Small } from './_brand'

interface MagicLinkEmailProps {
  siteName: string
  confirmationUrl: string
}

export const MagicLinkEmail = ({ confirmationUrl }: MagicLinkEmailProps) => (
  <BrandLayout
    preview="Your one-tap sign-in link for VibeCoder"
    eyebrow="Magic link"
  >
    <H1>Sign in to VibeCoder ✨</H1>
    <P>
      Tap the button below to sign in instantly. No password needed — this
      link is unique to you and expires in 15 minutes.
    </P>
    <CTA href={confirmationUrl}>Sign me in →</CTA>
    <Small>
      Trouble with the button? Paste this URL in your browser:
      <br />
      {confirmationUrl}
    </Small>
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      If you didn't request this link, you can safely ignore this email — your
      account is safe.
    </P>
  </BrandLayout>
)

export default MagicLinkEmail
