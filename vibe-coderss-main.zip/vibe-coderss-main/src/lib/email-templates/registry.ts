import type { ComponentType } from 'react'
import { template as apologyOgRestored } from './apology-og-restored'
import { template as welcome } from './welcome'
import { template as contactConfirmation } from './contact-confirmation'
import { template as notification } from './notification'
import { template as accountAlert } from './account-alert'
import { template as earlyAccessThankYou } from './early-access-thankyou'
import { template as weeklyDigest } from './weekly-digest'
import { template as streakAtRisk } from './streak-at-risk'
import { template as weeklyMission } from './weekly-mission'
import { template as winback } from './winback'

export interface TemplateEntry {
  component: ComponentType<any>
  subject: string | ((data: Record<string, any>) => string)
  displayName?: string
  previewData?: Record<string, any>
  /** Fixed recipient — overrides caller-provided recipientEmail when set. */
  to?: string
}

/**
 * Template registry — maps template names to their React Email components.
 * Import and register new templates here after creating them in this directory.
 */
export const TEMPLATES: Record<string, TemplateEntry> = {
  'apology-og-restored': apologyOgRestored,
  welcome,
  'contact-confirmation': contactConfirmation,
  notification,
  'account-alert': accountAlert,
  'early-access-thankyou': earlyAccessThankYou,
  'weekly-digest': weeklyDigest,
  'streak-at-risk': streakAtRisk,
  'weekly-mission': weeklyMission,
  winback,
}
