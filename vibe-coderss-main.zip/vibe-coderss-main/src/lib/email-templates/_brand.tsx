import * as React from 'react'
import {
  Body,
  Container,
  Head,
  Hr,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from '@react-email/components'

/**
 * Shared brand layout for all VibeCoder emails.
 * Neo-brutalist, coral + black on a cream card over white body.
 * Body background MUST remain #ffffff per platform rules.
 */

export const BRAND = {
  name: 'VibeCoder',
  tagline: "India's largest vibe coders community",
  rootDomain: 'joinvibecode.xyz',
  siteUrl: 'https://www.joinvibecode.xyz',
  logoUrl:
    'https://www.joinvibecode.xyz/__l5e/assets-v1/96e2590a-3cb7-4a3d-9421-ad751ece70bf/vibecode-wordmark.png',
  coral: '#E8623A',
  ink: '#0F0F0F',
  cream: '#FFF6EE',
}

interface LayoutProps {
  preview: string
  eyebrow?: string
  children: React.ReactNode
}

export const BrandLayout = ({ preview, eyebrow, children }: LayoutProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{preview}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Link href={BRAND.siteUrl} style={{ textDecoration: 'none' }}>
            <Img
              src={BRAND.logoUrl}
              alt="VibeCoder"
              width="180"
              height="42"
              style={{ display: 'block', margin: '0 auto' }}
            />
          </Link>
          <Text style={brandTag}>{BRAND.tagline}</Text>
        </Section>

        <Section style={card}>
          {eyebrow ? <Text style={eyebrowStyle}>{eyebrow}</Text> : null}
          {children}
        </Section>

        <Section style={footerSection}>
          <Text style={footerText}>
            Sent with ♥ from the VibeCoder team ·{' '}
            <Link href={BRAND.siteUrl} style={footerLink}>
              {BRAND.rootDomain}
            </Link>
          </Text>
          <Text style={footerFine}>
            You're receiving this because you joined VibeCoder — India's
            largest community of vibe coders.
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

/* Shared UI pieces */

export const H1 = ({ children }: { children: React.ReactNode }) => (
  <Text style={h1}>{children}</Text>
)

export const P = ({
  children,
  style,
}: {
  children: React.ReactNode
  style?: React.CSSProperties
}) => <Text style={{ ...p, ...(style || {}) }}>{children}</Text>

export const Small = ({ children }: { children: React.ReactNode }) => (
  <Text style={pSmall}>{children}</Text>
)

export const CTA = ({
  href,
  children,
}: {
  href: string
  children: React.ReactNode
}) => (
  <Section style={{ textAlign: 'center' as const, margin: '26px 0 10px' }}>
    <Link href={href} style={ctaBtn}>
      {children}
    </Link>
  </Section>
)

export const Divider = () => <Hr style={hr} />

export const CodeBlock = ({ code }: { code: string }) => (
  <Section style={codeBox}>
    <Text style={codeText}>{code}</Text>
  </Section>
)

/* Styles */

const main = {
  backgroundColor: '#ffffff',
  fontFamily:
    "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif",
  color: BRAND.ink,
  padding: '24px 0',
}
const container = { maxWidth: '580px', margin: '0 auto', padding: '0 20px' }
const header = { textAlign: 'center' as const, padding: '4px 0 22px' }
const brandTag = {
  fontSize: '12px',
  color: '#7a7266',
  margin: '10px 0 0',
  textAlign: 'center' as const,
}
const card = {
  background: BRAND.cream,
  border: `1.5px solid ${BRAND.ink}`,
  borderRadius: '16px',
  padding: '30px 26px',
  boxShadow: `6px 6px 0 0 ${BRAND.ink}`,
}
const eyebrowStyle = {
  fontSize: '11px',
  fontWeight: 800 as const,
  letterSpacing: '0.14em',
  textTransform: 'uppercase' as const,
  color: BRAND.coral,
  margin: '0 0 10px',
}
const h1 = {
  fontSize: '26px',
  fontWeight: 800 as const,
  lineHeight: 1.2,
  margin: '0 0 16px',
  color: BRAND.ink,
}
const p = {
  fontSize: '15px',
  lineHeight: 1.6,
  color: '#2b2b2b',
  margin: '0 0 14px',
}
const pSmall = {
  fontSize: '12px',
  lineHeight: 1.5,
  color: '#6a6258',
  margin: '10px 0 0',
  textAlign: 'center' as const,
}
const ctaBtn = {
  background: BRAND.coral,
  color: '#ffffff',
  padding: '14px 26px',
  borderRadius: '10px',
  fontWeight: 800 as const,
  fontSize: '15px',
  textDecoration: 'none',
  border: `1.5px solid ${BRAND.ink}`,
  boxShadow: `3px 3px 0 0 ${BRAND.ink}`,
  display: 'inline-block',
}
const hr = { border: 'none', borderTop: '1px dashed #d6ccbc', margin: '22px 0' }
const codeBox = {
  background: '#ffffff',
  border: `1.5px solid ${BRAND.ink}`,
  borderRadius: '12px',
  padding: '18px',
  textAlign: 'center' as const,
  margin: '18px 0 6px',
  boxShadow: `3px 3px 0 0 ${BRAND.ink}`,
}
const codeText = {
  fontFamily: "'JetBrains Mono', Menlo, Courier, monospace",
  fontSize: '30px',
  fontWeight: 800 as const,
  letterSpacing: '0.35em',
  color: BRAND.coral,
  margin: 0,
}
const footerSection = { textAlign: 'center' as const, padding: '20px 8px 4px' }
const footerText = { fontSize: '12px', color: '#7a7266', margin: '0 0 6px' }
const footerLink = { color: BRAND.coral, textDecoration: 'none' }
const footerFine = { fontSize: '11px', color: '#a49a8b', margin: 0 }
