import React from "react";
import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Link,
  Preview,
  Section,
  Text,
} from "@react-email/components";
import type { TemplateEntry } from "./registry";

interface Props {
  firstName?: string;
  ogNumber?: number;
  badgeUrl?: string;
}

const Email = ({
  firstName = "there",
  ogNumber = 28,
  badgeUrl = "https://www.joinvibecode.xyz/founders-wall#og-28",
}: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>
      A sincere apology from the VibeCoder team — your OG Founder badge is
      restored.
    </Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={brandRow}>
          <Text style={brandMark}>VibeCoder</Text>
          <Text style={brandTag}>India's largest vibe coders community</Text>
        </Section>

        <Section style={card}>
          <Text style={eyebrow}>A note from the founding team</Text>
          <Heading style={h1}>We're sorry, {firstName} 🙏</Heading>

          <Text style={p}>
            Earlier today your OG Founder spot on the VibeCoder Founders Wall
            was hidden by mistake during a routine review. That was our error,
            not yours.
          </Text>

          <Text style={p}>
            We reviewed your submission again — your details look genuine, and
            you were one of the first 100 builders to back this community
            before we even launched. That means a lot to us, and it deserves to
            be visible.
          </Text>

          <Section style={badgeBox}>
            <Text style={badgeLabel}>Your OG Founder number</Text>
            <Text style={badgeNumber}>
              #{String(ogNumber).padStart(3, "0")}
            </Text>
            <Text style={badgeSub}>
              Restored and live on the Founders Wall
            </Text>
          </Section>

          <Section style={{ textAlign: "center", margin: "28px 0 8px" }}>
            <Button href={badgeUrl} style={ctaBtn}>
              View your OG Badge →
            </Button>
          </Section>

          <Text style={pSmall}>
            Or open it directly:{" "}
            <Link href={badgeUrl} style={link}>
              {badgeUrl}
            </Link>
          </Text>

          <Hr style={hr} />

          <Text style={p}>
            Thank you for your patience — and for being an OG. Reply to this
            email if anything still looks off; a real human on the team will
            fix it.
          </Text>

          <Text style={signoff}>
            With gratitude,
            <br />
            <b>The VibeCoder Team</b>
          </Text>
        </Section>

        <Text style={footer}>
          You're receiving this because you're an OG Founder on VibeCoder.
        </Text>
      </Container>
    </Body>
  </Html>
);

export const template = {
  component: Email,
  subject: "We owe you an apology — your OG Founder badge is restored 🙏",
  displayName: "OG Founder — Apology & Restore",
  previewData: {
    firstName: "Suman",
    ogNumber: 28,
    badgeUrl: "https://www.joinvibecode.xyz/founders-wall#og-28",
  },
} satisfies TemplateEntry;

const main = { backgroundColor: "#ffffff", fontFamily: "Inter, Arial, sans-serif", color: "#0F0F0F" };
const container = { maxWidth: "560px", margin: "0 auto", padding: "24px 20px" };
const brandRow = { textAlign: "center" as const, padding: "8px 0 20px" };
const brandMark = { fontSize: "22px", fontWeight: 800 as const, letterSpacing: "-0.02em", margin: 0, color: "#0F0F0F" };
const brandTag = { fontSize: "12px", color: "#7a7266", margin: "4px 0 0" };
const card = { background: "#FFF6EE", border: "1.5px solid #0F0F0F", borderRadius: "16px", padding: "28px 24px", boxShadow: "6px 6px 0 0 #0F0F0F" };
const eyebrow = { fontSize: "11px", fontWeight: 800 as const, letterSpacing: "0.14em", textTransform: "uppercase" as const, color: "#E8623A", margin: "0 0 8px" };
const h1 = { fontSize: "26px", fontWeight: 800 as const, lineHeight: 1.2, margin: "0 0 14px", color: "#0F0F0F" };
const p = { fontSize: "15px", lineHeight: 1.6, color: "#2b2b2b", margin: "0 0 14px" };
const pSmall = { fontSize: "12px", lineHeight: 1.5, color: "#6a6258", margin: "8px 0 0", textAlign: "center" as const };
const badgeBox = { background: "#ffffff", border: "1.5px solid #0F0F0F", borderRadius: "12px", padding: "16px", textAlign: "center" as const, margin: "18px 0 4px", boxShadow: "3px 3px 0 0 #0F0F0F" };
const badgeLabel = { fontSize: "11px", fontWeight: 800 as const, textTransform: "uppercase" as const, letterSpacing: "0.12em", color: "#7a7266", margin: 0 };
const badgeNumber = { fontSize: "40px", fontWeight: 900 as const, letterSpacing: "-0.02em", color: "#E8623A", margin: "4px 0 2px", fontFamily: "Georgia, serif" };
const badgeSub = { fontSize: "12px", color: "#4a4238", margin: 0 };
const ctaBtn = { background: "#E8623A", color: "#ffffff", padding: "14px 22px", borderRadius: "10px", fontWeight: 800 as const, fontSize: "15px", textDecoration: "none", border: "1.5px solid #0F0F0F", boxShadow: "3px 3px 0 0 #0F0F0F", display: "inline-block" };
const link = { color: "#E8623A", textDecoration: "underline", wordBreak: "break-all" as const };
const hr = { border: "none", borderTop: "1px dashed #d6ccbc", margin: "22px 0" };
const signoff = { fontSize: "15px", lineHeight: 1.6, color: "#0F0F0F", margin: "12px 0 0" };
const footer = { fontSize: "11px", color: "#8a8172", textAlign: "center" as const, margin: "18px 0 0" };
