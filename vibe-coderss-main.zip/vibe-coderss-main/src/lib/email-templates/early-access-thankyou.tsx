import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider, Small } from './_brand'
import type { TemplateEntry } from './registry'

interface Props {
  firstName?: string
  wallUrl?: string
  launchDate?: string
}

const Email = ({
  firstName = 'there',
  wallUrl = 'https://www.joinvibecode.xyz/founders-wall',
  launchDate = '4 August 2026',
}: Props) => (
  <BrandLayout
    preview="Thank you for being an early builder on VibeCoder 💛"
    eyebrow="A note from the founders"
  >
    <H1>Thank you, {firstName} 💛</H1>
    <P>
      You didn't wait for the launch. You didn't wait for the polish. You
      signed up when VibeCoder was still just a promise — and that means the
      world to us.
    </P>
    <P>
      Because of early builders like you, we're building India's largest
      community of vibe coders — a home for people shipping real products with
      AI, without gatekeeping and without noise.
    </P>
    <P>
      Your spot is locked in. When we go live on <b>{launchDate}</b>, you'll
      unlock:
    </P>
    <P style={{ margin: '0 0 8px' }}>
      🏆 <b>1 year of VibeCoder Pro</b> — completely free
    </P>
    <P style={{ margin: '0 0 8px' }}>
      💰 <b>500 VibeCoins</b> welcome bonus, on the house
    </P>
    <P style={{ margin: '0 0 8px' }}>
      👑 <b>OG Founder badge</b> on your profile, forever
    </P>
    <P style={{ margin: '0 0 14px' }}>
      🚪 <b>Early access</b> to every feature we ship
    </P>
    <CTA href={wallUrl}>See the Founders Wall →</CTA>
    <Small>
      This isn't a marketing blast — just a genuine thank-you from a small
      team building for you.
    </Small>
    <Divider />
    <P style={{ fontSize: 14, color: '#2b2b2b', margin: 0 }}>
      With gratitude,
      <br />
      <b>The VibeCoder team</b>
    </P>
  </BrandLayout>
)

export const template = {
  component: Email,
  subject: 'Thank you for being an early builder on VibeCoder 💛',
  displayName: 'Early Access — Thank You',
  previewData: {
    firstName: 'Suman',
    wallUrl: 'https://www.joinvibecode.xyz/founders-wall',
    launchDate: '4 August 2026',
  },
} satisfies TemplateEntry
