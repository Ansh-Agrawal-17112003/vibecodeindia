import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider } from './_brand'
import type { TemplateEntry } from './registry'

interface Props {
  firstName?: string
  dashboardUrl?: string
}

const Email = ({
  firstName = 'there',
  dashboardUrl = 'https://www.joinvibecode.xyz',
}: Props) => (
  <BrandLayout
    preview="Welcome to VibeCoder — let's build something great"
    eyebrow="Welcome"
  >
    <H1>Welcome, {firstName} 👋</H1>
    <P>
      Thanks for joining <b>VibeCoder</b> — India's largest community of vibe
      coders. You're now part of a community shipping real products with AI.
    </P>
    <P>Here's how to get the most out of your first week:</P>
    <P style={{ margin: '0 0 8px' }}>
      🚀 <b>Complete your profile</b> — get discovered by other builders
    </P>
    <P style={{ margin: '0 0 8px' }}>
      💡 <b>Post your first build</b> — even the rough drafts count
    </P>
    <P style={{ margin: '0 0 14px' }}>
      🤝 <b>Join a community</b> — find your tribe of builders
    </P>
    <CTA href={dashboardUrl}>Open my dashboard →</CTA>
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      Reply to this email any time — a real human on the team reads every
      message.
    </P>
  </BrandLayout>
)

export const template = {
  component: Email,
  subject: 'Welcome to VibeCoder 👋',
  displayName: 'Welcome (Thank You)',
  previewData: {
    firstName: 'Suman',
    dashboardUrl: 'https://www.joinvibecode.xyz/dashboard',
  },
} satisfies TemplateEntry
