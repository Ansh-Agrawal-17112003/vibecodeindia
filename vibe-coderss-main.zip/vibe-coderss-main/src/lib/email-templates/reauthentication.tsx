import * as React from 'react'
import { BrandLayout, H1, P, CodeBlock, Divider } from './_brand'

interface ReauthenticationEmailProps {
  token: string
}

export const ReauthenticationEmail = ({ token }: ReauthenticationEmailProps) => (
  <BrandLayout
    preview="Your VibeCoder verification code"
    eyebrow="Verify it's you"
  >
    <H1>Your verification code</H1>
    <P>
      Use the code below to confirm this is really you. The code expires in 10
      minutes.
    </P>
    <CodeBlock code={token} />
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      If you didn't ask for this code, ignore this email and consider changing
      your password.
    </P>
  </BrandLayout>
)

export default ReauthenticationEmail
