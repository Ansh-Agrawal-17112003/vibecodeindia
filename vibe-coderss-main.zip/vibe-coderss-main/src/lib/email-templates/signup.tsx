import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider, Small } from './_brand'

interface SignupEmailProps {
  siteName: string
  siteUrl: string
  recipient: string
  confirmationUrl: string
}

export const SignupEmail = ({
  recipient,
  confirmationUrl,
}: SignupEmailProps) => (
  <BrandLayout
    preview="Confirm your email to activate your VibeCoder account"
    eyebrow="Welcome aboard"
  >
    <H1>Confirm your email 🎉</H1>
    <P>
      You're one click away from joining India's largest community of vibe
      coders. Confirm <b>{recipient}</b> to activate your account and start
      shipping.
    </P>
    <CTA href={confirmationUrl}>Verify my email →</CTA>
    <Small>
      This link expires in 24 hours. If the button doesn't work, paste this
      URL into your browser:
      <br />
      {confirmationUrl}
    </Small>
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      Didn't sign up? You can safely ignore this email — no account will be
      created.
    </P>
  </BrandLayout>
)

export default SignupEmail
