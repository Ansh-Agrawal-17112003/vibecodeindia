import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider } from './_brand'
import type { TemplateEntry } from './registry'

interface Props {
  firstName?: string
  missionTitle?: string
  missionDescription?: string
  rewardCoins?: number
  bonusCoins?: number
  bonusFirstN?: number
  ctaLabel?: string
  ctaHref?: string
  leaderboard?: { name: string; xp: number }[]
  yourRank?: number | null
  yourXp?: number
}

const Email = ({
  firstName = 'there',
  missionTitle = "This week's mission",
  missionDescription = 'Ship something small and share it in the feed.',
  rewardCoins = 25,
  bonusCoins = 50,
  bonusFirstN = 10,
  ctaLabel = 'Join challenge →',
  ctaHref = 'https://www.joinvibecode.xyz/dashboard',
  leaderboard = [],
  yourRank = null,
  yourXp = 0,
}: Props) => (
  <BrandLayout preview={`Your week ${new Date().toLocaleDateString('en-IN', { weekday: 'long' })} mission — ${missionTitle}`} eyebrow="Weekly mission">
    <H1>🎯 {missionTitle}</H1>
    <P>Hey {firstName},</P>
    <P>{missionDescription}</P>
    <P>
      Reward: <b>+{rewardCoins} VibeCoins</b>. First {bonusFirstN} to complete
      get an extra <b>+{bonusCoins}</b>.
    </P>
    <CTA href={ctaHref}>{ctaLabel}</CTA>

    {leaderboard.length > 0 ? (
      <>
        <Divider />
        <P style={{ fontWeight: 700, margin: '0 0 8px' }}>Current top builders</P>
        <ol style={{ padding: '0 0 0 20px', margin: 0, color: '#2b2b2b', fontSize: 14, lineHeight: 1.7 }}>
          {leaderboard.map((l) => (
            <li key={l.name}>{l.name} — <b>{l.xp.toLocaleString()} XP</b></li>
          ))}
        </ol>
        {yourRank !== null ? (
          <P style={{ marginTop: 12, fontSize: 14 }}>
            You: <b>#{yourRank}</b> — {yourXp.toLocaleString()} XP
          </P>
        ) : null}
      </>
    ) : null}
  </BrandLayout>
)

export const template = {
  component: Email,
  subject: ({ missionTitle = "This week's mission" }: Props) => `🎯 ${missionTitle}`,
  displayName: 'Weekly Mission',
  previewData: {
    firstName: 'Suman',
    missionTitle: 'Ship in Public',
    missionDescription: 'Share one thing you shipped this week, no matter how small.',
    rewardCoins: 25,
    bonusCoins: 50,
    bonusFirstN: 10,
    leaderboard: [
      { name: 'Aarav', xp: 4820 },
      { name: 'Priya', xp: 4100 },
      { name: 'Rohit', xp: 3750 },
    ],
    yourRank: 47,
    yourXp: 1240,
  },
} satisfies TemplateEntry
