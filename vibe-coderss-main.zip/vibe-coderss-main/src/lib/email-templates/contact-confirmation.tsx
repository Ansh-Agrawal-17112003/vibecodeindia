import * as React from 'react'
import { BrandLayout, H1, P, Divider, Small } from './_brand'
import type { TemplateEntry } from './registry'

interface Props {
  firstName?: string
  senderName?: string
  message?: string
}

const Email = ({
  firstName = 'there',
  senderName = 'the VibeCoder team',
  message = "Thanks for reaching out — we'll get back to you within 24 hours.",
}: Props) => (
  <BrandLayout
    preview="We got your message — thanks for reaching out"
    eyebrow="Message received"
  >
    <H1>Thanks, {firstName} 💌</H1>
    <P>
      We got your message and it's now in front of the right person on our
      team.
    </P>
    <P style={{ background: '#fff', border: '1.5px dashed #0F0F0F', borderRadius: 10, padding: '14px 16px' }}>
      {message}
    </P>
    <P>
      In the meantime, feel free to explore the community, catch up on what
      other builders are shipping, or read the latest on the blog.
    </P>
    <Divider />
    <Small>— {senderName}</Small>
  </BrandLayout>
)

export const template = {
  component: Email,
  subject: 'We got your message — thanks for reaching out 💌',
  displayName: 'Contact Form Confirmation',
  previewData: {
    firstName: 'Suman',
    senderName: 'The VibeCoder team',
    message: 'How can we help you launch on VibeCoder?',
  },
} satisfies TemplateEntry
