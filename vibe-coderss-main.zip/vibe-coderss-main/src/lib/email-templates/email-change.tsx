import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider, Small } from './_brand'

interface EmailChangeEmailProps {
  siteName: string
  oldEmail: string
  email: string
  newEmail: string
  confirmationUrl: string
}

export const EmailChangeEmail = ({
  oldEmail,
  newEmail,
  confirmationUrl,
}: EmailChangeEmailProps) => (
  <BrandLayout
    preview="Confirm your new email address for VibeCoder"
    eyebrow="Email change"
  >
    <H1>Confirm your new email 📬</H1>
    <P>
      You asked to change the email on your VibeCoder account from{' '}
      <b>{oldEmail}</b> to <b>{newEmail}</b>. Confirm the change to keep
      everything in sync.
    </P>
    <CTA href={confirmationUrl}>Confirm change →</CTA>
    <Small>
      Link not working? Paste this URL in your browser:
      <br />
      {confirmationUrl}
    </Small>
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      Didn't request this? Please secure your account immediately by resetting
      your password.
    </P>
  </BrandLayout>
)

export default EmailChangeEmail
