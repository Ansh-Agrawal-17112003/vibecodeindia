import * as React from 'react'
import { BrandLayout, H1, P, CTA } from './_brand'
import type { TemplateEntry } from './registry'

interface Props {
  firstName?: string
  streak?: number
}

const Email = ({ firstName = 'there', streak = 3 }: Props) => (
  <BrandLayout preview={`Don't break your ${streak}-day streak — log in before midnight 🔥`} eyebrow="Streak alert">
    <H1>🔥 Your {streak}-day streak is at risk</H1>
    <P>Hey {firstName},</P>
    <P>
      You haven't logged in today. Keep the fire going — a quick visit, a react,
      a comment, or a post keeps your streak alive.
    </P>
    <CTA href="https://www.joinvibecode.xyz/vibe">Keep my streak alive →</CTA>
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      Streaks unlock badges, VibeCoins, and leaderboard perks. Milestones at
      7 / 30 / 100 days.
    </P>
  </BrandLayout>
)

export const template = {
  component: Email,
  subject: ({ streak = 3 }: Props) => `🔥 Don't break your ${streak}-day VibeCode streak`,
  displayName: 'Streak Reminder',
  previewData: { firstName: 'Suman', streak: 12 },
} satisfies TemplateEntry
