import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider } from './_brand'
import type { TemplateEntry } from './registry'

interface Props {
  firstName?: string
  profileViews?: number
  searchAppearances?: number
  newFollowers?: number
  topPostTitle?: string | null
  topPostViews?: number
  saves?: number
}

const Email = ({
  firstName = 'there',
  profileViews = 0,
  searchAppearances = 0,
  newFollowers = 0,
  topPostTitle,
  topPostViews = 0,
  saves = 0,
}: Props) => (
  <BrandLayout preview={`Your VibeCode weekly — ${profileViews} views, ${newFollowers} new followers`} eyebrow="Your weekly report">
    <H1>Hey {firstName}, here's your week on VibeCode 📊</H1>
    <P>People are noticing you. Here's the recap of the last 7 days:</P>
    <ul style={{ padding: '0 0 0 20px', margin: '10px 0 18px', color: '#2b2b2b', fontSize: 15, lineHeight: 1.8 }}>
      <li>Your profile was viewed <b>{profileViews}</b> {profileViews === 1 ? 'time' : 'times'}</li>
      <li>You appeared in <b>{searchAppearances}</b> searches</li>
      <li><b>{newFollowers}</b> new {newFollowers === 1 ? 'builder' : 'builders'} started following you</li>
      <li><b>{saves}</b> {saves === 1 ? 'person' : 'people'} saved something of yours</li>
      {topPostTitle ? <li>Your top post — <i>"{topPostTitle}"</i> — got <b>{topPostViews}</b> views</li> : null}
    </ul>
    <CTA href="https://www.joinvibecode.xyz/analytics">See your full analytics →</CTA>
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      Keep shipping — the hirers and collaborators watching your feed are real.
    </P>
  </BrandLayout>
)

export const template = {
  component: Email,
  subject: ({ profileViews = 0 }: Props) =>
    profileViews > 0
      ? `📊 ${profileViews} people viewed your VibeCode profile this week`
      : 'Your VibeCode weekly report is ready',
  displayName: 'Weekly Digest',
  previewData: { firstName: 'Suman', profileViews: 23, searchAppearances: 14, newFollowers: 2, topPostTitle: 'Idea to app in 24h', topPostViews: 89, saves: 3 },
} satisfies TemplateEntry
