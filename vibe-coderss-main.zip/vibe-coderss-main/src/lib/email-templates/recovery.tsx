import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider, Small } from './_brand'

interface RecoveryEmailProps {
  siteName: string
  confirmationUrl: string
}

export const RecoveryEmail = ({ confirmationUrl }: RecoveryEmailProps) => (
  <BrandLayout
    preview="Reset your VibeCoder password"
    eyebrow="Password reset"
  >
    <H1>Reset your password 🔐</H1>
    <P>
      We got a request to reset the password on your VibeCoder account. Click
      the button below to choose a new one. This link expires in 1 hour.
    </P>
    <CTA href={confirmationUrl}>Reset password →</CTA>
    <Small>
      If the button doesn't work, paste this URL in your browser:
      <br />
      {confirmationUrl}
    </Small>
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      Didn't request this? You can ignore this email — your password stays the
      same. If you keep getting these, secure your account by signing in and
      reviewing your sessions.
    </P>
  </BrandLayout>
)

export default RecoveryEmail
