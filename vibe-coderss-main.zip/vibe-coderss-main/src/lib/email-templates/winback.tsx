import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider } from './_brand'
import type { TemplateEntry } from './registry'

interface Props {
  firstName?: string
  profileViews?: number
  searchAppearances?: number
  streak?: number
  highlights?: string[]
  jobsCount?: number
}

const Email = ({
  firstName = 'there',
  profileViews = 0,
  searchAppearances = 0,
  streak = 0,
  highlights = [],
  jobsCount = 0,
}: Props) => (
  <BrandLayout preview={`You missed a lot on VibeCode this week, ${firstName}`} eyebrow="You've been missed">
    <H1>Hey {firstName}, you missed something 👀</H1>
    <P>Here's what happened on VibeCode while you were away:</P>
    <ul style={{ padding: '0 0 0 20px', margin: '10px 0 18px', color: '#2b2b2b', fontSize: 15, lineHeight: 1.8 }}>
      {highlights.map((h, i) => <li key={i}>{h}</li>)}
      {jobsCount > 0 ? <li><b>{jobsCount}</b> new AI jobs were posted matching your skills</li> : null}
      {profileViews > 0 ? <li>Your profile was viewed <b>{profileViews}</b> times</li> : null}
      {searchAppearances > 0 ? <li><b>{searchAppearances}</b> hirers found you in searches</li> : null}
    </ul>
    <CTA href="https://www.joinvibecode.xyz/vibe">Open VibeCode →</CTA>
    <Divider />
    {streak >= 3 ? (
      <P style={{ fontSize: 13, color: '#6a6258' }}>
        P.S. Your 🔥 <b>{streak}-day streak</b> just broke. Come back today and
        start a new one — the badges reset when you do.
      </P>
    ) : (
      <P style={{ fontSize: 13, color: '#6a6258' }}>
        P.S. Log in today and start a fresh streak — 7-day badge is the first milestone.
      </P>
    )}
  </BrandLayout>
)

export const template = {
  component: Email,
  subject: ({ firstName = 'there' }: Props) => `You missed something, ${firstName}`,
  displayName: 'Win-back',
  previewData: {
    firstName: 'Suman',
    profileViews: 12,
    searchAppearances: 4,
    streak: 12,
    jobsCount: 3,
    highlights: [
      'Aarav shipped a new n8n automation you\'d love',
      'Priya shared a Claude prompt that got copied 847 times',
      'The Lovable Builders community had 234 new posts',
    ],
  },
} satisfies TemplateEntry
