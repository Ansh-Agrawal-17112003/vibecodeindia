import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider } from './_brand'
import type { TemplateEntry } from './registry'

interface Props {
  firstName?: string
  title?: string
  body?: string
  actionLabel?: string
  actionUrl?: string
}

const Email = ({
  firstName = 'there',
  title = 'You have a new update',
  body = 'Something new happened on VibeCoder that you might care about.',
  actionLabel = 'Open on VibeCoder →',
  actionUrl = 'https://www.joinvibecode.xyz',
}: Props) => (
  <BrandLayout preview={title} eyebrow="Notification">
    <H1>{title}</H1>
    <P>Hey {firstName},</P>
    <P>{body}</P>
    {actionUrl ? <CTA href={actionUrl}>{actionLabel}</CTA> : null}
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      You can manage what you get notified about anytime from your account
      settings.
    </P>
  </BrandLayout>
)

export const template = {
  component: Email,
  subject: ({ title }: { title?: string }) =>
    title || 'You have a new update on VibeCoder',
  displayName: 'Generic Notification',
  previewData: {
    firstName: 'Suman',
    title: 'Someone commented on your build',
    body: '@rohitk left a comment on your project "Idea to App in 24h". Jump in and reply.',
    actionLabel: 'View comment →',
    actionUrl: 'https://www.joinvibecode.xyz',
  },
} satisfies TemplateEntry
