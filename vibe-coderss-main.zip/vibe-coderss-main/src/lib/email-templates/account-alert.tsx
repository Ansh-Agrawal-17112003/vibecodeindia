import * as React from 'react'
import { BrandLayout, H1, P, CTA, Divider } from './_brand'
import type { TemplateEntry } from './registry'

interface Props {
  firstName?: string
  change?: string
  when?: string
  ipHint?: string
  secureUrl?: string
}

const Email = ({
  firstName = 'there',
  change = 'Your password was updated',
  when = 'just now',
  ipHint = 'unknown location',
  secureUrl = 'https://www.joinvibecode.xyz/settings',
}: Props) => (
  <BrandLayout
    preview="A change was made to your VibeCoder account"
    eyebrow="Account activity"
  >
    <H1>Account updated 🔔</H1>
    <P>Hi {firstName},</P>
    <P>
      <b>{change}</b> — {when}
      {ipHint ? <> · {ipHint}</> : null}.
    </P>
    <P>
      If this was you, no action is needed. If it wasn't, secure your account
      immediately by resetting your password and reviewing active sessions.
    </P>
    <CTA href={secureUrl}>Review my account →</CTA>
    <Divider />
    <P style={{ fontSize: 13, color: '#6a6258' }}>
      We send these alerts to help you keep your account safe.
    </P>
  </BrandLayout>
)

export const template = {
  component: Email,
  subject: 'Security alert — a change was made to your account',
  displayName: 'Account Activity Alert',
  previewData: {
    firstName: 'Suman',
    change: 'Your password was updated',
    when: 'just now',
    ipHint: 'Mumbai, IN',
    secureUrl: 'https://www.joinvibecode.xyz/settings',
  },
} satisfies TemplateEntry
