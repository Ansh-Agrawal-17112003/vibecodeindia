import { createMiddleware, createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

function isNewSupabaseApiKey(value: string): boolean {
  return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}

function createSupabaseFetch(supabaseKey: string): typeof fetch {
  return (input, init) => {
    const headers = new Headers(
      typeof Request !== "undefined" && input instanceof Request ? input.headers : undefined,
    );
    if (init?.headers) {
      new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    }
    if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) {
      headers.delete("Authorization");
    }
    headers.set("apikey", supabaseKey);
    return fetch(input, { ...init, headers });
  };
}

function getCloudEnv() {
  const url = process.env.SUPABASE_URL;
  const anon = process.env.SUPABASE_PUBLISHABLE_KEY;
  const service = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !anon || !service) throw new Error("Backend is not configured");
  return { url, anon, service };
}

function makeCloudAdmin() {
  const { url, service } = getCloudEnv();
  return createClient<Database>(url, service, {
    global: { fetch: createSupabaseFetch(service) },
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

const requireAdminStatsAuth = createMiddleware({ type: "function" }).server(async ({ next }) => {
  const { url, anon } = getCloudEnv();
  const authHeader = getRequest()?.headers?.get("authorization") ?? "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
  if (!token || token.split(".").length !== 3) throw new Error("Please sign in again to load live stats");

  const supabase = createClient<Database>(url, anon, {
    global: {
      fetch: createSupabaseFetch(anon),
      headers: { Authorization: `Bearer ${token}` },
    },
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });

  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) throw new Error("Please sign in again to load live stats");

  return next({ context: { supabase, userId: data.user.id } });
});

async function assertAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  const { data: sdata } = await supabase.rpc("has_role", { _user_id: userId, _role: "super_admin" });
  if (error) throw new Error("Forbidden");
  if (!data && !sdata) throw new Error("Admin only");
}

const DAY = 86_400_000;

async function listAuthenticatedUsers(supabaseAdmin: any) {
  const users: any[] = [];
  for (let page = 1; page < 100; page += 1) {
    const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 1000 });
    if (error) throw error;
    const batch = data?.users ?? [];
    users.push(...batch);
    if (batch.length < 1000) break;
  }
  return users.filter((u) => u.email_confirmed_at);
}

export const getDashboardStats = createServerFn({ method: "GET" })
  .middleware([requireAdminStatsAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();


    const now = Date.now();
    const dayAgo = new Date(now - DAY).toISOString();
    const weekAgo = new Date(now - 7 * DAY).toISOString();

    const authUsers = await listAuthenticatedUsers(supabaseAdmin);
    const authUserIds = new Set(authUsers.map((u) => u.id).filter(Boolean));
    const authCreatedAt = authUsers
      .map((u) => u.created_at)
      .filter(Boolean)
      .map((d) => new Date(d).getTime());

    const count = async (table: string, apply?: (q: any) => any) => {
      let q: any = (supabaseAdmin as any).from(table).select("*", { count: "exact", head: true });
      if (apply) q = apply(q);
      const { count: c } = await q;
      return c ?? 0;
    };

    const safe = async (p: Promise<number>) => p.catch(() => 0);

    const [
      totalUsers,
      newUsersToday,
      newUsersWeek,
      totalCommunities,
      communitiesWeek,
      totalJobs,
      jobsToday,
      totalProjects,
      projectsWeek,
      totalPrompts,
      pendingReports,
      totalSubs,
      ogStatsResult,
      ogMembersResult,
    ] = await Promise.all([
      Promise.resolve(authUsers.length),
      Promise.resolve(authCreatedAt.filter((t) => t >= new Date(dayAgo).getTime()).length),
      Promise.resolve(authCreatedAt.filter((t) => t >= new Date(weekAgo).getTime()).length),
      safe(count("communities", (q) => q.eq("is_demo", false))),
      safe(count("communities", (q) => q.eq("is_demo", false).gte("created_at", weekAgo))),
      safe(count("jobs")),
      safe(count("jobs", (q) => q.gte("created_at", dayAgo))),
      safe(count("projects", (q) => q.eq("is_demo", false))),
      safe(count("projects", (q) => q.eq("is_demo", false).gte("created_at", weekAgo))),
      safe(count("prompts")),
      safe(count("bug_reports", (q) => q.eq("status", "open"))),
      safe(count("subscriptions", (q) => q.eq("status", "active"))),
      Promise.resolve((supabaseAdmin as any).from("og_spots_remaining").select("remaining, taken, next_number").maybeSingle()).catch(() => ({ data: null })),
      Promise.resolve(
        (supabaseAdmin as any)
          .from("og_members")
          .select("id, full_name, username, city, state, og_number, og_status, show_on_wall, signed_up_at")
          .order("og_number", { ascending: true, nullsFirst: false })
          .limit(12)
      ).catch(() => ({ data: [] })),
    ]);

    // Daily signups for last 30 days
    const since = new Date(now - 30 * DAY).toISOString();
    const bucket: Record<string, number> = {};
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now - i * DAY);
      const key = `${d.getDate()}/${d.getMonth() + 1}`;
      bucket[key] = 0;
    }
    for (const user of authUsers) {
      if (!user.created_at || new Date(user.created_at).getTime() < new Date(since).getTime()) continue;
      const d = new Date(user.created_at);
      const key = `${d.getDate()}/${d.getMonth() + 1}`;
      if (key in bucket) bucket[key] += 1;
    }
    const growth = Object.entries(bucket).map(([day, users]) => ({ day, users }));

    // Recent signups list
    const recentAuthUsers = [...authUsers]
      .sort((a, b) => new Date(b.created_at ?? 0).getTime() - new Date(a.created_at ?? 0).getTime())
      .slice(0, 8);
    const recentIds = recentAuthUsers.map((u) => u.id).filter(Boolean);
    const { data: profileRows } = recentIds.length ? await (supabaseAdmin as any)
      .from("profiles")
      .select("id, display_name, username, avatar_url, created_at")
      .in("id", recentIds) : { data: [] };
    const profilesById = new Map(((profileRows ?? []) as any[]).map((p) => [p.id, p]));

    // Roles for those signups
    const ids = recentIds;
    let rolesMap: Record<string, "super_admin" | "admin" | "user"> = {};
    if (ids.length) {
      const { data: roleRows } = await (supabaseAdmin as any)
        .from("user_roles")
        .select("user_id, role")
        .in("user_id", ids);
      for (const r of (roleRows ?? []) as any[]) {
        const prev = rolesMap[r.user_id];
        if (r.role === "super_admin") rolesMap[r.user_id] = "super_admin";
        else if (r.role === "admin" && prev !== "super_admin") rolesMap[r.user_id] = "admin";
        else if (!prev) rolesMap[r.user_id] = "user";
      }
    }

    return {
      stats: {
        totalUsers,
        newUsersToday,
        newUsersWeek,
        activeToday: newUsersToday,
        communities: totalCommunities,
        communitiesWeek,
        jobs: totalJobs,
        jobsToday,
        projects: totalProjects,
        projectsWeek,
        prompts: totalPrompts,
        pendingReports,
        activeSubscriptions: totalSubs,
      },
      ogStats: {
        taken: Number(ogStatsResult?.data?.taken ?? 0),
        remaining: Number(ogStatsResult?.data?.remaining ?? 100),
        nextNumber: Number(ogStatsResult?.data?.next_number ?? 1),
      },
      ogMembers: ((ogMembersResult?.data ?? []) as any[]).map((m) => ({
        id: m.id,
        full_name: m.full_name,
        username: m.username ?? null,
        city: m.city ?? null,
        state: m.state ?? null,
        og_number: m.og_number ?? null,
        og_status: m.og_status ?? "pending",
        show_on_wall: !!m.show_on_wall,
        signed_up_at: m.signed_up_at ?? new Date().toISOString(),
      })),
      growth,
      recentSignups: recentAuthUsers.map((u) => {
        const p = profilesById.get(u.id) as any;
        const fallbackName = typeof u.email === "string" ? u.email.split("@")[0] : "User";
        return {
          id: u.id,
          name: p?.display_name ?? p?.username ?? fallbackName,
          username: p?.username ?? null,
          avatar_url: p?.avatar_url ?? null,
          created_at: u.created_at ?? p?.created_at ?? new Date().toISOString(),
          role: rolesMap[u.id] ?? "user",
        };
      }),
    };
  });

// ---------------------------------------------------------------------------
// listAdminUsers — auth users joined with profiles + roles
// ---------------------------------------------------------------------------
export const listAdminUsers = createServerFn({ method: "POST" })
  .middleware([requireAdminStatsAuth])
  .inputValidator((input) => z.object({
    search: z.string().optional(),
    role: z.enum(["all", "super_admin", "admin", "user"]).default("all"),
    limit: z.number().int().min(1).max(200).default(100),
  }).parse(input ?? {}))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();
    const authUsers = await listAuthenticatedUsers(supabaseAdmin);
    const ids = authUsers.map((u) => u.id);
    const emails = authUsers.map((u) => (u.email ?? "").toLowerCase()).filter(Boolean);
    const [{ data: profileRows }, { data: roleRows }, { data: ogRows }] = await Promise.all([
      (supabaseAdmin as any).from("profiles")
        .select("id, display_name, username, avatar_url, created_at, follower_count, total_xp, is_demo")
        .in("id", ids),
      (supabaseAdmin as any).from("user_roles").select("user_id, role").in("user_id", ids),
      (supabaseAdmin as any).from("og_members")
        .select("profile_id, email, og_number, og_status")
        .or(
          `profile_id.in.(${ids.length ? ids.join(",") : "00000000-0000-0000-0000-000000000000"}),email.in.(${emails.length ? emails.map((e) => `"${e}"`).join(",") : '""'})`,
        ),
    ]);
    const profilesById = new Map(((profileRows ?? []) as any[]).map((p) => [p.id, p]));
    const ogByProfile = new Map<string, any>();
    const ogByEmail = new Map<string, any>();
    for (const r of (ogRows ?? []) as any[]) {
      if (r.profile_id) ogByProfile.set(r.profile_id, r);
      if (r.email) ogByEmail.set(String(r.email).toLowerCase(), r);
    }
    const rolesMap: Record<string, "super_admin" | "admin" | "user"> = {};
    for (const r of (roleRows ?? []) as any[]) {
      const prev = rolesMap[r.user_id];
      if (r.role === "super_admin") rolesMap[r.user_id] = "super_admin";
      else if (r.role === "admin" && prev !== "super_admin") rolesMap[r.user_id] = "admin";
      else if (!prev) rolesMap[r.user_id] = "user";
    }
    let rows = authUsers.map((u) => {
      const p = profilesById.get(u.id) as any;
      const og = ogByProfile.get(u.id) ?? ogByEmail.get((u.email ?? "").toLowerCase());
      const ogStatus: string | null = og?.og_status ?? null;
      return {
        id: u.id,
        email: u.email ?? "",
        name: p?.display_name ?? p?.username ?? (u.email ? u.email.split("@")[0] : "User"),
        username: p?.username ?? null,
        avatar_url: p?.avatar_url ?? null,
        role: rolesMap[u.id] ?? "user",
        created_at: u.created_at ?? p?.created_at ?? new Date().toISOString(),
        last_sign_in_at: u.last_sign_in_at ?? null,
        followers: p?.follower_count ?? 0,
        xp: p?.total_xp ?? 0,
        is_demo: !!p?.is_demo,
        og_number: og?.og_number ?? null,
        og_status: ogStatus,
        is_early_access: !!ogStatus && ogStatus !== "activated",
      };
    });
    if (data.role !== "all") rows = rows.filter((r) => r.role === data.role);
    if (data.search) {
      const q = data.search.toLowerCase();
      rows = rows.filter((r) => r.name.toLowerCase().includes(q) || r.email.toLowerCase().includes(q));
    }
    rows.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    return { rows: rows.slice(0, data.limit), total: rows.length };
  });

// ---------------------------------------------------------------------------
// listAdminCommunities
// ---------------------------------------------------------------------------
export const listAdminCommunities = createServerFn({ method: "GET" })
  .middleware([requireAdminStatsAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();
    const { data, error } = await (supabaseAdmin as any).from("communities")
      .select("id, slug, name, icon_url, member_count, privacy, pricing_type, status, is_official, created_by, created_at, is_demo")
      .eq("is_demo", false)
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    const creatorIds = [...new Set(((data ?? []) as any[]).map((c) => c.created_by).filter(Boolean))];
    const { data: creators } = creatorIds.length
      ? await (supabaseAdmin as any).from("profiles").select("id, display_name, username").in("id", creatorIds)
      : { data: [] };
    const creatorMap = new Map(((creators ?? []) as any[]).map((p) => [p.id, p.display_name ?? p.username ?? "Unknown"]));
    return {
      rows: ((data ?? []) as any[]).map((c) => ({
        id: c.id,
        slug: c.slug,
        name: c.name,
        icon_url: c.icon_url,
        member_count: c.member_count ?? 0,
        privacy: c.privacy,
        pricing_type: c.pricing_type,
        status: c.status,
        is_official: !!c.is_official,
        created_at: c.created_at,
        created_by_name: c.created_by ? creatorMap.get(c.created_by) ?? "Unknown" : "System",
      })),
    };
  });

// ---------------------------------------------------------------------------
// listAdminJobs
// ---------------------------------------------------------------------------
export const listAdminJobs = createServerFn({ method: "GET" })
  .middleware([requireAdminStatsAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();
    const { data, error } = await (supabaseAdmin as any).from("jobs")
      .select("id, title, job_type, location, remote_type, salary_min, salary_max, status, created_at, posted_by, company_id")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    const rows = (data ?? []) as any[];
    const [companyIds, posterIds] = [
      [...new Set(rows.map((r) => r.company_id).filter(Boolean))],
      [...new Set(rows.map((r) => r.posted_by).filter(Boolean))],
    ];
    const [{ data: companies }, { data: posters }, appsAgg] = await Promise.all([
      companyIds.length ? (supabaseAdmin as any).from("companies").select("id, name").in("id", companyIds) : Promise.resolve({ data: [] }),
      posterIds.length ? (supabaseAdmin as any).from("profiles").select("id, display_name, username").in("id", posterIds) : Promise.resolve({ data: [] }),
      rows.length
        ? (supabaseAdmin as any).from("job_applications").select("job_id").in("job_id", rows.map((r) => r.id))
        : Promise.resolve({ data: [] }),
    ]);
    const companyMap = new Map(((companies ?? []) as any[]).map((c) => [c.id, c.name]));
    const posterMap = new Map(((posters ?? []) as any[]).map((p) => [p.id, p.display_name ?? p.username ?? "Unknown"]));
    const appsMap: Record<string, number> = {};
    for (const a of ((appsAgg?.data ?? []) as any[])) appsMap[a.job_id] = (appsMap[a.job_id] ?? 0) + 1;
    return {
      rows: rows.map((j) => ({
        id: j.id,
        title: j.title,
        company: j.company_id ? companyMap.get(j.company_id) ?? "—" : (j.posted_by ? posterMap.get(j.posted_by) ?? "—" : "—"),
        job_type: j.job_type,
        location: j.location ?? j.remote_type ?? "—",
        remote_type: j.remote_type,
        salary: j.salary_min || j.salary_max
          ? `₹${((j.salary_min ?? 0) / 1000).toFixed(0)}k–₹${((j.salary_max ?? 0) / 1000).toFixed(0)}k`
          : "—",
        status: j.status,
        posted_at: j.created_at,
        applicants: appsMap[j.id] ?? 0,
      })),
    };
  });

// ---------------------------------------------------------------------------
// listAdminProjects — all real user projects (excludes demo)
// ---------------------------------------------------------------------------
export const listAdminProjects = createServerFn({ method: "GET" })
  .middleware([requireAdminStatsAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();
    const { data, error } = await (supabaseAdmin as any).from("projects")
      .select("id, title, cover_image_url, industry, tools_used, tags, upvote_count, live_demo_url, github_url, featured_until, created_at, builder_id, is_demo")
      .eq("is_demo", false)
      .order("created_at", { ascending: false })
      .limit(500);
    if (error) throw new Error(error.message);
    const rows = (data ?? []) as any[];
    const builderIds = [...new Set(rows.map((r) => r.builder_id).filter(Boolean))];
    const { data: builders } = builderIds.length
      ? await (supabaseAdmin as any).from("profiles").select("id, display_name, username, avatar_url").in("id", builderIds)
      : { data: [] };
    const builderMap = new Map(((builders ?? []) as any[]).map((p) => [p.id, p]));
    return {
      rows: rows.map((p) => {
        const b = p.builder_id ? builderMap.get(p.builder_id) as any : null;
        return {
          id: p.id,
          title: p.title,
          cover_image_url: p.cover_image_url,
          industry: p.industry ?? "—",
          tools_used: p.tools_used ?? [],
          tags: p.tags ?? [],
          upvote_count: p.upvote_count ?? 0,
          live_demo_url: p.live_demo_url,
          github_url: p.github_url,
          featured: p.featured_until ? new Date(p.featured_until).getTime() > Date.now() : false,
          created_at: p.created_at,
          builder_id: p.builder_id,
          builder_name: b?.display_name ?? b?.username ?? "Unknown",
          builder_username: b?.username ?? null,
          builder_avatar: b?.avatar_url ?? null,
        };
      }),
    };
  });

// ---------------------------------------------------------------------------
// listAdminReports — bug_reports table + reporter display info
// ---------------------------------------------------------------------------
export const listAdminReports = createServerFn({ method: "POST" })
  .middleware([requireAdminStatsAuth])
  .inputValidator((input) => z.object({
    status: z.enum(["all", "open", "in_progress", "resolved", "closed"]).default("all"),
  }).parse(input ?? {}))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();
    let q: any = (supabaseAdmin as any).from("bug_reports")
      .select("id, reporter_id, title, description, page_url, status, created_at")
      .order("created_at", { ascending: false })
      .limit(200);
    if (data.status !== "all") q = q.eq("status", data.status);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    const reporterIds = [...new Set(((rows ?? []) as any[]).map((r) => r.reporter_id).filter(Boolean))];
    const { data: reporters } = reporterIds.length
      ? await (supabaseAdmin as any).from("profiles").select("id, display_name, username").in("id", reporterIds)
      : { data: [] };
    const reporterMap = new Map(((reporters ?? []) as any[]).map((p) => [p.id, p.display_name ?? p.username ?? "User"]));
    const counts = { open: 0, in_progress: 0, resolved: 0, closed: 0, total: (rows ?? []).length };
    for (const r of ((rows ?? []) as any[])) {
      if (r.status in counts) (counts as any)[r.status] += 1;
    }
    return {
      counts,
      rows: ((rows ?? []) as any[]).map((r) => ({
        id: r.id,
        title: r.title,
        description: r.description,
        page_url: r.page_url,
        status: r.status,
        created_at: r.created_at,
        reporter_name: r.reporter_id ? reporterMap.get(r.reporter_id) ?? "User" : "Anonymous",
      })),
    };
  });

// ---------------------------------------------------------------------------
// updateReportStatus
// ---------------------------------------------------------------------------
export const updateReportStatus = createServerFn({ method: "POST" })
  .middleware([requireAdminStatsAuth])
  .inputValidator((input) => z.object({
    id: z.string().uuid(),
    status: z.enum(["open", "in_progress", "resolved", "closed"]),
  }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();
    const { error } = await (supabaseAdmin as any).from("bug_reports").update({ status: data.status }).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { success: true };
  });

// ---------------------------------------------------------------------------
// getAdminAnalytics — growth over 30 days across users/communities/jobs/projects
// ---------------------------------------------------------------------------
export const getAdminAnalytics = createServerFn({ method: "GET" })
  .middleware([requireAdminStatsAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();
    const now = Date.now();
    const since = new Date(now - 30 * DAY).toISOString();

    const authUsers = await listAuthenticatedUsers(supabaseAdmin);

    const [{ data: comms }, { data: jobsRows }, { data: projRows }, { data: topComms }] = await Promise.all([
      (supabaseAdmin as any).from("communities").select("created_at, is_demo").eq("is_demo", false).gte("created_at", since),
      (supabaseAdmin as any).from("jobs").select("created_at").gte("created_at", since),
      (supabaseAdmin as any).from("projects").select("created_at, is_demo").eq("is_demo", false).gte("created_at", since),
      (supabaseAdmin as any).from("communities").select("name, member_count, is_demo").eq("is_demo", false).order("member_count", { ascending: false }).limit(6),
    ]);

    const days: { day: string; users: number; communities: number; jobs: number; projects: number }[] = [];
    const keyFor = (d: Date) => `${d.getDate()}/${d.getMonth() + 1}`;
    const idx: Record<string, number> = {};
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now - i * DAY);
      const k = keyFor(d);
      idx[k] = days.length;
      days.push({ day: k, users: 0, communities: 0, jobs: 0, projects: 0 });
    }
    const bump = (arr: any[] | null | undefined, field: "users" | "communities" | "jobs" | "projects") => {
      for (const r of (arr ?? []) as any[]) {
        if (!r.created_at) continue;
        const k = keyFor(new Date(r.created_at));
        if (k in idx) days[idx[k]][field] += 1;
      }
    };
    bump(authUsers.map((u) => ({ created_at: u.created_at })), "users");
    bump(comms, "communities");
    bump(jobsRows, "jobs");
    bump(projRows, "projects");

    const totals = {
      users: authUsers.length,
      communities: (comms ?? []).length,
      jobs: (jobsRows ?? []).length,
      projects: (projRows ?? []).length,
    };
    return {
      growth: days,
      totalsLast30: totals,
      topCommunities: ((topComms ?? []) as any[]).map((c) => ({ name: c.name, members: c.member_count ?? 0 })),
    };
  });

// ---------------------------------------------------------------------------
// Role management (super_admin only)
// ---------------------------------------------------------------------------
async function assertSuperAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "super_admin" });
  if (error || !data) throw new Error("Super Admin only");
}

export const grantAdminRole = createServerFn({ method: "POST" })
  .middleware([requireAdminStatsAuth])
  .inputValidator((input) => z.object({ userId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();
    const { error } = await (supabaseAdmin as any)
      .from("user_roles")
      .upsert({ user_id: data.userId, role: "admin" }, { onConflict: "user_id,role", ignoreDuplicates: true });
    if (error) throw new Error(error.message);
    return { success: true };
  });

export const revokeAdminRole = createServerFn({ method: "POST" })
  .middleware([requireAdminStatsAuth])
  .inputValidator((input) => z.object({ userId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const supabaseAdmin = makeCloudAdmin();
    const { data: isSuper } = await (supabaseAdmin as any).rpc("has_role", { _user_id: data.userId, _role: "super_admin" });
    if (isSuper) throw new Error("Cannot remove admin role from a Super Admin");
    const { error } = await (supabaseAdmin as any)
      .from("user_roles").delete()
      .eq("user_id", data.userId).eq("role", "admin");
    if (error) throw new Error(error.message);
    return { success: true };
  });
