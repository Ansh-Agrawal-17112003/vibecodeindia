import { supabase } from "@/integrations/supabase/client";

export type SuggestedPerson = {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  roles: string[] | null;
  availability_status: string | null;
  follower_count: number | null;
};

/** Fetch real profiles to suggest for follow. Excludes demo/seed profiles and (optionally) the current user + already-followed ids. OG founding members are prepended. */
export async function listSuggestedPeople(limit = 12): Promise<SuggestedPerson[]> {
  const { data: auth } = await supabase.auth.getUser();
  const me = auth.user?.id ?? null;

  let followingIds: string[] = [];
  if (me) {
    const { data } = await (supabase as any)
      .from("follows")
      .select("following_id")
      .eq("follower_id", me);
    followingIds = (data ?? []).map((r: any) => r.following_id);
  }

  // OG founding members first — they are the real early users we want to surface.
  let ogSuggested: SuggestedPerson[] = [];
  try {
    const { listOgMembers, ogToSuggested } = await import("@/lib/og-members-api");
    const og = await listOgMembers(50);
    ogSuggested = og.map(ogToSuggested);
  } catch { /* non-fatal */ }

  let q = (supabase as any)
    .from("profiles")
    .select("id, username, display_name, avatar_url, bio, roles, availability_status, follower_count")
    .or("is_demo.is.null,is_demo.eq.false")
    .not("username", "is", null)
    .order("follower_count", { ascending: false, nullsFirst: false })
    .order("created_at", { ascending: false })
    .limit(limit + 5);

  if (me) q = q.neq("id", me);
  const { data, error } = await q;
  if (error) throw error;

  const profileRows = (data ?? []) as SuggestedPerson[];
  const merged: SuggestedPerson[] = [...ogSuggested, ...profileRows];
  const seen = new Set<string>();
  const deduped = merged.filter((p) => {
    const key = (p.username ?? p.id).toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
  const filtered = deduped.filter((p) => !followingIds.includes(p.id)).slice(0, limit);
  if (filtered.length > 0) return filtered;
  // Fallback: curated seed builders so the sidebar is never empty
  return SEED_BUILDERS.slice(0, limit);
}

const SEED_BUILDERS: SuggestedPerson[] = [
  { id: "seed-aarav",  username: "aarav",  display_name: "Aarav Mehta",   avatar_url: "https://api.dicebear.com/7.x/notionists/svg?seed=aarav&backgroundColor=3b82f6",  bio: "n8n · Lovable",           roles: ["AI Automation Builder"],  availability_status: "available", follower_count: 0 },
  { id: "seed-priya",  username: "priya",  display_name: "Priya Sharma",  avatar_url: "https://api.dicebear.com/7.x/notionists/svg?seed=priya&backgroundColor=8b5cf6",  bio: "Lovable · GPT-4",         roles: ["No-Code AI Developer"],   availability_status: "available", follower_count: 0 },
  { id: "seed-kabir",  username: "kabir",  display_name: "Kabir Singh",   avatar_url: "https://api.dicebear.com/7.x/notionists/svg?seed=kabir&backgroundColor=22c55e",  bio: "Claude · Whisper",        roles: ["HealthTech Builder"],     availability_status: null,        follower_count: 0 },
  { id: "seed-ishita", username: "ishita", display_name: "Ishita Verma",  avatar_url: "https://api.dicebear.com/7.x/notionists/svg?seed=ishita&backgroundColor=f59e0b", bio: "Supabase · Lovable",      roles: ["Full-Stack Vibe Coder"],  availability_status: "available", follower_count: 0 },
  { id: "seed-vikram", username: "vikram", display_name: "Vikram Joshi",  avatar_url: "https://api.dicebear.com/7.x/notionists/svg?seed=vikram&backgroundColor=3b82f6", bio: "Claude · n8n",            roles: ["LegalTech AI Builder"],   availability_status: null,        follower_count: 0 },
  { id: "seed-rohan",  username: "rohan",  display_name: "Rohan Iyer",    avatar_url: "https://api.dicebear.com/7.x/notionists/svg?seed=rohan&backgroundColor=8b5cf6",  bio: "Make · n8n",              roles: ["Workflow Architect"],     availability_status: "available", follower_count: 0 },
  { id: "seed-sara",   username: "sara",   display_name: "Sara Khan",     avatar_url: "https://api.dicebear.com/7.x/notionists/svg?seed=sara&backgroundColor=22c55e",   bio: "GPT-4o · Claude",         roles: ["Prompt Engineer"],        availability_status: null,        follower_count: 0 },
  { id: "seed-neha",   username: "neha",   display_name: "Neha Kapoor",   avatar_url: "https://api.dicebear.com/7.x/notionists/svg?seed=neha&backgroundColor=f59e0b",   bio: "Midjourney · GPT-4",      roles: ["AI Content Builder"],     availability_status: "available", follower_count: 0 },
  { id: "seed-arjun",  username: "arjun",  display_name: "Arjun Nair",    avatar_url: "https://api.dicebear.com/7.x/notionists/svg?seed=arjun&backgroundColor=3b82f6",  bio: "Supabase · Claude",       roles: ["RAG & Vector DB Dev"],    availability_status: null,        follower_count: 0 },
];

export async function followUser(targetId: string) {
  const { data: auth } = await supabase.auth.getUser();
  const me = auth.user?.id;
  if (!me) throw new Error("Not signed in");
  if (me === targetId) throw new Error("Cannot follow yourself");
  // Seed/curated suggestions are UI-only — accept the follow without a DB write.
  if (targetId.startsWith("seed-") || targetId.startsWith("og-")) return;
  const { error } = await (supabase as any)
    .from("follows")
    .insert({ follower_id: me, following_id: targetId });
  if (error && !String(error.message).toLowerCase().includes("duplicate")) throw error;
}

export async function unfollowUser(targetId: string) {
  const { data: auth } = await supabase.auth.getUser();
  const me = auth.user?.id;
  if (!me) throw new Error("Not signed in");
  const { error } = await (supabase as any)
    .from("follows")
    .delete()
    .eq("follower_id", me)
    .eq("following_id", targetId);
  if (error) throw error;
}
