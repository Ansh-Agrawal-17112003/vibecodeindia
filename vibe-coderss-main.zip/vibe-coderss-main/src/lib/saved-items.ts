import { useEffect, useState, useCallback } from "react";

export type SavedKind = "prompt" | "workflow" | "template" | "project";

const KEY = "vc:saved-items";
const EVT = "vc:saved-items:changed";

export type SavedEntry = { kind: SavedKind; id: string; savedAt: number };

function read(): SavedEntry[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}
function write(items: SavedEntry[]) {
  localStorage.setItem(KEY, JSON.stringify(items));
  window.dispatchEvent(new Event(EVT));
}

export function getSavedItems(): SavedEntry[] {
  return read();
}
export function isItemSaved(kind: SavedKind, id: string) {
  return read().some((e) => e.kind === kind && e.id === id);
}
export function toggleSavedItem(kind: SavedKind, id: string) {
  const cur = read();
  const exists = cur.some((e) => e.kind === kind && e.id === id);
  const next = exists
    ? cur.filter((e) => !(e.kind === kind && e.id === id))
    : [{ kind, id, savedAt: Date.now() }, ...cur];
  write(next);
  return !exists;
}

export function useSavedItems() {
  const [items, setItems] = useState<SavedEntry[]>([]);
  useEffect(() => {
    setItems(read());
    const h = () => setItems(read());
    window.addEventListener(EVT, h);
    window.addEventListener("storage", h);
    return () => {
      window.removeEventListener(EVT, h);
      window.removeEventListener("storage", h);
    };
  }, []);
  const toggle = useCallback((kind: SavedKind, id: string) => toggleSavedItem(kind, id), []);
  const isSaved = useCallback((kind: SavedKind, id: string) => items.some((e) => e.kind === kind && e.id === id), [items]);
  return { items, count: items.length, toggle, isSaved };
}
