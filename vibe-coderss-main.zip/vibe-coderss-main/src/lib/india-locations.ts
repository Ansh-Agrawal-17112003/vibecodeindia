// Comprehensive list of Indian cities, towns, and notable villages across all states & UTs.
// Format: "City, State". Use for location autocomplete.

const RAW: Record<string, string[]> = {
  "Andhra Pradesh": ["Visakhapatnam","Vijayawada","Guntur","Nellore","Kurnool","Rajahmundry","Tirupati","Kakinada","Anantapur","Kadapa","Eluru","Ongole","Chittoor","Machilipatnam","Srikakulam","Vizianagaram","Tenali","Proddatur","Bhimavaram","Hindupur","Madanapalle","Adoni","Dharmavaram","Gudivada","Narasaraopet","Tadipatri","Mangalagiri","Chilakaluripet","Yemmiganur","Kavali","Palakollu","Tadepalligudem","Amaravati","Puttaparthi","Lepakshi"],
  "Arunachal Pradesh": ["Itanagar","Naharlagun","Pasighat","Tawang","Ziro","Bomdila","Aalo","Tezu","Roing","Khonsa","Changlang","Daporijo","Seppa","Yingkiong"],
  "Assam": ["Guwahati","Dispur","Silchar","Dibrugarh","Jorhat","Nagaon","Tinsukia","Tezpur","Bongaigaon","Karimganj","Sivasagar","Goalpara","Barpeta","North Lakhimpur","Diphu","Haflong","Dhubri","Mangaldoi","Hailakandi","Majuli"],
  "Bihar": ["Patna","Gaya","Bhagalpur","Muzaffarpur","Darbhanga","Purnia","Arrah","Begusarai","Katihar","Munger","Chhapra","Bettiah","Saharsa","Hajipur","Sasaram","Dehri","Siwan","Motihari","Nawada","Bagaha","Buxar","Kishanganj","Sitamarhi","Jamui","Jehanabad","Aurangabad","Madhubani","Bodh Gaya","Nalanda","Rajgir","Vaishali"],
  "Chhattisgarh": ["Raipur","Bhilai","Bilaspur","Korba","Durg","Rajnandgaon","Jagdalpur","Raigarh","Ambikapur","Dhamtari","Mahasamund","Kanker","Kawardha","Bastar","Dantewada","Sukma"],
  "Goa": ["Panaji","Margao","Vasco da Gama","Mapusa","Ponda","Bicholim","Curchorem","Sanquelim","Calangute","Anjuna","Candolim","Arambol","Palolem","Old Goa"],
  "Gujarat": ["Ahmedabad","Surat","Vadodara","Rajkot","Bhavnagar","Jamnagar","Gandhinagar","Junagadh","Anand","Navsari","Morbi","Nadiad","Mehsana","Bharuch","Vapi","Veraval","Porbandar","Godhra","Patan","Surendranagar","Gandhidham","Valsad","Palanpur","Botad","Amreli","Dwarka","Somnath","Kutch","Bhuj","Dholavira","Statue of Unity"],
  "Haryana": ["Gurugram","Faridabad","Panipat","Ambala","Yamunanagar","Rohtak","Hisar","Karnal","Sonipat","Panchkula","Bhiwani","Sirsa","Bahadurgarh","Jind","Thanesar","Kaithal","Rewari","Palwal","Pundri","Kosli","Narnaul","Kurukshetra","Nuh"],
  "Himachal Pradesh": ["Shimla","Dharamshala","Solan","Mandi","Kullu","Manali","Hamirpur","Una","Bilaspur","Chamba","Kasauli","Palampur","Nahan","Kangra","Sundarnagar","Dalhousie","Spiti","Kinnaur","Keylong","Reckong Peo"],
  "Jharkhand": ["Ranchi","Jamshedpur","Dhanbad","Bokaro","Hazaribagh","Deoghar","Phusro","Adityapur","Giridih","Ramgarh","Medininagar","Chirkunda","Dumka","Chaibasa","Sahebganj","Gumla","Lohardaga","Pakur"],
  "Karnataka": ["Bengaluru","Mysuru","Hubli","Mangaluru","Belagavi","Kalaburagi","Davanagere","Ballari","Vijayapura","Shivamogga","Tumakuru","Raichur","Bidar","Hospet","Hassan","Gadag","Udupi","Chitradurga","Kolar","Mandya","Chikkamagaluru","Bagalkot","Karwar","Sirsi","Madikeri","Coorg","Hampi","Badami","Sringeri","Dharwad"],
  "Kerala": ["Thiruvananthapuram","Kochi","Kozhikode","Thrissur","Kollam","Alappuzha","Palakkad","Malappuram","Kannur","Kasaragod","Kottayam","Pathanamthitta","Idukki","Wayanad","Munnar","Varkala","Kumarakom","Guruvayur","Ernakulam","Aluva","Perinthalmanna","Changanassery"],
  "Madhya Pradesh": ["Bhopal","Indore","Jabalpur","Gwalior","Ujjain","Sagar","Dewas","Satna","Ratlam","Rewa","Murwara","Singrauli","Burhanpur","Khandwa","Bhind","Chhindwara","Vidisha","Sehore","Hoshangabad","Itarsi","Mandsaur","Neemuch","Datia","Shivpuri","Guna","Khargone","Khajuraho","Orchha","Maheshwar","Pachmarhi"],
  "Maharashtra": ["Mumbai","Pune","Nagpur","Nashik","Thane","Aurangabad","Solapur","Kolhapur","Amravati","Navi Mumbai","Kalyan","Vasai-Virar","Sangli","Jalgaon","Akola","Latur","Dhule","Ahmednagar","Chandrapur","Parbhani","Ichalkaranji","Jalna","Bhiwandi","Nanded","Malegaon","Wardha","Ratnagiri","Satara","Beed","Yavatmal","Osmanabad","Lonavala","Mahabaleshwar","Alibaug","Shirdi","Panvel","Pimpri-Chinchwad","Mira-Bhayandar"],
  "Manipur": ["Imphal","Thoubal","Bishnupur","Churachandpur","Senapati","Ukhrul","Tamenglong","Jiribam","Moreh","Kakching"],
  "Meghalaya": ["Shillong","Tura","Jowai","Nongstoin","Williamnagar","Baghmara","Cherrapunji","Mawsynram","Dawki","Nongpoh"],
  "Mizoram": ["Aizawl","Lunglei","Champhai","Serchhip","Kolasib","Saiha","Mamit","Lawngtlai"],
  "Nagaland": ["Kohima","Dimapur","Mokokchung","Tuensang","Wokha","Mon","Zunheboto","Phek","Kiphire","Longleng"],
  "Odisha": ["Bhubaneswar","Cuttack","Rourkela","Berhampur","Sambalpur","Puri","Balasore","Bhadrak","Baripada","Jharsuguda","Jeypore","Angul","Dhenkanal","Kendrapara","Rayagada","Paradip","Konark","Koraput","Sundargarh"],
  "Punjab": ["Ludhiana","Amritsar","Jalandhar","Patiala","Bathinda","Mohali","Pathankot","Hoshiarpur","Batala","Moga","Abohar","Malerkotla","Khanna","Phagwara","Muktsar","Barnala","Rajpura","Firozpur","Kapurthala","Sangrur","Sirhind","Anandpur Sahib"],
  "Rajasthan": ["Jaipur","Jodhpur","Udaipur","Kota","Bikaner","Ajmer","Bhilwara","Alwar","Sikar","Pali","Sri Ganganagar","Tonk","Hanumangarh","Beawar","Kishangarh","Churu","Bharatpur","Dholpur","Banswara","Sawai Madhopur","Pushkar","Mount Abu","Jaisalmer","Chittorgarh","Nathdwara","Ranthambore","Nagaur","Barmer","Jhunjhunu"],
  "Sikkim": ["Gangtok","Namchi","Gyalshing","Mangan","Pelling","Ravangla","Lachung","Lachen","Yuksom","Rangpo","Jorethang"],
  "Tamil Nadu": ["Chennai","Coimbatore","Madurai","Tiruchirappalli","Salem","Tirunelveli","Tiruppur","Erode","Vellore","Thoothukudi","Dindigul","Thanjavur","Ranipet","Sivakasi","Karur","Udhagamandalam","Hosur","Nagercoil","Kanchipuram","Kumbakonam","Karaikkudi","Neyveli","Cuddalore","Kumarapalayam","Tiruvannamalai","Pollachi","Rajapalayam","Gudiyatham","Pudukkottai","Vaniyambadi","Ambur","Ramanathapuram","Mahabalipuram","Kodaikanal","Ooty","Yercaud","Rameshwaram"],
  "Telangana": ["Hyderabad","Warangal","Nizamabad","Karimnagar","Khammam","Ramagundam","Mahbubnagar","Nalgonda","Adilabad","Suryapet","Miryalaguda","Jagtial","Mancherial","Siddipet","Wanaparthy","Kothagudem","Bodhan","Sangareddy","Medak","Secunderabad"],
  "Tripura": ["Agartala","Udaipur","Dharmanagar","Kailasahar","Belonia","Khowai","Ambassa","Sabroom","Sonamura","Amarpur"],
  "Uttar Pradesh": ["Lucknow","Kanpur","Ghaziabad","Agra","Varanasi","Meerut","Prayagraj","Bareilly","Aligarh","Moradabad","Saharanpur","Gorakhpur","Noida","Firozabad","Jhansi","Muzaffarnagar","Mathura","Rampur","Shahjahanpur","Faizabad","Ayodhya","Sitapur","Bahraich","Modinagar","Unnao","Jaunpur","Lakhimpur","Hathras","Banda","Pilibhit","Mirzapur","Bulandshahr","Etawah","Sambhal","Amroha","Hardoi","Fatehpur","Raebareli","Orai","Sitarganj","Sultanpur","Etah","Ghazipur","Deoria","Mainpuri","Lalitpur","Greater Noida","Vrindavan","Sarnath","Kushinagar"],
  "Uttarakhand": ["Dehradun","Haridwar","Roorkee","Haldwani","Rudrapur","Kashipur","Rishikesh","Pithoragarh","Ramnagar","Mussoorie","Nainital","Almora","Pauri","Tehri","Kotdwar","Srinagar","Champawat","Bageshwar","Joshimath","Badrinath","Kedarnath","Auli","Chamoli","Uttarkashi"],
  "West Bengal": ["Kolkata","Howrah","Durgapur","Asansol","Siliguri","Bardhaman","Malda","Baharampur","Habra","Kharagpur","Shantipur","Dankuni","Dhulian","Ranaghat","Haldia","Krishnanagar","Nabadwip","Medinipur","Jalpaiguri","Balurghat","Basirhat","Bankura","Chakdaha","Darjeeling","Kalimpong","Kurseong","Digha","Mandarmani","Bolpur","Shantiniketan","Cooch Behar","Alipurduar"],
  "Delhi": ["New Delhi","Delhi","Dwarka","Rohini","Saket","Karol Bagh","Connaught Place","Hauz Khas","Vasant Kunj","Janakpuri","Lajpat Nagar","Pitampura","Mayur Vihar","Najafgarh","Narela"],
  "Jammu & Kashmir": ["Srinagar","Jammu","Anantnag","Baramulla","Kathua","Udhampur","Sopore","Kupwara","Pulwama","Budgam","Gulmarg","Pahalgam","Sonmarg","Doda","Rajouri","Poonch","Kishtwar"],
  "Ladakh": ["Leh","Kargil","Nubra","Diskit","Drass","Zanskar","Padum","Hanle"],
  "Chandigarh": ["Chandigarh"],
  "Puducherry": ["Puducherry","Karaikal","Yanam","Mahe","Auroville"],
  "Andaman & Nicobar": ["Port Blair","Havelock","Diglipur","Mayabunder","Car Nicobar","Neil Island"],
  "Dadra & Nagar Haveli and Daman & Diu": ["Daman","Diu","Silvassa"],
  "Lakshadweep": ["Kavaratti","Agatti","Minicoy","Andrott","Amini"],
};

export const INDIA_LOCATIONS: string[] = Object.entries(RAW).flatMap(([state, cities]) =>
  cities.map((c) => `${c}, ${state}`)
);

// Quick remote/global tags people commonly search
export const EXTRA_LOCATIONS = ["Remote", "Remote, India", "Hybrid", "Anywhere"];

export const ALL_LOCATIONS = [...EXTRA_LOCATIONS, ...INDIA_LOCATIONS];

export function searchLocations(q: string, limit = 8): string[] {
  const term = q.trim().toLowerCase();
  if (!term) return ALL_LOCATIONS.slice(0, limit);
  const starts: string[] = [];
  const contains: string[] = [];
  for (const loc of ALL_LOCATIONS) {
    const l = loc.toLowerCase();
    if (l.startsWith(term)) starts.push(loc);
    else if (l.includes(term)) contains.push(loc);
    if (starts.length >= limit) break;
  }
  return [...starts, ...contains].slice(0, limit);
}
