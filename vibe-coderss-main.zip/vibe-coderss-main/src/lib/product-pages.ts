import type { LucideIcon } from "lucide-react";
import vibeFeedHeroVideo from "@/assets/vibe-feed-hero.mp4.asset.json";
import vibeFeedFeature1 from "@/assets/vibe-feed-feature-1.mp4.asset.json";
import vibeFeedFeature2 from "@/assets/vibe-feed-feature-2.mp4.asset.json";
import vibeFeedFeature3 from "@/assets/vibe-feed-feature-3.mp4.asset.json";
import builderProfilesHero from "@/assets/builder-profiles-hero.mp4.asset.json";
import communitiesHero from "@/assets/communities-hero.mp4.asset.json";
import jobsBoardHero from "@/assets/jobs-board-hero.mp4.asset.json";
import promptLibraryHero from "@/assets/prompt-library-hero.mp4.asset.json";
import workflowTemplatesHero from "@/assets/workflow-templates-hero.mp4.asset.json";
import promptLibraryFeature1 from "@/assets/prompt-library-feature-1.mp4.asset.json";
import promptLibraryFeature2 from "@/assets/prompt-library-feature-2.mp4.asset.json";
import promptLibraryFeature3 from "@/assets/prompt-library-feature-3.mp4.asset.json";
import {
  Sparkles, Heart, Zap,
  UserCircle2, Award, Flame,
  Users, MessageCircle, GraduationCap, Video,
  Briefcase, MapPin, IndianRupee, Filter,
  BookOpen, Copy, Wand2,
  Wrench, ThumbsUp, Shield,
  Workflow, GitBranch, Bot, Rocket,
  Eye, Trophy,
  Palette, Code2, Building2, Store, Megaphone, Camera,
} from "lucide-react";

export type ProductFeatureRow = {
  icon: LucideIcon;
  eyebrow: string;
  title: string;
  body: string;
  bullets: string[];
  image?: string;
  video?: string;
  imageAlt: string;
  imageLabel: string;
};

export type ProductUseCase = { icon: LucideIcon; persona: string; line: string };
export type ProductTemplate = { title: string; tag: string; image?: string; alt: string };
export type ProductFAQ = { q: string; a: string };

export type ProductPageConfig = {
  slug: string;
  eyebrow: string;
  title: string;
  subtitle: string;
  heroBadges: string[];
  heroShot: { src?: string; video?: string; alt: string; label: string };
  featureRows: [ProductFeatureRow, ProductFeatureRow, ProductFeatureRow];
  useCases: ProductUseCase[];
  templates: ProductTemplate[];
  integrations: string[];
  faqs: ProductFAQ[];
  quote: { text: string; who: string; role: string };
  meta: { title: string; description: string };
};

const shot = (slug: string, name: string) => `/product-shots/${slug}/${name}.png`;

function build(
  slug: string,
  data: Omit<ProductPageConfig, "slug" | "heroShot" | "featureRows" | "templates"> & {
    heroAlt: string;
    heroLabel: string;
    featureRows: Array<Omit<ProductFeatureRow, "image" | "imageAlt" | "imageLabel"> & { imageAlt: string; imageLabel: string; imageKey: string }>;
    templates: Array<Omit<ProductTemplate, "image" | "alt"> & { alt: string; imageKey: string }>;
  },
): ProductPageConfig {
  return {
    slug,
    eyebrow: data.eyebrow,
    title: data.title,
    subtitle: data.subtitle,
    heroBadges: data.heroBadges,
    heroShot: { src: shot(slug, "hero"), alt: data.heroAlt, label: data.heroLabel },
    featureRows: data.featureRows.map((f) => ({
      ...f,
      image: shot(slug, f.imageKey),
      imageAlt: f.imageAlt,
      imageLabel: f.imageLabel,
    })) as unknown as ProductPageConfig["featureRows"],
    useCases: data.useCases,
    templates: data.templates.map((t) => ({ title: t.title, tag: t.tag, alt: t.alt, image: shot(slug, t.imageKey) })),
    integrations: data.integrations,
    faqs: data.faqs,
    quote: data.quote,
    meta: data.meta,
  };
}

export const PRODUCT_PAGES: Record<string, ProductPageConfig> = {
  "vibe-feed": (() => { const c = build("vibe-feed", {
    eyebrow: "Product · Vibe Feed",
    title: "The social feed built for AI builders in India",
    subtitle: "Ship logs, prompts, wins and rants — a home feed tuned for people who actually build with AI.",
    heroBadges: ["Realtime", "Zero-noise", "Made in India"],
    heroAlt: "Vibe Feed home page with posts and right rail",
    heroLabel: "Full Vibe feed: 3 posts + right rail with streaks",
    featureRows: [
      { icon: Sparkles, eyebrow: "Composer", title: "Post in seconds — text, images, the whole build log", body: "Drop a screenshot, paste your prompt, drag in a demo clip. The composer keeps up with how you actually ship.", bullets: ["Rich text + image attachments", "Paste screenshots straight in", "Drafts autosave as you type"], imageKey: "feature-1", imageAlt: "Post composer with attached image", imageLabel: "Composer with an image attached and post body" },
      { icon: Heart, eyebrow: "Feed", title: "A scrolling feed that actually reacts", body: "Real reactions, real comments, real threads. Not a graveyard of likes — a room that talks back.", bullets: ["Threaded comments under every post", "Reactions beyond a plain like", "Live as new replies land"], imageKey: "feature-2", imageAlt: "Feed with posts, reactions and comments", imageLabel: "Scrolling feed — posts with reactions + comments" },
      { icon: Zap, eyebrow: "People", title: "Never a lonely feed — people to follow on day one", body: "The moment you sign up, we surface builders worth following so your feed is alive from post zero.", bullets: ["Curated 'who to follow' picks", "Grouped by stack and interest", "One-tap follow, no empty state"], imageKey: "feature-3", imageAlt: "Who to follow suggestions", imageLabel: "People to follow — suggestions so the feed feels alive" },

    ],
    useCases: [
      { icon: Code2, persona: "Indie devs", line: "Ship in public, get feedback fast." },
      { icon: Palette, persona: "AI designers", line: "Share prompts and win commissions." },
      { icon: Rocket, persona: "Founders", line: "Launch to a room that actually replies." },
      { icon: Megaphone, persona: "Creators", line: "Build an audience that ships with you." },
    ],
    templates: [
      { title: "Ship a win", tag: "Post", imageKey: "tpl-1", alt: "Win post template" },
      { title: "Ask the room", tag: "Question", imageKey: "tpl-2", alt: "Question post template" },
      { title: "Launch a project", tag: "Launch", imageKey: "tpl-3", alt: "Launch post template" },
      { title: "Share a prompt", tag: "Tutorial", imageKey: "tpl-4", alt: "Tutorial post template" },
    ],
    integrations: ["GitHub", "Vercel", "Supabase", "n8n", "Cursor", "Anthropic", "Discord", "ClickUp"],
    faqs: [
      { q: "Is Vibe Feed free?", a: "Yes — posting, reacting, and following are free forever. Some pro tools sit behind the paid tier." },
      { q: "Who can see my posts?", a: "Everyone on VibeCode by default. You can mark posts as community-only or draft." },
      { q: "How is this different from Twitter?", a: "It's ranked by what you ship, not by who follows you. And the crowd is 100% AI builders in India." },
      { q: "Can I cross-post from Twitter?", a: "Yes — paste a tweet URL and we pull the media and text in one click." },
    ],
    quote: { text: "I got two interview calls the week I started posting.", who: "Aarav K.", role: "Indie AI dev, Bengaluru" },
    meta: {
      title: "Vibe Feed — the social feed for AI builders | VibeCode",
      description: "A home feed for India's AI builders. Ship, react, remix. Sign up to join.",
    },
  }); c.heroShot = { ...c.heroShot, video: vibeFeedHeroVideo.url };
    c.featureRows[0].video = vibeFeedFeature1.url;
    c.featureRows[1].video = vibeFeedFeature2.url;
    c.featureRows[2].video = vibeFeedFeature3.url;
    return c; })(),

  "builder-profiles": (() => { const c = build("builder-profiles", {
    eyebrow: "Product · Builder Profiles",
    title: "Your portfolio, XP, streaks & badges — in one link",
    subtitle: "A profile that shows what you've shipped, not just what you claim. Hirers actually read these.",
    heroBadges: ["XP", "Streaks", "Badges", "Portfolio"],
    heroAlt: "Builder profile page with XP, streak, and projects",
    heroLabel: "Full profile page: XP bar, streak, badges, project grid",
    featureRows: [
      { icon: UserCircle2, eyebrow: "Portfolio-first", title: "Projects pinned, receipts visible", body: "Your best projects, prompts, and posts pinned to the top. Recruiters don't scroll for proof.", bullets: ["Pin any 6 projects", "Prompt library on your page", "Post highlights auto-surface"], imageKey: "feature-1", imageAlt: "Badges tab with tooltip", imageLabel: "Badges tab with hover tooltip" },
      { icon: Flame, eyebrow: "Streaks", title: "Streaks reward showing up", body: "Ship daily and your streak climbs. Break it and it resets — no mercy, no fake gamification.", bullets: ["Daily ship counter", "Weekly review email", "Streak badges at 7/30/100/365"], imageKey: "feature-2", imageAlt: "XP history chart", imageLabel: "XP history chart with weekly bars" },
      { icon: Award, eyebrow: "Badges", title: "Badges for real craft", body: "Earn OG, Top Prompt, First Ship, Cohort Grad and more — only for verified actions.", bullets: ["30+ badges, more each month", "Rare badges you can't buy", "Shows on your public profile"], imageKey: "feature-3", imageAlt: "Public profile share view", imageLabel: "Public shareable profile view" },
    ],
    useCases: [
      { icon: Code2, persona: "Engineers", line: "One link replaces the resume." },
      { icon: Palette, persona: "Designers", line: "Show the process, not just the pixels." },
      { icon: Rocket, persona: "Founders", line: "Prove traction before you pitch." },
      { icon: GraduationCap, persona: "Students", line: "Get hired on shipped work, not GPA." },
    ],
    templates: [
      { title: "Founder profile", tag: "Founder", imageKey: "tpl-1", alt: "Founder profile example" },
      { title: "Designer profile", tag: "Design", imageKey: "tpl-2", alt: "Designer profile example" },
      { title: "AI dev profile", tag: "Dev", imageKey: "tpl-3", alt: "AI dev profile example" },
      { title: "Creator profile", tag: "Creator", imageKey: "tpl-4", alt: "Creator profile example" },
    ],
    integrations: ["GitHub", "Behance", "Dribbble", "LinkedIn", "Twitter/X", "Product Hunt", "Notion", "Figma", "YouTube", "Substack", "Vercel", "Lovable"],
    faqs: [
      { q: "Do I need to be technical?", a: "No. Designers, PMs, founders, and creators all have profiles here." },
      { q: "Is my profile public?", a: "Yes — anyone can view it at vibecode.xyz/u/yourhandle. You choose what to pin." },
      { q: "Can I hide my XP?", a: "Yes. Streaks and XP are on by default but you can hide either from your settings." },
      { q: "How do I get badges?", a: "Ship things. Every badge unlocks from a verified action — no self-award." },
    ],
    quote: { text: "My profile page did more for me than my resume ever did.", who: "Meera S.", role: "ML engineer, Pune" },
    meta: {
      title: "Builder Profiles — your portfolio + XP | VibeCode",
      description: "Portfolio, XP, streaks & badges in one shareable link. Sign up to claim yours.",
    },
  }); c.heroShot = { ...c.heroShot, video: builderProfilesHero.url }; return c; })(),

  "communities": (() => { const c = build("communities", {
    eyebrow: "Product · Communities",
    title: "Real classrooms, chat & cohorts that ship",
    subtitle: "Not another dead Discord. Live cohorts, uploaded lectures, and chat that stays on topic.",
    heroBadges: ["Live cohorts", "Lecture library", "Realtime chat"],
    heroAlt: "Community landing page with cover and members",
    heroLabel: "Community page: cover, member count, join CTA",
    featureRows: [
      { icon: GraduationCap, eyebrow: "Classrooms", title: "Live cohorts that graduate together", body: "12-week sprints with a clear ship-by date. Not another course you abandon week 3.", bullets: ["Weekly live sessions", "Public homework threads", "Graduation demo day"], imageKey: "feature-1", imageAlt: "Realtime chat panel", imageLabel: "Realtime community chat panel" },
      { icon: Video, eyebrow: "On-demand", title: "Lecture on-demand, same day", body: "Miss a session? The replay is up within hours with chapters and searchable transcript.", bullets: ["Auto-chaptered recordings", "Searchable transcripts", "Speed up to 2×"], imageKey: "feature-2", imageAlt: "Classroom lecture player", imageLabel: "Classroom / lecture player" },
      { icon: MessageCircle, eyebrow: "Chat", title: "Chat that actually ships", body: "Threads, wins channel, and prompt swaps — no meme-only channels choking the signal.", bullets: ["Threaded replies", "Pinned wins & resources", "No meme-only rooms"], imageKey: "feature-3", imageAlt: "Community feed tab", imageLabel: "Community feed tab with pinned wins" },
    ],
    useCases: [
      { icon: Code2, persona: "Learning a stack", line: "Ship 4 projects in the LangChain cohort." },
      { icon: Building2, persona: "City meetups", line: "Bangalore, Delhi, Mumbai — meet the local crew." },
      { icon: Rocket, persona: "Launching solo", line: "Cohorts that ship together, not talk together." },
      { icon: Users, persona: "Team upskilling", line: "Bring your team, get a private classroom." },
    ],
    templates: [
      { title: "LangChain India", tag: "Cohort", imageKey: "tpl-1", alt: "LangChain community" },
      { title: "n8n Automators", tag: "Tools", imageKey: "tpl-2", alt: "n8n community" },
      { title: "Prompt Pros", tag: "Craft", imageKey: "tpl-3", alt: "Prompt community" },
      { title: "Bangalore Builders", tag: "City", imageKey: "tpl-4", alt: "Bangalore community" },
    ],
    integrations: ["Zoom", "Google Meet", "YouTube", "Notion", "Discord", "Slack", "Loom", "Calendly", "Stripe", "Razorpay", "GitHub", "Figma"],
    faqs: [
      { q: "Are communities free to join?", a: "Most are free. Paid cohorts show pricing on the join card." },
      { q: "Can I start my own community?", a: "Yes — apply to be a host. We review for signal and give approved hosts full tooling." },
      { q: "Do I get a certificate?", a: "Cohort grads get a verified badge on their profile — better than a PDF." },
      { q: "What if I miss the live session?", a: "Every session is recorded, chaptered, and searchable within hours." },
    ],
    quote: { text: "First cohort I actually finished. Because the crew shipped with me.", who: "Rohan T.", role: "Founder, Hyderabad" },
    meta: {
      title: "Communities — real classrooms for builders | VibeCode",
      description: "Live cohorts, lecture library and chat that ships. Sign up to join a community.",
    },
  }); c.heroShot = { ...c.heroShot, video: communitiesHero.url }; return c; })(),

  "jobs-board": (() => { const c = build("jobs-board", {
    eyebrow: "Product · Jobs Board",
    title: "AI & vibe-coding roles, curated for India",
    subtitle: "No spam listings. Every role is hand-vetted, salary-transparent, and reachable — with your profile as your application.",
    heroBadges: ["Curated", "Salary shown", "Apply with profile"],
    heroAlt: "Jobs listing with filter sidebar",
    heroLabel: "Jobs board: filter sidebar + listing grid",
    featureRows: [
      { icon: Filter, eyebrow: "Curated", title: "Hand-vetted roles, no ghosts", body: "We drop listings that don't respond. Every role on the board is live and reachable.", bullets: ["Verified employer contact", "Removed if unresponsive 14 days", "No repost spam"], imageKey: "feature-1", imageAlt: "Job detail with apply CTA", imageLabel: "Single job detail page with apply CTA" },
      { icon: IndianRupee, eyebrow: "Transparent", title: "Salary in the open", body: "Every listing shows range in INR (or USD for remote). No 'competitive'. No games.", bullets: ["INR range required", "Equity clearly shown", "Sort by pay"], imageKey: "feature-2", imageAlt: "Saved jobs view", imageLabel: "Saved jobs view with filter chips" },
      { icon: MapPin, eyebrow: "India-first", title: "Filters that match how you search", body: "Remote, hybrid, or by city — filtered how Indian devs actually job-hunt.", bullets: ["City + tier filter", "Remote-only toggle", "Visa-sponsor filter for outbound"], imageKey: "feature-3", imageAlt: "Filter sidebar zoomed", imageLabel: "Filter sidebar zoomed — role, salary, remote" },
    ],
    useCases: [
      { icon: Code2, persona: "AI engineers", line: "LLM, RAG, fine-tune roles." },
      { icon: Wand2, persona: "Prompt engineers", line: "Full-time prompt & eval work." },
      { icon: Rocket, persona: "Founding roles", line: "Early-stage AI startup gigs." },
      { icon: Palette, persona: "AI designers", line: "Product design for AI-native tools." },
    ],
    templates: [
      { title: "AI Engineer", tag: "Eng", imageKey: "tpl-1", alt: "AI engineer job card" },
      { title: "Prompt Engineer", tag: "Craft", imageKey: "tpl-2", alt: "Prompt engineer job card" },
      { title: "Founding Engineer", tag: "Startup", imageKey: "tpl-3", alt: "Founding engineer job card" },
      { title: "AI Product Designer", tag: "Design", imageKey: "tpl-4", alt: "AI product designer job card" },
    ],
    integrations: ["LinkedIn", "GitHub", "Notion", "Greenhouse", "Lever", "Ashby", "Wellfound", "Slack", "Gmail", "Calendly", "Loom", "Zoom"],
    faqs: [
      { q: "Is applying free?", a: "Yes. Your profile is your application — no application fees, ever." },
      { q: "How do I post a role?", a: "Companies can post from the Employers dashboard. All listings are reviewed for signal." },
      { q: "Are salaries mandatory?", a: "Yes. No listing goes live without a range in INR or USD." },
      { q: "Do you handle interviews?", a: "No — you talk directly to the hiring team. We just clear the noise before the intro." },
    ],
    quote: { text: "The only board where I actually heard back from every role.", who: "Ishaan P.", role: "AI engineer, Remote" },
    meta: {
      title: "Jobs Board — curated AI roles in India | VibeCode",
      description: "Hand-vetted AI and vibe-coding jobs with transparent salaries. Sign up to apply.",
    },
  }); c.heroShot = { ...c.heroShot, video: jobsBoardHero.url }; return c; })(),


  "prompt-library": (() => { const c = build("prompt-library", {
    eyebrow: "Product · Prompt Library",
    title: "Curated prompts that actually ship",
    subtitle: "A library of prompts battle-tested by real builders — copy, remix, and version them into your workflow.",
    heroBadges: ["Battle-tested", "Remixable", "Versioned"],
    heroAlt: "Prompt library grid with category chips",
    heroLabel: "Prompt library: grid + category chips",
    featureRows: [
      { icon: BookOpen, eyebrow: "Curated", title: "Collections sorted by task", body: "Agents, code, copy, research, RAG — find prompts by the job, not the model.", bullets: ["30+ curated collections", "Filter by model & task", "Weekly editor picks"], imageKey: "feature-1", imageAlt: "Prompt detail with copy button", imageLabel: "Single prompt detail with copy button" },
      { icon: Copy, eyebrow: "Copy fast", title: "One-click copy or fork", body: "Copy the whole prompt with variables filled, or fork it to your workspace to remix.", bullets: ["Variables highlighted", "Fork to your workspace", "Version history"], imageKey: "feature-2", imageAlt: "Filter by model and category", imageLabel: "Filter by model / category" },
      { icon: Wand2, eyebrow: "Community", title: "Vetted by builders, not bots", body: "Upvotes, remixes, and ship-count surface what actually works in production.", bullets: ["Ship-count on every prompt", "Public remix tree", "Report broken prompts"], imageKey: "feature-3", imageAlt: "Saved prompts collection", imageLabel: "Saved prompts collection" },
    ],
    useCases: [
      { icon: Bot, persona: "Agent builders", line: "Ready-to-run tool-use prompts." },
      { icon: Code2, persona: "Devs", line: "Code review, refactor, test-gen." },
      { icon: Megaphone, persona: "Marketers", line: "Ad copy, landing copy, cold email." },
      { icon: Camera, persona: "Creators", line: "Midjourney, Runway, Suno prompts." },
    ],
    templates: [
      { title: "RAG chunker", tag: "Agent", imageKey: "tpl-1", alt: "RAG chunker prompt" },
      { title: "Code reviewer", tag: "Dev", imageKey: "tpl-2", alt: "Code reviewer prompt" },
      { title: "Cold email", tag: "Copy", imageKey: "tpl-3", alt: "Cold email prompt" },
      { title: "Cinematic MJ", tag: "Image", imageKey: "tpl-4", alt: "Midjourney cinematic prompt" },
    ],
    integrations: ["OpenAI", "Anthropic", "Groq", "Gemini", "Mistral", "Perplexity", "Midjourney", "Runway", "Cursor", "Lovable", "n8n", "LangChain"],
    faqs: [
      { q: "Can I submit my prompts?", a: "Yes — publish any prompt in one click and earn XP when others fork it." },
      { q: "Do prompts include variables?", a: "Yes. Variables show as filled placeholders you can override before copying." },
      { q: "Are the prompts free?", a: "Most are free. Some pro collections sit behind the paid tier — always marked." },
      { q: "Can I sell my prompts?", a: "Paid prompts are coming — join the waitlist from your profile." },
    ],
    quote: { text: "Saved me a week of prompt tuning on my first agent.", who: "Diya M.", role: "AI PM, Mumbai" },
    meta: {
      title: "Prompt Library — prompts that ship | VibeCode",
      description: "Battle-tested prompts curated by builders. Copy, remix, version. Sign up to access.",
    },
  }); c.heroShot = { ...c.heroShot, video: promptLibraryHero.url }; c.featureRows[0].video = promptLibraryFeature1.url; c.featureRows[1].video = promptLibraryFeature2.url; c.featureRows[2].video = promptLibraryFeature3.url; return c; })(),

  "ai-tools": build("ai-tools", {
    eyebrow: "Product · AI Tools Directory",
    title: "Vetted tools with real builder reviews",
    subtitle: "Not a list of every model on Product Hunt. A tight directory of tools builders actually use — with honest reviews.",
    heroBadges: ["Vetted", "Honest reviews", "Real pricing"],
    heroAlt: "AI tools directory grid with ratings",
    heroLabel: "Tools directory: grid with star ratings",
    featureRows: [
      { icon: Wrench, eyebrow: "Curated", title: "Only tools people actually use", body: "We drop tools nobody uses. You see the shortlist — sorted by real adoption, not launch hype.", bullets: ["Removed if unused 90 days", "Editor's pick weekly", "Comparison shortlists"], imageKey: "feature-1", imageAlt: "Single tool page with reviews", imageLabel: "Single tool page with review + rating breakdown" },
      { icon: ThumbsUp, eyebrow: "Reviews", title: "Reviews from real users", body: "No affiliate fluff. Reviewers are verified builders whose ship history is public.", bullets: ["Verified reviewer badge", "Pros + cons + gotchas", "Downvote spam reviews"], imageKey: "feature-2", imageAlt: "Comparison and filter view", imageLabel: "Comparison / filter view" },
      { icon: Shield, eyebrow: "Pricing", title: "Pricing you can actually trust", body: "Free tier honesty, seat pricing, hidden gotchas — all listed up front. No 'contact sales' games.", bullets: ["Free tier limits shown", "Overage costs listed", "Startup discount flags"], imageKey: "feature-3", imageAlt: "Submit a tool form", imageLabel: "Submit-a-tool form" },
    ],
    useCases: [
      { icon: Rocket, persona: "Founders", line: "Pick your MVP stack in an hour." },
      { icon: Code2, persona: "Engineers", line: "Compare embeddings, IDEs, hosting." },
      { icon: Palette, persona: "Designers", line: "Find the best gen-image tool for your brief." },
      { icon: Building2, persona: "Ops", line: "Pick the right automation stack." },
    ],
    templates: [
      { title: "Cursor", tag: "IDE", imageKey: "tpl-1", alt: "Cursor tool card" },
      { title: "Perplexity", tag: "Search", imageKey: "tpl-2", alt: "Perplexity tool card" },
      { title: "Lovable", tag: "Build", imageKey: "tpl-3", alt: "Lovable tool card" },
      { title: "Runway", tag: "Video", imageKey: "tpl-4", alt: "Runway tool card" },
    ],
    integrations: ["OpenAI", "Anthropic", "Cursor", "Lovable", "Perplexity", "Runway", "Midjourney", "Vercel", "Supabase", "Pinecone", "LangChain", "n8n"],
    faqs: [
      { q: "How do you vet tools?", a: "A tool needs 10+ verified builder reviews and active use to stay listed." },
      { q: "Can I submit a tool?", a: "Yes — from any tool page, hit Submit. New tools go into review within 7 days." },
      { q: "Are you paid to list tools?", a: "No listing fees. Sponsored placements are labelled clearly." },
      { q: "How often is it updated?", a: "New reviews every day. Dead tools get pruned weekly." },
    ],
    quote: { text: "Finally a directory that isn't 90% dead links.", who: "Karan V.", role: "Solo founder, Delhi" },
    meta: {
      title: "AI Tools Directory — vetted tools with real reviews | VibeCode",
      description: "A curated directory of AI tools with honest reviews from real builders. Sign up to explore.",
    },
  }),

  "workflow-templates": (() => { const c = build("workflow-templates", {
    eyebrow: "Product · Workflow Templates",
    title: "n8n & automation blueprints, ready to fork",
    subtitle: "Ship-ready workflows for scraping, summarizing, agents, and more — fork the JSON, wire your keys, go.",
    heroBadges: ["n8n", "Zapier", "Make", "Copy-paste JSON"],
    heroAlt: "Workflow template gallery with node graphs",
    heroLabel: "Workflow gallery: n8n-style thumbnails",
    featureRows: [
      { icon: Workflow, eyebrow: "Fork fast", title: "One-click JSON fork", body: "Grab the JSON, import into n8n, wire your API keys — done in under a minute.", bullets: ["Copy-paste n8n JSON", "Zapier + Make variants", "Env vars templated"], imageKey: "feature-1", imageAlt: "Single workflow detail with node graph", imageLabel: "Workflow detail with node graph preview" },
      { icon: GitBranch, eyebrow: "Maintained", title: "Versioned when APIs change", body: "OpenAI ships a new endpoint? We push a new version. You see the changelog on the template.", bullets: ["Semver on every template", "Changelog per version", "Deprecation warnings"], imageKey: "feature-2", imageAlt: "Fork workflow flow", imageLabel: "Fork-this-workflow flow" },
      { icon: Bot, eyebrow: "Agent-ready", title: "Preconfigured for every model", body: "Templates ship configured for OpenAI, Anthropic, Groq, Ollama, and local — swap in one node.", bullets: ["Model-agnostic nodes", "Local-first variants", "Cost estimator per run"], imageKey: "feature-3", imageAlt: "Category filter", imageLabel: "Workflow category filter" },
    ],
    useCases: [
      { icon: Building2, persona: "Ops teams", line: "Automate the boring stuff, fast." },
      { icon: Rocket, persona: "Founders", line: "Ship agents without a backend team." },
      { icon: Megaphone, persona: "Growth", line: "Scrape, enrich, and outreach on autopilot." },
      { icon: Code2, persona: "Devs", line: "Fork proven pipelines instead of writing them." },
    ],
    templates: [
      { title: "RAG over Notion", tag: "Agent", imageKey: "tpl-1", alt: "RAG Notion workflow" },
      { title: "Lead scraper", tag: "Growth", imageKey: "tpl-2", alt: "Lead scraper workflow" },
      { title: "Daily digest", tag: "Ops", imageKey: "tpl-3", alt: "Daily digest workflow" },
      { title: "AI form triage", tag: "Support", imageKey: "tpl-4", alt: "Form triage workflow" },
    ],
    integrations: ["n8n", "Zapier", "Make", "OpenAI", "Anthropic", "Groq", "Supabase", "Airtable", "Notion", "Slack", "Gmail", "Sheets"],
    faqs: [
      { q: "Do I need n8n installed?", a: "For n8n templates, yes — self-hosted or cloud both work. Zapier/Make variants run in-app." },
      { q: "Are templates free?", a: "Most are free. Pro templates (with support) sit behind the paid tier." },
      { q: "Can I publish my workflow?", a: "Yes — publish and get XP + credit every time someone forks it." },
      { q: "Do you store my API keys?", a: "Never. Keys live in your n8n / Zapier / Make workspace only." },
    ],
    quote: { text: "Cut my automation build time from days to a coffee.", who: "Neha R.", role: "Ops engineer, Chennai" },
    meta: {
      title: "Workflow Templates — n8n blueprints | VibeCode",
      description: "Ship-ready n8n and automation blueprints, ready to fork. Sign up to grab the templates.",
    },
  }); c.heroShot = { ...c.heroShot, video: workflowTemplatesHero.url }; return c; })(),


  "project-showcase": build("project-showcase", {
    eyebrow: "Product · Project Showcase",
    title: "Ship, get discovered, get hired",
    subtitle: "Project pages built for builders — screenshots, stack, prompts used, and a direct line from viewer to your DMs.",
    heroBadges: ["Portfolio pages", "Stack visible", "DM-ready"],
    heroAlt: "Project showcase masonry grid",
    heroLabel: "Project masonry: covers + upvote counts",
    featureRows: [
      { icon: Rocket, eyebrow: "Project pages", title: "Beautiful project pages, no setup", body: "Cover, stack, screenshots, launch link, prompts used — a page that looks like you hired a designer.", bullets: ["Auto-generated OG image", "Stack chips with tool logos", "Prompt gallery per project"], imageKey: "feature-1", imageAlt: "Single project page", imageLabel: "Single project page with builder + stack + upvotes" },
      { icon: Eye, eyebrow: "Discovery", title: "Land on the Showcase daily", body: "New projects surface on Trending, and Editor's Picks pin the best of the week.", bullets: ["Trending page", "Editor's picks weekly", "Category leaderboards"], imageKey: "feature-2", imageAlt: "Submit project form", imageLabel: "Submit-project form" },
      { icon: Trophy, eyebrow: "Compounds", title: "Every ship stacks XP & badges", body: "Ship counts on your profile. Wins compound — recruiters see the trajectory, not a snapshot.", bullets: ["XP per project", "Badges at 3/10/25 ships", "Public launch history"], imageKey: "feature-3", imageAlt: "Trending / new / top tabs", imageLabel: "Trending / new / top tabs" },
    ],
    useCases: [
      { icon: Rocket, persona: "Indie founders", line: "Launch weekly, get feedback fast." },
      { icon: Store, persona: "Freelancers", line: "One link, hirable-looking portfolio." },
      { icon: GraduationCap, persona: "Students", line: "Shipped work beats a CGPA." },
      { icon: Palette, persona: "Creators", line: "Turn side projects into commissions." },
    ],
    templates: [
      { title: "AI SaaS launch", tag: "SaaS", imageKey: "tpl-1", alt: "AI SaaS project" },
      { title: "Chrome extension", tag: "Extension", imageKey: "tpl-2", alt: "Chrome extension project" },
      { title: "Chatbot", tag: "Agent", imageKey: "tpl-3", alt: "Chatbot project" },
      { title: "Design tool", tag: "Design", imageKey: "tpl-4", alt: "Design tool project" },
    ],
    integrations: ["GitHub", "Vercel", "Lovable", "Product Hunt", "Loom", "Figma", "YouTube", "Twitter/X", "Notion", "Supabase", "Cursor", "Netlify"],
    faqs: [
      { q: "Can anyone submit?", a: "Yes — every member can submit. Approvals are lightweight and usually same day." },
      { q: "Does 'get hired' actually happen?", a: "Yes. Recruiters browse the Showcase and reach out via DM every week." },
      { q: "Can I keep a project private?", a: "Yes. Mark any project draft or community-only." },
      { q: "Do I own my content?", a: "100% yours. Export anytime, delete anytime." },
    ],
    quote: { text: "Two client leads landed in my DMs the week I shipped.", who: "Anaya D.", role: "Freelance builder, Kolkata" },
    meta: {
      title: "Project Showcase — ship, get discovered | VibeCode",
      description: "Portfolio pages built for AI builders. Ship a project, get hired. Sign up to submit.",
    },
  }),
};

// Legacy re-exports kept as no-ops for anything that might still import them
export type ProductFeature = ProductFeatureRow;
export type ProductStep = { n: number; title: string; body: string };
