// Feed ranking + Pro/OG-aware loaders.
// Additive: existing feed UI can opt-in by calling loadFeed(); nothing here
// mutates the current VibeHome/CenterFeed rendering path.
import { supabase } from "@/integrations/supabase/client";

export type FeedTab = "for-you" | "following" | "trending" | "prompts" | "workflows" | "projects";

export interface FeedPost {
  id: string;
  author_id: string;
  kind: string | null;
  body: string | null;
  image_urls: string[] | null;
  reaction_counts: Record<string, number> | null;
  comment_count: number | null;
  repost_count: number | null;
  like_count: number | null;
  created_at: string;
  is_demo?: boolean | null;
  profiles?: {
    id: string;
    display_name: string | null;
    username: string | null;
    avatar_url: string | null;
    subscription_plan?: string | null;
    is_verified?: boolean | null;
    is_og_member?: boolean | null;
    og_number?: number | null;
    is_boosted?: boolean | null;
  } | null;
  feed_score?: number;
}

const PROFILE_COLS =
  "id, display_name, username, avatar_url, subscription_plan, is_verified, is_og_member, og_number, is_boosted";

export async function loadFeed(
  userId: string | null,
  tab: FeedTab,
  page = 0,
  pageSize = 15,
): Promise<FeedPost[]> {
  const offset = page * pageSize;
  switch (tab) {
    case "for-you":
      return loadForYouFeed(userId, offset, pageSize);
    case "following":
      return loadFollowingFeed(userId, offset, pageSize);
    case "trending":
      return loadTrendingFeed(offset, pageSize);
    case "prompts":
      return loadTypedFeed("prompt", offset, pageSize);
    case "workflows":
      return loadTypedFeed("workflow", offset, pageSize);
    case "projects":
      return loadTypedFeed("project", offset, pageSize);
    default:
      return loadForYouFeed(userId, offset, pageSize);
  }
}

async function loadForYouFeed(userId: string | null, offset: number, limit: number): Promise<FeedPost[]> {
  const { data: posts } = await (supabase.from("posts") as any)
    .select(`*, profiles!inner(${PROFILE_COLS}), post_feed_scores(total_score)`)
    .order("created_at", { ascending: false })
    .range(offset, offset + limit * 3 - 1);

  if (!posts || !posts.length) return [];

  let followingIds: string[] = [];
  if (userId) {
    const { data } = await (supabase.from("follows") as any)
      .select("following_id")
      .eq("follower_id", userId);
    followingIds = (data ?? []).map((f: any) => f.following_id);
  }

  const scored = (posts as any[]).map((p) => {
    let score = p.post_feed_scores?.[0]?.total_score ?? 0;
    if (followingIds.includes(p.author_id)) score += 30;
    const plan = p.profiles?.subscription_plan;
    if (plan === "og_pro") score += 15;
    else if (plan === "pro") score += 8;
    if (p.profiles?.is_boosted) score += 40;
    return { ...p, feed_score: score } as FeedPost;
  });

  return scored.sort((a, b) => (b.feed_score ?? 0) - (a.feed_score ?? 0)).slice(0, limit);
}

async function loadFollowingFeed(userId: string | null, offset: number, limit: number): Promise<FeedPost[]> {
  if (!userId) return [];
  const { data: follows } = await (supabase.from("follows") as any)
    .select("following_id")
    .eq("follower_id", userId);
  const ids = (follows ?? []).map((f: any) => f.following_id);
  if (!ids.length) return [];

  const { data } = await (supabase.from("posts") as any)
    .select(`*, profiles(${PROFILE_COLS})`)
    .in("author_id", ids)
    .order("created_at", { ascending: false })
    .range(offset, offset + limit - 1);
  return (data ?? []) as FeedPost[];
}

async function loadTrendingFeed(offset: number, limit: number): Promise<FeedPost[]> {
  const since = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString();
  const { data } = await (supabase.from("posts") as any)
    .select(`*, profiles(${PROFILE_COLS}), post_feed_scores(total_score)`)
    .gte("created_at", since)
    .order("created_at", { ascending: false })
    .range(offset, offset + limit * 2 - 1);
  if (!data) return [];
  return (data as any[])
    .sort(
      (a, b) => (b.post_feed_scores?.[0]?.total_score ?? 0) - (a.post_feed_scores?.[0]?.total_score ?? 0),
    )
    .slice(0, limit) as FeedPost[];
}

async function loadTypedFeed(kind: string, offset: number, limit: number): Promise<FeedPost[]> {
  const { data } = await (supabase.from("posts") as any)
    .select(`*, profiles(${PROFILE_COLS})`)
    .eq("kind", kind)
    .order("created_at", { ascending: false })
    .range(offset, offset + limit - 1);
  return (data ?? []) as FeedPost[];
}

/** Recompute cached score for a post after engagement (reaction/comment/repost). */
export async function updatePostFeedScore(postId: string): Promise<void> {
  try {
    await (supabase as any).rpc("calculate_post_score", { p_post_id: postId });
  } catch {
    /* non-fatal */
  }
}

/** Log a profile view + bump cached counters. Skips self-views. */
export async function trackProfileView(
  viewedProfileId: string,
  viewerId: string | null,
  source: "search" | "explore" | "feed" | "job_application" | "direct" = "direct",
): Promise<void> {
  if (!viewedProfileId || viewedProfileId === viewerId) return;
  try {
    await (supabase.from("profile_views") as any).insert({
      viewed_profile_id: viewedProfileId,
      viewer_id: viewerId,
      source,
    });
    await (supabase as any).rpc("increment_profile_views", { p_profile_id: viewedProfileId });
  } catch {
    /* non-fatal */
  }
}
