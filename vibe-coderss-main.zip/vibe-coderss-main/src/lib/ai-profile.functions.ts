import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { generateText } from "ai";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

export type ProfileAiContent = {
  headline: string;
  about_long: string;
  what_i_do: string[];
  expertise: string[];
  services_offered: string[];
  approach: string[];
  why_work_with_me: string[];
  achievements: string[];
  values: string[];
  nice_to_haves: string[];
  faq: { q: string; a: string }[];
};

export type ProfileAiInput = {
  displayName: string;
  title?: string;
  bio?: string;
  location?: string;
  role?: "builder" | "hirer";
  skills?: string[];
  tools?: string[];
  experience?: string;
};

const FALLBACK = (i: ProfileAiInput): ProfileAiContent => ({
  headline: i.title || `${i.role === "builder" ? "Independent Builder" : "Talent Partner"} on VibeCode`,
  about_long: i.bio || `${i.displayName} is building on VibeCode.`,
  what_i_do: (i.skills ?? []).slice(0, 6).map((s) => `Ship ${s} features end-to-end for real users`),
  expertise: (i.skills ?? []).slice(0, 8),
  services_offered: ["Consulting & audits", "MVP builds", "Long-term collaborations"],
  approach: ["Deeply understand the problem", "Ship the smallest working thing", "Iterate with users, not slides"],
  why_work_with_me: ["Direct ownership, no middlemen", "Real production experience, not toy prototypes", "Clear written updates every step"],
  achievements: [],
  values: ["Craft over speed-for-its-own-sake", "Users before internal politics", "Documented decisions"],
  nice_to_haves: (i.tools ?? []).slice(0, 5),
  faq: [
    { q: "How do we start?", a: "Send a message with your goal — we jump on a 20-min call this week." },
    { q: "What's turnaround like?", a: "Small scopes ship in days, bigger builds in 2–6 weeks depending on depth." },
  ],
});

export const generateProfileContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => input as ProfileAiInput)
  .handler(async ({ data, context }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) return FALLBACK(data);

    const gateway = createLovableAiGatewayProvider(key);
    const model = gateway("google/gemini-3-flash-preview");

    const roleLabel = data.role === "hirer" ? "hiring manager / talent partner" : "independent AI builder";
    const prompt = `You are writing a detailed, professional VibeCode profile for a ${roleLabel}.
Return ONLY minified JSON matching this exact TypeScript shape (no markdown, no code fences, no extra keys):
{"headline":string,"about_long":string,"what_i_do":string[],"expertise":string[],"services_offered":string[],"approach":string[],"why_work_with_me":string[],"achievements":string[],"values":string[],"nice_to_haves":string[],"faq":{"q":string,"a":string}[]}

Rules:
- "about_long" is 3 short paragraphs joined with \\n\\n, written in first person, warm but professional, 120-180 words total.
- Each array has 4-7 concise bullet items (single sentence, 8-18 words each). Avoid clichés like "results-driven" or "passionate".
- "faq" has exactly 4 items, real questions a client would ask.
- Use the person's actual skills, tools, location, and role — don't invent employers, companies, degrees, or specific numbers.
- Keep tone confident, plainspoken, Indian-startup-friendly. No emojis. No hashtags.

Profile inputs:
- Name: ${data.displayName}
- Role on platform: ${roleLabel}
- Headline / Title: ${data.title || "(not provided)"}
- Location: ${data.location || "(not provided)"}
- Experience level: ${data.experience || "(not provided)"}
- Short bio hint: ${data.bio || "(not provided)"}
- Skills: ${(data.skills ?? []).join(", ") || "(not provided)"}
- AI Tools they use: ${(data.tools ?? []).join(", ") || "(not provided)"}`;

    try {
      const { text } = await generateText({ model, prompt, temperature: 0.7 });
      const cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "");
      const first = cleaned.indexOf("{");
      const last = cleaned.lastIndexOf("}");
      if (first < 0 || last < 0) throw new Error("no json");
      const parsed = JSON.parse(cleaned.slice(first, last + 1)) as ProfileAiContent;

      // Persist to profile
      await context.supabase
        .from("profiles" as any)
        .update({ ai_content: parsed } as any)
        .eq("id", context.userId);

      return parsed;
    } catch (err) {
      console.error("[ai-profile] generation failed", err);
      const fb = FALLBACK(data);
      await context.supabase
        .from("profiles" as any)
        .update({ ai_content: fb } as any)
        .eq("id", context.userId);
      return fb;
    }
  });
