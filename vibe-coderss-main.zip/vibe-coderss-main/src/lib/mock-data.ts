// Mock data for VibeCode platform
import { wfCover } from "./workflow-covers";

export type Builder = {
  id: string;
  username: string;
  name: string;
  title: string;
  avatar: string;
  banner?: string;
  location: string;
  available: boolean;
  verified: boolean;
  bio: string;
  skills: string[];
  tools: string[];
  rating: number;
  reviews: number;
  followers: number;
  following: number;
  projects: number;
  industry: string[];
  type: "Freelancer" | "Agency" | "Student" | "Founder";
  experience: "Beginner" | "Intermediate" | "Expert";
  hourlyRate: number;
  is_demo?: boolean;
};

const avatars = (seed: string) =>
  `https://api.dicebear.com/7.x/notionists/svg?seed=${seed}&backgroundColor=3b82f6,8b5cf6,22c55e,f59e0b,ef4444`;

export const builders: Builder[] = [
  { id: "1", username: "aarav", name: "Aarav Mehta", title: "AI Automation Builder", avatar: avatars("aarav"), location: "Bangalore", available: true, verified: true, bio: "Building n8n + GPT workflows for SaaS founders. 6 yrs shipping AI tools. Currently scaling automation at a YC startup.", skills: ["Automation", "Backend", "Prompt Engineering", "RAG"], tools: ["n8n", "Claude", "Lovable", "Cursor"], rating: 4.9, reviews: 38, followers: 1240, following: 320, projects: 12, industry: ["SaaS", "FinTech"], type: "Freelancer", experience: "Expert", hourlyRate: 4500 },
  { id: "2", username: "priya", name: "Priya Sharma", title: "Vibe Coder · Lovable Specialist", avatar: avatars("priya"), location: "Delhi", available: true, verified: true, bio: "Shipping micro-SaaS with Lovable + Supabase. Past: Razorpay, Zomato. Helping non-tech founders launch in days.", skills: ["Full-stack", "UI/UX", "Product"], tools: ["Lovable", "Cursor", "ChatGPT", "Bolt"], rating: 5.0, reviews: 52, followers: 2890, following: 145, projects: 24, industry: ["SaaS", "E-Commerce"], type: "Founder", experience: "Expert", hourlyRate: 6000 },
  { id: "3", username: "rohan", name: "Rohan Iyer", title: "AI Workflow Engineer", avatar: avatars("rohan"), location: "Mumbai", available: false, verified: true, bio: "n8n + Make.com automation expert. Built workflows processing 1M+ events/day.", skills: ["Automation", "Integrations", "APIs"], tools: ["n8n", "Make", "ChatGPT", "Claude"], rating: 4.8, reviews: 29, followers: 890, following: 210, projects: 18, industry: ["FinTech", "HealthTech"], type: "Freelancer", experience: "Expert", hourlyRate: 3800 },
  { id: "4", username: "ananya", name: "Ananya Reddy", title: "Generative AI Designer", avatar: avatars("ananya"), location: "Bangalore", available: true, verified: false, bio: "Midjourney + Figma. Brand systems for AI-first startups.", skills: ["Design", "Brand", "Illustration"], tools: ["Midjourney", "ChatGPT", "Figma"], rating: 4.7, reviews: 41, followers: 1560, following: 290, projects: 32, industry: ["Marketing", "E-Commerce"], type: "Freelancer", experience: "Intermediate", hourlyRate: 2800 },
  { id: "5", username: "kabir", name: "Kabir Singh", title: "Founder · AI Health App", avatar: avatars("kabir"), location: "Pune", available: false, verified: true, bio: "Building a healthtech co-pilot. Ex-Microsoft. Looking for design + ML collaborators.", skills: ["Product", "ML", "Leadership"], tools: ["Cursor", "Claude", "n8n"], rating: 4.9, reviews: 15, followers: 3400, following: 89, projects: 8, industry: ["HealthTech"], type: "Founder", experience: "Expert", hourlyRate: 8000 },
  { id: "6", username: "ishita", name: "Ishita Verma", title: "Indie Hacker · Micro-SaaS", avatar: avatars("ishita"), location: "Remote", available: true, verified: false, bio: "Shipped 12 micro-SaaS in 18 months. Lovable + Stripe is my stack.", skills: ["Full-stack", "Growth", "SEO"], tools: ["Lovable", "Cursor", "Bolt"], rating: 4.8, reviews: 22, followers: 980, following: 156, projects: 12, industry: ["SaaS"], type: "Founder", experience: "Intermediate", hourlyRate: 3200 },
  { id: "7", username: "vikram", name: "Vikram Joshi", title: "AI Agency Lead", avatar: avatars("vikram"), location: "Gurgaon", available: true, verified: true, bio: "Running an 8-person AI agency. We ship custom AI apps for enterprises.", skills: ["Leadership", "Architecture", "Sales"], tools: ["Claude", "Cursor", "n8n", "Lovable"], rating: 4.9, reviews: 67, followers: 4200, following: 412, projects: 45, industry: ["Legal", "FinTech", "SaaS"], type: "Agency", experience: "Expert", hourlyRate: 7500 },
  { id: "8", username: "sara", name: "Sara Khan", title: "Prompt Engineer", avatar: avatars("sara"), location: "Hyderabad", available: true, verified: false, bio: "Reverse-engineering LLMs for fun and profit. 200+ prompts in my library.", skills: ["Prompt Engineering", "Research", "Writing"], tools: ["ChatGPT", "Claude", "Gemini"], rating: 4.7, reviews: 31, followers: 1820, following: 245, projects: 6, industry: ["EdTech", "Marketing"], type: "Freelancer", experience: "Intermediate", hourlyRate: 2200 },
  { id: "9", username: "arjun", name: "Arjun Nair", title: "Student Builder · IIT", avatar: avatars("arjun"), location: "Chennai", available: true, verified: false, bio: "CS sophomore. Hackathon winner. Building open-source AI tools.", skills: ["Full-stack", "ML", "Open Source"], tools: ["Cursor", "Claude", "Bolt"], rating: 4.6, reviews: 8, followers: 420, following: 180, projects: 4, industry: ["EdTech", "Gaming"], type: "Student", experience: "Beginner", hourlyRate: 800 },
  { id: "10", username: "neha", name: "Neha Kapoor", title: "AI Product Manager", avatar: avatars("neha"), location: "Bangalore", available: false, verified: true, bio: "PM turned builder. Shipping AI features at a unicorn. Mentoring 1:1.", skills: ["Product", "Strategy", "Analytics"], tools: ["ChatGPT", "Claude", "Lovable"], rating: 5.0, reviews: 19, followers: 2100, following: 98, projects: 7, industry: ["SaaS", "E-Commerce"], type: "Founder", experience: "Expert", hourlyRate: 5500 },
];

export type Project = {
  id: string;
  title: string;
  cover: string;
  builderId: string;
  description: string;
  tools: string[];
  industry: string;
  upvotes: number;
  date: string;
  is_demo?: boolean;
};


// Warm editorial cover gradients — cream base + coral / teal / gold pops to match the brand
const COVER_PALETTES = [
  { bg: "#FAF6F1", a: "#E8623A", b: "#F5A623" },
  { bg: "#FFF4E6", a: "#2DD4BF", b: "#E8623A" },
  { bg: "#F5F0E8", a: "#FFB199", b: "#F5A623" },
  { bg: "#FFE4E1", a: "#E8623A", b: "#7C3AED" },
  { bg: "#E8F7F4", a: "#2DD4BF", b: "#0F0F0F" },
  { bg: "#FFF7D6", a: "#F5A623", b: "#E8623A" },
];
const cover = (i: number) => {
  const p = COVER_PALETTES[i % COVER_PALETTES.length];
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 600 400'><rect width='600' height='400' fill='${p.bg}'/><circle cx='460' cy='90' r='130' fill='${p.a}' opacity='0.85'/><circle cx='140' cy='320' r='110' fill='${p.b}' opacity='0.75'/><circle cx='320' cy='200' r='60' fill='#0F0F0F' opacity='0.08'/></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

// Curated professional Unsplash photos for template & service thumbnails.
const UNSPLASH_COVERS = [
  "photo-1461749280684-dccba630e2f6", // code screen
  "photo-1517694712202-14dd9538aa97", // laptop code
  "photo-1498050108023-c5249f4df085", // macbook coding
  "photo-1555066931-4365d14bab8c",    // code lines
  "photo-1519389950473-47ba0277781c", // team laptops
  "photo-1551288049-bebda4e38f71",    // analytics dashboard
  "photo-1460925895917-afdab827c52f", // charts
  "photo-1504384308090-c894fdcc538d", // workspace
  "photo-1522071820081-009f0129c71c", // team collab
  "photo-1556761175-5973dc0f32e7",    // business meeting
  "photo-1451187580459-43490279c0fa", // network globe
  "photo-1533750349088-cd871a92f312", // design tools
  "photo-1531482615713-2afd69097998", // dev workflow
  "photo-1454165804606-c3d57bc86b40", // charts closeup
  "photo-1550439062-609e1531270e",    // code night
  "photo-1517048676732-d65bc937f952", // marketing team
];
const unsplashCover = (i: number) =>
  `https://images.unsplash.com/${UNSPLASH_COVERS[i % UNSPLASH_COVERS.length]}?w=1200&auto=format&fit=crop&q=80`;


const projectCover = (id: string) =>
  `https://images.unsplash.com/${id}?w=1200&auto=format&fit=crop&q=80`;

export const projects: Project[] = [
  { id: "1", title: "MedScribe — AI Clinical Notes", cover: projectCover("photo-1581093588401-fbb62a02f120"), builderId: "5", description: "Voice-to-EHR for Indian clinics. Cuts doctor note-taking by 70%.", tools: ["Claude", "Lovable", "Whisper"], industry: "HealthTech", upvotes: 432, date: "2 days ago" },
  { id: "2", title: "FlowOps — n8n Templates Marketplace", cover: projectCover("photo-1518186285589-2f7649de83e0"), builderId: "1", description: "200+ pre-built n8n workflows for SaaS ops teams.", tools: ["n8n", "Lovable", "Stripe"], industry: "SaaS", upvotes: 318, date: "5 days ago" },
  { id: "3", title: "BrandKit AI", cover: projectCover("photo-1558655146-9f40138edfeb"), builderId: "4", description: "Generate full brand systems from a single prompt.", tools: ["Midjourney", "Cursor", "Figma API"], industry: "Marketing", upvotes: 287, date: "1 week ago" },
  { id: "4", title: "LedgerGPT", cover: projectCover("photo-1554224155-8d04cb21cd6c"), builderId: "7", description: "Conversational accounting for Indian SMBs. GST-aware.", tools: ["Claude", "Lovable", "Supabase"], industry: "FinTech", upvotes: 244, date: "1 week ago" },
  { id: "5", title: "Pitch.studio", cover: projectCover("photo-1557804506-669a67965ba0"), builderId: "2", description: "AI pitch-deck builder. Funded startups use it.", tools: ["Lovable", "GPT-4", "Stripe"], industry: "SaaS", upvotes: 198, date: "2 weeks ago" },
  { id: "6", title: "LegalLens", cover: projectCover("photo-1589994965851-a8f479c573a9"), builderId: "7", description: "Contract review co-pilot for Indian law firms.", tools: ["Claude", "Cursor", "n8n"], industry: "Legal", upvotes: 176, date: "2 weeks ago" },
  { id: "7", title: "ShipFast Boilerplate", cover: projectCover("photo-1517694712202-14dd9538aa97"), builderId: "6", description: "Lovable + Supabase starter with auth, payments, dashboards.", tools: ["Lovable", "Supabase", "Stripe"], industry: "SaaS", upvotes: 165, date: "3 weeks ago" },
  { id: "8", title: "Workflow Forge", cover: projectCover("photo-1451187580459-43490279c0fa"), builderId: "3", description: "Visual builder for n8n + Make.com hybrid automations.", tools: ["n8n", "Make", "Cursor"], industry: "SaaS", upvotes: 142, date: "3 weeks ago" },
  { id: "9", title: "PromptVault", cover: projectCover("photo-1555949963-ff9fe0c870eb"), builderId: "8", description: "Team prompt library with versioning and analytics.", tools: ["GPT-4", "Lovable", "Supabase"], industry: "SaaS", upvotes: 128, date: "1 month ago" },

];

export type Service = {
  id: string;
  title: string;
  builderId: string;
  cover: string;
  price: number;
  delivery: number;
  rating: number;
  reviews: number;
  tags: string[];
  category: string;
  is_demo?: boolean;
};


export const services: Service[] = [
  { id: "1", title: "I will build your full Lovable SaaS in 7 days", builderId: "2", cover: cover(220), price: 45000, delivery: 7, rating: 5.0, reviews: 23, tags: ["Lovable", "Full-stack"], category: "Development" },
  { id: "2", title: "Custom n8n automation for your business", builderId: "1", cover: cover(140), price: 18000, delivery: 5, rating: 4.9, reviews: 31, tags: ["n8n", "Automation"], category: "Automation" },
  { id: "3", title: "AI Agency: Custom apps for enterprises", builderId: "7", cover: cover(290), price: 250000, delivery: 30, rating: 4.9, reviews: 12, tags: ["Enterprise", "Custom"], category: "Agency" },
  { id: "4", title: "Brand system designed with AI", builderId: "4", cover: cover(20), price: 28000, delivery: 10, rating: 4.7, reviews: 18, tags: ["Design", "Branding"], category: "Design" },
  { id: "5", title: "Prompt engineering audit + library", builderId: "8", cover: cover(310), price: 12000, delivery: 4, rating: 4.8, reviews: 27, tags: ["Prompts", "Audit"], category: "Consulting" },
  { id: "6", title: "Micro-SaaS MVP in a weekend", builderId: "6", cover: cover(110), price: 35000, delivery: 3, rating: 4.8, reviews: 14, tags: ["MVP", "Lovable"], category: "Development" },
  { id: "7", title: "AI Product Strategy 1:1", builderId: "10", cover: cover(190), price: 8000, delivery: 1, rating: 5.0, reviews: 22, tags: ["Strategy", "Mentoring"], category: "Consulting" },
  { id: "8", title: "Workflow automation for content teams", builderId: "3", cover: cover(70), price: 15000, delivery: 5, rating: 4.8, reviews: 19, tags: ["Content", "Workflow"], category: "Automation" },
];

export type Community = {
  id: string;
  slug: string;
  name: string;
  icon: string;
  members: number;
  postsThisWeek: number;
  description: string;
  hue: number;
  isOfficial?: boolean;
  is_demo?: boolean;
};

export const communities: Community[] = [
  { id: "1", slug: "lovable", name: "Lovable Builders", icon: "💖", members: 8420, postsThisWeek: 142, description: "Ship full-stack apps without writing boilerplate. Tips, templates, showcases.", hue: 340 },
  { id: "2", slug: "cursor", name: "Cursor Power Users", icon: "⌘", members: 6210, postsThisWeek: 98, description: "Pair-programming with AI. Rules, shortcuts, and project setups.", hue: 200 },
  { id: "3", slug: "claude", name: "Claude Creators", icon: "🧠", members: 5890, postsThisWeek: 76, description: "Prompts, agents, and creative workflows with Anthropic's Claude.", hue: 30 },
  { id: "4", slug: "openai", name: "OpenAI Builders", icon: "⚡", members: 12300, postsThisWeek: 210, description: "GPT-4, GPT-4o, Assistants API, Realtime — everything OpenAI.", hue: 160 },
  { id: "5", slug: "n8n", name: "n8n Automation India", icon: "🔗", members: 4120, postsThisWeek: 64, description: "Self-hosted automation. Workflows, nodes, custom integrations.", hue: 280 },
  { id: "6", slug: "healthcare-ai", name: "Healthcare AI", icon: "⚕️", members: 1820, postsThisWeek: 28, description: "Builders shipping AI for clinics, hospitals, and patients.", hue: 180 },
  { id: "7", slug: "fintech-ai", name: "FinTech AI", icon: "💸", members: 2340, postsThisWeek: 38, description: "Banking, payments, RegTech — AI for India's financial stack.", hue: 120 },
  { id: "8", slug: "student-builders", name: "Student Builders", icon: "🎓", members: 3210, postsThisWeek: 52, description: "Students shipping AI side-projects. Hackathons, internships, mentors.", hue: 240 },
  { id: "9", slug: "indie-founders", name: "Indie Founders India", icon: "🚀", members: 5640, postsThisWeek: 88, description: "Solo & small-team founders building profitable AI products.", hue: 10 },
  { id: "10", slug: "open-source-ai", name: "Open Source AI", icon: "🌐", members: 2890, postsThisWeek: 41, description: "Llama, Mistral, local LLMs, fine-tuning, contributions welcome.", hue: 90 },
];

export type Prompt = {
  id: string;
  title: string;
  model: string;
  category: string;
  preview: string;
  full: string;
  upvotes: number;
  copyCount?: number;
  builderId: string;

};


export const prompts: Prompt[] = [
  { id: "1", title: "Ultimate SaaS Landing Page Generator", model: "GPT-4o", category: "Marketing", preview: "Act as a senior conversion copywriter at Stripe. Given a one-line product description, produce a complete landing page outline...", full: "Act as a senior conversion copywriter at Stripe. Given a one-line product description, produce a complete landing page outline with: 1) Hero headline (8 words max), 2) Subheadline (20 words), 3) Three benefit bullets, 4) Social proof block, 5) Feature trio, 6) FAQ (5 Q/A), 7) CTA copy.\n\nProduct: {{description}}", upvotes: 1240, builderId: "2" },
  { id: "2", title: "n8n Workflow Architect", model: "Claude", category: "Automation", preview: "You are an n8n expert. Given a business process described in plain English, output a node-by-node workflow specification...", full: "You are an n8n expert. Output a node-by-node workflow specification including trigger, processing nodes, error branches, and credentials required.\n\nProcess: {{process}}", upvotes: 892, builderId: "1" },
  { id: "3", title: "Code Review like Linus Torvalds", model: "Claude", category: "Engineering", preview: "Review this PR with the directness of Linus Torvalds. Focus on architectural smells, hidden complexity, and naming...", full: "Review this PR with the directness of Linus Torvalds. Focus on architectural smells, hidden complexity, and naming. Be brutal but constructive.\n\n{{diff}}", upvotes: 754, builderId: "7" },
  { id: "4", title: "Brand Naming + Domain Generator", model: "GPT-4o", category: "Marketing", preview: "Generate 10 brand name candidates for {{description}}. Each name must be: 2 syllables, easy to spell, available as .com or .ai...", full: "Generate 10 brand name candidates for {{description}}. Each: 2 syllables, easy to spell, .com or .ai availability hint, and 1-line rationale.", upvotes: 631, builderId: "4" },
  { id: "5", title: "Pitch Deck Outline (10 slides)", model: "Claude", category: "Startup", preview: "Build a 10-slide pitch deck outline following the Sequoia template for: {{startup}}. Each slide: title + 3 bullet points + suggested visual...", full: "Build a 10-slide pitch deck outline following the Sequoia template. Each slide: title + 3 bullet points + visual suggestion.", upvotes: 587, builderId: "10" },
  { id: "6", title: "User Interview Synthesizer", model: "Claude", category: "Research", preview: "You are a senior UX researcher. Given raw interview transcripts, extract: themes, surprising quotes, opportunity areas, anti-patterns...", full: "You are a senior UX researcher. Extract themes, surprising quotes, opportunity areas, anti-patterns. Cite participant IDs.", upvotes: 502, builderId: "10" },
  { id: "7", title: "SEO Cluster Map Generator", model: "GPT-4o", category: "Marketing", preview: "Generate an SEO topic cluster for {{topic}}. Output: 1 pillar page (3000 words outline), 8 cluster posts (titles + H2s), 30 keywords...", full: "Generate an SEO topic cluster: pillar page outline, 8 cluster posts with H2s, 30 long-tail keywords with intent classification.", upvotes: 448, builderId: "8" },
  { id: "8", title: "Lovable Component Spec", model: "Claude", category: "Engineering", preview: "Write a component spec optimized for Lovable AI. Include: props interface, design tokens used, accessibility notes, edge cases...", full: "Write a component spec optimized for Lovable AI. Include props interface, design tokens, a11y, edge cases, example usage.", upvotes: 412, builderId: "6" },
  { id: "9", title: "Customer Email Triage Agent", model: "Claude", category: "Support", preview: "Triage this customer email. Output: 1) Intent classification, 2) Urgency 1-5, 3) Suggested response draft, 4) Internal note...", full: "Triage this customer email. Output intent, urgency 1-5, response draft, internal note, escalation flag.", upvotes: 378, builderId: "1" },
  { id: "10", title: "AI System Prompt Auditor", model: "GPT-4o", category: "Engineering", preview: "Audit the following system prompt for: ambiguity, prompt-injection risk, missing fallbacks, role bleed, length efficiency...", full: "Audit this system prompt. Score 1-10 on clarity, injection-resistance, fallback handling, role consistency, token efficiency.", upvotes: 341, builderId: "8" },
  { id: "11", title: "Cold Outreach Email Generator", model: "Claude", category: "Marketing", preview: "Write a cold email that doesn't feel cold. Personalize on company news, recent funding, or product launches...", full: "Write a 4-line cold email to {{persona}} at {{company}}. Open with a specific reference to their recent {{trigger}}. End with one soft CTA.", upvotes: 312, builderId: "8" },
  { id: "12", title: "Product Launch Tweet Thread", model: "GPT-4o", category: "Marketing", preview: "Write a 9-tweet launch thread. Hook in tweet 1, problem in 2, solution in 3-6, social proof in 7, CTA in 8-9...", full: "Write a 9-tweet thread launching {{product}}. Hook, problem, solution (4 tweets), social proof, CTA, link.", upvotes: 298, builderId: "4" },
  { id: "13", title: "OKR Writer for Startups", model: "Claude", category: "Startup", preview: "Generate Q4 OKRs for a Series A SaaS. 3 objectives, 3 measurable KRs each. Stretch but achievable...", full: "Generate Q{{quarter}} OKRs for a {{stage}} {{industry}} startup. 3 objectives, 3 measurable KRs each.", upvotes: 276, builderId: "10" },
  { id: "14", title: "Bug Report → Repro Steps", model: "Claude", category: "Engineering", preview: "Convert a messy customer bug report into clean repro steps with expected vs actual behavior...", full: "Convert this customer bug report into: 1) Title, 2) Environment, 3) Repro steps, 4) Expected, 5) Actual, 6) Severity.\n\n{{report}}", upvotes: 264, builderId: "7" },
  { id: "15", title: "RAG Chunk Splitter", model: "GPT-4o", category: "Engineering", preview: "Split this document into semantically-coherent chunks of ~500 tokens. Preserve headings as metadata...", full: "Split into ~500-token chunks. Preserve heading hierarchy as metadata. Return JSON array with {text, headings, position}.", upvotes: 251, builderId: "1" },
  { id: "16", title: "Customer Persona from Reviews", model: "Claude", category: "Research", preview: "Synthesize 3 customer personas from these app store reviews. Include JTBD, frustrations, and decision triggers...", full: "From {{reviews}}, generate 3 personas: demographics, JTBD, frustrations, decision triggers, preferred channels.", upvotes: 238, builderId: "10" },
  { id: "17", title: "Twitter Bio Optimizer", model: "GPT-4o", category: "Marketing", preview: "Rewrite my Twitter bio to maximize follows from AI builders. Punchy, specific, no buzzwords...", full: "Rewrite this Twitter bio in 3 styles (punchy / authoritative / curious). 160 char limit. No emojis unless essential.\n\n{{bio}}", upvotes: 224, builderId: "4" },
  { id: "18", title: "Investor Update Email", model: "Claude", category: "Startup", preview: "Monthly investor update template. Wins, lows, asks, metrics. Honest tone, founder-style...", full: "Write a monthly investor update: wins (3), lows (2), asks (1-2), metrics (MRR, churn, runway), hiring.", upvotes: 213, builderId: "2" },
  { id: "19", title: "Sales Discovery Call Script", model: "Claude", category: "Marketing", preview: "30-min discovery call structure for B2B SaaS. SPIN questions, pain dig, next steps...", full: "30-min discovery call script: opener, 6 SPIN questions, pain dig, demo gate criteria, next steps.", upvotes: 201, builderId: "10" },
  { id: "20", title: "Lovable Prompt Refiner", model: "GPT-4o", category: "Engineering", preview: "Take my vague Lovable request and rewrite it into a tight, unambiguous spec it'll one-shot...", full: "Rewrite this Lovable request for one-shot success: explicit components, design tokens, edge cases, data shape.\n\n{{request}}", upvotes: 192, builderId: "6" },
  { id: "21", title: "Cursor Rules Generator", model: "Claude", category: "Engineering", preview: "Generate a .cursorrules file for a {{stack}} project. Include code style, naming, testing, and security guards...", full: "Generate .cursorrules for {{stack}}: style, naming, testing patterns, security guards, do-not-touch list.", upvotes: 187, builderId: "7" },
  { id: "22", title: "Hindi Marketing Copy Generator", model: "GPT-4o", category: "Marketing", preview: "Write Hinglish marketing copy that feels native, not Google-translated. Tone: warm, urban, founder-style...", full: "Write Hinglish marketing copy for {{product}}: hero, 3 benefits, CTA. Natural code-switch, no translation feel.", upvotes: 176, builderId: "4" },
  { id: "23", title: "GST-aware Invoice Generator", model: "Claude", category: "Engineering", preview: "Generate a compliant Indian invoice in JSON: HSN codes, IGST/CGST/SGST split, place of supply...", full: "Generate JSON for an Indian B2B invoice. Include HSN, IGST/CGST/SGST, reverse charge flag, place of supply rules.", upvotes: 168, builderId: "7" },
  { id: "24", title: "Hiring JD Bias Detector", model: "Claude", category: "Engineering", preview: "Scan this JD for gendered, ageist, or culturally biased language. Suggest neutral rewrites...", full: "Scan this JD. List biased phrases with line numbers, classification, and neutral rewrite.\n\n{{jd}}", upvotes: 159, builderId: "10" },
  { id: "25", title: "Notion Page → API Endpoint", model: "Claude", category: "Engineering", preview: "Given a Notion product spec, generate a REST endpoint contract: route, method, request/response schema, errors...", full: "From this Notion spec, generate REST endpoint: route, method, Zod schemas, error codes, example curl.\n\n{{spec}}", upvotes: 152, builderId: "6" },
  { id: "26", title: "Daily Standup Synthesizer", model: "GPT-4o", category: "Automation", preview: "Read these Slack standup messages. Summarize by team, surface blockers, and tag at-risk items...", full: "Summarize {{messages}} as: by team, blockers, at-risk, wins. Tag @people for follow-ups.", upvotes: 147, builderId: "1" },
  { id: "27", title: "LinkedIn Hook Generator", model: "Claude", category: "Marketing", preview: "10 scroll-stopping first lines for a LinkedIn post about {{topic}}. No 'I' or rhetorical questions...", full: "Generate 10 LinkedIn opening lines on {{topic}}. Avoid 'I', rhetorical questions, and platitudes.", upvotes: 142, builderId: "4" },
  { id: "28", title: "Support Macro Library", model: "Claude", category: "Support", preview: "Generate 15 reusable customer support macros for a SaaS. Friendly, brand-safe, with merge fields...", full: "15 support macros: refund, downgrade, bug, billing, feature request, churn save. With {{customer.first_name}} fields.", upvotes: 138, builderId: "1" },
  { id: "29", title: "Founder Story Polisher", model: "Claude", category: "Startup", preview: "Take my rough founder origin story and polish it for the About page. Specific, vivid, no clichés...", full: "Polish this founder origin into 250 words: specific details, narrative arc, no clichés, ends on mission.\n\n{{story}}", upvotes: 133, builderId: "2" },
  { id: "30", title: "Competitor Teardown Template", model: "GPT-4o", category: "Research", preview: "Comprehensive competitor teardown: positioning, pricing, GTM, weaknesses, what to steal...", full: "Tear down {{competitor}}: positioning, pricing, GTM channels, weaknesses, opportunities for us to exploit.", upvotes: 128, builderId: "10" },
  { id: "31", title: "Tweet → Blog Post Expander", model: "Claude", category: "Marketing", preview: "Expand a viral tweet into an 800-word blog post. Keep voice. Add examples, sources, and a CTA...", full: "Expand this tweet into 800 words. Preserve voice. Add 2 examples, 1 stat, 1 source link, CTA.\n\n{{tweet}}", upvotes: 124, builderId: "4" },
  { id: "32", title: "Webhook Payload Parser", model: "GPT-4o", category: "Engineering", preview: "Given an unknown webhook payload, infer schema, write a Zod validator, and suggest a handler skeleton...", full: "Infer Zod schema from {{payload}}. Write TS handler with validation, idempotency, and error logging.", upvotes: 119, builderId: "7" },
  { id: "33", title: "Onboarding Email Sequence", model: "Claude", category: "Marketing", preview: "5-email onboarding drip for a {{product}}. Each email: subject, preview text, 100-word body, single CTA...", full: "Write a 5-email drip for {{product}}: welcome, aha-moment, feature, social-proof, upsell. Subject + preview + body + CTA each.", upvotes: 114, builderId: "8" },
  { id: "34", title: "Code Comment → Documentation", model: "Claude", category: "Engineering", preview: "Convert these JSDoc comments into a clean Mintlify docs page with examples, params, returns, and gotchas...", full: "Convert {{jsdoc}} into a Mintlify page: intro, params table, returns, 2 examples, gotchas, related links.", upvotes: 109, builderId: "6" },
  { id: "35", title: "n8n Node Description Writer", model: "GPT-4o", category: "Automation", preview: "Write hover-tooltip descriptions for a custom n8n node. Concise, action-first, no marketing fluff...", full: "Write 10-word tooltip descriptions for each parameter of {{nodeName}}. Action-first.", upvotes: 104, builderId: "1" },
  { id: "36", title: "User Interview Question Bank", model: "Claude", category: "Research", preview: "20 open-ended user interview questions for {{topic}}. Non-leading, JTBD-style, escape leading 'why'...", full: "Generate 20 interview questions for {{topic}}. JTBD-style, non-leading, avoid 'why' interrogation.", upvotes: 99, builderId: "10" },
  { id: "37", title: "Slack Message → Linear Issue", model: "GPT-4o", category: "Automation", preview: "Convert a casual Slack message into a properly-formed Linear issue with title, description, acceptance criteria...", full: "Convert {{slack}} into Linear: title (8 words), description, acceptance criteria, label, priority guess.", upvotes: 94, builderId: "3" },
  { id: "38", title: "Pricing Page Copywriter", model: "Claude", category: "Marketing", preview: "Write pricing page copy for 3 tiers. Anchor on high tier, justify middle, make free tier feel generous...", full: "Pricing copy for 3 tiers ({{tiers}}). Each: name, headline, price line, feature list (5), CTA. Anchor on highest.", upvotes: 89, builderId: "2" },
  { id: "39", title: "Resume → JD Match Scorer", model: "Claude", category: "Research", preview: "Score a resume against a job description on 5 dimensions. Output 0-100 with reasoning per axis...", full: "Score {{resume}} vs {{jd}}: skills match, experience depth, domain fit, signal strength, red flags. 0-100 each + summary.", upvotes: 84, builderId: "10" },
  { id: "40", title: "Domain Name Brainstormer", model: "GPT-4o", category: "Startup", preview: "30 domain name candidates for {{idea}}. Mix made-up words, real words, .ai / .so / .dev TLDs...", full: "30 domains for {{idea}}: brandable made-ups, evocative real words, .com / .ai / .so / .dev mix. Mark availability hints.", upvotes: 79, builderId: "4" },
  { id: "41", title: "Postmortem Writer", model: "Claude", category: "Engineering", preview: "Blameless postmortem template. Timeline, root cause, contributing factors, action items, lessons...", full: "Write a blameless postmortem from {{incident}}: timeline, root cause, contributing factors, 5 action items with owners.", upvotes: 75, builderId: "7" },
  { id: "42", title: "Email → Action Items Extractor", model: "Claude", category: "Automation", preview: "Read this thread. Extract action items, owners, deadlines. Output as Notion-ready checklist...", full: "Extract from {{thread}}: action items, owner, deadline, status. Format as Notion checkbox markdown.", upvotes: 71, builderId: "1" },
  { id: "43", title: "Mock Interview Conductor", model: "Claude", category: "Research", preview: "Conduct a 30-min mock product manager interview. Ask follow-ups, score on STAR framework, give feedback...", full: "Conduct mock PM interview. 6 questions across product sense, execution, leadership. Score STAR, give written feedback.", upvotes: 67, builderId: "10" },
  { id: "44", title: "WhatsApp Marketing Broadcast", model: "GPT-4o", category: "Marketing", preview: "Craft a WhatsApp broadcast (under 350 chars) for {{offer}}. Conversational, single CTA, India-friendly emojis...", full: "WhatsApp broadcast for {{offer}}. Under 350 chars, conversational, 1 emoji, 1 CTA. Hinglish optional.", upvotes: 63, builderId: "4" },
  { id: "45", title: "API Error Message Rewriter", model: "Claude", category: "Engineering", preview: "Rewrite cryptic API errors into developer-friendly messages with cause, fix, and docs link...", full: "Rewrite {{error}} as: human-readable summary, likely cause, suggested fix, docs link placeholder.", upvotes: 59, builderId: "7" },
  { id: "46", title: "Discord Welcome Bot Script", model: "GPT-4o", category: "Automation", preview: "Onboarding script for a Discord community. Greet, role-pick, channel tour, intro prompt, FAQ ping...", full: "Discord onboarding flow: 5-step DM script — greet, role pick, channel tour, intro prompt, FAQ link. Friendly tone.", upvotes: 55, builderId: "1" },
  { id: "47", title: "Daily Journaling Coach", model: "Claude", category: "Support", preview: "Reflective journaling prompts for builders. Wins, blockers, energy, one question for tomorrow...", full: "Generate today's journal prompts: wins, blockers, energy 1-10, one focus for tomorrow, gratitude.", upvotes: 51, builderId: "5" },
  { id: "48", title: "Press Release for Funding", model: "Claude", category: "Startup", preview: "TechCrunch-ready press release for a {{round}} round. Lede, quotes, traction, what's next...", full: "Press release for {{round}} round at {{startup}}: lede, founder quote, investor quote, traction stats, what's next.", upvotes: 47, builderId: "2" },
  { id: "49", title: "Refactor Plan from Codebase", model: "Claude", category: "Engineering", preview: "Read this directory tree + 3 hottest files. Propose a phased refactor plan with risk and effort scores...", full: "Given {{tree}} and {{hot_files}}, propose 3-phase refactor: scope, files touched, risk 1-5, effort in days.", upvotes: 43, builderId: "7" },
  { id: "50", title: "Newsletter Subject Line A/B", model: "GPT-4o", category: "Marketing", preview: "Generate 10 subject lines optimized for open rate. Mix curiosity, urgency, specificity, and personalization...", full: "Generate 10 subject lines for {{topic}}: mix curiosity / urgency / specificity / personalization. Mark predicted winner.", upvotes: 39, builderId: "8" },
];




export type Workflow = {
  id: string;
  title: string;
  cover: string;
  tools: string[];
  category: string;
  description: string;
  upvotes: number;
  builderId: string;
};

export const workflows: Workflow[] = [
  { id: "1", title: "Lead Enrichment → CRM → Slack", cover: wfCover(0), tools: ["n8n", "Apollo", "HubSpot", "Slack"], category: "Sales Ops", description: "New lead arrives, gets enriched with Apollo, pushed to HubSpot, and posted to #leads in Slack.", upvotes: 542, builderId: "1" },
  { id: "2", title: "Form → GPT Triage → Linear Ticket", cover: wfCover(1), tools: ["n8n", "GPT-4", "Linear"], category: "Support", description: "Customer support form → GPT classifies priority + creates Linear ticket in the right team.", upvotes: 421, builderId: "3" },
  { id: "3", title: "Daily AI Newsletter Automation", cover: wfCover(2), tools: ["n8n", "Claude", "Beehiiv"], category: "Content", description: "RSS feeds → Claude summarizes → drafts Beehiiv newsletter daily at 7am.", upvotes: 378, builderId: "8" },
  { id: "4", title: "Invoice OCR → Tally Sync", cover: wfCover(3), tools: ["Make", "GPT-4 Vision", "Tally"], category: "Finance", description: "Drop invoice PDFs in a folder → extracted with GPT-4 Vision → synced to Tally.", upvotes: 312, builderId: "3" },
  { id: "5", title: "Social Media Brand Watch", cover: wfCover(4), tools: ["n8n", "Twitter API", "Claude"], category: "Marketing", description: "Monitors brand mentions on X, Claude classifies sentiment, alerts on negatives.", upvotes: 287, builderId: "4" },
  { id: "6", title: "Auto Code Review on PR", cover: wfCover(5), tools: ["GitHub", "Claude", "Cursor"], category: "Engineering", description: "PR opened → Claude reviews diff → posts inline comments on GitHub.", upvotes: 251, builderId: "7" },
  { id: "7", title: "Calendly → Briefing Doc → Email", cover: wfCover(6), tools: ["n8n", "GPT-4", "Notion"], category: "Productivity", description: "Meeting booked → research participant → generate briefing doc → email to host.", upvotes: 214, builderId: "1" },
  { id: "8", title: "Doctor Voice Notes → EHR", cover: wfCover(7), tools: ["n8n", "Whisper", "Claude"], category: "HealthTech", description: "Voice memo from doctor → Whisper transcribes → Claude structures → pushed to EHR.", upvotes: 198, builderId: "5" },
  { id: "9", title: "Shopify Order → WhatsApp Update", cover: wfCover(8), tools: ["n8n", "Shopify", "WhatsApp"], category: "Marketing", description: "Every Shopify order triggers a personalized WhatsApp message and review request 7 days later.", upvotes: 184, builderId: "4" },
  { id: "10", title: "Resume → Notion Pipeline", cover: wfCover(9), tools: ["n8n", "GPT-4", "Notion"], category: "Productivity", description: "Inbound resumes parsed, scored, deduped, and synced to a Notion hiring pipeline.", upvotes: 172, builderId: "7" },
  { id: "11", title: "Stripe Failed Payment Recovery", cover: wfCover(10), tools: ["n8n", "Stripe", "Claude"], category: "Finance", description: "Failed charge → Claude writes a tailored email → sent through Postmark → tracked in HubSpot.", upvotes: 165, builderId: "1" },
  { id: "12", title: "GitHub Issue Auto-Triage", cover: wfCover(11), tools: ["GitHub", "Claude", "Linear"], category: "Engineering", description: "Every new GitHub issue gets labels, priority, owner suggestion, and a Linear mirror.", upvotes: 156, builderId: "7" },
  { id: "13", title: "Sales Call Recording → CRM", cover: wfCover(12), tools: ["n8n", "Whisper", "HubSpot"], category: "Sales Ops", description: "Zoom recording → transcribed → action items extracted → next steps logged to HubSpot deal.", upvotes: 148, builderId: "1" },
  { id: "14", title: "Daily Competitor Tracker", cover: wfCover(13), tools: ["Make", "GPT-4", "Slack"], category: "Marketing", description: "Scrapes competitor pricing pages every morning and posts diffs to Slack.", upvotes: 132, builderId: "8" },
  { id: "15", title: "Patient Intake Form → Triage", cover: wfCover(14), tools: ["n8n", "Claude", "Twilio"], category: "HealthTech", description: "Symptom intake form classified by Claude and routes urgent cases via SMS to on-call doctor.", upvotes: 124, builderId: "5" },
  { id: "16", title: "Podcast → Show Notes Generator", cover: wfCover(15), tools: ["n8n", "Whisper", "Claude"], category: "Content", description: "Audio file → transcribed → chaptered → SEO show notes → published to Ghost.", upvotes: 118, builderId: "8" },
];

export type Job = {
  id: string;
  title: string;
  company: string;
  logo: string;
  location: string;
  type: "Full-time" | "Part-time" | "Contract" | "Internship";
  remote: "Remote" | "Hybrid" | "On-site";
  level: "Entry" | "Mid" | "Senior" | "Lead";
  salary: string;
  posted: string;
  description: string;
  tools: string[];
  industry: string;
  is_demo?: boolean;
};


const logo = (letter: string, hue: number) =>
  `data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><rect width='64' height='64' rx='12' fill='hsl(${hue},65%,25%)'/><text x='32' y='42' font-family='Inter,sans-serif' font-size='30' font-weight='700' text-anchor='middle' fill='hsl(${hue},85%,75%)'>${letter}</text></svg>`)}`;

export const jobs: Job[] = [
  { id: "1", title: "Senior AI Engineer", company: "Razorpay", logo: logo("R", 220), location: "Bangalore", type: "Full-time", remote: "Hybrid", level: "Senior", salary: "₹40-65L", posted: "2d ago", description: "Lead AI infrastructure for fraud detection and merchant copilots. Own the ML platform end-to-end.", tools: ["Claude", "Cursor", "Python"], industry: "FinTech" },
  { id: "2", title: "Full-stack Vibe Coder", company: "Cred", logo: logo("C", 340), location: "Remote", type: "Full-time", remote: "Remote", level: "Mid", salary: "₹25-40L", posted: "3d ago", description: "Ship internal AI tools fast. You live in Cursor and ship daily. No tickets, just outcomes.", tools: ["Cursor", "Lovable", "Claude"], industry: "FinTech" },
  { id: "3", title: "AI Product Designer", company: "Zomato", logo: logo("Z", 0), location: "Gurgaon", type: "Full-time", remote: "On-site", level: "Senior", salary: "₹35-55L", posted: "5d ago", description: "Design AI-first experiences for 100M+ users. Prototype with Midjourney + Figma.", tools: ["Midjourney", "Figma", "ChatGPT"], industry: "E-Commerce" },
  { id: "4", title: "Prompt Engineer (Contract)", company: "Glance", logo: logo("G", 280), location: "Remote", type: "Contract", remote: "Remote", level: "Mid", salary: "₹3-5L/mo", posted: "1w ago", description: "Build production-grade prompt systems for our news AI. 6-month contract, possible extension.", tools: ["Claude", "GPT-4"], industry: "Marketing" },
  { id: "5", title: "Founding Engineer", company: "Stealth AI Startup", logo: logo("S", 200), location: "Bangalore", type: "Full-time", remote: "Hybrid", level: "Lead", salary: "₹50-80L + equity", posted: "1w ago", description: "Build an AI legal-research product from zero. 0.5-2% equity. Ex-FAANG founders.", tools: ["Cursor", "Claude", "n8n"], industry: "Legal" },
  { id: "6", title: "AI Automation Specialist", company: "Meesho", logo: logo("M", 320), location: "Bangalore", type: "Full-time", remote: "Hybrid", level: "Mid", salary: "₹28-42L", posted: "1w ago", description: "Automate seller operations using n8n + GPT. Save 1000+ hours per month.", tools: ["n8n", "GPT-4"], industry: "E-Commerce" },
  { id: "7", title: "ML Engineer · Healthcare", company: "Practo", logo: logo("P", 180), location: "Bangalore", type: "Full-time", remote: "On-site", level: "Senior", salary: "₹35-50L", posted: "2w ago", description: "Ship ML for symptom-checker and triage. HIPAA-grade infra.", tools: ["Python", "Claude"], industry: "HealthTech" },
  { id: "8", title: "AI Intern", company: "Lovable", logo: logo("L", 340), location: "Remote", type: "Internship", remote: "Remote", level: "Entry", salary: "₹50K/mo", posted: "3d ago", description: "Help us improve our codegen quality. Open to students.", tools: ["Lovable", "Cursor"], industry: "SaaS" },
  { id: "9", title: "AI Solutions Architect", company: "Infosys", logo: logo("I", 240), location: "Pune", type: "Full-time", remote: "Hybrid", level: "Lead", salary: "₹45-70L", posted: "2w ago", description: "Lead enterprise AI engagements. 10+ yrs experience.", tools: ["Claude", "n8n", "Python"], industry: "SaaS" },
  { id: "10", title: "Growth Engineer", company: "Postman", logo: logo("P", 30), location: "Bangalore", type: "Full-time", remote: "Hybrid", level: "Mid", salary: "₹30-45L", posted: "5d ago", description: "Ship growth experiments with AI. Mix of code, copy, analytics.", tools: ["Cursor", "ChatGPT"], industry: "SaaS" },
  { id: "11", title: "AI Content Lead", company: "Unacademy", logo: logo("U", 140), location: "Bangalore", type: "Full-time", remote: "Hybrid", level: "Senior", salary: "₹32-48L", posted: "1w ago", description: "Build AI-generated study material at scale.", tools: ["Claude", "ChatGPT"], industry: "EdTech" },
  { id: "12", title: "Workflow Consultant", company: "Acko", logo: logo("A", 100), location: "Bangalore", type: "Contract", remote: "Hybrid", level: "Senior", salary: "₹2-4L/mo", posted: "4d ago", description: "Audit and optimize internal workflows using n8n + Make.", tools: ["n8n", "Make"], industry: "FinTech" },
  { id: "13", title: "Backend Engineer · AI Infra", company: "Swiggy", logo: logo("S", 20), location: "Bangalore", type: "Full-time", remote: "Hybrid", level: "Senior", salary: "₹38-58L", posted: "2d ago", description: "Build the inference platform powering personalization for 30M+ users.", tools: ["Python", "Cursor"], industry: "E-Commerce" },
  { id: "14", title: "Vibe Coder · Founding Team", company: "Zepto", logo: logo("Z", 280), location: "Mumbai", type: "Full-time", remote: "On-site", level: "Mid", salary: "₹28-45L + equity", posted: "4d ago", description: "Ship internal tools at startup speed. You live in Lovable + Cursor.", tools: ["Lovable", "Cursor", "Claude"], industry: "E-Commerce" },
  { id: "15", title: "Junior AI Developer", company: "Freshworks", logo: logo("F", 160), location: "Chennai", type: "Full-time", remote: "Hybrid", level: "Entry", salary: "₹12-18L", posted: "6d ago", description: "Help build conversational AI for SMB customers worldwide.", tools: ["GPT-4", "Python"], industry: "SaaS" },
  { id: "16", title: "Automation Lead", company: "Urban Company", logo: logo("U", 50), location: "Gurgaon", type: "Full-time", remote: "Hybrid", level: "Lead", salary: "₹40-60L", posted: "1w ago", description: "Lead a 4-person automation pod replacing ops bottlenecks with n8n + GPT.", tools: ["n8n", "GPT-4", "Make"], industry: "E-Commerce" },
  { id: "17", title: "AI Research Engineer", company: "Sarvam AI", logo: logo("S", 120), location: "Bangalore", type: "Full-time", remote: "On-site", level: "Senior", salary: "₹50-90L + equity", posted: "3d ago", description: "Train Indic LLMs from scratch. Strong DL + distributed training background.", tools: ["Python", "Claude"], industry: "SaaS" },
  { id: "18", title: "Product Manager · AI Tools", company: "Atlassian", logo: logo("A", 220), location: "Bangalore", type: "Full-time", remote: "Hybrid", level: "Senior", salary: "₹55-85L", posted: "1w ago", description: "Own the roadmap for AI features inside Jira & Confluence.", tools: ["ChatGPT", "Claude"], industry: "SaaS" },
  { id: "19", title: "EdTech Content Engineer", company: "PhysicsWallah", logo: logo("P", 60), location: "Noida", type: "Full-time", remote: "On-site", level: "Mid", salary: "₹18-28L", posted: "5d ago", description: "Use GPT to generate, validate, and grade JEE/NEET content at scale.", tools: ["GPT-4", "Cursor"], industry: "EdTech" },
  { id: "20", title: "AI Engineer Intern · Summer", company: "Nykaa", logo: logo("N", 340), location: "Mumbai", type: "Internship", remote: "On-site", level: "Entry", salary: "₹60K/mo", posted: "2d ago", description: "3-month summer internship building recommendation copilots.", tools: ["Python", "ChatGPT"], industry: "E-Commerce" },
  { id: "21", title: "Lovable Solutions Engineer", company: "Lovable", logo: logo("L", 340), location: "Remote", type: "Full-time", remote: "Remote", level: "Mid", salary: "$60-90K", posted: "6d ago", description: "Help top customers ship faster on Lovable. Part dev, part DX.", tools: ["Lovable", "Cursor"], industry: "SaaS" },
  { id: "22", title: "Senior Cursor Specialist", company: "Browserstack", logo: logo("B", 200), location: "Mumbai", type: "Full-time", remote: "Hybrid", level: "Senior", salary: "₹40-60L", posted: "1w ago", description: "Set Cursor playbooks and rules across a 200-engineer org.", tools: ["Cursor", "Claude"], industry: "SaaS" },
];

export const AI_TOOLS = ["ChatGPT", "Claude", "Cursor", "Lovable", "n8n", "Midjourney", "Bolt", "Replit", "Gemini", "GPT-4"];
export const INDUSTRIES = ["SaaS", "HealthTech", "FinTech", "EdTech", "E-Commerce", "Legal", "Marketing", "Gaming"];
export const LOCATIONS = ["Delhi", "Mumbai", "Bangalore", "Gurgaon", "Pune", "Hyderabad", "Chennai", "Remote"];

// ============================================================
// PROGRAMMATIC EXPANSION — pad every library to 50+ entries
// ============================================================

const FIRST = ["Aarav","Vivaan","Aditya","Krishna","Rudra","Arjun","Ishaan","Reyansh","Kabir","Rohan","Yash","Karan","Dev","Sahil","Manav","Aryan","Veer","Tanish","Atharv","Om","Priya","Ananya","Diya","Aanya","Saanvi","Myra","Aadhya","Anika","Kiara","Riya","Sara","Ishita","Neha","Pooja","Tara","Mira","Aisha","Zara","Nisha","Meera","Ritu","Sneha","Kavya","Trisha","Rhea","Aditi","Naina","Esha","Avni","Tanya"];
const LAST = ["Mehta","Sharma","Iyer","Reddy","Singh","Kapoor","Joshi","Khan","Nair","Patel","Gupta","Verma","Bose","Das","Ghosh","Chopra","Malhotra","Bhat","Pillai","Rao","Menon","Sinha","Yadav","Saxena","Tiwari"];
const TITLES = ["Vibe Coder","AI Engineer","Workflow Architect","Prompt Engineer","Indie Hacker","Founder","AI Designer","Automation Lead","Full-stack Builder","Solutions Engineer","ML Researcher","Product Builder","RAG Specialist","No-Code Pro","AI Consultant"];
const SKILLS_POOL = ["Automation","Backend","Frontend","Full-stack","UI/UX","Product","Prompt Engineering","RAG","ML","Growth","SEO","Design","Brand","Open Source","Research","Strategy","APIs","Integrations","Architecture","Sales","Leadership"];
const TYPE_POOL: Builder["type"][] = ["Freelancer","Agency","Student","Founder"];
const EXP_POOL: Builder["experience"][] = ["Beginner","Intermediate","Expert"];

function pick<T>(arr: T[], i: number) { return arr[i % arr.length]; }
function pickN<T>(arr: T[], seed: number, n: number): T[] {
  const out: T[] = []; const used = new Set<number>();
  for (let k = 0; k < n; k++) { let idx = (seed * 7 + k * 13) % arr.length; while (used.has(idx)) idx = (idx + 1) % arr.length; used.add(idx); out.push(arr[idx]); }
  return out;
}

// Builders → 60 total
for (let i = builders.length; i < 60; i++) {
  const first = pick(FIRST, i * 3 + 1);
  const last = pick(LAST, i * 5 + 2);
  const name = `${first} ${last}`;
  const username = (first + last).toLowerCase().replace(/[^a-z]/g, "") + (i + 1);
  builders.push({
    id: String(i + 1), username, name,
    title: pick(TITLES, i),
    avatar: avatars(username),
    location: pick(LOCATIONS, i + 2),
    available: i % 3 !== 0,
    verified: i % 4 === 0,
    bio: `${pick(TITLES, i)} building AI-first products. Shipping with ${pick(AI_TOOLS, i)} + ${pick(AI_TOOLS, i + 3)}.`,
    skills: pickN(SKILLS_POOL, i, 3),
    tools: pickN(AI_TOOLS, i + 1, 4),
    rating: 4.4 + ((i * 7) % 7) / 10,
    reviews: 5 + ((i * 11) % 80),
    followers: 200 + ((i * 173) % 5000),
    following: 50 + ((i * 13) % 400),
    projects: 2 + ((i * 3) % 25),
    industry: pickN(INDUSTRIES, i + 2, 2),
    type: pick(TYPE_POOL, i),
    experience: pick(EXP_POOL, i),
    hourlyRate: 800 + ((i * 311) % 8000),
  });
}

// Projects → 60 total
const PROJECT_VERBS = ["AI","Smart","Auto","Co-pilot","Studio","Lab","OS","Forge","Hub","Stack","Pulse","Cloud","Wave","Edge","Sense","Vault","Genie","Mind","Brain","Sync"];
const PROJECT_NOUNS = ["Scribe","Bot","Engine","Pipeline","Studio","Dash","Notes","Pilot","Suite","Maker","Tracker","Scout","Loop","Forge","Lens","Desk","Vibe","Snap","Tales","Sync"];
for (let i = projects.length; i < 60; i++) {
  projects.push({
    id: String(i + 1),
    title: `${pick(PROJECT_VERBS, i)}${pick(PROJECT_NOUNS, i + 3)} — ${pick(INDUSTRIES, i)} ${pick(["Co-pilot","Suite","Engine","Builder","Platform"], i)}`,
    cover: cover(i * 41),
    builderId: String(((i * 7) % 60) + 1),
    description: `A focused AI tool for ${pick(INDUSTRIES, i + 1).toLowerCase()} teams. Built with ${pick(AI_TOOLS, i)} and ${pick(AI_TOOLS, i + 2)}.`,
    tools: pickN(AI_TOOLS, i, 3),
    industry: pick(INDUSTRIES, i),
    upvotes: 30 + ((i * 53) % 500),
    date: `${1 + (i % 8)} ${i % 2 ? "weeks" : "days"} ago`,
  });
}

// Services → 50 total
const SERVICE_TEMPLATES = [
  "I will build your {industry} MVP in {days} days",
  "Custom n8n automations for {industry} teams",
  "Lovable expert: ship your {industry} SaaS this week",
  "AI design system for your {industry} brand",
  "Prompt engineering audit + library for {industry}",
  "Workflow automation consulting for {industry}",
  "End-to-end AI integration for {industry} startups",
  "Cursor pair-programming sprint — {days} days",
];
const SERVICE_CATS = ["Development","Automation","Design","Consulting","Agency"];
for (let i = services.length; i < 110; i++) {
  const t = SERVICE_TEMPLATES[i % SERVICE_TEMPLATES.length]
    .replace("{industry}", pick(INDUSTRIES, i))
    .replace("{days}", String(3 + (i % 10)));
  services.push({
    id: String(i + 1), title: t,
    builderId: String(((i * 11) % 60) + 1),
    cover: cover(i * 37 + 7),
    price: 5000 + ((i * 1217) % 90000),
    delivery: 2 + (i % 14),
    rating: 4.5 + ((i * 7) % 6) / 10,
    reviews: 4 + ((i * 13) % 60),
    tags: pickN(AI_TOOLS, i, 2),
    category: pick(SERVICE_CATS, i),
  });
}

// Communities → 55 total
const COMMUNITY_SEED = [
  { name: "Bolt.new Builders", icon: "⚡", hue: 50 },
  { name: "Vercel v0 India", icon: "▲", hue: 0 },
  { name: "Make.com Power Users", icon: "🛠", hue: 270 },
  { name: "Zapier Wizards", icon: "🪄", hue: 18 },
  { name: "RAG & Vector Search", icon: "📚", hue: 200 },
  { name: "Voice AI Builders", icon: "🎙", hue: 160 },
  { name: "AI Video Creators", icon: "🎬", hue: 320 },
  { name: "Replit Hackers", icon: "🟧", hue: 25 },
  { name: "Supabase Stack", icon: "🟢", hue: 140 },
  { name: "Stripe Builders", icon: "💳", hue: 250 },
  { name: "EdTech AI India", icon: "🎓", hue: 220 },
  { name: "LegalTech AI", icon: "⚖️", hue: 40 },
  { name: "Real Estate AI", icon: "🏠", hue: 80 },
  { name: "Travel + AI", icon: "✈️", hue: 200 },
  { name: "AI for Creators", icon: "🎨", hue: 300 },
  { name: "Devtools Builders", icon: "🧰", hue: 150 },
  { name: "RegTech India", icon: "🛡", hue: 110 },
  { name: "Climate + AI", icon: "🌱", hue: 130 },
  { name: "Agri AI", icon: "🌾", hue: 60 },
  { name: "MLOps India", icon: "🔧", hue: 230 },
  { name: "Founders of One", icon: "👤", hue: 350 },
  { name: "Women in AI India", icon: "✨", hue: 330 },
  { name: "Hackathon Hunters", icon: "🏆", hue: 30 },
  { name: "AI Game Dev", icon: "🎮", hue: 280 },
  { name: "Browser Automation", icon: "🌐", hue: 190 },
  { name: "Mobile AI Apps", icon: "📱", hue: 100 },
  { name: "AI Tinkerers Mumbai", icon: "🔬", hue: 240 },
  { name: "AI Tinkerers Bangalore", icon: "🔬", hue: 170 },
  { name: "AI Tinkerers Delhi NCR", icon: "🔬", hue: 20 },
  { name: "AI Tinkerers Hyderabad", icon: "🔬", hue: 260 },
  { name: "Local LLM Runners", icon: "🖥", hue: 90 },
  { name: "Cursor Power India", icon: "⌘", hue: 200 },
  { name: "Lovable Pro Builders", icon: "💖", hue: 340 },
  { name: "AI Sales Stack", icon: "📈", hue: 0 },
  { name: "AI Recruiting Stack", icon: "🧲", hue: 14 },
  { name: "AI Marketing Ops", icon: "📣", hue: 290 },
  { name: "Crypto x AI", icon: "🪙", hue: 45 },
  { name: "Solo Devs India", icon: "🧑‍💻", hue: 210 },
  { name: "DevOps + AI", icon: "🚢", hue: 175 },
  { name: "AI for Customer Support", icon: "💬", hue: 195 },
  { name: "Knowledge Base Builders", icon: "📖", hue: 70 },
  { name: "AI Interview Coaches", icon: "🎤", hue: 115 },
  { name: "Indie iOS Builders", icon: "🍎", hue: 0 },
  { name: "AI Side-Project Club", icon: "🧪", hue: 305 },
  { name: "Made-in-India AI", icon: "🇮🇳", hue: 25 },
];
const COMMUNITY_DESC_TEMPLATES = [
  (name: string) => `${name} — workflows, tools, and case studies from builders who ship in this space. Weekly show-and-tell threads plus deep-dives on what actually works.`,
  (name: string) => `A working group for ${name.toLowerCase()}. Templates, benchmarks, hiring, and honest post-mortems from teams in production.`,
  (name: string) => `Everything ${name.toLowerCase()} — from first prototype to production scale. Peer feedback, weekly builds, and a jobs channel.`,
  (name: string) => `Builders sharing prompts, playbooks, and reference implementations across ${name.toLowerCase()}. India-first, English-speaking, no gate-keeping.`,
];
for (let i = 0; communities.length < 110; i++) {
  const s = COMMUNITY_SEED[i % COMMUNITY_SEED.length];
  const cycle = Math.floor(i / COMMUNITY_SEED.length);
  const name = cycle === 0 ? s.name : `${s.name} ${["Pro","Vol 2","Vol 3","Vol 4"][cycle - 1] ?? `Vol ${cycle + 1}`}`;
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  communities.push({
    id: String(communities.length + 1), slug, name, icon: s.icon,
    members: 400 + ((i * 467) % 9000),
    postsThisWeek: 8 + ((i * 17) % 150),
    description: COMMUNITY_DESC_TEMPLATES[i % COMMUNITY_DESC_TEMPLATES.length](s.name),
    hue: (s.hue + cycle * 47) % 360,
  });
}


// Workflows → 55 total
const WF_TEMPLATES = [
  { t: "Auto-tag {tool} signups in HubSpot", c: "Sales Ops", tools: ["n8n","HubSpot"] },
  { t: "Daily {industry} news digest to Slack", c: "Content", tools: ["n8n","Claude","Slack"] },
  { t: "{industry} lead enrichment pipeline", c: "Sales Ops", tools: ["n8n","Apollo","HubSpot"] },
  { t: "Inbox triage with {tool}", c: "Productivity", tools: ["n8n","Claude"] },
  { t: "Auto-generate {industry} reports weekly", c: "Productivity", tools: ["n8n","GPT-4","Notion"] },
  { t: "{tool} → Linear issue auto-creator", c: "Engineering", tools: ["n8n","Linear"] },
  { t: "Auto-respond to support tickets ({industry})", c: "Support", tools: ["n8n","Claude"] },
  { t: "{industry} pricing scraper → Slack diff", c: "Marketing", tools: ["Make","GPT-4","Slack"] },
  { t: "Twitter → blog draft for {industry}", c: "Content", tools: ["n8n","Claude","Notion"] },
  { t: "{tool} alert → WhatsApp escalation", c: "Productivity", tools: ["n8n","WhatsApp"] },
  { t: "Auto-label GitHub issues with {tool}", c: "Engineering", tools: ["GitHub","Claude"] },
  { t: "{industry} CSV → enriched DB rows", c: "Productivity", tools: ["n8n","GPT-4","Supabase"] },
  { t: "Daily journal prompt via {tool}", c: "Productivity", tools: ["n8n","Claude"] },
];
for (let i = workflows.length; i < 110; i++) {
  const tpl = WF_TEMPLATES[i % WF_TEMPLATES.length];
  const tool = pick(AI_TOOLS, i);
  const ind = pick(INDUSTRIES, i + 1);
  workflows.push({
    id: String(i + 1),
    title: tpl.t.replace("{tool}", tool).replace("{industry}", ind),
    cover: wfCover(i),
    tools: tpl.tools,
    category: tpl.c,
    description: `Production-ready ${tpl.c.toLowerCase()} workflow. Imports cleanly into n8n / Make.`,
    upvotes: 20 + ((i * 41) % 400),
    builderId: String(((i * 5) % 60) + 1),
  });
}

// Jobs → 55 total
const JOB_TITLES = ["AI Engineer","Senior AI Engineer","Vibe Coder","Lovable Specialist","Cursor Lead","Prompt Engineer","Automation Engineer","ML Engineer","AI Product Manager","AI Designer","AI Solutions Engineer","Founding AI Engineer","Workflow Consultant","RAG Engineer","Growth Engineer","AI Researcher","Full-stack AI Builder","DevRel — AI Tools","Support Engineer · AI","AI QA Lead"];
const COMPANIES: Array<[string, number]> = [["Zerodha",220],["Groww",140],["PhonePe",260],["Paytm",200],["BharatPe",340],["Dream11",110],["BookMyShow",10],["Ola",80],["Uber",0],["Flipkart",240],["Myntra",330],["Tata Digital",200],["Reliance Jio",90],["Wipro",160],["TCS",220],["HCL",180],["MakeMyTrip",30],["Goibibo",10],["Hike",300],["Sharechat",260],["Nykaa",340],["Lenskart",60],["Cult.fit",20],["Razorpay",220],["Cred",340],["Zomato",0],["Swiggy",20]];
const JOB_DESC_TEMPLATES: Array<(co: string, role: string, tool: string, ind: string) => string> = [
  (co, role, tool, ind) => `Own the ${tool} stack that powers ${co}'s ${ind.toLowerCase()} product. Ship weekly, work with a tight cross-functional pod, and measure impact in P99 latency and revenue.`,
  (co, role, _t, ind) => `Join a 6-person AI pod inside ${co} building the next generation of ${ind.toLowerCase()} experiences. You'll ship prototypes, run experiments, and take winners to production.`,
  (co, _r, tool, _i) => `Move at startup speed inside ${co}. No tickets, no sprints — just outcomes. You'll ship internal tools and customer-facing features weekly using ${tool} and modern AI tooling.`,
  (co, _r, tool, ind) => `Help ${co} bring AI to millions of ${ind.toLowerCase()} users across India. You'll build with ${tool}, own features end-to-end, and work closely with design and product leadership.`,
  (co, role, _t, _i) => `${co} is looking for a ${role.toLowerCase()} to prototype, ship, and iterate on AI features that reach real users on day one. Mentorship from senior ICs and a clear promotion track.`,
  (co, _r, tool, ind) => `Build production AI systems for ${co}'s ${ind.toLowerCase()} business. Focus on evals, reliability, and cost — not just prompts. Strong ${tool} experience preferred.`,
  (co, _r, _t, _i) => `Small team, big scope. You'll be one of the first AI hires at ${co}, shaping architecture, hiring bar, and the roadmap. Equity is meaningful.`,
];
function computeSalary(level: Job["level"], typ: Job["type"], i: number): string {
  if (typ === "Internship") {
    const min = 30 + ((i * 5) % 40);      // 30-70K/mo
    const max = min + 20;                  // +20K spread → cap ≤ 100K
    return `₹${min}-${max}K/mo`;
  }
  if (typ === "Contract" || typ === "Part-time") {
    const min = 1 + ((i * 3) % 4);         // 1-4L/mo
    return `₹${min}-${min + 2}L/mo`;
  }
  const bands: Record<Job["level"], [number, number]> = {
    Entry: [12, 25],
    Mid: [25, 50],
    Senior: [45, 80],
    Lead: [70, 120],
  };
  const [lo, hi] = bands[level];
  const min = lo + ((i * 3) % Math.max(1, Math.floor((hi - lo) / 2)));
  const max = Math.min(hi, min + Math.max(10, Math.floor((hi - lo) / 2)));
  return `₹${min}-${max}L`;
}
for (let i = jobs.length; i < 55; i++) {
  const [co, hue] = COMPANIES[i % COMPANIES.length];
  const lvl = pick<Job["level"]>(["Entry","Mid","Senior","Lead"], i);
  const typ = pick<Job["type"]>(["Full-time","Full-time","Full-time","Contract","Internship"], i);
  const rem = pick<Job["remote"]>(["Remote","Hybrid","On-site"], i);
  const role = pick(JOB_TITLES, i);
  const tool = pick(AI_TOOLS, i);
  const ind = pick(INDUSTRIES, i);
  const founding = /founding|lead/i.test(role) || lvl === "Lead";
  let salary = computeSalary(lvl, typ, i);
  if (founding && typ === "Full-time") salary = `${salary} + equity`;
  const desc = JOB_DESC_TEMPLATES[i % JOB_DESC_TEMPLATES.length](co, role, tool, ind);
  jobs.push({
    id: String(i + 1),
    title: role,
    company: co,
    logo: logo(co[0], hue),
    location: pick(LOCATIONS, i + 1),
    type: typ, remote: rem, level: lvl,
    salary,
    posted: `${1 + (i % 9)}${i % 2 ? "d" : "w"} ago`,
    description: desc,
    tools: pickN(AI_TOOLS, i, 3),
    industry: ind,
  });
}


// ============================================================
// NEW LIBRARY #1 — Tools Directory (50 entries)
// ============================================================
export type Tool = {
  id: string; slug: string; name: string; tagline: string; category: string;
  pricing: "Free" | "Freemium" | "Paid"; logoSlug?: string; logoBg: string;
  url: string; upvotes: number; description: string;
};
const TOOL_SEED: Array<Omit<Tool, "id" | "upvotes" | "description">> = [
  { slug: "lovable", name: "Lovable", tagline: "Build full-stack apps by chatting", category: "App Builder", pricing: "Freemium", logoBg: "#FF4D8D", url: "https://lovable.dev" },
  { slug: "cursor", name: "Cursor", tagline: "The AI code editor", category: "IDE", pricing: "Freemium", logoBg: "#0F0F0F", url: "https://cursor.com" },
  { slug: "bolt", name: "Bolt.new", tagline: "Prompt, run, edit & deploy", category: "App Builder", pricing: "Freemium", logoBg: "#0F0F0F", url: "https://bolt.new" },
  { slug: "v0", name: "v0 by Vercel", tagline: "Generative UI from prompts", category: "UI Builder", pricing: "Freemium", logoSlug: "vercel", logoBg: "#0F0F0F", url: "https://v0.dev" },
  { slug: "claude", name: "Claude", tagline: "Anthropic's flagship LLM", category: "LLM", pricing: "Freemium", logoSlug: "anthropic", logoBg: "#D97757", url: "https://claude.ai" },
  { slug: "chatgpt", name: "ChatGPT", tagline: "OpenAI's conversational AI", category: "LLM", pricing: "Freemium", logoSlug: "openai", logoBg: "#10A37F", url: "https://chat.openai.com" },
  { slug: "gemini", name: "Gemini", tagline: "Google's multimodal model", category: "LLM", pricing: "Freemium", logoSlug: "googlegemini", logoBg: "#4285F4", url: "https://gemini.google.com" },
  { slug: "perplexity", name: "Perplexity", tagline: "Answer engine with citations", category: "Search", pricing: "Freemium", logoSlug: "perplexity", logoBg: "#1FB8CD", url: "https://perplexity.ai" },
  { slug: "n8n", name: "n8n", tagline: "Self-hosted workflow automation", category: "Automation", pricing: "Freemium", logoSlug: "n8n", logoBg: "#EA4B71", url: "https://n8n.io" },
  { slug: "make", name: "Make", tagline: "Visual no-code automation", category: "Automation", pricing: "Freemium", logoSlug: "make", logoBg: "#6D00CC", url: "https://make.com" },
  { slug: "zapier", name: "Zapier", tagline: "Connect 6000+ apps", category: "Automation", pricing: "Freemium", logoSlug: "zapier", logoBg: "#FF4A00", url: "https://zapier.com" },
  { slug: "supabase", name: "Supabase", tagline: "Open-source Firebase alternative", category: "Backend", pricing: "Freemium", logoSlug: "supabase", logoBg: "#3ECF8E", url: "https://supabase.com" },
  { slug: "vercel", name: "Vercel", tagline: "Frontend cloud", category: "Hosting", pricing: "Freemium", logoSlug: "vercel", logoBg: "#0F0F0F", url: "https://vercel.com" },
  { slug: "stripe", name: "Stripe", tagline: "Payments infrastructure", category: "Payments", pricing: "Paid", logoSlug: "stripe", logoBg: "#635BFF", url: "https://stripe.com" },
  { slug: "midjourney", name: "Midjourney", tagline: "AI image generation", category: "Image", pricing: "Paid", logoBg: "#0F0F0F", url: "https://midjourney.com" },
  { slug: "replit", name: "Replit", tagline: "Code, run, deploy from browser", category: "IDE", pricing: "Freemium", logoSlug: "replit", logoBg: "#F26207", url: "https://replit.com" },
  { slug: "linear", name: "Linear", tagline: "Issue tracking for builders", category: "Productivity", pricing: "Freemium", logoSlug: "linear", logoBg: "#5E6AD2", url: "https://linear.app" },
  { slug: "notion", name: "Notion", tagline: "Connected workspace + AI", category: "Productivity", pricing: "Freemium", logoSlug: "notion", logoBg: "#FFFFFF", url: "https://notion.so" },
  { slug: "figma", name: "Figma", tagline: "Collaborative design", category: "Design", pricing: "Freemium", logoSlug: "figma", logoBg: "#F24E1E", url: "https://figma.com" },
  { slug: "github", name: "GitHub", tagline: "Where the world builds software", category: "DevTools", pricing: "Freemium", logoSlug: "github", logoBg: "#0F0F0F", url: "https://github.com" },
  { slug: "openrouter", name: "OpenRouter", tagline: "Unified LLM API", category: "API", pricing: "Paid", logoBg: "#0F0F0F", url: "https://openrouter.ai" },
  { slug: "replicate", name: "Replicate", tagline: "Run open-source models", category: "API", pricing: "Paid", logoSlug: "replicate", logoBg: "#0F0F0F", url: "https://replicate.com" },
  { slug: "huggingface", name: "Hugging Face", tagline: "Models, datasets, spaces", category: "ML", pricing: "Freemium", logoBg: "#FFD21E", url: "https://huggingface.co" },
  { slug: "elevenlabs", name: "ElevenLabs", tagline: "Realistic AI voice", category: "Voice", pricing: "Freemium", logoBg: "#0F0F0F", url: "https://elevenlabs.io" },
  { slug: "runway", name: "Runway", tagline: "AI video tools", category: "Video", pricing: "Freemium", logoBg: "#0F0F0F", url: "https://runwayml.com" },
  { slug: "pika", name: "Pika", tagline: "Generative video", category: "Video", pricing: "Freemium", logoBg: "#FF4D8D", url: "https://pika.art" },
  { slug: "windsurf", name: "Windsurf", tagline: "Agentic IDE by Codeium", category: "IDE", pricing: "Freemium", logoBg: "#00C2A8", url: "https://codeium.com/windsurf" },
  { slug: "warp", name: "Warp", tagline: "AI-powered terminal", category: "DevTools", pricing: "Freemium", logoBg: "#01A4FF", url: "https://warp.dev" },
  { slug: "raycast", name: "Raycast", tagline: "Productivity launcher + AI", category: "Productivity", pricing: "Freemium", logoBg: "#FF6363", url: "https://raycast.com" },
  { slug: "framer", name: "Framer", tagline: "Design + ship sites with AI", category: "Design", pricing: "Freemium", logoBg: "#0055FF", url: "https://framer.com" },
  { slug: "webflow", name: "Webflow", tagline: "Visual web development", category: "App Builder", pricing: "Freemium", logoBg: "#146EF5", url: "https://webflow.com" },
  { slug: "airtable", name: "Airtable", tagline: "Spreadsheet meets database + AI", category: "Productivity", pricing: "Freemium", logoBg: "#FCB400", url: "https://airtable.com" },
  { slug: "retool", name: "Retool", tagline: "Internal tools faster", category: "App Builder", pricing: "Freemium", logoBg: "#3D3D3D", url: "https://retool.com" },
  { slug: "langchain", name: "LangChain", tagline: "Framework for LLM apps", category: "Framework", pricing: "Free", logoBg: "#1C3D2E", url: "https://langchain.com" },
  { slug: "langgraph", name: "LangGraph", tagline: "Build stateful agents", category: "Framework", pricing: "Free", logoBg: "#1C3D2E", url: "https://langchain-ai.github.io/langgraph/" },
  { slug: "llamaindex", name: "LlamaIndex", tagline: "Data framework for LLMs", category: "Framework", pricing: "Free", logoBg: "#3E50FF", url: "https://llamaindex.ai" },
  { slug: "pinecone", name: "Pinecone", tagline: "Vector database", category: "Vector DB", pricing: "Freemium", logoBg: "#1B17F4", url: "https://pinecone.io" },
  { slug: "weaviate", name: "Weaviate", tagline: "Open vector database", category: "Vector DB", pricing: "Freemium", logoBg: "#3CB371", url: "https://weaviate.io" },
  { slug: "qdrant", name: "Qdrant", tagline: "High-perf vector search", category: "Vector DB", pricing: "Freemium", logoBg: "#DC382C", url: "https://qdrant.tech" },
  { slug: "modal", name: "Modal", tagline: "Serverless compute for AI", category: "Hosting", pricing: "Paid", logoBg: "#7FEE64", url: "https://modal.com" },
  { slug: "fal", name: "Fal", tagline: "Lightning-fast inference", category: "API", pricing: "Paid", logoBg: "#0F0F0F", url: "https://fal.ai" },
  { slug: "togetherai", name: "Together AI", tagline: "Train + run open LLMs", category: "API", pricing: "Paid", logoBg: "#1A56DB", url: "https://together.ai" },
  { slug: "groq", name: "Groq", tagline: "Fastest LLM inference", category: "API", pricing: "Freemium", logoBg: "#F55036", url: "https://groq.com" },
  { slug: "deepgram", name: "Deepgram", tagline: "Speech-to-text API", category: "Voice", pricing: "Freemium", logoBg: "#13EF93", url: "https://deepgram.com" },
  { slug: "assemblyai", name: "AssemblyAI", tagline: "Audio intelligence", category: "Voice", pricing: "Freemium", logoBg: "#2042F4", url: "https://assemblyai.com" },
  { slug: "twilio", name: "Twilio", tagline: "SMS, voice, WhatsApp APIs", category: "Comms", pricing: "Paid", logoBg: "#F22F46", url: "https://twilio.com" },
  { slug: "resend", name: "Resend", tagline: "Email for developers", category: "Comms", pricing: "Freemium", logoBg: "#0F0F0F", url: "https://resend.com" },
  { slug: "posthog", name: "PostHog", tagline: "Product analytics + AI", category: "Analytics", pricing: "Freemium", logoBg: "#F9BD2B", url: "https://posthog.com" },
  { slug: "plausible", name: "Plausible", tagline: "Lightweight web analytics", category: "Analytics", pricing: "Paid", logoBg: "#5850EC", url: "https://plausible.io" },
  { slug: "tailwindui", name: "Tailwind UI", tagline: "Beautiful UI kit", category: "Design", pricing: "Paid", logoBg: "#38BDF8", url: "https://tailwindui.com" },
];
export const tools: Tool[] = TOOL_SEED.map((s, i) => ({
  ...s, id: String(i + 1),
  upvotes: 50 + ((i * 71) % 900),
  description: `${s.tagline}. Used by thousands of vibe coders to ship faster.`,
}));
export const TOOL_CATEGORIES = Array.from(new Set(tools.map((t) => t.category)));

// ============================================================
// NEW LIBRARY #2 — Templates (50 entries)
// ============================================================
export type Template = {
  id: string; slug: string; title: string; cover: string; stack: string[];
  category: string; framework: string; price: string;
  downloads: number; description: string; builderId: string;
  is_demo?: boolean;
};

const TPL_SEED: ReadonlyArray<readonly [string, string, string, readonly string[]]> = [
  ["SaaS Starter — Auth + Stripe + Dashboard","SaaS","Lovable",["Lovable","Supabase","Stripe"]],
  ["AI Chat App with RAG","AI Chat","Lovable",["Lovable","Supabase","Claude"]],
  ["Customer Support Helpdesk","Support","Lovable",["Lovable","Supabase","GPT-4"]],
  ["Lead Generation Landing Page","Marketing","Lovable",["Lovable","Resend"]],
  ["B2B Directory + Profiles","Directory","Lovable",["Lovable","Supabase"]],
  ["AI Image Generator UI","AI","Lovable",["Lovable","Replicate"]],
  ["Cursor Rules — TypeScript","DevTools","Cursor",["Cursor"]],
  ["Cursor Rules — Lovable Project","DevTools","Cursor",["Cursor","Lovable"]],
  ["n8n — Lead Enrichment","Automation","n8n",["n8n","Apollo"]],
  ["n8n — Daily Newsletter","Content","n8n",["n8n","Claude"]],
  ["n8n — Slack Stand-up Bot","Productivity","n8n",["n8n","Slack"]],
  ["n8n — Stripe Failed Payment","Finance","n8n",["n8n","Stripe"]],
  ["EdTech LMS Starter","EdTech","Lovable",["Lovable","Supabase"]],
  ["Marketplace Two-sided","Marketplace","Lovable",["Lovable","Supabase","Stripe"]],
  ["Booking + Calendar App","Booking","Lovable",["Lovable","Supabase"]],
  ["Realtime Chat App","Chat","Lovable",["Lovable","Supabase"]],
  ["AI Resume Reviewer","HR","Lovable",["Lovable","Claude"]],
  ["AI Pitch Deck Generator","Startup","Lovable",["Lovable","GPT-4"]],
  ["Indie Founder Landing Kit","Marketing","Framer",["Framer"]],
  ["Cursor Rules — Next.js + Supabase","DevTools","Cursor",["Cursor"]],
  ["Lovable + Stripe Subscriptions","SaaS","Lovable",["Lovable","Stripe","Supabase"]],
  ["HealthTech Triage Form","HealthTech","Lovable",["Lovable","Claude"]],
  ["FinTech KYC Onboarding","FinTech","Lovable",["Lovable","Supabase"]],
  ["AI Voice Agent Starter","Voice","Lovable",["Lovable","ElevenLabs"]],
  ["Notion-style Notes App","Productivity","Lovable",["Lovable","Supabase"]],
  ["LegalTech Contract Review","Legal","Lovable",["Lovable","Claude"]],
  ["Social Network MVP","Social","Lovable",["Lovable","Supabase"]],
  ["AI Tutor for JEE/NEET","EdTech","Lovable",["Lovable","GPT-4"]],
  ["n8n — GitHub PR Auto Review","Engineering","n8n",["n8n","Claude","GitHub"]],
  ["n8n — Shopify Order → WhatsApp","E-Commerce","n8n",["n8n","WhatsApp"]],
  ["Bolt — Portfolio Site","Portfolio","Bolt",["Bolt"]],
  ["Bolt — Indie Hacker Blog","Content","Bolt",["Bolt"]],
  ["v0 — Pricing Page","Marketing","v0",["v0"]],
  ["v0 — Dashboard UI","UI","v0",["v0"]],
  ["Lovable — Job Board","Marketplace","Lovable",["Lovable","Supabase"]],
  ["Lovable — Community Forum","Community","Lovable",["Lovable","Supabase"]],
  ["Lovable — AI Newsletter Backend","Content","Lovable",["Lovable","Resend"]],
  ["Lovable — Event RSVP App","Events","Lovable",["Lovable","Supabase"]],
  ["Lovable — Donation Platform","Nonprofit","Lovable",["Lovable","Stripe"]],
  ["AI Survey + Insights","Research","Lovable",["Lovable","Claude"]],
  ["Local LLM Chat (Ollama)","AI Chat","Cursor",["Cursor","Replit"]],
  ["AI Sales Co-pilot","Sales","Lovable",["Lovable","Claude"]],
  ["AI Hiring Pipeline","HR","Lovable",["Lovable","GPT-4"]],
  ["Lovable — Indian GST Invoice","FinTech","Lovable",["Lovable","Supabase"]],
  ["Lovable — Quiz/Assessment App","EdTech","Lovable",["Lovable","Supabase"]],
  ["Lovable — Podcast Show Notes","Content","Lovable",["Lovable","Claude"]],
  ["Lovable — Affiliate Tracker","Marketing","Lovable",["Lovable","Supabase"]],
  ["n8n — RAG Customer Support","Support","n8n",["n8n","Claude"]],
  ["n8n — Daily Twitter Thread","Content","n8n",["n8n","Claude"]],
  ["Lovable — AI Habit Tracker","Productivity","Lovable",["Lovable","Supabase"]],
];
export const templates: Template[] = TPL_SEED.map(([title, category, framework, stack], i) => ({
  id: String(i + 1),
  slug: title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""),
  title,
  cover: unsplashCover(i),
  stack: [...stack],
  category,
  framework,
  price: i % 5 === 0 ? "₹999" : "Free",
  downloads: 80 + ((i * 137) % 4500),
  description: `Production-ready ${category.toLowerCase()} template. Fork, customise, and deploy in minutes.`,
  builderId: String(((i * 7) % 60) + 1),
}));
export const TEMPLATE_CATEGORIES = Array.from(new Set(templates.map((t) => t.category)));
export const TEMPLATE_FRAMEWORKS = Array.from(new Set(templates.map((t) => t.framework)));

// ============================================================
// PROGRAMMATIC PADDING — pad prompts / tools / templates to 110
// ============================================================
const PROMPT_TEMPLATES = [
  { t: "{industry} Onboarding Email Generator", c: "Marketing", m: "GPT-4o" },
  { t: "{industry} Sales Discovery Script", c: "Marketing", m: "Claude" },
  { t: "{tool} Best-Practices Auditor", c: "Engineering", m: "Claude" },
  { t: "{industry} Investor Update Drafter", c: "Startup", m: "Claude" },
  { t: "{tool} → Notion Spec Converter", c: "Engineering", m: "GPT-4o" },
  { t: "{industry} Persona Synthesizer", c: "Research", m: "Claude" },
  { t: "{industry} Customer Support Macro Pack", c: "Support", m: "Claude" },
  { t: "{tool} Prompt Library for {industry}", c: "Automation", m: "GPT-4o" },
  { t: "{industry} Landing Page Copywriter", c: "Marketing", m: "GPT-4o" },
  { t: "{tool} Bug Triage Assistant", c: "Engineering", m: "Claude" },
  { t: "{industry} OKR Generator (Q-by-Q)", c: "Startup", m: "Claude" },
  { t: "{industry} User Interview Question Bank", c: "Research", m: "Claude" },
];
for (let i = prompts.length; i < 110; i++) {
  const tpl = PROMPT_TEMPLATES[i % PROMPT_TEMPLATES.length];
  const tool = pick(AI_TOOLS, i);
  const ind = pick(INDUSTRIES, i + 2);
  const title = tpl.t.replace("{tool}", tool).replace("{industry}", ind);
  prompts.push({
    id: String(i + 1), title, model: tpl.m, category: tpl.c,
    preview: `Battle-tested ${tpl.c.toLowerCase()} prompt for ${ind} teams using ${tool}. Copy and ship.`,
    full: `You are an expert in ${ind}. ${title}.\n\nContext: {{context}}\nTool: ${tool}\n\nReturn a clear, actionable result.`,
    upvotes: 30 + ((i * 89) % 700),
    copyCount: 50 + ((i * 173) % 4950),
    builderId: String(((i * 7) % 60) + 1),
  });

}

// Tools → 110 total (clone seed with variant suffixes)
{
  const baseLen = tools.length;
  for (let i = baseLen; i < 110; i++) {
    const src = TOOL_SEED[(i - baseLen) % TOOL_SEED.length];
    const variant = Math.floor((i - baseLen) / TOOL_SEED.length) + 2;
    tools.push({
      ...src,
      id: String(i + 1),
      slug: `${src.slug}-v${variant}`,
      name: `${src.name} ${["Pro","Plus","Studio","Labs","Cloud"][variant - 2] ?? `v${variant}`}`,
      upvotes: 50 + ((i * 71) % 900),
      description: `${src.tagline}. Used by thousands of vibe coders to ship faster.`,
    });
  }
}

// Templates → 110 total (clone seed)
{
  const baseLen = templates.length;
  for (let i = baseLen; i < 110; i++) {
    const src = TPL_SEED[(i - baseLen) % TPL_SEED.length];
    const [title, category, framework, stack] = src;
    const variant = Math.floor((i - baseLen) / TPL_SEED.length) + 2;
    const newTitle = `${title} — v${variant}`;
    templates.push({
      id: String(i + 1),
      slug: newTitle.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""),
      title: newTitle,
      cover: unsplashCover(i),
      stack: [...stack],
      category,
      framework,
      price: i % 5 === 0 ? "₹999" : "Free",
      downloads: 80 + ((i * 137) % 4500),
      description: `Production-ready ${category.toLowerCase()} template. Fork, customise, and deploy in minutes.`,
      builderId: String(((i * 7) % 60) + 1),
    });
  }
}


// ============================================================
// DEMO FLAGS + UNSPLASH THUMBNAILS
// All seeded records are demo. Services also get professional
// Unsplash thumbnails (templates already do above).
// ============================================================
services.forEach((s, i) => {
  s.cover = unsplashCover(i + 3);
  s.is_demo = true;
});
projects.forEach((p) => { p.is_demo = true; });
jobs.forEach((j) => { j.is_demo = true; });
templates.forEach((t) => { t.is_demo = true; });




// ============================================================
// USER-SUBMITTED ENTRIES (localStorage, client-only)
// ============================================================
type Submission =
  | { kind: "project"; data: Project }
  | { kind: "service"; data: Service }
  | { kind: "workflow"; data: Workflow }
  | { kind: "prompt"; data: Prompt }
  | { kind: "job"; data: Job }
  | { kind: "template"; data: Template }
  | { kind: "tool"; data: Tool }
  | { kind: "community"; data: Community }
  | { kind: "builder"; data: Builder }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  | { kind: "blog"; data: any };

const STORAGE_KEY = "vc:submissions";

export function loadSubmissions(): Submission[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}
export function saveSubmission(s: Submission) {
  if (typeof window === "undefined") return;
  const all = loadSubmissions();
  all.push(s);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

export const getBuilder = (id: string) => builders.find((b) => b.id === id) ?? builders[0];
export const getBuilderByUsername = (u: string) => builders.find((b) => b.username === u);
export const getTool = (slug: string) => tools.find((t) => t.slug === slug);
export const getTemplate = (slug: string) => templates.find((t) => t.slug === slug);

// Merge user submissions (client-only) with seeded data. Newest first.
function subsOf<T>(kind: Submission["kind"]): T[] {
  return loadSubmissions().filter((s) => s.kind === kind).map((s) => s.data as T);
}
export const allJobs = (): Job[] => [...subsOf<Job>("job"), ...jobs];
export const allProjects = (): Project[] => [...subsOf<Project>("project"), ...projects];
export const allWorkflows = (): Workflow[] => [...subsOf<Workflow>("workflow"), ...workflows];
export const allPrompts = (): Prompt[] => [...subsOf<Prompt>("prompt"), ...prompts];
export const allServices = (): Service[] => [...subsOf<Service>("service"), ...services];
export const allCommunities = (): Community[] => [...subsOf<Community>("community"), ...communities];
export const allTools = (): Tool[] => [...subsOf<Tool>("tool"), ...tools];
export const allTemplates = (): Template[] => [...subsOf<Template>("template"), ...templates];
export const allBuilders = (): Builder[] => [...subsOf<Builder>("builder"), ...builders];



