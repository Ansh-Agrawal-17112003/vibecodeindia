// Curated Unsplash photos for workflow thumbnails — tech / automation / editorial.
// Each ID is a distinct photo so cards on the workflow library don't repeat.
const PHOTO_IDS = [
  "1518770660439-4636190af475", // circuit board
  "1526374965328-7f61d4dc18c5", // matrix code
  "1550751827-4bd374c3f58b", // server rack
  "1551288049-bebda4e38f71", // laptop analytics
  "1517245386807-bb43f82c33c4", // neon lights code
  "1573164713714-d95e436ab8d6", // programmer screens
  "1504384308090-c894fdcc538d", // desk keyboard
  "1516110833967-0b5716ca1387", // network cables
  "1587620962725-abab7fe55159", // colorful code
  "1461749280684-dccba630e2f6", // syntax code
  "1555949963-ff9fe0c870eb", // circuit macro
  "1518432031352-d6fc5c10da5a", // dashboard laptop
  "1519389950473-47ba0277781c", // team laptops
  "1498050108023-c5249f4df085", // macbook code
  "1517430816045-df4b7de11d1d", // typewriter
  "1531403009284-440f080d1e12", // marketing analytics
  "1460925895917-afdab827c52f", // analytics dashboard
  "1454165804606-c3d57bc86b40", // computer setup
  "1522252234503-e356532cafd5", // laptop code night
  "1547658719-da2b51169166", // paper workflow
  "1517420704952-d9f39e95b43e", // pipeline lights
  "1526379095098-d400fd0bf935", // servers glow
  "1581091226825-a6a2a5aee158", // ai woman screen
  "1607799279861-4dd421887fb3", // healthcare tech
  "1563986768609-322da13575f3", // ai neural
  "1553877522-43269d4ea984", // finance chart
  "1556761175-5973dc0f32e7", // office collab
  "1552664730-d307ca884978", // meeting dashboard
  "1519389950473-47ba0277781c", // fallback tail
  "1611175694989-4870fafa4494", // whatsapp phone
  "1620712943543-bcc4688e7485", // ai abstract
  "1516321318423-f06f85e504b3", // spreadsheet
  "1580894732444-8ecded7900cd", // podcast mic
  "1522199755839-a2bacb67c546", // notebook plan
  "1512314889357-e157c22f938d", // devops board
  "1587560699334-cc4ff634909a", // fintech
  "1581094794329-c8112a89af12", // whisper voice
  "1521737604893-d14cc237f11d", // team laptops top
  "1483058712412-4245e9b90334", // desk workspace
  "1517694712202-14dd9538aa97", // clean code
];

export function wfCover(i: number): string {
  const id = PHOTO_IDS[i % PHOTO_IDS.length];
  return `https://images.unsplash.com/photo-${id}?w=1200&h=675&fit=crop&auto=format&q=80`;
}
