import { useEffect, useState, useCallback } from "react";

const KEY = "vc:saved-jobs";
const EVT = "vc:saved-jobs:changed";

export function getSavedJobs(): string[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; }
}
function write(ids: string[]) {
  localStorage.setItem(KEY, JSON.stringify(ids));
  window.dispatchEvent(new Event(EVT));
}
export function toggleSavedJob(id: string) {
  const cur = getSavedJobs();
  const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
  write(next);
  return next.includes(id);
}
export function isJobSaved(id: string) { return getSavedJobs().includes(id); }

export function useSavedJobs() {
  const [ids, setIds] = useState<string[]>([]);
  useEffect(() => {
    setIds(getSavedJobs());
    const h = () => setIds(getSavedJobs());
    window.addEventListener(EVT, h);
    window.addEventListener("storage", h);
    return () => { window.removeEventListener(EVT, h); window.removeEventListener("storage", h); };
  }, []);
  const toggle = useCallback((id: string) => toggleSavedJob(id), []);
  return { ids, count: ids.length, toggle, isSaved: (id: string) => ids.includes(id) };
}
