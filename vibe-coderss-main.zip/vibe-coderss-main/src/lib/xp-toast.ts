import { toast } from "sonner";

/**
 * Fires a small "+N XP ⚡" toast for a user action. Deliberately quick so
 * it doesn't stack with regular success toasts.
 */
export function xpToast(amount: number) {
  toast(`+${amount} XP`, {
    duration: 1800,
    className: "xp-toast",
    icon: "⚡",
    unstyled: false,
  });
}

// Track first-copy XP per prompt so users only get the bonus once.
const copiedPromptIds = new Set<string>();

export function xpToastFirstCopy(id: string, amount = 5) {
  if (copiedPromptIds.has(id)) return;
  copiedPromptIds.add(id);
  xpToast(amount);
}
