import { supabase } from "@/integrations/supabase/client";

export type Lecture = {
  id: string;
  community_id: string;
  channel_id: string | null;
  uploader_id: string;
  title: string;
  description: string | null;
  video_url: string | null;
  thumbnail_url: string | null;
  duration_sec: number | null;
  tags: string[];
  is_published: boolean;
  view_count: number;
  created_at: string;
};

const BUCKET = "community-lectures";

/** List published lectures for a community, newest first. */
export async function listLectures(communityId: string): Promise<Lecture[]> {
  const { data, error } = await supabase
    .from("community_lectures" as any)
    .select("*")
    .eq("community_id", communityId)
    .eq("is_published", true)
    .order("created_at", { ascending: false })
    .limit(200);
  if (error) throw error;
  return (data ?? []) as unknown as Lecture[];
}

export async function getLecture(id: string): Promise<Lecture | null> {
  const { data, error } = await supabase
    .from("community_lectures" as any)
    .select("*")
    .eq("id", id)
    .maybeSingle();
  if (error) throw error;
  return (data as unknown as Lecture) ?? null;
}

/** Create a draft (unpublished) row so we know the lecture id before upload. */
export async function createDraftLecture(input: {
  community_id: string;
  uploader_id: string;
  title: string;
  description?: string | null;
  tags?: string[];
}): Promise<Lecture> {
  const { data, error } = await (supabase.from("community_lectures" as any) as any)
    .insert({
      community_id: input.community_id,
      uploader_id: input.uploader_id,
      title: input.title,
      description: input.description ?? null,
      tags: input.tags ?? [],
      is_published: false,
    })
    .select("*")
    .single();
  if (error) throw error;
  return data as unknown as Lecture;
}

export async function updateLecture(id: string, patch: Partial<Lecture>): Promise<void> {
  const { error } = await (supabase.from("community_lectures" as any) as any)
    .update(patch)
    .eq("id", id);
  if (error) throw error;
}

export async function deleteLecture(id: string): Promise<void> {
  const { error } = await supabase.from("community_lectures" as any).delete().eq("id", id);
  if (error) throw error;
}

/** Upload the video file to the private bucket. Path: {community_id}/{lecture_id}/{filename} */
export async function uploadLectureVideo(params: {
  communityId: string;
  lectureId: string;
  file: File;
  onProgress?: (pct: number) => void;
}): Promise<string> {
  const safeName = params.file.name.replace(/[^a-z0-9.\-_]/gi, "_");
  const path = `${params.communityId}/${params.lectureId}/${Date.now()}-${safeName}`;
  // supabase-js v2 uploads don't stream progress; kick a synthetic 100% on completion.
  const { error } = await supabase.storage.from(BUCKET).upload(path, params.file, {
    contentType: params.file.type,
    upsert: false,
  });
  if (error) throw error;
  params.onProgress?.(100);
  return path;
}

/** Upload an image blob for the thumbnail. */
export async function uploadLectureThumbnail(params: {
  communityId: string;
  lectureId: string;
  blob: Blob;
}): Promise<string> {
  const path = `${params.communityId}/${params.lectureId}/thumb-${Date.now()}.jpg`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, params.blob, {
    contentType: "image/jpeg",
    upsert: true,
  });
  if (error) throw error;
  return path;
}

/** Get a short-lived signed URL for a private bucket path. */
export async function getSignedUrl(path: string, expiresIn = 3600): Promise<string> {
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, expiresIn);
  if (error) throw error;
  return data.signedUrl;
}

/** Extract a poster frame from a video File. */
export async function captureThumbnail(file: File, atSec = 2): Promise<{ blob: Blob; durationSec: number }> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement("video");
    v.preload = "metadata";
    v.muted = true;
    v.playsInline = true;
    v.src = url;

    const cleanup = () => URL.revokeObjectURL(url);
    let seeked = false;

    v.onloadedmetadata = () => {
      const target = Math.min(atSec, Math.max(0, (v.duration || 0) - 0.1));
      try { v.currentTime = target; } catch (e) { reject(e); cleanup(); }
    };
    v.onseeked = () => {
      if (seeked) return;
      seeked = true;
      const w = v.videoWidth || 1280;
      const h = v.videoHeight || 720;
      const canvas = document.createElement("canvas");
      canvas.width = Math.min(w, 1280);
      canvas.height = Math.round(canvas.width * (h / w));
      const ctx = canvas.getContext("2d");
      if (!ctx) { reject(new Error("canvas not supported")); cleanup(); return; }
      ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
      canvas.toBlob(
        (blob) => {
          cleanup();
          if (!blob) return reject(new Error("thumbnail encode failed"));
          resolve({ blob, durationSec: Math.round(v.duration || 0) });
        },
        "image/jpeg",
        0.82,
      );
    };
    v.onerror = () => { cleanup(); reject(new Error("could not read video")); };
  });
}

/** Upsert view progress for the current user on a lecture. */
export async function recordLectureProgress(params: {
  lectureId: string;
  viewerId: string;
  watchedSec: number;
  lastPositionSec: number;
}): Promise<void> {
  await (supabase.from("lecture_views" as any) as any).upsert(
    {
      lecture_id: params.lectureId,
      viewer_id: params.viewerId,
      watched_sec: params.watchedSec,
      last_position_sec: params.lastPositionSec,
    },
    { onConflict: "lecture_id,viewer_id" },
  );
}

/** Increment view count once per session for a lecture. */
export async function bumpLectureViewCount(lectureId: string): Promise<void> {
  const key = `vc:lecture-viewed:${lectureId}`;
  if (typeof window !== "undefined" && sessionStorage.getItem(key)) return;
  const { data } = await supabase
    .from("community_lectures" as any)
    .select("view_count")
    .eq("id", lectureId)
    .maybeSingle();
  const current = ((data as any)?.view_count as number | undefined) ?? 0;
  await (supabase.from("community_lectures" as any) as any)
    .update({ view_count: current + 1 })
    .eq("id", lectureId);
  if (typeof window !== "undefined") sessionStorage.setItem(key, "1");
}
