// Curated Unsplash photos for community thumbnails — editorial, professional.
const u = (id: string) => `https://images.unsplash.com/photo-${id}?w=1200&h=675&fit=crop&auto=format&q=80`;

export const COMMUNITY_COVERS: Record<string, string> = {
  lovable: u("1522542550221-31fd19575a2d"),           // coral hearts / warm workspace
  cursor: u("1517245386807-bb43f82c33c4"),            // neon code terminal
  claude: u("1509228468518-180dd4864904"),            // brain / paper texture warmth
  openai: u("1620712943543-bcc4688e7485"),            // abstract AI green/gold
  n8n: u("1558494949-ef010cbdcc31"),                  // flowing violet nodes
  "healthcare-ai": u("1576091160399-112ba8d25d1d"),   // teal medical tech
  "fintech-ai": u("1553877522-43269d4ea984"),         // finance charts gold
  "student-builders": u("1522202176988-66273c2fd55f"),// students collaborating
  "indie-founders": u("1519389950473-47ba0277781c"),  // team laptops orange light
  "open-source-ai": u("1451187580459-43490279c0fa"),  // globe network lines
};

// Fallback cycles through all covers for unknown slugs so every card has a unique image.
const COVER_LIST = Object.values(COMMUNITY_COVERS);

export function coverForSlug(slug: string): string {
  if (COMMUNITY_COVERS[slug]) return COMMUNITY_COVERS[slug];
  let hash = 0;
  for (let i = 0; i < slug.length; i++) hash = (hash * 31 + slug.charCodeAt(i)) >>> 0;
  return COVER_LIST[hash % COVER_LIST.length];
}
