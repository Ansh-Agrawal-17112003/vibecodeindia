import { supabase } from "@/integrations/supabase/client";
import { updatePostFeedScore } from "@/lib/feed-algorithm";

export type PostKind = "text" | "image" | "project" | "repost" | "job" | "service" | "community";

export type FeedAuthor = {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  accent_color?: string | null;
  is_og_member?: boolean | null;
  og_number?: number | null;
  is_verified?: boolean | null;
  subscription_plan?: string | null;
  is_boosted?: boolean | null;
};

export type RefEntity = {
  table: "jobs" | "services" | "communities";
  id: string;
  title: string;
  cover: string | null;
  slug?: string | null;
  subtitle?: string | null;
};

export type ReactionType = "like" | "fire" | "celebrate" | "insightful";

export const REACTION_TYPES: ReactionType[] = ["like", "fire", "celebrate", "insightful"];

export const REACTION_META: Record<ReactionType, { emoji: string; label: string }> = {
  like:       { emoji: "👍", label: "Like" },
  fire:       { emoji: "🔥", label: "Fire" },
  celebrate:  { emoji: "🎉", label: "Celebrate" },
  insightful: { emoji: "💡", label: "Insightful" },
};

export type ReactionCounts = Record<ReactionType, number>;

export const EMPTY_REACTIONS: ReactionCounts = { like: 0, fire: 0, celebrate: 0, insightful: 0 };

export type LivePost = {
  id: string;
  author_id: string;
  kind: PostKind;
  body: string | null;
  image_urls: string[];
  project_id: string | null;
  repost_of: string | null;
  ref_table: string | null;
  ref_id: string | null;
  like_count: number;
  comment_count: number;
  repost_count: number;
  reaction_counts: ReactionCounts;
  created_at: string;
  edited_at?: string | null;
  author: FeedAuthor | null;
  project?: { id: string; title: string; cover_image_url: string | null } | null;
  ref_entity?: RefEntity | null;
  reposted?: LivePost | null;
  liked_by_me?: boolean;
  my_reaction?: ReactionType | null;
  bookmarked_by_me?: boolean;
};


export type LiveComment = {
  id: string;
  post_id: string;
  author_id: string;
  body: string;
  created_at: string;
  edited_at?: string | null;
  parent_comment_id: string | null;
  author: FeedAuthor | null;
};


const PROFILE_SELECT = "id, username, display_name, avatar_url, accent_color, is_og_member, og_number, is_verified, subscription_plan, is_boosted";
const POST_SELECT = `id, author_id, kind, body, image_urls, project_id, repost_of, ref_table, ref_id, like_count, comment_count, repost_count, reaction_counts, created_at, edited_at,
       author:profiles!posts_author_id_fkey(${PROFILE_SELECT}),
       project:projects(id, title, cover_image_url)`;


export type FeedSort = "latest" | "top";

async function attachRefEntities(posts: LivePost[]): Promise<void> {
  const byTable: Record<"jobs" | "services" | "communities", string[]> = { jobs: [], services: [], communities: [] };
  for (const p of posts) {
    if (p.ref_table && p.ref_id && (p.ref_table === "jobs" || p.ref_table === "services" || p.ref_table === "communities")) {
      byTable[p.ref_table].push(p.ref_id);
    }
  }
  const refMap = new Map<string, RefEntity>();
  const jobs = Array.from(new Set(byTable.jobs));
  const services = Array.from(new Set(byTable.services));
  const communities = Array.from(new Set(byTable.communities));

  await Promise.all([
    jobs.length
      ? (supabase.from("jobs") as any).select("id, title, location, job_type").in("id", jobs).then(({ data }: any) => {
          for (const r of (data ?? []) as any[]) {
            refMap.set(`jobs:${r.id}`, { table: "jobs", id: r.id, title: r.title, cover: null, subtitle: [r.location, r.job_type].filter(Boolean).join(" · ") });
          }
        })
      : Promise.resolve(),
    services.length
      ? (supabase.from("services") as any).select("id, title, cover_image_url, category").in("id", services).then(({ data }: any) => {
          for (const r of (data ?? []) as any[]) {
            refMap.set(`services:${r.id}`, { table: "services", id: r.id, title: r.title, cover: r.cover_image_url ?? null, subtitle: r.category ?? null });
          }
        })
      : Promise.resolve(),
    communities.length
      ? (supabase.from("communities") as any).select("id, slug, name, icon, banner_url, description").in("id", communities).then(({ data }: any) => {
          for (const r of (data ?? []) as any[]) {
            refMap.set(`communities:${r.id}`, { table: "communities", id: r.id, title: r.name, cover: r.banner_url ?? null, slug: r.slug, subtitle: r.description ?? null });
          }
        })
      : Promise.resolve(),
  ]);

  for (const p of posts) {
    if (p.ref_table && p.ref_id) {
      p.ref_entity = refMap.get(`${p.ref_table}:${p.ref_id}`) ?? null;
    }
  }
}

export async function listFeed(limit = 30, sort: FeedSort = "latest"): Promise<LivePost[]> {
  let q = (supabase.from("posts") as any).select(POST_SELECT).eq("is_deleted", false);
  if (sort === "top") {
    // Top of the last 24h — LinkedIn-style engagement ordering.
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    q = q.gte("created_at", since).order("like_count", { ascending: false }).order("comment_count", { ascending: false });
  } else {
    q = q.order("created_at", { ascending: false });
  }
  const { data: rows, error } = await q.limit(limit);
  if (error) throw error;
  const posts = (rows as LivePost[] | null) ?? [];

  // Resolve reposted parents in a second query.
  const repostIds = Array.from(new Set(posts.map((p) => p.repost_of).filter((v): v is string => !!v)));
  if (repostIds.length) {
    const { data: parents } = await (supabase.from("posts") as any).select(POST_SELECT).in("id", repostIds);
    const map = new Map<string, LivePost>();
    for (const parent of (parents as LivePost[] | null) ?? []) map.set(parent.id, parent);
    posts.forEach((p) => { if (p.repost_of) p.reposted = map.get(p.repost_of) ?? null; });
  }

  const allToResolve: LivePost[] = [...posts, ...posts.map((p) => p.reposted).filter((v): v is LivePost => !!v)];
  await attachRefEntities(allToResolve);

  // Normalize reaction_counts on every post (in case the column was null in older rows).
  posts.forEach((p) => { p.reaction_counts = normalizeReactionCounts(p.reaction_counts); });

  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;

  // For-you ranking: blend cached feed score + follow bump + plan/boost weight.
  // Preserve chronological for very fresh posts (< 20 min) so live feed still feels live.
  if (sort === "latest" && posts.length) {
    const ids = posts.map((p) => p.id);
    const [{ data: scores }, followingIds] = await Promise.all([
      (supabase.from("post_feed_scores") as any).select("post_id, total_score").in("post_id", ids),
      uid
        ? (supabase.from("follows") as any).select("following_id").eq("follower_id", uid).then(({ data }: any) => new Set((data ?? []).map((f: any) => f.following_id)))
        : Promise.resolve(new Set<string>()),
    ]);
    const scoreMap = new Map<string, number>();
    for (const s of (scores as { post_id: string; total_score: number }[] | null) ?? []) {
      scoreMap.set(s.post_id, s.total_score ?? 0);
    }
    const now = Date.now();
    const rank = (p: LivePost): number => {
      let s = scoreMap.get(p.id) ?? 0;
      if (p.author && (followingIds as Set<string>).has(p.author_id)) s += 30;
      const plan = p.author?.subscription_plan;
      if (plan === "og_pro") s += 15;
      else if (plan === "pro") s += 8;
      if (p.author?.is_boosted) s += 40;
      return s;
    };
    // Split into "fresh chronological head" (< 20 min) and "ranked tail".
    const FRESH_MS = 20 * 60 * 1000;
    const fresh: LivePost[] = [];
    const rest: LivePost[] = [];
    for (const p of posts) {
      const age = now - new Date(p.created_at).getTime();
      if (age < FRESH_MS) fresh.push(p);
      else rest.push(p);
    }
    rest.sort((a, b) => rank(b) - rank(a));
    posts.splice(0, posts.length, ...fresh, ...rest);
  }

  if (uid && posts.length) {
    const ids = posts.map((p) => p.id);
    const [{ data: myReactions }, { data: myBookmarks }] = await Promise.all([
      (supabase.from("post_reactions") as any).select("post_id, reaction_type").eq("user_id", uid).in("post_id", ids),
      (supabase.from("post_bookmarks") as any).select("post_id").eq("user_id", uid).in("post_id", ids),
    ]);
    const reactionMap = new Map<string, ReactionType>();
    for (const r of (myReactions as { post_id: string; reaction_type: ReactionType }[] | null) ?? []) {
      reactionMap.set(r.post_id, r.reaction_type);
    }
    const savedSet = new Set(((myBookmarks as { post_id: string }[]) ?? []).map((r) => r.post_id));
    posts.forEach((p) => {
      p.my_reaction = reactionMap.get(p.id) ?? null;
      p.liked_by_me = !!p.my_reaction;
      p.bookmarked_by_me = savedSet.has(p.id);
    });
  }

  return posts;
}

export function normalizeReactionCounts(input: any): ReactionCounts {
  const src = input && typeof input === "object" ? input : {};
  return {
    like:       Number(src.like)       || 0,
    fire:       Number(src.fire)       || 0,
    celebrate:  Number(src.celebrate)  || 0,
    insightful: Number(src.insightful) || 0,
  };
}


export async function listUserPosts(userId: string, limit = 20): Promise<LivePost[]> {
  const { data, error } = await (supabase.from("posts") as any)
    .select(POST_SELECT)
    .eq("author_id", userId)
    .eq("is_deleted", false)
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  const posts = (data as LivePost[] | null) ?? [];
  posts.forEach((p) => { p.reaction_counts = normalizeReactionCounts(p.reaction_counts); });
  await attachRefEntities(posts);
  return posts;
}


export async function listMyProjects() {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) return [];
  const { data, error } = await (supabase.from("projects") as any)
    .select("id, title, cover_image_url")
    .eq("builder_id", uid)
    .order("created_at", { ascending: false })
    .limit(20);
  if (error) return [];
  return (data as { id: string; title: string; cover_image_url: string | null }[]) ?? [];
}

export async function createPost(input: {
  kind: PostKind;
  body?: string;
  imageUrls?: string[];
  projectId?: string | null;
}): Promise<LivePost> {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) throw new Error("Not signed in");

  const body = (input.body ?? "").trim().slice(0, 2000);
  const imageUrls = (input.imageUrls ?? []).slice(0, 4);
  const kind: PostKind = input.projectId ? "project" : imageUrls.length ? "image" : "text";

  const { data, error } = await (supabase.from("posts") as any)
    .insert({
      author_id: uid,
      kind,
      body: body || null,
      image_urls: imageUrls,
      project_id: input.projectId ?? null,
    })
    .select("id")
    .single();
  if (error) throw error;
  return { id: (data as { id: string }).id } as LivePost;
}

export async function repostPost(postId: string, body?: string) {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) throw new Error("Not signed in");
  const { error } = await (supabase.from("posts") as any).insert({
    author_id: uid,
    kind: "repost",
    body: body?.trim() || null,
    repost_of: postId,
  });
  if (error) throw error;
  void updatePostFeedScore(postId);
}

/**
 * Set (or clear) the current user's reaction to a post.
 *  - next=null     → remove reaction
 *  - next=<type>   → insert or change to that reaction
 * Passing the same reaction that already exists is a no-op.
 */
export async function setReaction(postId: string, next: ReactionType | null) {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) throw new Error("Not signed in");

  if (next === null) {
    const { error } = await (supabase.from("post_reactions") as any)
      .delete().eq("post_id", postId).eq("user_id", uid);
    if (error) throw error;
    void updatePostFeedScore(postId);
    return;
  }

  const { error } = await (supabase.from("post_reactions") as any)
    .upsert({ post_id: postId, user_id: uid, reaction_type: next }, { onConflict: "post_id,user_id" });
  if (error) throw error;
  void updatePostFeedScore(postId);
}

/** Backwards-compat wrapper: toggle the default 'like' reaction. */
export async function toggleLike(postId: string, liked: boolean) {
  await setReaction(postId, liked ? null : "like");
}


export async function deletePost(postId: string) {
  const { error } = await (supabase.from("posts") as any)
    .update({ is_deleted: true })
    .eq("id", postId);
  if (error) throw error;
}

export async function listComments(postId: string): Promise<LiveComment[]> {
  const { data, error } = await (supabase.from("post_comments") as any)
    .select(`id, post_id, author_id, body, created_at, edited_at, parent_comment_id, author:profiles!post_comments_author_id_fkey(${PROFILE_SELECT})`)
    .eq("post_id", postId)
    .order("created_at", { ascending: true })
    .limit(400);
  if (error) throw error;
  return (data as LiveComment[] | null) ?? [];
}

export async function addComment(postId: string, body: string, parentCommentId: string | null = null) {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) throw new Error("Not signed in");
  const clean = body.trim().slice(0, 1000);
  if (!clean) throw new Error("Comment is empty");
  const { data, error } = await (supabase.from("post_comments") as any)
    .insert({ post_id: postId, author_id: uid, body: clean, parent_comment_id: parentCommentId })
    .select(`id, post_id, author_id, body, created_at, edited_at, parent_comment_id, author:profiles!post_comments_author_id_fkey(${PROFILE_SELECT})`)
    .single();
  if (error) throw error;
  void updatePostFeedScore(postId);
  return data as LiveComment;
}

export async function editComment(commentId: string, body: string) {
  const clean = body.trim().slice(0, 1000);
  if (!clean) throw new Error("Comment is empty");
  const { error } = await (supabase.from("post_comments") as any)
    .update({ body: clean }).eq("id", commentId);
  if (error) throw error;
}

export async function deleteComment(commentId: string) {
  const { error } = await (supabase.from("post_comments") as any)
    .delete().eq("id", commentId);
  if (error) throw error;
}


export async function uploadPostImage(file: File): Promise<string> {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) throw new Error("Not signed in");
  const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
  const path = `${uid}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from("post-images").upload(path, file, {
    contentType: file.type || "image/jpeg",
    upsert: false,
  });
  if (error) throw error;
  // Bucket is private — return a long-lived signed URL for now.
  const { data: signed, error: signErr } = await supabase.storage.from("post-images").createSignedUrl(path, 60 * 60 * 24 * 365);
  if (signErr || !signed) throw signErr ?? new Error("Failed to sign URL");
  return signed.signedUrl;
}

export function timeAgo(iso: string): string {
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return `${Math.floor(s)}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  if (s < 604800) return `${Math.floor(s / 86400)}d`;
  return new Date(iso).toLocaleDateString();
}

/* -------------------- Bookmarks / Save -------------------- */

export async function toggleBookmark(postId: string, saved: boolean) {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) throw new Error("Not signed in");
  if (saved) {
    const { error } = await (supabase.from("post_bookmarks") as any)
      .delete().eq("post_id", postId).eq("user_id", uid);
    if (error) throw error;
  } else {
    const { error } = await (supabase.from("post_bookmarks") as any)
      .insert({ post_id: postId, user_id: uid });
    if (error && (error as { code?: string }).code !== "23505") throw error;
  }
}

export async function listBookmarks(limit = 50): Promise<LivePost[]> {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) return [];
  const { data, error } = await (supabase.from("post_bookmarks") as any)
    .select(`created_at, post:posts(${POST_SELECT})`)
    .eq("user_id", uid)
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  const posts = ((data as { post: LivePost | null }[] | null) ?? [])
    .map((r) => r.post)
    .filter((p): p is LivePost => !!p);
  posts.forEach((p) => { p.reaction_counts = normalizeReactionCounts(p.reaction_counts); });
  await attachRefEntities(posts);

  // Hydrate my_reaction so the reaction picker on the /saved page shows the correct state.
  if (posts.length) {
    const ids = posts.map((p) => p.id);
    const { data: myReactions } = await (supabase.from("post_reactions") as any)
      .select("post_id, reaction_type").eq("user_id", uid).in("post_id", ids);
    const reactionMap = new Map<string, ReactionType>();
    for (const r of (myReactions as { post_id: string; reaction_type: ReactionType }[] | null) ?? []) {
      reactionMap.set(r.post_id, r.reaction_type);
    }
    posts.forEach((p) => {
      p.my_reaction = reactionMap.get(p.id) ?? null;
      p.liked_by_me = !!p.my_reaction;
    });
  }
  posts.forEach((p) => (p.bookmarked_by_me = true));
  return posts;
}


/* -------------------- Edit post -------------------- */

export async function editPost(postId: string, body: string) {
  const clean = body.trim().slice(0, 2000);
  const { error } = await (supabase.from("posts") as any)
    .update({ body: clean || null, edited_at: new Date().toISOString() })
    .eq("id", postId);
  if (error) throw error;
}

/* -------------------- Report post -------------------- */

export async function reportPost(postId: string, reason: string, details?: string) {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) throw new Error("Not signed in");
  const { error } = await (supabase.from("post_reports") as any).insert({
    post_id: postId,
    reporter_id: uid,
    reason,
    details: details?.trim() || null,
  });
  if (error && (error as { code?: string }).code !== "23505") throw error;
}

/* -------------------- Follow / Unfollow author -------------------- */

export async function toggleFollow(targetId: string, following: boolean) {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) throw new Error("Not signed in");
  if (uid === targetId) throw new Error("You can't follow yourself");
  // UI-only synthetic targets (curated seeds, OG founding members without profile rows yet)
  if (targetId.startsWith("seed-") || targetId.startsWith("og-")) return;
  if (following) {
    const { error } = await (supabase.from("follows") as any)
      .delete().eq("follower_id", uid).eq("following_id", targetId);
    if (error) throw error;
  } else {
    const { error } = await (supabase.from("follows") as any)
      .insert({ follower_id: uid, following_id: targetId });
    if (error && (error as { code?: string }).code !== "23505") throw error;
  }
}

export async function listFollowingIds(): Promise<Set<string>> {
  const { data: authData } = await supabase.auth.getUser();
  const uid = authData?.user?.id;
  if (!uid) return new Set();
  const { data } = await (supabase.from("follows") as any)
    .select("following_id").eq("follower_id", uid);
  return new Set(((data as { following_id: string }[]) ?? []).map((r) => r.following_id));
}

/* -------------------- Hide (client-only) -------------------- */

const HIDDEN_KEY = "vibe:hidden-posts";
export function getHiddenPosts(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try { return new Set(JSON.parse(localStorage.getItem(HIDDEN_KEY) || "[]")); } catch { return new Set(); }
}
export function hidePostLocally(postId: string) {
  const s = getHiddenPosts(); s.add(postId);
  try { localStorage.setItem(HIDDEN_KEY, JSON.stringify([...s])); } catch { /* noop */ }
}
