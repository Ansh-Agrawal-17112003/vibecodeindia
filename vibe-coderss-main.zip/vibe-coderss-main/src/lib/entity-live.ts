// Shared helpers for submitting entities to the backend and merging DB rows
// with mock data on listing pages. Works with realtime subscriptions.

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Service, Community, Prompt, Workflow, Tool, Template } from "@/lib/mock-data";

type Kind = "project" | "job" | "service" | "community" | "prompt" | "workflow" | "tool" | "template";

function slugify(s: string) {
  return (s || "item").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
function arr(csv?: string) {
  return (csv || "").split(",").map((s) => s.trim()).filter(Boolean);
}
function coverFor(seed: string) {
  const n = Math.abs([...seed].reduce((a, c) => a + c.charCodeAt(0), 0)) % 400;
  return `https://images.unsplash.com/photo-15${16 + (n % 80)}${String(20000 + n * 37).slice(0, 8)}?w=800&h=500&fit=crop&auto=format`;
}

/**
 * Insert an entity into its backing table. Returns the inserted row id
 * (with `db-` prefix so we can distinguish DB rows from mock IDs), or null
 * if the user is not signed in or the insert failed.
 */
export async function insertEntity(
  kind: Kind,
  form: Record<string, string>,
): Promise<string | null> {
  const { data: userRes } = await supabase.auth.getUser();
  const user = userRes.user;
  if (!user) return null;

  try {
    switch (kind) {
      case "project": {
        const { data, error } = await supabase.from("projects").insert({
          builder_id: user.id,
          title: form.title,
          case_study: form.description,
          solution: form.description,
          industry: form.industry || "SaaS",
          tools_used: arr(form.tools),
        }).select("id").single();
        if (error) throw error;
        return `db-${data.id}`;
      }
      case "job": {
        // Job schema uses strict enums — /submit-job handles the full form.
        // Fall through to local save only.
        return null;
      }

      case "service": {
        const { data, error } = await supabase.from("services").insert({
          builder_id: user.id,
          title: form.title,
          description: form.title,
          category: form.category || "Development",
          packages: {
            price: Number(form.price) || 10000,
            delivery: Number(form.delivery) || 7,
            tags: arr(form.tags),
          },
        }).select("id").single();
        if (error) throw error;
        return `db-${data.id}`;
      }
      case "community": {
        const { data, error } = await supabase.from("communities").insert({
          created_by: user.id,
          name: form.name,
          slug: slugify(form.name),
          icon: form.icon || "🌐",
          description: form.description,
          hue: 200,
          status: "approved",
        }).select("id").single();
        if (error) throw error;
        return `db-${data.id}`;
      }
      case "prompt": {
        const full = form.full || "";
        const { data, error } = await supabase.from("prompts").insert({
          author_id: user.id,
          title: form.title,
          model: form.model || "Claude",
          category: form.category || "Engineering",
          body: full,
          preview: full.slice(0, 140),
        }).select("id").single();
        if (error) throw error;
        return `db-${data.id}`;
      }
      case "workflow": {
        const { data, error } = await supabase.from("workflows").insert({
          author_id: user.id,
          title: form.title,
          category: form.category || "Productivity",
          description: form.description,
          tools: arr(form.tools),
        }).select("id").single();
        if (error) throw error;
        return `db-${data.id}`;
      }
      case "tool": {
        const { data, error } = await supabase.from("ai_tools").insert({
          submitted_by: user.id,
          slug: slugify(form.name) + "-" + Math.random().toString(36).slice(2, 6),
          name: form.name,
          tagline: form.tagline,
          url: form.url,
          category: form.category || "DevTools",
          pricing: form.pricing || "Freemium",
          description: form.description || form.tagline,
        }).select("id").single();
        if (error) throw error;
        return `db-${data.id}`;
      }
      case "template": {
        const { data, error } = await supabase.from("templates").insert({
          author_id: user.id,
          slug: slugify(form.title) + "-" + Math.random().toString(36).slice(2, 6),
          title: form.title,
          description: form.description,
          framework: form.framework || "Lovable",
          category: form.category || "SaaS",
          stack: arr(form.stack),
          price_label: form.price || "Free",
        }).select("id").single();
        if (error) throw error;
        return `db-${data.id}`;
      }
    }
  } catch (err) {
    console.warn(`[insertEntity:${kind}] failed`, err);
    return null;
  }
  return null;
}

// ============================================================
// Mappers: DB row → mock-data shape (so existing cards render unchanged)
// ============================================================

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Row = any;

export const mapService = (r: Row): Service => {
  const pkg = (r.packages ?? {}) as { price?: number; delivery?: number; tags?: string[] };
  return {
    id: `db-${r.id}`,
    title: r.title,
    builderId: r.builder_id,
    cover: r.cover_image_url || coverFor(r.id),
    price: pkg.price ?? 10000,
    delivery: pkg.delivery ?? 7,
    rating: r.rating_avg ?? 5,
    reviews: 0,
    tags: pkg.tags ?? [],
    category: r.category ?? "Development",
  };
};

export const mapCommunity = (r: Row): Community => ({
  id: `db-${r.id}`,
  slug: r.slug,
  name: r.name,
  icon: r.icon ?? "🌐",
  members: r.member_count ?? 0,
  postsThisWeek: r.posts_this_week ?? 0,
  description: r.description ?? "",
  hue: r.hue ?? 200,
  isOfficial: r.is_official ?? false,
  is_demo: r.is_demo ?? false,
});

export const mapPrompt = (r: Row): Prompt => ({
  id: `db-${r.id}`,
  title: r.title,
  model: r.model ?? "Claude",
  category: r.category ?? "Engineering",
  preview: r.preview ?? String(r.body ?? "").slice(0, 140),
  full: r.body ?? "",
  upvotes: r.upvote_count ?? 0,
  builderId: r.author_id,
});

export const mapWorkflow = (r: Row): Workflow => ({
  id: `db-${r.id}`,
  title: r.title,
  cover: r.cover_image_url || coverFor(r.id),
  tools: r.tools ?? [],
  category: r.category ?? "Productivity",
  description: r.description ?? "",
  upvotes: r.upvote_count ?? 0,
  builderId: r.author_id,
});

export const mapTool = (r: Row): Tool => ({
  id: `db-${r.id}`,
  slug: r.slug,
  name: r.name,
  tagline: r.tagline,
  category: r.category ?? "DevTools",
  pricing: (r.pricing ?? "Freemium") as Tool["pricing"],
  logoBg: "#0F0F0F",
  url: r.url,
  upvotes: r.upvote_count ?? 0,
  description: r.description ?? r.tagline,
});

export const mapTemplate = (r: Row): Template => ({
  id: `db-${r.id}`,
  slug: r.slug,
  title: r.title,
  cover: r.cover_image_url || coverFor(r.id),
  stack: r.stack ?? [],
  category: r.category ?? "SaaS",
  framework: r.framework ?? "Lovable",
  price: r.price_label ?? "Free",
  downloads: r.downloads ?? 0,
  description: r.description ?? "",
  builderId: r.author_id,
});

// ============================================================
// Hook: fetch a table + subscribe to realtime; return mapped mock rows
// ============================================================

export function useLiveTable<T>(
  table: "services" | "communities" | "prompts" | "workflows" | "ai_tools" | "templates",
  mapper: (row: Row) => T,
  orderCol: string = "created_at",
): T[] {
  const [rows, setRows] = useState<T[]>([]);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const q = supabase.from(table as any).select("*").order(orderCol, { ascending: false });
      const { data, error } = await q;
      if (cancelled || error || !data) return;
      setRows((data as Row[]).map(mapper));
    };
    load();
    const channel = supabase
      .channel(`live:${table}:${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table }, () => load())
      .subscribe();
    return () => {
      cancelled = true;
      try { supabase.removeChannel(channel); } catch { /* noop */ }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [table]);

  return rows;
}
