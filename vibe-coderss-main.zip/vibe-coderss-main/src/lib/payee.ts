// Central UPI payee for all VibeCode payments.
// All checkouts (plan upgrades, service orders, QR scans) route funds here.
export const PAYEE_UPI_ID = "9473916731@ybl";
export const PAYEE_NAME = "VibeCode";

/** Build a standard NPCI UPI intent link (works with GPay, PhonePe, Paytm, BHIM, CRED, etc.). */
export function upiIntent({
  amount,
  note,
  ref,
}: {
  amount: number;
  note?: string;
  ref?: string;
}) {
  const params = new URLSearchParams({
    pa: PAYEE_UPI_ID,
    pn: PAYEE_NAME,
    am: amount.toFixed(2),
    cu: "INR",
  });
  if (note) params.set("tn", note.slice(0, 80));
  if (ref) params.set("tr", ref.slice(0, 35));
  return `upi://pay?${params.toString()}`;
}

/** Scannable QR image for the UPI intent (renders in any <img>). */
export function upiQrUrl(args: { amount: number; note?: string; ref?: string; size?: number }) {
  const data = encodeURIComponent(upiIntent(args));
  const size = args.size ?? 260;
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&margin=0&data=${data}`;
}
