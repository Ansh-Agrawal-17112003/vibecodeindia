import { builders, jobs, communities } from "@/lib/mock-data";

export type PostType = "project" | "prompt" | "workflow" | "update" | "question";

export type ReactionCounts = {
  like: number;
  celebrate: number;
  fire: number;
  insightful: number;
  support: number;
};

export type FeedPost = {
  id: string;
  authorId: string;
  type: PostType;
  text: string;
  hashtags: string[];
  createdAgo: string;
  reactions: ReactionCounts;
  comments: number;
  shares: number;
  views: number;
  topComment?: { authorId: string; text: string; likes: number; ago: string };
  // type-specific
  project?: { title: string; cover: string; tools: string[]; demoUrl?: string; githubUrl?: string };
  prompt?: { model: string; text: string };
  workflow?: { title: string; thumb: string; tools: string[] };
  update?: { images?: string[] };
  question?: { tags: string[] };
};

const cover = (a: number | string, b?: number) => {
  const seed = typeof a === "string" ? a : `c${a}-${b ?? 0}`;
  return `https://picsum.photos/seed/${encodeURIComponent(seed)}/800/450`;
};

const rnd = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
const r = (seed: number, min: number, max: number) => {
  // deterministic-ish per seed to avoid hydration jumps but stay unroundy
  const x = Math.sin(seed * 9999) * 10000;
  const f = x - Math.floor(x);
  return Math.floor(f * (max - min + 1)) + min;
};

const rc = (seed: number): ReactionCounts => ({
  like: r(seed, 40, 340),
  celebrate: r(seed + 1, 8, 60),
  fire: r(seed + 2, 12, 90),
  insightful: r(seed + 3, 6, 45),
  support: r(seed + 4, 3, 30),
});

const bId = (n: number) => builders[n % builders.length].id;

export const SEED_POSTS: FeedPost[] = [
  // 8 project posts
  { id: "p1", authorId: bId(0), type: "project", text: "Just shipped FlowOps v2 — a marketplace of 200+ n8n workflows for SaaS ops teams. First 100 users get lifetime access.", hashtags: ["n8n","automation","saas"], createdAgo: "2h ago", reactions: rc(1), comments: 47, shares: 12, views: 1240, project: { title: "FlowOps — n8n Templates Marketplace", cover: cover("flowops"), tools: ["n8n","Lovable","Stripe"], demoUrl: "#", githubUrl: "#" }, topComment: { authorId: bId(1), text: "This is insane! How did you handle auth for private templates?", likes: 12, ago: "1h ago" } },
  { id: "p2", authorId: bId(1), type: "project", text: "Pitch.studio — AI pitch-deck builder that funded startups actually use. Just crossed 500 paying users 🚀", hashtags: ["lovable","ai","launch"], createdAgo: "5h ago", reactions: rc(2), comments: 63, shares: 24, views: 2871, project: { title: "Pitch.studio", cover: cover("pitchstudio"), tools: ["Lovable","GPT-4","Stripe"], demoUrl: "#" } },
  { id: "p3", authorId: bId(4), type: "project", text: "Building in public: MedScribe cut doctor note-taking by 70% in a Bangalore clinic pilot. Onboarding 3 more clinics next week.", hashtags: ["healthtech","whisper","claude"], createdAgo: "8h ago", reactions: rc(3), comments: 29, shares: 8, views: 943, project: { title: "MedScribe — AI Clinical Notes", cover: cover("medscribe"), tools: ["Claude","Lovable","Whisper"], demoUrl: "#" } },
  { id: "p4", authorId: bId(6), type: "project", text: "LegalLens shipped its contract review co-pilot to 12 law firms this month. Average review time down from 4h to 22min.", hashtags: ["legal","claude","automation"], createdAgo: "1d ago", reactions: rc(4), comments: 34, shares: 15, views: 1567, project: { title: "LegalLens", cover: cover("legallens"), tools: ["Claude","Cursor","n8n"], demoUrl: "#" } },
  { id: "p5", authorId: bId(5), type: "project", text: "ShipFast boilerplate v3 out. Lovable + Supabase + Stripe + auth + dashboards. Cloned 340+ times this week.", hashtags: ["boilerplate","supabase"], createdAgo: "1d ago", reactions: rc(5), comments: 41, shares: 33, views: 2104, project: { title: "ShipFast Boilerplate", cover: cover("shipfast"), tools: ["Lovable","Supabase","Stripe"], githubUrl: "#" } },
  { id: "p6", authorId: bId(2), type: "project", text: "Workflow Forge — visual builder for hybrid n8n + Make workflows. Launched on Product Hunt today, currently #3 🎉", hashtags: ["n8n","make","launch"], createdAgo: "2d ago", reactions: rc(6), comments: 88, shares: 42, views: 4231, project: { title: "Workflow Forge", cover: cover("workflowforge"), tools: ["n8n","Make","Cursor"], demoUrl: "#" } },
  { id: "p7", authorId: bId(7), type: "project", text: "PromptVault → team prompt library with versioning + A/B testing analytics. 40 teams already onboarded.", hashtags: ["prompts","teams"], createdAgo: "2d ago", reactions: rc(7), comments: 22, shares: 9, views: 812, project: { title: "PromptVault", cover: cover("promptvault"), tools: ["GPT-4","Lovable"], demoUrl: "#" } },
  { id: "p8", authorId: bId(3), type: "project", text: "BrandKit AI can now generate full brand systems (logo, palette, typography, mockups) from a one-line prompt.", hashtags: ["design","midjourney"], createdAgo: "3d ago", reactions: rc(8), comments: 56, shares: 27, views: 1988, project: { title: "BrandKit AI", cover: cover("brandkit"), tools: ["Midjourney","Cursor","Figma API"], demoUrl: "#" } },

  // 8 prompt posts
  { id: "pr1", authorId: bId(1), type: "prompt", text: "This landing-page prompt has generated 40+ conversions for my clients this month. Steal it. 👇", hashtags: ["gpt4o","copywriting"], createdAgo: "3h ago", reactions: rc(9), comments: 31, shares: 58, views: 3120, prompt: { model: "GPT-4o", text: "Act as a senior conversion copywriter at Stripe. Given a one-line product description, produce: 1) Hero headline (8 words max), 2) Subheadline (20 words), 3) Three benefit bullets, 4) Social proof block, 5) Feature trio, 6) FAQ (5 Q/A), 7) CTA copy. Product: {{description}}" } },
  { id: "pr2", authorId: bId(7), type: "prompt", text: "Prompt I use every day to audit other prompts. Meta but works.", hashtags: ["prompteng"], createdAgo: "6h ago", reactions: rc(10), comments: 14, shares: 22, views: 1204, prompt: { model: "Claude", text: "Audit the following system prompt. Score 1-10 on: clarity, injection-resistance, fallback handling, role consistency, token efficiency. Then rewrite it tighter.\n\n{{prompt}}" } },
  { id: "pr3", authorId: bId(0), type: "prompt", text: "n8n Workflow Architect prompt — describe a business process in English, get a full node-by-node spec.", hashtags: ["n8n","claude"], createdAgo: "10h ago", reactions: rc(11), comments: 19, shares: 34, views: 1611, prompt: { model: "Claude", text: "You are an n8n expert. Output a node-by-node workflow specification: trigger, processing nodes, error branches, credentials required. Return as a numbered list.\n\nProcess: {{process}}" } },
  { id: "pr4", authorId: bId(6), type: "prompt", text: "\"Linus Torvalds code review\" prompt. Brutal but always right. Improved my architecture reviews 10x.", hashtags: ["engineering"], createdAgo: "1d ago", reactions: rc(12), comments: 42, shares: 51, views: 2894, prompt: { model: "Claude", text: "Review this PR with the directness of Linus Torvalds. Focus on architectural smells, hidden complexity, and naming. Be brutal but constructive. Cite line numbers.\n\n{{diff}}" } },
  { id: "pr5", authorId: bId(9), type: "prompt", text: "OKR writer for startups. Q4 planning got 3x faster in our team after using this.", hashtags: ["startup"], createdAgo: "1d ago", reactions: rc(13), comments: 9, shares: 14, views: 743, prompt: { model: "Claude", text: "Generate Q{{quarter}} OKRs for a {{stage}} {{industry}} startup. 3 objectives, 3 measurable KRs each. Stretch but achievable. Include leading + lagging indicators." } },
  { id: "pr6", authorId: bId(3), type: "prompt", text: "Brand naming + domain checker prompt. Ships 10 names in 20 seconds with .com/.ai availability hints.", hashtags: ["marketing"], createdAgo: "2d ago", reactions: rc(14), comments: 17, shares: 28, views: 1345, prompt: { model: "GPT-4o", text: "Generate 10 brand name candidates for {{description}}. Each: 2 syllables, easy to spell, .com or .ai availability hint, 1-line rationale, and 1 potential trademark risk." } },
  { id: "pr7", authorId: bId(7), type: "prompt", text: "SEO cluster map generator. One topic → pillar + 8 clusters + 30 keywords with intent.", hashtags: ["seo","growth"], createdAgo: "2d ago", reactions: rc(15), comments: 24, shares: 39, views: 1876, prompt: { model: "GPT-4o", text: "Generate an SEO topic cluster for {{topic}}: 1 pillar page outline (3000 words), 8 cluster posts (titles + H2s), 30 long-tail keywords with intent classification." } },
  { id: "pr8", authorId: bId(5), type: "prompt", text: "Lovable component spec generator. Feed it a feature idea, get a Lovable-ready spec.", hashtags: ["lovable"], createdAgo: "3d ago", reactions: rc(16), comments: 33, shares: 47, views: 2213, prompt: { model: "Claude", text: "Write a component spec optimized for Lovable AI. Include: props interface (TypeScript), design tokens used, accessibility notes, edge cases, example usage. Feature: {{feature}}" } },

  // 6 workflow posts
  { id: "w1", authorId: bId(2), type: "workflow", text: "n8n workflow that turns customer support emails into Linear tickets with priority auto-tagged. Saved my team 12h/week.", hashtags: ["n8n","support"], createdAgo: "4h ago", reactions: rc(17), comments: 26, shares: 41, views: 1912, workflow: { title: "Support Email → Linear Ticket", thumb: cover("support"), tools: ["n8n","GPT-4","Linear"] } },
  { id: "w2", authorId: bId(0), type: "workflow", text: "Make.com workflow: new Stripe subscription → onboarding email sequence + Slack alert + CRM update. Zero code.", hashtags: ["make","stripe"], createdAgo: "9h ago", reactions: rc(18), comments: 18, shares: 29, views: 1445, workflow: { title: "Stripe → Full Onboarding", thumb: cover("stripe"), tools: ["Make","Stripe","Slack"] } },
  { id: "w3", authorId: bId(2), type: "workflow", text: "Automated LinkedIn content pipeline: idea DB → GPT drafting → human review → scheduling → analytics.", hashtags: ["n8n","content"], createdAgo: "1d ago", reactions: rc(19), comments: 34, shares: 52, views: 2678, workflow: { title: "LinkedIn Content Machine", thumb: cover("linkedin"), tools: ["n8n","GPT-4","LinkedIn"] } },
  { id: "w4", authorId: bId(6), type: "workflow", text: "n8n workflow for contract intake → clause extraction → risk scoring → lawyer review queue. Legal ops teams love it.", hashtags: ["legal","rag"], createdAgo: "2d ago", reactions: rc(20), comments: 15, shares: 22, views: 1103, workflow: { title: "Contract Intake Pipeline", thumb: cover("contract"), tools: ["n8n","Claude","Airtable"] } },
  { id: "w5", authorId: bId(5), type: "workflow", text: "Weekend build: RSS → LLM summariser → daily digest email. Reading 100 sources in 5 min every morning.", hashtags: ["automation"], createdAgo: "3d ago", reactions: rc(21), comments: 21, shares: 18, views: 942, workflow: { title: "Personal AI News Digest", thumb: cover("newsdigest"), tools: ["n8n","Claude","Resend"] } },
  { id: "w6", authorId: bId(0), type: "workflow", text: "Instagram DM → GPT triage → auto-reply for FAQs, escalate the rest. Cut agent load by 60% for a D2C brand.", hashtags: ["support","ecom"], createdAgo: "4d ago", reactions: rc(22), comments: 12, shares: 20, views: 823, workflow: { title: "IG DM Auto-Triage", thumb: cover("instagram"), tools: ["Make","GPT-4","Instagram"] } },

  // 4 questions
  { id: "q1", authorId: bId(8), type: "question", text: "What's the best way to handle streaming responses from Claude inside a Lovable app? Getting weird cut-offs after ~2s.", hashtags: ["lovable","claude"], createdAgo: "1h ago", reactions: rc(23), comments: 11, shares: 2, views: 342, question: { tags: ["help","lovable"] }, topComment: { authorId: bId(0), text: "Use SSE via a Supabase edge fn and let it pipe chunks. DM me if you want a template.", likes: 8, ago: "40m ago" } },
  { id: "q2", authorId: bId(3), type: "question", text: "Anyone here running Midjourney API programmatically in India? Payment methods that actually work?", hashtags: ["midjourney"], createdAgo: "7h ago", reactions: rc(24), comments: 19, shares: 5, views: 611, question: { tags: ["help","design"] } },
  { id: "q3", authorId: bId(4), type: "question", text: "Best vector DB for a 500K-doc RAG on a bootstrapped budget? Weighing Supabase pgvector vs Qdrant Cloud.", hashtags: ["rag","vectordb"], createdAgo: "1d ago", reactions: rc(25), comments: 34, shares: 12, views: 1782, question: { tags: ["rag","help"] } },
  { id: "q4", authorId: bId(1), type: "question", text: "How are you handling GST + international payments for AI SaaS from India? Stripe Atlas or LLC?", hashtags: ["saas","india"], createdAgo: "2d ago", reactions: rc(26), comments: 41, shares: 18, views: 2411, question: { tags: ["startup","india"] } },

  // 4 updates
  { id: "u1", authorId: bId(4), type: "update", text: "Two years, four failed projects, one that finally clicked. MedScribe just crossed ₹1L MRR. Building in India works — just takes longer than Twitter tells you. 🙏", hashtags: ["milestone"], createdAgo: "3h ago", reactions: rc(27), comments: 78, shares: 34, views: 4128, update: {} },
  { id: "u2", authorId: bId(1), type: "update", text: "Hiring 2 vibe coders for a founding team gig in Bangalore. Full-stack, Lovable-first. Equity + salary. DMs open.", hashtags: ["hiring"], createdAgo: "6h ago", reactions: rc(28), comments: 52, shares: 88, views: 3299, update: {} },
  { id: "u3", authorId: bId(6), type: "update", text: "AMA I did last week with 80+ Indian AI builders is now up on YouTube. Questions on pricing, positioning, and shipping fast.", hashtags: ["community"], createdAgo: "1d ago", reactions: rc(29), comments: 23, shares: 41, views: 1897, update: {} },
  { id: "u4", authorId: bId(0), type: "update", text: "Small win: automated my own invoicing + GST filing with n8n + a Sheets doc. Reclaimed 4h/week. If enough people want it, I'll open-source the template.", hashtags: ["automation"], createdAgo: "2d ago", reactions: rc(30), comments: 96, shares: 33, views: 2812, update: {} },
];

export const RIGHT_JOBS_POOL = jobs.slice(0, 12);
export const RIGHT_PEOPLE_POOL = builders;

export const AI_NEWS: { title: string; source: string; ago: string; hue: number }[] = [
  { title: "OpenAI releases GPT-5 with real-time voice + vision inference", source: "TechCrunch", ago: "2h ago", hue: 20 },
  { title: "Anthropic's Claude 4 now supports 2M-token context window", source: "The Verge", ago: "4h ago", hue: 280 },
  { title: "India's AI startup funding hits $1.2B in Q3, up 68% YoY", source: "Inc42", ago: "6h ago", hue: 140 },
  { title: "n8n raises $35M Series B to accelerate self-hosted AI automation", source: "VentureBeat", ago: "1d ago", hue: 200 },
  { title: "Sarvam AI open-sources Indic LLM outperforming GPT-4 on Hindi", source: "YourStory", ago: "1d ago", hue: 40 },
  { title: "Google DeepMind's Gemini 3 leaked benchmarks stun researchers", source: "Ars Technica", ago: "2d ago", hue: 180 },
  { title: "Cursor hits $500M ARR, becomes fastest-growing dev tool ever", source: "The Information", ago: "2d ago", hue: 320 },
  { title: "Lovable crosses 1M shipped apps, announces enterprise tier", source: "TechCrunch", ago: "2d ago", hue: 340 },
  { title: "Meta releases Llama 4: multimodal, open-weights, 400B params", source: "The Verge", ago: "3d ago", hue: 220 },
  { title: "Replit launches Agent v2 with autonomous background tasks", source: "Wired", ago: "3d ago", hue: 100 },
  { title: "RBI approves UPI-based subscription billing for AI SaaS", source: "Economic Times", ago: "3d ago", hue: 60 },
  { title: "Mistral AI ships Codestral 2, top open-source coding model", source: "The Register", ago: "4d ago", hue: 20 },
  { title: "Perplexity introduces India-focused search with Hindi voice", source: "Mint", ago: "4d ago", hue: 240 },
  { title: "Vercel v0 now generates full Next.js apps from Figma files", source: "Vercel Blog", ago: "5d ago", hue: 0 },
  { title: "Zapier acquires Vibe Automations for $80M cash + stock", source: "TechCrunch", ago: "5d ago", hue: 280 },
  { title: "Bengaluru startup Sarvam raises $41M for full-stack Indian AI", source: "YourStory", ago: "6d ago", hue: 140 },
  { title: "OpenAI Realtime API pricing cut by 50% for voice apps", source: "Hacker News", ago: "6d ago", hue: 20 },
  { title: "GitHub Copilot Workspace now GA, competing with Cursor", source: "GitHub Blog", ago: "1w ago", hue: 200 },
  { title: "IIT-Delhi and Sarvam launch India's first AI research chair", source: "The Hindu", ago: "1w ago", hue: 40 },
  { title: "Y Combinator W26 batch is 62% AI startups, breaks record", source: "TechCrunch", ago: "1w ago", hue: 320 },
];

export const DAILY_CHALLENGES = [
  { day: "Wed", title: "Drop your latest project", body: "Share a project for community feedback! Top post wins 100 VibeCoins." },
  { day: "Thu", title: "Share a workflow", body: "Post an n8n / Make workflow that saves you time. Best one wins 100 VibeCoins." },
  { day: "Fri", title: "Prompt Friday", body: "Share your most-used prompt of the week. Top post wins 100 VibeCoins." },
];

export const SEED_HASHTAGS = ["#lovable", "#claude", "#n8n", "#automation", "#gpt4o", "#supabase", "#cursor", "#buildinpublic"];

export function getBuilder(id: string) {
  return builders.find((b) => b.id === id) ?? builders[0];
}

export function shuffleFeed<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function makeInfinitePage(offset: number, count = 10): FeedPost[] {
  const out: FeedPost[] = [];
  for (let i = 0; i < count; i++) {
    const base = SEED_POSTS[(offset + i) % SEED_POSTS.length];
    out.push({ ...base, id: `${base.id}-${offset + i}` });
  }
  return out;
}

export { rnd, cover };
