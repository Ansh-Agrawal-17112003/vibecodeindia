import { supabase } from "@/integrations/supabase/client";

export type RvmKind =
  | "hire"
  | "freelance"
  | "collab"
  | "feature"
  | "prompt_saved_time"
  | "cashout"
  | "followers_boost"
  | "other";

export type RealValueMoment = {
  id: string;
  user_id: string;
  kind: RvmKind;
  title: string;
  description: string | null;
  amount_inr: number | null;
  hours_saved: number | null;
  evidence_url: string | null;
  source: string;
  source_ref: string | null;
  verified: boolean;
  featured: boolean;
  verified_at: string | null;
  verified_by: string | null;
  created_at: string;
  profile?: {
    id: string;
    display_name: string | null;
    username: string | null;
    avatar_url: string | null;
  } | null;
};

export const KIND_LABEL: Record<RvmKind, string> = {
  hire: "Got hired",
  freelance: "Freelance gig",
  collab: "Shipped a collab",
  feature: "Got featured",
  prompt_saved_time: "Prompt saved time",
  cashout: "Cashed out",
  followers_boost: "Follower boost",
  other: "Other",
};

export const KIND_EMOJI: Record<RvmKind, string> = {
  hire: "🎯",
  freelance: "💼",
  collab: "🤝",
  feature: "⭐",
  prompt_saved_time: "⚡",
  cashout: "💸",
  followers_boost: "📈",
  other: "✨",
};

export async function fetchFeaturedMoments(limit = 20) {
  const { data, error } = await (supabase.from("real_value_moments") as any)
    .select("*")
    .eq("verified", true)
    .order("featured", { ascending: false })
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) {
    console.error("fetchFeaturedMoments", error);
    return [];
  }
  return attachProfiles((data ?? []) as RealValueMoment[]);
}

export async function fetchWeeklyCount() {
  const { data, error } = await (supabase.rpc as any)("rvm_weekly_count");
  if (error) {
    console.error("rvm_weekly_count", error);
    return [];
  }
  return (data ?? []) as { week_start: string; total: number; verified: number }[];
}

export async function submitMoment(input: {
  user_id: string;
  kind: RvmKind;
  title: string;
  description?: string;
  amount_inr?: number;
  hours_saved?: number;
  evidence_url?: string;
}) {
  const { error } = await (supabase.from("real_value_moments") as any).insert({
    ...input,
    source: "manual",
  });
  if (error) throw error;
}

export async function fetchAllMomentsAdmin(limit = 200) {
  const { data, error } = await (supabase.from("real_value_moments") as any)
    .select("*")
    .order("verified", { ascending: true })
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) {
    console.error("fetchAllMomentsAdmin", error);
    return [];
  }
  return attachProfiles((data ?? []) as RealValueMoment[]);
}

async function attachProfiles(rows: RealValueMoment[]) {
  if (rows.length === 0) return rows;
  const ids = Array.from(new Set(rows.map((r) => r.user_id)));
  const { data } = await supabase
    .from("profiles")
    .select("id,display_name,username,avatar_url")
    .in("id", ids);
  const map = new Map((data ?? []).map((p: any) => [p.id, p]));
  return rows.map((r) => ({ ...r, profile: map.get(r.user_id) ?? null }));
}

export async function updateMoment(
  id: string,
  patch: Partial<Pick<RealValueMoment, "verified" | "featured" | "title" | "description">>,
) {
  const payload: any = { ...patch };
  if (patch.verified) payload.verified_at = new Date().toISOString();
  const { error } = await (supabase.from("real_value_moments") as any).update(payload).eq("id", id);
  if (error) throw error;
}

export async function deleteMoment(id: string) {
  const { error } = await supabase.from("real_value_moments").delete().eq("id", id);
  if (error) throw error;
}
