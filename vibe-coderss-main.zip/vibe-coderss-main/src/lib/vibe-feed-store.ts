import type { FeedPost, PostType } from "@/lib/vibe-feed-seed";
import { cover } from "@/lib/vibe-feed-seed";

type Listener = (post: FeedPost) => void;
const listeners = new Set<Listener>();

export function subscribeNewPost(fn: Listener) {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export function publishNewPost(post: FeedPost) {
  listeners.forEach((l) => l(post));
}

export function createDraftPost(input: {
  type: PostType;
  authorId: string;
  text: string;
  hashtags: string[];
  projectTitle?: string;
  tools?: string[];
  demoUrl?: string;
  githubUrl?: string;
  promptModel?: string;
  promptText?: string;
  workflowTitle?: string;
  questionTags?: string[];
}): FeedPost {
  const id = `local-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const base: FeedPost = {
    id,
    authorId: input.authorId,
    type: input.type,
    text: input.text.trim(),
    hashtags: input.hashtags,
    createdAgo: "just now",
    reactions: { like: 0, celebrate: 0, fire: 0, insightful: 0, support: 0 },
    comments: 0,
    shares: 0,
    views: 1,
  };
  const hue = Math.floor(Math.random() * 360);
  if (input.type === "project") {
    base.project = {
      title: input.projectTitle || "Untitled project",
      cover: cover(hue, (hue + 40) % 360),
      tools: input.tools || [],
      demoUrl: input.demoUrl,
      githubUrl: input.githubUrl,
    };
  } else if (input.type === "prompt") {
    base.prompt = {
      model: input.promptModel || "GPT-4o",
      text: input.promptText || input.text,
    };
  } else if (input.type === "workflow") {
    base.workflow = {
      title: input.workflowTitle || "Untitled workflow",
      thumb: cover(hue, (hue + 60) % 360),
      tools: input.tools || [],
    };
  } else if (input.type === "question") {
    base.question = { tags: input.questionTags || input.hashtags };
  } else if (input.type === "update") {
    base.update = {};
  }
  return base;
}

export function extractHashtags(text: string): string[] {
  const set = new Set<string>();
  text.replace(/#(\w+)/g, (_, tag) => {
    set.add(tag.toLowerCase());
    return "";
  });
  return Array.from(set);
}
