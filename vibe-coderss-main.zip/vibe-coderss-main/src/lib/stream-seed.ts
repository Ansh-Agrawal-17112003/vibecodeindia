// Seed scripts to give freshly-created community channels a lively feel.
// Bot users are created in Stream Chat (not real Supabase accounts) so
// members joining a room immediately see multi-participant activity.

export type SeedBot = { id: string; name: string; image: string };

export const SEED_BOTS: SeedBot[] = [
  { id: "bot-aarav",   name: "Aarav Mehta",     image: "https://api.dicebear.com/7.x/avataaars/svg?seed=aarav" },
  { id: "bot-priya",   name: "Priya Sharma",    image: "https://api.dicebear.com/7.x/avataaars/svg?seed=priya" },
  { id: "bot-rohan",   name: "Rohan Verma",     image: "https://api.dicebear.com/7.x/avataaars/svg?seed=rohan" },
  { id: "bot-ananya",  name: "Ananya Iyer",     image: "https://api.dicebear.com/7.x/avataaars/svg?seed=ananya" },
  { id: "bot-vikram",  name: "Vikram Rao",      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=vikram" },
  { id: "bot-sneha",   name: "Sneha Kapoor",    image: "https://api.dicebear.com/7.x/avataaars/svg?seed=sneha" },
  { id: "bot-arjun",   name: "Arjun Nair",      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=arjun" },
  { id: "bot-ishita",  name: "Ishita Bose",     image: "https://api.dicebear.com/7.x/avataaars/svg?seed=ishita" },
];

// Per-topic conversation scripts, indexed by the trailing topic slug.
const SCRIPTS: Record<string, Array<{ bot: number; text: string }>> = {
  general: [
    { bot: 0, text: "gm builders ☕ what's everyone shipping this week?" },
    { bot: 1, text: "Working on an AI resume rewriter with Lovable + Gemini. Beta drops Friday!" },
    { bot: 2, text: "Nice 🔥 I just launched a Notion → landing page automation with n8n." },
    { bot: 3, text: "Any recs for cheapest vector DB for a side project? Pinecone free tier is tiny." },
    { bot: 4, text: "Try Supabase pgvector — free and fast enough for <1M rows." },
    { bot: 5, text: "+1 on pgvector. Cursor + Claude 3.5 handles the schema for you." },
    { bot: 0, text: "Btw, anyone going to the Bangalore Vibe Coders meetup on Saturday?" },
    { bot: 6, text: "I'll be there! Bringing a demo of my voice-to-workflow agent 🎙️" },
    { bot: 7, text: "Save me a seat 🙌" },
  ],
  showcase: [
    { bot: 1, text: "Just shipped v1 of my AI meeting-note SaaS. 40 signups in 24h 🎉" },
    { bot: 2, text: "Congrats! What's the stack?" },
    { bot: 1, text: "Lovable + Supabase + Deepgram for transcription + GPT-4o-mini for summaries." },
    { bot: 3, text: "Bookmarking this thread. Sharing my launch tomorrow — a Hinglish prompt library." },
    { bot: 4, text: "Show us the demo when it drops! 🚀" },
    { bot: 5, text: "I got featured on PH last week btw — landed 3 paying customers in 48h." },
    { bot: 6, text: "🎯 huge. Which category worked best for you?" },
  ],
  help: [
    { bot: 3, text: "Stuck on Supabase RLS — anon can read but authenticated can't. Help?" },
    { bot: 4, text: "Sounds like your policy uses `USING (true)` for anon and you forgot to add one for authenticated." },
    { bot: 3, text: "Ohhh yep that was it. GRANT + policy fixed it. Thanks 🙏" },
    { bot: 0, text: "Anyone got a good pattern for streaming Gemini responses in Lovable?" },
    { bot: 5, text: "Use AI Gateway with stream:true, then pipe to a Response inside a server function." },
    { bot: 7, text: "I wrote a mini template — happy to share the repo, DM me." },
  ],
  resources: [
    { bot: 2, text: "📚 Dropping my personal 'AI Builder Starter Pack':" },
    { bot: 2, text: "1) Lovable for frontend  2) Supabase for backend  3) n8n for automation  4) Cursor for polish" },
    { bot: 0, text: "Adding: PostHog for analytics (free tier is generous) + Resend for transactional email." },
    { bot: 4, text: "Bookmarking. Would love a 'first 100 users' playbook next 🙏" },
    { bot: 6, text: "Coming soon — I'm drafting a Notion doc. Will post here on Friday." },
  ],
  jobs: [
    { bot: 5, text: "Hiring: Full-stack AI engineer, remote India, ₹18-30 LPA. DM if keen." },
    { bot: 6, text: "Looking for a founding designer for my AI copilot startup (equity + salary). Bangalore." },
    { bot: 7, text: "Open to freelance builds — Lovable, n8n, Supabase. 3+ shipped apps." },
    { bot: 1, text: "We're hiring 2 interns for a stealth AI SaaS. Send portfolios 🔥" },
    { bot: 3, text: "Anyone need a landing page done this week? Fixed price ₹8k." },
  ],
};

// Extract the final segment of the stream channel id.
// stream_channel_id looks like "vibe-<community-slug>-<topic-slug>".
function topicSlugFromChannelId(cid: string): string {
  const parts = cid.split("-");
  return parts[parts.length - 1] ?? "general";
}

/**
 * Seed a channel with a scripted multi-participant conversation.
 * No-op if the channel already has any messages.
 */
export async function seedChannelIfEmpty(
  serverClient: import("stream-chat").StreamChat,
  channelType: string,
  channelId: string,
): Promise<void> {
  const channel = serverClient.channel(channelType, channelId);
  try {
    const state = await channel.query({ messages: { limit: 1 } });
    if ((state.messages?.length ?? 0) > 0) return;
  } catch {
    return;
  }

  const topic = topicSlugFromChannelId(channelId);
  const script = SCRIPTS[topic] ?? SCRIPTS.general;

  const usedBotIndexes = Array.from(new Set(script.map((s) => s.bot)));
  const bots = usedBotIndexes.map((i) => SEED_BOTS[i % SEED_BOTS.length]);

  // Upsert bot users + add as members so their messages render with avatars.
  try {
    await serverClient.upsertUsers(bots.map((b) => ({ ...b, role: "user" })));
    await channel.addMembers(bots.map((b) => b.id));
  } catch {
    /* ignore */
  }

  // Send messages spread over the last ~48 hours so it feels ongoing.
  const now = Date.now();
  const spanMs = 1000 * 60 * 60 * 40; // 40h window
  for (let i = 0; i < script.length; i++) {
    const line = script[i];
    const bot = SEED_BOTS[line.bot % SEED_BOTS.length];
    const createdAt = new Date(now - spanMs + (spanMs / script.length) * i);
    try {
      await channel.sendMessage(
        {
          text: line.text,
          user_id: bot.id,
          // @ts-expect-error - Stream accepts created_at server-side
          created_at: createdAt.toISOString(),
        },
        { skip_push: true },
      );
    } catch {
      /* ignore individual send errors */
    }
  }
}
