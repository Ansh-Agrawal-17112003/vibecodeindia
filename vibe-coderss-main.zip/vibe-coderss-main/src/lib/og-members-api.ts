import { supabase } from "@/integrations/supabase/client";
import type { Builder } from "@/lib/mock-data";
import type { SuggestedPerson } from "@/lib/people-api";

export type OgMember = {
  id: string;
  profile_id: string | null;
  full_name: string;
  username: string | null;
  city: string | null;
  state: string | null;
  builder_type: string | null;
  primary_tool: string | null;
  other_tools: string[] | null;
  what_building: string | null;
  linkedin_url: string | null;
  twitter_url: string | null;
  github_url: string | null;
  og_number: number;
  wall_tagline: string | null;
  ai_content: any | null;
};

const AVATAR = (seed: string) =>
  `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed)}&backgroundColor=E8623A,F5A623,2DD4BF,7C3AED`;

// Public reads go through the `og_wall_public` view, which excludes PII
// (email, IP address, user agent). The base `og_members` table is not
// readable by anon/authenticated clients for those sensitive columns.
const OG_VIEW = "og_wall_public";
const OG_COLS =
  "id, profile_id, full_name, username, city, state, builder_type, primary_tool, other_tools, what_building, linkedin_url, twitter_url, github_url, og_number, wall_tagline, ai_content";

/** Fetch all "wall-visible" OG founding members that have a username. */
export async function listOgMembers(limit = 50): Promise<OgMember[]> {
  const { data, error } = await (supabase as any)
    .from(OG_VIEW)
    .select(OG_COLS)
    .order("og_number", { ascending: true })
    .limit(limit);
  if (error) throw error;
  return (data ?? []) as OgMember[];
}

export async function getOgMemberByUsername(username: string): Promise<OgMember | null> {
  const { data, error } = await (supabase as any)
    .from(OG_VIEW)
    .select(OG_COLS)
    .eq("username", username)
    .maybeSingle();
  if (error) throw error;
  return (data as OgMember | null) ?? null;
}

const TYPE_MAP: Record<string, Builder["type"]> = {
  founder: "Founder",
  freelancer: "Freelancer",
  agency: "Agency",
  student: "Student",
};

/** Shape an OG member as a Builder for the Explore directory. */
export function ogToBuilder(o: OgMember): Builder {
  const name = o.full_name || o.username || `OG #${o.og_number}`;
  const location = [o.city, o.state].filter(Boolean).join(", ") || "India";
  const tools = [o.primary_tool, ...(o.other_tools ?? [])].filter(Boolean) as string[];
  const type = TYPE_MAP[(o.builder_type ?? "").toLowerCase()] ?? "Founder";
  const ai = o.ai_content ?? {};
  const title = (ai.headline as string) || o.wall_tagline || `OG Founding Member · #${o.og_number}`;
  const bio = (ai.about_long as string) || o.wall_tagline || `OG Founding Member #${o.og_number} — building the future of Indian AI.`;
  const skills = (ai.expertise as string[]) || (ai.what_i_do as string[]) || ["Building"];
  return {
    id: `og-${o.og_number}`,
    username: o.username!,
    name,
    title,
    avatar: AVATAR(o.username || String(o.og_number)),
    location,
    available: true,
    verified: true,
    bio,
    skills,
    tools: tools.length ? tools : ["Lovable"],
    rating: 5.0,
    reviews: 0,
    followers: 0,
    following: 0,
    projects: 0,
    industry: ["SaaS"],
    type,
    experience: "Expert",
    hourlyRate: 5000,
    is_demo: false,
  };
}

/** Shape an OG member as a SuggestedPerson (feed sidebars). */
export function ogToSuggested(o: OgMember): SuggestedPerson {
  const name = o.full_name || o.username || `OG #${o.og_number}`;
  const ai = o.ai_content ?? {};
  return {
    id: `og-${o.og_number}`,
    username: o.username,
    display_name: name,
    avatar_url: AVATAR(o.username || String(o.og_number)),
    bio: (ai.headline as string) || o.wall_tagline || `OG Founding Member · #${o.og_number}`,
    roles: ["builder"],
    availability_status: "available",
    follower_count: 0,
  };
}
