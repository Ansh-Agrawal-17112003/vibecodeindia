import type { Tool } from "@/lib/mock-data";

function domainOf(url: string): string | null {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

// Returns an ordered list of logo URLs to try. The consumer falls back to
// the next source when an <img> fails to load, and finally to an initial.
export function getToolLogoSources(t: Tool): string[] {
  const out: string[] = [];
  const domain = domainOf(t.url);
  if (domain) {
    // Google's favicon service is the most reliable — returns a real logo for
    // essentially every live domain and is CDN-cached.
    out.push(`https://www.google.com/s2/favicons?domain=${domain}&sz=128`);
    // DuckDuckGo icon service — good higher-resolution fallback.
    out.push(`https://icons.duckduckgo.com/ip3/${domain}.ico`);
  }
  if (t.logoSlug) {
    out.push(`https://cdn.simpleicons.org/${t.logoSlug}`);
  }
  return out;
}
