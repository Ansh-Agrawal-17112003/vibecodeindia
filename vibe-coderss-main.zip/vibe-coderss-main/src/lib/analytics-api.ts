import { supabase } from "@/integrations/supabase/client";

export type OverviewAnalytics = {
  views_window: number;
  views_prev_window: number;
  views_growth_pct: number | null;
  total_views_all_time: number;
  followers: number;
  following: number;
  new_followers: number;
  posts: number;
  likes_received: number;
  comments_received: number;
  search_appearances: number;
  engagement_rate: number;
  daily_trend: { day: string; views: number }[];
};

export type ViewerBreakdown = {
  by_title: { label: string; n: number }[];
  by_location: { label: string; n: number }[];
  top_viewers: {
    id: string;
    display_name: string | null;
    username: string | null;
    avatar_url: string | null;
    title: string | null;
    view_count: number;
    last_view: string;
  }[];
  repeat_viewers: number;
};

export type ContentAnalytics = {
  posts: {
    id: string;
    excerpt: string;
    kind: string;
    like_count: number;
    comment_count: number;
    repost_count: number;
    reaction_counts: Record<string, number> | null;
    created_at: string;
    score: number;
    has_media: boolean;
  }[];
  best_time_heatmap: { dow: number; hour: number; posts: number; engagement: number }[];
  media_vs_text: { media: number; text: number; media_count: number; text_count: number };
  reaction_mix: { like: number; fire: number; celebrate: number; insightful: number };
};

export type HiringAnalytics = {
  jobs_active: number;
  jobs_closed: number;
  applications_total: number;
  applications_pro: number;
  applications_free: number;
  by_status: Record<string, number>;
  by_seniority: { label: string; n: number }[];
  by_location: { label: string; n: number }[];
  top_skills: { label: string; n: number }[];
  avg_applicant_xp: number;
  avg_hours_to_first_app: number;
  jobs: {
    id: string;
    title: string;
    status: string;
    created_at: string;
    applications: number;
    saves: number;
  }[];
};

export async function fetchOverview(userId: string, days = 30): Promise<OverviewAnalytics | null> {
  const { data, error } = await (supabase.rpc as any)("get_profile_analytics", {
    p_user: userId,
    p_days: days,
  });
  if (error) {
    console.error("get_profile_analytics", error);
    return null;
  }
  return data as OverviewAnalytics;
}

export async function fetchViewers(userId: string, days = 30): Promise<ViewerBreakdown | null> {
  const { data, error } = await (supabase.rpc as any)("get_viewer_breakdown", {
    p_user: userId,
    p_days: days,
  });
  if (error) {
    console.error("get_viewer_breakdown", error);
    return null;
  }
  return data as ViewerBreakdown;
}

export async function fetchContent(userId: string, days = 30): Promise<ContentAnalytics | null> {
  const { data, error } = await (supabase.rpc as any)("get_content_analytics", {
    p_user: userId,
    p_days: days,
  });
  if (error) {
    console.error("get_content_analytics", error);
    return null;
  }
  return data as ContentAnalytics;
}

export async function fetchHiring(companyId: string, days = 30): Promise<HiringAnalytics | null> {
  const { data, error } = await (supabase.rpc as any)("get_hiring_analytics", {
    p_company: companyId,
    p_days: days,
  });
  if (error) {
    console.error("get_hiring_analytics", error);
    return null;
  }
  return data as HiringAnalytics;
}
