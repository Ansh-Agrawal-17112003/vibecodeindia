// Server-only. Content library + persona list for the seed-bot engagement system.
// Not imported from any client-reachable module.

export type SeedPersona = {
  handle: string; // username + email localpart
  name: string;
  bio: string;
  avatarSeed: string;
};

export const SEED_PERSONAS: SeedPersona[] = [
  { handle: "aarav_builds", name: "Aarav Mehta", bio: "Full-stack AI builder · Bangalore · shipping weekly", avatarSeed: "aarav" },
  { handle: "priya_ships", name: "Priya Sharma", bio: "Automating workflows with n8n + Lovable · Pune", avatarSeed: "priya" },
  { handle: "rohan_v", name: "Rohan Verma", bio: "Indie hacker · AI SaaS · Delhi NCR", avatarSeed: "rohan" },
  { handle: "ananya_ai", name: "Ananya Iyer", bio: "Prompt engineer · GenAI at a stealth startup · Chennai", avatarSeed: "ananya" },
  { handle: "vikram_rao", name: "Vikram Rao", bio: "Founder building an AI copilot for sales · Hyderabad", avatarSeed: "vikram" },
  { handle: "sneha_k", name: "Sneha Kapoor", bio: "Design + AI · shipping micro-SaaS on weekends", avatarSeed: "sneha" },
  { handle: "arjun_nair", name: "Arjun Nair", bio: "ML engineer turned indie builder · Kochi", avatarSeed: "arjun" },
  { handle: "ishita_b", name: "Ishita Bose", bio: "Notion + Lovable stack · community builder · Kolkata", avatarSeed: "ishita" },
  { handle: "kunal_dev", name: "Kunal Desai", bio: "Backend + Supabase · love clean APIs · Ahmedabad", avatarSeed: "kunal" },
  { handle: "meera_j", name: "Meera Joshi", bio: "Product designer · shipping AI tools for creators", avatarSeed: "meera" },
  { handle: "sid_g", name: "Siddharth Gupta", bio: "Fullstack · Lovable + n8n · Mumbai", avatarSeed: "sid" },
  { handle: "riya_writes", name: "Riya Patel", bio: "Content + growth · writing about AI builders · Bangalore", avatarSeed: "riya" },
  { handle: "dev_shah", name: "Dev Shah", bio: "Solo founder · AI voice agents · Surat", avatarSeed: "dev" },
  { handle: "tara_m", name: "Tara Malhotra", bio: "Automations · Zapier + n8n consultant · Gurgaon", avatarSeed: "tara" },
  { handle: "yash_r", name: "Yash Reddy", bio: "Agentic workflows · shipping in public · Bangalore", avatarSeed: "yash" },
];

// Reaction distribution — bots leave 5-9 reactions on each quiet post.
const REACTION_TYPES = ["like", "like", "like", "fire", "fire", "celebrate", "insightful"];

// Comment templates. `{{author}}` becomes @username, `{{title}}` becomes a short title fallback.
const COMMENT_TEMPLATES = [
  "Love this @{{author}} 🔥 keep shipping!",
  "This is really clean @{{author}} — how long did it take you end to end?",
  "@{{author}} congrats on the ship! Any plans to open source it?",
  "@{{author}} bookmarking this. The direction here is 🔥",
  "This is exactly the kind of build I love seeing on VibeCode @{{author}} 🙌",
  "@{{author}} following you for more of this. What's the stack?",
  "Solid work @{{author}} — the framing is spot on.",
  "Curious to hear how you plan to scale this @{{author}} 👀",
  "@{{author}} this made my morning. Ship v2 soon 🚀",
  "@{{author}} tried something similar last month, yours is way cleaner 👏",
  "Big fan of this angle @{{author}} — most people miss it.",
  "@{{author}} keep going, this has real legs.",
  "@{{author}} would love a short teardown post on how you built it.",
  "Very underrated @{{author}} 🔥",
];

// DM templates — short, warm, feels like a real builder reaching out.
const DM_TEMPLATES = [
  "hey {{firstName}}! saw your post — genuinely impressed. would love to chat sometime 🙌",
  "yo, this is fire {{firstName}}. mind if I share it with a few builder friends?",
  "{{firstName}} congrats on shipping! I'm working on something adjacent — coffee call this week?",
  "hey! new here too? your build looks 🔥 keep going",
  "{{firstName}} loved your post. following you now, ping me if you ever want feedback on v2",
  "seriously nice work {{firstName}} 👏 what's next for the project?",
  "{{firstName}} this is exactly what I needed today. thanks for shipping in public 🙏",
  "yo {{firstName}}, big fan of the approach. lmk if you're open to collab",
];

function shuffle<T>(arr: T[], seed: number): T[] {
  const a = [...arr];
  let s = seed || 1;
  for (let i = a.length - 1; i > 0; i--) {
    s = (s * 9301 + 49297) % 233280;
    const j = Math.floor((s / 233280) * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function pickBots<T>(bots: T[], count: number, seed: number): T[] {
  return shuffle(bots, seed).slice(0, Math.min(count, bots.length));
}

export function pickReactions(count: number, seed: number): string[] {
  return shuffle(REACTION_TYPES, seed).slice(0, count);
}

export function renderComments(count: number, seed: number, vars: { author: string; title: string }): string[] {
  return shuffle(COMMENT_TEMPLATES, seed)
    .slice(0, count)
    .map((t) => t.replaceAll("{{author}}", vars.author).replaceAll("{{title}}", vars.title));
}

export function renderDMs(count: number, seed: number, vars: { firstName: string }): string[] {
  return shuffle(DM_TEMPLATES, seed)
    .slice(0, count)
    .map((t) => t.replaceAll("{{firstName}}", vars.firstName));
}

// How many bots do what for a single quiet post.
export const ENGAGEMENT_PLAN = {
  reactions: { min: 5, max: 9 },
  comments: { min: 2, max: 4 },
  dms: { min: 3, max: 5 },
};

export function randInRange(min: number, max: number, seed: number): number {
  const s = (seed * 9301 + 49297) % 233280;
  return min + Math.floor((s / 233280) * (max - min + 1));
}
