// Deterministic seed data for the immersive community inside page.
// All state is client-side; polls/RSVPs/reactions/comments persist in localStorage.
import { builders } from "@/lib/mock-data";

export type Reactions = { like: number; celebrate: number; fire: number; insightful: number; support: number };
export type ReactionKey = keyof Reactions;

export type Comment = { id: string; builderIdx: number; body: string; likes: number; time: string; replies?: Comment[] };

export type PostType = "post" | "prompt" | "workflow" | "poll" | "event" | "resource" | "question";

export type BasePost = {
  id: string;
  type: PostType;
  builderIdx: number;
  title?: string;
  body: string;
  tags: string[];
  reactions: Reactions;
  views: number;
  time: string;
  pinned?: boolean;
  media?: { kind: "gradient"; a: string; b: string };
  comments: Comment[];
  // type-specific
  pollOptions?: { text: string; votes: number }[];
  pollEndsAt?: string;
  eventTitle?: string;
  eventWhen?: string;
  eventLocation?: string;
  eventLocationType?: "online" | "in-person";
  eventGoing?: number;
  resourceUrl?: string;
  resourceCategory?: string;
};

export type Resource = { id: string; title: string; category: string; builderIdx: number; date: string; downloads: number; rating: number; kind: "Guide" | "Video" | "Template" | "Prompt Pack" | "Workflow" };
export type CalendarEvent = { id: string; day: number; month: string; title: string; when: string; location: string; organizerIdx: number; going: number };
export type Rule = string;

const hash = (s: string) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); };
const seededRand = (seed: number) => { let s = seed || 1; return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; }; };
const pickN = <T,>(arr: T[], seed: number, n: number): T[] => {
  const out: T[] = []; const used = new Set<number>(); const rnd = seededRand(seed);
  while (out.length < Math.min(n, arr.length)) { const i = Math.floor(rnd() * arr.length); if (!used.has(i)) { used.add(i); out.push(arr[i]); } }
  return out;
};

const GRADIENTS = [
  { a: "#E8623A", b: "#F5A623" }, { a: "#2DD4BF", b: "#0F0F0F" }, { a: "#7C3AED", b: "#FF4D8D" },
  { a: "#F5A623", b: "#E8623A" }, { a: "#22C55E", b: "#2DD4BF" }, { a: "#0F0F0F", b: "#7C3AED" },
];

const SAMPLE_COMMENTS = [
  "This is exactly what I needed today. Saving it.",
  "Ran into the same wall last week — thanks for writing it up.",
  "Curious how this scales past 10k users?",
  "Beautiful work 🔥 keep shipping.",
  "Any chance you'd open-source the template?",
  "Loved the breakdown. The prompt structure at the end is gold.",
  "Just tried this — worked first try. Wild.",
  "Bookmarking this for our next sprint.",
];

export function communityId(slug: string) { return hash(slug); }

export function getPosts(slug: string, name: string): BasePost[] {
  const h = hash(slug);
  const subject = name.replace(/\s*(Builders|Creators|Power Users|Community|India|Automation)\s*/gi, "").trim() || name;
  const rnd = seededRand(h);
  const mkReactions = (i: number): Reactions => ({
    like: 40 + Math.floor(rnd() * 160), celebrate: 6 + Math.floor(rnd() * 40),
    fire: 10 + Math.floor(rnd() * 60), insightful: 8 + Math.floor(rnd() * 30), support: 4 + Math.floor(rnd() * 20),
  });
  const mkComments = (i: number, n: number): Comment[] =>
    Array.from({ length: n }).map((_, k) => ({
      id: `${i}-${k}`, builderIdx: (h + i * 7 + k * 3) % builders.length,
      body: SAMPLE_COMMENTS[(h + i + k) % SAMPLE_COMMENTS.length],
      likes: Math.floor(rnd() * 24), time: `${k + 1}h ago`,
    }));
  const times = ["2h ago", "5h ago", "8h ago", "yesterday", "2d ago", "3d ago", "4d ago", "1w ago"];
  const tags = [["#ai-agents", "#automation"], ["#workflows", "#n8n"], ["#showcase"], ["#help", "#question"], ["#jobs"], ["#resource"], ["#prompt"], ["#poll"]];

  const posts: BasePost[] = [
    {
      id: "pin-1", type: "post", builderIdx: 1, pinned: true,
      title: `Welcome to ${name}! Read this first`,
      body: `Introduce yourself in #general, check the pinned starter pack, and drop your first ${subject} build in Showcase. We celebrate every ship — big or small.`,
      tags: ["#welcome", "#start-here"], reactions: mkReactions(0), views: 3400, time: "3d ago",
      comments: mkComments(0, 4),
    },
    {
      id: "pin-2", type: "resource", builderIdx: 6, pinned: true,
      title: `${subject} Starter Pack — 2026 edition`,
      body: `Hand-picked docs, videos, templates, and prompts. Everything you need to go from zero to first ship in a weekend.`,
      tags: ["#resource", "#starter"], reactions: mkReactions(1), views: 2100, time: "5d ago",
      resourceUrl: "https://vibecoder.app/resources/starter", resourceCategory: "Guide",
      comments: mkComments(1, 3),
    },
    {
      id: "p-3", type: "showcase" as any, builderIdx: 2,
      title: `Shipped my first ${subject} tool this weekend 🚀`,
      body: `Built a tiny app in 12 hours with Lovable + Supabase. 200 signups in 48h. Would love feedback from the community before v2.`,
      tags: ["#showcase", "#lovable"], reactions: mkReactions(2), views: 1800, time: times[0],
      media: { kind: "gradient", ...GRADIENTS[h % GRADIENTS.length] },
      comments: mkComments(2, 6),
    },
    {
      id: "p-4", type: "poll", builderIdx: 3,
      title: `What's your biggest ${subject} blocker right now?`,
      body: `Trying to decide what to write the next deep-dive on. Vote below 👇`,
      tags: ["#poll"], reactions: mkReactions(3), views: 2600, time: times[1],
      pollOptions: [
        { text: "Cost & token spend", votes: 34 },
        { text: "Reliability at scale", votes: 22 },
        { text: "Evals / QA", votes: 18 },
        { text: "Team workflows", votes: 9 },
      ],
      pollEndsAt: "in 2 days",
      comments: mkComments(3, 5),
    },
    {
      id: "p-5", type: "event", builderIdx: 4,
      title: `Live: ${subject} Workshop — Build in 90 min`,
      body: `Hands-on session with 3 seasoned builders. Bring your laptop. We'll build and deploy live.`,
      tags: ["#event", "#workshop"], reactions: mkReactions(4), views: 3100, time: times[2],
      eventTitle: `${subject} Workshop — Build in 90 min`,
      eventWhen: "Sat, Jul 12 · 7:00 PM IST", eventLocation: "Online — Zoom", eventLocationType: "online",
      eventGoing: 128,
      comments: mkComments(4, 4),
    },
    {
      id: "p-6", type: "prompt", builderIdx: 5,
      title: `The one-shot prompt that replaced my whole outreach flow`,
      body: `Been iterating for 6 weeks. Now it writes personalized cold emails in my voice. Full prompt + variables in the comments.`,
      tags: ["#prompt", "#growth"], reactions: mkReactions(5), views: 4200, time: times[3],
      comments: mkComments(5, 8),
    },
    {
      id: "p-7", type: "workflow", builderIdx: 6,
      title: `n8n workflow: auto-enrich leads → Slack → CRM in 3 minutes`,
      body: `Free download. Handles rate limits, retries, and dedupes on email. Full JSON attached.`,
      tags: ["#workflow", "#n8n"], reactions: mkReactions(6), views: 1900, time: times[4],
      comments: mkComments(6, 3),
    },
    {
      id: "p-8", type: "question", builderIdx: 7,
      title: `Best pattern for long-running ${subject} jobs?`,
      body: `Pipeline is 8–10 min end-to-end. What's your favorite async + notification pattern? Trigger.dev? Inngest? Roll your own?`,
      tags: ["#question", "#help"], reactions: mkReactions(7), views: 1100, time: times[5],
      comments: mkComments(7, 7),
    },
    {
      id: "p-9", type: "post", builderIdx: 8,
      title: `Replaced a ₹40K/mo SaaS with a 100-line ${subject} workflow`,
      body: `Full breakdown of the schema, prompts, and gotchas. Open-sourced the template — link in comments.`,
      tags: ["#showcase", "#savings"], reactions: mkReactions(8), views: 5800, time: times[6],
      media: { kind: "gradient", ...GRADIENTS[(h + 2) % GRADIENTS.length] },
      comments: mkComments(8, 9),
    },
    {
      id: "p-10", type: "resource", builderIdx: 9,
      title: `${subject} cheatsheet — printable, 1 page`,
      body: `Distilled 3 months of notes into one page. Bookmark it on your monitor. Free, no email required.`,
      tags: ["#resource", "#cheatsheet"], reactions: mkReactions(9), views: 2300, time: times[7],
      resourceUrl: "https://vibecoder.app/cheatsheet", resourceCategory: "Guide",
      comments: mkComments(9, 2),
    },
  ];
  // normalize showcase → post
  return posts.map((p) => ({ ...p, type: (p.type as any) === "showcase" ? "post" : p.type }));
}

export function getTopics(slug: string) {
  const h = hash(slug);
  const base = ["general", "ai-agents", "automation", "workflows", "showcase", "jobs", "prompts", "help"];
  return base.map((n, i) => ({ name: n, count: 200 + ((h + i * 137) % 1400) }));
}

export function getResources(slug: string, name: string): Resource[] {
  const h = hash(slug);
  const s = name.split(" ")[0];
  const kinds: Resource["kind"][] = ["Guide", "Video", "Template", "Prompt Pack", "Workflow"];
  return Array.from({ length: 12 }).map((_, i) => ({
    id: `r-${i}`,
    title: `${s} ${kinds[i % kinds.length]}: ${["Getting Started", "Advanced Patterns", "Cost Optimization", "Eval Playbook", "Team Setup", "Deployment", "Growth Loops", "Cold Outreach", "Client Onboarding", "Pricing", "Analytics", "Case Study"][i]}`,
    category: kinds[i % kinds.length],
    kind: kinds[i % kinds.length],
    builderIdx: (h + i * 5) % builders.length,
    date: ["1d ago", "3d ago", "5d ago", "1w ago", "2w ago"][i % 5],
    downloads: 40 + ((h + i * 91) % 1200),
    rating: 4.3 + ((h + i * 17) % 8) / 10,
  }));
}

export function getEvents(slug: string, name: string): CalendarEvent[] {
  const h = hash(slug);
  const s = name.split(" ")[0];
  const months = ["JUL", "AUG"];
  return Array.from({ length: 6 }).map((_, i) => ({
    id: `e-${i}`,
    day: 4 + ((h + i * 13) % 24),
    month: months[i % 2],
    title: [`${s} Workshop`, `${s} AMA`, `Live Build: ${s}`, `Office Hours`, `${s} Meetup`, `Community Ship Day`][i],
    when: `${months[i % 2]} ${4 + ((h + i * 13) % 24)}, 2026 · ${6 + i}:00 PM IST`,
    location: i % 2 === 0 ? "Online — Zoom" : "Bangalore · WeWork Prestige",
    organizerIdx: (h + i * 3) % builders.length,
    going: 30 + ((h + i * 53) % 220),
  }));
}

export function getLeaderboard(slug: string) {
  const h = hash(slug);
  const shuffled = pickN(builders, h, builders.length);
  return shuffled.map((b, i) => ({
    rank: i + 1,
    builder: b,
    level: ["Vibe Legend", "Vibe Pro", "Vibe Maker", "Vibe Builder", "Vibe Builder"][Math.min(i, 4)],
    points: Math.max(500, 14000 - i * (900 + (h % 200))),
  }));
}

export function getRules(): Rule[] {
  return [
    "Be respectful and constructive — assume good intent.",
    "Share only AI-related content that adds value.",
    "No spam, no unsolicited DMs, no low-effort promotion.",
    "Credit original creators when you share their work.",
    "Help others — we grow when we grow together.",
  ];
}

export const REACTION_META: Record<ReactionKey, { emoji: string; label: string }> = {
  like: { emoji: "👍", label: "Like" },
  celebrate: { emoji: "🎉", label: "Celebrate" },
  fire: { emoji: "🔥", label: "Fire" },
  insightful: { emoji: "💡", label: "Insightful" },
  support: { emoji: "🤝", label: "Support" },
};

export function reactionTotal(r: Reactions) { return r.like + r.celebrate + r.fire + r.insightful + r.support; }

// localStorage helpers -----------------------------------------------------
const KEY = "vc:community-state";
type PerSlugState = {
  votes: Record<string, number>; // postId -> optionIdx
  rsvps: Record<string, boolean>;
  reactions: Record<string, ReactionKey>; // postId -> user's reaction
  saved: Record<string, boolean>;
};

function readAll(): Record<string, PerSlugState> {
  if (typeof window === "undefined") return {};
  try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { return {}; }
}
function writeAll(v: Record<string, PerSlugState>) { localStorage.setItem(KEY, JSON.stringify(v)); }

export function loadSlugState(slug: string): PerSlugState {
  const all = readAll();
  return all[slug] ?? { votes: {}, rsvps: {}, reactions: {}, saved: {} };
}
export function saveSlugState(slug: string, state: PerSlugState) {
  const all = readAll();
  all[slug] = state;
  writeAll(all);
}
