import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(supabase: any, userId: string, requireSuper = false) {
  const { data, error } = await supabase.from("profiles").select("role").eq("id", userId).maybeSingle();
  if (error || !data) throw new Error("Forbidden");
  const role = (data as any).role;
  if (requireSuper && role !== "super_admin") throw new Error("Super admin only");
  if (!requireSuper && role !== "super_admin" && role !== "admin") throw new Error("Admin only");
  return role as "super_admin" | "admin" | "user";
}

// ---------------------------------------------------------------------------
// assignRole — super_admin only. Cannot assign super_admin via API.
// ---------------------------------------------------------------------------
export const assignRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      target_user_id: z.string().uuid(),
      new_role: z.enum(["admin", "user"]),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Never overwrite an existing super_admin
    const { data: target } = await (supabaseAdmin.from("profiles") as any).select("role").eq("id", data.target_user_id).maybeSingle();
    if ((target as any)?.role === "super_admin") throw new Error("Cannot modify a super admin");
    const { error } = await (supabaseAdmin.from("profiles") as any).update({ role: data.new_role }).eq("id", data.target_user_id);
    if (error) throw new Error(error.message);
    return { success: true };
  });

// ---------------------------------------------------------------------------
// banUser — admin+. Sets is_banned and ban_reason.
// ---------------------------------------------------------------------------
export const banUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      target_user_id: z.string().uuid(),
      ban: z.boolean(),
      reason: z.string().max(500).optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, false);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: target } = await (supabaseAdmin.from("profiles") as any).select("role").eq("id", data.target_user_id).maybeSingle();
    if ((target as any)?.role === "super_admin") throw new Error("Cannot ban a super admin");
    const { error } = await (supabaseAdmin.from("profiles") as any).update({
      is_banned: data.ban,
      ban_reason: data.ban ? (data.reason ?? null) : null,
    }).eq("id", data.target_user_id);
    if (error) throw new Error(error.message);
    return { success: true };
  });

// ---------------------------------------------------------------------------
// suspendUser — admin+. Sets suspended_until.
// ---------------------------------------------------------------------------
export const suspendUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      target_user_id: z.string().uuid(),
      days: z.number().int().min(0).max(365),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, false);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const patch = data.days > 0
      ? { is_suspended: true, suspended_until: new Date(Date.now() + data.days * 86400_000).toISOString() }
      : { is_suspended: false, suspended_until: null };
    const { error } = await (supabaseAdmin.from("profiles") as any).update(patch).eq("id", data.target_user_id);
    if (error) throw new Error(error.message);
    return { success: true };
  });

// ---------------------------------------------------------------------------
// getAdminStats — admin+. Returns dashboard counts.
// ---------------------------------------------------------------------------
export const getAdminStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId, false);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const dayAgo = new Date(Date.now() - 86400_000).toISOString();
    const weekAgo = new Date(Date.now() - 7 * 86400_000).toISOString();

    const count = async (table: string, filter?: (q: any) => any) => {
      let q: any = (supabaseAdmin as any).from(table).select("*", { count: "exact", head: true });
      if (filter) q = filter(q);
      const { count: c } = await q;
      return c ?? 0;
    };

    const [
      totalUsers, newSignupsToday, newSignupsWeek,
      totalCommunities, communitiesWeek,
      totalJobs, jobsToday,
      totalProjects, projectsWeek,
      totalPosts, postsToday,
      pendingReports, totalTemplates,
    ] = await Promise.all([
      count("profiles"),
      count("profiles", (q) => q.gte("created_at", dayAgo)),
      count("profiles", (q) => q.gte("created_at", weekAgo)),
      count("communities"),
      count("communities", (q) => q.gte("created_at", weekAgo)),
      count("jobs"),
      count("jobs", (q) => q.gte("created_at", dayAgo)),
      count("projects"),
      count("projects", (q) => q.gte("created_at", weekAgo)),
      count("posts").catch(() => 0),
      count("posts", (q) => q.gte("created_at", dayAgo)).catch(() => 0),
      count("reports", (q) => q.eq("status", "pending")).catch(() => 0),
      count("services").catch(() => 0),
    ]);

    return {
      totalUsers, newSignupsToday, newSignupsWeek,
      activeToday: newSignupsToday, // proxy — refine later
      totalCommunities, communitiesWeek,
      totalJobs, jobsToday,
      totalProjects, projectsWeek,
      totalPosts, postsToday,
      pendingReports, totalTemplates,
    };
  });

// ---------------------------------------------------------------------------
// listUsers — admin+. Paginated user list with search.
// ---------------------------------------------------------------------------
export const listUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      search: z.string().optional(),
      role: z.enum(["all", "super_admin", "admin", "user"]).default("all"),
      status: z.enum(["all", "active", "banned", "suspended"]).default("all"),
      limit: z.number().int().min(1).max(100).default(25),
      offset: z.number().int().min(0).default(0),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, false);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let q: any = supabaseAdmin
      .from("profiles")
      .select("id, display_name, avatar_url, role, is_banned, is_suspended, suspended_until, created_at, last_active_at", { count: "exact" })
      .order("created_at", { ascending: false });
    if (data.search) q = q.ilike("display_name", `%${data.search}%`);
    if (data.role !== "all") q = q.eq("role", data.role);
    if (data.status === "banned") q = q.eq("is_banned", true);
    if (data.status === "suspended") q = q.eq("is_suspended", true);
    if (data.status === "active") q = q.eq("is_banned", false).eq("is_suspended", false);
    q = q.range(data.offset, data.offset + data.limit - 1);
    const { data: rows, count, error } = await q;
    if (error) throw new Error(error.message);
    return { rows: rows ?? [], count: count ?? 0 };
  });

// ---------------------------------------------------------------------------
// listReports — admin+. Pending moderation queue.
// ---------------------------------------------------------------------------
export const listReports = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ status: z.enum(["all","pending","resolved","dismissed"]).default("pending"), limit: z.number().int().min(1).max(100).default(25) }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, false);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let q: any = (supabaseAdmin as any).from("reports").select("*").order("created_at", { ascending: false }).limit(data.limit);
    if (data.status !== "all") q = q.eq("status", data.status);
    const { data: rows, error } = await q;
    if (error) return { rows: [] };
    return { rows: rows ?? [] };
  });
