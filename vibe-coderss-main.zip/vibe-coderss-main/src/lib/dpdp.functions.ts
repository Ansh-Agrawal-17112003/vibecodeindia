import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Tables that hold data owned by / about a user. Each entry: table name + the
// column that references the user's profile id (which equals auth.users.id).
const USER_TABLES: Array<{ table: string; col: string }> = [
  { table: "profiles", col: "id" },
  { table: "builder_details", col: "profile_id" },
  { table: "subscriptions", col: "profile_id" },
  { table: "subscription_requests", col: "profile_id" },
  { table: "projects", col: "builder_id" },
  { table: "services", col: "builder_id" },
  { table: "jobs", col: "posted_by" },
  { table: "job_applications", col: "applicant_id" },
  { table: "saved_jobs", col: "profile_id" },
  { table: "posts", col: "author_id" },
  { table: "post_comments", col: "author_id" },
  { table: "post_likes", col: "user_id" },
  { table: "post_reactions", col: "user_id" },
  { table: "post_bookmarks", col: "user_id" },
  { table: "post_reports", col: "reporter_id" },
  { table: "prompts", col: "author_id" },
  { table: "workflows", col: "author_id" },
  { table: "templates", col: "author_id" },
  { table: "ai_tools", col: "submitted_by" },
  { table: "reviews", col: "author_id" },
  { table: "upvotes", col: "profile_id" },
  { table: "follows", col: "follower_id" },
  { table: "notifications", col: "user_id" },
  { table: "messages", col: "sender_id" },
  { table: "conversations", col: "user_a" },
  { table: "communities", col: "created_by" },
  { table: "community_members", col: "profile_id" },
  { table: "community_lectures", col: "uploader_id" },
  { table: "lecture_views", col: "profile_id" },
  { table: "profile_views", col: "viewed_profile_id" },
  { table: "search_appearances", col: "profile_id" },
  { table: "search_usage", col: "profile_id" },
  { table: "xp_transactions", col: "profile_id" },
  { table: "vibecoin_transactions", col: "profile_id" },
  { table: "vibecoin_redemptions", col: "profile_id" },
  { table: "og_members", col: "profile_id" },
  { table: "bug_reports", col: "reporter_id" },
  { table: "companies", col: "owner_profile_id" },
];

// ---------------------------------------------------------------------------
// exportMyData — DPDP §11 Right to Access. Returns a JSON bundle of everything
// this account owns across the platform. Runs as the signed-in user with RLS.
// ---------------------------------------------------------------------------
export const exportMyData = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const uid = context.userId;
    const bundle: Record<string, unknown> = {
      exported_at: new Date().toISOString(),
      user_id: uid,
    };

    // Load privileged admin client so we can also pull auth.users identity data.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // auth.users summary (email, created_at, providers) — user's own record only.
    try {
      const { data: authUser } = await (supabaseAdmin as any).auth.admin.getUserById(uid);
      if (authUser?.user) {
        bundle.auth = {
          id: authUser.user.id,
          email: authUser.user.email,
          phone: authUser.user.phone,
          created_at: authUser.user.created_at,
          last_sign_in_at: authUser.user.last_sign_in_at,
          providers: authUser.user.app_metadata?.providers,
          user_metadata: authUser.user.user_metadata,
        };
      }
    } catch {
      // non-fatal
    }

    for (const { table, col } of USER_TABLES) {
      try {
        const { data, error } = await (supabaseAdmin as any)
          .from(table)
          .select("*")
          .eq(col, uid);
        if (!error) bundle[table] = data ?? [];
      } catch {
        // skip tables that don't exist or fail
      }
    }

    // Conversations where the user is user_b too (covered separately)
    try {
      const { data } = await (supabaseAdmin as any)
        .from("conversations")
        .select("*")
        .or(`user_a.eq.${uid},user_b.eq.${uid}`);
      bundle.conversations = data ?? [];
    } catch {
      // ignore
    }

    return { json: JSON.stringify(bundle, null, 2) };
  });


// ---------------------------------------------------------------------------
// deleteMyAccount — DPDP §12 Right to Erasure. Requires the user to type
// "DELETE" to confirm. Removes the auth user; ON DELETE CASCADE removes
// profiles + downstream owned rows.
// ---------------------------------------------------------------------------
export const deleteMyAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ confirm: z.literal("DELETE") }).parse(input),
  )
  .handler(async ({ context }) => {
    const uid = context.userId;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Best-effort clean-up of rows that don't cascade from auth.users.
    const bestEffort = [
      "notifications",
      "messages",
      "post_reports",
      "search_appearances",
      "profile_views",
      "lecture_views",
      "vibecoin_transactions",
      "xp_transactions",
    ];
    for (const t of bestEffort) {
      try {
        await (supabaseAdmin as any).from(t).delete().eq(
          t === "notifications" ? "user_id" : t === "messages" ? "sender_id" : "profile_id",
          uid,
        );
      } catch {
        // ignore
      }
    }

    const { error } = await (supabaseAdmin as any).auth.admin.deleteUser(uid);
    if (error) throw new Error(error.message);
    return { success: true };
  });
