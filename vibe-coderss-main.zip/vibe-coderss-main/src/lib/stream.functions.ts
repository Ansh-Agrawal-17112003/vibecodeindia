import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { StreamChat } from "stream-chat";
import { seedChannelIfEmpty } from "@/lib/stream-seed";


function getStreamServer() {
  const key = process.env.STREAM_API_KEY;
  const secret = process.env.STREAM_API_SECRET;
  if (!key || !secret) {
    throw new Error("Stream Chat is not configured. STREAM_API_KEY / STREAM_API_SECRET missing.");
  }
  return { client: StreamChat.getInstance(key, secret), key };
}

/**
 * Returns everything the browser needs to connect to Stream Chat as the
 * signed-in user. Also upserts the user in Stream and mints a token.
 */
export const getStreamCredentials = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { client, key } = getStreamServer();
    const userId = context.userId;

    const { data: profile } = await context.supabase
      .from("profiles")
      .select("display_name, avatar_url")
      .eq("id", userId)
      .maybeSingle();

    const name = profile?.display_name ?? "Builder";
    const image = profile?.avatar_url ?? undefined;

    await client.upsertUser({ id: userId, name, image, role: "user" });
    const token = client.createToken(userId);

    return { apiKey: key, userId, userToken: token, name, image };
  });

/**
 * Join a community: inserts membership, then adds the user to every
 * Stream channel for that community. Idempotent.
 */
export const joinCommunityChannels = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { communitySlug: string }) => {
    if (!data?.communitySlug || typeof data.communitySlug !== "string") {
      throw new Error("communitySlug required");
    }
    return data;
  })
  .handler(async ({ data, context }) => {
    const { client } = getStreamServer();
    const userId = context.userId;

    // Look up community
    const { data: community, error: cErr } = await context.supabase
      .from("communities")
      .select("id, name, welcome_message")
      .eq("slug", data.communitySlug)
      .eq("status", "approved")
      .maybeSingle();

    if (cErr || !community) throw new Error("Community not found");

    // Insert membership (idempotent via ON CONFLICT)
    const { error: mErr } = await context.supabase
      .from("community_members")
      .upsert(
        { community_id: community.id, profile_id: userId, role: "member" },
        { onConflict: "community_id,profile_id" },
      );
    if (mErr) throw new Error(mErr.message);

    // Fetch topic channels
    const { data: channels } = await context.supabase
      .from("community_channels")
      .select("stream_channel_id")
      .eq("community_id", community.id);

    // Ensure user exists in Stream, then add to each channel
    const { data: profile } = await context.supabase
      .from("profiles")
      .select("display_name, avatar_url")
      .eq("id", userId)
      .maybeSingle();
    await client.upsertUser({
      id: userId,
      name: profile?.display_name ?? "Builder",
      image: profile?.avatar_url ?? undefined,
      role: "user",
    });

    const channelIds = (channels ?? []).map((c) => c.stream_channel_id);
    for (const cid of channelIds) {
      const channel = client.channel("messaging", cid, {
        // @ts-expect-error custom Stream field
        community_slug: data.communitySlug,
        name: `${community.name} · ${cid.split("-").pop()}`,
        created_by_id: userId,
      });
      try {
        await channel.create();
      } catch {
        // channel likely exists; ignore
      }
      try {
        await channel.addMembers([userId]);
      } catch {
        // already a member; ignore
      }
      // Seed lively bot conversation if the room is empty.
      try {
        await seedChannelIfEmpty(client, "messaging", cid);
      } catch (e) {
        console.error("seedChannelIfEmpty failed", cid, e);
      }
    }


    return {
      ok: true,
      communityId: community.id,
      channelIds,
      welcomeMessage: community.welcome_message,
    };
  });

/**
 * Leave a community: remove membership + demote from Stream channels.
 */
export const leaveCommunityChannels = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { communitySlug: string }) => data)
  .handler(async ({ data, context }) => {
    const { client } = getStreamServer();
    const userId = context.userId;

    const { data: community } = await context.supabase
      .from("communities")
      .select("id")
      .eq("slug", data.communitySlug)
      .maybeSingle();
    if (!community) return { ok: true };

    await context.supabase
      .from("community_members")
      .delete()
      .eq("community_id", community.id)
      .eq("profile_id", userId);

    const { data: channels } = await context.supabase
      .from("community_channels")
      .select("stream_channel_id")
      .eq("community_id", community.id);

    for (const c of channels ?? []) {
      try {
        const channel = client.channel("messaging", c.stream_channel_id);
        await channel.removeMembers([userId]);
      } catch {
        /* ignore */
      }
    }
    return { ok: true };
  });
