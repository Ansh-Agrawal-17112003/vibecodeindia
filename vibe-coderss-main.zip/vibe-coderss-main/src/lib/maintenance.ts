// Maintenance / early-access-only mode.
//
// While this is true, the LIVE site (custom domain + published lovable.app URL)
// will only serve /early-access. Every other path is redirected there.
//
// The editor PREVIEW host (id-preview--*.lovable.app, localhost, sandbox) is
// always exempt so you can keep building and previewing the full app.
//
// When you're ready to open the whole site to users, flip this to `false`
// and re-publish.
export const MAINTENANCE_MODE = true;

// Paths that stay reachable on live even in maintenance mode.
// Keep this minimal — legal pages + the early-access page itself.
const ALLOWED_LIVE_PATHS = new Set<string>([
  "/early-access",
  "/auth-callback",
  "/founders-wall",
  "/terms",
  "/privacy-policy",
]);

export function isPathAllowedInMaintenance(pathname: string): boolean {
  if (ALLOWED_LIVE_PATHS.has(pathname)) return true;
  // Allow any /api/* server route (webhooks, public JSON, etc.)
  if (pathname.startsWith("/api/")) return true;
  return false;
}

export function isEditorPreviewHost(host: string): boolean {
  if (!host) return false;
  if (host === "localhost" || host === "127.0.0.1") return true;
  // Lovable editor preview + sandbox variants
  if (host.startsWith("id-preview--")) return true;
  if (host.startsWith("preview--")) return true;
  if (host.endsWith(".lovableproject.com")) return true;
  if (host.endsWith(".sandbox.lovable.dev")) return true;
  if (host.endsWith(".lovable.dev")) return true;
  // Any *-dev.lovable.app subdomain (dev preview alias)
  if (/-dev\.lovable\.app$/.test(host)) return true;
  return false;
}

export function shouldGateHost(host: string): boolean {
  return MAINTENANCE_MODE && !isEditorPreviewHost(host);
}
