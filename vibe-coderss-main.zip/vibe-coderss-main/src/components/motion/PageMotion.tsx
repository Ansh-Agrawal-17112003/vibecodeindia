import { useEffect, useRef, type ReactNode } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

/** Dotted trail — a soft dotted trail that follows the native cursor. */
export function DottedArrowCursor() {
  const dotsRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.matchMedia("(pointer: coarse)").matches) return;

    const DOT_COUNT = 6;
    const dotsWrap = dotsRef.current;
    if (!dotsWrap) return;

    const dots: HTMLDivElement[] = [];
    for (let i = 0; i < DOT_COUNT; i++) {
      const d = document.createElement("div");
      const size = 6 - i * 0.6;
      d.style.cssText = `position:fixed;left:0;top:0;width:${size}px;height:${size}px;border-radius:9999px;background:#0f0f0f;opacity:${0.5 - i * 0.07};pointer-events:none;transform:translate3d(-100px,-100px,0);will-change:transform;`;
      dotsWrap.appendChild(d);
      dots.push(d);
    }

    let tx = -100, ty = -100;
    const trail = Array.from({ length: DOT_COUNT }, () => ({ x: -100, y: -100 }));
    let ax = -100, ay = -100;
    let raf = 0;
    let visible = false;

    const onMove = (e: PointerEvent) => {
      tx = e.clientX; ty = e.clientY;
      if (!visible) { visible = true; dotsWrap.style.opacity = "1"; }
    };
    const onLeave = () => { visible = false; dotsWrap.style.opacity = "0"; };

    const tick = () => {
      ax += (tx - ax) * 0.35;
      ay += (ty - ay) * 0.35;
      let px = ax, py = ay;
      for (let i = 0; i < DOT_COUNT; i++) {
        trail[i].x += (px - trail[i].x) * (0.28 - i * 0.03);
        trail[i].y += (py - trail[i].y) * (0.28 - i * 0.03);
        dots[i].style.transform = `translate3d(${trail[i].x - 3}px, ${trail[i].y - 3}px, 0)`;
        px = trail[i].x; py = trail[i].y;
      }
      raf = requestAnimationFrame(tick);
    };

    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerleave", onLeave);
    raf = requestAnimationFrame(tick);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerleave", onLeave);
      cancelAnimationFrame(raf);
      dots.forEach(d => d.remove());
    };
  }, []);

  return <div ref={dotsRef} aria-hidden className="pointer-events-none fixed inset-0 z-[9998] opacity-0 transition-opacity duration-300" />;
}

/** Ambient floating orbs behind content for gentle depth. */
export function AmbientOrbs() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      <div className="absolute -left-32 top-24 h-72 w-72 rounded-full bg-[radial-gradient(closest-side,rgba(245,166,35,0.18),transparent)] blur-2xl animate-float" />
      <div className="absolute right-[-6rem] top-[40vh] h-96 w-96 rounded-full bg-[radial-gradient(closest-side,rgba(232,98,58,0.14),transparent)] blur-2xl animate-float" style={{ animationDelay: "1.2s" }} />
      <div className="absolute left-1/3 bottom-[-4rem] h-80 w-80 rounded-full bg-[radial-gradient(closest-side,rgba(15,15,15,0.08),transparent)] blur-2xl animate-float" style={{ animationDelay: "2.4s" }} />
    </div>
  );
}

/** IntersectionObserver-driven reveal for [data-reveal] elements. */
export function RevealObserver() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      document.querySelectorAll<HTMLElement>("[data-reveal]").forEach(el => el.classList.add("is-visible"));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          io.unobserve(entry.target);
        }
      }
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });

    const scan = () => document.querySelectorAll<HTMLElement>("[data-reveal]:not(.is-visible)").forEach(el => io.observe(el));
    scan();
    const mo = new MutationObserver(scan);
    mo.observe(document.body, { childList: true, subtree: true });
    return () => { io.disconnect(); mo.disconnect(); };
  }, []);
  return null;
}

/** No-op passthrough — page transitions removed for instant navigation. */
export function PageTransition({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

/** Magnetic wrapper — child follows cursor slightly on hover. */
export function Magnetic({ children, strength = 0.25, className }: { children: ReactNode; strength?: number; className?: string }) {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 200, damping: 15, mass: 0.4 });
  const sy = useSpring(y, { stiffness: 200, damping: 15, mass: 0.4 });
  const ref = useRef<HTMLSpanElement>(null);
  return (
    <motion.span
      ref={ref}
      className={className}
      style={{ x: sx, y: sy, display: "inline-block" }}
      onPointerMove={(e) => {
        const el = ref.current; if (!el) return;
        const r = el.getBoundingClientRect();
        x.set((e.clientX - (r.left + r.width / 2)) * strength);
        y.set((e.clientY - (r.top + r.height / 2)) * strength);
      }}
      onPointerLeave={() => { x.set(0); y.set(0); }}
    >
      {children}
    </motion.span>
  );
}
