import { useEffect, useState } from "react";
import { Rocket } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

type BoostProfile = {
  id: string;
  subscription_plan: string | null;
  is_boosted: boolean | null;
  boost_expires_at: string | null;
  monthly_boosts_used: number | null;
  monthly_boosts_limit: number | null;
};

export function ProfileBoostCard() {
  const { user } = useAuth();
  const [p, setP] = useState<BoostProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const refresh = async () => {
    if (!user) return;
    const { data } = await (supabase.from("profiles") as any)
      .select(
        "id, subscription_plan, is_boosted, boost_expires_at, monthly_boosts_used, monthly_boosts_limit",
      )
      .eq("id", user.id)
      .maybeSingle();
    if (data) setP(data as BoostProfile);
  };

  useEffect(() => {
    refresh();
  }, [user?.id]);

  if (!p) return null;

  const canBoost = p.subscription_plan === "pro" || p.subscription_plan === "og_pro";
  const remaining = Math.max(0, (p.monthly_boosts_limit ?? 0) - (p.monthly_boosts_used ?? 0));
  const activeUntil = p.boost_expires_at ? new Date(p.boost_expires_at) : null;
  const isActive = !!(p.is_boosted && activeUntil && activeUntil > new Date());
  const daysLeft = isActive ? Math.ceil((activeUntil!.getTime() - Date.now()) / 86_400_000) : 0;

  const handleBoost = async () => {
    if (!user || !canBoost || remaining <= 0 || isActive) return;
    setLoading(true);
    setMsg(null);
    try {
      const { data, error } = await (supabase as any).rpc("activate_profile_boost", {
        p_user_id: user.id,
      });
      if (error) throw error;
      if (data?.success) {
        setMsg({ ok: true, text: `Boost active for 7 days · ${data.boosts_remaining} left this month` });
        await refresh();
      } else {
        setMsg({ ok: false, text: data?.error ?? "Boost failed" });
      }
    } catch (e: any) {
      setMsg({ ok: false, text: e?.message ?? "Boost failed" });
    } finally {
      setLoading(false);
    }
  };

  if (!canBoost) {
    return (
      <div className="card-editorial p-4">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
          <Rocket className="h-4 w-4 text-coral" /> Profile boost
        </div>
        <p className="mt-2 text-xs text-muted-foreground">Boost your profile to the top of search & Explore.</p>
        <Link to="/pricing" className="btn-coral mt-3 h-9 w-full text-xs">
          Upgrade to unlock
        </Link>
      </div>
    );
  }

  return (
    <div className="card-editorial p-4">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
          <Rocket className="h-4 w-4 text-coral" /> Profile boost
        </div>
        <span
          className={`rounded-full border-[1.5px] border-[#0F0F0F] px-2 py-0.5 text-[10px] font-bold ${
            remaining > 0 ? "bg-white" : "bg-yellow-100"
          }`}
        >
          {remaining} / {p.monthly_boosts_limit} left
        </span>
      </div>

      {isActive ? (
        <div className="mt-3 rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700">
          🔥 Active — {daysLeft} day{daysLeft === 1 ? "" : "s"} remaining
        </div>
      ) : (
        <p className="mt-2 text-xs text-muted-foreground">
          Appear at the top of search results & Explore for 7 days. Resets on the 1st.
        </p>
      )}

      {msg && (
        <div
          className={`mt-2 rounded-md border px-3 py-2 text-xs font-bold ${
            msg.ok
              ? "border-emerald-300 bg-emerald-50 text-emerald-700"
              : "border-red-300 bg-red-50 text-red-700"
          }`}
        >
          {msg.text}
        </div>
      )}

      <button
        onClick={handleBoost}
        disabled={loading || isActive || remaining <= 0}
        className="btn-coral mt-3 h-9 w-full text-xs disabled:cursor-not-allowed disabled:opacity-60"
      >
        {loading
          ? "Activating…"
          : isActive
            ? "Boost active"
            : remaining <= 0
              ? "No boosts left this month"
              : "🚀 Activate 7-day boost"}
      </button>
    </div>
  );
}
