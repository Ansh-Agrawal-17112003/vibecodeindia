import { Link } from "@tanstack/react-router";
import { Star, Clock } from "lucide-react";
import { DemoBadge } from "@/components/ui/DemoBadge";
import { getBuilder, type Service } from "@/lib/mock-data";

export function ServiceCard({ s }: { s: Service }) {
  const b = getBuilder(s.builderId);
  return (
    <Link to="/services/$id" params={{ id: s.id }} className="card-editorial hover-lift group block overflow-hidden transition hover:border-coral hover:-translate-y-0.5">
      <div className="relative aspect-[16/9] overflow-hidden border-b border-border">
        <img src={s.cover} alt="" loading="lazy" className="h-full w-full object-cover transition group-hover:scale-105" />
        {s.is_demo && <DemoBadge className="absolute left-2 top-2" />}
      </div>
      <div className="p-4">
        <div className="flex items-center gap-2">
          <img src={b.avatar} alt="" className="h-5 w-5 rounded-full" />
          <span className="text-xs text-muted-foreground">{b.name}</span>
        </div>
        <h3 className="mt-2 line-clamp-2 font-display font-bold text-foreground">{s.title}</h3>
        <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1 font-bold text-foreground"><Star className="h-3 w-3 fill-gold text-gold" /> {s.rating}</span>
          <span>({s.reviews})</span>
          <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {s.delivery}d</span>
        </div>
        <div className="mt-3 flex items-baseline justify-between border-t border-border pt-3">
          <span className="text-xs text-muted-foreground">Starting at</span>
          <span className="font-display text-lg font-extrabold text-coral">₹{s.price.toLocaleString("en-IN")}</span>
        </div>
      </div>
    </Link>
  );
}

