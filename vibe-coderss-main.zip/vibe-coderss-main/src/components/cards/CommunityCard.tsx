import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Check, Users } from "lucide-react";
import type { Community } from "@/lib/mock-data";
import { isMember } from "@/components/site/JoinCommunityModal";
import { coverForSlug } from "@/lib/community-covers";


const ICON_BG = ["#E8623A", "#2DD4BF", "#F5A623", "#7C3AED", "#FF4D8D", "#0F0F0F"];
const BANNER_PAIRS = [
  ["#FFE4D6", "#FFB199"],
  ["#E8F7F4", "#A5F3E5"],
  ["#FFF1C9", "#F5D687"],
  ["#EDE4FF", "#C9B6FF"],
  ["#FFE0EC", "#FFB3CE"],
  ["#FAF6F1", "#E8DFCC"],
];

type CommunityWithPricing = Community & {
  pricing_type?: "free" | "paid_monthly" | "paid_onetime";
  price_inr?: number;
  is_demo?: boolean;
};

const FEATURED_SLUGS = new Set([
  "ai-builders-india", "lovable", "lovable-builders", "claude", "n8n",
  "openai", "cursor", "student-builders", "indie-founders",
]);

const TAG_MAP: Array<{ match: RegExp; tags: string[] }> = [
  { match: /lovable/i, tags: ["no-code", "full-stack", "vibe-coding"] },
  { match: /cursor/i, tags: ["ide", "pair-programming", "cursorrules"] },
  { match: /claude/i, tags: ["anthropic", "agents", "prompts"] },
  { match: /openai|gpt/i, tags: ["gpt", "assistants", "openai"] },
  { match: /n8n|automation|workflow|make/i, tags: ["automation", "workflows", "self-hosted"] },
  { match: /health|clinic|medtech/i, tags: ["medtech", "clinical-ai", "health"] },
  { match: /fintech|bank|paym/i, tags: ["payments", "banking", "regtech"] },
  { match: /student|hackathon/i, tags: ["students", "hackathons", "mentorship"] },
  { match: /indie|founder|solo/i, tags: ["solofounder", "micro-saas", "bootstrapped"] },
  { match: /mlops|ml/i, tags: ["deployment", "ml-ops", "production"] },
  { match: /video|runway|sora/i, tags: ["ai-video", "runway", "sora"] },
  { match: /voice|whisper|eleven/i, tags: ["voice-ai", "whisper", "elevenlabs"] },
  { match: /devops|infra/i, tags: ["devops", "infra", "reliability"] },
  { match: /agri|farm/i, tags: ["agritech", "bharat", "supply-chain"] },
  { match: /real.?estate/i, tags: ["proptech", "valuation", "listings"] },
  { match: /open.?source|llama|mistral/i, tags: ["open-source", "local-llms", "fine-tuning"] },
  { match: /agent|rag|llm/i, tags: ["agents", "rag", "llm-apps"] },
  { match: /no.?code|bolt/i, tags: ["no-code", "prototyping", "mvp"] },
];

function tagsFor(c: { name: string; slug: string; description: string }): string[] {
  const hay = `${c.name} ${c.slug} ${c.description}`;
  for (const { match, tags } of TAG_MAP) if (match.test(hay)) return tags;
  return ["ai-builders", "india", "community"];
}

export function CommunityCard({ c }: { c: CommunityWithPricing }) {
  const nav = useNavigate();
  let hash = 0;
  for (let i = 0; i < c.slug.length; i++) hash = (hash * 31 + c.slug.charCodeAt(i)) >>> 0;
  const idx = hash % ICON_BG.length;
  const bg = ICON_BG[idx];
  const [b1, b2] = BANNER_PAIRS[idx];
  const featured = FEATURED_SLUGS.has(c.slug);
  const online = Math.round(c.members * 0.12);
  const tags = tagsFor(c);


  const isPaid = (c.pricing_type ?? "free") !== "free" && (c.price_inr ?? 0) > 0;
  const priceBadge = isPaid
    ? { text: `₹${c.price_inr}${c.pricing_type === "paid_monthly" ? "/mo" : ""}`, bg: c.pricing_type === "paid_onetime" ? "#7C3AED" : "#E8623A", fg: "#fff" }
    : { text: "FREE", bg: "#22C55E", fg: "#fff" };

  const [joined, setJoined] = useState(false);
  useEffect(() => {
    setJoined(isMember(c.slug));
    const on = (e: Event) => {
      const d = (e as CustomEvent).detail as { slug: string };
      if (d?.slug === c.slug) setJoined(true);
    };
    window.addEventListener("vc:joined", on);
    return () => window.removeEventListener("vc:joined", on);
  }, [c.slug]);

  return (
    <div className="card-editorial hover-lift overflow-hidden">
      <Link to="/communities/$slug" params={{ slug: c.slug }} className="block">
        <div
          className="relative h-[110px] bg-cover bg-center sm:h-[150px]"
          style={{ backgroundImage: `url(${coverForSlug(c.slug)})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent" />
          {c.isOfficial ? (
            <span className="absolute right-2 top-2 inline-flex items-center gap-1 rounded-full border-[1.5px] border-foreground bg-coral px-2 py-0.5 text-[9px] font-bold uppercase text-white sm:right-3 sm:top-3 sm:px-2.5 sm:text-[10px]">
              <Check className="h-2.5 w-2.5 sm:h-3 sm:w-3" /> Official
            </span>
          ) : featured && (
            <span className="absolute right-2 top-2 rounded-full border-[1.5px] border-foreground bg-[#22C55E] px-2 py-0.5 text-[9px] font-bold uppercase text-white sm:right-3 sm:top-3 sm:px-2.5 sm:text-[10px]">
              Featured
            </span>
          )}
          <span
            className="absolute left-2 top-2 rounded-full border-[1.5px] border-foreground px-2 py-0.5 text-[9px] font-bold uppercase shadow-[1.5px_1.5px_0_0_#0F0F0F] sm:left-3 sm:top-3 sm:text-[10px]"
            style={{ background: priceBadge.bg, color: priceBadge.fg }}
          >{priceBadge.text}</span>
          <div
            className="absolute -bottom-5 left-3 grid h-10 w-10 place-items-center rounded-xl border-[1.5px] border-foreground text-xl text-white shadow-[2px_2px_0_0_#0F0F0F] sm:-bottom-6 sm:left-5 sm:h-12 sm:w-12 sm:text-2xl"
            style={{ background: bg }}
          >
            {c.icon}
          </div>
        </div>

        <div className="px-3.5 pb-4 pt-7 sm:px-5 sm:pb-5 sm:pt-8">
          <div className="flex items-start gap-2">
            <h3 className="font-display text-sm font-bold text-foreground hover:text-coral sm:text-base">
              {c.name}
            </h3>
            {c.is_demo && (
              <span className="mt-0.5 rounded-sm border border-foreground bg-yellow-300 px-1 py-[1px] text-[8px] font-black uppercase tracking-wider text-foreground shadow-[1px_1px_0_0_#0F0F0F] sm:text-[9px]">
                Demo
              </span>
            )}
          </div>
          <p className="mt-1 line-clamp-2 text-xs text-muted-foreground sm:text-[13px]">{c.description}</p>

          <div className="mt-2.5 flex items-center gap-3 text-[11px] text-muted-foreground sm:mt-3 sm:text-xs">
            <span className="inline-flex items-center gap-1">
              <Users className="h-3 w-3 sm:h-3.5 sm:w-3.5" /> {formatK(c.members)} Members
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="h-2 w-2 rounded-full bg-[#22C55E]" /> {formatK(online)} Online
            </span>
          </div>

          {tags.length > 0 && (
            <div className="mt-2.5 flex flex-wrap gap-1.5 sm:mt-3">
              {tags.map((t) => (
                <span
                  key={t}
                  className="rounded-full border-[1.5px] border-foreground bg-background px-1.5 py-0.5 text-[9px] font-semibold uppercase text-foreground sm:px-2 sm:text-[10px]"
                >
                  #{t}

                </span>
              ))}
            </div>
          )}
        </div>
      </Link>

      <div className="px-3.5 pb-4 sm:px-5 sm:pb-5">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            if (joined) nav({ to: "/communities/$slug/feed", params: { slug: c.slug } });
            else nav({ to: "/communities/$slug", params: { slug: c.slug } });
          }}
          className={`flex h-9 w-full items-center justify-center gap-1.5 rounded-full border-[1.5px] border-foreground text-xs font-bold text-white shadow-[2px_2px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:shadow-[4px_4px_0_0_#0F0F0F] sm:h-10 sm:text-sm ${joined ? "bg-success" : "bg-coral"}`}
        >
          {joined ? (<><Check className="h-4 w-4" /> View Community</>) : (isPaid ? `Join · ${priceBadge.text} →` : "Join Community →")}
        </button>
      </div>
    </div>
  );
}

function formatK(n: number) {
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
}

