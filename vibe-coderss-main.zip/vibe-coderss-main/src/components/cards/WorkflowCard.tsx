import { Link } from "@tanstack/react-router";
import { ArrowUp } from "lucide-react";
import { ToolLogos } from "@/components/site/ToolLogo";
import { getBuilder, type Workflow } from "@/lib/mock-data";
import { SaveButton } from "@/components/site/SaveButton";

export function WorkflowCard({ w }: { w: Workflow }) {
  const b = getBuilder(w.builderId);
  return (
    <Link to="/workflows/$id" params={{ id: w.id }} className="card-editorial hover-lift group relative block overflow-hidden transition hover:border-coral hover:-translate-y-0.5">
      <div className="relative aspect-[16/9] overflow-hidden border-b border-border">
        <img src={w.cover} alt="" className="h-full w-full object-cover transition group-hover:scale-105" />
        <SaveButton kind="workflow" id={w.id} label="" className="absolute right-2 top-2 shadow-[2px_2px_0_0_#0F0F0F]" />
      </div>
      <div className="p-2.5 sm:p-4">
        <span className="rounded-md bg-teal/25 px-1.5 sm:px-2 py-0.5 text-[9px] sm:text-[10px] font-bold text-[#0a6b5e]">{w.category}</span>
        <h3 className="mt-1.5 sm:mt-2 font-display text-sm sm:text-base font-bold text-foreground">{w.title}</h3>
        <p className="mt-1 line-clamp-2 text-xs sm:text-sm text-muted-foreground">{w.description}</p>
        <div className="mt-2 sm:mt-3"><ToolLogos names={w.tools} max={4} /></div>
        <div className="mt-2.5 sm:mt-4 flex items-center justify-between border-t border-border pt-2 sm:pt-3">
          <div className="flex items-center gap-1.5 sm:gap-2">
            <img src={b.avatar} alt="" className="h-4 w-4 sm:h-5 sm:w-5 rounded-full" />
            <span className="text-[11px] sm:text-xs text-muted-foreground">{b.name}</span>
          </div>
          <span className="flex items-center gap-1 rounded-full bg-coral/10 px-1.5 sm:px-2 py-0.5 text-[11px] sm:text-xs font-bold text-coral">
            <ArrowUp className="h-3 w-3" /> {w.upvotes}
          </span>
        </div>
      </div>
    </Link>
  );
}
