import { Link } from "@tanstack/react-router";
import { MapPin, Star, Users, BadgeCheck } from "lucide-react";
import { ToolLogos } from "@/components/site/ToolLogo";
import type { Builder } from "@/lib/mock-data";

const BANNER_GRADIENTS = [
  "linear-gradient(135deg, #E8623A, #F5A623)",
  "linear-gradient(135deg, #2DD4BF, #0a6b5e)",
  "linear-gradient(135deg, #F5A623, #FF4D8D)",
  "linear-gradient(135deg, #7C3AED, #E8623A)",
  "linear-gradient(135deg, #FFE4E1, #E8623A)",
];

export function BuilderCard({ b }: { b: Builder }) {
  const gradient = BANNER_GRADIENTS[parseInt(b.id) % BANNER_GRADIENTS.length];
  return (
    <Link
      to="/u/$username"
      params={{ username: b.username }}
      className="card-editorial hover-lift group block overflow-hidden transition hover:border-coral hover:-translate-y-0.5"
    >
      <div className="relative h-14 sm:h-20" style={{ background: gradient }}>
        <div className="absolute -bottom-5 left-3 h-10 w-10 overflow-hidden rounded-full border-2 border-card bg-card sm:-bottom-6 sm:left-4 sm:h-12 sm:w-12">
          <img src={b.avatar} alt={b.name} className="h-full w-full" />
        </div>
        {b.available && (
          <div className="absolute right-2 top-2 flex items-center gap-1 rounded-full bg-white px-1.5 py-0.5 text-[9px] font-bold text-[#0a6b5e] sm:right-3 sm:top-3 sm:gap-1.5 sm:px-2 sm:text-[10px]">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Available
          </div>
        )}
      </div>
      <div className="px-3 pb-3 pt-6 sm:px-4 sm:pb-4 sm:pt-8">
        <div className="flex items-center gap-1.5">
          <h3 className="truncate font-display text-sm font-bold text-foreground sm:text-base">{b.name}</h3>
          {b.verified && <BadgeCheck className="h-3.5 w-3.5 shrink-0 text-coral sm:h-4 sm:w-4" />}
          {b.is_demo !== false && (
            <span className="ml-auto shrink-0 rounded-sm border border-foreground bg-yellow-300 px-1 py-[1px] text-[8px] font-black uppercase tracking-wider text-foreground shadow-[1px_1px_0_0_#0F0F0F]">
              Demo
            </span>
          )}
        </div>
        <p className="mt-0.5 truncate text-xs text-muted-foreground sm:text-sm">{b.title}</p>
        <div className="mt-1.5 flex items-center gap-1 text-[11px] text-muted-foreground sm:mt-2 sm:text-xs">
          <MapPin className="h-3 w-3" /> {b.location}
        </div>
        <div className="mt-2 sm:mt-3"><ToolLogos names={b.tools} max={3} /></div>
        <div className="mt-3 flex items-center gap-2 border-t border-border pt-2 text-[11px] text-muted-foreground sm:mt-4 sm:gap-3 sm:pt-3 sm:text-xs">
          <span className="flex items-center gap-1 font-bold text-foreground"><Star className="h-3 w-3 fill-gold text-gold" /> {b.rating}</span>
          <span>{b.reviews} reviews</span>
          <span className="ml-auto flex items-center gap-1"><Users className="h-3 w-3" /> {b.followers > 999 ? `${(b.followers / 1000).toFixed(1)}k` : b.followers}</span>
        </div>
      </div>
    </Link>
  );
}
