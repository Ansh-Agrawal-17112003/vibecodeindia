import { Link, useNavigate } from "@tanstack/react-router";
import { MapPin, Clock } from "lucide-react";
import { ToolLogos } from "@/components/site/ToolLogo";
import { CompanyLogo } from "@/components/site/CompanyLogo";
import { DemoBadge } from "@/components/ui/DemoBadge";
import type { Job } from "@/lib/mock-data";


export function JobCard({ j }: { j: Job }) {
  const navigate = useNavigate();
  const go = () => navigate({ to: "/jobs/$id", params: { id: j.id } });
  return (
    <div
      role="link"
      tabIndex={0}
      onClick={go}
      onKeyDown={(e) => { if (e.key === "Enter") go(); }}
      className="card-editorial hover-lift block cursor-pointer p-3 sm:p-5 transition hover:border-coral"
    >
      <div className="flex items-start gap-3 sm:gap-4">
        <CompanyLogo name={j.company} size={48} radius={12} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <h3 className="font-display text-sm sm:text-lg font-bold text-foreground">{j.title}</h3>
            <span className="rounded-md bg-teal/25 px-1.5 sm:px-2 py-0.5 text-[9px] sm:text-[10px] font-bold text-[#0a6b5e]">{j.type}</span>
            <span className="rounded-md bg-pink px-1.5 sm:px-2 py-0.5 text-[9px] sm:text-[10px] font-bold text-[#0F0F0F]">{j.remote}</span>
            {j.is_demo && <DemoBadge />}
          </div>

          <div className="mt-1 flex flex-wrap items-center gap-2 sm:gap-3 text-[11px] sm:text-xs text-muted-foreground">
            <span className="font-bold text-foreground">{j.company}</span>
            <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {j.location}</span>
            <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {j.posted}</span>
          </div>
          <p className="mt-2 sm:mt-3 line-clamp-2 text-xs sm:text-sm text-muted-foreground">{j.description}</p>
          <div className="mt-2.5 sm:mt-3 flex flex-wrap items-center justify-between gap-2 sm:gap-3">
            <ToolLogos names={j.tools} max={4} />
            <div className="flex items-center gap-2 sm:gap-3">
              <span className="text-xs sm:text-sm font-bold text-foreground">{j.salary}</span>
              <Link
                to="/jobs/$id"
                params={{ id: j.id }}
                onClick={(e) => e.stopPropagation()}
                className="rounded-full bg-coral px-3 sm:px-4 py-1.5 sm:py-2 text-[11px] sm:text-xs font-bold text-white transition hover:bg-coral-hover"
              >
                Apply Now
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
