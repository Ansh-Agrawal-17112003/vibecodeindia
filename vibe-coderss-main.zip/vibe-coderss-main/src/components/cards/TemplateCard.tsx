import { Link } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { ToolLogos } from "@/components/site/ToolLogo";
import { DemoBadge } from "@/components/ui/DemoBadge";
import { SaveButton } from "@/components/site/SaveButton";
import type { Template } from "@/lib/mock-data";

export function TemplateCard({ t }: { t: Template }) {
  return (
    <Link to="/templates/$slug" params={{ slug: t.slug }} className="card-editorial hover-lift group block overflow-hidden transition hover:border-coral hover:-translate-y-0.5">
      <div className="relative aspect-[16/9] overflow-hidden border-b-[1.5px] border-[#0F0F0F]">
        <img src={t.cover} alt="" loading="lazy" className="h-full w-full object-cover transition group-hover:scale-105" />
        {t.is_demo && <DemoBadge className="absolute left-2 top-2" />}
        <SaveButton kind="template" id={t.slug} label="" className="absolute right-2 top-2 shadow-[2px_2px_0_0_#0F0F0F]" />
      </div>
      <div className="p-2.5 sm:p-4">
        <div className="flex items-center gap-1.5 sm:gap-2 text-[9px] sm:text-[10px] font-bold uppercase tracking-wider">
          <span className="rounded-md bg-teal/25 px-1.5 sm:px-2 py-0.5 text-[#0a6b5e]">{t.category}</span>
          <span className="rounded-md bg-pink px-1.5 sm:px-2 py-0.5 text-[#0F0F0F]">{t.framework}</span>
        </div>
        <h3 className="mt-1.5 sm:mt-2 font-display text-sm sm:text-base font-bold leading-tight text-foreground">{t.title}</h3>
        <p className="mt-1 line-clamp-2 text-xs sm:text-sm text-muted-foreground">{t.description}</p>
        <div className="mt-2 sm:mt-3"><ToolLogos names={t.stack} max={4} /></div>
        <div className="mt-2.5 sm:mt-4 flex items-center justify-between border-t-[1.5px] border-[#0F0F0F] pt-2 sm:pt-3 text-[11px] sm:text-xs">
          <span className="flex items-center gap-1 text-muted-foreground"><Download className="h-3 w-3" /> {t.downloads.toLocaleString()}</span>
          <span className="font-display text-sm sm:text-base font-extrabold text-coral">{t.price}</span>
        </div>
      </div>
    </Link>
  );
}

