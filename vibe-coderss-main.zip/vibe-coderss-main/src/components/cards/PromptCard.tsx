import { Link } from "@tanstack/react-router";
import { ArrowUp, Copy } from "lucide-react";
import { useState } from "react";
import { getBuilder, type Prompt } from "@/lib/mock-data";
import { SaveButton } from "@/components/site/SaveButton";

export function PromptCard({ p }: { p: Prompt }) {
  const b = getBuilder(p.builderId);
  const [copied, setCopied] = useState(false);
  const copy = (e: React.MouseEvent) => {
    e.preventDefault();
    navigator.clipboard?.writeText(p.full);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <Link to="/prompts/$id" params={{ id: p.id }} className="card-editorial hover-lift block p-5 transition hover:border-coral hover:-translate-y-0.5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="rounded-md bg-coral/15 px-2 py-0.5 font-mono text-[10px] font-bold text-coral">{p.model}</span>
        <span className="rounded-md bg-teal/25 px-2 py-0.5 text-[10px] font-bold text-[#0a6b5e]">{p.category}</span>
        {typeof p.copyCount === "number" && (
          <span className="ml-auto text-[10px] font-semibold text-muted-foreground">📋 Copied {p.copyCount.toLocaleString()} times</span>
        )}
      </div>

      <h3 className="mt-3 font-display font-bold text-foreground">{p.title}</h3>
      <p className="mt-2 line-clamp-2 font-mono text-xs leading-relaxed text-muted-foreground">{p.preview}</p>
      <div className="mt-4 flex items-center justify-between border-t border-border pt-3">
        <div className="flex items-center gap-2">
          <img src={b.avatar} alt="" className="h-5 w-5 rounded-full" />
          <span className="text-xs text-muted-foreground">{b.name}</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={copy} className="flex items-center gap-1 rounded-full border border-border bg-card px-2 py-1 text-xs font-bold text-foreground transition hover:border-coral hover:text-coral">
            <Copy className="h-3 w-3" /> {copied ? "Copied" : "Copy"}
          </button>
          <SaveButton kind="prompt" id={p.id} label="" />
          <span className="flex items-center gap-1 rounded-full bg-coral/10 px-2 py-0.5 text-xs font-bold text-coral">
            <ArrowUp className="h-3 w-3" /> {p.upvotes}
          </span>
        </div>
      </div>
    </Link>
  );
}
