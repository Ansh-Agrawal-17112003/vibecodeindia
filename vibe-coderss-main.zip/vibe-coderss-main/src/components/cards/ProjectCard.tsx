import { Link } from "@tanstack/react-router";
import { ArrowUp } from "lucide-react";
import { ToolLogos } from "@/components/site/ToolLogo";
import { DemoBadge } from "@/components/ui/DemoBadge";
import { SaveButton } from "@/components/site/SaveButton";
import { getBuilder, type Project } from "@/lib/mock-data";

export function ProjectCard({ p }: { p: Project }) {
  const b = getBuilder(p.builderId);
  return (
    <Link
      to="/projects/$id"
      params={{ id: p.id }}
      className="card-editorial hover-lift group block overflow-hidden transition hover:border-coral hover:-translate-y-0.5"
    >
      <div className="relative aspect-[16/10] overflow-hidden border-b border-border">
        <img src={p.cover} alt={p.title} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
        {p.is_demo && <DemoBadge className="absolute left-2 top-2" />}
        <SaveButton kind="project" id={p.id} label="" className="absolute right-2 top-2 shadow-[2px_2px_0_0_#0F0F0F]" />
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-display font-bold leading-tight text-foreground">{p.title}</h3>
          <div className="flex shrink-0 items-center gap-1 rounded-full bg-coral/10 px-2 py-1 text-xs font-bold text-coral">
            <ArrowUp className="h-3 w-3" /> {p.upvotes}
          </div>
        </div>
        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{p.description}</p>
        <div className="mt-3"><ToolLogos names={p.tools} max={4} /></div>
        <div className="mt-4 flex items-center gap-2 border-t border-border pt-3">
          <img src={b.avatar} alt="" className="h-5 w-5 rounded-full" />
          <span className="text-xs text-muted-foreground">{b.name} · {p.date}</span>
        </div>
      </div>
    </Link>
  );
}

