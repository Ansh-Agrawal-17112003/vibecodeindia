import { Link } from "@tanstack/react-router";
import { ArrowUp, ExternalLink } from "lucide-react";
import { useState } from "react";
import type { Tool } from "@/lib/mock-data";
import { getToolLogoSources } from "@/lib/tool-logo";

export function ToolCard({ t }: { t: Tool }) {
  const initial = t.name[0];
  const sources = getToolLogoSources(t);
  const [idx, setIdx] = useState(0);
  return (
    <Link to="/tools/$slug" params={{ slug: t.slug }} className="card-editorial hover-lift group block p-4 transition hover:border-coral hover:-translate-y-0.5">
      <div className="flex items-start gap-3">
        <div className="grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F] bg-white text-[#0F0F0F]" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          {idx < sources.length ? (
            <img src={sources[idx]} alt={`${t.name} logo`} className="h-8 w-8 object-contain" loading="lazy" onError={() => setIdx(idx + 1)} />
          ) : (
            <span className="font-display text-xl font-extrabold" style={{ color: t.logoBg }}>{initial}</span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className="truncate font-display font-bold text-foreground">{t.name}</h3>
            <ExternalLink className="h-3 w-3 shrink-0 text-muted-foreground" />
          </div>
          <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{t.tagline}</p>
        </div>
      </div>
      <div className="mt-4 flex items-center justify-between border-t-[1.5px] border-[#0F0F0F] pt-3 text-xs">
        <div className="flex gap-2">
          <span className="rounded-md bg-teal/25 px-2 py-0.5 font-bold text-[#0a6b5e]">{t.category}</span>
          <span className="rounded-md bg-gold/40 px-2 py-0.5 font-bold text-[#0F0F0F]">{t.pricing}</span>
        </div>
        <span className="flex items-center gap-1 font-bold text-coral"><ArrowUp className="h-3 w-3" /> {t.upvotes}</span>
      </div>
    </Link>
  );
}
