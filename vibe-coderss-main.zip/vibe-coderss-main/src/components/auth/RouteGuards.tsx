import { Navigate } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useAuth } from "@/hooks/useAuth";
import { BannedScreen, SuspendedScreen } from "./AccountStateScreens";

function Loading() {
  return (
    <div className="grid min-h-screen place-items-center bg-background">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-[#0F0F0F] border-t-transparent" />
    </div>
  );
}

function AccountGate({ children }: { children: ReactNode }) {
  const { profile, isBanned, isSuspended } = useAuth();
  if (isBanned) return <BannedScreen reason={profile?.ban_reason ?? undefined} />;
  if (isSuspended) return <SuspendedScreen until={profile?.suspended_until ?? undefined} />;
  return <>{children}</>;
}

export function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <Loading />;
  if (!user) return <Navigate to="/auth" replace />;
  return <AccountGate>{children}</AccountGate>;
}

export function AdminRoute({ children }: { children: ReactNode }) {
  const { user, isAdmin, loading } = useAuth();
  if (loading) return <Loading />;
  if (!user) return <Navigate to="/auth" replace />;
  if (!isAdmin) return <Navigate to="/dashboard" replace />;
  return <AccountGate>{children}</AccountGate>;
}

export function SuperAdminRoute({ children }: { children: ReactNode }) {
  const { user, isSuperAdmin, loading } = useAuth();
  if (loading) return <Loading />;
  if (!user) return <Navigate to="/auth" replace />;
  if (!isSuperAdmin) return <Navigate to="/admin" replace />;
  return <AccountGate>{children}</AccountGate>;
}
