import { Ban, Clock } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { VibeCodeLogo } from "@/components/site/Logo";

function fmt(d?: string) {
  if (!d) return "";
  try { return new Date(d).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }); } catch { return d; }
}

export function BannedScreen({ reason }: { reason?: string }) {
  const { signOut } = useAuth();
  return (
    <div className="grid min-h-screen place-items-center bg-background px-6">
      <div className="w-full max-w-md rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-8 text-center" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}>
        <div className="mb-4 flex justify-center"><VibeCodeLogo /></div>
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-coral text-white" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
          <Ban className="h-6 w-6" />
        </div>
        <h1 className="mt-4 font-display text-2xl font-extrabold">Account Banned</h1>
        <p className="mt-2 text-sm text-muted-foreground">Your account has been permanently banned from VibeCode for violating our community guidelines.</p>
        {reason && (
          <div className="mt-4 rounded-md border-[1.5px] border-[#0F0F0F] bg-background p-3 text-left text-sm">
            <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Reason</div>
            <div className="mt-1">{reason}</div>
          </div>
        )}
        <p className="mt-4 text-xs text-muted-foreground">If you believe this is a mistake, contact <a className="font-bold text-coral" href="mailto:support@vibecode.app">support@vibecode.app</a></p>
        <button onClick={signOut} className="btn-coral mt-6 h-11 w-full">Sign out</button>
      </div>
    </div>
  );
}

export function SuspendedScreen({ until }: { until?: string }) {
  const { signOut } = useAuth();
  return (
    <div className="grid min-h-screen place-items-center bg-background px-6">
      <div className="w-full max-w-md rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-8 text-center" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}>
        <div className="mb-4 flex justify-center"><VibeCodeLogo /></div>
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-gold" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
          <Clock className="h-6 w-6" />
        </div>
        <h1 className="mt-4 font-display text-2xl font-extrabold">Account Suspended</h1>
        <p className="mt-2 text-sm text-muted-foreground">Your account is temporarily suspended.</p>
        <div className="mt-4 rounded-md border-[1.5px] border-[#0F0F0F] bg-background p-3 text-sm">
          <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Suspended until</div>
          <div className="mt-1 font-semibold">{fmt(until)}</div>
        </div>
        <button onClick={signOut} className="btn-coral mt-6 h-11 w-full">Sign out</button>
      </div>
    </div>
  );
}
