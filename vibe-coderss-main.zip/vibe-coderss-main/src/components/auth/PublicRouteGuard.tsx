import { useEffect, useRef } from "react";
import { useRouter, useRouterState } from "@tanstack/react-router";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { isEditorPreviewHost } from "@/lib/maintenance";

/**
 * Public-route gate: only the landing page and auth-related routes are
 * viewable without a session. Any other route (vibe, explore, communities,
 * jobs, services, projects, prompts, workflows, tools, templates, blog,
 * detail pages, etc.) bounces unauthenticated visitors back to `/` with a
 * toast prompting them to sign in.
 *
 * The `_authenticated/*` layout and `admin/*` layout already guard themselves
 * on the server; this component covers the remaining top-level content routes
 * that used to be publicly reachable.
 */
const ALWAYS_PUBLIC = new Set<string>([
  "/",
  "/landing",
  "/auth",
  "/login",
  "/signup",
  "/reset-password",
  "/terms",
  "/privacy-policy",
  "/early-access",
  "/founders-wall",
]);

function isAlwaysPublic(pathname: string): boolean {
  if (ALWAYS_PUBLIC.has(pathname)) return true;
  // `_authenticated/*` and `admin/*` handle their own gating.
  if (pathname.startsWith("/admin")) return true;
  // Public API endpoints served by TSS.
  if (pathname.startsWith("/api/public")) return true;
  return false;
}

export function PublicRouteGuard() {
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { session, loading } = useAuth();
  const lastToastPath = useRef<string | null>(null);

  useEffect(() => {
    if (loading) return;
    if (session) return;
    if (typeof window !== "undefined" && isEditorPreviewHost(window.location.hostname)) return;
    if (isAlwaysPublic(pathname)) return;

    // Avoid toast spam if the effect re-runs on the same blocked path.
    if (lastToastPath.current !== pathname) {
      lastToastPath.current = pathname;
      toast("Sign in to explore the platform", {
        description: "Create your free profile to unlock the full VibeCode community.",
        action: {
          label: "Log in",
          onClick: () => router.navigate({ to: "/auth" }),
        },
      });
    }

    router.navigate({ to: "/", replace: true });
  }, [pathname, session, loading, router]);

  return null;
}
