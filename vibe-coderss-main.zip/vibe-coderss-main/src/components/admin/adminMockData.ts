// Mock data for admin panel frontend build.
// Deterministic — reused across all admin pages.

export const growth30d = Array.from({ length: 30 }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() - (29 - i));
  const label = `${d.getDate()}/${d.getMonth() + 1}`;
  const base = 80 + i * 12;
  return {
    day: label,
    users: Math.round(base + Math.sin(i / 3) * 30),
    active: Math.round(base * 0.72 + Math.cos(i / 4) * 24),
    posts: Math.round(60 + i * 8 + Math.sin(i / 2) * 20),
    jobs: Math.round(6 + Math.sin(i / 5) * 4 + i * 0.4),
  };
});

export const trafficSources = [
  { name: "LinkedIn", value: 42 },
  { name: "Direct", value: 28 },
  { name: "WhatsApp", value: 18 },
  { name: "Referral", value: 12 },
];

export const cityBreakdown = [
  { city: "Delhi", users: 3240 },
  { city: "Bangalore", users: 2980 },
  { city: "Mumbai", users: 2170 },
  { city: "Hyderabad", users: 1420 },
  { city: "Pune", users: 1180 },
  { city: "Other", users: 1857 },
];

export const postsByType = [
  { type: "Update", count: 3820 },
  { type: "Project", count: 2140 },
  { type: "Prompt", count: 1890 },
  { type: "Workflow", count: 460 },
  { type: "Question", count: 110 },
];

export const topCommunitiesRanked = [
  { name: "AI Builders India", members: 4820 },
  { name: "Lovable Builders", members: 2340 },
  { name: "n8n Automation", members: 1890 },
  { name: "Cursor Pros", members: 1240 },
  { name: "Prompt Engineers", members: 980 },
];

const firstNames = ["Rohit", "Priya", "Aarav", "Ananya", "Vikram", "Neha", "Kabir", "Isha", "Rahul", "Meera", "Arjun", "Zara", "Dev", "Riya", "Karan", "Sneha", "Yash", "Diya", "Aditya", "Kavya", "Nikhil", "Tara", "Sameer", "Pooja", "Manish"];
const lastNames = ["Singh", "Sharma", "Verma", "Kapoor", "Gupta", "Kumar", "Rao", "Patel", "Iyer", "Menon", "Bose", "Das", "Joshi", "Malhotra", "Nair", "Sinha"];
const cities = ["Delhi", "Bangalore", "Mumbai", "Hyderabad", "Pune", "Chennai", "Kolkata", "Ahmedabad"];

function seededPick<T>(arr: T[], seed: number) { return arr[seed % arr.length]; }

export type MockUser = {
  id: string;
  name: string;
  email: string;
  role: "super_admin" | "admin" | "user";
  status: "active" | "suspended" | "banned";
  joined: string;
  lastActive: string;
  projects: number;
  city: string;
  followers: number;
};

export const mockUsers: MockUser[] = Array.from({ length: 60 }, (_, i) => {
  const fn = seededPick(firstNames, i * 3 + 1);
  const ln = seededPick(lastNames, i * 5 + 2);
  const role: MockUser["role"] = i === 0 ? "super_admin" : i === 1 ? "super_admin" : i < 6 ? "admin" : "user";
  const status: MockUser["status"] = i % 17 === 0 ? "banned" : i % 11 === 0 ? "suspended" : "active";
  const daysAgo = Math.floor(i * 1.7);
  return {
    id: `u_${1000 + i}`,
    name: `${fn} ${ln}`,
    email: `${fn.toLowerCase()}.${ln.toLowerCase()}@gmail.com`,
    role,
    status,
    joined: new Date(Date.now() - daysAgo * 86400_000).toISOString(),
    lastActive: new Date(Date.now() - (i % 9) * 3600_000).toISOString(),
    projects: (i * 3) % 24,
    city: seededPick(cities, i + 3),
    followers: (i * 37) % 500,
  };
});

export type MockCommunity = {
  id: string;
  name: string;
  slug: string;
  members: number;
  type: "public" | "private";
  pricing: "free" | "paid";
  price?: number;
  status: "active" | "suspended" | "review" | "deleted";
  createdBy: string;
  created: string;
  featured: boolean;
  verified: boolean;
};

const commNames = ["AI Builders India", "Lovable Builders", "n8n Automation", "Cursor Pros", "Prompt Engineers", "OpenAI India", "Claude Devs", "Fintech AI", "Healthcare AI", "Indie Founders", "Student Builders", "Open Source AI", "Design Systems", "GenAI Startups", "Web3 x AI"];
export const mockCommunities: MockCommunity[] = commNames.map((name, i) => ({
  id: `c_${100 + i}`,
  name,
  slug: name.toLowerCase().replace(/\s+/g, "-"),
  members: 400 + (i * 317) % 4500,
  type: i % 4 === 0 ? "private" : "public",
  pricing: i % 3 === 0 ? "paid" : "free",
  price: i % 3 === 0 ? 499 : undefined,
  status: i % 13 === 0 ? "review" : i % 19 === 0 ? "suspended" : "active",
  createdBy: seededPick(mockUsers, i).name,
  created: new Date(Date.now() - (i * 5 + 3) * 86400_000).toISOString(),
  featured: i < 3,
  verified: i < 5,
}));

const jobTitles = ["Senior AI Engineer", "Prompt Engineer", "Full-Stack Builder", "n8n Automation Expert", "AI Product Manager", "Frontend Engineer", "ML Ops Lead", "Growth Engineer", "Founding Engineer", "AI Solutions Consultant"];
const companies = ["Lovable", "Zeta", "Razorpay", "CRED", "Freshworks", "Ola Krutrim", "Zomato AI", "Swiggy Labs", "Byju's", "Meesho"];

export type MockJob = {
  id: string;
  title: string;
  company: string;
  type: "full-time" | "part-time" | "contract" | "freelance";
  location: string;
  salary: string;
  posted: string;
  applicants: number;
  status: "active" | "review" | "flagged" | "expired" | "paused";
};

export const mockJobs: MockJob[] = Array.from({ length: 30 }, (_, i) => ({
  id: `j_${500 + i}`,
  title: seededPick(jobTitles, i),
  company: seededPick(companies, i * 2 + 1),
  type: (["full-time", "contract", "full-time", "freelance", "part-time"] as const)[i % 5],
  location: seededPick(cities, i) + (i % 3 === 0 ? " · Remote" : ""),
  salary: `₹${8 + (i % 24)}L – ₹${25 + (i % 30)}L`,
  posted: new Date(Date.now() - (i * 3 + 1) * 3600_000).toISOString(),
  applicants: (i * 11) % 120,
  status: i % 23 === 0 ? "flagged" : i % 17 === 0 ? "review" : i % 29 === 0 ? "expired" : i % 31 === 0 ? "paused" : "active",
}));

export type ModItem = {
  id: string;
  kind: "post" | "job" | "comment" | "profile";
  priority: "high" | "medium" | "low";
  preview: string;
  postedBy: MockUser;
  reportCount: number;
  reasons: string[];
  createdAgo: string;
};

const spamPreviews = [
  "Join my Telegram for FREE AI tools and make ₹50k/month easy…",
  "🚨 URGENT: Get 100x ChatGPT credits with this one weird trick",
  "DM me for paid prompt engineering course — only ₹99, limited seats!",
  "Selling verified LinkedIn accounts — bulk discount available",
  "This new AI tool will replace all developers by 2026, buy now",
  "Airdrop alert! Connect wallet to claim free tokens",
  "Free Netflix + Spotify accounts — click link in bio",
  "Anyone from my batch wants to buy Kaggle competition solutions?",
];

export const mockModQueue: ModItem[] = Array.from({ length: 19 }, (_, i) => ({
  id: `m_${9000 + i}`,
  kind: (["post", "post", "job", "comment", "profile"] as const)[i % 5],
  priority: (["high", "medium", "low"] as const)[i % 3],
  preview: seededPick(spamPreviews, i),
  postedBy: seededPick(mockUsers.filter((u) => u.role === "user"), i + 4),
  reportCount: 1 + (i % 5),
  reasons: [["Spam", "Misleading", "Harassment", "Explicit", "Off-topic"][i % 5]],
  createdAgo: `${1 + (i % 12)}h ago`,
}));

export type Report = {
  id: string;
  kind: "user" | "post" | "job" | "community";
  reportedName: string;
  reportedEmail: string;
  byName: string;
  byEmail: string;
  reason: string;
  details: string;
  createdAgo: string;
  status: "pending" | "resolved" | "dismissed";
};

const reasons = ["Harassment", "Spam", "Inappropriate content", "Impersonation", "Misinformation", "Fraud"];

export const mockReports: Report[] = Array.from({ length: 24 }, (_, i) => {
  const reported = seededPick(mockUsers, i + 7);
  const by = seededPick(mockUsers, i + 13);
  return {
    id: `r_${1800 + i}`,
    kind: (["user", "post", "job", "community"] as const)[i % 4],
    reportedName: reported.name,
    reportedEmail: reported.email,
    byName: by.name,
    byEmail: by.email,
    reason: seededPick(reasons, i),
    details: "The user has been sending unsolicited promotional messages and links to external services after joining multiple communities in the last week.",
    createdAgo: `${1 + (i % 20)}h ago`,
    status: (["pending", "pending", "resolved", "resolved", "dismissed"] as const)[i % 5],
  };
});

export type FeatureFlag = {
  key: string;
  label: string;
  description: string;
  enabled: boolean;
  changedAgo: string;
  changedBy: string;
};

export const featureFlags: FeatureFlag[] = [
  { key: "live_sessions", label: "Live Sessions", description: "Enable Go Live feature for approved builders", enabled: false, changedAgo: "2d ago", changedBy: "admin@vibecode.app" },
  { key: "prompt_library", label: "Prompt Library", description: "Show prompt library in navigation", enabled: true, changedAgo: "5d ago", changedBy: "admin@vibecode.app" },
  { key: "services_marketplace", label: "Services Marketplace", description: "Allow builders to offer paid services", enabled: true, changedAgo: "1w ago", changedBy: "admin@vibecode.app" },
  { key: "paid_communities", label: "Paid Communities", description: "Enable paid community memberships", enabled: false, changedAgo: "3w ago", changedBy: "founder@vibecode.app" },
  { key: "vibecoin_rewards", label: "VibeCoin Rewards", description: "Enable XP and VibeCoin earning system", enabled: true, changedAgo: "2w ago", changedBy: "founder@vibecode.app" },
  { key: "video_calls", label: "Video Calls", description: "Enable Daily.co video call integration", enabled: false, changedAgo: "1mo ago", changedBy: "founder@vibecode.app" },
  { key: "job_board", label: "Job Board", description: "Show job board to all users", enabled: true, changedAgo: "6w ago", changedBy: "founder@vibecode.app" },
  { key: "ai_project_feedback", label: "AI Project Feedback", description: "Auto-generate AI feedback on project upload", enabled: false, changedAgo: "3d ago", changedBy: "admin@vibecode.app" },
];

export const roleAuditLog = [
  { by: "you", target: "admin@email.com", action: "made", role: "Admin", ago: "3d ago" },
  { by: "you", target: "mod@email.com", action: "removed", role: "Admin", ago: "1w ago" },
  { by: "you", target: "helper@email.com", action: "made", role: "Admin", ago: "3w ago" },
];

export const dashboardStats = {
  totalUsers: 12847,
  activeToday: 1240,
  communities: 47,
  jobs: 284,
  projects: 3284,
  prompts: 8420,
  pendingReports: 12,
  modQueue: 7,
  newUsersToday: 124,
  jobsToday: 18,
  projectsWeek: 43,
  promptsToday: 210,
  communitiesWeek: 3,
};
