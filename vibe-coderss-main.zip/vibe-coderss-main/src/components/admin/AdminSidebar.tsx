import { useState, useEffect } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, Users, Home, Briefcase, FolderKanban, Shield, Flag, BarChart3, Settings, Crown, ToggleRight, ArrowLeft, Sparkles, Menu, X, Rocket, Trophy } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";


type BadgeKey = "pendingReports" | "modQueue";

const nav: { to: string; label: string; icon: any; exact?: boolean; badgeKey?: BadgeKey }[] = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/users", label: "Users", icon: Users },
  { to: "/admin/communities", label: "Communities", icon: Home },
  { to: "/admin/projects", label: "Projects", icon: FolderKanban },
  { to: "/admin/jobs", label: "Jobs", icon: Briefcase },
  { to: "/admin/moderation", label: "Moderation", icon: Shield, badgeKey: "modQueue" },
  { to: "/admin/reports", label: "Reports", icon: Flag, badgeKey: "pendingReports" },
  { to: "/admin/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/admin/wins", label: "Real Wins", icon: Trophy },
  { to: "/admin/og-founders", label: "OG Founders", icon: Rocket },
];

const superNav = [
  { to: "/admin/settings", label: "Platform Settings", icon: Settings },
  { to: "/admin/feature-flags", label: "Feature Flags", icon: ToggleRight },
  { to: "/admin/roles", label: "Role Management", icon: Crown },
];

export function AdminSidebar({ badges }: { badges?: { pendingReports?: number; modQueue?: number } }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { isSuperAdmin } = useAuth();

  const item = (to: string, label: string, Icon: any, active: boolean, badge?: number) => (
    <Link
      key={to}
      to={to}
      className={`group relative mx-3 flex items-center gap-3 rounded-lg border-[1.5px] px-3 py-2.5 text-[13.5px] font-bold transition ${
        active
          ? "border-[#0F0F0F] bg-coral text-white shadow-[3px_3px_0_0_#0F0F0F] translate-x-0"
          : "border-transparent text-foreground/75 hover:border-[#0F0F0F] hover:bg-card hover:shadow-[2px_2px_0_0_#0F0F0F] hover:-translate-y-0.5"
      }`}
    >
      <span className={`grid h-7 w-7 place-items-center rounded-md border-[1.5px] transition ${active ? "border-white/40 bg-white/10 text-white" : "border-[#0F0F0F]/20 bg-surface text-foreground group-hover:border-[#0F0F0F]"}`}>
        <Icon className="h-3.5 w-3.5" />
      </span>
      <span className="flex-1">{label}</span>
      {badge && badge > 0 ? (
        <span className="grid h-[20px] min-w-[20px] place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-gold px-1 text-[10px] font-extrabold text-[#0F0F0F]">
          {badge}
        </span>
      ) : null}
    </Link>
  );

  return (
    <aside className="hidden w-64 flex-shrink-0 flex-col border-r-[1.5px] border-[#0F0F0F] bg-surface lg:flex">
      <nav className="flex-1 overflow-y-auto py-5 text-sm">
        <div className="mb-2 px-6 text-[10px] font-extrabold uppercase tracking-[0.14em] text-muted-foreground">Main</div>
        <div className="flex flex-col gap-1">
          {nav.map((it) => {
            const active = it.exact ? path === it.to : path === it.to || path.startsWith(it.to + "/");
            const badge = it.badgeKey ? badges?.[it.badgeKey] : undefined;
            return item(it.to, it.label, it.icon, active, badge);
          })}
        </div>

        {isSuperAdmin && (
          <>
            <div className="mx-6 my-5 border-t-[1.5px] border-dashed border-[#0F0F0F]/25" />
            <div className="mb-2 flex items-center gap-1.5 px-6 text-[10px] font-extrabold uppercase tracking-[0.14em] text-coral">
              <Sparkles className="h-3 w-3" /> Super Admin
            </div>
            <div className="flex flex-col gap-1">
              {superNav.map((it) => item(it.to, it.label, it.icon, path === it.to))}
            </div>
          </>
        )}
      </nav>

      <div className="border-t-[1.5px] border-[#0F0F0F] bg-card p-4">
        <Link
          to="/"
          className="flex items-center justify-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-surface px-3 py-2 text-[12px] font-extrabold text-foreground shadow-[2px_2px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:bg-gold hover:shadow-[3px_3px_0_0_#0F0F0F]"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to VibeCode
        </Link>
      </div>
    </aside>
  );
}

export function AdminMobileHeader({ badges }: { badges?: { pendingReports?: number; modQueue?: number } }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { isSuperAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const current = [...nav, ...superNav].find((n) => path === n.to || (n.to !== "/admin" && path.startsWith(n.to)))?.label ?? "Admin";

  // Close drawer on route change
  useEffect(() => { setOpen(false); }, [path]);

  // Lock body scroll while drawer is open
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [open]);

  const linkItem = (to: string, label: string, Icon: any, active: boolean, badge?: number) => (
    <Link
      key={to}
      to={to}
      onClick={() => setOpen(false)}
      className={`flex items-center gap-3 rounded-lg border-[1.5px] px-3 py-3 text-[14px] font-bold transition ${
        active
          ? "border-[#0F0F0F] bg-coral text-white shadow-[3px_3px_0_0_#0F0F0F]"
          : "border-transparent text-foreground/85 hover:border-[#0F0F0F] hover:bg-card"
      }`}
    >
      <span className={`grid h-8 w-8 place-items-center rounded-md border-[1.5px] ${active ? "border-white/40 bg-white/10 text-white" : "border-[#0F0F0F]/20 bg-surface text-foreground"}`}>
        <Icon className="h-4 w-4" />
      </span>
      <span className="flex-1">{label}</span>
      {badge && badge > 0 ? (
        <span className="grid h-[20px] min-w-[20px] place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-gold px-1 text-[10px] font-extrabold text-[#0F0F0F]">
          {badge}
        </span>
      ) : null}
    </Link>
  );

  return (
    <>
      <div className="sticky top-16 z-30 flex items-center justify-between gap-2 border-b-[1.5px] border-[#0F0F0F] bg-surface px-4 py-3 lg:hidden">
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-label="Open admin menu"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-card text-foreground shadow-[2px_2px_0_0_#0F0F0F] transition active:translate-y-0.5"
        >
          <Menu className="h-4 w-4" />
        </button>
        <div className="min-w-0 flex-1 truncate font-display text-base font-extrabold text-foreground">{current}</div>
        <div className="pill-badge shrink-0 bg-coral text-white">Admin</div>
      </div>

      {/* Drawer */}
      {open && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div
            className="absolute inset-0 bg-[#0F0F0F]/60"
            onClick={() => setOpen(false)}
            aria-hidden="true"
          />
          <aside
            role="dialog"
            aria-label="Admin navigation"
            className="absolute left-0 top-0 flex h-full w-[86%] max-w-[320px] flex-col border-r-[1.5px] border-[#0F0F0F] bg-surface shadow-[6px_0_0_-2px_#0F0F0F]"
          >
            <div className="flex items-center justify-between border-b-[1.5px] border-[#0F0F0F] bg-card px-4 py-3">
              <div className="font-display text-base font-extrabold text-foreground">Admin Menu</div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close admin menu"
                className="grid h-9 w-9 place-items-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-surface text-foreground shadow-[2px_2px_0_0_#0F0F0F]"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <nav className="flex-1 overflow-y-auto p-3">
              <div className="mb-2 px-2 text-[10px] font-extrabold uppercase tracking-[0.14em] text-muted-foreground">Main</div>
              <div className="flex flex-col gap-1.5">
                {nav.map((it) => {
                  const active = it.exact ? path === it.to : path === it.to || path.startsWith(it.to + "/");
                  const badge = it.badgeKey ? badges?.[it.badgeKey] : undefined;
                  return linkItem(it.to, it.label, it.icon, active, badge);
                })}
              </div>

              {isSuperAdmin && (
                <>
                  <div className="mx-2 my-4 border-t-[1.5px] border-dashed border-[#0F0F0F]/25" />
                  <div className="mb-2 flex items-center gap-1.5 px-2 text-[10px] font-extrabold uppercase tracking-[0.14em] text-coral">
                    <Sparkles className="h-3 w-3" /> Super Admin
                  </div>
                  <div className="flex flex-col gap-1.5">
                    {superNav.map((it) => linkItem(it.to, it.label, it.icon, path === it.to))}
                  </div>
                </>
              )}
            </nav>

            <div className="border-t-[1.5px] border-[#0F0F0F] bg-card p-3">
              <Link
                to="/"
                onClick={() => setOpen(false)}
                className="flex items-center justify-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-surface px-3 py-2.5 text-[13px] font-extrabold text-foreground shadow-[2px_2px_0_0_#0F0F0F]"
              >
                <ArrowLeft className="h-3.5 w-3.5" /> Back to VibeCode
              </Link>
            </div>
          </aside>
        </div>
      )}
    </>
  );
}

