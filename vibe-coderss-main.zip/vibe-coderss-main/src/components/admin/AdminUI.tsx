import type { ReactNode } from "react";

/**
 * Admin panel building blocks — VibeCode neo-brutalist brand:
 * cream surfaces, 1.5px #0F0F0F borders, 4-6px offset shadows,
 * coral / gold accents, Bricolage Grotesque display, Inter body.
 * All exports keep the same names/props as before so admin pages don't break.
 */

export function AdminPage({
  title,
  subtitle,
  actions,
  children,
  eyebrow,
}: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
  eyebrow?: string;
}) {
  return (
    <div className="mx-auto max-w-[1400px] px-3 py-4 sm:px-4 sm:py-6 md:px-8 md:py-10">
      <div className="mb-4 border-b-[1.5px] border-dashed border-[#0F0F0F]/25 pb-3 sm:mb-7 sm:pb-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end sm:justify-between sm:gap-4">
          <div className="min-w-0">
            {eyebrow && (
              <div className="pill-badge mb-2 bg-gold text-[#0F0F0F] sm:mb-3">{eyebrow}</div>
            )}
            <h1 className="font-display text-[20px] font-extrabold leading-tight tracking-tight text-foreground sm:text-3xl md:text-[40px]">
              {title}
              <span className="text-coral">.</span>
            </h1>
            {subtitle && (
              <p className="mt-1 max-w-2xl text-[12px] text-muted-foreground sm:mt-2 sm:text-sm md:text-[15px]">{subtitle}</p>
            )}
          </div>
          {actions && (
            <div className="-mx-3 overflow-x-auto px-3 sm:mx-0 sm:overflow-visible sm:px-0">
              <div className="flex w-max min-w-full items-center gap-1.5 sm:w-auto sm:min-w-0 sm:flex-wrap sm:gap-2">
                {actions}
              </div>
            </div>
          )}
        </div>
      </div>
      {children}
    </div>
  );
}

export function AdminCard({
  children,
  className = "",
  accent,
  onClick,
  hover = false,
}: {
  children: ReactNode;
  className?: string;
  accent?: "warn" | "danger" | "success" | "coral" | "gold";
  onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
  hover?: boolean;
}) {
  const accentRail =
    accent === "warn"    ? "before:bg-[#F5A623]" :
    accent === "danger"  ? "before:bg-[#EF4444]" :
    accent === "success" ? "before:bg-[#22C55E]" :
    accent === "coral"   ? "before:bg-coral" :
    accent === "gold"    ? "before:bg-gold" :
    "before:bg-transparent";
  const hoverCls = hover || onClick ? "card-hover cursor-pointer" : "";
  return (
    <div
      onClick={onClick}
      className={`card-surface relative overflow-hidden before:absolute before:inset-y-0 before:left-0 before:w-1 ${accentRail} ${hoverCls} ${className}`}
    >
      {children}
    </div>
  );
}

export function StatCard({
  icon, label, value, delta, deltaTone = "up", accent, cta,
}: {
  icon?: ReactNode; label: string; value: string | number; delta?: string;
  deltaTone?: "up" | "down" | "warn"; accent?: "warn" | "coral" | "gold" | "success"; cta?: ReactNode;
}) {
  const tone =
    deltaTone === "down" ? "bg-[#FEE2E2] text-[#B91C1C] border-[#EF4444]/40" :
    deltaTone === "warn" ? "bg-[#FEF3C7] text-[#92400E] border-[#F5A623]/40" :
    "bg-[#DCFCE7] text-[#166534] border-[#22C55E]/40";
  return (
    <AdminCard accent={accent ?? "coral"} className="group p-3 sm:p-5">
      <div className="flex items-start justify-between gap-2">
        <div className="text-[10px] font-extrabold uppercase tracking-[0.08em] text-muted-foreground sm:text-[11px]">{label}</div>
        {icon && (
          <div className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-surface text-[#0F0F0F] shadow-[2px_2px_0_0_#0F0F0F] transition group-hover:-translate-y-0.5 sm:h-9 sm:w-9">
            {icon}
          </div>
        )}
      </div>
      <div className="mt-1.5 font-display text-[22px] font-extrabold leading-none tracking-tight text-foreground sm:mt-3 sm:text-[36px] md:text-[42px]">
        {typeof value === "number" ? value.toLocaleString("en-IN") : value}
      </div>
      {delta && (
        <div className={`mt-1.5 inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold sm:mt-3 sm:text-[11px] ${tone}`}>
          {delta}
        </div>
      )}
      {cta && <div className="mt-2 sm:mt-4">{cta}</div>}
    </AdminCard>
  );
}

export function Pill({ children, tone = "muted" }: { children: ReactNode; tone?: "muted" | "success" | "warn" | "danger" | "coral" | "gold" | "info" }) {
  const map: Record<string, string> = {
    muted:   "bg-surface text-foreground border-[#0F0F0F]",
    success: "bg-[#DCFCE7] text-[#166534] border-[#0F0F0F]",
    warn:    "bg-[#FEF3C7] text-[#92400E] border-[#0F0F0F]",
    danger:  "bg-[#FEE2E2] text-[#B91C1C] border-[#0F0F0F]",
    coral:   "bg-coral text-white border-[#0F0F0F]",
    gold:    "bg-gold text-[#0F0F0F] border-[#0F0F0F]",
    info:    "bg-[#DBEAFE] text-[#1E40AF] border-[#0F0F0F]",
  };
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border-[1.5px] px-2.5 py-0.5 text-[11px] font-extrabold uppercase tracking-wide ${map[tone]}`}>
      {children}
    </span>
  );
}

export function StatusDot({ tone }: { tone: "success" | "warn" | "danger" }) {
  const color = tone === "success" ? "bg-[#22C55E]" : tone === "warn" ? "bg-[#F5A623]" : "bg-[#EF4444]";
  return (
    <span className="relative inline-flex h-2.5 w-2.5">
      <span className={`absolute inline-flex h-full w-full animate-ping rounded-full opacity-60 ${color}`} />
      <span className={`relative inline-flex h-2.5 w-2.5 rounded-full border border-[#0F0F0F] ${color}`} />
    </span>
  );
}

const inputCls =
  "h-9 sm:h-10 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-[13px] sm:text-sm text-foreground outline-none placeholder:text-muted-foreground shadow-[2px_2px_0_0_#0F0F0F] transition focus:-translate-y-0.5 focus:shadow-[3px_3px_0_0_#0F0F0F] focus:border-coral";

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  const { className = "", ...rest } = props;
  return <input {...rest} className={`${inputCls} ${className}`} />;
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  const { className = "", children, ...rest } = props;
  return (
    <select {...rest} className={`${inputCls} px-2 pr-6 ${className}`}>
      {children}
    </select>
  );
}

export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const { className = "", ...rest } = props;
  return (
    <textarea
      {...rest}
      className={`w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground shadow-[2px_2px_0_0_#0F0F0F] transition focus:border-coral ${className}`}
    />
  );
}

const btnBase =
  "inline-flex h-9 sm:h-10 shrink-0 items-center gap-1.5 rounded-lg border-[1.5px] border-[#0F0F0F] px-3 sm:px-3.5 text-[12px] sm:text-[13px] font-extrabold shadow-[2px_2px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:shadow-[3px_3px_0_0_#0F0F0F] active:translate-y-0 active:shadow-[1px_1px_0_0_#0F0F0F] disabled:pointer-events-none disabled:opacity-50";

export function BtnCoral({ children, ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...rest} className={`${btnBase} bg-coral text-white ${rest.className ?? ""}`}>
      {children}
    </button>
  );
}

export function BtnGhost({ children, ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...rest} className={`${btnBase} bg-card text-foreground ${rest.className ?? ""}`}>
      {children}
    </button>
  );
}

export function BtnGold({ children, ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...rest} className={`${btnBase} bg-gold text-[#0F0F0F] ${rest.className ?? ""}`}>
      {children}
    </button>
  );
}

export function BtnDanger({ children, ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...rest} className={`${btnBase} bg-[#FEE2E2] text-[#B91C1C] ${rest.className ?? ""}`}>
      {children}
    </button>
  );
}

export function Toggle({ checked, onChange, disabled }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-7 w-12 items-center rounded-full border-[1.5px] border-[#0F0F0F] transition shadow-[2px_2px_0_0_#0F0F0F] ${checked ? "bg-coral" : "bg-surface"} disabled:opacity-40`}
    >
      <span
        className={`inline-block h-5 w-5 transform rounded-full border-[1.5px] border-[#0F0F0F] bg-white transition ${checked ? "translate-x-5" : "translate-x-0.5"}`}
      />
    </button>
  );
}

export function EmptyState({ icon, title, description }: { icon?: ReactNode; title: string; description?: string }) {
  return (
    <div className="grid place-items-center rounded-2xl border-[1.5px] border-dashed border-[#0F0F0F]/40 bg-surface py-16 text-center">
      {icon && (
        <div className="mb-3 grid h-14 w-14 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card text-2xl text-coral shadow-[3px_3px_0_0_#0F0F0F]">
          {icon}
        </div>
      )}
      <div className="font-display text-base font-extrabold text-foreground">{title}</div>
      {description && <p className="mt-1 max-w-md px-6 text-sm text-muted-foreground">{description}</p>}
    </div>
  );
}

export function TableWrap({ children }: { children: ReactNode }) {
  return (
    <AdminCard className="overflow-hidden p-0">
      <div className="overflow-x-auto">
        <table className="w-full text-[12.5px] text-foreground sm:text-sm">{children}</table>
      </div>
    </AdminCard>
  );
}

export function TH({ children, className = "" }: { children?: ReactNode; className?: string }) {
  return (
    <th className={`sticky top-0 border-b-[1.5px] border-[#0F0F0F] bg-surface px-3 py-2.5 text-left text-[10px] font-extrabold uppercase tracking-[0.09em] text-foreground sm:px-4 sm:py-3 sm:text-[10.5px] ${className}`}>
      {children}
    </th>
  );
}

export function TD({ children, className = "" }: { children?: ReactNode; className?: string }) {
  return (
    <td className={`border-t border-[#0F0F0F]/10 bg-card px-3 py-2.5 align-middle transition group-hover:bg-surface/60 sm:px-4 sm:py-3 ${className}`}>
      {children}
    </td>
  );
}

export function TR({ children, className = "", onClick }: { children?: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <tr onClick={onClick} className={`group ${onClick ? "cursor-pointer" : ""} ${className}`}>
      {children}
    </tr>
  );
}

export function RolePill({ role }: { role: "super_admin" | "admin" | "user" }) {
  if (role === "super_admin") return <Pill tone="gold">👑 Super Admin</Pill>;
  if (role === "admin") return <Pill tone="coral">⚡ Admin</Pill>;
  return <Pill>User</Pill>;
}

export function StatusPill({ status }: { status: "active" | "suspended" | "banned" | "review" | "flagged" | "expired" | "paused" | "deleted" }) {
  switch (status) {
    case "active":    return <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#166534]"><StatusDot tone="success" /> Active</span>;
    case "suspended": return <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#92400E]"><StatusDot tone="warn" /> Suspended</span>;
    case "banned":    return <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#B91C1C]"><StatusDot tone="danger" /> Banned</span>;
    case "review":    return <Pill tone="warn">Under Review</Pill>;
    case "flagged":   return <Pill tone="danger">Flagged</Pill>;
    case "expired":   return <Pill>Expired</Pill>;
    case "paused":    return <Pill tone="warn">Paused</Pill>;
    case "deleted":   return <Pill tone="danger">Deleted</Pill>;
  }
}

/** Decorative brutalist section header for grouping panels inside a page. */
export function SectionHeader({ title, subtitle, right, icon }: { title: string; subtitle?: string; right?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div className="flex items-center gap-3">
        {icon && (
          <div className="grid h-9 w-9 place-items-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-gold text-[#0F0F0F] shadow-[2px_2px_0_0_#0F0F0F]">
            {icon}
          </div>
        )}
        <div>
          <div className="font-display text-lg font-extrabold tracking-tight text-foreground">{title}</div>
          {subtitle && <div className="text-xs text-muted-foreground">{subtitle}</div>}
        </div>
      </div>
      {right}
    </div>
  );
}
