import { type FC, useEffect, useRef, useState, type ReactNode } from "react";
import { motion, useSpring } from "framer-motion";

interface Position { x: number; y: number }

export interface SmoothCursorProps {
  cursor?: ReactNode;
  springConfig?: { damping: number; stiffness: number; mass: number; restDelta: number };
}

const DESKTOP_POINTER_QUERY = "(any-hover: hover) and (any-pointer: fine)";
const isTrackablePointer = (t: string) => t !== "touch";

/** VibeCode coral arrow cursor — refined designer mark with inner highlight + tip dot. */
const VibeCursor: FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width={34} height={38} viewBox="0 0 50 54" fill="none">
    <g filter="url(#vc_shadow)">
      <path
        d="M43.7146 40.6933L28.5431 6.34306C27.3556 3.65428 23.5772 3.69516 22.3668 6.32755L6.57226 40.6778C5.3134 43.4156 7.97238 46.298 10.803 45.2549L24.7662 40.109C25.0221 40.0147 25.2999 40.0156 25.5494 40.1082L39.4193 45.254C42.2261 46.2953 44.9254 43.4347 43.7146 40.6933Z"
        fill="url(#vc_grad)"
        stroke="#0F0F0F"
        strokeWidth={2.2}
        strokeLinejoin="round"
      />
      {/* inner highlight */}
      <path
        d="M25.4 11 L21 34 L25.4 32.4 L29.8 34 Z"
        fill="rgba(255,255,255,0.28)"
      />
      {/* tip dot */}
      <circle cx="25.4" cy="8.5" r="1.6" fill="#FFF3EC" />
    </g>
    <defs>
      <linearGradient id="vc_grad" x1="10" y1="6" x2="44" y2="46" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#F5A623" />
        <stop offset="0.55" stopColor="#E8623A" />
        <stop offset="1" stopColor="#C2451F" />
      </linearGradient>
      <filter id="vc_shadow" x={-4} y={-2} width={58} height={60} filterUnits="userSpaceOnUse">
        <feFlood floodOpacity={0} result="bg" />
        <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="a" />
        <feOffset dy={2} />
        <feGaussianBlur stdDeviation={2.5} />
        <feColorMatrix values="0 0 0 0 0.91 0 0 0 0 0.38 0 0 0 0 0.22 0 0 0 0.38 0" />
        <feBlend in2="bg" result="d" />
        <feBlend in="SourceGraphic" in2="d" />
      </filter>
    </defs>
  </svg>
);




export function SmoothCursor({
  cursor = <VibeCursor />,
  springConfig = { damping: 45, stiffness: 400, mass: 1, restDelta: 0.001 },
}: SmoothCursorProps) {
  const lastMousePos = useRef<Position>({ x: 0, y: 0 });
  const velocity = useRef<Position>({ x: 0, y: 0 });
  const lastUpdateTime = useRef(Date.now());
  const previousAngle = useRef(0);
  const accumulatedRotation = useRef(0);
  const [isEnabled, setIsEnabled] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  const cursorX = useSpring(0, springConfig);
  const cursorY = useSpring(0, springConfig);
  const rotation = useSpring(0, { ...springConfig, damping: 60, stiffness: 300 });
  const scale = useSpring(1, { ...springConfig, stiffness: 500, damping: 35 });

  useEffect(() => {
    if (typeof window === "undefined") return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
    const mq = window.matchMedia(DESKTOP_POINTER_QUERY);
    const update = () => {
      const next = mq.matches && !reduce.matches;
      setIsEnabled(next);
      if (!next) setIsVisible(false);
    };
    update();
    mq.addEventListener("change", update);
    reduce.addEventListener("change", update);
    return () => {
      mq.removeEventListener("change", update);
      reduce.removeEventListener("change", update);
    };
  }, []);

  useEffect(() => {
    if (!isEnabled) return;
    let timeout: ReturnType<typeof setTimeout> | null = null;

    const updateVelocity = (p: Position) => {
      const t = Date.now();
      const dt = t - lastUpdateTime.current;
      if (dt > 0) {
        velocity.current = {
          x: (p.x - lastMousePos.current.x) / dt,
          y: (p.y - lastMousePos.current.y) / dt,
        };
      }
      lastUpdateTime.current = t;
      lastMousePos.current = p;
    };

    const move = (e: PointerEvent) => {
      if (!isTrackablePointer(e.pointerType)) return;
      setIsVisible(true);
      const p = { x: e.clientX, y: e.clientY };
      updateVelocity(p);
      const speed = Math.hypot(velocity.current.x, velocity.current.y);
      cursorX.set(p.x);
      cursorY.set(p.y);
      if (speed > 0.1) {
        const angle = Math.atan2(velocity.current.y, velocity.current.x) * (180 / Math.PI) + 90;
        let diff = angle - previousAngle.current;
        if (diff > 180) diff -= 360;
        if (diff < -180) diff += 360;
        accumulatedRotation.current += diff;
        rotation.set(accumulatedRotation.current);
        previousAngle.current = angle;
        scale.set(0.95);
        if (timeout) clearTimeout(timeout);
        timeout = setTimeout(() => scale.set(1), 150);
      }
    };

    let raf = 0;
    const throttled = (e: PointerEvent) => {
      if (!isTrackablePointer(e.pointerType)) return;
      if (raf) return;
      raf = requestAnimationFrame(() => { move(e); raf = 0; });
    };
    const onLeave = () => setIsVisible(false);

    document.documentElement.classList.add("vc-hide-cursor");
    window.addEventListener("pointermove", throttled, { passive: true });
    window.addEventListener("pointerleave", onLeave);

    return () => {
      window.removeEventListener("pointermove", throttled);
      window.removeEventListener("pointerleave", onLeave);
      document.documentElement.classList.remove("vc-hide-cursor");
      if (raf) cancelAnimationFrame(raf);
      if (timeout) clearTimeout(timeout);
    };
  }, [cursorX, cursorY, rotation, scale, isEnabled]);

  if (!isEnabled) return null;

  return (
    <>
      <motion.div
        aria-hidden
        style={{
          position: "fixed",
          left: cursorX,
          top: cursorY,
          translateX: "-50%",
          translateY: "-50%",
          width: 52,
          height: 52,
          borderRadius: 9999,
          background:
            "radial-gradient(closest-side, rgba(232,98,58,0.55), rgba(245,166,35,0.18) 55%, rgba(232,98,58,0) 75%)",
          filter: "blur(8px)",
          zIndex: 9998,
          pointerEvents: "none",
          willChange: "transform",
          opacity: isVisible ? 0.9 : 0,
          transition: "opacity 200ms ease",
        }}
      />
      <motion.div
        style={{
          position: "fixed",
          left: cursorX,
          top: cursorY,
          translateX: "-50%",
          translateY: "-50%",
          rotate: rotation,
          scale,
          zIndex: 9999,
          pointerEvents: "none",
          willChange: "transform",
          opacity: isVisible ? 1 : 0,
        }}
        initial={false}
        animate={{ opacity: isVisible ? 1 : 0 }}
        transition={{ duration: 0.15 }}
      >
        {cursor}
      </motion.div>
    </>
  );
}
