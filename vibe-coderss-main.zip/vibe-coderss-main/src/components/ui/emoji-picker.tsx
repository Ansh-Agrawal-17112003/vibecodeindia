import { useEffect, useRef, useState } from "react";
import { Smile } from "lucide-react";
import { cn } from "@/lib/utils";

const EMOJI_GROUPS: { name: string; emojis: string[] }[] = [
  { name: "Smileys", emojis: ["😀","😃","😄","😁","😆","😅","😂","🤣","😊","😇","🙂","🙃","😉","😌","😍","🥰","😘","😗","😙","😚","😋","😛","😝","😜","🤪","🤨","🧐","🤓","😎","🥸","🤩","🥳"] },
  { name: "Emotion", emojis: ["😏","😒","😞","😔","😟","😕","🙁","☹️","😣","😖","😫","😩","🥺","😢","😭","😤","😠","😡","🤬","🤯","😳","🥵","🥶","😱","😨","😰","😥","😓","🤗","🤔","🤭","🤫"] },
  { name: "Hands",   emojis: ["👍","👎","👌","🤌","🤏","✌️","🤞","🤟","🤘","🤙","👈","👉","👆","👇","☝️","👋","🤚","🖐️","✋","🖖","👏","🙌","🤝","🙏","💪","🫶","❤️","🧡","💛","💚","💙","💜"] },
  { name: "Objects", emojis: ["🔥","✨","⭐","🌟","💥","💯","💡","🎉","🎊","🚀","🏆","🥇","💎","💰","📈","📊","🎯","✅","❌","⚡","☕","🍕","🍔","🍟","🎵","🎶","🖥️","💻","📱","⌚","🎨","🛠️"] },
];

export function EmojiPicker({
  onPick,
  align = "start",
  className,
}: {
  onPick: (emoji: string) => void;
  align?: "start" | "end";
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const [group, setGroup] = useState(0);
  const wrapRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  return (
    <div ref={wrapRef} className={cn("relative", className)}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label="Add emoji"
        className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-surface hover:text-coral"
      >
        <Smile className="h-4 w-4" />
      </button>
      {open && (
        <div
          className={cn(
            "absolute bottom-10 z-30 w-[272px] rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-2 shadow-[3px_3px_0_0_#0F0F0F]",
            align === "end" ? "right-0" : "left-0",
          )}
        >
          <div className="mb-1.5 flex gap-1 overflow-x-auto">
            {EMOJI_GROUPS.map((g, i) => (
              <button
                key={g.name}
                type="button"
                onClick={() => setGroup(i)}
                className={cn(
                  "shrink-0 rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-wider",
                  group === i ? "bg-coral text-white" : "bg-surface text-muted-foreground",
                )}
              >
                {g.name}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-8 gap-0.5">
            {EMOJI_GROUPS[group].emojis.map((e) => (
              <button
                key={e}
                type="button"
                onClick={() => { onPick(e); setOpen(false); }}
                className="grid h-8 w-8 place-items-center rounded-md text-lg transition hover:bg-surface hover:scale-125"
              >
                {e}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
