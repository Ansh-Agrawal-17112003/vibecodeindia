import * as React from "react";
import { cn } from "@/lib/utils";

export interface ShimmerButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  shimmerColor?: string;
  shimmerSize?: string;
  shimmerDuration?: string;
  borderRadius?: string;
  background?: string;
}

/**
 * Magic UI ShimmerButton — animated conic-gradient shimmer that runs around
 * the button edge. Styled here to match the site's neo-brutalist palette
 * (coral fill + hard black border + offset shadow) so it slots into the nav.
 */
export const ShimmerButton = React.forwardRef<HTMLButtonElement, ShimmerButtonProps>(
  (
    {
      shimmerColor = "#ffffff",
      shimmerSize = "0.08em",
      shimmerDuration = "2.4s",
      borderRadius = "9999px",
      background = "#FF6B57", // coral
      className,
      children,
      style,
      ...props
    },
    ref,
  ) => {
    return (
      <button
        ref={ref}
        style={
          {
            "--spread": "90deg",
            "--shimmer-color": shimmerColor,
            "--radius": borderRadius,
            "--speed": shimmerDuration,
            "--cut": shimmerSize,
            "--bg": background,
            boxShadow: "2px 2px 0 0 #0F0F0F",
            ...style,
          } as React.CSSProperties
        }
        className={cn(
          "group relative z-0 flex cursor-pointer items-center justify-center overflow-hidden whitespace-nowrap border-[1.5px] border-[#0F0F0F] px-4 py-2 text-sm font-bold text-white [background:var(--bg)] [border-radius:var(--radius)]",
          "transition-all duration-200 ease-out hover:-translate-x-[2px] hover:-translate-y-[2px] hover:shadow-[4px_4px_0_0_#0F0F0F] active:translate-x-0 active:translate-y-0 active:shadow-[1px_1px_0_0_#0F0F0F]",
          className,
        )}
        {...props}
      >
        {/* spark container */}
        <div
          className={cn(
            "-z-30 blur-[2px]",
            "absolute inset-0 overflow-visible [container-type:size]",
          )}
        >
          <div
            className="absolute inset-0 h-[100cqh] [aspect-ratio:1] [border-radius:0] [mask:none]"
            style={{ animation: `shimmer-slide-x var(--speed) infinite linear` }}
          >
            <div
              className="absolute -inset-full w-auto rotate-0 [background:conic-gradient(from_calc(270deg-(var(--spread)*0.5)),transparent_0,var(--shimmer-color)_var(--spread),transparent_var(--spread))] [translate:0_0]"
              style={{ animation: `shimmer-spin-around calc(var(--speed)*2) infinite linear` }}
            />
          </div>
        </div>

        <span className="relative z-10">{children}</span>

        {/* Highlight */}
        <div
          className={cn(
            "insert-0 absolute size-full",
            "rounded-2xl px-4 py-1.5 text-sm font-medium shadow-[inset_0_-8px_10px_#ffffff1f]",
            "transform-gpu transition-all duration-300 ease-in-out",
            "group-hover:shadow-[inset_0_-6px_10px_#ffffff3f]",
            "group-active:shadow-[inset_0_-10px_10px_#ffffff3f]",
          )}
        />

        {/* backdrop */}
        <div
          className={cn(
            "absolute [background:var(--bg)] [border-radius:var(--radius)]",
            "-z-20 [inset:var(--cut)]",
          )}
        />
      </button>
    );
  },
);
ShimmerButton.displayName = "ShimmerButton";
