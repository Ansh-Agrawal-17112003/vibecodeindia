export function DemoBadge({ className = "" }: { className?: string }) {
  return (
    <span
      className={`inline-block rounded-sm border border-foreground bg-yellow-300 px-1 py-[1px] text-[8px] font-black uppercase tracking-wider text-foreground shadow-[1px_1px_0_0_#0F0F0F] sm:text-[9px] ${className}`}
    >
      Demo
    </span>
  );
}
