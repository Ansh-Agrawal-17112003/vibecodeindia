"use client";

import { motion, useInView, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useRef } from "react";
import { cn } from "@/lib/utils";

interface KineticTextProps {
  text: string;
  className?: string;
  /** index at which the accent color starts (inclusive). Letters before → base, from splitAt onward → accent */
  splitAt?: number;
  baseColor?: string;
  accentColor?: string;
}

export function KineticText({
  text,
  className,
  splitAt,
  baseColor = "#FFFFFF",
  accentColor = "#E8623A",
}: KineticTextProps) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.4 });
  const mouseX = useMotionValue(-9999);

  const chars = Array.from(text);

  return (
    <div
      ref={ref}
      onMouseMove={(e) => {
        const rect = ref.current?.getBoundingClientRect();
        if (rect) mouseX.set(e.clientX - rect.left);
      }}
      onMouseLeave={() => mouseX.set(-9999)}
      className={cn(
        "relative inline-flex cursor-default select-none font-display font-black leading-[0.9]",
        className,
      )}
      aria-label={text}
    >
      {chars.map((ch, i) => (
        <Letter
          key={i}
          char={ch}
          index={i}
          total={chars.length}
          inView={inView}
          mouseX={mouseX}
          color={splitAt !== undefined && i >= splitAt ? accentColor : baseColor}
        />
      ))}
    </div>
  );
}

function Letter({
  char,
  index,
  total,
  inView,
  mouseX,
  color,
}: {
  char: string;
  index: number;
  total: number;
  inView: boolean;
  mouseX: ReturnType<typeof useMotionValue<number>>;
  color: string;
}) {
  const letterRef = useRef<HTMLSpanElement>(null);

  // Distance-based reaction to cursor (desktop only — touch doesn't fire mousemove)
  const distance = useTransform(mouseX, (mx) => {
    const el = letterRef.current;
    const parent = el?.parentElement;
    if (!el || !parent) return 9999;
    const parentRect = parent.getBoundingClientRect();
    const rect = el.getBoundingClientRect();
    const center = rect.left - parentRect.left + rect.width / 2;
    return Math.abs(mx - center);
  });

  const lift = useTransform(distance, [0, 180], [-28, 0], { clamp: true });
  const smoothLift = useSpring(lift, { stiffness: 260, damping: 22, mass: 0.6 });

  return (
    <motion.span
      ref={letterRef}
      initial={{ y: "110%", rotate: 8, opacity: 0, scaleY: 1.35 }}
      animate={
        inView
          ? {
              y: ["110%", "-6%", "0%"],
              rotate: [8, -2, 0],
              opacity: [0, 1, 1],
              scaleY: [1.35, 0.96, 1],
            }
          : {}
      }
      transition={{
        duration: 0.9,
        delay: index * (0.55 / Math.max(total, 1)),
        ease: [0.22, 1, 0.36, 1],
        times: [0, 0.65, 1],
      }}
      style={{
        display: "inline-block",
        transformOrigin: "50% 100%",
        color,
        y: inView ? smoothLift : undefined,
      }}
    >
      {char === " " ? "\u00A0" : char}
    </motion.span>
  );
}
