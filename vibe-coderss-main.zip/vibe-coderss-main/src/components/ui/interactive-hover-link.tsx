import * as React from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface InteractiveHoverLinkProps {
  to: string;
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  /** Fill color the dot expands into on hover (also the dot color) */
  revealBg?: string;
  /** Text color shown once the reveal fills the pill */
  revealFg?: string;
}

/**
 * Magic UI "Interactive Hover Button" adapted for TanStack Link.
 * Keeps the caller's base pill styling (background/color/border/shadow via
 * `style`) and animates a small dot into a full-fill reveal on hover.
 */
export function InteractiveHoverLink({
  to,
  children,
  className,
  style,
  revealBg = "#0F0F0F",
  revealFg = "#ffffff",
}: InteractiveHoverLinkProps) {
  return (
    <Link
      to={to as string}
      className={cn(
        "group relative inline-flex cursor-pointer items-center justify-center overflow-hidden rounded-xl px-6 py-3 text-sm font-semibold transition-transform hover:-translate-y-0.5",
        className,
      )}
      style={style}
    >
      <span className="relative z-[1] flex items-center gap-2">
        <span
          className="h-2 w-2 rounded-full transition-all duration-500 ease-out group-hover:scale-[100.8]"
          style={{ background: revealBg }}
        />
        <span className="inline-block transition-all duration-300 group-hover:translate-x-12 group-hover:opacity-0">
          {children}
        </span>
      </span>
      <span
        className="absolute inset-0 z-[2] flex translate-x-12 items-center justify-center gap-2 opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100"
        style={{ color: revealFg }}
      >
        <span>{children}</span>
        <ArrowRight className="h-4 w-4" />
      </span>
    </Link>
  );
}
