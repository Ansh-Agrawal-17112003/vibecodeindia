import { BadgeCheck, Rocket, Trophy } from "lucide-react";

interface BadgeProps {
  profile: {
    is_og_member?: boolean | null;
    og_number?: number | null;
    is_verified?: boolean | null;
    subscription_plan?: string | null;
    is_boosted?: boolean | null;
  };
  size?: "xs" | "sm" | "md";
}

const SIZE_CLS: Record<NonNullable<BadgeProps["size"]>, string> = {
  xs: "text-[9px] px-1.5 py-0.5 gap-0.5",
  sm: "text-[10px] px-2 py-0.5 gap-1",
  md: "text-[11px] px-2.5 py-1 gap-1",
};

export function MemberBadges({ profile, size = "sm" }: BadgeProps) {
  const cls = SIZE_CLS[size];
  const iconSize = size === "xs" ? "h-2.5 w-2.5" : "h-3 w-3";
  return (
    <div className="inline-flex flex-wrap items-center gap-1">
      {profile.is_og_member && profile.og_number ? (
        <span
          className={`inline-flex items-center rounded-full border-[1.5px] border-[#0F0F0F] font-black uppercase tracking-wide text-white shadow-[1px_1px_0_0_#0F0F0F] ${cls}`}
          style={{ background: "linear-gradient(135deg, #F5A623, #E8623A)" }}
          title={`OG Founder #${profile.og_number}`}
        >
          <Trophy className={iconSize} /> OG #{profile.og_number}
        </span>
      ) : profile.is_verified ? (
        <span
          className={`inline-flex items-center rounded-full bg-coral font-bold text-white ${cls}`}
          title="Verified"
        >
          <BadgeCheck className={iconSize} /> Verified
        </span>
      ) : null}

      {profile.subscription_plan === "pro" && !profile.is_og_member && (
        <span
          className={`inline-flex items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-gold font-black uppercase text-foreground shadow-[1px_1px_0_0_#0F0F0F] ${cls}`}
        >
          PRO
        </span>
      )}

      {profile.is_boosted && (
        <span
          className={`inline-flex items-center rounded-full border border-emerald-300 bg-emerald-50 font-bold text-emerald-700 ${cls}`}
          title="Boost active"
        >
          <Rocket className={iconSize} /> Boosted
        </span>
      )}
    </div>
  );
}
