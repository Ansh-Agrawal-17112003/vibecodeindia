import * as React from "react";
import { cn } from "@/lib/utils";

interface GlareHoverProps extends React.HTMLAttributes<HTMLDivElement> {
  duration?: number;
  glareColor?: string;
  glareOpacity?: number;
  glareAngle?: number;
  glareSize?: number;
  children: React.ReactNode;
}

export function GlareHover({
  className,
  duration = 600,
  glareColor = "#ffffff",
  glareOpacity = 0.45,
  glareAngle = -30,
  glareSize = 250,
  style,
  children,
  ...props
}: GlareHoverProps) {
  const [hover, setHover] = React.useState(false);
  const rgba = React.useMemo(() => {
    const hex = glareColor.replace("#", "");
    const bigint = parseInt(hex.length === 3 ? hex.split("").map(c => c + c).join("") : hex, 16);
    const r = (bigint >> 16) & 255;
    const g = (bigint >> 8) & 255;
    const b = bigint & 255;
    return `${r}, ${g}, ${b}`;
  }, [glareColor]);

  return (
    <div
      {...props}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      className={cn("relative overflow-hidden isolate", className)}
      style={style}
    >
      {children}
      <span
        aria-hidden
        className="pointer-events-none absolute inset-0 z-[2]"
        style={{
          background: `linear-gradient(${glareAngle}deg, rgba(${rgba},0) 40%, rgba(${rgba},${glareOpacity}) 50%, rgba(${rgba},0) 60%)`,
          backgroundSize: `${glareSize}% ${glareSize}%`,
          backgroundRepeat: "no-repeat",
          backgroundPosition: hover ? "-20% -20%" : "120% 120%",
          transition: `background-position ${duration}ms ease`,
          mixBlendMode: "overlay",
        }}
      />
    </div>
  );
}
