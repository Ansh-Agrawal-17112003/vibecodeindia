import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export interface DiaTextRevealProps {
  text: string | string[];
  colors?: string[];
  className?: string;
  repeat?: boolean;
  repeatDelay?: number;
  duration?: number;
  stagger?: number;
}

const DEFAULT_COLORS = ["#E8623A", "#F5A623", "#0F0F0F"];

/**
 * DiaTextReveal — per-character blur + gradient sweep reveal, rotating.
 */
export function DiaTextReveal({
  text,
  colors = DEFAULT_COLORS,
  className,
  repeat = false,
  repeatDelay = 1.4,
  duration = 0.55,
  stagger = 0.04,
}: DiaTextRevealProps) {
  const phrasesKey = Array.isArray(text) ? text.join("\u0001") : text;
  const phrases = useMemo(
    () => (Array.isArray(text) ? text : [text]),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [phrasesKey],
  );
  const [index, setIndex] = useState(0);
  const current = phrases[index % phrases.length];

  useEffect(() => {
    if (!repeat || phrases.length <= 1) return;
    const totalReveal = current.length * stagger + duration;
    const t = window.setTimeout(
      () => setIndex((n) => (n + 1) % phrases.length),
      (totalReveal + repeatDelay) * 1000,
    );
    return () => window.clearTimeout(t);
  }, [index, phrasesKey, repeat, repeatDelay, duration, stagger]);

  const gradient = `linear-gradient(90deg, ${colors.join(", ")})`;
  const maxLen = Math.max(...phrases.map((p) => p.length));

  return (
    <span
      className={`relative inline-block align-baseline ${className ?? ""}`}
      style={{ minWidth: `${maxLen}ch` }}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={current}
          className="inline-block whitespace-nowrap"
          aria-label={current}
        >
          {Array.from(current).map((ch, i) => (
            <motion.span
              key={`${current}-${i}`}
              aria-hidden
              initial={{ opacity: 0, y: 14, filter: "blur(10px)" }}
              animate={{
                opacity: 1,
                y: 0,
                filter: "blur(0px)",
                transition: { delay: i * stagger, duration, ease: [0.22, 1, 0.36, 1] },
              }}
              exit={{
                opacity: 0,
                y: -12,
                filter: "blur(8px)",
                transition: { delay: i * (stagger * 0.5), duration: 0.3, ease: [0.4, 0, 1, 1] },
              }}
              style={{
                display: "inline-block",
                backgroundImage: gradient,
                backgroundSize: "200% 100%",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
                WebkitTextFillColor: "transparent",
                whiteSpace: "pre",
              }}
            >
              {ch === " " ? "\u00A0" : ch}
            </motion.span>
          ))}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}
