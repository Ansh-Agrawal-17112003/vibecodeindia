import { useEffect, useState } from "react";

export function ScrollProgressBar() {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      setPct(max > 0 ? (h.scrollTop / max) * 100 : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-x-0 top-0 z-[60] h-[3px]"
      style={{ background: "transparent" }}
    >
      <div
        className="h-full origin-left"
        style={{
          width: `${pct}%`,
          background: "linear-gradient(90deg, #E8623A, #F5A623)",
          boxShadow: "0 0 12px rgba(232,98,58,0.6)",
          transition: "width 80ms linear",
        }}
      />
    </div>
  );
}
