import type { LucideIcon } from "lucide-react";
import {
  Sparkles,
  UserCircle2,
  Users,
  Briefcase,
  BookOpen,
  Wrench,
  Workflow,
  Rocket,
  Code2,
  Building2,
  Megaphone,
  UserRoundCog,
  FileText,
  GraduationCap,
  Newspaper,
  Mail,
  CalendarDays,
  Book,
  Package,
  Webhook,
  Puzzle,
  History,
  Search,
  Palette,
  ListFilter,
  Trophy,
  Award,
  Quote,
  PartyPopper,
  MessagesSquare,
  Video,
  BadgeCheck,
  IndianRupee,
  Layers,
  Building,
  Scale,
} from "lucide-react";

export type MegaItem = {
  label: string;
  description: string;
  icon: LucideIcon;
  to: string;
  hash?: string;
};

export type MegaSection = {
  key: string;
  label: string;
  columns: 1 | 2;
  items: MegaItem[];
};

export const MEGA_NAV: MegaSection[] = [
  {
    key: "product",
    label: "Product",
    columns: 2,
    items: [
      { label: "Vibe Feed", description: "Social feed built for AI builders", icon: Sparkles, to: "/product/vibe-feed" },
      { label: "Builder Profiles", description: "Portfolio, XP, streaks & badges", icon: UserCircle2, to: "/product/builder-profiles" },
      { label: "Communities", description: "Real classrooms, chat & cohorts", icon: Users, to: "/product/communities" },
      { label: "Jobs Board", description: "AI & vibe-coding roles in India", icon: Briefcase, to: "/product/jobs-board" },
      { label: "Prompt Library", description: "Curated prompts that ship", icon: BookOpen, to: "/product/prompt-library" },
      { label: "AI Tools Directory", description: "Vetted tools with real reviews", icon: Wrench, to: "/product/ai-tools" },
      { label: "Workflow Templates", description: "n8n & automation blueprints", icon: Workflow, to: "/product/workflow-templates" },
      { label: "Project Showcase", description: "Ship, get discovered, get hired", icon: Rocket, to: "/product/project-showcase" },
    ],
  },
  {
    key: "solutions",
    label: "Solutions",
    columns: 1,
    items: [
      { label: "For Indie Builders", description: "Ship in public, find your crew", icon: Rocket, to: "/solutions/indie-builders" },
      { label: "For AI Engineers", description: "Deep prompts, tools & jobs", icon: Code2, to: "/solutions/ai-engineers" },
      { label: "For Startups Hiring", description: "Reach 120k+ vetted builders", icon: Building2, to: "/solutions/startups-hiring" },
      { label: "For Community Leaders", description: "Run cohorts on autopilot", icon: Megaphone, to: "/solutions/community-leaders" },
      { label: "For Agencies", description: "Source talent & showcase work", icon: UserRoundCog, to: "/solutions/agencies" },
    ],
  },
  {
    key: "resources",
    label: "Resources",
    columns: 1,
    items: [
      { label: "Blog", description: "Playbooks & builder stories", icon: FileText, to: "/blog" },
      { label: "Tutorials & Guides", description: "Learn by shipping", icon: GraduationCap, to: "/resources/tutorials" },
      { label: "Case Studies", description: "How builders got hired", icon: Newspaper, to: "/resources/case-studies" },
      { label: "Newsletter", description: "Weekly signal, zero noise", icon: Mail, to: "/resources/newsletter" },
      { label: "Events & Meetups", description: "IRL vibe sessions", icon: CalendarDays, to: "/resources/events" },
    ],
  },
  {
    key: "developers",
    label: "Developers",
    columns: 1,
    items: [
      { label: "API Docs", description: "Query the platform", icon: Book, to: "/developers/api" },
      { label: "SDKs & Libraries", description: "TS, Python & more", icon: Package, to: "/developers/sdks" },
      { label: "Webhooks", description: "Realtime event streams", icon: Webhook, to: "/developers/webhooks" },
      { label: "Integrations", description: "Plug into your stack", icon: Puzzle, to: "/developers/integrations" },
      { label: "Changelog", description: "What shipped this week", icon: History, to: "/developers/changelog" },
    ],
  },
  {
    key: "enterprise",
    label: "Enterprise",
    columns: 1,
    items: [
      { label: "Talent Sourcing", description: "Vetted builders on demand", icon: Search, to: "/enterprise/talent-sourcing" },
      { label: "Community-as-a-Service", description: "We run the cohort, you ship", icon: Users, to: "/enterprise/community-as-a-service" },
      { label: "Employer Branding", description: "Own your presence here", icon: Palette, to: "/enterprise/employer-branding" },
      { label: "Custom Job Feeds", description: "Curated pipelines by role", icon: ListFilter, to: "/enterprise/custom-job-feeds" },
    ],
  },
  {
    key: "learn",
    label: "Learn",
    columns: 1,
    items: [
      { label: "Classroom (live cohorts)", description: "Learn from top builders", icon: GraduationCap, to: "/communities" },
      { label: "Prompt Engineering 101", description: "From zero to shipping", icon: BookOpen, to: "/prompts" },
      { label: "Vibe Coding Bootcamp", description: "12 weeks, real projects", icon: Rocket, to: "/learn/bootcamp" },
      { label: "Video Library", description: "Watch, pause, ship", icon: Video, to: "/learn/videos" },
      { label: "Certifications", description: "Prove your craft", icon: BadgeCheck, to: "/learn/certifications" },
    ],
  },
  {
    key: "community",
    label: "Community",
    columns: 1,
    items: [
      { label: "Leaderboard", description: "Top builders this week", icon: Trophy, to: "/leaderboard" },
      { label: "Founders Wall", description: "The OG 100", icon: Award, to: "/founders-wall" },
      { label: "Testimonials", description: "Words from the crew", icon: Quote, to: "/testimonials" },
      { label: "Wins", description: "Ship logs that inspire", icon: PartyPopper, to: "/wins" },
      { label: "Discord / X / GitHub", description: "Hang out with builders", icon: MessagesSquare, to: "/community/social" },
    ],
  },
  {
    key: "pricing",
    label: "Pricing",
    columns: 1,
    items: [
      { label: "Individual Plans", description: "For solo builders", icon: IndianRupee, to: "/pricing/individual" },
      { label: "Team Plans", description: "For crews & agencies", icon: Layers, to: "/pricing/team" },
      { label: "Enterprise", description: "Custom rollouts", icon: Building, to: "/pricing/enterprise" },
      { label: "Compare Plans", description: "See it side by side", icon: Scale, to: "/pricing/compare" },
    ],
  },
];
