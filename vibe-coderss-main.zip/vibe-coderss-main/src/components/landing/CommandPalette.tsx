import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  Search,
  Compass,
  Briefcase,
  Users,
  Sparkles,
  Rocket,
  Flame,
  BookOpen,
  Award,
  HelpCircle,
  DollarSign,
  Home,
} from "lucide-react";

type Cmd = {
  id: string;
  label: string;
  hint: string;
  group: "Navigate" | "Discover" | "Support";
  icon: React.ComponentType<{ className?: string }>;
  action: () => void;
};

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [idx, setIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const commands: Cmd[] = useMemo(
    () => [
      { id: "home", label: "Home", hint: "Landing page", group: "Navigate", icon: Home, action: () => navigate({ to: "/" }) },
      { id: "vibe", label: "The Vibe Feed", hint: "Live builder feed", group: "Navigate", icon: Flame, action: () => navigate({ to: "/vibe" }) },
      { id: "explore", label: "Explore Builders", hint: "Find AI builders", group: "Discover", icon: Compass, action: () => navigate({ to: "/explore" }) },
      { id: "jobs", label: "Browse Jobs", hint: "300+ AI roles", group: "Discover", icon: Briefcase, action: () => navigate({ to: "/jobs" }) },
      { id: "projects", label: "Projects", hint: "See what's shipping", group: "Discover", icon: Rocket, action: () => navigate({ to: "/projects" }) },
      { id: "prompts", label: "Prompt Library", hint: "Battle-tested prompts", group: "Discover", icon: Sparkles, action: () => navigate({ to: "/prompts" }) },
      { id: "communities", label: "Communities", hint: "12 active groups", group: "Discover", icon: Users, action: () => navigate({ to: "/communities" }) },
      { id: "templates", label: "Templates", hint: "Ship faster", group: "Discover", icon: BookOpen, action: () => navigate({ to: "/templates" }) },
      { id: "leaderboard", label: "Leaderboard", hint: "Top builders", group: "Discover", icon: Award, action: () => navigate({ to: "/leaderboard" }) },
      { id: "pricing", label: "Pricing", hint: "Free forever for builders", group: "Support", icon: DollarSign, action: () => navigate({ to: "/pricing" }) },
      { id: "blog", label: "Blog", hint: "Latest posts", group: "Support", icon: BookOpen, action: () => navigate({ to: "/blog" }) },
      { id: "faq", label: "FAQ", hint: "Common questions", group: "Support", icon: HelpCircle, action: () => document.getElementById("faq")?.scrollIntoView({ behavior: "smooth" }) },
      { id: "signup", label: "Join VibeCode", hint: "Create free account", group: "Support", icon: Rocket, action: () => navigate({ to: "/signup" }) },
    ],
    [navigate],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return commands;
    return commands.filter(
      (c) => c.label.toLowerCase().includes(q) || c.hint.toLowerCase().includes(q),
    );
  }, [query, commands]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (open) {
      setQuery("");
      setIdx(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  useEffect(() => setIdx(0), [query]);

  if (!open) return null;

  const runAt = (i: number) => {
    const cmd = filtered[i];
    if (!cmd) return;
    cmd.action();
    setOpen(false);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setIdx((i) => Math.min(i + 1, filtered.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setIdx((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      runAt(idx);
    }
  };

  // group filtered
  const groups: Record<string, Cmd[]> = {};
  filtered.forEach((c) => {
    groups[c.group] = groups[c.group] || [];
    groups[c.group].push(c);
  });

  let flatIdx = -1;

  return (
    <div
      className="fixed inset-0 z-[80] flex items-start justify-center px-4 pt-[12vh]"
      onClick={() => setOpen(false)}
      style={{ background: "rgba(15,15,15,0.55)", backdropFilter: "blur(6px)", animation: "cmdFade 150ms ease-out" }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-[560px] overflow-hidden rounded-2xl bg-white"
        style={{
          border: "1px solid #E8E0D6",
          boxShadow: "0 30px 80px -20px rgba(0,0,0,0.5)",
          animation: "cmdRise 180ms cubic-bezier(0.22,1,0.36,1)",
        }}
      >
        <div className="flex items-center gap-2 border-b px-4 py-3.5" style={{ borderColor: "#EFE9DF" }}>
          <Search className="h-4 w-4" style={{ color: "#888" }} />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Type a command or search…"
            className="flex-1 bg-transparent text-[15px] outline-none"
            style={{ color: "#1c1a16" }}
          />
          <kbd className="rounded-md border px-1.5 py-0.5 font-mono text-[10px]" style={{ borderColor: "#E8E0D6", color: "#8a8578", background: "#FAF7F1" }}>
            ESC
          </kbd>
        </div>

        <div className="max-h-[52vh] overflow-y-auto p-2">
          {filtered.length === 0 && (
            <div className="px-4 py-10 text-center text-sm" style={{ color: "#8a8578" }}>
              No commands match "{query}".
            </div>
          )}
          {Object.entries(groups).map(([g, items]) => (
            <div key={g} className="mb-1">
              <div className="px-3 pb-1 pt-2 font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: "#a39d8f" }}>
                {g}
              </div>
              {items.map((c) => {
                flatIdx++;
                const isActive = flatIdx === idx;
                const myIdx = flatIdx;
                return (
                  <button
                    key={c.id}
                    onMouseEnter={() => setIdx(myIdx)}
                    onClick={() => runAt(myIdx)}
                    className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-left transition-colors"
                    style={{
                      background: isActive ? "#FFF1EA" : "transparent",
                      color: "#1c1a16",
                    }}
                  >
                    <span
                      className="grid h-8 w-8 place-items-center rounded-md"
                      style={{
                        background: isActive ? "#E8623A" : "#F5F1E8",
                        color: isActive ? "#fff" : "#8a8578",
                      }}
                    >
                      <c.icon className="h-4 w-4" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="text-[14px] font-semibold">{c.label}</div>
                      <div className="truncate text-[12px]" style={{ color: "#8a8578" }}>{c.hint}</div>
                    </div>
                    {isActive && (
                      <kbd className="rounded-md border px-1.5 py-0.5 font-mono text-[10px]" style={{ borderColor: "#F4C7B4", color: "#E8623A", background: "#fff" }}>
                        ↵
                      </kbd>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between border-t px-4 py-2.5 text-[11px]" style={{ borderColor: "#EFE9DF", background: "#FAF7F1", color: "#8a8578" }}>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1"><kbd className="rounded border px-1 font-mono" style={{ borderColor: "#E8E0D6" }}>↑</kbd><kbd className="rounded border px-1 font-mono" style={{ borderColor: "#E8E0D6" }}>↓</kbd> navigate</span>
            <span className="flex items-center gap-1"><kbd className="rounded border px-1 font-mono" style={{ borderColor: "#E8E0D6" }}>↵</kbd> select</span>
          </div>
          <span className="flex items-center gap-1">
            <kbd className="rounded border px-1 font-mono" style={{ borderColor: "#E8E0D6" }}>⌘</kbd>
            <kbd className="rounded border px-1 font-mono" style={{ borderColor: "#E8E0D6" }}>K</kbd>
          </span>
        </div>
      </div>

      <style>{`
        @keyframes cmdFade { from { opacity: 0 } to { opacity: 1 } }
        @keyframes cmdRise { from { opacity: 0; transform: translateY(-8px) scale(0.98) } to { opacity: 1; transform: translateY(0) scale(1) } }
      `}</style>
    </div>
  );
}

/** Floating hint pill that opens the palette on click. */
export function CommandKHint() {
  const dispatch = () => {
    window.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true }));
  };
  return (
    <button
      onClick={dispatch}
      className="fixed bottom-5 left-5 z-40 hidden items-center gap-1.5 rounded-full border bg-white/95 px-3 py-1.5 text-[11px] font-semibold shadow-lg backdrop-blur transition-all hover:-translate-y-0.5 hover:shadow-xl lg:inline-flex"
      style={{ borderColor: "#E8E0D6", color: "#3d3a33" }}
    >
      Press
      <kbd className="rounded-md border px-1.5 py-0.5 font-mono text-[10px]" style={{ borderColor: "#E8E0D6", background: "#FAF7F1", color: "#8a8578" }}>⌘K</kbd>
      to search
    </button>
  );
}
