import { Link } from "@tanstack/react-router";
import { Search, Send } from "lucide-react";

const INK = "#0F0F0F";
const CORAL = "#E8623A";

export function DiscoverBuilders() {
  return (
    <section className="w-full border-t-[1.5px]" style={{ background: "#FAF7F1", borderColor: INK }}>
      <div className="mx-auto max-w-[1200px] px-5 py-16 md:px-8 md:py-24">
        <div className="grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
          <div>
            <h2 className="font-display text-[32px] md:text-[52px] font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ color: INK }}>
              Discover builders on demand.
            </h2>
            <p className="mt-3 max-w-[560px] text-[15px] md:text-[17px]" style={{ color: "#4a463d" }}>
              Search 120K+ Indian AI builders by tool, city, and what they've actually shipped. No resumes. No recruiters. DM them directly.
            </p>
          </div>
          <Link
            to="/explore"
            className="inline-flex items-center gap-2 self-start rounded-xl border-[1.5px] px-5 py-3 text-sm font-extrabold uppercase tracking-wide text-white md:self-end"
            style={{ background: CORAL, borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
          >
            Browse builders
          </Link>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {/* Coral: search-by-tool */}
          <div className="rounded-2xl border-[1.5px] p-6 md:p-8" style={{ background: "#FFE4D6", borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}>
            <div className="text-lg font-extrabold" style={{ color: INK }}>Search by tool. Instantly.</div>
            <p className="mt-1 text-[13.5px]" style={{ color: "#4a463d" }}>Type any AI tool. See who's shipping with it this week.</p>
            <div className="mt-5 flex items-center gap-2 rounded-lg border-[1.5px] bg-white px-3 py-2.5" style={{ borderColor: INK }}>
              <Search className="h-4 w-4" style={{ color: CORAL }} />
              <span className="text-[13px] font-bold" style={{ color: INK }}>lovable</span>
              <span className="text-[12px]" style={{ color: "#8a8578" }}>in Bangalore</span>
            </div>
            <div className="mt-3 space-y-2">
              {[
                { n: "Arjun M.", s: "12 projects · 4.9★", seed: "arjunbuilds" },
                { n: "Neha K.", s: "8 projects · Available", seed: "nehaships" },
                { n: "Vikram R.", s: "22 projects · Top 1%", seed: "vikramr" },
              ].map((b, i) => (
                <div
                  key={b.n}
                  className="group/row flex items-center justify-between rounded-md bg-white/70 px-3 py-2 text-[13px] transition-all duration-300 hover:translate-x-1 hover:bg-white hover:shadow-[3px_3px_0_0_#0F0F0F] cursor-pointer"
                  style={{ animation: `discoverFade 0.5s ease-out ${i * 100}ms both` }}
                >
                  <span className="flex items-center gap-2">
                    <img src={`https://api.dicebear.com/7.x/notionists/svg?seed=${b.seed}`} alt="" className="h-6 w-6 rounded-full border-[1.5px] bg-white transition-transform duration-300 group-hover/row:scale-110 group-hover/row:rotate-6" style={{ borderColor: INK }} />
                    <span className="font-bold" style={{ color: INK }}>{b.n}</span>
                  </span>
                  <span className="flex items-center gap-1.5" style={{ color: "#4a463d" }}>
                    {b.s}
                    <Send className="h-3 w-3 -translate-x-1 opacity-0 transition-all duration-300 group-hover/row:translate-x-0 group-hover/row:opacity-100" style={{ color: CORAL }} />
                  </span>
                </div>
              ))}
            </div>
            <style>{`@keyframes discoverFade { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }`}</style>
          </div>

          {/* Blue: DM mock */}
          <div className="rounded-2xl border-[1.5px] p-6 md:p-8" style={{ background: "#E6F0FF", borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}>
            <div className="text-lg font-extrabold" style={{ color: INK }}>DM any builder. Skip the gate.</div>
            <p className="mt-1 text-[13.5px]" style={{ color: "#4a463d" }}>No connection requests. No cold email tax. Just message.</p>
            <div className="mt-5 space-y-2 min-h-[132px]">
              <div className="ml-auto max-w-[80%] rounded-2xl rounded-br-sm bg-white px-3.5 py-2 text-[13px] db-msg db-msg-1" style={{ color: INK }}>
                Hey — loved your CRM workflow. Can you build one for us this week?
              </div>
              <div className="mr-auto max-w-[80%] rounded-2xl rounded-bl-sm px-3.5 py-2 text-[13px] text-white db-msg db-msg-2" style={{ background: "#2a5cd6" }}>
                Yes. Free 15-min call at 4pm?
              </div>
              <div className="ml-auto max-w-[70%] rounded-2xl rounded-br-sm bg-white px-3.5 py-2 text-[13px] db-msg db-msg-3" style={{ color: INK }}>
                Booked. See you.
              </div>
              <div className="mr-auto inline-flex items-center gap-1 rounded-2xl rounded-bl-sm bg-white px-3 py-2 db-msg db-msg-4" style={{ color: INK }}>
                <span className="db-dot" />
                <span className="db-dot db-dot-2" />
                <span className="db-dot db-dot-3" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-2 rounded-lg border-[1.5px] bg-white px-3 py-2" style={{ borderColor: INK }}>
              <span className="flex-1 text-[13px] db-typer" style={{ color: INK }} />
              <Send className="h-4 w-4 db-send-pulse" style={{ color: "#2a5cd6" }} />
            </div>
            <style>{`
              @keyframes dbMsgIn {
                0%, 8%   { opacity: 0; transform: translateY(6px) scale(0.96); }
                14%, 100% { opacity: 1; transform: translateY(0) scale(1); }
              }
              .db-msg { opacity: 0; animation: dbMsgIn 8s ease-out infinite; }
              .db-msg-1 { animation-delay: 0s; }
              .db-msg-2 { animation-delay: 1.4s; }
              .db-msg-3 { animation-delay: 2.8s; }
              .db-msg-4 { animation-delay: 4.2s; }
              @keyframes dbDot {
                0%, 60%, 100% { opacity: 0.3; transform: translateY(0); }
                30%           { opacity: 1;   transform: translateY(-2px); }
              }
              .db-dot { display:inline-block; width:5px; height:5px; border-radius:9999px; background:#0F0F0F; animation: dbDot 1s ease-in-out infinite; }
              .db-dot-2 { animation-delay: 0.15s; }
              .db-dot-3 { animation-delay: 0.3s; }
              @keyframes dbTyper {
                0%, 10%  { content: ""; }
                20%      { content: "M"; }
                24%      { content: "Me"; }
                28%      { content: "Mes"; }
                32%      { content: "Mess"; }
                36%      { content: "Messa"; }
                40%      { content: "Messag"; }
                44%      { content: "Message"; }
                50%      { content: "Message N"; }
                54%      { content: "Message Ne"; }
                58%      { content: "Message Neh"; }
                62%      { content: "Message Neha"; }
                66%      { content: "Message Neha…"; }
                90%, 100% { content: "Message Neha…"; }
              }
              .db-typer::before { content: "Message Neha…"; animation: dbTyper 6s steps(1, end) infinite; color: #8a8578; }
              @keyframes dbSend { 0%, 80%, 100% { transform: scale(1); } 88% { transform: scale(1.25) rotate(-10deg); } }
              .db-send-pulse { animation: dbSend 6s ease-in-out infinite; transform-origin: center; }
              @media (prefers-reduced-motion: reduce) {
                .db-msg, .db-dot, .db-typer::before, .db-send-pulse { animation: none !important; opacity: 1 !important; }
              }
            `}</style>
          </div>
        </div>
      </div>
    </section>
  );
}
