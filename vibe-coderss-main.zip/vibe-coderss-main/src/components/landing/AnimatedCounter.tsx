import { useEffect, useState } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

function format(n: number) {
  if (n >= 100000) return `${Math.round(n / 1000)}K`;
  if (n >= 10000) return `${(n / 1000).toFixed(1)}K`;
  if (n >= 1000) return n.toLocaleString("en-IN");
  return n.toString();
}

export function AnimatedCounter({
  end,
  prefix = "",
  suffix = "",
  duration = 1800,
  formatK = true,
}: {
  end: number;
  prefix?: string;
  suffix?: string;
  duration?: number;
  formatK?: boolean;
}) {
  const { ref, isVisible } = useScrollAnimation<HTMLSpanElement>();
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isVisible) return;
    let raf = 0;
    let start = 0;
    const step = (t: number) => {
      if (!start) start = t;
      const p = Math.min((t - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setCount(Math.floor(eased * end));
      if (p < 1) raf = requestAnimationFrame(step);
      else setCount(end);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [isVisible, end, duration]);

  return (
    <span ref={ref}>
      {prefix}
      {formatK ? format(count) : count.toLocaleString("en-IN")}
      {suffix}
    </span>
  );
}
