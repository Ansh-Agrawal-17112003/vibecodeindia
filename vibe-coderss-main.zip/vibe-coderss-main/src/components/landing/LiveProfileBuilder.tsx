import { useMemo, useState } from "react";
import { MapPin, Star, Users, BadgeCheck, Sparkles, ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";

const TOOLS = ["Lovable", "Claude", "n8n", "Cursor", "Supabase", "GPT-4o", "Midjourney", "Make", "Bolt"];
const CITIES = ["Bengaluru", "Mumbai", "Delhi", "Hyderabad", "Pune", "Chennai", "Kolkata", "Ahmedabad", "Remote"];
const TITLES = ["AI Builder", "Full-stack Vibe Coder", "n8n Automation Pro", "Lovable Specialist", "Prompt Engineer", "Solo Founder"];

export function LiveProfileBuilder() {
  const [name, setName] = useState("Aarav Mehta");
  const [title, setTitle] = useState(TITLES[0]);
  const [city, setCity] = useState(CITIES[0]);
  const [tools, setTools] = useState<string[]>(["Lovable", "Claude", "n8n"]);
  const [avatarSeed, setAvatarSeed] = useState("aarav-42");

  const toggleTool = (t: string) => {
    setTools((prev) => prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t].slice(0, 5));
  };

  const rating = useMemo(() => (4.6 + (tools.length * 0.05)).toFixed(1), [tools.length]);
  const followers = useMemo(() => 340 + tools.length * 47 + name.length * 3, [tools.length, name]);

  return (
    <section data-reveal data-label="Build Profile" className="relative w-full overflow-hidden" style={{ background: "#0F0F0F" }}>
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{ background: "radial-gradient(600px circle at 80% 30%, rgba(232,98,58,0.16), transparent 60%)" }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage: "radial-gradient(rgba(255,255,255,0.04) 1px, transparent 1px)",
          backgroundSize: "22px 22px",
          maskImage: "radial-gradient(ellipse 70% 60% at 50% 50%, #000 40%, transparent 100%)",
        }}
      />

      <div className="relative mx-auto grid w-full max-w-[1200px] gap-10 px-5 py-16 md:grid-cols-[1.1fr_1fr] md:items-center md:px-8 md:py-24">
        {/* Left: editor */}
        <div>
          <div className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-wider" style={{ background: "rgba(232,98,58,0.15)", color: "#E8623A" }}>
            <Sparkles className="h-3 w-3" /> Build yours in 30 seconds
          </div>
          <h2 className="mt-4 font-display text-[32px] font-extrabold leading-[1.05] tracking-[-0.02em] text-white md:text-[52px]">
            This could be <span style={{ color: "#E8623A" }}>your profile</span> tomorrow.
          </h2>
          <p className="mt-4 max-w-[520px] text-[15px] leading-[1.7] md:text-[17px]" style={{ color: "#b8b8b8" }}>
            Tweak the fields below and see your live VibeCode profile card render in real time. Then claim it.
          </p>

          <div className="mt-8 space-y-5">
            <Field label="Name">
              <input
                value={name}
                onChange={(e) => setName(e.target.value.slice(0, 32))}
                className="w-full rounded-lg border bg-[#161616] px-3 py-2.5 text-[14px] text-white outline-none transition-colors focus:border-[#E8623A]"
                style={{ borderColor: "#2a2a2a" }}
              />
            </Field>
            <Field label="Title">
              <div className="flex flex-wrap gap-1.5">
                {TITLES.map((t) => (
                  <Chip key={t} active={title === t} onClick={() => setTitle(t)}>{t}</Chip>
                ))}
              </div>
            </Field>
            <Field label="City">
              <div className="flex flex-wrap gap-1.5">
                {CITIES.map((c) => (
                  <Chip key={c} active={city === c} onClick={() => setCity(c)}>{c}</Chip>
                ))}
              </div>
            </Field>
            <Field label={`Tools (${tools.length}/5)`}>
              <div className="flex flex-wrap gap-1.5">
                {TOOLS.map((t) => (
                  <Chip key={t} active={tools.includes(t)} onClick={() => toggleTool(t)}>{t}</Chip>
                ))}
              </div>
            </Field>
            <button
              onClick={() => setAvatarSeed(Math.random().toString(36).slice(2, 10))}
              className="text-[12px] font-semibold underline underline-offset-4"
              style={{ color: "#E8623A" }}
            >
              🎲 Randomize avatar
            </button>
          </div>

          <Link
            to="/signup"
            className="mt-8 inline-flex items-center gap-2 rounded-xl border-[1.5px] bg-coral px-6 py-3.5 text-sm font-extrabold uppercase tracking-wide text-white transition-all hover:-translate-y-0.5"
            style={{ borderColor: "#0F0F0F", boxShadow: "4px 4px 0 0 #E8623A" }}
          >
            Claim this profile <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        {/* Right: live preview card (mirrors BuilderCard) */}
        <div className="relative">
          <div
            className="absolute -inset-6 rounded-3xl blur-3xl opacity-40"
            style={{ background: "radial-gradient(circle, #E8623A, transparent 60%)" }}
          />
          <div
            className="relative mx-auto max-w-[360px] overflow-hidden rounded-2xl bg-white"
            style={{ border: "1.5px solid #0F0F0F", boxShadow: "8px 8px 0 0 #E8623A" }}
          >
            <div className="relative h-24" style={{ background: "linear-gradient(135deg, #E8623A, #F5A623)" }}>
              <div className="absolute -bottom-8 left-5 h-16 w-16 overflow-hidden rounded-full border-4 border-white bg-white shadow-md">
                <img
                  src={`https://api.dicebear.com/7.x/notionists/svg?seed=${avatarSeed}`}
                  alt=""
                  className="h-full w-full"
                />
              </div>
              <div className="absolute right-3 top-3 flex items-center gap-1.5 rounded-full bg-white px-2 py-0.5 text-[10px] font-bold" style={{ color: "#0a6b5e" }}>
                <span className="h-1.5 w-1.5 rounded-full bg-green-500" /> Available
              </div>
            </div>
            <div className="px-5 pb-5 pt-10">
              <div className="flex items-center gap-1.5">
                <h3 className="truncate font-display text-lg font-bold" style={{ color: "#0F0F0F" }}>{name || "Your Name"}</h3>
                <BadgeCheck className="h-4 w-4 shrink-0 text-[#E8623A]" />
                <span className="ml-auto shrink-0 rounded-sm border border-[#0F0F0F] bg-yellow-300 px-1.5 py-[1px] font-mono text-[9px] font-black uppercase tracking-wider" style={{ color: "#0F0F0F", boxShadow: "1px 1px 0 0 #0F0F0F" }}>
                  Live
                </span>
              </div>
              <p className="mt-0.5 text-sm" style={{ color: "#6a6a6a" }}>{title}</p>
              <div className="mt-2 flex items-center gap-1 text-[12px]" style={{ color: "#6a6a6a" }}>
                <MapPin className="h-3 w-3" /> {city}
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {tools.slice(0, 5).map((t) => (
                  <span key={t} className="rounded-md border px-2 py-0.5 text-[11px] font-bold" style={{ borderColor: "#EFE9DF", color: "#3d3a33", background: "#FAF7F1" }}>
                    {t}
                  </span>
                ))}
                {tools.length === 0 && <span className="text-[11px]" style={{ color: "#a39d8f" }}>Pick a tool →</span>}
              </div>
              <div className="mt-4 flex items-center gap-3 border-t pt-3 text-[12px]" style={{ borderColor: "#EFE9DF", color: "#6a6a6a" }}>
                <span className="flex items-center gap-1 font-bold" style={{ color: "#0F0F0F" }}>
                  <Star className="h-3 w-3 fill-[#F5A623] text-[#F5A623]" /> {rating}
                </span>
                <span>{Math.floor(tools.length * 4 + 12)} reviews</span>
                <span className="ml-auto flex items-center gap-1">
                  <Users className="h-3 w-3" /> {followers > 999 ? `${(followers / 1000).toFixed(1)}k` : followers}
                </span>
              </div>
            </div>
          </div>
          <div className="mt-4 text-center font-mono text-[11px]" style={{ color: "#888" }}>
            ↑ updates live as you edit
          </div>
        </div>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-2 font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: "#888" }}>
        {label}
      </div>
      {children}
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className="rounded-full border px-3 py-1 text-[12px] font-semibold transition-all"
      style={{
        background: active ? "#E8623A" : "#161616",
        borderColor: active ? "#E8623A" : "#2a2a2a",
        color: active ? "#fff" : "#c9c9c9",
        transform: active ? "scale(1.02)" : "none",
      }}
    >
      {children}
    </button>
  );
}
