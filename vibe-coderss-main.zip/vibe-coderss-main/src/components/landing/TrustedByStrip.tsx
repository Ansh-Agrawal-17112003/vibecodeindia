/**
 * TrustedByStrip — brand logo wall shown after the hero.
 * Two-row monochrome layout with dot separators (Notion / Vercel style).
 */
const ROW_ONE = [
  { name: "OpenAI", src: "/brands/openai.svg" },
  { name: "Anthropic", src: "/brands/anthropic.svg" },
  { name: "Figma", src: "/brands/figma.svg" },
  { name: "Cursor", src: "/brands/cursor.svg" },
  { name: "Vercel", src: "/brands/vercel.svg" },
  { name: "Notion", src: "/brands/notion.svg" },
  { name: "Supabase", src: "/brands/supabase.svg" },
  { name: "Stripe", src: "/brands/stripe.svg" },
  { name: "Discord", src: "/brands/discord.svg" },
];

const ROW_TWO = [
  { name: "Claude", src: "/brands/claude.svg" },
  { name: "n8n", src: "/brands/n8n.svg" },
  { name: "Linear", src: "/brands/linear.svg" },
  { name: "GitHub", src: "/brands/github.svg" },
  { name: "Replit", src: "/brands/replit.svg" },
  { name: "Zapier", src: "/brands/zapier.svg" },
  { name: "Make", src: "/brands/make.svg" },
  { name: "ClickUp", src: "/brands/clickup.svg" },
];

function LogoRow({ items }: { items: { name: string; src: string }[] }) {
  return (
    <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-4 md:gap-x-10">
      {items.map((b, i) => (
        <div key={b.name} className="flex items-center gap-x-6 md:gap-x-10">
          <img
            src={b.src}
            alt={b.name}
            title={b.name}
            loading="lazy"
            className="h-6 w-auto opacity-80 grayscale transition duration-300 hover:opacity-100 hover:grayscale-0 md:h-7"
            style={{ filter: "brightness(0)" }}
          />
          {i < items.length - 1 && (
            <span aria-hidden className="hidden text-[10px] text-[#0F0F0F]/25 md:inline">
              ●
            </span>
          )}
        </div>
      ))}
    </div>
  );
}

export function TrustedByStrip() {
  return (
    <section
      className="relative w-full"
      style={{
        background: "linear-gradient(180deg, #FAF6F1 0%, #F3ECE0 100%)",
        borderTop: "1px solid rgba(15,15,15,0.08)",
        borderBottom: "1px solid rgba(15,15,15,0.08)",
      }}
    >
      <div className="mx-auto max-w-[1180px] px-4 py-12 md:px-8 md:py-16">
        <p className="text-center text-[12px] font-semibold tracking-[0.02em] text-[#0F0F0F]/55 md:text-[13px]">
          Powering builders shipping with{" "}
          <span className="font-bold text-[#0F0F0F]/70">India's most-loved AI stack</span>
        </p>
        <div className="mt-8 space-y-6 md:mt-10 md:space-y-7">
          <LogoRow items={ROW_ONE} />
          <LogoRow items={ROW_TWO} />
        </div>
      </div>
    </section>
  );
}
