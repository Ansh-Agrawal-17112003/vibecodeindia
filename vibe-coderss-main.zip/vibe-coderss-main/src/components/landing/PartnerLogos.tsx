const INK = "#0F0F0F";

// TODO: replace with real partner names/logos
const PARTNERS = ["IIT Delhi", "BITS Pilani", "Antler India", "Sequoia Surge", "AngelList India", "100x.vc", "Nasscom", "iSPIRT"];

export function PartnerLogos() {
  return (
    <section className="w-full border-t-[1.5px]" style={{ background: "#FAF7F1", borderColor: INK }}>
      <div className="mx-auto max-w-[1200px] px-5 py-10 md:px-8 md:py-14">
        <div className="text-center font-mono text-[11px] font-extrabold uppercase tracking-[0.2em]" style={{ color: "#8a8578" }}>
          Builders from
        </div>
        <div className="mt-5 flex flex-wrap items-center justify-center gap-x-8 gap-y-4 md:gap-x-12">
          {PARTNERS.map((p) => (
            <span key={p} className="text-[14px] md:text-[15px] font-bold opacity-70" style={{ color: INK, fontFamily: "serif" }}>
              {p}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
