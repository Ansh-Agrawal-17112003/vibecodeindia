import { useEffect, useState } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const FEATURES = [
  {
    icon: "🔥",
    tab: "The Vibe Feed",
    heading: "Your builder home. Open it every morning.",
    description:
      "Projects, prompts, workflows, and questions from 120,000 AI builders — all in one intelligent feed that learns what you care about.",
    screenshot: "https://picsum.photos/seed/vibefeed/900/560",
    highlight: "Posts from people you follow + trending content",
  },
  {
    icon: "🏗",
    tab: "Builder Profiles",
    heading: "Your portfolio. Powered by proof of work.",
    description:
      "Not a resume. A live profile showing your projects, prompts, XP level, and reputation. Hirers search here. Clients DM you here.",
    screenshot: "https://picsum.photos/seed/builderprofile/900/560",
    highlight: "Verified badge + priority search placement for Pro",
  },
  {
    icon: "💼",
    tab: "Jobs Board",
    heading: "AI roles that actually match your skills.",
    description:
      "55+ jobs from India's best companies — filtered by AI tool, salary, and location. Apply in 10 seconds using your VibeCode profile.",
    screenshot: "https://picsum.photos/seed/jobsboard/900/560",
    highlight: "OG Pro members appear first in every application list",
  },
  {
    icon: "🏘",
    tab: "Communities",
    heading: "Find your people. For real.",
    description:
      "12 active communities organized by tool, industry, and experience level. Live chat, resources, events, leaderboards — all in one space.",
    screenshot: "https://picsum.photos/seed/communities/900/560",
    highlight: "450+ communities · 847K+ combined members",
  },
  {
    icon: "💡",
    tab: "Prompt Library",
    heading: "8,400+ prompts. Copy. Use. Ship.",
    description:
      "The largest collection of AI builder prompts in India. Tested and shared by real builders. Filter by tool, category, and use case.",
    screenshot: "https://picsum.photos/seed/promptlib/900/560",
    highlight: "Most copied prompt this week: 2,847 copies",
  },
];

export function FeatureShowcase() {
  const [active, setActive] = useState(0);
  const { ref, isVisible } = useScrollAnimation();

  useEffect(() => {
    const iv = setInterval(() => {
      if (document.hidden) return;
      setActive((p) => (p + 1) % FEATURES.length);
    }, 4200);
    return () => clearInterval(iv);
  }, []);

  const f = FEATURES[active];

  return (
    <section className="border-y-[1.5px] border-[#0F0F0F] bg-[#FAF6F1] py-20">
      <div
        ref={ref}
        className="container-page"
        style={{ opacity: isVisible ? 1 : 0, transition: "opacity 0.8s ease" }}
      >
        <div className="mb-8 text-center">
          <span
            className="inline-flex items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-gold px-3 py-1 text-[11px] font-extrabold uppercase tracking-wider text-[#0F0F0F]"
            style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
          >
            ✦ How VibeCode Works
          </span>
          <h2 className="mt-4 font-display text-4xl font-extrabold leading-tight md:text-5xl">
            Everything an AI builder needs. <span className="text-coral">In one place.</span>
          </h2>
        </div>

        {/* tabs */}
        <div className="mb-10 flex flex-wrap justify-center gap-2">
          {FEATURES.map((feat, i) => {
            const on = i === active;
            return (
              <button
                key={feat.tab}
                onClick={() => setActive(i)}
                className={`inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] px-4 py-2 text-sm font-bold transition ${
                  on ? "bg-coral text-white" : "bg-card text-[#0F0F0F] hover:bg-background"
                }`}
                style={{ boxShadow: on ? "3px 3px 0 0 #0F0F0F" : "2px 2px 0 0 #0F0F0F" }}
              >
                <span>{feat.icon}</span> {feat.tab}
              </button>
            );
          })}
        </div>

        {/* content */}
        <div className="grid gap-10 md:grid-cols-2 md:items-center">
          <div key={`t-${active}`} style={{ animation: "slideInLeft 0.4s ease" }}>
            <div className="text-4xl">{f.icon}</div>
            <h3 className="mt-3 font-display text-2xl font-extrabold leading-tight text-[#0F0F0F] md:text-3xl">
              {f.heading}
            </h3>
            <p className="mt-3 text-base leading-relaxed text-muted-foreground">{f.description}</p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-md border border-coral/30 bg-coral/10 px-3 py-2 text-[13px] font-bold text-coral">
              ✦ {f.highlight}
            </div>
            <div className="mt-8 h-[3px] overflow-hidden rounded bg-[#E8E0D6]">
              <div
                key={`bar-${active}`}
                className="h-full bg-coral"
                style={{ animation: "progressBar 4.2s linear" }}
              />
            </div>
          </div>

          <div
            key={`i-${active}`}
            className="overflow-hidden rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card"
            style={{ animation: "slideInRight 0.4s ease", boxShadow: "8px 8px 0 0 #0F0F0F" }}
          >
            <img src={f.screenshot} alt={f.tab} className="block h-[340px] w-full object-cover" />
          </div>
        </div>
      </div>
    </section>
  );
}
