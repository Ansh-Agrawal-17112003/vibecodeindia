import { Link } from "@tanstack/react-router";

const INK = "#0F0F0F";
const CORAL = "#E8623A";

export function FinalCTA() {
  return (
    <section className="w-full border-t-[1.5px]" style={{ background: "#F1EEE6", borderColor: INK }}>
      <div className="mx-auto max-w-[900px] px-5 py-16 text-center md:py-24">
        <h2 className="font-display text-[36px] md:text-[64px] font-extrabold leading-[1] tracking-[-0.02em]" style={{ color: INK }}>
          Claim your OG Founding spot.
        </h2>
        <p className="mx-auto mt-4 max-w-[560px] text-[15px] md:text-[17px]" style={{ color: "#4a463d" }}>
          The first 100 members get a lifetime badge, a spot on the public Founders Wall, and 1 year of Pro included. Launch: August 4, 2026.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            to="/early-access"
            className="inline-flex items-center gap-2 rounded-xl border-[1.5px] px-6 py-3.5 text-sm font-extrabold uppercase tracking-wide text-white"
            style={{ background: CORAL, borderColor: INK, boxShadow: `5px 5px 0 0 ${INK}` }}
          >
            Get early access
          </Link>
          <Link
            to="/explore"
            className="inline-flex items-center gap-2 rounded-xl border-[1.5px] bg-white px-6 py-3.5 text-sm font-extrabold uppercase tracking-wide"
            style={{ borderColor: INK, color: INK, boxShadow: `5px 5px 0 0 ${INK}` }}
          >
            Explore builders
          </Link>
        </div>
      </div>
    </section>
  );
}
