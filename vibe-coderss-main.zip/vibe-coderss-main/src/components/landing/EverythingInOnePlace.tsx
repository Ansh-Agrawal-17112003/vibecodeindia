import { Link } from "@tanstack/react-router";
import { Users, Radio, Briefcase, Trophy, ArrowUpRight, Flame, Sparkles, MessageCircle } from "lucide-react";

const INK = "#0F0F0F";

/* ---------- Mini interactive previews (per card) ---------- */

function CommunitiesPreview() {
  const rooms = [
    { n: "#lovable-india", c: 2413, dot: "#E8623A", delta: "+18" },
    { n: "#n8n-builders", c: 1802, dot: "#2a5cd6", delta: "+7" },
    { n: "#cursor-pro", c: 967, dot: "#22C55E", delta: "+12" },
    { n: "#claude-agents", c: 1421, dot: "#F5A623", delta: "+9" },
    { n: "#supabase-in", c: 733, dot: "#8B5CF6", delta: "+4" },
  ];
  const loop = [...rooms, ...rooms];
  return (
    <div className="relative mt-6 h-[108px] overflow-hidden">
      <div className="absolute inset-x-0 top-0 space-y-1.5 eiop-marquee-c">
        {loop.map((r, i) => (
          <div
            key={`${r.n}-${i}`}
            className="flex items-center justify-between rounded-md border-[1.5px] bg-white/85 px-2.5 py-1.5 text-[12px] font-bold"
            style={{ borderColor: INK }}
          >
            <span className="flex items-center gap-2" style={{ color: INK }}>
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-60" style={{ background: r.dot }} />
                <span className="relative inline-flex h-2 w-2 rounded-full" style={{ background: r.dot }} />
              </span>
              {r.n}
            </span>
            <span className="flex items-center gap-1.5">
              <span className="font-mono text-[10px]" style={{ color: "#4a463d" }}>{r.c.toLocaleString()}</span>
              <span className="rounded-sm bg-emerald-500/15 px-1 font-mono text-[9px] font-extrabold text-emerald-700">{r.delta}</span>
            </span>
          </div>
        ))}
      </div>
      <div className="pointer-events-none absolute inset-x-0 top-0 h-4 bg-gradient-to-b from-[#D8F3E8] to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-6 bg-gradient-to-t from-[#D8F3E8] to-transparent" />
    </div>
  );
}

function VibeFeedPreview() {
  const posts = [
    { u: "Arjun", t: "Shipped a Lovable × n8n CRM 🚀", tag: "PROJECT", bg: "#FFE4D6" },
    { u: "Neha", t: "Prompt: 10x faster SEO briefs", tag: "PROMPT", bg: "#E6F0FF" },
    { u: "Vikram", t: "WhatsApp bot in 40 mins", tag: "WORKFLOW", bg: "#E6FFF0" },
    { u: "Meera", t: "Cursor rules for React 19 ✨", tag: "PROMPT", bg: "#F5E6FF" },
    { u: "Kabir", t: "Voice agent in 60 lines", tag: "PROJECT", bg: "#FFE9D6" },
  ];
  // Duplicate for seamless infinite loop
  const loop = [...posts, ...posts];
  return (
    <div className="relative mt-6 h-[132px] overflow-hidden">
      <div className="absolute inset-x-0 top-0 space-y-1.5 eiop-marquee-v group-hover:[animation-play-state:paused]">
        {loop.map((p, i) => (
          <div
            key={`${p.u}-${i}`}
            className="rounded-md border-[1.5px] p-2"
            style={{ borderColor: INK, background: p.bg }}
          >
            <div className="flex items-center gap-1.5">
              <span className="rounded-sm bg-white/70 px-1 text-[9px] font-extrabold" style={{ color: INK }}>{p.tag}</span>
              <span className="text-[11px] font-bold" style={{ color: INK }}>@{p.u.toLowerCase()}</span>
              <span className="ml-auto flex h-1.5 w-1.5 rounded-full eiop-pulse" style={{ background: "#E8623A" }} />
            </div>
            <div className="mt-0.5 text-[12px] font-semibold leading-tight" style={{ color: INK }}>{p.t}</div>
          </div>
        ))}
      </div>
      <div className="pointer-events-none absolute inset-x-0 top-0 h-6 bg-gradient-to-b from-[#FFF3B8] to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-8 bg-gradient-to-t from-[#FFF3B8] to-transparent" />
    </div>
  );
}

function JobsPreview() {
  const jobs = [
    { r: "AI Engineer", co: "Antler", pay: "₹35L", tag: "NEW", tagBg: "#22C55E" },
    { r: "Lovable Dev", co: "Zomato", pay: "₹40L", tag: "HOT", tagBg: "#E8623A" },
    { r: "Prompt Eng.", co: "Meesho", pay: "₹28L", tag: "REMOTE", tagBg: "#2a5cd6" },
  ];
  return (
    <div className="relative mt-6 space-y-1.5 overflow-hidden">
      {/* auto-sweeping highlight */}
      <span
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[38px] rounded-md eiop-sweep"
        style={{ background: "linear-gradient(90deg, transparent, rgba(232,98,58,0.12), transparent)" }}
      />
      {jobs.map((j, i) => (
        <div
          key={j.r}
          className="relative flex items-center justify-between rounded-md border-[1.5px] bg-white px-2.5 py-2 text-[12px] transition-all duration-300 group-hover:-translate-y-0.5"
          style={{ borderColor: INK, transitionDelay: `${i * 60}ms` }}
        >
          <div className="min-w-0">
            <div className="truncate font-extrabold" style={{ color: INK }}>{j.r}</div>
            <div className="text-[10px]" style={{ color: "#4a463d" }}>{j.co} · {j.pay}</div>
          </div>
          <span
            className="shrink-0 rounded-sm px-1.5 py-0.5 text-[9px] font-extrabold text-white eiop-tag-flash"
            style={{ background: j.tagBg, animationDelay: `${i * 900}ms` }}
          >
            {j.tag}
          </span>
        </div>
      ))}
    </div>
  );
}

function LeaderboardPreview() {
  const rows = [
    { r: 1, n: "@arjunbuilds", xp: 4820, bar: 100, color: "#E8623A" },
    { r: 2, n: "@nehaships", xp: 4210, bar: 87, color: "#2a5cd6" },
    { r: 3, n: "@vikramr", xp: 3745, bar: 77, color: "#F5A623" },
  ];
  return (
    <div className="mt-6 space-y-2">
      {rows.map((row, i) => (
        <div key={row.n} className="rounded-md border-[1.5px] bg-white/90 p-2" style={{ borderColor: INK }}>
          <div className="flex items-center justify-between text-[11px]">
            <span className="flex items-center gap-1.5 font-extrabold" style={{ color: INK }}>
              <span className="grid h-4 w-4 place-items-center rounded-full text-[9px] text-white eiop-rank-pop" style={{ background: row.color, animationDelay: `${i * 0.9}s` }}>{row.r}</span>
              {row.n}
            </span>
            <span className="font-mono font-bold" style={{ color: INK }}>{row.xp.toLocaleString()} XP</span>
          </div>
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-black/10">
            <div
              className="h-full rounded-full eiop-bar"
              style={{
                background: row.color,
                animationDelay: `${i * 0.35}s`,
                ["--w" as never]: `${row.bar}%`,
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

const CARDS = [
  {
    to: "/communities" as const,
    icon: Users,
    tag: "Communities",
    title: "Learn from builders shipping now",
    body: "Join sub-communities. Watch lectures. Post what you're building. Get feedback in hours.",
    bg: "#D8F3E8",
    Preview: CommunitiesPreview,
  },
  {
    to: "/vibe" as const,
    icon: Radio,
    tag: "Vibe Feed",
    title: "Live feed of what India ships",
    body: "A single scroll of every project, prompt, and workflow going live across the community.",
    bg: "#FFF3B8",
    Preview: VibeFeedPreview,
  },
  {
    to: "/jobs" as const,
    icon: Briefcase,
    tag: "Jobs",
    title: "AI-first roles, no resume tax",
    body: "Remote, contract, full-time. Every role hires on shipped work, not degrees.",
    bg: "#DDEBFF",
    Preview: JobsPreview,
  },
  {
    to: "/leaderboard" as const,
    icon: Trophy,
    tag: "Leaderboard",
    title: "XP for shipping, not tweeting",
    body: "Weekly ranks by ship-rate, community help, and streaks. Real signal, not vanity.",
    bg: "#F0EAE0",
    Preview: LeaderboardPreview,
  },
];

export function EverythingInOnePlace() {
  return (
    <section className="w-full border-t-[1.5px]" style={{ background: "#F1EEE6", borderColor: INK }}>
      <div className="mx-auto max-w-[1200px] px-5 py-16 md:px-8 md:py-24">
        <h2 className="font-display text-[32px] md:text-[52px] font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ color: INK }}>
          Everything an AI builder ships,
          <br />
          in one place.
        </h2>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {CARDS.map((c) => (
            <Link
              key={c.tag}
              to={c.to}
              className="group relative flex flex-col overflow-hidden rounded-2xl border-[1.5px] p-6 md:p-8 transition-all duration-300 hover:-translate-y-1 hover:shadow-[8px_8px_0_0_#0F0F0F]"
              style={{ background: c.bg, borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
            >
              {/* animated ink sweep on hover */}
              <span
                aria-hidden
                className="pointer-events-none absolute -inset-x-4 -top-1 h-[3px] origin-left scale-x-0 bg-[#0F0F0F] transition-transform duration-500 ease-out group-hover:scale-x-100"
              />

              <div className="flex items-start justify-between">
                <div className="inline-flex items-center gap-2 rounded-full border bg-white px-2.5 py-1 font-mono text-[10px] font-extrabold uppercase tracking-wider transition-transform duration-300 group-hover:scale-105" style={{ borderColor: INK, color: INK }}>
                  <c.icon className="h-3 w-3" /> {c.tag}
                </div>
                <div
                  className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] bg-white transition-all duration-300 group-hover:rotate-45 group-hover:bg-[#0F0F0F] group-hover:text-white"
                  style={{ borderColor: INK, color: INK }}
                >
                  <ArrowUpRight className="h-4 w-4" />
                </div>
              </div>

              <div className="mt-6 font-display text-[22px] md:text-[26px] font-extrabold leading-[1.15] tracking-[-0.01em]" style={{ color: INK }}>
                {c.title}
              </div>
              <p className="mt-2 text-[13.5px] md:text-[14px]" style={{ color: "#3a3a3a" }}>{c.body}</p>

              {/* Interactive preview */}
              <c.Preview />
            </Link>
          ))}
        </div>

        {/* Little legend */}
        <div className="mt-6 flex items-center gap-2 text-[11px] font-mono uppercase tracking-wider" style={{ color: "#4a463d" }}>
          <Sparkles className="h-3 w-3" /> hover any card to preview
          <span className="ml-auto flex items-center gap-3">
            <Flame className="h-3 w-3" />
            <MessageCircle className="h-3 w-3" />
          </span>
        </div>
      </div>
    </section>
  );
}
