const ACTIVITIES = [
  { emoji: "🔥", text: "Aarav from Bangalore just posted a new n8n workflow" },
  { emoji: "💼", text: "Razorpay just posted an AI Engineer role (₹1.2L/month)" },
  { emoji: "👥", text: "Priya just joined the Lovable Builders community" },
  { emoji: "💡", text: "A Claude prompt was copied 847 times in the last hour" },
  { emoji: "🏆", text: "Kabir just reached Vibe Pro level (5,000 XP)" },
  { emoji: "✓", text: "NeuroStack hired an AI developer through VibeCode" },
  { emoji: "🌟", text: "FlowOps project crossed 1,000 views today" },
  { emoji: "🤝", text: "2 builders just matched for a collab project" },
];

export function LiveActivityTicker() {
  const list = [...ACTIVITIES, ...ACTIVITIES];
  return (
    <div className="relative overflow-hidden border-y-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] py-3">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-[#0F0F0F] to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-[#0F0F0F] to-transparent" />
      <div className="flex w-max gap-12 whitespace-nowrap" style={{ animation: "ticker 40s linear infinite" }}>
        {list.map((a, i) => (
          <span key={i} className="inline-flex shrink-0 items-center gap-2 text-[13px] text-[#888]">
            <span
              className="inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-coral"
              style={{ animation: "pulseGlow 2s infinite" }}
            />
            <span className="text-base">{a.emoji}</span>
            <span>{a.text}</span>
          </span>
        ))}
      </div>
    </div>
  );
}
