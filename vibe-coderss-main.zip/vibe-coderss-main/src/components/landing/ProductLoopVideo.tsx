import { useEffect, useState } from "react";
import posterImg from "@/assets/landing-product-loop-poster.jpg";
import slide1 from "@/assets/landing-product-loop-1.jpg";
import slide2 from "@/assets/landing-product-loop-2.jpg";

const C = {
  cream: "#FAF7F1",
  dark: "#0F0F0F",
  muted: "#4a463d",
};

const SLIDES = [
  { src: posterImg, caption: "Your feed, your builders, your inbox." },
  { src: slide1, caption: "A project ships — likes bump in real time." },
  { src: slide2, caption: "Someone follows you while you're offline." },
];

const INTERVAL_MS = 4200;

export function ProductLoopVideo() {
  const [index, setIndex] = useState(0);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(media.matches);
    if (media.matches) return;
    const id = setInterval(() => {
      setIndex((i) => (i + 1) % SLIDES.length);
    }, INTERVAL_MS);
    return () => clearInterval(id);
  }, []);

  return (
    <section
      className="border-t-[1.5px] py-16 md:py-24"
      style={{ borderColor: C.dark, background: C.cream }}
      aria-label="See VibeCode in motion"
    >
      <div className="container-page">
        <div className="mb-10 max-w-3xl">
          <div
            className="mb-4 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.14em]"
            style={{ color: C.dark }}
          >
            ◆ See it in motion
          </div>
          <h2
            className="font-display text-[32px] font-extrabold leading-[1.05] tracking-tight md:text-[52px]"
            style={{ color: C.dark }}
          >
            Your profile, quietly at work.
          </h2>
          <p className="mt-4 text-base md:text-lg" style={{ color: C.muted }}>
            Ship a project, get followed, land a DM — while you're doing something else.
          </p>
        </div>

        <div
          className="relative overflow-hidden rounded-2xl"
          style={{
            border: `1.5px solid ${C.dark}`,
            boxShadow: `4px 4px 0 0 ${C.dark}`,
            aspectRatio: "16 / 10",
            background: C.cream,
          }}
        >
          {SLIDES.map((s, i) => (
            <img
              key={i}
              src={s.src}
              alt={s.caption}
              width={1920}
              height={1200}
              loading={i === 0 ? "eager" : "lazy"}
              className="absolute inset-0 h-full w-full object-cover transition-opacity duration-[900ms] ease-in-out"
              style={{ opacity: reduced ? (i === 0 ? 1 : 0) : i === index ? 1 : 0 }}
            />
          ))}

          {/* caption chip */}
          <div
            className="absolute bottom-4 left-4 hidden rounded-full px-3 py-1.5 text-xs font-semibold md:inline-flex"
            style={{
              background: C.cream,
              color: C.dark,
              border: `1.5px solid ${C.dark}`,
              boxShadow: `2px 2px 0 0 ${C.dark}`,
            }}
          >
            {SLIDES[index].caption}
          </div>

          {/* progress dots */}
          <div className="absolute bottom-4 right-4 flex items-center gap-1.5">
            {SLIDES.map((_, i) => (
              <span
                key={i}
                className="h-2 rounded-full transition-all duration-500"
                style={{
                  width: i === index ? 20 : 8,
                  background: i === index ? C.dark : "rgba(15,15,15,0.28)",
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
