const INK = "#0F0F0F";

const CARDS = [
  {
    bg: "#E8623A",
    tint: "linear-gradient(180deg, rgba(232,98,58,0.85), rgba(150,40,20,0.95))",
    quote: "Landed 3 clients in my first month. My Lovable projects finally have somewhere to live that isn't a random Notion page.",
    name: "Arjun Mehta",
    meta: "Solo SaaS · Bangalore · Lovable, n8n",
    seed: "arjunbuilds",
    stats: [
      { k: "Clients", v: "3" },
      { k: "Projects live", v: "12" },
      { k: "MRR", v: "₹1.4L" },
    ],
    stack: ["arjun", "meera", "kabir", "ira"],
  },
  {
    bg: "#2a5cd6",
    tint: "linear-gradient(180deg, rgba(42,92,214,0.85), rgba(20,40,100,0.95))",
    quote: "Got hired by a YC startup because they saw my workflow on the Vibe Feed. Never sent a resume.",
    name: "Neha Kapoor",
    meta: "AI Engineer · Delhi · Claude, LangChain",
    seed: "nehaships",
    stats: [
      { k: "Offers", v: "4" },
      { k: "DMs / wk", v: "22" },
      { k: "Time to hire", v: "9d" },
    ],
    stack: ["neha", "priya", "isha", "ananya"],
  },
  {
    bg: "#F5A623",
    tint: "linear-gradient(180deg, rgba(245,166,35,0.85), rgba(150,90,10,0.95))",
    quote: "I run a 6-person agency now. Every single hire came from VibeCode DMs. The trust layer just works.",
    name: "Vikram Rao",
    meta: "Founder, Shipfast Labs · Mumbai",
    seed: "vikramr",
    stats: [
      { k: "Team", v: "6" },
      { k: "Retainers", v: "9" },
      { k: "Avg deal", v: "₹80k" },
    ],
    stack: ["vikram", "yash", "harshv", "sidr", "manav"],
  },
];

export function BuildersShipping() {
  return (
    <section className="w-full border-t-[1.5px]" style={{ background: "#F1EEE6", borderColor: INK }}>
      <div className="mx-auto max-w-[1200px] px-5 py-16 md:px-8 md:py-24">
        <h2 className="font-display text-[32px] md:text-[52px] font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ color: INK }}>
          Builders shipping every week.
        </h2>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {CARDS.map((c) => (
            <div
              key={c.name}
              className="group relative flex min-h-[420px] flex-col justify-end overflow-hidden rounded-2xl border-[1.5px] p-6 text-white transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[8px_8px_0_0_#0F0F0F] md:p-7"
              style={{ background: c.tint, backgroundColor: c.bg, borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
            >
              {/* Decorative avatar (top-right) */}
              <img
                src={`https://api.dicebear.com/7.x/notionists/svg?seed=${c.seed}`}
                alt=""
                aria-hidden
                className="absolute -right-6 -top-6 h-32 w-32 rounded-full border-[1.5px] bg-white/95 transition-all duration-500 ease-out group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110"
                style={{ borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
              />

              {/* Quote — fades on hover */}
              <p className="font-display text-[18px] md:text-[20px] font-bold leading-[1.35] transition-all duration-300 group-hover:-translate-y-2 group-hover:opacity-0">
                {c.quote}
              </p>

              {/* Stats grid — reveals on hover */}
              <div className="pointer-events-none absolute inset-x-6 top-[52%] grid translate-y-3 grid-cols-3 gap-2 opacity-0 transition-all duration-400 ease-out group-hover:translate-y-0 group-hover:opacity-100 md:inset-x-7">
                {c.stats.map((s, i) => (
                  <div
                    key={s.k}
                    className="rounded-lg border-[1.5px] border-white/40 bg-white/15 px-2 py-2 text-center backdrop-blur-sm transition-transform"
                    style={{ transitionDelay: `${i * 60}ms` }}
                  >
                    <div className="font-display text-[20px] font-extrabold leading-none">{s.v}</div>
                    <div className="mt-1 text-[10px] font-bold uppercase tracking-wider opacity-80">{s.k}</div>
                  </div>
                ))}
              </div>

              {/* Meta + avatar stack */}
              <div className="relative mt-6">
                <div className="text-[14px] font-extrabold">{c.name}</div>
                <div className="mt-0.5 text-[12px] opacity-80">{c.meta}</div>
                <div className="mt-3 flex items-center gap-3">
                  <div className="flex -space-x-2">
                    {c.stack.map((s) => (
                      <img
                        key={s}
                        src={`https://api.dicebear.com/7.x/notionists/svg?seed=${s}`}
                        alt=""
                        className="h-6 w-6 rounded-full border-[1.5px] bg-white/95"
                        style={{ borderColor: INK }}
                      />
                    ))}
                  </div>
                  <span className="text-[11px] font-bold uppercase tracking-wider opacity-90">
                    +{40 + c.stack.length * 7} peers in city
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
