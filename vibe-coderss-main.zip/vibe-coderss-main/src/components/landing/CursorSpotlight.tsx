import { useEffect } from "react";

/**
 * Mounts once at page root. Finds any element with `data-spotlight` and
 * paints a soft radial gradient overlay that follows the cursor.
 * Purely additive — no restyle of the host element.
 */
export function CursorSpotlight({ color = "rgba(232,98,58,0.18)" }: { color?: string }) {
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.matchMedia?.("(pointer: coarse)").matches) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;

    const hosts = Array.from(document.querySelectorAll<HTMLElement>("[data-spotlight]"));
    const overlays: HTMLDivElement[] = [];

    hosts.forEach((host) => {
      const prevPos = getComputedStyle(host).position;
      if (prevPos === "static") host.style.position = "relative";
      const overlay = document.createElement("div");
      overlay.style.cssText = `position:absolute;inset:0;pointer-events:none;opacity:0;transition:opacity 300ms ease;background:radial-gradient(600px circle at var(--sx,50%) var(--sy,50%), ${color}, transparent 60%);z-index:1;`;
      host.appendChild(overlay);
      overlays.push(overlay);

      const onMove = (e: MouseEvent) => {
        const rect = host.getBoundingClientRect();
        overlay.style.setProperty("--sx", `${e.clientX - rect.left}px`);
        overlay.style.setProperty("--sy", `${e.clientY - rect.top}px`);
        overlay.style.opacity = "1";
      };
      const onLeave = () => {
        overlay.style.opacity = "0";
      };
      host.addEventListener("mousemove", onMove);
      host.addEventListener("mouseleave", onLeave);
      (overlay as unknown as { _cleanup: () => void })._cleanup = () => {
        host.removeEventListener("mousemove", onMove);
        host.removeEventListener("mouseleave", onLeave);
      };
    });

    return () => {
      overlays.forEach((o) => {
        (o as unknown as { _cleanup?: () => void })._cleanup?.();
        o.remove();
      });
    };
  }, [color]);

  return null;
}
