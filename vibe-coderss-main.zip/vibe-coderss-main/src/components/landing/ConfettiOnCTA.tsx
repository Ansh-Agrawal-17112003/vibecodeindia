import { useEffect } from "react";

/**
 * Zero-dep canvas confetti burst. Listens for clicks on any element
 * with [data-confetti]. One-shot per session.
 */
export function ConfettiOnCTA() {
  useEffect(() => {
    let fired = false;
    if (typeof window !== "undefined" && sessionStorage.getItem("vc-confetti") === "1") {
      fired = true;
    }
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) fired = true;

    const burst = (x: number, y: number) => {
      const canvas = document.createElement("canvas");
      canvas.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:9999";
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      document.body.appendChild(canvas);
      const ctx = canvas.getContext("2d")!;
      const colors = ["#E8623A", "#F5A623", "#FFBE7B", "#22C55E", "#3B82F6", "#0F0F0F"];
      const parts = Array.from({ length: 90 }, () => {
        const angle = Math.random() * Math.PI * 2;
        const speed = 6 + Math.random() * 8;
        return {
          x, y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 4,
          size: 4 + Math.random() * 5,
          color: colors[Math.floor(Math.random() * colors.length)],
          rot: Math.random() * Math.PI,
          vr: (Math.random() - 0.5) * 0.3,
          life: 1,
        };
      });
      let raf = 0;
      const tick = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        let alive = 0;
        parts.forEach((p) => {
          if (p.life <= 0) return;
          alive++;
          p.vy += 0.28; // gravity
          p.vx *= 0.99;
          p.x += p.vx;
          p.y += p.vy;
          p.rot += p.vr;
          p.life -= 0.012;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.globalAlpha = Math.max(0, p.life);
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.5);
          ctx.restore();
        });
        if (alive > 0) raf = requestAnimationFrame(tick);
        else canvas.remove();
      };
      raf = requestAnimationFrame(tick);
      setTimeout(() => { cancelAnimationFrame(raf); canvas.remove(); }, 3500);
    };

    const onClick = (e: MouseEvent) => {
      if (fired) return;
      const target = (e.target as HTMLElement)?.closest?.("[data-confetti]");
      if (!target) return;
      fired = true;
      sessionStorage.setItem("vc-confetti", "1");
      const rect = (target as HTMLElement).getBoundingClientRect();
      burst(rect.left + rect.width / 2, rect.top + rect.height / 2);
    };
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  return null;
}
