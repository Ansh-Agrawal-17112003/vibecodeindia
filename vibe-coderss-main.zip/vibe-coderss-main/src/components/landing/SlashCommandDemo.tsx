import { useEffect, useRef, useState } from "react";
import { Rocket, Sparkles, Briefcase, HelpCircle, Hash, MessageSquare, ArrowRight } from "lucide-react";

type SlashCmd = {
  id: string;
  label: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  preview: { emoji: string; title: string; body: string };
};

const SLASH: SlashCmd[] = [
  {
    id: "project",
    label: "Project",
    hint: "Share something you shipped",
    icon: Rocket,
    color: "#E8623A",
    preview: {
      emoji: "🚀",
      title: "FlowOps v2 \u2014 n8n Marketplace",
      body: "Shipped a marketplace for battle-tested n8n workflows. 391 upvotes, 12 paying customers in week 1.",
    },
  },
  {
    id: "prompt",
    label: "Prompt",
    hint: "Drop a prompt that works",
    icon: Sparkles,
    color: "#F5A623",
    preview: {
      emoji: "✨",
      title: "Landing page conversion prompt",
      body: "You are a conversion expert. Analyze this landing page and give me five prioritized changes\u2026",
    },
  },
  {
    id: "job",
    label: "Job",
    hint: "Hire an AI builder",
    icon: Briefcase,
    color: "#3B82F6",
    preview: {
      emoji: "💼",
      title: "Senior Lovable Builder \u2014 Razorpay",
      body: "Remote \u2022 \u20B920\u201335 LPA \u2022 Apply in 10s with your VibeCode profile.",
    },
  },
  {
    id: "question",
    label: "Question",
    hint: "Ask the community",
    icon: HelpCircle,
    color: "#22C55E",
    preview: {
      emoji: "❓",
      title: "How do you handle long-running n8n workflows?",
      body: "Anyone chunking with queues? Best pattern for 40+ min jobs on webhook triggers?",
    },
  },
  {
    id: "milestone",
    label: "Milestone",
    hint: "Celebrate a win",
    icon: Hash,
    color: "#EC4899",
    preview: {
      emoji: "🎉",
      title: "MedScribe crossed \u20B91L MRR",
      body: "6 months from idea to \u20B91L monthly. Thanks to everyone here who reviewed my prompts \ud83d\ude4f",
    },
  },
];

export function SlashCommandDemo() {
  const [text, setText] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [selected, setSelected] = useState<SlashCmd | null>(null);
  const [idx, setIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  // auto-demo on mount so visitors see it in action
  useEffect(() => {
    let cancelled = false;
    const script = async () => {
      await sleep(1200);
      if (cancelled) return;
      const t = "Ship in public /";
      for (let i = 0; i < t.length; i++) {
        if (cancelled) return;
        setText(t.slice(0, i + 1));
        await sleep(60);
      }
      setMenuOpen(true);
      await sleep(1400);
      if (cancelled) return;
      setIdx(0);
      await sleep(700);
      setIdx(1);
      await sleep(700);
      setIdx(0);
      await sleep(500);
      pick(SLASH[0]);
    };
    script();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = (() => {
    const after = text.split("/").pop() ?? "";
    const q = after.toLowerCase();
    if (!q) return SLASH;
    return SLASH.filter((s) => s.label.toLowerCase().includes(q) || s.hint.toLowerCase().includes(q));
  })();

  const onChange = (v: string) => {
    setText(v);
    const hasSlash = v.includes("/");
    setMenuOpen(hasSlash);
    setIdx(0);
    if (!hasSlash) setSelected(null);
  };

  const pick = (cmd: SlashCmd) => {
    setSelected(cmd);
    setMenuOpen(false);
    setText((t) => t.replace(/\/[^/]*$/, "").trimEnd());
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (!menuOpen) return;
    if (e.key === "ArrowDown") { e.preventDefault(); setIdx((i) => Math.min(i + 1, filtered.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setIdx((i) => Math.max(i - 1, 0)); }
    else if (e.key === "Enter") { e.preventDefault(); if (filtered[idx]) pick(filtered[idx]); }
    else if (e.key === "Escape") setMenuOpen(false);
  };

  return (
    <section data-reveal data-label="Slash Menu" className="relative w-full overflow-hidden" style={{ background: "#F5F1E8" }}>
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage: "radial-gradient(rgba(0,0,0,0.05) 1px, transparent 1px)",
          backgroundSize: "22px 22px",
          maskImage: "radial-gradient(ellipse 70% 60% at 50% 40%, #000 40%, transparent 100%)",
        }}
      />

      <div className="relative mx-auto w-full max-w-[1000px] px-5 py-16 md:px-8 md:py-24">
        <div className="text-center">
          <div className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-wider" style={{ background: "#E8623A18", color: "#E8623A" }}>
            <span>/</span> Try it — press slash
          </div>
          <h2 className="mt-5 font-display text-[32px] font-extrabold leading-[1.05] tracking-[-0.02em] md:text-[52px]" style={{ color: "#1c1a16" }}>
            Post anything with <span style={{ color: "#E8623A" }}>one keystroke</span>.
          </h2>
          <p className="mx-auto mt-4 max-w-[560px] text-[15px] leading-[1.7] md:text-[17px]" style={{ color: "#4a463d" }}>
            Every action on VibeCode is a slash command. Project, prompt, job, question — no forms, no friction.
          </p>
        </div>

        <div
          className="relative mx-auto mt-10 max-w-[640px] rounded-2xl bg-white p-4 md:p-6"
          style={{ border: "1px solid #E8E0D6", boxShadow: "0 30px 60px -30px rgba(0,0,0,0.25)" }}
        >
          {/* fake page top bar */}
          <div className="mb-3 flex items-center gap-1.5 font-mono text-[11px]" style={{ color: "#8a8578" }}>
            <span>📄</span>
            <span>vibecode</span>
            <span style={{ color: "#c9c2b4" }}>/</span>
            <span>new-post</span>
          </div>

          {/* input row */}
          <div className="relative">
            <input
              ref={inputRef}
              value={text}
              onChange={(e) => onChange(e.target.value)}
              onKeyDown={onKeyDown}
              onFocus={() => text.includes("/") && setMenuOpen(true)}
              placeholder="Type here, then / to add a project, prompt, or question…"
              className="w-full rounded-lg border bg-transparent px-4 py-3.5 text-[15px] outline-none transition-colors focus:border-[#E8623A]"
              style={{ borderColor: "#EFE9DF", color: "#1c1a16" }}
            />

            {menuOpen && (
              <div
                className="absolute left-0 right-0 top-full z-20 mt-2 overflow-hidden rounded-xl bg-white"
                style={{ border: "1px solid #E8E0D6", boxShadow: "0 20px 50px -20px rgba(0,0,0,0.35)", animation: "slashRise 180ms cubic-bezier(0.22,1,0.36,1)" }}
              >
                <div className="border-b px-3 py-2 font-mono text-[10px] font-bold uppercase tracking-wider" style={{ borderColor: "#EFE9DF", color: "#a39d8f" }}>
                  Basic blocks
                </div>
                <div className="max-h-[280px] overflow-y-auto p-1.5">
                  {filtered.length === 0 && (
                    <div className="px-4 py-6 text-center text-sm" style={{ color: "#8a8578" }}>No commands</div>
                  )}
                  {filtered.map((s, i) => {
                    const isActive = i === idx;
                    return (
                      <button
                        key={s.id}
                        onMouseEnter={() => setIdx(i)}
                        onClick={() => pick(s)}
                        className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-left transition-colors"
                        style={{ background: isActive ? "#FFF1EA" : "transparent" }}
                      >
                        <span
                          className="grid h-9 w-9 place-items-center rounded-md text-white"
                          style={{ background: isActive ? s.color : `${s.color}22`, color: isActive ? "#fff" : s.color }}
                        >
                          <s.icon className="h-4 w-4" />
                        </span>
                        <div className="flex-1">
                          <div className="text-[14px] font-semibold" style={{ color: "#1c1a16" }}>{s.label}</div>
                          <div className="text-[12px]" style={{ color: "#8a8578" }}>{s.hint}</div>
                        </div>
                        {isActive && (
                          <kbd className="rounded-md border px-1.5 py-0.5 font-mono text-[10px]" style={{ borderColor: "#F4C7B4", color: "#E8623A" }}>↵</kbd>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* preview of the selected block */}
          {selected && (
            <div
              key={selected.id}
              className="mt-4 rounded-xl border-l-[3px] p-4"
              style={{
                background: `${selected.color}0C`,
                borderColor: selected.color,
                animation: "slashRise 260ms cubic-bezier(0.22,1,0.36,1)",
              }}
            >
              <div className="flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: selected.color }}>
                <MessageSquare className="h-3 w-3" /> {selected.label} block
              </div>
              <div className="mt-2 flex items-start gap-3">
                <span className="text-2xl">{selected.preview.emoji}</span>
                <div className="min-w-0 flex-1">
                  <div className="font-bold" style={{ color: "#1c1a16" }}>{selected.preview.title}</div>
                  <div className="mt-1 text-[13.5px] leading-[1.6]" style={{ color: "#4a463d" }}>{selected.preview.body}</div>
                </div>
              </div>
              <button
                className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-bold uppercase tracking-wider"
                style={{ color: selected.color }}
              >
                Post to feed <ArrowRight className="h-3 w-3" />
              </button>
            </div>
          )}

          {/* hint row */}
          <div className="mt-4 flex flex-wrap items-center gap-3 text-[11px]" style={{ color: "#8a8578" }}>
            <span className="flex items-center gap-1">
              Type <kbd className="rounded border px-1 font-mono" style={{ borderColor: "#E8E0D6", background: "#FAF7F1" }}>/</kbd> to open
            </span>
            <span className="flex items-center gap-1">
              <kbd className="rounded border px-1 font-mono" style={{ borderColor: "#E8E0D6", background: "#FAF7F1" }}>↑</kbd>
              <kbd className="rounded border px-1 font-mono" style={{ borderColor: "#E8E0D6", background: "#FAF7F1" }}>↓</kbd> navigate
            </span>
            <span className="flex items-center gap-1">
              <kbd className="rounded border px-1 font-mono" style={{ borderColor: "#E8E0D6", background: "#FAF7F1" }}>↵</kbd> select
            </span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slashRise { from { opacity: 0; transform: translateY(-6px) scale(0.98) } to { opacity: 1; transform: translateY(0) scale(1) } }
      `}</style>
    </section>
  );
}

function sleep(ms: number) { return new Promise((r) => setTimeout(r, ms)); }
