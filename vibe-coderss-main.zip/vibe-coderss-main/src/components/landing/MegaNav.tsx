import { Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ChevronDown, Menu, X } from "lucide-react";
import { MEGA_NAV, type MegaSection, type MegaItem } from "./megaNavConfig";

const INK = "#0F0F0F";
const CORAL = "#E8623A";
const IVORY = "#FAF6F1";
const BORDER = "rgba(15,15,15,0.12)";

function useReducedMotion() {
  const [rm, setRm] = useState(false);
  useEffect(() => {
    const m = window.matchMedia("(prefers-reduced-motion: reduce)");
    setRm(m.matches);
    const h = () => setRm(m.matches);
    m.addEventListener("change", h);
    return () => m.removeEventListener("change", h);
  }, []);
  return rm;
}

function MegaItemLink({ item }: { item: MegaItem }) {
  const Icon = item.icon;
  const to = item.hash ? `${item.to}#${item.hash}` : item.to;
  return (
    <Link
      to={to}
      className="group flex items-start gap-3 rounded-lg border border-transparent p-3 transition-all hover:-translate-y-0.5 hover:border-[color:var(--nav-border)] hover:bg-white"
      style={{ ["--nav-border" as string]: BORDER }}
    >
      <span
        className="grid h-9 w-9 shrink-0 place-items-center rounded-md border-[1.5px] transition-colors group-hover:bg-[color:var(--coral)] group-hover:text-white"
        style={{ background: "#FFF", borderColor: INK, color: INK, boxShadow: `2px 2px 0 0 ${INK}`, ["--coral" as string]: CORAL }}
      >
        <Icon className="h-4 w-4" />
      </span>
      <span className="min-w-0">
        <span className="block text-[13.5px] font-bold leading-tight text-[color:var(--ink)] group-hover:text-[color:var(--coral)]" style={{ ["--ink" as string]: INK, ["--coral" as string]: CORAL }}>
          {item.label}
        </span>
        <span className="mt-0.5 block truncate text-[12px] text-[#666]">{item.description}</span>
      </span>
    </Link>
  );
}

function MegaPanel({
  section,
  triggerRect,
  reduced,
  onEnter,
  onLeave,
}: {
  section: MegaSection;
  triggerRect: DOMRect;
  reduced: boolean;
  onEnter: () => void;
  onLeave: () => void;
}) {
  const width = section.columns === 2 ? 680 : 360;
  const cols = section.columns === 2 ? "grid-cols-2" : "grid-cols-1";
  const margin = 12;
  const vw = typeof window !== "undefined" ? window.innerWidth : 1280;
  const desiredLeft = triggerRect.left + triggerRect.width / 2 - width / 2;
  const left = Math.max(margin, Math.min(desiredLeft, vw - width - margin));
  const top = triggerRect.bottom + 8;

  return (
    <div
      className="fixed z-[70]"
      style={{
        left,
        top,
        width,
        animation: reduced ? "none" : "meganav-in 160ms ease-out both",
      }}
      onMouseEnter={onEnter}
      onMouseLeave={onLeave}
    >
      <div
        className="rounded-2xl border-[1.5px] p-3"
        style={{ background: IVORY, borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
      >
        <div className={`grid gap-1.5 ${cols}`}>
          {section.items.map((item) => (
            <MegaItemLink key={item.label} item={item} />
          ))}
        </div>
      </div>
    </div>
  );
}

export function MegaNav() {
  const [active, setActive] = useState<string | null>(null);
  const [triggerRect, setTriggerRect] = useState<DOMRect | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openMobile, setOpenMobile] = useState<string | null>(null);
  const closeTimer = useRef<number | null>(null);
  const triggerRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const reduced = useReducedMotion();

  const openSection = (key: string) => {
    if (closeTimer.current) {
      window.clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
    const el = triggerRefs.current[key];
    if (el) setTriggerRect(el.getBoundingClientRect());
    setActive(key);
  };
  const scheduleClose = () => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current);
    closeTimer.current = window.setTimeout(() => setActive(null), 140);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActive(null);
    };
    const onScrollOrResize = () => setActive(null);
    window.addEventListener("keydown", onKey);
    window.addEventListener("resize", onScrollOrResize);
    window.addEventListener("scroll", onScrollOrResize, true);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", onScrollOrResize);
      window.removeEventListener("scroll", onScrollOrResize, true);
      if (closeTimer.current) window.clearTimeout(closeTimer.current);
    };
  }, []);

  const activeSection = active ? MEGA_NAV.find((s) => s.key === active) : null;

  return (
    <>
      <style>{`
        @keyframes meganav-in {
          from { opacity: 0; transform: translateY(-4px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <div
        className="sticky top-0 z-40 w-full backdrop-blur"
        style={{ background: "rgba(250,246,241,0.85)", borderBottom: `1px solid ${BORDER}` }}
      >
        <div className="mx-auto flex h-14 w-full max-w-[1240px] items-center justify-between px-4 md:px-8">
          {/* Brand */}
          <Link to="/landing" className="flex items-center gap-2">
            <span
              className="grid h-8 w-8 place-items-center rounded-[8px] border-[1.5px]"
              style={{ background: CORAL, borderColor: INK, color: "#fff", boxShadow: `2px 2px 0 0 ${INK}` }}
            >
              <svg viewBox="0 0 24 24" width={14} height={14} fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
                <path d="M8 8 L3 12 L8 16" /><path d="M16 8 L21 12 L16 16" /><path d="M14 5 L10 19" />
              </svg>
            </span>
            <span className="font-display text-[15px] font-extrabold tracking-tight" style={{ color: INK }}>VibeCode</span>
          </Link>

          {/* Desktop triggers */}
          <nav
            className="hidden items-center gap-0.5 lg:flex"
            onMouseLeave={scheduleClose}
          >
            {MEGA_NAV.map((section) => {
              const isOpen = active === section.key;
              return (
                <div
                  key={section.key}
                  onMouseEnter={() => openSection(section.key)}
                >
                  <button
                    ref={(el) => { triggerRefs.current[section.key] = el; }}
                    type="button"
                    aria-expanded={isOpen}
                    aria-haspopup="true"
                    onFocus={() => openSection(section.key)}
                    onClick={() => (isOpen ? setActive(null) : openSection(section.key))}
                    className="flex items-center gap-1 rounded-md px-3 py-2 text-[13.5px] font-semibold transition-colors"
                    style={{ color: isOpen ? CORAL : INK }}
                  >
                    {section.label}
                    <ChevronDown className={`h-3.5 w-3.5 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                  </button>
                </div>
              );
            })}
          </nav>


          {/* CTA + mobile toggle */}
          <div className="flex items-center gap-2">
            <Link
              to="/auth"
              className="hidden rounded-md px-3 py-2 text-[13px] font-semibold md:inline-flex"
              style={{ color: INK }}
            >
              Sign in
            </Link>
            <Link
              to="/auth"
              className="hidden rounded-md border-[1.5px] px-3.5 py-2 text-[13px] font-bold md:inline-flex"
              style={{ background: CORAL, borderColor: INK, color: "#fff", boxShadow: `2px 2px 0 0 ${INK}` }}
            >
              Join VibeCode
            </Link>
            <button
              type="button"
              aria-label="Open menu"
              onClick={() => setMobileOpen(true)}
              className="grid h-9 w-9 place-items-center rounded-md border-[1.5px] lg:hidden"
              style={{ background: "#FFF", borderColor: INK, color: INK, boxShadow: `2px 2px 0 0 ${INK}` }}
            >
              <Menu className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Active panel (fixed, clamped to viewport) */}
      {activeSection && triggerRect && (
        <MegaPanel
          section={activeSection}
          triggerRect={triggerRect}
          reduced={reduced}
          onEnter={() => openSection(activeSection.key)}
          onLeave={scheduleClose}
        />
      )}

      {/* Mobile sheet */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <button
            type="button"
            aria-label="Close menu"
            onClick={() => setMobileOpen(false)}
            className="absolute inset-0"
            style={{ background: "rgba(15,15,15,0.5)" }}
          />
          <div
            className="absolute right-0 top-0 h-full w-[86%] max-w-[380px] overflow-y-auto border-l-[1.5px] p-4"
            style={{ background: IVORY, borderColor: INK }}
          >
            <div className="mb-4 flex items-center justify-between">
              <span className="font-display text-base font-extrabold" style={{ color: INK }}>Menu</span>
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                aria-label="Close"
                className="grid h-9 w-9 place-items-center rounded-md border-[1.5px]"
                style={{ background: "#FFF", borderColor: INK, color: INK }}
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-2">
              {MEGA_NAV.map((section) => {
                const isOpen = openMobile === section.key;
                return (
                  <div key={section.key} className="rounded-lg border-[1.5px]" style={{ borderColor: INK, background: "#FFF" }}>
                    <button
                      type="button"
                      onClick={() => setOpenMobile(isOpen ? null : section.key)}
                      className="flex w-full items-center justify-between px-3 py-2.5 text-[14px] font-bold"
                      style={{ color: INK }}
                    >
                      {section.label}
                      <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                    </button>
                    {isOpen && (
                      <div className="grid gap-1 border-t p-2" style={{ borderColor: BORDER }}>
                        {section.items.map((item) => (
                          <MegaItemLink key={item.label} item={item} />
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}

              <Link
                to="/auth"
                onClick={() => setMobileOpen(false)}
                className="mt-4 flex items-center justify-center rounded-md border-[1.5px] px-4 py-3 text-[14px] font-extrabold"
                style={{ background: CORAL, borderColor: INK, color: "#fff", boxShadow: `3px 3px 0 0 ${INK}` }}
              >
                Join VibeCode
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
