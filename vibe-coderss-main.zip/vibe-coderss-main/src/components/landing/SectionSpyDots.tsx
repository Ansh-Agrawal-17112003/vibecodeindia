import { useEffect, useState } from "react";

type SectionMeta = { id: string; label: string };

export function SectionSpyDots() {
  const [sections, setSections] = useState<SectionMeta[]>([]);
  const [active, setActive] = useState<string | null>(null);

  useEffect(() => {
    const nodes = Array.from(
      document.querySelectorAll<HTMLElement>("section[data-reveal]"),
    );
    const metas: SectionMeta[] = nodes.map((el, i) => {
      if (!el.id) el.id = `sec-${i}`;
      const label =
        el.dataset.label ||
        el.querySelector("h2, h1")?.textContent?.trim().slice(0, 40) ||
        `Section ${i + 1}`;
      return { id: el.id, label };
    });
    setSections(metas);

    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive((visible.target as HTMLElement).id);
      },
      { threshold: [0.25, 0.5, 0.75], rootMargin: "-30% 0px -30% 0px" },
    );
    nodes.forEach((n) => obs.observe(n));
    return () => obs.disconnect();
  }, []);

  if (sections.length === 0) return null;

  return (
    <nav
      aria-label="Section navigation"
      className="fixed right-4 top-1/2 z-40 hidden -translate-y-1/2 flex-col gap-2.5 lg:flex"
    >
      {sections.map((s) => {
        const isActive = active === s.id;
        return (
          <a
            key={s.id}
            href={`#${s.id}`}
            aria-label={`Jump to ${s.label}`}
            className="group relative flex h-3 w-3 items-center justify-end"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById(s.id)?.scrollIntoView({ behavior: "smooth", block: "start" });
            }}
          >
            <span
              className="block rounded-full transition-all duration-300"
              style={{
                width: isActive ? 10 : 6,
                height: isActive ? 10 : 6,
                background: isActive ? "#E8623A" : "rgba(140,140,140,0.55)",
                boxShadow: isActive ? "0 0 12px rgba(232,98,58,0.55)" : "none",
              }}
            />
            <span
              className="pointer-events-none absolute right-6 whitespace-nowrap rounded-md border px-2 py-1 text-[11px] font-semibold opacity-0 shadow-sm transition-opacity duration-200 group-hover:opacity-100"
              style={{ background: "#0F0F0F", color: "#fff", borderColor: "#2a2a2a" }}
            >
              {s.label}
            </span>
          </a>
        );
      })}
    </nav>
  );
}
