import { Link } from "@tanstack/react-router";
import { Rocket, MessageSquare, Sparkles, Briefcase, Wrench, Zap, ArrowRight } from "lucide-react";

const INK = "#0F0F0F";
const CREAM = "#FAF7F1";
const CORAL = "#E8623A";

function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div
      className="rounded-2xl border-[1.5px] bg-white p-6 md:p-8"
      style={{ borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}`, ...style }}
    >
      {children}
    </div>
  );
}

export function ProfileWorks247() {
  return (
    <section className="w-full border-t-[1.5px]" style={{ background: "#F1EEE6", borderColor: INK }}>
      <div className="mx-auto max-w-[1200px] px-5 py-16 md:px-8 md:py-24">
        <h2 className="font-display text-[32px] md:text-[52px] font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ color: INK }}>
          Your builder profile works 24/7.
        </h2>
        <p className="mt-3 max-w-[640px] text-[15px] md:text-[17px]" style={{ color: "#4a463d" }}>
          Ship once — your profile auto-updates with every project, prompt, and workflow. Recruiters, founders, and clients discover you in their sleep.
        </p>

        {/* two panels */}
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {/* Left: live profile mock — auto-scrolling ticker */}
          <Card>
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2 font-mono text-[11px] font-bold uppercase tracking-wider" style={{ color: CORAL }}>
                <span className="pw-live-dot h-1.5 w-1.5 rounded-full" style={{ background: CORAL }} /> live profile
              </div>
              <span className="font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: "#8a8578" }}>auto-syncing</span>
            </div>
            <div className="text-lg font-extrabold" style={{ color: INK }}>Your projects, always in sync</div>
            <div className="relative mt-5 h-[196px] overflow-hidden">
              <div className="absolute inset-x-0 top-0 space-y-2.5 pw-marquee">
                {[
                  { t: "Shipped Bolt-Notion sync", w: "Lovable · 2h ago", pill: "New" },
                  { t: "Prompt: SEO title generator", w: "Claude · yesterday", pill: "+142" },
                  { t: "n8n workflow: WhatsApp CRM", w: "n8n · 3d", pill: "Trending" },
                  { t: "Case study: solo SaaS at ₹8L MRR", w: "Blog · 1w", pill: "" },
                  { t: "Shipped Bolt-Notion sync", w: "Lovable · 2h ago", pill: "New" },
                  { t: "Prompt: SEO title generator", w: "Claude · yesterday", pill: "+142" },
                  { t: "n8n workflow: WhatsApp CRM", w: "n8n · 3d", pill: "Trending" },
                  { t: "Case study: solo SaaS at ₹8L MRR", w: "Blog · 1w", pill: "" },
                ].map((r, i) => (
                  <div key={i} className="flex items-center justify-between rounded-lg border px-3 py-2.5" style={{ borderColor: "#E8E0D6", background: CREAM }}>
                    <div className="min-w-0">
                      <div className="truncate text-[13.5px] font-bold" style={{ color: INK }}>{r.t}</div>
                      <div className="truncate text-[11.5px]" style={{ color: "#8a8578" }}>{r.w}</div>
                    </div>
                    {r.pill && (
                      <span className="shrink-0 rounded-md border px-2 py-0.5 text-[10px] font-extrabold uppercase" style={{ borderColor: INK, background: "#fff", color: INK }}>
                        {r.pill}
                      </span>
                    )}
                  </div>
                ))}
              </div>
              <div className="pointer-events-none absolute inset-x-0 top-0 h-6 bg-gradient-to-b from-white to-transparent" />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-8 bg-gradient-to-t from-white to-transparent" />
            </div>
          </Card>

          {/* Right: inbound DM inbox — auto-cycling messages */}
          <Card style={{ background: "#FFF7E6" }}>
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2 font-mono text-[11px] font-bold uppercase tracking-wider" style={{ color: "#8a6a10" }}>
                <MessageSquare className="h-3 w-3" /> inbound inbox
              </div>
              <span className="font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: "#8a8578" }}>3 new</span>
            </div>
            <div className="text-lg font-extrabold" style={{ color: INK }}>Recruiters &amp; founders slide in</div>
            <div className="mt-5 space-y-3 min-h-[196px]">
              {[
                { n: "Priya · Antler India", m: "Loved your n8n CRM. Ping for portfolio company role?", d: 0 },
                { n: "Rohan · Zomato", m: "Full-time Lovable engineer — 40L base. Interested?", d: 1.6 },
                { n: "Aisha · YC founder", m: "Need help shipping our MVP by Friday. Budget ₹1.5L.", d: 3.2 },
              ].map((d) => (
                <div
                  key={d.n}
                  className="pw-dm rounded-lg border bg-white p-3"
                  style={{ borderColor: "#F0D68A", animationDelay: `${d.d}s` }}
                >
                  <div className="flex items-center justify-between">
                    <div className="text-[12px] font-extrabold" style={{ color: INK }}>{d.n}</div>
                    <span className="pw-badge rounded-full px-1.5 py-0.5 text-[9px] font-extrabold text-white" style={{ background: CORAL }}>NEW</span>
                  </div>
                  <div className="mt-0.5 text-[13px] leading-snug" style={{ color: "#3a3a3a" }}>{d.m}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Tile row */}
        <div className="mt-8 -mx-5 overflow-x-auto px-5 md:mx-0 md:overflow-visible md:px-0">
          <div className="flex gap-4 md:grid md:grid-cols-5">
            {[
              { i: Rocket, l: "Projects", to: "/projects", c: "#FFE4D6", n: "3.2k" },
              { i: Sparkles, l: "Prompts", to: "/prompts", c: "#E6F0FF", n: "8.4k" },
              { i: Zap, l: "Workflows", to: "/workflows", c: "#E6FFF0", n: "1.9k" },
              { i: Wrench, l: "Services", to: "/services", c: "#FFF3B8", n: "620" },
            ].map((t) => (
              <Link
                key={t.l}
                to={t.to}
                className="group relative flex min-w-[180px] flex-col justify-between overflow-hidden rounded-xl border-[1.5px] p-4 transition-all duration-300 hover:-translate-y-1 hover:shadow-[6px_6px_0_0_#0F0F0F] md:min-w-0"
                style={{ borderColor: INK, background: t.c, boxShadow: `3px 3px 0 0 ${INK}` }}
              >
                <span aria-hidden className="pointer-events-none absolute -right-8 -top-8 h-20 w-20 rounded-full bg-white/40 opacity-0 transition-all duration-500 group-hover:opacity-100 group-hover:scale-125" />
                <div className="relative flex items-center justify-between">
                  <t.i className="h-5 w-5 transition-transform duration-300 group-hover:-rotate-12 group-hover:scale-110" style={{ color: INK }} />
                  <span className="rounded-full border-[1.5px] bg-white px-1.5 py-0.5 font-mono text-[10px] font-extrabold transition-transform duration-300 group-hover:scale-110" style={{ borderColor: INK, color: INK }}>{t.n}</span>
                </div>
                <div className="relative mt-8 flex items-center justify-between text-[15px] font-extrabold" style={{ color: INK }}>
                  {t.l}
                  <ArrowRight className="h-4 w-4 -translate-x-1 opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100" />
                </div>
              </Link>
            ))}
            <Link
              to="/signup"
              className="group relative flex min-w-[180px] flex-col justify-between overflow-hidden rounded-xl border-[1.5px] p-4 text-white transition-all duration-300 hover:-translate-y-1 hover:shadow-[6px_6px_0_0_#E8623A] md:min-w-0"
              style={{ borderColor: INK, background: INK, boxShadow: `3px 3px 0 0 ${CORAL}` }}
            >
              <span aria-hidden className="pointer-events-none absolute -right-10 -top-10 h-24 w-24 rounded-full opacity-0 transition-all duration-500 group-hover:opacity-100 group-hover:scale-125" style={{ background: `${CORAL}44` }} />
              <Briefcase className="relative h-5 w-5 transition-transform duration-300 group-hover:-rotate-12" />
              <div className="relative mt-8 flex items-center gap-1.5 text-[15px] font-extrabold">
                Start your profile <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
