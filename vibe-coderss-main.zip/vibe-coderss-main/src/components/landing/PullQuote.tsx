const INK = "#0F0F0F";

export function PullQuote() {
  return (
    <section className="w-full border-t-[1.5px]" style={{ background: "#FAF7F1", borderColor: INK }}>
      <div className="mx-auto max-w-[900px] px-5 py-16 text-center md:py-24">
        {/* TODO: replace with real press quote */}
        <p className="font-display text-[26px] md:text-[40px] font-extrabold leading-[1.15] tracking-[-0.01em]" style={{ color: INK }}>
          "The GitHub for India's AI builders."
        </p>
        <div className="mt-4 font-mono text-[11px] font-extrabold uppercase tracking-[0.2em]" style={{ color: "#8a8578" }}>
          — YourStory
        </div>
      </div>
    </section>
  );
}
