import { useEffect, useState } from "react";
import { Rocket, Briefcase, TrendingUp, ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";

const ROLES = [
  {
    id: "builder",
    label: "I'm a Builder",
    icon: Rocket,
    headline: "Ship in public. Get discovered.",
    sub: "Your projects, prompts, and workflows become your portfolio. Companies find you. Clients DM you.",
    cta: "Create your builder profile",
    to: "/signup" as const,
    accent: "#E8623A",
  },
  {
    id: "recruiter",
    label: "I'm a Recruiter",
    icon: Briefcase,
    headline: "Hire builders who actually ship.",
    sub: "Skip resumes. Search 120K+ Indian AI builders by tool, ship-rate, and availability. First hire in a week.",
    cta: "Post your first role free",
    to: "/jobs" as const,
    accent: "#0F0F0F",
  },
  {
    id: "investor",
    label: "I'm an Investor",
    icon: TrendingUp,
    headline: "See what India ships this week.",
    sub: "The earliest signal in Indian AI \u2014 who's building what, growing how fast, and open to talking.",
    cta: "Browse breakout projects",
    to: "/projects" as const,
    accent: "#B8461F",
  },
];

export function RoleSwitcher() {
  const [active, setActive] = useState(0);

  // gentle auto-advance until user interacts
  const [touched, setTouched] = useState(false);
  useEffect(() => {
    if (touched) return;
    const iv = setInterval(() => {
      if (document.hidden) return;
      setActive((i) => (i + 1) % ROLES.length);
    }, 4500);
    return () => clearInterval(iv);
  }, [touched]);

  const role = ROLES[active];

  return (
    <section data-reveal data-label="Personalize" className="relative w-full overflow-hidden" style={{ background: "#FAF7F1" }}>
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{ background: `radial-gradient(500px circle at 20% 50%, ${role.accent}18, transparent 60%)`, transition: "background 600ms ease" }}
      />
      <div className="relative mx-auto grid w-full max-w-[1200px] gap-8 px-5 py-14 md:grid-cols-[280px_1fr] md:items-center md:px-8 md:py-20">
        {/* Left: role chips */}
        <div className="flex flex-col gap-2">
          <div className="mb-1 font-mono text-[11px] font-bold uppercase tracking-wider" style={{ color: "#8a8578" }}>
            Personalize
          </div>
          {ROLES.map((r, i) => {
            const isActive = i === active;
            return (
              <button
                key={r.id}
                onClick={() => { setActive(i); setTouched(true); }}
                className="group flex items-center gap-3 rounded-xl border px-4 py-3 text-left transition-all"
                style={{
                  background: isActive ? "#fff" : "transparent",
                  borderColor: isActive ? r.accent : "#E8E0D6",
                  boxShadow: isActive ? `0 8px 22px -12px ${r.accent}` : "none",
                  transform: isActive ? "translateX(4px)" : "none",
                }}
              >
                <span
                  className="grid h-9 w-9 place-items-center rounded-lg transition-colors"
                  style={{
                    background: isActive ? r.accent : "#F5F1E8",
                    color: isActive ? "#fff" : "#8a8578",
                  }}
                >
                  <r.icon className="h-4 w-4" />
                </span>
                <span className="flex-1 text-[14.5px] font-bold" style={{ color: "#1c1a16" }}>{r.label}</span>
                {isActive && <span className="text-lg" style={{ color: r.accent }}>›</span>}
              </button>
            );
          })}
        </div>

        {/* Right: swapping content */}
        <div key={role.id} style={{ animation: "roleSwap 380ms cubic-bezier(0.22,1,0.36,1)" }}>
          <div
            className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-wider"
            style={{ background: `${role.accent}18`, color: role.accent }}
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: role.accent }} />
            For {role.label.replace("I'm ", "").replace("a ", "").replace("an ", "")}s
          </div>
          <h2 className="mt-4 font-display text-[32px] font-extrabold leading-[1.05] tracking-[-0.02em] md:text-[52px]" style={{ color: "#1c1a16" }}>
            {role.headline}
          </h2>
          <p className="mt-4 max-w-[560px] text-[16px] leading-[1.7] md:text-[17px]" style={{ color: "#4a463d" }}>
            {role.sub}
          </p>
          <Link
            to={role.to}
            className="mt-6 inline-flex items-center gap-2 rounded-xl border-[1.5px] px-5 py-3 text-sm font-extrabold uppercase tracking-wide text-white transition-all hover:-translate-y-0.5"
            style={{ background: role.accent, borderColor: "#0F0F0F", boxShadow: "4px 4px 0 0 #0F0F0F" }}
          >
            {role.cta} <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>

      <style>{`
        @keyframes roleSwap { from { opacity: 0; transform: translateY(8px) } to { opacity: 1; transform: translateY(0) } }
      `}</style>
    </section>
  );
}
