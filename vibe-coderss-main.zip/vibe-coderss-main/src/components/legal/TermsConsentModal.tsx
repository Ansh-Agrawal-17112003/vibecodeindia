import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { AlertTriangle, ShieldCheck, ExternalLink, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

const STORAGE_PREFIX = "vc.terms.accepted.v1.";

/**
 * Terms & Conditions consent modal.
 * Appears the first time an authenticated user lands on the app after signup/login.
 * Blocks the UI until the user either accepts (persisted per-user in localStorage)
 * or declines (signs them out).
 */
export function TermsConsentModal() {
  const { session, loading, signOut } = useAuth();
  const [checked, setChecked] = useState(false);
  const [needsConsent, setNeedsConsent] = useState(false);
  const [busy, setBusy] = useState(false);

  const userId = session?.user?.id ?? null;

  useEffect(() => {
    if (loading) return;
    if (!userId) {
      setNeedsConsent(false);
      return;
    }
    try {
      const accepted = localStorage.getItem(STORAGE_PREFIX + userId);
      setNeedsConsent(accepted !== "1");
    } catch {
      setNeedsConsent(true);
    }
    setChecked(false);
  }, [userId, loading]);

  if (!needsConsent || !userId) return null;

  const accept = () => {
    if (!checked) return;
    setBusy(true);
    try {
      localStorage.setItem(STORAGE_PREFIX + userId, "1");
    } catch {
      /* ignore quota errors — still allow entry for this session */
    }
    setNeedsConsent(false);
    setBusy(false);
  };

  const decline = async () => {
    setBusy(true);
    try {
      await supabase.auth.signOut();
    } finally {
      try {
        await signOut?.();
      } catch {
        /* noop */
      }
      setBusy(false);
      setNeedsConsent(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="vc-terms-title"
      className="fixed inset-0 z-[9998] flex items-end justify-center bg-black/60 p-3 backdrop-blur-sm sm:items-center sm:p-6"
      style={{ animation: "vc-terms-fade 220ms ease-out" }}
    >
      <style>{`
        @keyframes vc-terms-fade { from { opacity: 0 } to { opacity: 1 } }
        @keyframes vc-terms-pop { from { transform: translateY(24px); opacity: 0 } to { transform: translateY(0); opacity: 1 } }
      `}</style>
      <div
        className="relative w-full max-w-[560px] overflow-hidden rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white shadow-[6px_6px_0_0_#0F0F0F]"
        style={{ animation: "vc-terms-pop 260ms cubic-bezier(.22,1,.36,1)" }}
      >
        {/* Header */}
        <div className="relative border-b border-[#0F0F0F]/10 bg-[#FAF7F0] px-5 py-4 sm:px-6 sm:py-5">
          <div className="flex items-center gap-3">
            <span
              className="grid h-9 w-9 place-items-center rounded-xl border-[1.5px] border-[#0F0F0F] bg-[#E8623A] text-white"
              style={{ boxShadow: "1.5px 1.5px 0 0 #0F0F0F" }}
            >
              <ShieldCheck className="h-4 w-4" />
            </span>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#E8623A]">One quick thing</div>
              <h2 id="vc-terms-title" className="font-display text-[19px] font-extrabold leading-tight sm:text-[22px]">
                Accept our Terms & Cookie Policy
              </h2>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="max-h-[55vh] overflow-y-auto px-5 py-4 sm:px-6 sm:py-5">
          <p className="text-[14.5px] leading-[1.65] text-[#0F0F0F]/80">
            Welcome to <b>VibeCode</b>. Before you start hiring, listing, or shipping — we need you to read and agree
            to how the platform works.
          </p>

          <div className="mt-4 flex items-start gap-3 rounded-xl border-[1.5px] border-[#E8623A] bg-[#FFF3EE] p-3.5 text-[13.5px] leading-[1.6] text-[#0F0F0F]">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[#E8623A]" />
            <div>
              <b>VibeCode is a marketplace.</b> We connect hirers with builders, freelancers, and communities — but{" "}
              <b>we are not a party</b> to your deals and <b>cannot guarantee</b> that every user is genuine or
              scam-free. <b>Always test the builder</b>, start with a small paid milestone, verify deliverables, and
              never transfer large sums or share credentials before you have confirmed the counterparty is real.
            </div>
          </div>

          <ul className="mt-4 space-y-2 text-[13.5px] leading-[1.6] text-[#0F0F0F]/80">
            <li className="flex gap-2"><span className="text-[#E8623A]">•</span> You are responsible for your own vetting, payments, and communications.</li>
            <li className="flex gap-2"><span className="text-[#E8623A]">•</span> You own the content you upload; you must have the rights to it (no plagiarism, no copyright infringement).</li>
            <li className="flex gap-2"><span className="text-[#E8623A]">•</span> We use essential cookies to keep you signed in, and analytics cookies to improve the product.</li>
            <li className="flex gap-2"><span className="text-[#E8623A]">•</span> Fraud, scams, or abuse can be reported at <a href="mailto:trust@joinvibecode.xyz" className="text-[#E8623A] underline">trust@joinvibecode.xyz</a>.</li>
          </ul>

          <div className="mt-4 rounded-xl border border-[#0F0F0F]/10 bg-[#FAF7F0] p-3.5">
            <label className="flex cursor-pointer items-start gap-3">
              <input
                type="checkbox"
                className="mt-1 h-4 w-4 shrink-0 accent-[#E8623A]"
                checked={checked}
                onChange={(e) => setChecked(e.target.checked)}
              />
              <span className="text-[13.5px] leading-[1.55] text-[#0F0F0F]">
                I have read and agree to VibeCode's{" "}
                <Link
                  to="/terms"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 font-semibold text-[#E8623A] underline"
                >
                  Terms & Conditions <ExternalLink className="h-3 w-3" />
                </Link>{" "}
                ,{" "}
                <Link
                  to="/privacy-policy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 font-semibold text-[#E8623A] underline"
                >
                  Privacy Policy <ExternalLink className="h-3 w-3" />
                </Link>{" "}
                and{" "}
                <Link
                  to="/p/$slug"
                  params={{ slug: "cookies" }}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 font-semibold text-[#E8623A] underline"
                >
                  Cookie Policy <ExternalLink className="h-3 w-3" />
                </Link>
                . I understand VibeCode does not guarantee outcomes and I will vet the users I transact with.
              </span>
            </label>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col-reverse gap-2 border-t border-[#0F0F0F]/10 bg-white px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6 sm:py-4">
          <button
            type="button"
            onClick={decline}
            disabled={busy}
            className="inline-flex items-center justify-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-4 py-2 text-[13px] font-extrabold uppercase tracking-[0.1em] text-[#0F0F0F] transition-transform active:scale-95 disabled:opacity-60"
          >
            <X className="h-3.5 w-3.5" />
            Decline & sign out
          </button>
          <button
            type="button"
            onClick={accept}
            disabled={!checked || busy}
            className="inline-flex items-center justify-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] px-5 py-2.5 text-[13px] font-extrabold uppercase tracking-[0.1em] text-white transition-transform active:scale-95 disabled:cursor-not-allowed disabled:opacity-50"
            style={{
              background: checked ? "#E8623A" : "#c9c0af",
              boxShadow: checked ? "2px 2px 0 0 #0F0F0F" : "none",
            }}
          >
            <ShieldCheck className="h-3.5 w-3.5" />
            Accept & continue
          </button>
        </div>
      </div>
    </div>
  );
}

export default TermsConsentModal;
