import { useEffect, useRef, useState } from "react";

interface ScrollHighlightTextProps {
  text: string;
  className?: string;
  style?: React.CSSProperties;
  baseColor?: string;
  highlightColor?: string;
}

/**
 * Highlights text word-by-word as the user scrolls the element through the viewport.
 * Dim words become bright as they cross the reading line.
 */
export function ScrollHighlightText({
  text,
  className,
  style,
  baseColor = "#3a3a3a",
  highlightColor = "#ffffff",
}: ScrollHighlightTextProps) {
  const ref = useRef<HTMLParagraphElement>(null);
  const [progress, setProgress] = useState(0);
  const words = text.split(" ");

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const update = () => {
      const rect = el.getBoundingClientRect();
      const vh = window.innerHeight || document.documentElement.clientHeight;
      // Narrow reading zone near viewport center so stacked paragraphs
      // animate sequentially (one finishes before the next begins).
      const start = vh * 0.7;
      const end = vh * 0.4;
      const total = rect.height + (start - end);
      const traveled = start - rect.top;
      const p = Math.max(0, Math.min(1, traveled / total));
      setProgress(p);
    };

    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);

  const activeIndex = progress * words.length;

  return (
    <p ref={ref} className={className} style={style}>
      {words.map((word, i) => {
        // Smooth fade per word over ~1 word window
        const wordProgress = Math.max(0, Math.min(1, activeIndex - i));
        return (
          <span
            key={i}
            style={{
              color: wordProgress > 0.5 ? highlightColor : baseColor,
              transition: "color 300ms ease-out",
            }}
          >
            {word}
            {i < words.length - 1 ? " " : ""}
          </span>
        );
      })}
    </p>
  );
}
