import { useState } from "react";
import { toast } from "sonner";
import { Bug, X, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export function ReportBugModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  if (!open) return null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim().length < 3) return toast.error("Give it a short title");
    if (description.trim().length < 10) return toast.error("Add a little more detail (10+ chars)");
    setBusy(true);
    const { error } = await supabase.from("bug_reports").insert({
      reporter_id: user?.id ?? null,
      title: title.trim().slice(0, 200),
      description: description.trim().slice(0, 4000),
      page_url: typeof window !== "undefined" ? window.location.href : null,
      user_agent: typeof navigator !== "undefined" ? navigator.userAgent : null,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    setSent(true);
    toast.success("Thanks! Bug reported.");
    setTimeout(() => {
      setSent(false);
      setTitle("");
      setDescription("");
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[120] grid place-items-center overflow-y-auto bg-black/60 p-4 backdrop-blur-sm" role="dialog" aria-modal="true">
      <div
        className="relative w-full max-w-md rounded-[16px] border-[1.5px] border-[#0F0F0F] bg-card p-6"
        style={{ boxShadow: "8px 8px 0 0 #0F0F0F" }}
      >
        <button onClick={onClose} aria-label="Close" className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] hover:bg-surface">
          <X className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-2">
          <span className="grid h-10 w-10 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-coral text-white shadow-[2px_2px_0_0_#0F0F0F]">
            <Bug className="h-5 w-5" />
          </span>
          <div>
            <h2 className="font-display text-xl font-extrabold">Report a bug</h2>
            <p className="text-xs text-muted-foreground">We fix reported bugs faster than tweets. Promise.</p>
          </div>
        </div>

        {sent ? (
          <div className="mt-6 rounded-md border-[1.5px] border-[#0F0F0F] bg-cream p-6 text-center">
            <div className="text-3xl">✅</div>
            <p className="mt-2 font-bold">Bug filed. Thanks!</p>
          </div>
        ) : (
          <form onSubmit={submit} className="mt-5 space-y-3">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Short title (e.g. Upload button 404s)"
              className="h-11 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-surface px-3 text-sm outline-none focus:border-coral"
              maxLength={200}
            />
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What happened? What did you expect?"
              rows={5}
              className="w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-surface p-3 text-sm outline-none focus:border-coral"
              maxLength={4000}
            />
            <div className="text-[11px] text-muted-foreground">
              Page: <code className="rounded bg-surface px-1">{typeof window !== "undefined" ? window.location.pathname : ""}</code>
            </div>
            <button type="submit" disabled={busy} className="btn-coral h-11 w-full disabled:opacity-60">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send bug report →"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
