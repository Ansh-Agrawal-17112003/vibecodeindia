// VibeCode wordmark — split-circle mark: coral top, ink bottom, brackets + pulse
const WORD = "vibecoder";
const CORAL = "#E8623A";
const INK = "#0F0F0F";

function VibeMarkSvg({ size = 36 }: { size?: number }) {
  return (
    <svg
      viewBox="0 0 48 48"
      width={size}
      height={size}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden
    >
      {/* Split ring: top half coral, bottom half ink */}
      <path
        d="M4 24 A20 20 0 0 1 44 24"
        stroke={CORAL}
        strokeWidth="5"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M4 24 A20 20 0 0 0 44 24"
        stroke={INK}
        strokeWidth="5"
        strokeLinecap="round"
        fill="none"
      />
      {/* Left bracket */}
      <path
        d="M17 19 L12 24 L17 29"
        stroke={INK}
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      {/* Right bracket */}
      <path
        d="M31 19 L36 24 L31 29"
        stroke={INK}
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      {/* Heartbeat pulse */}
      <path
        d="M19 25 L21.5 25 L23 20 L25 30 L26.5 25 L29 25"
        stroke={CORAL}
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <circle cx="29" cy="25" r="1.4" fill={CORAL} />
    </svg>
  );
}

export function VibeCodeLogo({ size = 28, className }: { size?: number; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2 ${className ?? ""}`}>
      <VibeMarkSvg size={size} />
      <span className="font-display text-xl font-extrabold tracking-tight leading-none" aria-label={WORD}>
        <span style={{ color: INK }}>{WORD.slice(0, 4)}</span>
        <span style={{ color: CORAL }}>{WORD.slice(4)}</span>
      </span>
    </span>
  );
}

export function VibeCodeMark({ size = 36 }: { size?: number }) {
  return (
    <span
      className="inline-grid place-items-center"
      style={{ width: size, height: size }}
      aria-label="VibeCode"
    >
      <VibeMarkSvg size={size} />
    </span>
  );
}
