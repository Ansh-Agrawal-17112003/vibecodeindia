import { useMemo, useState } from "react";
import { InteractiveHoverLink } from "@/components/ui/interactive-hover-link";

const C = {
  cream: "#FAF6F1",
  white: "#FFFFFF",
  dark: "#0F0F0F",
  border: "#E8E0D6",
  muted: "#666666",
  coral: "#E8623A",
  coralSoft: "#FFF1EA",
  gold: "#F5A623",
};

export function PricingCalculator() {
  const [hours, setHours] = useState(20);
  const [rate, setRate] = useState(1500);

  const monthly = hours * rate;
  const yearly = monthly * 12;
  const proCost = 499;
  const roi = Math.round((monthly / proCost) * 10) / 10;

  const bar = useMemo(() => Math.min(100, (hours / 80) * 100), [hours]);
  const rateBar = useMemo(() => Math.min(100, ((rate - 500) / 4500) * 100), [rate]);

  return (
    <section
      data-reveal
      className="relative w-full overflow-hidden py-20 md:py-28"
      style={{ background: C.white }}
    >
      <div className="container-page">
        <div className="mx-auto max-w-[760px] text-center">
          <span
            className="inline-flex items-center rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-[0.14em]"
            style={{ background: C.coralSoft, color: C.coral }}
          >
            ROI Calculator
          </span>
          <h2 className="mt-6 text-[32px] md:text-[56px] lg:text-[68px] font-extrabold leading-[1.02] tracking-[-0.02em]">
            See what your time is <span style={{ color: C.coral }}>actually worth</span>.
          </h2>
          <p className="mt-4 text-base md:text-[18px]" style={{ color: C.muted }}>
            Drag the sliders. Watch the numbers move. VibeCode Pro pays for itself in{" "}
            <b style={{ color: C.dark }}>hours</b>, not months.
          </p>
        </div>

        <div
          className="mx-auto mt-12 grid max-w-[1100px] gap-6 md:grid-cols-2"
        >
          {/* Sliders */}
          <div
            className="rounded-2xl p-6 md:p-8"
            style={{ background: C.cream, border: `1.5px solid ${C.dark}`, boxShadow: "6px 6px 0 0 #0F0F0F" }}
          >
            <SliderRow
              label="Hours saved per month"
              value={`${hours} hrs`}
              min={1}
              max={80}
              step={1}
              val={hours}
              onChange={setHours}
              bar={bar}
              hint="Prompts, workflows, community help & jobs you skipped hunting for."
            />
            <div className="my-6 h-px w-full" style={{ background: C.border }} />
            <SliderRow
              label="Your effective hourly rate"
              value={`₹${rate.toLocaleString("en-IN")}`}
              min={500}
              max={5000}
              step={100}
              val={rate}
              onChange={setRate}
              bar={rateBar}
              hint="What a client pays you — or what you'd charge yourself."
            />
          </div>

          {/* Results */}
          <div
            className="relative overflow-hidden rounded-2xl p-6 md:p-8"
            style={{ background: C.dark, color: C.white }}
          >
            <div
              aria-hidden
              className="pointer-events-none absolute inset-0"
              style={{
                background: `radial-gradient(500px circle at 100% 0%, rgba(232,98,58,0.25), transparent 60%)`,
              }}
            />
            <div className="relative">
              <div className="text-[11px] font-bold uppercase tracking-[0.16em] opacity-70">
                Value returned to you
              </div>

              <div className="mt-4">
                <div className="text-[13px] opacity-70">Per month</div>
                <div className="mt-1 flex items-end gap-2">
                  <span className="text-[44px] md:text-[56px] font-extrabold leading-none tracking-tight" style={{ color: C.coral }}>
                    ₹{monthly.toLocaleString("en-IN")}
                  </span>
                </div>
              </div>

              <div className="mt-6">
                <div className="text-[13px] opacity-70">Per year</div>
                <div className="mt-1 text-[28px] md:text-[36px] font-extrabold leading-none tracking-tight" style={{ color: C.gold }}>
                  ₹{yearly.toLocaleString("en-IN")}
                </div>
              </div>

              <div
                className="mt-6 rounded-xl p-4"
                style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)" }}
              >
                <div className="flex items-center justify-between text-sm">
                  <span className="opacity-80">VibeCode Pro</span>
                  <span className="font-bold">₹{proCost}/mo</span>
                </div>
                <div className="mt-2 flex items-center justify-between text-sm">
                  <span className="opacity-80">Your ROI</span>
                  <span className="font-extrabold" style={{ color: C.coral }}>{roi}×</span>
                </div>
                <div className="mt-3 h-2 w-full overflow-hidden rounded-full" style={{ background: "rgba(255,255,255,0.1)" }}>
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${Math.min(100, roi * 4)}%`,
                      background: `linear-gradient(90deg, ${C.coral}, ${C.gold})`,
                    }}
                  />
                </div>
              </div>

              <InteractiveHoverLink
                to="/pricing"
                className="mt-6 w-full px-4 py-3 text-sm"
                style={{ background: C.coral, color: C.white, border: `1.5px solid ${C.coral}` }}
                revealBg={C.white}
                revealFg={C.dark}
              >
                Start free — upgrade when you're ready
              </InteractiveHoverLink>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function SliderRow({
  label,
  value,
  min,
  max,
  step,
  val,
  onChange,
  bar,
  hint,
}: {
  label: string;
  value: string;
  min: number;
  max: number;
  step: number;
  val: number;
  onChange: (n: number) => void;
  bar: number;
  hint: string;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <label className="text-[13px] font-bold uppercase tracking-[0.12em]" style={{ color: C.dark }}>
          {label}
        </label>
        <span className="text-[22px] font-extrabold tracking-tight" style={{ color: C.coral }}>
          {value}
        </span>
      </div>
      <div className="relative mt-3">
        <div className="h-2 w-full rounded-full" style={{ background: "#EADFCE" }} />
        <div
          className="pointer-events-none absolute left-0 top-0 h-2 rounded-full transition-all duration-150"
          style={{ width: `${bar}%`, background: C.coral }}
        />
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={val}
          onChange={(e) => onChange(Number(e.target.value))}
          className="absolute inset-0 h-2 w-full cursor-pointer opacity-0"
          aria-label={label}
        />
      </div>
      <p className="mt-2 text-[12px]" style={{ color: C.muted }}>{hint}</p>
    </div>
  );
}
