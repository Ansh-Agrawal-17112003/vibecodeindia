import { useEffect, useRef, useState } from "react";
import { Check, X as XIcon } from "lucide-react";

const C = {
  cream: "#FAF6F1",
  white: "#FFFFFF",
  dark: "#0F0F0F",
  border: "#E8E0D6",
  muted: "#666666",
  coral: "#E8623A",
  coralSoft: "#FFF1EA",
  green: "#22C55E",
};

type Row = { feature: string; vibecode: boolean; linkedin: boolean; producthunt: boolean; discord: boolean };

const ROWS: Row[] = [
  { feature: "Built for Indian AI builders",       vibecode: true,  linkedin: false, producthunt: false, discord: false },
  { feature: "Ship-in-public feed (not resumes)",  vibecode: true,  linkedin: false, producthunt: false, discord: false },
  { feature: "Share prompts & workflows",           vibecode: true,  linkedin: false, producthunt: false, discord: true  },
  { feature: "Discover builders by tool (Lovable, Cursor…)", vibecode: true, linkedin: false, producthunt: false, discord: false },
  { feature: "Curated AI-first jobs & gigs",        vibecode: true,  linkedin: true,  producthunt: false, discord: false },
  { feature: "Launch products to a niche audience", vibecode: true,  linkedin: false, producthunt: true,  discord: false },
  { feature: "Communities with paid access",        vibecode: true,  linkedin: false, producthunt: false, discord: true  },
  { feature: "Verified builder profile & OG badge", vibecode: true,  linkedin: false, producthunt: false, discord: false },
  { feature: "No recruiter spam",                   vibecode: true,  linkedin: false, producthunt: true,  discord: true  },
  { feature: "Signal-to-noise for shippers",        vibecode: true,  linkedin: false, producthunt: false, discord: false },
];

export function CompareTable() {
  return (
    <section
      data-reveal
      className="relative w-full overflow-hidden border-t-[1.5px]"
      style={{ background: C.cream, borderColor: C.dark }}
    >
      <div className="mx-auto w-full max-w-[1200px] px-5 py-16 md:px-8 md:py-24">
        <h2 className="font-display text-[32px] md:text-[52px] font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ color: C.dark }}>
          Why not just use the other places?
        </h2>
        <p className="mt-3 max-w-[640px] text-[15px] md:text-[17px]" style={{ color: "#4a463d" }}>
          They're great for what they're built for. None of them are built for you.
        </p>

        <div
          className="mt-10 overflow-hidden rounded-2xl"
          style={{ background: C.white, border: `1.5px solid ${C.dark}`, boxShadow: `4px 4px 0 0 ${C.dark}` }}
        >
          {/* Header */}
          <div
            className="grid items-center px-4 py-4 text-[11px] font-bold uppercase tracking-[0.14em] md:px-6 md:py-5"
            style={{ background: C.dark, color: C.white, gridTemplateColumns: "1.6fr repeat(4, 1fr)" }}
          >
            <div className="opacity-70">Feature</div>
            <ColHeader label="VibeCode" highlight />
            <ColHeader label="LinkedIn" />
            <ColHeader label="Product Hunt" />
            <ColHeader label="Discord" />
          </div>

          {ROWS.map((r, i) => (
            <CompareRow key={r.feature} row={r} index={i} />
          ))}
        </div>

        <p className="mt-6 text-[13px]" style={{ color: "#888" }}>
          One place instead of four tabs. Built for builders in India.
        </p>
      </div>
    </section>
  );
}

function ColHeader({ label, highlight = false }: { label: string; highlight?: boolean }) {
  return (
    <div className="text-center">
      <span
        className="inline-block rounded-md px-2.5 py-1"
        style={{
          background: highlight ? C.coral : "transparent",
          color: highlight ? C.white : C.white,
          opacity: highlight ? 1 : 0.7,
        }}
      >
        {label}
      </span>
    </div>
  );
}

function CompareRow({ row, index }: { row: Row; index: number }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [seen, setSeen] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setSeen(true)),
      { threshold: 0.2 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className="grid items-center border-t px-4 py-4 md:px-6 md:py-5"
      style={{
        gridTemplateColumns: "1.6fr repeat(4, 1fr)",
        borderColor: C.border,
        background: index % 2 === 0 ? C.white : "#FBF7F1",
      }}
    >
      <div className="pr-3 text-[13px] md:text-[15px] font-medium" style={{ color: C.dark }}>
        {row.feature}
      </div>
      <Mark on={row.vibecode}     delay={80  + index * 30} seen={seen} highlight />
      <Mark on={row.linkedin}     delay={140 + index * 30} seen={seen} />
      <Mark on={row.producthunt}  delay={200 + index * 30} seen={seen} />
      <Mark on={row.discord}      delay={260 + index * 30} seen={seen} />
    </div>
  );
}

function Mark({ on, delay, seen, highlight = false }: { on: boolean; delay: number; seen: boolean; highlight?: boolean }) {
  const show = seen;

  // Premium palette per state
  const styles = on
    ? highlight
      ? {
          bg: "linear-gradient(135deg, #F07A54 0%, #E8623A 100%)",
          fg: "#FFFFFF",
          ring: "1px solid rgba(255,255,255,0.35)",
          shadow: "0 8px 20px -8px rgba(232,98,58,0.55), inset 0 1px 0 rgba(255,255,255,0.25)",
        }
      : {
          bg: "#EAF7EF",
          fg: "#15803D",
          ring: "1px solid rgba(21,128,61,0.18)",
          shadow: "inset 0 1px 0 rgba(255,255,255,0.6)",
        }
    : {
        bg: "#F6F1EA",
        fg: "#B8AFA2",
        ring: "1px solid rgba(15,15,15,0.06)",
        shadow: "none",
      };

  return (
    <div className="flex items-center justify-center">
      <span
        className="inline-flex h-8 w-8 items-center justify-center rounded-full transition-all md:h-9 md:w-9"
        style={{
          background: styles.bg,
          color: styles.fg,
          border: styles.ring,
          boxShadow: styles.shadow,
          transform: show ? "scale(1)" : "scale(0.5)",
          opacity: show ? 1 : 0,
          transitionDelay: `${delay}ms`,
          transitionDuration: "500ms",
          transitionTimingFunction: "cubic-bezier(0.34, 1.56, 0.64, 1)",
        }}
        aria-hidden
      >
        {on ? (
          <Check className="h-[15px] w-[15px] md:h-4 md:w-4" strokeWidth={2.75} strokeLinecap="round" strokeLinejoin="round" />
        ) : (
          <XIcon className="h-[13px] w-[13px] md:h-[14px] md:w-[14px]" strokeWidth={2.25} strokeLinecap="round" strokeLinejoin="round" />
        )}
      </span>
    </div>
  );
}

