import { Counter } from "./Counter";

export function StatsStrip({
  items,
}: {
  items: { label: string; value: number; prefix?: string; suffix?: string }[];
}) {
  return (
    <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
      {items.map((it) => (
        <div
          key={it.label}
          className="rounded-2xl border-[1.5px] border-foreground bg-card p-4 shadow-[3px_3px_0_0_#0F0F0F]"
        >
          <Counter
            to={it.value}
            prefix={it.prefix}
            suffix={it.suffix}
            className="font-display text-2xl font-extrabold tracking-tight md:text-3xl"
          />
          <div className="mt-1 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            {it.label}
          </div>
        </div>
      ))}
    </div>
  );
}
