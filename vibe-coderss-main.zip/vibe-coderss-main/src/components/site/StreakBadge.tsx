import { Flame } from "lucide-react";

/**
 * Compact streak pill — 🔥 with count. Tooltip on title.
 * Used in Navbar, profile header, leaderboard row.
 */
export function StreakBadge({ streak, size = "sm" }: { streak: number; size?: "xs" | "sm" }) {
  if (!streak || streak < 1) return null;
  const cls = size === "xs" ? "h-6 px-1.5 text-[11px]" : "h-7 px-2 text-xs";
  const icon = size === "xs" ? "h-3 w-3" : "h-3.5 w-3.5";
  return (
    <span
      title={`${streak}-day Vibe Streak — keep it going!`}
      className={`inline-flex items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white font-bold tabular-nums ${cls}`}
      style={{ boxShadow: "1.5px 1.5px 0 0 #0F0F0F" }}
    >
      <Flame className={`${icon} text-coral`} fill="currentColor" />
      {streak}
    </span>
  );
}
