import { useState } from "react";
import { Copy, Loader2, Upload, CheckCircle2, ExternalLink } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { usePlatformSettings } from "@/hooks/useSubscription";
import { PAYEE_UPI_ID, upiQrUrl } from "@/lib/payee";

export function UpgradeModal({
  open,
  onOpenChange,
  plan,
  onSubmitted,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  plan: "pro" | "business";
  onSubmitted?: () => void;
}) {
  const { user } = useAuth();
  const { settings } = usePlatformSettings();
  const [utr, setUtr] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const amount = Number(settings[`${plan}_plan_price`] ?? (plan === "pro" ? "499" : "2999"));
  const upi = PAYEE_UPI_ID;
  const qr = settings.payment_qr_url || upiQrUrl({ amount, note: `VibeCode ${plan}`, ref: `${plan}-${user?.id ?? "guest"}` });
  const paymentLink = settings[`${plan}_plan_payment_link`];

  const copy = (val: string) => {
    navigator.clipboard.writeText(val);
    toast.success("Copied to clipboard");
  };

  const submit = async () => {
    if (!user) {
      toast.error("Please sign in first");
      return;
    }
    if (!utr.trim()) {
      toast.error("Enter the transaction / UTR number");
      return;
    }
    setSubmitting(true);
    try {
      let screenshotUrl: string | null = null;
      if (file) {
        const ext = file.name.split(".").pop() ?? "png";
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("payment-screenshots")
          .upload(path, file, { upsert: false });
        if (upErr) throw upErr;
        screenshotUrl = path;
      }
      const { error } = await supabase.from("subscription_requests").insert({
        profile_id: user.id,
        requested_plan: plan,
        amount,
        transaction_reference: utr.trim(),
        payment_screenshot_url: screenshotUrl,
      });
      if (error) throw error;
      setDone(true);
      toast.success("Submitted — we'll verify within 24 hours");
      onSubmitted?.();
    } catch (e) {
      toast.error((e as Error).message ?? "Submission failed");
    } finally {
      setSubmitting(false);
    }
  };

  const close = () => {
    onOpenChange(false);
    setTimeout(() => {
      setDone(false);
      setUtr("");
      setFile(null);
    }, 300);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => (o ? onOpenChange(true) : close())}>
      <DialogContent className="max-w-lg border-[1.5px] border-[#0F0F0F] bg-cream shadow-[6px_6px_0_0_#0F0F0F]">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl font-extrabold uppercase">
            {done ? "Submitted ✓" : `Upgrade to ${plan}`}
          </DialogTitle>
          <DialogDescription>
            {done
              ? "Your plan will be activated within 24 hours after we verify your payment."
              : `Amount due: ₹${amount.toLocaleString("en-IN")} — pay via UPI or the link below, then submit your transaction reference.`}
          </DialogDescription>
        </DialogHeader>

        {done ? (
          <div className="space-y-4 py-2">
            <div className="flex items-start gap-3 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white p-4">
              <CheckCircle2 className="h-5 w-5 shrink-0 text-coral" />
              <div className="text-sm">
                We've received your payment claim. You'll get a notification and email
                once it's verified.
              </div>
            </div>
            <button onClick={close} className="btn-coral w-full justify-center">Done</button>
          </div>
        ) : (
          <div className="space-y-5">
            {/* Step 1 */}
            <section>
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Step 1 · Pay</div>
              <div className="mt-2 space-y-3">
                <div className="flex items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2">
                  <span className="text-xs font-bold uppercase">UPI</span>
                  <span className="flex-1 font-mono text-sm">{upi}</span>
                  <button onClick={() => copy(upi)} className="rounded-md border border-[#0F0F0F] bg-cream p-1.5 hover:bg-white">
                    <Copy className="h-3.5 w-3.5" />
                  </button>
                </div>
                {qr && (
                  <div className="flex justify-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-white p-3">
                    <img src={qr} alt="Payment QR" className="h-40 w-40 object-contain" />
                  </div>
                )}
                {paymentLink && (
                  <a
                    href={paymentLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-gold px-4 py-2.5 text-sm font-bold hover:shadow-[3px_3px_0_0_#0F0F0F]"
                  >
                    Pay ₹{amount} via Razorpay <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                )}
              </div>
            </section>

            {/* Step 2 */}
            <section>
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Step 2 · Confirm</div>
              <div className="mt-2 space-y-3">
                <div>
                  <label className="text-xs font-bold uppercase">Transaction / UTR number *</label>
                  <input
                    value={utr}
                    onChange={(e) => setUtr(e.target.value)}
                    placeholder="e.g. 412345678901"
                    className="mt-1.5 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold uppercase">Payment screenshot (optional)</label>
                  <label className="mt-1.5 flex cursor-pointer items-center gap-2 rounded-lg border-[1.5px] border-dashed border-[#0F0F0F] bg-white px-3 py-2.5 text-sm hover:bg-cream">
                    <Upload className="h-4 w-4" />
                    {file ? file.name : "Choose a file"}
                    <input
                      type="file"
                      accept="image/*"
                      hidden
                      onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                    />
                  </label>
                </div>
              </div>
            </section>

            <button onClick={submit} disabled={submitting} className="btn-coral w-full justify-center disabled:opacity-70">
              {submitting ? (<><Loader2 className="h-4 w-4 animate-spin" /> Submitting…</>) : "Submit for verification"}
            </button>
            <p className="text-center text-[11px] text-muted-foreground">
              Your plan will be activated within 24 hours after we verify your payment.
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
