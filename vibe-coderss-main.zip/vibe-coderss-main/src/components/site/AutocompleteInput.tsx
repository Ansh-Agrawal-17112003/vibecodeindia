import { useEffect, useMemo, useRef, useState } from "react";
import { useTypewriter } from "@/hooks/useTypewriter";

type Props = {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  suggestions: string[];
  className?: string;
  wrapperClassName?: string;
  max?: number;
  /** Optional preset list shown when the input is empty + focused (e.g. popular searches) */
  presets?: string[];
  /** Optional list of animated typewriter placeholders (cycled while empty) */
  typewriter?: string[];
};

export function AutocompleteInput({
  value,
  onChange,
  placeholder,
  suggestions,
  className = "h-9 w-full bg-transparent text-sm outline-none",
  wrapperClassName = "relative flex-1",
  max = 8,
  presets,
  typewriter,
}: Props) {
  const typed = useTypewriter(typewriter ?? [], { type: 55, erase: 25, pause: 1600 });
  const activePlaceholder = typewriter && typewriter.length && !value ? typed : placeholder;
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const items = useMemo(() => {
    const term = value.trim().toLowerCase();
    const pool = Array.from(new Set(suggestions.filter(Boolean)));
    if (!term) return (presets ?? pool).slice(0, max);
    return pool
      .filter((s) => s.toLowerCase().includes(term) && s.toLowerCase() !== term)
      .sort((a, b) => {
        const ai = a.toLowerCase().indexOf(term);
        const bi = b.toLowerCase().indexOf(term);
        return ai - bi || a.length - b.length;
      })
      .slice(0, max);
  }, [value, suggestions, presets, max]);

  return (
    <div ref={ref} className={wrapperClassName}>
      <input
        value={value}
        onChange={(e) => {
          onChange(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        placeholder={activePlaceholder}
        className={className}
        autoComplete="off"
      />
      {open && items.length > 0 && (
        <div className="absolute left-0 right-0 top-[calc(100%+6px)] z-50 max-h-72 overflow-y-auto rounded-lg border-[1.5px] border-[#0F0F0F] bg-card shadow-[3px_3px_0_0_#0F0F0F]">
          {items.map((s) => (
            <button
              type="button"
              key={s}
              onMouseDown={(e) => {
                e.preventDefault();
                onChange(s);
                setOpen(false);
              }}
              className="block w-full truncate px-3 py-2 text-left text-sm hover:bg-coral hover:text-white"
            >
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
