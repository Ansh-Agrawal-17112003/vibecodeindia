// Real payment brand icons.
// Colored, recognizable brand marks are inlined as SVG (Simple Icons is monochrome-only,
// which turns Google Pay / Amazon Pay / CRED / wallets into flat black blobs).
// Every viewBox is tightened so the mark fills its container edge-to-edge with
// object-contain — no dead whitespace shrinking the logo inside its tile.

import type { CSSProperties, ReactElement } from "react";

export type PaymentBrandSlug =
  | "googlepay" | "phonepe" | "paytm" | "amazonpay" | "cred" | "whatsapp"
  | "visa" | "mastercard" | "americanexpress" | "dinersclub"
  | "mobikwik" | "freecharge" | "paytmwallet" | "amazonpaybalance";

type Props = {
  slug: PaymentBrandSlug | string;
  color?: string; // hex without # — only used by the CDN fallback
  alt: string;
  className?: string;
  style?: CSSProperties;
};

const Inline: Record<string, (p: { alt: string; className?: string; style?: CSSProperties }) => ReactElement> = {
  // Google Pay — full "G" + "Pay" wordmark, snug viewBox
  googlepay: ({ alt, className, style }) => (
    <svg viewBox="0 0 88 32" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <g transform="translate(0 4)">
        <path fill="#4285F4" d="M24 12.3c0-.85-.08-1.65-.22-2.42H12.2v4.58h6.63c-.29 1.55-1.16 2.85-2.47 3.75v3.1h4c2.34-2.17 3.67-5.36 3.67-9.01z"/>
        <path fill="#34A853" d="M12.2 24.5c3.34 0 6.14-1.1 8.19-3l-4-3.1c-1.11.75-2.52 1.2-4.19 1.2-3.22 0-5.94-2.17-6.92-5.09H1.14v3.16c2.04 4.05 6.22 6.83 11.06 6.83z"/>
        <path fill="#FBBC04" d="M5.28 14.5c-.25-.75-.39-1.55-.39-2.38 0-.82.14-1.62.39-2.37V6.59H1.14C.41 8.03 0 9.66 0 12.13c0 2.46.41 4.09 1.14 5.53l4.14-3.16z"/>
        <path fill="#EA4335" d="M12.2 4.75c1.82 0 3.45.62 4.74 1.85l3.55-3.55C18.34 1.19 15.54 0 12.2 0 7.36 0 3.18 2.78 1.14 6.83l4.14 3.16c.98-2.92 3.7-5.09 6.92-5.09z"/>
      </g>
      <text x="30" y="21" fontFamily="Product Sans, Arial, sans-serif" fontWeight="500" fontSize="16" fill="#5F6368">Pay</text>
    </svg>
  ),

  phonepe: ({ alt, className, style }) => (
    <svg viewBox="0 0 32 32" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <rect width="32" height="32" rx="6" fill="#5F259F"/>
      <path fill="#fff" d="M23 14.3c0-.5-.4-.85-.9-.85h-2.1v-1.55c0-2.1-1.7-3.8-3.8-3.8-.4 0-.7.3-.7.7s.3.7.7.7c1.3 0 2.4 1.05 2.4 2.4v1.55H10.8c-.5 0-.9.35-.9.85V21c0 2.4 1.9 4.3 4.3 4.3h3.6c2.4 0 4.3-1.9 4.3-4.3v-6.7zm-4.7 6.05c0 .5-.35.85-.85.85h-1c-.4 0-.75-.35-.75-.85V16.5h2.6v3.85z"/>
    </svg>
  ),

  paytm: ({ alt, className, style }) => (
    <svg viewBox="0 0 82 24" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <text x="0" y="19" fontFamily="Arial, sans-serif" fontWeight="800" fontSize="22" fill="#00BAF2">pay</text>
      <text x="42" y="19" fontFamily="Arial, sans-serif" fontWeight="800" fontSize="22" fill="#002970">tm</text>
    </svg>
  ),

  paytmwallet: ({ alt, className, style }) => (
    <svg viewBox="0 0 138 24" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <text x="0" y="19" fontFamily="Arial, sans-serif" fontWeight="800" fontSize="21" fill="#00BAF2">pay</text>
      <text x="41" y="19" fontFamily="Arial, sans-serif" fontWeight="800" fontSize="21" fill="#002970">tm</text>
      <text x="78" y="19" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="13" fill="#002970">Wallet</text>
    </svg>
  ),

  amazonpay: ({ alt, className, style }) => (
    <svg viewBox="0 0 128 36" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <text x="0" y="20" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="20" fill="#131A22">amazon</text>
      <text x="76" y="20" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="20" fill="#FF9900">pay</text>
      <path d="M2 27c20 8 56 8 76 0" fill="none" stroke="#FF9900" strokeWidth="2.5" strokeLinecap="round"/>
      <path d="M78 25.5l4 1.8-4 3.5z" fill="#FF9900"/>
    </svg>
  ),

  amazonpaybalance: ({ alt, className, style }) => (
    <svg viewBox="0 0 128 48" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <text x="0" y="20" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="19" fill="#131A22">amazon</text>
      <text x="74" y="20" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="19" fill="#FF9900">pay</text>
      <path d="M2 26c20 7 55 7 74 0" fill="none" stroke="#FF9900" strokeWidth="2.2" strokeLinecap="round"/>
      <text x="0" y="44" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="13" fill="#131A22">Balance</text>
    </svg>
  ),

  cred: ({ alt, className, style }) => (
    <svg viewBox="0 0 84 28" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <rect width="84" height="28" rx="5" fill="#0F0F0F"/>
      <text x="42" y="20" textAnchor="middle" fontFamily="Georgia, serif" fontStyle="italic" fontWeight="700" fontSize="17" fill="#FFFFFF" letterSpacing="2">CRED</text>
    </svg>
  ),

  whatsapp: ({ alt, className, style }) => (
    <svg viewBox="0 0 32 32" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <circle cx="16" cy="16" r="15" fill="#25D366"/>
      <path fill="#fff" d="M16 6C10.5 6 6 10.5 6 16c0 1.8.5 3.4 1.3 4.9L6 26l5.3-1.4c1.4.8 3 1.2 4.7 1.2 5.5 0 10-4.5 10-10S21.5 6 16 6zm5.8 14.2c-.2.6-1.2 1.2-1.7 1.3-.4.1-1 .1-1.6-.1-.4-.1-.9-.3-1.5-.6-2.6-1.1-4.4-3.8-4.5-4-.1-.2-1.1-1.4-1.1-2.8s.7-2 1-2.2c.2-.2.5-.3.7-.3h.5c.2 0 .4-.1.6.4.2.5.7 1.7.8 1.9.1.1.1.3 0 .4 0 .1-.1.3-.2.4l-.4.4c-.1.1-.2.3-.1.5.1.2.6 1.1 1.4 1.7 1 .9 1.8 1.1 2.1 1.3.3.1.4.1.6-.1.1-.2.6-.8.8-1 .2-.2.4-.2.6-.1s1.6.8 1.9.9c.3.1.4.2.5.4.1.1.1.8-.2 1.4z"/>
    </svg>
  ),

  mobikwik: ({ alt, className, style }) => (
    <svg viewBox="0 0 108 24" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <text x="0" y="19" fontFamily="Arial, sans-serif" fontWeight="800" fontSize="20" fill="#272361">MobiK</text>
      <text x="68" y="19" fontFamily="Arial, sans-serif" fontWeight="800" fontSize="20" fill="#00A3E1">wik</text>
    </svg>
  ),

  freecharge: ({ alt, className, style }) => (
    <svg viewBox="0 0 138 28" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <circle cx="14" cy="14" r="12" fill="#F05B24"/>
      <path d="M9 14l3.5 3.5L20 9.5" stroke="#fff" strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
      <text x="32" y="20" fontFamily="Arial, sans-serif" fontWeight="800" fontSize="18" fill="#231F20">Freecharge</text>
    </svg>
  ),

  visa: ({ alt, className, style }) => (
    <svg viewBox="0 0 60 20" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <text x="30" y="17" textAnchor="middle" fontFamily="Arial, sans-serif" fontStyle="italic" fontWeight="900" fontSize="20" fill="#1A1F71" letterSpacing="1">VISA</text>
    </svg>
  ),

  mastercard: ({ alt, className, style }) => (
    <svg viewBox="0 0 36 22" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <circle cx="13" cy="11" r="10" fill="#EB001B"/>
      <circle cx="23" cy="11" r="10" fill="#F79E1B"/>
      <path d="M18 3.5a10 10 0 000 15 10 10 0 000-15z" fill="#FF5F00"/>
    </svg>
  ),

  americanexpress: ({ alt, className, style }) => (
    <svg viewBox="0 0 56 22" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <rect width="56" height="22" rx="3" fill="#2E77BC"/>
      <text x="28" y="10" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="800" fontSize="7" fill="#fff">AMERICAN</text>
      <text x="28" y="18" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="800" fontSize="7" fill="#fff">EXPRESS</text>
    </svg>
  ),

  dinersclub: ({ alt, className, style }) => (
    <svg viewBox="0 0 84 22" role="img" aria-label={alt} className={className} style={style} preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
      <circle cx="11" cy="11" r="10" fill="#0079BE"/>
      <path d="M8 4v14a7 7 0 000-14zm6 0v14a7 7 0 000-14z" fill="#fff"/>
      <text x="26" y="15" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="9" fill="#0079BE">Diners Club</text>
    </svg>
  ),
};

export function PaymentBrand({ slug, color, alt, className = "h-6 w-auto", style }: Props) {
  const key = String(slug).toLowerCase();
  const Draw = Inline[key];
  if (Draw) return <Draw alt={alt} className={className} style={style} />;
  const url = color ? `https://cdn.simpleicons.org/${slug}/${color}` : `https://cdn.simpleicons.org/${slug}`;
  return <img src={url} alt={alt} loading="lazy" className={className} style={style} />;
}
