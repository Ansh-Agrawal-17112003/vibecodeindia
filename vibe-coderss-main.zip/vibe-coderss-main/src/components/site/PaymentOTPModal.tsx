import { useEffect, useRef, useState } from "react";
import { Loader2, Shield, RefreshCw, CheckCircle2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  amount: number;
  purpose: string;
  reference: string;
  method?: string;
  onVerified: (otpId: string) => void | Promise<void>;
}

export function PaymentOTPModal({ open, onOpenChange, amount, purpose, reference, method = "UPI", onVerified }: Props) {
  const { user } = useAuth();
  const [otp, setOtp] = useState("");
  const [otpId, setOtpId] = useState<string | null>(null);
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [seconds, setSeconds] = useState(120);
  const [creating, setCreating] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [done, setDone] = useState(false);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startTimer = () => {
    setSeconds(120);
    if (tickRef.current) clearInterval(tickRef.current);
    tickRef.current = setInterval(() => {
      setSeconds((s) => {
        if (s <= 1) {
          clearInterval(tickRef.current!);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
  };

  const sendOtp = async () => {
    if (!user) return toast.error("Please sign in");
    setCreating(true);
    const code = String(Math.floor(100000 + Math.random() * 900000));
    const expires = new Date(Date.now() + 5 * 60 * 1000).toISOString();
    const { data, error } = await supabase
      .from("payment_otps")
      .insert({
        user_id: user.id,
        purpose,
        reference,
        amount,
        otp_code: code,
        expires_at: expires,
      })
      .select()
      .single();
    setCreating(false);
    if (error) return toast.error(error.message);
    setOtpId(data.id);
    setGeneratedOtp(code);
    setOtp("");
    startTimer();
    toast.success(`OTP sent · Use ${code}`, { description: "Demo OTP — shown here for testing." });
  };

  useEffect(() => {
    if (open && !otpId) sendOtp();
    if (!open) {
      setOtp("");
      setOtpId(null);
      setGeneratedOtp(null);
      setDone(false);
      if (tickRef.current) clearInterval(tickRef.current);
    }
    return () => {
      if (tickRef.current) clearInterval(tickRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const verify = async () => {
    if (otp.length !== 6 || !otpId) return;
    setVerifying(true);
    const { data, error } = await supabase
      .from("payment_otps")
      .select("*")
      .eq("id", otpId)
      .single();
    if (error || !data) {
      setVerifying(false);
      return toast.error("OTP session expired. Resend a new code.");
    }
    if (new Date(data.expires_at) < new Date()) {
      setVerifying(false);
      return toast.error("OTP expired — tap Resend.");
    }
    if (data.otp_code !== otp) {
      setVerifying(false);
      return toast.error("Incorrect OTP. Try again.");
    }
    await supabase
      .from("payment_otps")
      .update({ status: "verified", verified_at: new Date().toISOString() })
      .eq("id", otpId);
    setDone(true);
    setVerifying(false);
    toast.success("Payment verified ✓");
    await onVerified(otpId);
    setTimeout(() => onOpenChange(false), 1200);
  };

  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md border-[1.5px] border-[#0F0F0F] bg-cream shadow-[6px_6px_0_0_#0F0F0F]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display text-xl font-extrabold uppercase">
            <Shield className="h-5 w-5 text-coral" /> Verify Payment
          </DialogTitle>
          <DialogDescription>
            Enter the 6-digit OTP to confirm your ₹{amount.toLocaleString("en-IN")} {method} payment.
          </DialogDescription>
        </DialogHeader>

        {done ? (
          <div className="grid place-items-center gap-3 py-6">
            <CheckCircle2 className="h-14 w-14 text-success" />
            <div className="font-bold">Payment confirmed</div>
            <div className="text-sm text-muted-foreground">Activating your access…</div>
          </div>
        ) : (
          <div className="space-y-5 py-2">
            <div className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-white p-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-bold">₹{amount.toLocaleString("en-IN")}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Method</span>
                <span className="font-bold">{method}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Ref</span>
                <span className="font-mono text-xs">{reference.slice(0, 18)}</span>
              </div>
            </div>

            <div className="flex flex-col items-center gap-3">
              <InputOTP maxLength={6} value={otp} onChange={setOtp}>
                <InputOTPGroup>
                  {[0, 1, 2, 3, 4, 5].map((i) => (
                    <InputOTPSlot key={i} index={i} className="h-12 w-10 border-[1.5px] border-[#0F0F0F] text-lg font-bold" />
                  ))}
                </InputOTPGroup>
              </InputOTP>
              <div className="text-xs text-muted-foreground">
                {seconds > 0 ? <>OTP valid for <span className="font-mono">{mm}:{ss}</span></> : "OTP expired"}
              </div>
              {generatedOtp && (
                <div className="rounded-md border border-dashed border-coral/60 bg-coral/5 px-3 py-1.5 text-[11px] text-coral">
                  Demo OTP: <span className="font-mono font-bold">{generatedOtp}</span>
                </div>
              )}
            </div>

            <button
              onClick={verify}
              disabled={otp.length !== 6 || verifying || creating}
              className="btn-coral w-full justify-center disabled:opacity-50"
            >
              {verifying ? <><Loader2 className="h-4 w-4 animate-spin" /> Verifying…</> : `Pay ₹${amount.toLocaleString("en-IN")}`}
            </button>
            <button
              onClick={sendOtp}
              disabled={creating || seconds > 90}
              className="flex w-full items-center justify-center gap-2 text-xs text-muted-foreground hover:text-foreground disabled:opacity-50"
            >
              <RefreshCw className="h-3 w-3" /> Resend OTP
            </button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
