// Real brand logos via simple-icons CDN. Returns a colored chip with the actual logo mark.
// CDN: https://cdn.simpleicons.org/<slug>/<hexcolor>
type Meta = { slug?: string; bg: string; fg?: string; initial?: string; invertOnDark?: boolean };

const TOOL_META: Record<string, Meta> = {
  Lovable:    { bg: "#FF4D8D", fg: "#fff", initial: "♥" },
  Cursor:     { bg: "#0F0F0F", fg: "#fff", initial: "⌘" },
  ChatGPT:    { bg: "#10A37F", fg: "#fff", initial: "G" },
  "GPT-4":    { bg: "#10A37F", fg: "#fff", initial: "G" },
  "GPT-4o":   { bg: "#10A37F", fg: "#fff", initial: "G" },
  "GPT-4 Vision": { bg: "#10A37F", fg: "#fff", initial: "G" },
  Whisper:    { bg: "#10A37F", fg: "#fff", initial: "W" },
  Claude:     { slug: "anthropic", bg: "#D97757", fg: "#fff" },
  Gemini:     { slug: "googlegemini", bg: "#4285F4", fg: "#fff" },
  n8n:        { slug: "n8n", bg: "#EA4B71", fg: "#fff" },
  Make:       { slug: "make", bg: "#6D00CC", fg: "#fff" },
  Zapier:     { slug: "zapier", bg: "#FF4A00", fg: "#fff" },
  Bolt:       { bg: "#0F0F0F", fg: "#fff", initial: "⚡" },
  v0:         { slug: "vercel", bg: "#0F0F0F", fg: "#fff" },
  Supabase:   { slug: "supabase", bg: "#3ECF8E", fg: "#fff" },
  Vercel:     { slug: "vercel", bg: "#0F0F0F", fg: "#fff" },
  Figma:      { slug: "figma", bg: "#F24E1E", fg: "#fff" },
  "Figma API":{ slug: "figma", bg: "#F24E1E", fg: "#fff" },
  Midjourney: { bg: "#0F0F0F", fg: "#fff", initial: "✦" },
  Stripe:     { slug: "stripe", bg: "#635BFF", fg: "#fff" },
  HubSpot:    { slug: "hubspot", bg: "#FF7A59", fg: "#fff" },
  Slack:      { slug: "slack", bg: "#4A154B", fg: "#fff" },
  Apollo:     { bg: "#1E40AF", fg: "#fff", initial: "A" },
  Linear:     { slug: "linear", bg: "#5E6AD2", fg: "#fff" },
  GitHub:     { slug: "github", bg: "#0F0F0F", fg: "#fff" },
  Tally:      { bg: "#FFC107", fg: "#0F0F0F", initial: "T" },
  Beehiiv:    { bg: "#FFCC4F", fg: "#0F0F0F", initial: "B" },
  "Twitter API": { slug: "x", bg: "#0F0F0F", fg: "#fff" },
  Notion:     { slug: "notion", bg: "#FFFFFF", fg: "#000" },
  Discord:    { slug: "discord", bg: "#5865F2", fg: "#fff" },
  Dribbble:   { slug: "dribbble", bg: "#EA4C89", fg: "#fff" },
  Binance:    { slug: "binance", bg: "#F0B90B", fg: "#000" },
  Producthunt:{ slug: "producthunt", bg: "#DA552F", fg: "#fff" },
  YouTube:    { slug: "youtube", bg: "#FF0000", fg: "#fff" },
  LinkedIn:   { slug: "linkedin", bg: "#0A66C2", fg: "#fff" },
  Instagram:  { slug: "instagram", bg: "#E4405F", fg: "#fff" },
  Twitter:    { slug: "x", bg: "#0F0F0F", fg: "#fff" },
  Telegram:   { slug: "telegram", bg: "#26A5E4", fg: "#fff" },
  WhatsApp:   { slug: "whatsapp", bg: "#25D366", fg: "#fff" },
  Replit:     { slug: "replit", bg: "#F26207", fg: "#fff" },
  Anthropic:  { slug: "anthropic", bg: "#D97757", fg: "#fff" },
  OpenAI:     { bg: "#10A37F", fg: "#fff", initial: "O" },
  Perplexity: { slug: "perplexity", bg: "#1FB8CD", fg: "#fff" },
  Replicate:  { slug: "replicate", bg: "#0F0F0F", fg: "#fff" },
};

function LogoImg({ slug, fg }: { slug: string; fg: string }) {
  const color = (fg ?? "#fff").replace("#", "");
  return (
    <img
      src={`https://cdn.simpleicons.org/${slug}/${color}`}
      alt=""
      className="h-3 w-3"
      loading="lazy"
      onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
    />
  );
}

export function ToolLogo({ name }: { name: string }) {
  const meta = TOOL_META[name] ?? { bg: "#E8E0D6", fg: "#0F0F0F", initial: name[0] };
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-card py-0.5 pl-0.5 pr-2.5 text-[11px] font-bold text-foreground">
      <span
        className="grid h-5 w-5 place-items-center rounded-full text-[10px] font-bold"
        style={{ backgroundColor: meta.bg, color: meta.fg ?? "#fff" }}
      >
        {meta.slug ? <LogoImg slug={meta.slug} fg={meta.fg ?? "#fff"} /> : (meta.initial ?? name[0])}
      </span>
      {name}
    </span>
  );
}

export function ToolLogos({ names, max = 4 }: { names: string[]; max?: number }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {names.slice(0, max).map((n) => <ToolLogo key={n} name={n} />)}
    </div>
  );
}

// Large standalone logo tile (for marquee / partner grids)
export function BrandTile({ name, size = 44 }: { name: string; size?: number }) {
  const meta = TOOL_META[name] ?? { bg: "#E8E0D6", fg: "#0F0F0F", initial: name[0] };
  return (
    <div
      className="grid shrink-0 place-items-center rounded-[10px] border-[1.5px] border-[#0F0F0F]"
      style={{ width: size, height: size, backgroundColor: meta.bg, boxShadow: "2px 2px 0 0 #0F0F0F" }}
      title={name}
    >
      {meta.slug ? (
        <img
          src={`https://cdn.simpleicons.org/${meta.slug}/${(meta.fg ?? "#fff").replace("#", "")}`}
          alt={name}
          className="h-1/2 w-1/2"
          loading="lazy"
        />
      ) : (
        <span className="text-base font-extrabold" style={{ color: meta.fg ?? "#fff" }}>{meta.initial}</span>
      )}
    </div>
  );
}
