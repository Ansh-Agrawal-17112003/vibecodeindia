import { useEffect, useState } from "react";
import { Sparkles, Check, Crown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

const STORAGE_KEY = "vc_og_founder_seen_v1";

const OG_FEATURES = [
  "Everything in Builder",
  "500 VibeCoins (claim 1 paid community free)",
  "Top of search results",
  "Verified Builder badge (premium red)",
  "Verified OG badge (golden)",
  "Featured profile placement",
  "Priority job application",
  "Advanced profile analytics",
  "Profile boost 2x / month",
  "Early access to new / beta features",
  "Founding member — name on Founder's Wall forever",
];

export function OgFounderWelcomeModal() {
  const { user, refreshProfile } = useAuth();
  const [open, setOpen] = useState(false);
  const [result, setResult] = useState<{ already_claimed?: boolean } | null>(null);

  useEffect(() => {
    if (!user) return;
    const key = `${STORAGE_KEY}:${user.id}`;
    if (typeof window === "undefined") return;
    if (localStorage.getItem(key) === "1") return;

    let cancelled = false;
    (async () => {
      const { data, error } = await supabase.rpc("claim_og_founder_access" as never);
      if (cancelled || error) return;
      const r = data as { granted?: boolean; already_claimed?: boolean } | null;
      if (r?.granted) {
        // Only pop once ever per user; if they already claimed on a previous
        // device, don't nag.
        if (!r.already_claimed) {
          setResult(r);
          setOpen(true);
          refreshProfile().catch(() => {});
        }
        localStorage.setItem(key, "1");
      }
    })();
    return () => { cancelled = true; };
  }, [user, refreshProfile]);

  if (!open) return null;

  const close = () => setOpen(false);

  return (
    <div
      className="fixed inset-0 z-[110] flex items-center justify-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="OG Founder welcome"
    >
      <div
        className="relative w-full max-w-lg rounded-[22px] border-[1.5px] border-[#0F0F0F] bg-white p-6 md:p-8"
        style={{ boxShadow: "10px 10px 0 0 #0F0F0F" }}
      >
        <button
          onClick={close}
          aria-label="Close"
          className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white text-lg font-bold hover:bg-cream"
        >
          ×
        </button>

        <div className="text-center">
          <div
            className="mx-auto mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full border-[1.5px] border-[#0F0F0F]"
            style={{ background: "#F5A623", boxShadow: "4px 4px 0 0 #0F0F0F" }}
          >
            <Crown className="h-8 w-8 text-[#0F0F0F]" />
          </div>
          <div className="mb-2 inline-flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-[#F5A623] px-3 py-1 text-[11px] font-extrabold uppercase tracking-wider text-[#0F0F0F]">
            <Sparkles className="h-3.5 w-3.5" /> OG Founder · Free for 1 Year
          </div>
          <h2 className="mt-2 font-display text-3xl font-extrabold leading-tight tracking-tight text-[#0F0F0F] md:text-[34px]">
            Welcome, OG Founder 👑
          </h2>
          <p className="mt-3 text-sm text-muted-foreground">
            You joined the early access list — so we've unlocked the full
            <span className="font-bold text-[#0F0F0F]"> OG Builder plan </span>
            on your account, absolutely free for the next 12 months.
          </p>
        </div>

        <div className="mt-5 rounded-[14px] border-[1.5px] border-[#0F0F0F] bg-cream p-4">
          <div className="mb-2 text-[11px] font-extrabold uppercase tracking-wider text-[#0F0F0F]">
            What you get today
          </div>
          <ul className="grid gap-1.5 md:grid-cols-2">
            {OG_FEATURES.map((f) => (
              <li key={f} className="flex items-start gap-2 text-[13px] text-[#0F0F0F]">
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-coral" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>

        {result?.already_claimed ? null : (
          <p className="mt-4 text-center text-[12px] font-semibold text-muted-foreground">
            🎁 500 VibeCoins added to your wallet · Golden OG badge active on your profile
          </p>
        )}

        <button
          onClick={close}
          className="btn-coral mt-5 h-12 w-full text-base"
        >
          Let's Build →
        </button>
      </div>
    </div>
  );
}
