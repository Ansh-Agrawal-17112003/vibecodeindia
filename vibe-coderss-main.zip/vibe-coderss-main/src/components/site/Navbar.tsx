import { Link, useNavigate } from "@tanstack/react-router";
import {
  Bell, MessageSquare, Menu, Plus, LogOut, Bookmark, Shield, ChevronDown, User as UserIcon,
  Home, Compass, Users, Briefcase, Wrench, FolderGit2, Lightbulb, Workflow as WorkflowIcon,
  Package, LayoutTemplate, BookOpen, Settings as SettingsIcon, LogIn, Sparkles,
} from "lucide-react";
import { useState } from "react";
import { VibeCodeLogo } from "./Logo";
import { useAuth } from "@/hooks/useAuth";
import { useNotifications, useUnreadMessages } from "@/hooks/useNotifications";
import { useXpProfile } from "@/hooks/useXpProfile";
import { StreakBadge } from "@/components/site/StreakBadge";
import { useSavedJobs } from "@/lib/saved-jobs";
import { useViewMode } from "@/hooks/useViewMode";
import { Sheet, SheetContent, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { InteractiveHoverButton } from "@/components/ui/interactive-hover-button";
import { ShimmerButton } from "@/components/ui/shimmer-button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";


function Badge({ n }: { n: number }) {
  if (!n) return null;
  return (
    <span className="absolute -right-1 -top-1 grid h-4 min-w-[16px] place-items-center rounded-full bg-coral px-1 text-[10px] font-bold text-white">
      {n > 99 ? "99+" : n}
    </span>
  );
}

const primaryLinks = [
  { to: "/", label: "Vibe", icon: Home },
  { to: "/explore", label: "Explore", icon: Compass },
  { to: "/communities", label: "Communities", icon: Users },
  { to: "/jobs", label: "Jobs", icon: Briefcase },
  { to: "/services", label: "Services", icon: Wrench },
] as const;

const moreLinks = [
  { to: "/projects", label: "Projects", icon: FolderGit2 },
  { to: "/prompts", label: "Prompts", icon: Lightbulb },
  { to: "/workflows", label: "Workflows", icon: WorkflowIcon },
  { to: "/tools", label: "Tools", icon: Package },
  { to: "/templates", label: "Templates", icon: LayoutTemplate },
  { to: "/blog", label: "Blog", icon: BookOpen },
] as const;



export function Navbar() {
  const { user, profile, signOut, isAdmin, isSuperAdmin } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const authed = !!user;
  const { unread: unreadNotifs } = useNotifications();
  const { count: unreadMsgs } = useUnreadMessages();
  const { count: savedCount } = useSavedJobs();
  const { profile: xp } = useXpProfile();
  const [viewMode, setViewMode] = useViewMode();
  const showAdmin = authed && isAdmin;

  return (
    <header className="sticky top-0 z-40 border-b-[1.5px] border-[#0F0F0F] bg-background">
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <Link to="/landing" onClick={() => setMobileOpen(false)}><VibeCodeLogo /></Link>

        <nav className="hidden items-center gap-0.5 lg:flex">
          {primaryLinks.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="nav-shimmer group relative rounded-full px-3 py-1.5 text-sm font-semibold text-foreground/75 transition-colors duration-200 hover:text-foreground"
              activeProps={{ className: "text-coral" }}

            >
              <span className="pointer-events-none absolute inset-0 -z-10 scale-90 rounded-full bg-foreground/[0.06] opacity-0 transition-all duration-200 ease-out group-hover:scale-100 group-hover:opacity-100" />
              <span className="relative">
                {l.label}
                <span className="pointer-events-none absolute -bottom-0.5 left-1/2 h-[2px] w-0 -translate-x-1/2 rounded-full bg-coral transition-all duration-300 ease-out group-hover:w-4/5" />
              </span>
            </Link>
          ))}
          <DropdownMenu>
            <DropdownMenuTrigger className="nav-shimmer group relative inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-sm font-semibold text-foreground/75 outline-none transition-colors duration-200 hover:text-foreground data-[state=open]:text-foreground">
              <span className="pointer-events-none absolute inset-0 -z-10 scale-90 rounded-full bg-foreground/[0.06] opacity-0 transition-all duration-200 ease-out group-hover:scale-100 group-hover:opacity-100 group-data-[state=open]:scale-100 group-data-[state=open]:opacity-100" />
              More <ChevronDown className="h-3.5 w-3.5 transition-transform duration-200 group-data-[state=open]:rotate-180" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              {moreLinks.map((l) => (
                <DropdownMenuItem key={l.to} asChild>
                  <Link to={l.to} className="w-full">{l.label}</Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>


        <div className="flex items-center gap-2">
          {showAdmin && (
            <Link
              to="/admin"
              title="Admin Panel"
              className="nav-shimmer hidden h-9 items-center gap-1.5 rounded-lg border border-[#333] bg-[#0F0F0F] px-3.5 text-[13px] font-semibold text-white transition-all duration-200 ease-out hover:-translate-y-0.5 hover:bg-coral hover:border-coral hover:shadow-[0_6px_0_-1px_#0F0F0F] active:translate-y-0 active:shadow-none md:inline-flex"
            >
              <Shield className="h-3.5 w-3.5" /> Admin
            </Link>

          )}
          <Link to="/early-access" title="Join Early Access — Founding OG Member" className="nav-shimmer group relative hidden h-9 items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-3 text-xs font-extrabold text-white transition-all duration-200 ease-out hover:-translate-x-[2px] hover:-translate-y-[2px] hover:shadow-[4px_4px_0_0_#0F0F0F] active:translate-x-0 active:translate-y-0 active:shadow-[1px_1px_0_0_#0F0F0F] md:inline-flex" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <span className="grid h-4 w-4 place-items-center">🔥</span> Join Early Access
          </Link>
          {authed && (
            <Link to="/submit" className="nav-shimmer group hidden h-9 items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-gold px-3 text-xs font-bold text-[#0F0F0F] transition-all duration-200 ease-out hover:-translate-x-[2px] hover:-translate-y-[2px] hover:bg-[#ffb735] hover:shadow-[4px_4px_0_0_#0F0F0F] active:translate-x-0 active:translate-y-0 active:shadow-[1px_1px_0_0_#0F0F0F] md:inline-flex" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <Plus className="h-3.5 w-3.5 transition-transform duration-200 group-hover:rotate-90" /> Submit
            </Link>
          )}
          <Link to="/saved-jobs" title="Saved Jobs" className="nav-shimmer group relative hidden h-9 items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 text-xs font-bold transition-all duration-200 ease-out hover:-translate-x-[2px] hover:-translate-y-[2px] hover:bg-pink hover:shadow-[4px_4px_0_0_#0F0F0F] active:translate-x-0 active:translate-y-0 active:shadow-[1px_1px_0_0_#0F0F0F] md:inline-flex" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>

            <Bookmark className={`h-3.5 w-3.5 transition-transform duration-200 group-hover:scale-110 ${savedCount ? "fill-coral text-coral" : ""}`} /> Saved
            {savedCount > 0 && <span className="ml-0.5 grid h-4 min-w-[16px] place-items-center rounded-full bg-coral px-1 text-[10px] font-bold text-white">{savedCount > 99 ? "99+" : savedCount}</span>}
          </Link>
          {authed ? (
            <>
              {xp && xp.login_streak > 0 && (
                <Link to="/dashboard" title="Your Vibe Streak" className="hidden md:inline-flex">
                  <StreakBadge streak={xp.login_streak} size="sm" />
                </Link>
              )}
              <Link to="/notifications" className="group relative hidden h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card transition-all duration-200 ease-out hover:-translate-x-[2px] hover:-translate-y-[2px] hover:bg-pink hover:shadow-[4px_4px_0_0_#0F0F0F] active:translate-x-0 active:translate-y-0 active:shadow-[1px_1px_0_0_#0F0F0F] md:grid" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>

                <Bell className="h-4 w-4 transition-transform duration-200 group-hover:-rotate-12" />
                <Badge n={unreadNotifs} />
              </Link>
              <Link to="/messages" className="group relative hidden h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card transition-all duration-200 ease-out hover:-translate-x-[2px] hover:-translate-y-[2px] hover:bg-pink hover:shadow-[4px_4px_0_0_#0F0F0F] active:translate-x-0 active:translate-y-0 active:shadow-[1px_1px_0_0_#0F0F0F] md:grid" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                <MessageSquare className="h-4 w-4 transition-transform duration-200 group-hover:scale-110" />
                <Badge n={unreadMsgs} />
              </Link>
              <DropdownMenu>
                <DropdownMenuTrigger className="hidden h-9 w-9 place-items-center overflow-hidden rounded-full border-[1.5px] border-[#0F0F0F] bg-card outline-none transition-all duration-200 ease-out hover:-translate-x-[2px] hover:-translate-y-[2px] hover:shadow-[4px_4px_0_0_#E8623A] active:translate-x-0 active:translate-y-0 active:shadow-[1px_1px_0_0_#0F0F0F] data-[state=open]:-translate-x-[2px] data-[state=open]:-translate-y-[2px] data-[state=open]:shadow-[4px_4px_0_0_#E8623A] md:grid" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                  <img src={profile?.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(user?.email ?? "me")}`} alt="" className="h-full w-full transition-transform duration-200 hover:scale-110" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {profile?.username && (
                    <DropdownMenuItem asChild><Link to="/u/$username" params={{ username: profile.username }}>My Profile</Link></DropdownMenuItem>
                  )}
                  <DropdownMenuItem asChild><Link to="/dashboard">Dashboard</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link to="/settings">Settings</Link></DropdownMenuItem>
                  {isAdmin && (
                    <>
                      <DropdownMenuSeparator />
                      {viewMode === "admin" ? (
                        <>
                          <DropdownMenuItem asChild>
                            <Link to="/admin" className="font-bold text-coral">
                              <Shield className="mr-2 h-4 w-4" /> {isSuperAdmin ? "Super Admin Panel" : "Admin Panel"}
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => setViewMode("user")}>
                            <UserIcon className="mr-2 h-4 w-4" /> Switch to User view
                          </DropdownMenuItem>
                        </>
                      ) : (
                        <DropdownMenuItem onSelect={() => { setViewMode("admin"); navigate({ to: "/admin" }); }}>
                          <Shield className="mr-2 h-4 w-4" /> Switch to {isSuperAdmin ? "Super Admin" : "Admin"} view
                        </DropdownMenuItem>
                      )}
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={async () => { await signOut(); navigate({ to: "/" }); }}>
                    <LogOut className="mr-2 h-4 w-4" /> Log out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <div className="hidden items-center gap-2 md:flex">
              <Link to="/auth" className="inline-flex h-9 items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-4 text-sm font-bold text-foreground transition hover:-translate-y-0.5" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>Log In</Link>
              <Link to="/auth" search={{ mode: "signup" } as any} className="inline-block">
                <ShimmerButton className="h-9 px-5 text-sm">Join Free</ShimmerButton>
              </Link>
            </div>
          )}

          <Link to="/saved-jobs" title="Saved" className="relative grid h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card lg:hidden" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <Bookmark className={`h-4 w-4 ${savedCount ? "fill-coral text-coral" : ""}`} />
            {savedCount > 0 && <span className="absolute -right-1 -top-1 grid h-4 min-w-[16px] place-items-center rounded-full bg-coral px-1 text-[10px] font-bold text-white">{savedCount > 99 ? "99+" : savedCount}</span>}
          </Link>
          {authed && (
            <>
              <Link to="/messages" title="Messages" className="relative grid h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card lg:hidden" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                <MessageSquare className="h-4 w-4" />
                <Badge n={unreadMsgs} />
              </Link>
            </>
          )}
          <button aria-label="Open menu" onClick={() => setMobileOpen(true)} className="grid h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card lg:hidden" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <Menu className="h-4 w-4" />
          </button>
        </div>
      </div>

      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-[85%] max-w-xs overflow-y-auto border-r-[1.5px] border-[#0F0F0F] bg-background p-0">
          <SheetTitle className="sr-only">Navigation menu</SheetTitle>
          <SheetDescription className="sr-only">Primary site navigation, libraries, and account actions.</SheetDescription>
          <MobileDrawerContent
            user={user}
            profile={profile}
            authed={authed}
            isAdmin={isAdmin}
            isSuperAdmin={isSuperAdmin}
            viewMode={viewMode}
            setViewMode={setViewMode}
            unreadNotifs={unreadNotifs}
            unreadMsgs={unreadMsgs}
            savedCount={savedCount}
            close={() => setMobileOpen(false)}
            onSignOut={async () => { await signOut(); setMobileOpen(false); navigate({ to: "/" }); }}
            onAdminSwitch={() => { setViewMode("admin"); setMobileOpen(false); navigate({ to: "/admin" }); }}
          />
        </SheetContent>
      </Sheet>
    </header>
  );
}

function MobileDrawerContent({
  user, profile, authed, isAdmin, isSuperAdmin, viewMode, setViewMode,
  unreadNotifs, unreadMsgs, savedCount,
  close, onSignOut, onAdminSwitch,
}: any) {
  const displayName = (user?.user_metadata?.display_name as string) || user?.email?.split("@")[0] || "Guest";
  const avatar = profile?.avatar_url || (user?.user_metadata?.avatar_url as string) || `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(user?.email ?? "guest")}`;
  const profileHref = profile?.username ? { to: "/u/$username" as const, params: { username: profile.username } } : { to: "/dashboard" as const };

  return (
    <div className="flex h-full flex-col">
      {/* Header: avatar / greeting */}
      <div className="flex items-center gap-3 border-b-[1.5px] border-[#0F0F0F] bg-cream p-4">
        <Link {...profileHref} onClick={close} className="grid h-12 w-12 place-items-center overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F] bg-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          <img src={avatar} alt="" className="h-full w-full" />
        </Link>
        <div className="min-w-0 flex-1">
          <div className="truncate font-display text-base font-extrabold">{authed ? displayName : "Welcome, builder"}</div>
          <div className="text-[11px] font-bold text-muted-foreground">
            {authed ? "Signed in · India's AI builder network" : "Join 120,000+ vibe coders"}
          </div>
        </div>
      </div>

      <div className="flex-1 space-y-5 overflow-y-auto p-4">
        {/* NAVIGATE */}
        <div>
          <h4 className="mb-2 px-1 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Navigate</h4>
          <ul className="space-y-0.5 text-sm">
            {primaryLinks.map((l) => {
              const Icon = l.icon;
              return (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    onClick={close}
                    className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left font-bold text-foreground/80 hover:bg-cream"
                    activeProps={{ className: "flex w-full items-center gap-2 rounded-md bg-coral/15 px-2 py-2 text-left font-bold text-coral" }}
                    activeOptions={{ exact: l.to === "/" }}
                  >
                    <Icon className="h-4 w-4" /> {l.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>

        {/* LIBRARIES */}
        <div>
          <h4 className="mb-2 px-1 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Libraries</h4>
          <ul className="space-y-0.5 text-sm">
            {moreLinks.map((l) => {
              const Icon = l.icon;
              return (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    onClick={close}
                    className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left font-bold text-foreground/80 hover:bg-cream"
                    activeProps={{ className: "flex w-full items-center gap-2 rounded-md bg-coral/15 px-2 py-2 text-left font-bold text-coral" }}
                  >
                    <Icon className="h-4 w-4" /> {l.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>

        {/* YOU */}
        {authed && (
          <div>
            <h4 className="mb-2 px-1 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">You</h4>
            <ul className="space-y-0.5 text-sm">
              {profile?.username && (
                <li>
                  <Link to="/u/$username" params={{ username: profile.username }} onClick={close} className="flex w-full items-center justify-between gap-2 rounded-md px-2 py-2 font-bold text-foreground/80 hover:bg-cream">
                    <span className="flex items-center gap-2"><UserIcon className="h-4 w-4" /> My Profile</span>
                  </Link>
                </li>
              )}
              <li>
                <Link to="/dashboard" onClick={close} className="flex w-full items-center justify-between gap-2 rounded-md px-2 py-2 font-bold text-foreground/80 hover:bg-cream">
                  <span className="flex items-center gap-2"><UserIcon className="h-4 w-4" /> Dashboard</span>
                </Link>
              </li>
              <li>
                <Link to="/notifications" onClick={close} className="flex w-full items-center justify-between gap-2 rounded-md px-2 py-2 font-bold text-foreground/80 hover:bg-cream">
                  <span className="flex items-center gap-2"><Bell className="h-4 w-4" /> Notifications</span>
                  {unreadNotifs > 0 && <span className="rounded-full bg-coral px-1.5 py-0.5 text-[10px] font-extrabold text-white">{unreadNotifs > 99 ? "99+" : unreadNotifs}</span>}
                </Link>
              </li>
              <li>
                <Link to="/messages" onClick={close} className="flex w-full items-center justify-between gap-2 rounded-md px-2 py-2 font-bold text-foreground/80 hover:bg-cream">
                  <span className="flex items-center gap-2"><MessageSquare className="h-4 w-4" /> Messages</span>
                  {unreadMsgs > 0 && <span className="rounded-full bg-coral px-1.5 py-0.5 text-[10px] font-extrabold text-white">{unreadMsgs > 99 ? "99+" : unreadMsgs}</span>}
                </Link>
              </li>
              <li>
                <Link to="/saved-jobs" onClick={close} className="flex w-full items-center justify-between gap-2 rounded-md px-2 py-2 font-bold text-foreground/80 hover:bg-cream">
                  <span className="flex items-center gap-2"><Bookmark className={`h-4 w-4 ${savedCount ? "fill-coral text-coral" : ""}`} /> Saved</span>
                  {savedCount > 0 && <span className="rounded-full bg-cream px-1.5 py-0.5 text-[10px] font-extrabold">{savedCount}</span>}
                </Link>
              </li>
              <li>
                <Link to="/settings" onClick={close} className="flex w-full items-center gap-2 rounded-md px-2 py-2 font-bold text-foreground/80 hover:bg-cream">
                  <SettingsIcon className="h-4 w-4" /> Settings
                </Link>
              </li>
            </ul>
          </div>
        )}

        {/* ADMIN */}
        {authed && isAdmin && (
          <div>
            <h4 className="mb-2 px-1 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Admin</h4>
            {viewMode === "admin" ? (
              <div className="space-y-2">
                <Link to="/admin" onClick={close} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] px-3 py-2 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #E8623A" }}>
                  <Shield className="h-3.5 w-3.5" /> {isSuperAdmin ? "Super Admin Panel" : "Admin Panel"}
                </Link>
                <button onClick={() => { setViewMode("user"); close(); }} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-xs font-extrabold">
                  <UserIcon className="h-3.5 w-3.5" /> Switch to User view
                </button>
              </div>
            ) : (
              <button onClick={onAdminSwitch} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] px-3 py-2 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #E8623A" }}>
                <Shield className="h-3.5 w-3.5" /> Switch to {isSuperAdmin ? "Super Admin" : "Admin"} view
              </button>
            )}
          </div>
        )}
      </div>

      {/* Footer CTA */}
      <div className="space-y-2 border-t-[1.5px] border-[#0F0F0F] bg-cream p-4">
        <Link to="/early-access" onClick={close} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral py-2.5 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          🔥 Join Early Access — OG Member
        </Link>
        {authed ? (
          <>
            <Link to="/submit" onClick={close} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-gold py-2.5 text-xs font-extrabold text-[#0F0F0F]" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <Plus className="h-3.5 w-3.5" /> Submit / Share
            </Link>
            <button onClick={onSignOut} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-red-500/60 bg-white py-2.5 text-xs font-extrabold text-red-600">
              <LogOut className="h-3.5 w-3.5" /> Log out
            </button>
          </>
        ) : (
          <>
            <Link to="/auth" onClick={close} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral py-2.5 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <Sparkles className="h-3.5 w-3.5" /> Join Free →
            </Link>
            <Link to="/auth" onClick={close} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-white py-2.5 text-xs font-extrabold">
              <LogIn className="h-3.5 w-3.5" /> Sign in
            </Link>
          </>
        )}
      </div>
    </div>
  );
}

