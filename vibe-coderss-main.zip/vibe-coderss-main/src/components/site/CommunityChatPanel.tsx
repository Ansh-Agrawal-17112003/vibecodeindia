import { useEffect, useMemo, useRef, useState } from "react";
import { Hash, LogIn, Send, Smile } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { useAuth } from "@/hooks/useAuth";

/* ---------------- Bot participants + scripts ---------------- */

const BOTS = [
  { id: "b1", name: "Ananya",  avatar: "https://i.pravatar.cc/64?img=47", color: "#E8623A" },
  { id: "b2", name: "Rohit",   avatar: "https://i.pravatar.cc/64?img=12", color: "#2DD4BF" },
  { id: "b3", name: "Priya",   avatar: "https://i.pravatar.cc/64?img=48", color: "#F5A623" },
  { id: "b4", name: "Karan",   avatar: "https://i.pravatar.cc/64?img=15", color: "#7C3AED" },
  { id: "b5", name: "Meera",   avatar: "https://i.pravatar.cc/64?img=45", color: "#0F0F0F" },
  { id: "b6", name: "Ishaan",  avatar: "https://i.pravatar.cc/64?img=32", color: "#FF4D8D" },
  { id: "b7", name: "Divya",   avatar: "https://i.pravatar.cc/64?img=44", color: "#0EA5E9" },
  { id: "b8", name: "Aarav",   avatar: "https://i.pravatar.cc/64?img=8",  color: "#16A34A" },
];

const SCRIPTS: Record<string, string[]> = {
  general: [
    "morning folks 👋 who's shipping today?",
    "just deployed my n8n workflow to prod, feels good",
    "anyone in Bengaluru up for a coworking session sat?",
    "Claude 4.5 is genuinely nuts for agent loops",
    "cursor + lovable combo has been my superpower this month",
    "we crossed 1k MRR yesterday 🥲 thanks for all the feedback",
    "lovable cloud is honestly underrated, RLS out of the box",
    "any recs for a fast vector db under free tier?",
    "hot take: 90% of AI wrappers ship because of onboarding, not the model",
    "screen share in 5 if anyone wants to pair on a bug",
  ],
  showcase: [
    "🚀 launched my resume roaster — 400 signups in 2 days",
    "built a wedding invite generator, hit #3 on PH today",
    "dropped v2 of my Notion → Twitter agent, link in bio",
    "made a Hindi voice cloner over the weekend, sharing repo soon",
    "shipped Razorpay + UPI checkout in under an hour with lovable",
    "just crossed 10k users on my Whatsapp bot 🎉",
  ],
  help: [
    "how do you handle stripe webhooks in edge functions?",
    "stuck on supabase RLS for a many-to-many, halp",
    "anyone got a good prompt for pdf → structured json?",
    "getting CORS on my worker route, ideas?",
    "best way to store large embeddings without blowing costs?",
  ],
  resources: [
    "great thread on eval-driven dev → https://x.com/…",
    "sharing my system prompt for research agents 👇",
    "dropping a curated list of 20 must-try MCP servers",
    "cheat sheet for shadcn tokens I keep re-typing",
  ],
  jobs: [
    "we're hiring a full-stack builder in Bengaluru, 25-40 LPA",
    "looking for a freelance designer for a 2-week AI project",
    "solo founder wants a technical co-founder, DM me",
    "hiring: prompt engineer, remote, ₹1.5L/mo",
  ],
};

const TOPICS = [
  { slug: "general",   name: "general",   desc: "Open chat for everyone" },
  { slug: "showcase",  name: "showcase",  desc: "Show what you shipped" },
  { slug: "help",      name: "help",      desc: "Ask + answer questions" },
  { slug: "resources", name: "resources", desc: "Links, prompts, tools" },
  { slug: "jobs",      name: "jobs",      desc: "Gigs and hiring" },
];

type Msg = {
  id: string;
  authorId: string;
  authorName: string;
  avatar: string;
  color: string;
  body: string;
  at: number;
  self?: boolean;
};

function seedMessages(topic: string): Msg[] {
  const lines = SCRIPTS[topic] ?? SCRIPTS.general;
  const now = Date.now();
  return lines.map((body, i) => {
    const bot = BOTS[(i * 3 + topic.length) % BOTS.length];
    return {
      id: `${topic}-seed-${i}`,
      authorId: bot.id,
      authorName: bot.name,
      avatar: bot.avatar,
      color: bot.color,
      body,
      at: now - (lines.length - i) * 1000 * 60 * (3 + (i % 5)),
    };
  });
}

function fmtTime(ts: number) {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

/* ---------------- Component ---------------- */

export function CommunityChatPanel({
  communitySlug: _communitySlug,
  isMember,
  onJoinClick,
}: {
  communitySlug: string;
  isMember: boolean;
  onJoinClick: () => void;
}) {
  const { user } = useAuth();
  const [activeSlug, setActiveSlug] = useState(TOPICS[0].slug);
  const [store, setStore] = useState<Record<string, Msg[]>>(() =>
    Object.fromEntries(TOPICS.map((t) => [t.slug, seedMessages(t.slug)])),
  );
  const [draft, setDraft] = useState("");
  const [typing, setTyping] = useState<string | null>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const messages = store[activeSlug] ?? [];

  // Auto-scroll to bottom on new messages / topic switch
  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length, activeSlug]);

  // Bot posts on interval — feels alive
  useEffect(() => {
    if (!isMember) return;
    let alive = true;
    const tick = () => {
      if (!alive) return;
      const topic = TOPICS[Math.floor(Math.random() * TOPICS.length)].slug;
      const lines = SCRIPTS[topic] ?? SCRIPTS.general;
      const bot = BOTS[Math.floor(Math.random() * BOTS.length)];
      const body = lines[Math.floor(Math.random() * lines.length)];

      // Show typing indicator briefly on the active topic
      if (topic === activeSlug) {
        setTyping(bot.name);
        setTimeout(() => alive && setTyping((t) => (t === bot.name ? null : t)), 1200);
      }

      setTimeout(() => {
        if (!alive) return;
        setStore((prev) => ({
          ...prev,
          [topic]: [
            ...(prev[topic] ?? []),
            {
              id: `${topic}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
              authorId: bot.id,
              authorName: bot.name,
              avatar: bot.avatar,
              color: bot.color,
              body,
              at: Date.now(),
            },
          ],
        }));
      }, 1300);
    };
    const iv = window.setInterval(tick, 4500 + Math.random() * 2500);
    return () => {
      alive = false;
      window.clearInterval(iv);
    };
  }, [isMember, activeSlug]);

  const onlineCount = useMemo(() => 40 + Math.floor(Math.random() * 60), []);

  /* ---------------- Gates ---------------- */

  if (!user) {
    return (
      <div className="rounded-xl border-[1.5px] border-foreground bg-card p-10 text-center">
        <p className="font-bold">Sign in to join the chat</p>
        <Link
          to="/auth"
          className="mt-4 inline-flex items-center gap-2 rounded-md border-[1.5px] border-foreground bg-coral px-4 py-2 text-sm font-bold text-white shadow-[2px_2px_0_0_#0F0F0F]"
        >
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </div>
    );
  }

  if (!isMember) {
    return (
      <div className="rounded-xl border-[1.5px] border-foreground bg-card p-10 text-center">
        <Hash className="mx-auto h-8 w-8 text-coral" />
        <p className="mt-3 font-display text-lg font-extrabold">Join to unlock chat</p>
        <p className="mt-1 text-sm text-muted-foreground">
          Members see a lively feed of ongoing conversations, can react, and reply in threads.
        </p>
        <button
          onClick={onJoinClick}
          className="mt-4 inline-flex items-center gap-2 rounded-md border-[1.5px] border-foreground bg-coral px-4 py-2 text-sm font-bold text-white shadow-[2px_2px_0_0_#0F0F0F]"
        >
          Join community
        </button>
      </div>
    );
  }

  /* ---------------- Send ---------------- */

  const send = () => {
    const body = draft.trim();
    if (!body) return;
    setStore((prev) => ({
      ...prev,
      [activeSlug]: [
        ...(prev[activeSlug] ?? []),
        {
          id: `me-${Date.now()}`,
          authorId: user.id,
          authorName: (user.user_metadata as { display_name?: string })?.display_name ?? "You",
          avatar: (user.user_metadata as { avatar_url?: string })?.avatar_url ?? "https://i.pravatar.cc/64?img=13",
          color: "#0F0F0F",
          body,
          at: Date.now(),
          self: true,
        },
      ],
    }));
    setDraft("");
  };

  /* ---------------- UI ---------------- */

  return (
    <div className="grid gap-4 md:grid-cols-[220px_1fr]">
      {/* Topics */}
      <aside className="rounded-xl border-[1.5px] border-foreground bg-card p-3">
        <p className="mb-2 px-2 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Topics</p>
        <ul className="space-y-1">
          {TOPICS.map((t) => {
            const active = t.slug === activeSlug;
            const unread = (store[t.slug]?.length ?? 0) > (t.slug === activeSlug ? 999 : 0);
            return (
              <li key={t.slug}>
                <button
                  onClick={() => setActiveSlug(t.slug)}
                  className={`flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm font-semibold transition ${
                    active ? "bg-coral text-white" : "hover:bg-[#FFE9DC]"
                  }`}
                >
                  <Hash className="h-3.5 w-3.5 opacity-70" />
                  <span className="truncate">{t.name}</span>
                  {!active && unread && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-coral" />}
                </button>
              </li>
            );
          })}
        </ul>
        <div className="mt-4 border-t border-border pt-3 text-[11px] text-muted-foreground">
          <span className="mr-1 inline-block h-2 w-2 rounded-full bg-emerald-500 align-middle" />
          {onlineCount} members online
        </div>
      </aside>

      {/* Active room */}
      <div className="flex min-h-[520px] flex-col rounded-xl border-[1.5px] border-foreground bg-card">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div>
            <div className="flex items-center gap-1.5 font-display text-base font-extrabold">
              <Hash className="h-4 w-4 text-coral" />
              {activeSlug}
            </div>
            <div className="text-[11px] text-muted-foreground">
              {TOPICS.find((t) => t.slug === activeSlug)?.desc}
            </div>
          </div>
          <div className="flex -space-x-2">
            {BOTS.slice(0, 5).map((b) => (
              <img
                key={b.id}
                src={b.avatar}
                alt=""
                className="h-6 w-6 rounded-full border-[1.5px] border-[#0F0F0F]"
              />
            ))}
          </div>
        </div>

        <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4" style={{ maxHeight: 460 }}>
          {messages.map((m) => (
            <div key={m.id} className="flex items-start gap-2.5">
              <img src={m.avatar} alt="" className="mt-0.5 h-8 w-8 rounded-full border-[1.5px] border-[#0F0F0F]" />
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline gap-2">
                  <span className="text-sm font-extrabold" style={{ color: m.color }}>
                    {m.authorName}
                  </span>
                  <span className="text-[10px] text-muted-foreground">{fmtTime(m.at)}</span>
                  {m.self && (
                    <span className="rounded bg-coral/10 px-1.5 text-[9px] font-bold uppercase text-coral">you</span>
                  )}
                </div>
                <div className="text-sm text-foreground/90">{m.body}</div>
              </div>
            </div>
          ))}
          {typing && (
            <div className="flex items-center gap-2 pl-10 text-[11px] italic text-muted-foreground">
              <span className="inline-flex gap-0.5">
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-.2s]" />
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-.1s]" />
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground" />
              </span>
              {typing} is typing…
            </div>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
          className="flex items-center gap-2 border-t border-border p-3"
        >
          <Smile className="h-4 w-4 text-muted-foreground" />
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={`Message #${activeSlug}`}
            className="h-10 flex-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 text-sm outline-none focus:shadow-[2px_2px_0_0_#0F0F0F]"
          />
          <button
            type="submit"
            disabled={!draft.trim()}
            className="inline-flex h-10 items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-4 text-sm font-bold text-white shadow-[2px_2px_0_0_#0F0F0F] disabled:opacity-50"
          >
            <Send className="h-4 w-4" /> Send
          </button>
        </form>
      </div>
    </div>
  );
}
