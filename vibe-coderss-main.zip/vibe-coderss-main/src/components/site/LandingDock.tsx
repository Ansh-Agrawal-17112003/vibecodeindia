import { Link } from "@tanstack/react-router";
import {
  Home,
  Compass,
  Sparkles,
  Briefcase,
  Users,
  MessageCircle,
  Twitter,
  Github,
  Youtube,
  Instagram,
  Mail,
  ArrowUp,
} from "lucide-react";
import { Dock, DockIcon } from "@/components/ui/dock";

type Item = {
  key: string;
  label: string;
  icon: React.ReactNode;
  to?: string;
  href?: string;
  color?: string;
  onClick?: () => void;
};

function DockDivider() {
  return <div className="mx-1 h-10 w-px shrink-0 bg-[#0F0F0F]/15" aria-hidden />;
}

function DockLabel({ children }: { children: React.ReactNode }) {
  return (
    <span
      className="pointer-events-none absolute -top-10 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md border border-[#0F0F0F] bg-[#0F0F0F] px-2 py-1 text-[11px] font-semibold text-white opacity-0 shadow-[2px_2px_0_0_#0F0F0F] transition-opacity duration-200 group-hover:opacity-100"
    >
      {children}
    </span>
  );
}

function IconTile({ children, bg = "#FFFFFF", ring = "#0F0F0F" }: { children: React.ReactNode; bg?: string; ring?: string }) {
  return (
    <span
      className="grid h-full w-full place-items-center rounded-full border-[1.5px] transition-transform"
      style={{ background: bg, borderColor: ring, color: "#0F0F0F", boxShadow: "1px 1px 0 0 #0F0F0F" }}
    >
      {children}
    </span>
  );
}

export function LandingDock() {
  const nav: Item[] = [
    { key: "home", label: "Home", icon: <Home className="h-4 w-4" />, to: "/landing", color: "#FFFFFF" },
    { key: "explore", label: "Explore", icon: <Compass className="h-4 w-4" />, to: "/explore", color: "#FFF1EA" },
    { key: "vibe", label: "Vibe Feed", icon: <Sparkles className="h-4 w-4" />, to: "/vibe", color: "#FFE4E1" },
    { key: "jobs", label: "Jobs", icon: <Briefcase className="h-4 w-4" />, to: "/jobs", color: "#F5F0E8" },
    { key: "communities", label: "Communities", icon: <Users className="h-4 w-4" />, to: "/communities", color: "#FFF1EA" },
    { key: "blog", label: "Blog", icon: <MessageCircle className="h-4 w-4" />, to: "/blog", color: "#F5F0E8" },
  ];

  const social: Item[] = [
    { key: "tw", label: "Twitter", icon: <Twitter className="h-4 w-4" />, href: "https://twitter.com/joinvibecode", color: "#E8F5FE" },
    { key: "gh", label: "GitHub", icon: <Github className="h-4 w-4" />, href: "https://github.com/joinvibecode", color: "#F3F0EB" },
    { key: "yt", label: "YouTube", icon: <Youtube className="h-4 w-4" />, href: "https://youtube.com/@joinvibecode", color: "#FFE9E6" },
    { key: "ig", label: "Instagram", icon: <Instagram className="h-4 w-4" />, href: "https://instagram.com/joinvibecode", color: "#FFEEF6" },
    { key: "mail", label: "Contact", icon: <Mail className="h-4 w-4" />, href: "mailto:hello@vibecode.in", color: "#FFF6E6" },
  ];

  return (
    <div className="relative w-full" style={{ background: "#FAF6F1" }}>
      {/* Top divider strip with brand statement */}
      <div className="border-t border-[#0F0F0F]/10 py-16 md:py-20">
        <div className="mx-auto w-full max-w-[1200px] px-5 text-center md:px-8">
          <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-[#E8623A]/30 bg-[#FFF1EA] px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-[#E8623A]">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#E8623A] opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[#E8623A]" />
            </span>
            Made in India · Shipped Worldwide
          </div>
          <h3 className="mx-auto mt-6 max-w-[900px] font-extrabold tracking-[-0.02em] text-[#0F0F0F]" style={{ fontSize: "clamp(32px, 5vw, 56px)", lineHeight: 1.05 }}>
            Everything you need, <span style={{ color: "#E8623A" }}>one click away</span>.
          </h3>
          <p className="mx-auto mt-4 max-w-[560px] text-[15px] md:text-[17px]" style={{ color: "#666" }}>
            Hover the dock. Jump to any corner of VibeCode — or ping us on your favourite platform.
          </p>
        </div>
      </div>

      {/* The dock */}
      <div className="relative pb-14 md:pb-20">
        {/* Ambient glow behind dock */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 bottom-8 mx-auto h-24 max-w-[720px]"
          style={{ background: "radial-gradient(ellipse 50% 100% at 50% 50%, rgba(232,98,58,0.25), transparent 70%)", filter: "blur(20px)" }}
        />

        <div className="relative flex justify-center px-4">
          {/* Desktop dock — magnifying */}
          <div className="hidden md:block">
            <Dock iconSize={44} iconMagnification={76} iconDistance={150} className="border-[1.5px]">
              {nav.map((it) => (
                <DockIcon key={it.key}>
                  <Link to={it.to!} className="relative grid h-full w-full place-items-center">
                    <IconTile bg={it.color}>{it.icon}</IconTile>
                    <DockLabel>{it.label}</DockLabel>
                  </Link>
                </DockIcon>
              ))}

              <DockIcon>
                <DockDivider />
              </DockIcon>

              {social.map((it) => (
                <DockIcon key={it.key}>
                  <a href={it.href} target="_blank" rel="noopener noreferrer" className="relative grid h-full w-full place-items-center">
                    <IconTile bg={it.color}>{it.icon}</IconTile>
                    <DockLabel>{it.label}</DockLabel>
                  </a>
                </DockIcon>
              ))}

              <DockIcon>
                <DockDivider />
              </DockIcon>

              <DockIcon>
                <button
                  type="button"
                  onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
                  className="relative grid h-full w-full place-items-center"
                  aria-label="Back to top"
                >
                  <span
                    className="grid h-full w-full place-items-center rounded-full border-[1.5px]"
                    style={{ background: "#E8623A", borderColor: "#0F0F0F", color: "#FFFFFF", boxShadow: "1px 1px 0 0 #0F0F0F" }}
                  >
                    <ArrowUp className="h-4 w-4" />
                  </span>
                  <DockLabel>Back to top</DockLabel>
                </button>
              </DockIcon>
            </Dock>
          </div>

          {/* Mobile: no dock — landing stays chromeless on mobile */}

        </div>

        {/* Meta strip */}
        <div className="mx-auto mt-8 flex w-full max-w-[900px] flex-col items-center justify-between gap-3 px-5 text-[12px] md:flex-row md:px-8" style={{ color: "#7a7a7a" }}>
          <div className="flex items-center gap-2">
            <span className="grid h-6 w-6 place-items-center rounded-[6px] border-[1.5px] border-[#0F0F0F] bg-[#E8623A] text-white" style={{ boxShadow: "1.5px 1.5px 0 0 #0F0F0F" }}>
              <svg viewBox="0 0 24 24" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
                <path d="M8 8 L3 12 L8 16" /><path d="M16 8 L21 12 L16 16" /><path d="M14 5 L10 19" />
              </svg>
            </span>
            <span className="font-semibold text-[#0F0F0F]">© {new Date().getFullYear()} VibeCode</span>
            <span>·</span>
            <span>All rights reserved</span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/pricing" className="transition-colors hover:text-[#E8623A]">Pricing</Link>
            <Link to="/blog" className="transition-colors hover:text-[#E8623A]">Blog</Link>
            <a href="mailto:hello@vibecode.in" className="transition-colors hover:text-[#E8623A]">Contact</a>
          </div>
        </div>
      </div>
    </div>
  );
}
