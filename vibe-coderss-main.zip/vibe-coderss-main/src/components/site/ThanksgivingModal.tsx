import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Briefcase, Sparkles, Users, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

export function ThanksgivingModal() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState<string>("builder");

  useEffect(() => {
    if (!user) return;
    const key = `vc_thanks_shown_${user.id}`;
    if (localStorage.getItem(key)) return;

    // Fetch display name
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("display_name,username")
        .eq("id", user.id)
        .maybeSingle();
      const fallback = user.email?.split("@")[0] ?? "builder";
      const chosen = (data?.display_name || data?.username || fallback).split(" ")[0];
      setName(chosen);
      setOpen(true);
      localStorage.setItem(key, String(Date.now()));
    })();
  }, [user]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[110] flex items-start justify-center overflow-y-auto bg-black/60 p-3 py-6 backdrop-blur-sm sm:items-center sm:p-4" role="dialog" aria-modal="true">
      <div
        className="relative my-auto w-full max-w-[calc(100vw-1.5rem)] rounded-[18px] border-[1.5px] border-[#0F0F0F] bg-card p-4 sm:max-w-lg sm:p-6 md:p-8"
        style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}
      >
        <button
          onClick={() => setOpen(false)}
          aria-label="Close"
          className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card hover:bg-surface sm:right-3 sm:top-3 sm:h-9 sm:w-9"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="text-center">
          <div className="mx-auto inline-flex h-12 w-12 items-center justify-center rounded-full border-[1.5px] border-[#0F0F0F] bg-gold text-2xl sm:h-16 sm:w-16 sm:text-3xl" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}>
            🎊
          </div>
          <div className="mt-3 inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-white sm:mt-4 sm:px-3 sm:py-1 sm:text-xs">
            <Sparkles className="h-3 w-3" /> You're in, {name}
          </div>
          <h2 className="mt-2 font-display text-xl font-extrabold leading-tight tracking-tight sm:mt-3 sm:text-2xl md:text-[32px]">
            Welcome to VibeCoder, {name} 💛
          </h2>
          <p className="mt-2 text-xs text-muted-foreground sm:mt-3 sm:text-sm md:text-base">
            You just joined <b className="text-foreground">India's largest vibe-coder community</b> — 50,000+ builders,
            1,200+ companies hiring, and a marketplace built for you.
          </p>

          <div className="mt-4 grid grid-cols-3 gap-1.5 text-center sm:mt-5 sm:gap-2">
            {[
              { n: "50K+", l: "Builders" },
              { n: "1.2K+", l: "Companies" },
              { n: "10K+", l: "Live jobs" },
            ].map((s) => (
              <div key={s.l} className="rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-surface p-1.5 sm:p-2">
                <div className="font-display text-sm font-extrabold text-coral sm:text-lg">{s.n}</div>
                <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground sm:text-[10px]">{s.l}</div>
              </div>
            ))}
          </div>

          <div className="mt-4 grid grid-cols-3 gap-1.5 sm:mt-6 sm:gap-2">
            <Link
              to="/jobs"
              onClick={() => setOpen(false)}
              className="group flex flex-col items-center gap-1 rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-cream p-2 text-[10px] font-bold shadow-[3px_3px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:bg-coral hover:text-white sm:p-3 sm:text-xs"
            >
              <Briefcase className="h-4 w-4 sm:h-5 sm:w-5" /> Find a job
            </Link>
            <Link
              to="/services"
              onClick={() => setOpen(false)}
              className="group flex flex-col items-center gap-1 rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-cream p-2 text-[10px] font-bold shadow-[3px_3px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:bg-coral hover:text-white sm:p-3 sm:text-xs"
            >
              <Sparkles className="h-4 w-4 sm:h-5 sm:w-5" /> Hire a builder
            </Link>
            <Link
              to="/communities"
              onClick={() => setOpen(false)}
              className="group flex flex-col items-center gap-1 rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-cream p-2 text-[10px] font-bold shadow-[3px_3px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:bg-coral hover:text-white sm:p-3 sm:text-xs"
            >
              <Users className="h-4 w-4 sm:h-5 sm:w-5" /> Join a community
            </Link>
          </div>

          <Link
            to="/dashboard"
            onClick={() => setOpen(false)}
            className="btn-coral mt-4 inline-flex h-11 w-full items-center justify-center text-sm sm:mt-5 sm:h-12 sm:text-base"
          >
            Start the Journey, {name} →
          </Link>
        </div>
      </div>
    </div>
  );
}
