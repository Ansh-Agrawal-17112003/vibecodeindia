import { useEffect, useState } from "react";

/**
 * VibeCode preloader — animated gradient text-reveal ("Dia" style).
 * Shows once per session on first arrival, then fades out.
 */
export function Preloader() {
  const [mounted, setMounted] = useState(false);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    // Only show once per browser session
    try {
      if (sessionStorage.getItem("vc_preloaded") === "1") return;
      sessionStorage.setItem("vc_preloaded", "1");
    } catch {
      // ignore storage errors
    }
    setMounted(true);
    const t1 = window.setTimeout(() => setLeaving(true), 1900);
    const t2 = window.setTimeout(() => setMounted(false), 2500);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, []);

  if (!mounted) return null;

  // Logo-matched palette: coral, gold, dark ink
  const colors = ["#E8623A", "#F5A623", "#0F0F0F", "#E8623A"];
  const gradient = `linear-gradient(90deg, ${colors.join(", ")})`;

  return (
    <div
      aria-hidden
      className="fixed inset-0 z-[9999] flex items-center justify-center"
      style={{
        background: "#FAF6F1",
        opacity: leaving ? 0 : 1,
        transition: "opacity 550ms cubic-bezier(0.22,1,0.36,1)",
        pointerEvents: leaving ? "none" : "auto",
      }}
    >
      {/* Ambient orb */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 60% 45% at 50% 50%, rgba(232,98,58,0.10), transparent 70%)",
        }}
      />

      <div className="relative flex flex-col items-center gap-6 px-6">
        {/* Mark */}
        <span
          className="grid place-items-center rounded-[12px] border-[1.5px] border-[#0F0F0F] bg-[#E8623A] text-white"
          style={{
            width: 52,
            height: 52,
            boxShadow: "3px 3px 0 0 #0F0F0F",
            animation: "vc-pop 0.5s cubic-bezier(0.22,1,0.36,1) both",
          }}
        >
          <svg viewBox="0 0 24 24" width={32} height={32} fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M8 8 L3 12 L8 16" />
            <path d="M16 8 L21 12 L16 16" />
            <path d="M14 5 L10 19" />
          </svg>
        </span>

        {/* Animated gradient wordmark */}
        <h1
          className="vc-reveal text-center font-extrabold tracking-tight"
          style={{
            fontFamily: '"Bricolage Grotesque", system-ui, sans-serif',
            fontSize: "clamp(48px, 9vw, 96px)",
            lineHeight: 1,
            backgroundImage: gradient,
            backgroundSize: "300% 100%",
            WebkitBackgroundClip: "text",
            backgroundClip: "text",
            color: "transparent",
            WebkitTextFillColor: "transparent",
          }}
        >
          Vibe Code
        </h1>

        {/* Loading rail */}
        <div
          className="relative mt-2 h-[3px] w-[180px] overflow-hidden rounded-full"
          style={{ background: "rgba(15,15,15,0.08)" }}
        >
          <span
            className="absolute inset-y-0 left-0 w-1/2 rounded-full"
            style={{
              background: "linear-gradient(90deg, transparent, #E8623A, #F5A623, transparent)",
              animation: "vc-rail 1.4s ease-in-out infinite",
            }}
          />
        </div>

        <p className="text-[11px] font-bold uppercase tracking-[0.28em]" style={{ color: "#666" }}>
          India's AI Builder Community
        </p>
      </div>

      <style>{`
        @keyframes vc-reveal-sweep {
          0%   { background-position: 100% 0; filter: blur(6px); opacity: 0; letter-spacing: 0.02em; }
          25%  { opacity: 1; filter: blur(0); }
          100% { background-position: -100% 0; filter: blur(0); opacity: 1; letter-spacing: -0.02em; }
        }
        .vc-reveal { animation: vc-reveal-sweep 2.2s cubic-bezier(0.22,1,0.36,1) both; }
        @keyframes vc-pop {
          from { transform: scale(0.6) rotate(-8deg); opacity: 0; }
          to   { transform: scale(1) rotate(0); opacity: 1; }
        }
        @keyframes vc-rail {
          0%   { transform: translateX(-100%); }
          100% { transform: translateX(220%); }
        }
      `}</style>
    </div>
  );
}
