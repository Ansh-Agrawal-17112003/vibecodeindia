import { BrandTile } from "./ToolLogo";

export function LogoMarquee({ names }: { names: string[] }) {
  // duplicate for seamless loop
  const list = [...names, ...names];
  return (
    <div className="relative overflow-hidden border-y-[1.5px] border-[#0F0F0F] bg-card py-6">
      {/* fade edges */}
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-card to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-card to-transparent" />
      <div className="flex w-max gap-6 animate-marquee">
        {list.map((n, i) => (
          <div key={`${n}-${i}`} className="flex items-center gap-3 rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-background px-4 py-2.5" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <BrandTile name={n} size={28} />
            <span className="font-display text-sm font-bold">{n}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
