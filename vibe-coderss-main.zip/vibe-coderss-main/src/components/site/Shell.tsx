import type { ReactNode } from "react";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { MobileBottomTabs } from "@/components/vibe/MobileBottomTabs";
import { ProfileCompletionBanner } from "./ProfileCompletionBanner";
import { BackToTop } from "./BackToTop";


export function Shell({ children, hideFooter, hideNavbar, mobileChromeless, chromeless }: { children: ReactNode; hideFooter?: boolean; hideNavbar?: boolean; mobileChromeless?: boolean; chromeless?: boolean }) {
  if (chromeless) {
    return (
      <div className="flex min-h-screen flex-col lg:h-screen lg:min-h-0 lg:overflow-hidden">
        <main className="flex flex-1 flex-col lg:min-h-0">{children}</main>
      </div>
    );
  }
  return (
    <div className="flex min-h-screen flex-col">
      {!hideNavbar && (
        <div className={mobileChromeless ? "hidden lg:block" : ""}>
          <Navbar />
        </div>
      )}
      <ProfileCompletionBanner />
      <main className={`flex-1 ${mobileChromeless ? "lg:pb-0" : "pb-20 lg:pb-0"}`}>{children}</main>
      {!hideFooter && (
        <div className={mobileChromeless ? "hidden lg:block" : ""}>
          <Footer />
        </div>
      )}
      <MobileBottomTabs />
      <BackToTop />
    </div>
  );
}


export function PageHeader({ title, subtitle, breadcrumb }: { title: string; subtitle?: string; breadcrumb?: string }) {
  return (
    <div className="border-b-[1.5px] border-[#0F0F0F] bg-surface/40">
      <div className="container-page py-10">
        {breadcrumb && <div className="pill-badge mb-3 bg-coral text-white">{breadcrumb}</div>}
        <h1 className="font-display text-4xl font-extrabold tracking-tight md:text-5xl">{title}</h1>
        {subtitle && <p className="mt-3 max-w-2xl text-base text-muted-foreground">{subtitle}</p>}
      </div>
    </div>
  );
}
