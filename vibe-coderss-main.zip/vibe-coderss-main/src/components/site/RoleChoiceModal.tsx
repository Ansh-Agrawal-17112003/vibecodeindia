import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Shield, ShieldCheck, User, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { setViewMode } from "@/hooks/useViewMode";

/**
 * Asked once after the Thanksgiving welcome modal. Lets an authenticated user
 * (typically admin / super-admin) pick whether to browse as a regular user or
 * jump into the admin console. Choice is persisted to localStorage and drives
 * whether the "Admin" entry point appears in the navbar.
 */
export function RoleChoiceModal() {
  const { user, isAdmin, isSuperAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (loading || !user) return;
    const thanksKey = `vc_thanks_shown_${user.id}`;
    const choiceKey = `vc_role_choice_${user.id}`;
    if (localStorage.getItem(choiceKey)) return;

    // Wait until the thanksgiving modal has been shown (or skipped) before asking.
    const check = () => {
      if (localStorage.getItem(thanksKey) && !localStorage.getItem(choiceKey)) {
        setOpen(true);
      }
    };
    check();
    const t = setInterval(check, 600);
    return () => clearInterval(t);
  }, [user, loading]);

  if (!open || !user) return null;

  const choose = (mode: "user" | "admin") => {
    setViewMode(mode);
    localStorage.setItem(`vc_role_choice_${user.id}`, mode);
    setOpen(false);
    if (mode === "admin" && isAdmin) navigate({ to: "/admin" });
  };

  const dismiss = () => {
    setViewMode("user");
    localStorage.setItem(`vc_role_choice_${user.id}`, "user");
    setOpen(false);
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm" role="dialog" aria-modal="true">
      <div
        className="relative w-full max-w-lg rounded-[18px] border-[1.5px] border-[#0F0F0F] bg-card p-6 sm:p-8"
        style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}
      >
        <button
          onClick={dismiss}
          aria-label="Close"
          className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card hover:bg-surface"
        >
          <X className="h-4 w-4" />
        </button>

        <h2 className="font-display text-2xl font-extrabold tracking-tight sm:text-[26px]">
          How do you want to enter today?
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Pick the view that fits what you're doing right now. You can switch anytime from your profile menu.
        </p>

        <div className={`mt-5 grid gap-3 ${isAdmin ? "sm:grid-cols-2" : "sm:grid-cols-1"}`}>
          <button
            onClick={() => choose("user")}
            className="group flex flex-col items-start gap-2 rounded-[12px] border-[1.5px] border-[#0F0F0F] bg-cream p-4 text-left shadow-[3px_3px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:bg-coral hover:text-white"
          >
            <span className="grid h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white text-[#0F0F0F]">
              <User className="h-4 w-4" />
            </span>
            <div className="font-display text-base font-extrabold">Continue as User</div>
            <div className="text-xs opacity-80">Browse jobs, communities, tools and services.</div>
          </button>

          {isAdmin && (
            <button
              onClick={() => choose("admin")}
              className="group flex flex-col items-start gap-2 rounded-[12px] border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] p-4 text-left text-white shadow-[3px_3px_0_0_#E8623A] transition hover:-translate-y-0.5"
            >
              <span className="grid h-9 w-9 place-items-center rounded-full border border-white/20 bg-white/10">
                {isSuperAdmin ? <ShieldCheck className="h-4 w-4" /> : <Shield className="h-4 w-4" />}
              </span>
              <div className="font-display text-base font-extrabold">
                Enter as {isSuperAdmin ? "Super Admin" : "Admin"}
              </div>
              <div className="text-xs text-white/70">Open the admin console and reveal the Admin button in the navbar.</div>
            </button>
          )}
        </div>

        {!isAdmin && (
          <p className="mt-4 text-center text-[11px] uppercase tracking-wider text-muted-foreground">
            Admin views are available to authorised accounts only.
          </p>
        )}
      </div>
    </div>
  );
}
