import { useState, useRef, useEffect } from "react";
import { Smile, Paperclip, Mic, Square, X, Reply, Send, Loader2, FileText } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const EMOJIS = ["😀","😂","😍","🤩","🥳","😎","🤔","🙌","👏","🔥","💯","✨","🚀","💛","💜","❤️","👍","👎","🙏","👀","🎉","💪","🤝","🫡","😅","😴","🤯","😭","🥲","🤗","🧠","💡","⚡","🎯","📌","✅","❌","⏰","☕","🍕"];

export function EmojiPicker({ onPick, onClose }: { onPick: (e: string) => void; onClose: () => void }) {
  return (
    <div className="absolute bottom-14 right-0 z-30 w-64 rounded-md border-[1.5px] border-[#0F0F0F] bg-card p-2 shadow-[4px_4px_0_0_#0F0F0F]">
      <div className="mb-1 flex items-center justify-between px-1 text-[10px] font-bold uppercase text-muted-foreground">
        <span>Emojis</span>
        <button onClick={onClose} aria-label="Close"><X className="h-3 w-3" /></button>
      </div>
      <div className="grid grid-cols-8 gap-1">
        {EMOJIS.map((e) => (
          <button key={e} onClick={() => onPick(e)} className="rounded p-1 text-lg hover:bg-surface" type="button">{e}</button>
        ))}
      </div>
    </div>
  );
}

export function useVoiceRecorder() {
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const recorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  const start = async (): Promise<void> => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunks.current = [];
      rec.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
      rec.start();
      recorder.current = rec;
      setRecording(true);
      setSeconds(0);
      timer.current = setInterval(() => setSeconds((s) => s + 1), 1000);
    } catch {
      toast.error("Mic permission denied");
    }
  };

  const stop = (): Promise<Blob | null> => new Promise((resolve) => {
    const rec = recorder.current;
    if (!rec) return resolve(null);
    rec.onstop = () => {
      if (timer.current) clearInterval(timer.current);
      setRecording(false);
      rec.stream.getTracks().forEach((t) => t.stop());
      const blob = new Blob(chunks.current, { type: "audio/webm" });
      resolve(blob);
    };
    rec.stop();
  });

  const cancel = () => {
    if (recorder.current) {
      recorder.current.stream.getTracks().forEach((t) => t.stop());
      recorder.current = null;
    }
    if (timer.current) clearInterval(timer.current);
    setRecording(false);
    setSeconds(0);
  };

  useEffect(() => () => { if (timer.current) clearInterval(timer.current); }, []);

  return { recording, seconds, start, stop, cancel };
}

export async function uploadAttachment(userId: string, file: File | Blob, name: string, type: string) {
  const ext = name.includes(".") ? name.split(".").pop() : "bin";
  const path = `${userId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from("message-attachments").upload(path, file, { contentType: type, upsert: false });
  if (error) throw error;
  const { data } = await supabase.storage.from("message-attachments").createSignedUrl(path, 60 * 60 * 24 * 30);
  return { url: data?.signedUrl ?? "", name, type };
}

export function AttachmentPreview({ url, type, name }: { url: string; type?: string | null; name?: string | null }) {
  if (!url) return null;
  const t = type ?? "";
  if (t.startsWith("image/")) {
    return <img src={url} alt={name ?? ""} className="mt-1 max-h-56 rounded-md border-[1.5px] border-[#0F0F0F]/40" />;
  }
  if (t.startsWith("audio/")) {
    return <audio src={url} controls className="mt-1 h-9 w-full max-w-[240px]" />;
  }
  return (
    <a href={url} target="_blank" rel="noopener noreferrer" className="mt-1 inline-flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F]/40 bg-white/70 px-2 py-1.5 text-xs font-semibold text-[#0F0F0F] hover:bg-white">
      <FileText className="h-3.5 w-3.5" /> {name ?? "Attachment"}
    </a>
  );
}

export function ReplyPreview({ body, onClear }: { body: string; onClear: () => void }) {
  return (
    <div className="mb-2 flex items-start gap-2 rounded-md border-l-4 border-coral bg-surface p-2 text-xs">
      <Reply className="mt-0.5 h-3.5 w-3.5 shrink-0 text-coral" />
      <div className="min-w-0 flex-1">
        <div className="text-[10px] font-bold uppercase tracking-wider text-coral">Replying to</div>
        <div className="truncate text-muted-foreground">{body || "attachment"}</div>
      </div>
      <button onClick={onClear} aria-label="Cancel reply" className="text-muted-foreground hover:text-foreground"><X className="h-3.5 w-3.5" /></button>
    </div>
  );
}

export { Smile, Paperclip, Mic, Square, X, Reply, Send, Loader2 };
