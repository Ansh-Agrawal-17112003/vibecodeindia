import { useEffect, useState } from "react";
import { CheckCircle2, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { joinCommunityChannels } from "@/lib/stream.functions";

type Props = {
  open: boolean;
  onClose: () => void;
  communitySlug: string;
  communityName: string;
};

type Membership = {
  slug: string;
  name: string;
  username: string;
  email: string;
  joinedAt: string;
};

const STORAGE_KEY = "vc:memberships";

export function getMemberships(): Membership[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}

export function isMember(slug: string) {
  return getMemberships().some((m) => m.slug === slug);
}

export function JoinCommunityModal({ open, onClose, communitySlug, communityName }: Props) {
  const { user } = useAuth();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [joined, setJoined] = useState(false);
  const [alreadyMember, setAlreadyMember] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) {
      setAlreadyMember(isMember(communitySlug));
      setJoined(false);
    }
  }, [open, communitySlug]);

  if (!open) return null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !email.trim() || !/^\S+@\S+\.\S+$/.test(email)) {
      toast.error("Enter a valid username and email");
      return;
    }
    setSubmitting(true);
    const list = getMemberships().filter((m) => m.slug !== communitySlug);
    list.push({
      slug: communitySlug,
      name: communityName,
      username: username.trim(),
      email: email.trim(),
      joinedAt: new Date().toISOString(),
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));

    // If signed in, join for real via Stream Chat + DB
    if (user) {
      try {
        await joinCommunityChannels({ data: { communitySlug } });
      } catch (err) {
        console.error("Failed to join Stream channels", err);
        // Non-fatal: local membership is still saved
      }
    }

    window.dispatchEvent(new CustomEvent("vc:joined", { detail: { slug: communitySlug } }));
    setJoined(true);
    setSubmitting(false);
    toast.success(`Welcome to ${communityName}! 🎉`);
  };

  return (
    <div className="fixed inset-0 z-[100] grid place-items-center bg-black/60 p-4" onClick={onClose}>
      <div
        className="relative w-full max-w-md rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-6"
        style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white" aria-label="Close">
          <X className="h-4 w-4" />
        </button>

        {joined || alreadyMember ? (
          <div className="py-4 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-success text-white">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <h3 className="mt-4 font-display text-xl font-extrabold">
              {alreadyMember && !joined ? "You're already in!" : `Welcome to ${communityName}!`}
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              You now have access to discussions, events, and resources.
            </p>
            <button onClick={onClose} className="mt-5 inline-flex h-11 items-center justify-center rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-5 text-sm font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              Start exploring →
            </button>
          </div>
        ) : (
          <>
            <h3 className="font-display text-xl font-extrabold">Join {communityName}</h3>
            <p className="mt-1 text-sm text-muted-foreground">Free · Instant access · No spam</p>
            <form onSubmit={submit} className="mt-5 space-y-3">
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username"
                required
                maxLength={40}
                className="h-11 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm outline-none focus:-translate-y-0.5 focus:shadow-[3px_3px_0_0_#0F0F0F] transition"
              />
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                placeholder="Email address"
                required
                maxLength={120}
                className="h-11 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm outline-none focus:-translate-y-0.5 focus:shadow-[3px_3px_0_0_#0F0F0F] transition"
              />
              <button type="submit" disabled={submitting} className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral text-sm font-extrabold text-white disabled:opacity-60" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
                {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
                {submitting ? "Joining..." : "Join Community →"}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}

export function copyInviteLink(slug: string) {
  const url = `${window.location.origin}/communities/${slug}?invite=1`;
  navigator.clipboard?.writeText(url).then(
    () => toast.success("Invite link copied to clipboard"),
    () => toast.error("Could not copy link"),
  );
  return url;
}
