const COMPANY_COLORS: Record<string, { bg: string; letter: string }> = {
  Razorpay: { bg: "#528FF0", letter: "R" },
  Cred: { bg: "#1A1A2E", letter: "C" },
  CRED: { bg: "#1A1A2E", letter: "C" },
  Zomato: { bg: "#E23744", letter: "Z" },
  Swiggy: { bg: "#FC8019", letter: "S" },
  Flipkart: { bg: "#2874F0", letter: "F" },
  Paytm: { bg: "#002970", letter: "P" },
  PhonePe: { bg: "#5F259F", letter: "P" },
  Meesho: { bg: "#9B2D8E", letter: "M" },
  Nykaa: { bg: "#FC2779", letter: "N" },
  NeuroStack: { bg: "#0F172A", letter: "N" },
  TechVerse: { bg: "#7C3AED", letter: "T" },
  DataPilot: { bg: "#0EA5E9", letter: "D" },
  Algorix: { bg: "#F59E0B", letter: "A" },
  BuildAI: { bg: "#10B981", letter: "B" },
  Glance: { bg: "#8B5CF6", letter: "G" },
  Practo: { bg: "#14B8A6", letter: "P" },
  Lovable: { bg: "#E8623A", letter: "L" },
  Infosys: { bg: "#0072CE", letter: "I" },
  Postman: { bg: "#FF6C37", letter: "P" },
  Unacademy: { bg: "#08BD80", letter: "U" },
  Acko: { bg: "#0F1F5C", letter: "A" },
  Zepto: { bg: "#7C3AED", letter: "Z" },
  Freshworks: { bg: "#22C55E", letter: "F" },
  "Urban Company": { bg: "#E23744", letter: "U" },
  "Sarvam AI": { bg: "#F97316", letter: "S" },
  Atlassian: { bg: "#0052CC", letter: "A" },
  PhysicsWallah: { bg: "#5F0F87", letter: "P" },
  Browserstack: { bg: "#F4B740", letter: "B" },
  "Stealth AI Startup": { bg: "#0F0F0F", letter: "S" },
};

export function CompanyLogo({
  name,
  size = 48,
  radius = 10,
  className = "",
}: {
  name: string;
  size?: number;
  radius?: number;
  className?: string;
}) {
  const c = COMPANY_COLORS[name] || { bg: "#E8623A", letter: (name?.[0] || "?").toUpperCase() };
  return (
    <div
      className={`shrink-0 ${className}`}
      style={{
        width: size,
        height: size,
        borderRadius: radius,
        background: c.bg,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: Math.round(size * 0.42),
        fontWeight: 700,
        color: "white",
        lineHeight: 1,
      }}
      aria-label={name}
    >
      {c.letter}
    </div>
  );
}
