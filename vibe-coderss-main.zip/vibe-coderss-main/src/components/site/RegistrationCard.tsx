import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";

export function RegistrationCard() {
  const navigate = useNavigate();
  const [firstName, setFirstName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    // Stash prefill so /auth (signup) and /onboarding can pick it up.
    try {
      sessionStorage.setItem(
        "vc_signup_prefill",
        JSON.stringify({ display_name: firstName, email, phone: phone ? `+91${phone}` : "" }),
      );
    } catch {}
    navigate({ to: "/auth", search: { mode: "signup" } as any });
  }

  return (
    <div className="relative mx-auto w-full max-w-full sm:max-w-md pr-1 sm:pr-0">
      <div className="absolute -top-3 left-1/2 z-10 -translate-x-1/2 whitespace-nowrap">
        <span className="pill-badge bg-coral text-[10px] text-white sm:text-xs">FREE · OPEN TO ALL</span>
      </div>
      <div className="rounded-[20px] border-[1.5px] border-[#0F0F0F] bg-card p-4 pt-7 sm:p-7 sm:pt-9 shadow-[3px_3px_0_0_#0F0F0F] sm:shadow-[4px_4px_0_0_#0F0F0F]">
        <h3 className="font-display text-xl font-extrabold leading-tight tracking-tight text-foreground sm:text-2xl">
          Save your spot — it's free
        </h3>
        <p className="mt-2 text-xs text-muted-foreground sm:text-sm">
          Create your account first, then finish your profile in 60 seconds.
        </p>
        <div className="mt-3 flex items-center gap-2 text-xs font-bold text-foreground">
          <span className="h-2 w-2 animate-blink rounded-full bg-success" />
          Free to join · 10,000 spots only
        </div>

        <form className="mt-5 space-y-3" onSubmit={handleSubmit}>
          <input
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            placeholder="First Name"
            className="h-12 w-full rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-card px-4 text-sm outline-none transition focus:-translate-y-0.5 focus:shadow-[3px_3px_0_0_#0F0F0F]"
          />
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email ID"
            type="email"
            required
            className="h-12 w-full rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-card px-4 text-sm outline-none transition focus:-translate-y-0.5 focus:shadow-[3px_3px_0_0_#0F0F0F]"
          />
          <div className="flex h-12 w-full items-center gap-2 rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-card pl-3 pr-4 transition focus-within:-translate-y-0.5 focus-within:shadow-[3px_3px_0_0_#0F0F0F]">
            <span className="text-base">🇮🇳</span>
            <span className="text-sm font-semibold text-muted-foreground">+91</span>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
              placeholder="WhatsApp Number"
              inputMode="numeric"
              className="h-full flex-1 bg-transparent text-sm outline-none"
            />
          </div>
          <button type="submit" className="btn-coral mt-2 h-12 w-full">
            Continue to sign up →
          </button>
          <p className="text-center text-[11px] text-muted-foreground">
            You'll create an account, then complete your profile.
          </p>
        </form>
      </div>
    </div>
  );
}
