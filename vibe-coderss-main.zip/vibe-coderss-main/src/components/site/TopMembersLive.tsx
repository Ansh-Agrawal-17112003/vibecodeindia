import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { TrendingUp, TrendingDown } from "lucide-react";
import { builders } from "@/lib/mock-data";

type Row = {
  id: string;
  name: string;
  username: string;
  avatar: string;
  pts: number;
  delta: number;
};

function build(): Row[] {
  // Deterministic initial state to avoid SSR/client hydration mismatch
  return builders.slice(0, 5).map((b, i) => ({
    id: b.id,
    name: b.name,
    username: b.username,
    avatar: b.avatar,
    pts: 12000 - i * 800,
    delta: 0,
  }));
}

export function TopMembersLive() {
  const [rows, setRows] = useState<Row[]>(() => build());

  useEffect(() => {

    const iv = window.setInterval(() => {
      setRows((prev) => {
        // Random engagement bumps across everyone
        const bumped = prev.map((r) => {
          const bump = Math.floor(Math.random() * 380) - 40;
          return { ...r, pts: Math.max(1000, r.pts + bump), delta: bump };
        });
        // Occasionally sub in a new builder to force reshuffle
        if (Math.random() < 0.4) {
          const pool = builders.filter((b) => !bumped.some((r) => r.id === b.id));
          if (pool.length) {
            const nb = pool[Math.floor(Math.random() * pool.length)];
            bumped[bumped.length - 1] = {
              id: nb.id,
              name: nb.name,
              username: nb.username,
              avatar: nb.avatar,
              pts: 7000 + Math.floor(Math.random() * 5000),
              delta: 400,
            };
          }
        }
        return [...bumped].sort((a, b) => b.pts - a.pts).slice(0, 5);
      });
    }, 3200);
    return () => window.clearInterval(iv);
  }, []);

  return (
    <div className="mt-3 space-y-3">
      {rows.map((r, i) => (
        <Link
          key={r.id}
          to="/u/$username"
          params={{ username: r.username }}
          className="flex items-center gap-3 transition-all duration-500 hover:text-coral"
          style={{ transform: `translateY(0)` }}
        >
          <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white text-[10px] font-extrabold">
            {i + 1}
          </span>
          <img src={r.avatar} className="h-8 w-8 rounded-full border-[1.5px] border-[#0F0F0F]" alt="" />
          <div className="min-w-0 flex-1 truncate text-sm font-bold">{r.name}</div>
          <span className="flex items-center gap-1 text-[11px] font-bold tabular-nums text-muted-foreground">
            {(r.pts / 1000).toFixed(1)}K
            {r.delta > 0 ? (
              <TrendingUp className="h-3 w-3 text-emerald-600" />
            ) : r.delta < 0 ? (
              <TrendingDown className="h-3 w-3 text-rose-600" />
            ) : null}
          </span>
        </Link>
      ))}
    </div>
  );
}
