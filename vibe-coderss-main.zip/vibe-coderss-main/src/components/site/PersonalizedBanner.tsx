import { useEffect, useState } from "react";

type Source = {
  key: "twitter" | "linkedin" | "producthunt" | "github" | "youtube" | "reddit" | "referral" | "default";
  label: string;
  headline: string;
  emoji: string;
};

const SOURCES: Record<Source["key"], Source> = {
  twitter:     { key: "twitter",     label: "Twitter",       headline: "Hey Twitter builder — the ship-in-public crew lives here.",      emoji: "𝕏" },
  linkedin:    { key: "linkedin",    label: "LinkedIn",      headline: "Welcome from LinkedIn — a home for builders, not recruiters.",   emoji: "in" },
  producthunt: { key: "producthunt", label: "Product Hunt",  headline: "Hunter? Launch here — to India's actual AI builders.",           emoji: "🐈" },
  github:      { key: "github",      label: "GitHub",        headline: "From GitHub? Meet the humans behind the commits.",               emoji: "◉" },
  youtube:     { key: "youtube",     label: "YouTube",       headline: "Saw us on YouTube? Come ship with the crew.",                    emoji: "▶" },
  reddit:      { key: "reddit",      label: "Reddit",        headline: "From Reddit — no karma farming, just builders shipping.",        emoji: "↑" },
  referral:    { key: "referral",    label: "a friend",      headline: "A friend sent you. You already belong here.",                    emoji: "✦" },
  default:     { key: "default",     label: "",              headline: "",                                                               emoji: "" },
};

function detect(): Source["key"] {
  if (typeof window === "undefined") return "default";
  try {
    const params = new URLSearchParams(window.location.search);
    const utm = (params.get("utm_source") || params.get("ref") || "").toLowerCase();
    const ref = document.referrer.toLowerCase();
    const both = `${utm} ${ref}`;

    if (/twitter|t\.co|x\.com/.test(both))       return "twitter";
    if (/linkedin|lnkd/.test(both))              return "linkedin";
    if (/producthunt|ph\b/.test(both))           return "producthunt";
    if (/github/.test(both))                     return "github";
    if (/youtube|youtu\.be/.test(both))          return "youtube";
    if (/reddit/.test(both))                     return "reddit";
    if (params.get("ref") || document.referrer)  return "referral";
    return "default";
  } catch {
    return "default";
  }
}

export function PersonalizedBanner() {
  const [source, setSource] = useState<Source["key"]>("default");
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const s = detect();
    if (s !== "default") {
      setSource(s);
      // Small delay for a smooth entrance
      const t = setTimeout(() => setVisible(true), 150);
      return () => clearTimeout(t);
    }
  }, []);

  if (source === "default") return null;
  const s = SOURCES[source];

  return (
    <div
      className="mx-auto mb-4 inline-flex max-w-[92vw] items-center gap-2 rounded-full px-3 py-1.5 text-[11px] sm:text-[12px] font-semibold transition-all duration-500"
      style={{
        background: "#0F0F0F",
        color: "#FFFFFF",
        border: "1.5px solid #0F0F0F",
        boxShadow: "2px 2px 0 0 #E8623A",
        transform: visible ? "translateY(0)" : "translateY(-6px)",
        opacity: visible ? 1 : 0,
      }}
    >
      <span
        className="inline-flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold"
        style={{ background: "#E8623A", color: "#FFFFFF" }}
        aria-hidden
      >
        {s.emoji}
      </span>
      <span className="truncate">{s.headline}</span>
    </div>
  );
}
