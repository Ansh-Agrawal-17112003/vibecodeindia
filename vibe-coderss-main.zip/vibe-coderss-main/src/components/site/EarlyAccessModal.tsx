import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const SESSION_KEY = "vc_early_access_session_v2";
const DISMISS_KEY = "vc_early_access_dismissed_v2";
// Show on every load until July 4, 2026
const CUTOFF = new Date("2026-07-04T23:59:59+05:30").getTime();

export function EarlyAccessModal() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    // Stop showing after cutoff
    if (Date.now() > CUTOFF) return;
    // Only once per browser session (avoid re-opening on every route change)
    if (sessionStorage.getItem(SESSION_KEY)) return;
    // Respect explicit dismissal within the same day
    const dismissed = localStorage.getItem(DISMISS_KEY);
    if (dismissed && Date.now() - Number(dismissed) < 24 * 60 * 60 * 1000) return;

    const t = setTimeout(() => {
      setOpen(true);
      sessionStorage.setItem(SESSION_KEY, "1");
    }, 900);
    return () => clearTimeout(t);
  }, []);

  const close = () => {
    localStorage.setItem(DISMISS_KEY, String(Date.now()));
    setOpen(false);
  };

  const startJourney = () => {
    localStorage.setItem(DISMISS_KEY, String(Date.now()));
    setOpen(false);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    const value = email.trim().toLowerCase();
    if (cleanName.length < 2) return toast.error("Please enter your name");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value)) return toast.error("Enter a valid email");
    setLoading(true);
    const { error } = await supabase
      .from("early_access_signups")
      .insert({ email: value, source: `welcome_modal:${cleanName}` });
    setLoading(false);
    if (error && !error.message.toLowerCase().includes("duplicate")) {
      toast.error("Something went wrong. Try again.");
      return;
    }
    setDone(true);
    toast.success(`Welcome aboard, ${cleanName.split(" ")[0]}! 🎉`);
  };

  if (!open) return null;

  const firstName = name.trim().split(" ")[0] || "builder";

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-black/60 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
    >
      <div
        className="relative w-full max-w-md rounded-[20px] border-[1.5px] border-[#0F0F0F] bg-card p-6 md:p-8"
        style={{ boxShadow: "8px 8px 0 0 #0F0F0F" }}
      >
        <button
          onClick={close}
          aria-label="Close"
          className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card text-lg font-bold hover:bg-surface"
        >
          ×
        </button>

        {done ? (
          <div className="text-center">
            <div className="mx-auto mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full border-[1.5px] border-[#0F0F0F] bg-gold text-3xl" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}>
              🎉
            </div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1 text-xs font-extrabold uppercase tracking-wide text-white">
              <span className="h-2 w-2 animate-pulse rounded-full bg-white" />
              You're officially in
            </div>
            <h2 className="font-display text-3xl font-extrabold leading-tight tracking-tight text-foreground md:text-[34px]">
              Thank you, {firstName} 💛
            </h2>
            <p className="mt-3 text-sm text-muted-foreground">
              Welcome to <span className="font-bold text-foreground">VibeCoder</span> — India's largest vibe coder platform with{" "}
              <span className="font-bold text-foreground">50,000+ active builders</span>, top AI-first companies, and a community that ships every single day.
            </p>

            <div className="mt-5 grid grid-cols-3 gap-2 text-center">
              {[
                { n: "50K+", l: "Builders" },
                { n: "1.2K+", l: "Companies" },
                { n: "24/7", l: "Support" },
              ].map((s) => (
                <div key={s.l} className="rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-surface p-2">
                  <div className="font-display text-lg font-extrabold text-coral">{s.n}</div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{s.l}</div>
                </div>
              ))}
            </div>

            <button onClick={startJourney} className="btn-coral mt-5 h-12 w-full text-base">
              Start the Journey, {firstName} →
            </button>
          </div>
        ) : (
          <>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1 text-xs font-extrabold uppercase tracking-wide text-white">
              <span className="h-2 w-2 animate-pulse rounded-full bg-white" />
              Pre-launch · Early Access · Until 4 July
            </div>

            <h2 className="font-display text-2xl font-extrabold leading-tight tracking-tight text-foreground md:text-3xl">
              Welcome to VibeCoder 👋
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              India's largest community of AI builders — 50,000+ vibe coders & top companies. Get first dibs on jobs, tools, invites & builder perks.
            </p>

            <form onSubmit={submit} className="mt-5 space-y-3">
              <input
                type="text" required autoFocus
                value={name} onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                className="h-12 w-full rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-card px-4 text-sm outline-none transition focus:-translate-y-0.5 focus:shadow-[3px_3px_0_0_#0F0F0F]"
              />
              <input
                type="email" required
                value={email} onChange={(e) => setEmail(e.target.value)}
                placeholder="you@builder.dev"
                className="h-12 w-full rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-card px-4 text-sm outline-none transition focus:-translate-y-0.5 focus:shadow-[3px_3px_0_0_#0F0F0F]"
              />
              <button type="submit" disabled={loading} className="btn-coral h-12 w-full disabled:opacity-70">
                {loading ? "Saving..." : "Get Early Access →"}
              </button>
              <button type="button" onClick={close} className="w-full text-xs font-semibold text-muted-foreground underline underline-offset-4 hover:text-foreground">
                Skip for now, take me to the platform
              </button>
            </form>

            <div className="mt-5 flex items-center justify-between border-t-[1.5px] border-dashed border-[#0F0F0F]/30 pt-3 text-[11px] font-semibold text-muted-foreground">
              <span>🇮🇳 Made for Indian builders</span>
              <span>No spam. Unsubscribe anytime.</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
