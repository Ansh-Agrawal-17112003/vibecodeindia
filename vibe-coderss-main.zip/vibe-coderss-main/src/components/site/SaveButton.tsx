import { Bookmark } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useSavedItems, type SavedKind } from "@/lib/saved-items";
import { xpToast } from "@/lib/xp-toast";

type Props = {
  kind: SavedKind;
  id: string;
  className?: string;
  label?: string;
};

export function SaveButton({ kind, id, className, label }: Props) {
  const { isSaved, toggle } = useSavedItems();
  const saved = isSaved(kind, id);
  const onClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const nowSaved = toggle(kind, id);
    if (nowSaved) {
      xpToast(5);
      toast.success(`Saved ${kind}`);
    } else {
      toast.success(`Removed from saved`);
    }
  };
  return (
    <button
      onClick={onClick}
      aria-label={saved ? "Remove from saved" : "Save"}
      className={cn(
        "inline-flex items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white/95 px-2 py-1 text-[11px] font-bold text-foreground transition hover:border-coral hover:text-coral",
        saved && "border-coral text-coral",
        className,
      )}
    >
      <Bookmark className={cn("h-3.5 w-3.5", saved && "fill-coral text-coral")} />
      {label ?? (saved ? "Saved" : "Save")}
    </button>
  );
}
