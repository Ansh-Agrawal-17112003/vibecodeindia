import { levelFor } from "@/lib/xp";

type Props = {
  xp: number;
  size?: "xs" | "sm" | "md";
  showName?: boolean;
  className?: string;
};

export function LevelBadge({ xp, size = "sm", showName = true, className = "" }: Props) {
  const lvl = levelFor(xp);
  const px =
    size === "xs" ? "px-1.5 py-0.5 text-[10px] gap-1" :
    size === "sm" ? "px-2 py-0.5 text-[11px] gap-1" :
    "px-2.5 py-1 text-xs gap-1.5";
  const isMaster = lvl.name === "Vibe Master";
  return (
    <span
      title={`${lvl.name} · ${xp.toLocaleString()} XP`}
      className={`inline-flex shrink-0 items-center rounded-full border-[1.5px] border-[#0F0F0F] font-extrabold ${px} ${className}`}
      style={{
        background: isMaster
          ? "linear-gradient(90deg,#E8623A,#F5A623,#8B5CF6)"
          : `${lvl.color}22`,
        color: isMaster ? "#0F0F0F" : lvl.color,
        boxShadow: "1px 1px 0 0 #0F0F0F",
      }}
    >
      <span aria-hidden>{lvl.emoji}</span>
      {showName && <span className="tracking-wide">{lvl.name}</span>}
    </span>
  );
}
