import { useEffect, useState } from "react";
import { Target, Loader2, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

type Mission = {
  id: string;
  week_start: string;
  title: string;
  description: string;
  cta_label: string;
  cta_href: string;
  reward_coins: number;
  bonus_first_n: number;
  bonus_coins: number;
};

/**
 * Weekly mission card — shown on /dashboard.
 * Reads latest mission (week_start <= today), lets user claim once.
 */
export function MissionCard() {
  const { user } = useAuth();
  const [mission, setMission] = useState<Mission | null>(null);
  const [completed, setCompleted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);

  useEffect(() => {
    (async () => {
      const today = new Date().toISOString().slice(0, 10);
      const { data } = await supabase
        .from("weekly_missions")
        .select("*")
        .lte("week_start", today)
        .order("week_start", { ascending: false })
        .limit(1)
        .maybeSingle();
      setMission((data as Mission) || null);
      if (data && user) {
        const { data: p } = await supabase
          .from("weekly_mission_participants")
          .select("id")
          .eq("mission_id", data.id)
          .eq("user_id", user.id)
          .maybeSingle();
        setCompleted(!!p);
      }
      setLoading(false);
    })();
  }, [user]);

  if (loading) return null;
  if (!mission) return null;

  const claim = async () => {
    setClaiming(true);
    try {
      const { data, error } = await (supabase.rpc as any)("complete_mission", { _mission_id: mission.id });
      if (error) throw error;
      if (data?.ok) {
        setCompleted(true);
        toast.success(
          data.bonus
            ? `🎯 Bonus unlocked — +${data.coins} VibeCoins!`
            : `🎯 Mission complete — +${data.coins} VibeCoins`,
        );
      } else if (data?.reason === "already_completed") {
        setCompleted(true);
        toast("Already completed this week");
      }
    } catch (e: any) {
      toast.error(e?.message || "Could not complete mission");
    } finally {
      setClaiming(false);
    }
  };

  return (
    <div
      className="mt-6 rounded-xl border-[1.5px] border-[#0F0F0F] bg-gradient-to-br from-coral/10 to-gold/10 p-5"
      style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
    >
      <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-coral">
        <Target className="h-4 w-4" /> This week's mission
      </div>
      <h3 className="mt-2 font-display text-xl font-extrabold">{mission.title}</h3>
      <p className="mt-1 text-sm text-foreground/80">{mission.description}</p>
      <div className="mt-2 text-xs font-bold text-muted-foreground">
        Reward: <span className="text-coral">+{mission.reward_coins} 🪙</span>
        {" · "}First {mission.bonus_first_n} get bonus <span className="text-coral">+{mission.bonus_coins}</span>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <a href={mission.cta_href} className="btn-coral h-9 text-xs">{mission.cta_label}</a>
        {completed ? (
          <span className="inline-flex items-center gap-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1.5 text-xs font-bold">
            <CheckCircle2 className="h-3.5 w-3.5 text-green-600" /> Completed
          </span>
        ) : (
          <button
            onClick={claim}
            disabled={claiming}
            className="inline-flex h-9 items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 text-xs font-bold disabled:opacity-60"
            style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
          >
            {claiming ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "I've done it"}
          </button>
        )}
      </div>
    </div>
  );
}
