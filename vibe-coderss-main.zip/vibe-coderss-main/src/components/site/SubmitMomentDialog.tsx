import { useState } from "react";
import { X } from "lucide-react";
import { submitMoment, KIND_LABEL, type RvmKind } from "@/lib/rvm-api";
import { toast } from "sonner";

const KINDS: RvmKind[] = [
  "hire",
  "freelance",
  "collab",
  "feature",
  "prompt_saved_time",
  "cashout",
  "followers_boost",
  "other",
];

export function SubmitMomentDialog({
  open,
  onClose,
  userId,
  onSubmitted,
}: {
  open: boolean;
  onClose: () => void;
  userId: string;
  onSubmitted?: () => void;
}) {
  const [kind, setKind] = useState<RvmKind>("hire");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [hours, setHours] = useState("");
  const [evidence, setEvidence] = useState("");
  const [saving, setSaving] = useState(false);

  if (!open) return null;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setSaving(true);
    try {
      await submitMoment({
        user_id: userId,
        kind,
        title: title.trim(),
        description: description.trim() || undefined,
        amount_inr: amount ? Number(amount) : undefined,
        hours_saved: hours ? Number(hours) : undefined,
        evidence_url: evidence.trim() || undefined,
      });
      toast.success("Submitted — an admin will review it shortly.");
      setTitle("");
      setDescription("");
      setAmount("");
      setHours("");
      setEvidence("");
      onSubmitted?.();
      onClose();
    } catch (err: any) {
      toast.error(err?.message ?? "Failed to submit.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <form
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg rounded-2xl border-[1.5px] border-foreground bg-card p-5 shadow-[4px_4px_0_0_#0F0F0F]"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-extrabold">Share your win</h2>
          <button type="button" onClick={onClose} className="rounded p-1 hover:bg-surface">
            <X className="h-4 w-4" />
          </button>
        </div>

        <label className="mb-1 block text-xs font-extrabold uppercase tracking-wider">Kind</label>
        <select
          value={kind}
          onChange={(e) => setKind(e.target.value as RvmKind)}
          className="mb-3 w-full rounded-md border-[1.5px] border-foreground bg-white px-3 py-2 text-sm font-bold"
        >
          {KINDS.map((k) => (
            <option key={k} value={k}>
              {KIND_LABEL[k]}
            </option>
          ))}
        </select>

        <label className="mb-1 block text-xs font-extrabold uppercase tracking-wider">Title *</label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          maxLength={120}
          placeholder="e.g. Landed a ₹40k/mo React gig via VibeCode"
          className="mb-3 w-full rounded-md border-[1.5px] border-foreground bg-white px-3 py-2 text-sm"
        />

        <label className="mb-1 block text-xs font-extrabold uppercase tracking-wider">Story</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          maxLength={600}
          placeholder="What happened? Who was involved?"
          className="mb-3 w-full rounded-md border-[1.5px] border-foreground bg-white px-3 py-2 text-sm"
        />

        <div className="mb-3 grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1 block text-xs font-extrabold uppercase tracking-wider">
              Amount (₹)
            </label>
            <input
              value={amount}
              type="number"
              min="0"
              onChange={(e) => setAmount(e.target.value)}
              className="w-full rounded-md border-[1.5px] border-foreground bg-white px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-extrabold uppercase tracking-wider">
              Hours saved
            </label>
            <input
              value={hours}
              type="number"
              min="0"
              onChange={(e) => setHours(e.target.value)}
              className="w-full rounded-md border-[1.5px] border-foreground bg-white px-3 py-2 text-sm"
            />
          </div>
        </div>

        <label className="mb-1 block text-xs font-extrabold uppercase tracking-wider">
          Evidence link (optional)
        </label>
        <input
          value={evidence}
          onChange={(e) => setEvidence(e.target.value)}
          placeholder="Tweet, screenshot, invoice, LinkedIn post…"
          className="mb-4 w-full rounded-md border-[1.5px] border-foreground bg-white px-3 py-2 text-sm"
        />

        <div className="flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-md border-[1.5px] border-foreground bg-white px-4 py-2 text-sm font-bold"
          >
            Cancel
          </button>
          <button type="submit" disabled={saving} className="btn-coral h-10">
            {saving ? "Submitting…" : "Submit"}
          </button>
        </div>
      </form>
    </div>
  );
}
