import { useState } from "react";
import { X, Copy, MessageCircle, Twitter, Mail, Link as LinkIcon, Check } from "lucide-react";
import { toast } from "sonner";

type Props = {
  open: boolean;
  onClose: () => void;
  slug: string;
  name: string;
};

export function InviteModal({ open, onClose, slug, name }: Props) {
  const [copied, setCopied] = useState(false);
  if (!open) return null;
  const url = typeof window !== "undefined" ? `${window.location.origin}/communities/${slug}?invite=1` : "";
  const text = `Join me in the ${name} community on VibeCode 🚀`;

  const copy = () => {
    navigator.clipboard?.writeText(url).then(() => {
      setCopied(true); toast.success("Invite link copied");
      setTimeout(() => setCopied(false), 1500);
    });
  };

  const options = [
    { label: "Copy link", icon: copied ? Check : LinkIcon, onClick: copy, bg: "#F5A623" },
    { label: "WhatsApp", icon: MessageCircle, href: `https://wa.me/?text=${encodeURIComponent(`${text} ${url}`)}`, bg: "#25D366" },
    { label: "Twitter / X", icon: Twitter, href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, bg: "#0F0F0F" },
    { label: "Email", icon: Mail, href: `mailto:?subject=${encodeURIComponent(`Join ${name} on VibeCode`)}&body=${encodeURIComponent(`${text}\n\n${url}`)}`, bg: "#E8623A" },
  ] as const;

  return (
    <div className="fixed inset-0 z-[100] grid place-items-center overflow-y-auto bg-black/60 p-4" onClick={onClose}>
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-5 sm:p-6 pr-12" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute right-3 top-3 z-10 grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white" aria-label="Close"><X className="h-4 w-4" /></button>
        <h3 className="pr-2 font-display text-lg sm:text-xl font-extrabold break-words">Invite friends to {name}</h3>
        <p className="mt-1 text-sm text-muted-foreground">Pick a channel or copy the invite link.</p>

        <div className="mt-5 flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-white p-2">
          <span className="min-w-0 flex-1 truncate px-2 text-xs font-mono">{url}</span>
          <button onClick={copy} className="shrink-0 flex items-center gap-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1.5 text-xs font-bold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <Copy className="h-3 w-3" /> {copied ? "Copied" : "Copy"}
          </button>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2">
          {options.map((o) => {
            const Icon = o.icon;
            const cls = "flex items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] px-3 py-3 text-sm font-bold text-white";
            const style = { background: o.bg, boxShadow: "2px 2px 0 0 #0F0F0F" };
            return "href" in o ? (
              <a key={o.label} href={o.href} target="_blank" rel="noopener noreferrer" className={cls} style={style}>
                <Icon className="h-4 w-4" /> {o.label}
              </a>
            ) : (
              <button key={o.label} onClick={o.onClick} className={cls} style={style}>
                <Icon className="h-4 w-4" /> {o.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
