import { useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronRight, Plus, Minus, ArrowRight } from "lucide-react";
import { Shell } from "./Shell";

export type TocItem = { id: string; label: string };

export function NotionPageShell({
  eyebrow,
  breadcrumb,
  title,
  intro,
  toc = [],
  children,
  cta,
}: {
  eyebrow?: string;
  breadcrumb?: { label: string; to: string }[];
  title: ReactNode;
  intro?: ReactNode;
  toc?: TocItem[];
  children: ReactNode;
  cta?: { label: string; to: string; sub?: string };
}) {
  return (
    <Shell>
      <div className="bg-surface">
        <div className="container-page pt-10 md:pt-14">
          {breadcrumb && (
            <nav className="mb-6 flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
              <Link to="/" className="hover:text-foreground">Home</Link>
              {breadcrumb.map((b, i) => (
                <span key={i} className="flex items-center gap-1">
                  <ChevronRight className="h-3 w-3" />
                  {i === breadcrumb.length - 1 ? (
                    <span className="text-foreground">{b.label}</span>
                  ) : (
                    <Link to={b.to} className="hover:text-foreground">{b.label}</Link>
                  )}
                </span>
              ))}
            </nav>
          )}

          <header className="max-w-3xl">
            {eyebrow && (
              <span className="pill-badge mb-4 bg-white text-foreground">
                {eyebrow}
              </span>
            )}
            <h1 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-6xl">
              {title}
            </h1>
            {intro && (
              <p className="mt-5 text-lg leading-relaxed text-muted-foreground md:text-xl">
                {intro}
              </p>
            )}
          </header>
        </div>

        <div className="container-page grid gap-10 py-12 md:py-16 lg:grid-cols-[220px_1fr]">
          {toc.length > 0 ? (
            <aside className="hidden lg:block">
              <div className="sticky top-24">
                <div className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">On this page</div>
                <ul className="space-y-2 border-l border-[#0F0F0F]/15 pl-4 text-sm">
                  {toc.map((t) => (
                    <li key={t.id}>
                      <a href={`#${t.id}`} className="text-muted-foreground transition hover:text-coral">
                        {t.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </aside>
          ) : (
            <div className="hidden lg:block" />
          )}

          <div className="min-w-0 space-y-16">
            {children}
            {cta && (
              <NotionCTA label={cta.label} to={cta.to} sub={cta.sub} />
            )}
          </div>
        </div>
      </div>
    </Shell>
  );
}

export function NotionSection({
  id,
  eyebrow,
  title,
  children,
}: {
  id?: string;
  eyebrow?: string;
  title: ReactNode;
  children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24">
      {eyebrow && (
        <div className="mb-2 text-xs font-bold uppercase tracking-wider text-coral">{eyebrow}</div>
      )}
      <h2 className="font-display text-3xl font-extrabold leading-tight tracking-tight md:text-4xl">
        {title}
      </h2>
      <div className="mt-5 space-y-5 text-base leading-relaxed text-foreground/85">
        {children}
      </div>
    </section>
  );
}

export function NotionCallout({
  emoji = "💡",
  children,
  tone = "cream",
}: {
  emoji?: string;
  children: ReactNode;
  tone?: "cream" | "coral" | "gold" | "mint";
}) {
  const bg =
    tone === "coral"
      ? "bg-coral/10"
      : tone === "gold"
      ? "bg-gold/20"
      : tone === "mint"
      ? "bg-emerald-500/10"
      : "bg-cream";
  return (
    <div className={`flex gap-3 rounded-xl border border-[#0F0F0F]/15 p-4 ${bg}`}>
      <div className="text-xl leading-none">{emoji}</div>
      <div className="text-sm leading-relaxed text-foreground/85">{children}</div>
    </div>
  );
}

export function NotionFeatureGrid({
  items,
  columns = 2,
}: {
  items: { icon?: ReactNode; title: string; description: string }[];
  columns?: 2 | 3;
}) {
  const cls = columns === 3 ? "md:grid-cols-3" : "md:grid-cols-2";
  return (
    <div className={`grid gap-4 ${cls}`}>
      {items.map((it, i) => (
        <div
          key={i}
          className="group rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-5 transition hover:-translate-y-0.5 hover:shadow-[4px_4px_0_0_#0F0F0F]"
        >
          {it.icon && (
            <div className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[#0F0F0F]/15 bg-cream text-coral">
              {it.icon}
            </div>
          )}
          <div className="font-display text-lg font-bold">{it.title}</div>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{it.description}</p>
        </div>
      ))}
    </div>
  );
}

export function NotionToggle({ q, a }: { q: string; a: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-[#0F0F0F]/15 py-3">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-4 text-left"
      >
        <span className="font-medium text-foreground">{q}</span>
        {open ? <Minus className="h-4 w-4 shrink-0" /> : <Plus className="h-4 w-4 shrink-0" />}
      </button>
      {open && <div className="mt-2 text-sm leading-relaxed text-muted-foreground">{a}</div>}
    </div>
  );
}

export function NotionQuote({ children, by }: { children: ReactNode; by?: string }) {
  return (
    <blockquote className="border-l-4 border-coral pl-5">
      <p className="font-display text-xl leading-snug text-foreground md:text-2xl">"{children}"</p>
      {by && <footer className="mt-2 text-sm text-muted-foreground">— {by}</footer>}
    </blockquote>
  );
}

export function NotionCTA({ label, to, sub }: { label: string; to: string; sub?: string }) {
  return (
    <div className="rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-8 text-center shadow-[6px_6px_0_0_#0F0F0F] md:p-10">
      <h3 className="font-display text-2xl font-extrabold md:text-3xl">Ready to ship?</h3>
      {sub && <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground">{sub}</p>}
      <Link
        to={to}
        className="mt-5 inline-flex items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-coral px-5 py-3 text-sm font-bold uppercase text-white transition hover:shadow-[4px_4px_0_0_#0F0F0F]"
      >
        {label} <ArrowRight className="h-4 w-4" />
      </Link>
    </div>
  );
}

export function NotionList({ items }: { items: ReactNode[] }) {
  return (
    <ul className="space-y-2">
      {items.map((it, i) => (
        <li key={i} className="flex gap-3">
          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-coral" />
          <span className="text-sm leading-relaxed text-foreground/85">{it}</span>
        </li>
      ))}
    </ul>
  );
}
