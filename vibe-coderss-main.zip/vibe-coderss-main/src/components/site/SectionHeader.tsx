import type { ReactNode } from "react";

export function SectionHeader({
  label,
  title,
  subtitle,
  align = "center",
}: {
  label?: string;
  title: ReactNode;
  subtitle?: string;
  align?: "center" | "left";
}) {
  const a = align === "center" ? "text-center mx-auto items-center" : "text-left items-start";
  return (
    <div className={`flex flex-col ${a} max-w-3xl ${align === "center" ? "mx-auto" : ""}`}>
      {label && (
        <span className="pill-badge mb-5 bg-coral text-white">
          {label}
        </span>
      )}
      <h2 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-foreground md:text-5xl">
        {title}
      </h2>
      {subtitle && <p className="mt-4 max-w-xl text-base text-muted-foreground md:text-lg">{subtitle}</p>}
    </div>
  );
}

export function CoralWord({ children }: { children: ReactNode }) {
  return <span className="text-coral">{children}</span>;
}
