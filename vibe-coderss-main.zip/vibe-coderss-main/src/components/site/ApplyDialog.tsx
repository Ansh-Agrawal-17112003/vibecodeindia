import { useState } from "react";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export function ApplyDialog({ jobId, onClose }: { jobId: string; onClose: () => void }) {
  const { user } = useAuth();
  const [coverNote, setCoverNote] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);

  if (!user) {
    return (
      <Overlay onClose={onClose}>
        <h3 className="font-display text-xl font-extrabold">Sign in to apply</h3>
        <p className="mt-2 text-sm text-muted-foreground">Create a free VibeCode account to apply to this job.</p>
        <Link to="/auth" className="btn-coral mt-4 h-11 w-full">Sign in / Sign up →</Link>
      </Overlay>
    );
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (!user) throw new Error("Not signed in");
      let resumeUrl: string | null = null;
      if (file) {
        if (file.size > 10 * 1024 * 1024) throw new Error("Resume must be < 10MB");
        const path = `${user.id}/${Date.now()}-${file.name.replace(/[^a-z0-9.\-_]/gi, "_")}`;
        const { error: upErr } = await supabase.storage.from("resumes").upload(path, file);
        if (upErr) throw upErr;
        resumeUrl = path;
      }
      const { error } = await supabase.from("job_applications").insert({
        job_id: jobId,
        applicant_id: user.id,
        cover_note: coverNote,
        resume_url: resumeUrl,
      });
      if (error) throw error;
      toast.success("Application submitted!");
      onClose();
    } catch (e: any) {
      toast.error(e?.message ?? "Failed to apply");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Overlay onClose={onClose}>
      <h3 className="font-display text-xl font-extrabold">Apply for this job</h3>
      <form onSubmit={submit} className="mt-4 space-y-3">
        <textarea value={coverNote} onChange={(e) => setCoverNote(e.target.value)} rows={5} placeholder="Cover note — why are you a great fit?" className="w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3 text-sm" />
        <div>
          <label className="text-xs font-bold">Resume (PDF, max 10MB)</label>
          <input type="file" accept=".pdf,.doc,.docx" onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="mt-1 block w-full text-sm" />
        </div>
        <button disabled={busy} className="btn-coral h-11 w-full">{busy ? "Submitting…" : "Submit application →"}</button>
      </form>
    </Overlay>
  );
}

function Overlay({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-6" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }} onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}
