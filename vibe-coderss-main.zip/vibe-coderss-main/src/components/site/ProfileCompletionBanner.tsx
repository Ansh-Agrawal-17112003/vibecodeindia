import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { AlertCircle, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

/**
 * Enforces profile completion for every signed-in user.
 *
 * - If the user has never onboarded (no `onboarded_at`, or missing username/bio/location),
 *   we HARD-REDIRECT them to `/onboarding` — profile completion is compulsory
 *   so no empty profiles ever go live on `/u/:username`.
 * - If they've onboarded but their profile is only partially filled (missing
 *   avatar, socials, etc.), we show a dismissible banner nudging them to
 *   finish.
 *
 * Public/auth pages are excluded so users can still sign up and read landing
 * content before authenticating.
 */
const EXCLUDED_PATHS = new Set([
  "/onboarding", "/auth", "/login", "/signup", "/reset-password", "/",
  "/landing", "/pricing", "/blog",
]);

function isExcluded(pathname: string) {
  if (EXCLUDED_PATHS.has(pathname)) return true;
  return (
    pathname.startsWith("/_authenticated/onboarding") ||
    pathname.startsWith("/blog/") ||
    pathname.startsWith("/api/")
  );
}

export function ProfileCompletionBanner() {
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [state, setState] = useState<null | { missing: string[]; needsOnboarding: boolean }>(null);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    let alive = true;
    if (!user) { setState(null); return; }
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("username, bio, avatar_url, location, onboarded_at")
        .eq("id", user.id)
        .maybeSingle();
      if (!alive) return;
      if (!data) { setState(null); return; }
      const missing: string[] = [];
      const needsOnboarding = !data.onboarded_at || !data.username?.trim() || !data.bio?.trim() || !data.location?.trim();
      if (!data.username?.trim()) missing.push("username");
      if (!data.bio?.trim()) missing.push("bio");
      if (!data.location?.trim()) missing.push("location");
      if (!data.avatar_url?.trim()) missing.push("avatar");
      setState(missing.length || needsOnboarding ? { missing, needsOnboarding } : null);
    })();
    return () => { alive = false; };
  }, [user]);

  // Hard-redirect users who never completed onboarding.
  useEffect(() => {
    if (!user || !state?.needsOnboarding) return;
    if (isExcluded(location.pathname)) return;
    navigate({ to: "/onboarding" });
  }, [user, state?.needsOnboarding, location.pathname, navigate]);

  useEffect(() => {
    try { setHidden(sessionStorage.getItem("vc.profileBanner.hidden") === "1"); } catch {}
  }, []);

  if (!user || !state || hidden) return null;
  // Users being redirected to onboarding don't need the banner too.
  if (state.needsOnboarding && !isExcluded(location.pathname)) return null;
  // On the onboarding page itself, no banner.
  if (location.pathname.includes("/onboarding")) return null;

  return (
    <div className="border-b-[1.5px] border-[#0F0F0F] bg-coral/10">
      <div className="container-page flex items-center gap-2 py-2 text-xs sm:text-sm">
        <AlertCircle className="h-4 w-4 shrink-0 text-coral" />
        <div className="min-w-0 flex-1">
          <span className="font-bold">Finish your profile</span>
          <span className="hidden text-muted-foreground sm:inline"> — add {state.missing.join(", ")} so people can discover and hire you.</span>
        </div>
        <Link to="/onboarding" className="rounded-full bg-coral px-3 py-1 text-[11px] font-bold text-white hover:opacity-90 sm:text-xs">Finish</Link>
        <button
          aria-label="Dismiss"
          onClick={() => { try { sessionStorage.setItem("vc.profileBanner.hidden", "1"); } catch {} setHidden(true); }}
          className="grid h-6 w-6 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white hover:bg-cream"
        >
          <X className="h-3 w-3" />
        </button>
      </div>
    </div>
  );
}
