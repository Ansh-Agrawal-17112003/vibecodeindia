import { Link, useNavigate } from "@tanstack/react-router";
import { Search, MapPin } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { builders, projects, services, prompts, workflows, communities, jobs, tools, templates } from "@/lib/mock-data";
import { searchLocations } from "@/lib/india-locations";
import { DiaTextReveal } from "@/components/ui/dia-text-reveal";
import { PersonalizedBanner } from "@/components/site/PersonalizedBanner";


const POPULAR = ["Lovable", "Cursor", "SaaS", "AI Agents", "Automation", "Web Apps", "No Code", "Open Source"];

// Build a deduped pool of searchable terms once.
const SEARCH_POOL: string[] = (() => {
  const set = new Set<string>();
  const push = (s?: string) => { if (s && s.length < 60) set.add(s); };
  builders.forEach((b) => { push(b.name); push(b.title); b.skills.forEach(push); b.tools.forEach(push); });
  projects.forEach((p) => { push(p.title); push(p.industry); p.tools.forEach(push); });
  services.forEach((s) => { push(s.title); push(s.category); s.tags.forEach(push); });
  prompts.forEach((p) => { push(p.title); push(p.category); push(p.model); });
  workflows.forEach((w) => { push(w.title); push(w.category); w.tools.forEach(push); });
  communities.forEach((c) => push(c.name));
  jobs.forEach((j) => { push(j.title); push(j.company); push(j.industry); j.tools.forEach(push); });
  tools.forEach((t) => { push(t.name); push(t.category); });
  templates.forEach((t) => { push(t.title); push(t.category); push(t.framework); });
  POPULAR.forEach(push);
  return Array.from(set);
})();

function suggestQueries(q: string, limit = 8): string[] {
  const term = q.trim().toLowerCase();
  if (!term) return POPULAR.slice(0, limit);
  const starts: string[] = [];
  const contains: string[] = [];
  for (const s of SEARCH_POOL) {
    const l = s.toLowerCase();
    if (l === term) continue;
    if (l.startsWith(term)) starts.push(s);
    else if (l.includes(term)) contains.push(s);
    if (starts.length >= limit) break;
  }
  return [...starts, ...contains].slice(0, limit);
}

function Suggestions({
  items,
  active,
  onPick,
  icon,
}: {
  items: string[];
  active: number;
  onPick: (v: string) => void;
  icon: React.ReactNode;
}) {
  if (!items.length) return null;
  return (
    <ul
      role="listbox"
      className="absolute left-0 right-0 top-full z-50 mt-1 max-h-72 overflow-auto rounded-md border-[1.5px] border-[#0F0F0F] bg-card py-1 text-left"
      style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
    >
      {items.map((s, i) => (
        <li
          key={s}
          role="option"
          aria-selected={i === active}
          onMouseDown={(e) => { e.preventDefault(); onPick(s); }}
          className={`flex cursor-pointer items-center gap-2 px-3 py-2 text-sm ${i === active ? "bg-coral text-white" : "hover:bg-background"}`}
        >
          <span className={i === active ? "text-white" : "text-muted-foreground"}>{icon}</span>
          <span className="truncate">{s}</span>
        </li>
      ))}
    </ul>
  );
}

const TYPE_WORDS = ["AI Builders", "Vibecoders", "Creators", "Founders", "Hackers"];
const PLACEHOLDERS = [
  "Search builders, projects, tools, prompts...",
  "Try 'Lovable SaaS templates'",
  "Find AI agents for automation",
  "Discover top vibecoders near you",
  "Browse open source AI projects",
];

function useTypewriter(words: string[], { type = 90, pause = 1400, erase = 45 } = {}) {
  const [text, setText] = useState("");
  const [i, setI] = useState(0);
  const [del, setDel] = useState(false);
  useEffect(() => {
    const word = words[i % words.length];
    if (!del && text === word) {
      const t = setTimeout(() => setDel(true), pause);
      return () => clearTimeout(t);
    }
    if (del && text === "") {
      setDel(false);
      setI((n) => (n + 1) % words.length);
      return;
    }
    const t = setTimeout(
      () => setText(del ? word.slice(0, text.length - 1) : word.slice(0, text.length + 1)),
      del ? erase : type,
    );
    return () => clearTimeout(t);
  }, [text, del, i, words, type, pause, erase]);
  return text;
}

export function Hero() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [loc, setLoc] = useState("");
  const typedHeading = useTypewriter(TYPE_WORDS);
  const typedPlaceholder = useTypewriter(PLACEHOLDERS, { type: 45, erase: 20, pause: 1800 });
  const [qOpen, setQOpen] = useState(false);
  const [locOpen, setLocOpen] = useState(false);
  const [qIdx, setQIdx] = useState(-1);
  const [locIdx, setLocIdx] = useState(-1);
  const qWrap = useRef<HTMLDivElement>(null);
  const locWrap = useRef<HTMLDivElement>(null);

  const qSuggestions = useMemo(() => suggestQueries(q), [q]);
  const locSuggestions = useMemo(() => searchLocations(loc), [loc]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (qWrap.current && !qWrap.current.contains(e.target as Node)) setQOpen(false);
      if (locWrap.current && !locWrap.current.contains(e.target as Node)) setLocOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const go = (nextQ?: string, nextLoc?: string) => {
    const finalQ = (nextQ ?? q).trim();
    const finalLoc = (nextLoc ?? loc).trim();
    navigate({ to: "/search", search: { q: finalQ || undefined, location: finalLoc || undefined } });
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    go();
  };

  const handleKey = (
    e: React.KeyboardEvent<HTMLInputElement>,
    list: string[],
    idx: number,
    setIdx: (n: number) => void,
    setOpen: (b: boolean) => void,
    setValue: (v: string) => void,
    onSelect: (v: string) => void,
  ) => {
    if (e.key === "ArrowDown") { e.preventDefault(); setOpen(true); setIdx(Math.min(idx + 1, list.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setIdx(Math.max(idx - 1, -1)); }
    else if (e.key === "Enter") {
      if (idx >= 0 && list[idx]) {
        e.preventDefault();
        setValue(list[idx]);
        setOpen(false);
        setIdx(-1);
        onSelect(list[idx]);
      }
    } else if (e.key === "Escape") { setOpen(false); setIdx(-1); }
  };

  return (
    <section className="gradient-mesh relative overflow-hidden border-b-[1.5px] border-[#0F0F0F]">
      {/* paper texture */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.05] mix-blend-multiply"
        style={{
          backgroundImage:
            "radial-gradient(#0F0F0F 1px, transparent 1px), radial-gradient(#0F0F0F 1px, transparent 1px)",
          backgroundSize: "22px 22px, 22px 22px",
          backgroundPosition: "0 0, 11px 11px",
        }}
      />
      {/* floating geometric accents — hugged around the centered headline */}
      <div aria-hidden className="pointer-events-none absolute left-1/2 top-36 hidden h-12 w-12 -translate-x-[560px] rotate-12 rounded-md border-[1.5px] border-[#0F0F0F] bg-gold md:block" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }} />
      <div aria-hidden className="pointer-events-none absolute left-1/2 top-52 hidden h-9 w-9 translate-x-[520px] -rotate-6 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral md:block" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }} />
      <div aria-hidden className="pointer-events-none absolute left-1/2 top-[360px] hidden -translate-x-[580px] lg:block">
        <svg width="72" height="40" viewBox="0 0 72 40" fill="none">
          <path d="M2 30 Q 20 2, 40 20 T 70 10" stroke="#0F0F0F" strokeWidth="2" strokeLinecap="round" fill="none" />
          <path d="M60 6 L70 10 L64 18" stroke="#0F0F0F" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        </svg>
      </div>
      <div aria-hidden className="pointer-events-none absolute left-1/2 top-[380px] hidden translate-x-[520px] lg:block">
        <svg width="46" height="46" viewBox="0 0 50 50" fill="none">
          <g stroke="#E8623A" strokeWidth="2.2" strokeLinecap="round">
            <line x1="25" y1="4" x2="25" y2="16" />
            <line x1="25" y1="34" x2="25" y2="46" />
            <line x1="4" y1="25" x2="16" y2="25" />
            <line x1="34" y1="25" x2="46" y2="25" />
            <line x1="10" y1="10" x2="18" y2="18" />
            <line x1="32" y1="32" x2="40" y2="40" />
          </g>
        </svg>
      </div>



      <div className="container-page relative flex flex-col items-center py-8 text-center md:py-24 lg:py-32">
        <PersonalizedBanner />
        <span
          className="inline-flex items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-gold px-3 py-1 text-[10px] font-extrabold uppercase tracking-wider text-[#0F0F0F] sm:py-1.5 sm:text-[11px]"
          style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
        >
          ✦ The home of every AI builder
        </span>

        <h1 className="mt-4 font-display text-[44px] font-extrabold uppercase leading-[0.95] tracking-tight text-foreground sm:mt-6 sm:text-6xl md:text-7xl lg:text-[96px]">
          India's Largest
          <br />
          Platform Of
          <br />
          <DiaTextReveal
            repeat
            repeatDelay={1.4}
            duration={0.6}
            stagger={0.05}
            text={["AI Builders", "Vibecoders", "Shippers", "Founders", "Hackers"]}
            colors={["#E8623A", "#F5A623", "#0F0F0F", "#E8623A"]}
          />
          
        </h1>

        <p className="mt-3 max-w-2xl text-sm text-muted-foreground sm:mt-6 sm:text-base md:text-lg">
          Showcase projects, build your reputation, offer services, find opportunities, and collaborate with builders across India.
        </p>


        <form
          onSubmit={submit}
          className="relative mt-5 flex w-full max-w-3xl flex-col gap-2 rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-2 sm:mt-10 sm:flex-row sm:items-center"
          style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}
        >
          {/* Query */}
          <div ref={qWrap} className="relative flex flex-1 items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-background px-4 py-3 text-left">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => { setQ(e.target.value); setQOpen(true); setQIdx(-1); }}
              onFocus={() => setQOpen(true)}
              onKeyDown={(e) => handleKey(e, qSuggestions, qIdx, setQIdx, setQOpen, setQ, (v) => go(v))}
              placeholder={typedPlaceholder || "Search builders, projects, tools, prompts..."}
              autoComplete="off"
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
            {qOpen && (
              <Suggestions
                items={qSuggestions}
                active={qIdx}
                onPick={(v) => { setQ(v); setQOpen(false); setQIdx(-1); go(v); }}
                icon={<Search className="h-3.5 w-3.5" />}
              />
            )}
          </div>

          {/* Location */}
          <div ref={locWrap} className="relative flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-background px-4 py-3 text-left sm:w-56">
            <MapPin className="h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              value={loc}
              onChange={(e) => { setLoc(e.target.value); setLocOpen(true); setLocIdx(-1); }}
              onFocus={() => setLocOpen(true)}
              onKeyDown={(e) => handleKey(e, locSuggestions, locIdx, setLocIdx, setLocOpen, setLoc, (v) => go(undefined, v))}
              placeholder="Location (any city in India)"
              autoComplete="off"
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
            {locOpen && (
              <Suggestions
                items={locSuggestions}
                active={locIdx}
                onPick={(v) => { setLoc(v); setLocOpen(false); setLocIdx(-1); }}
                icon={<MapPin className="h-3.5 w-3.5" />}
              />
            )}
          </div>

          <button
            type="submit"
            data-confetti
            className="group inline-flex items-center justify-center gap-2 rounded-xl border-[1.5px] border-[#0F0F0F] bg-coral px-8 py-3.5 text-sm font-extrabold uppercase tracking-wide text-white transition-all duration-150 hover:-translate-x-0.5 hover:-translate-y-0.5 hover:bg-coral-hover active:translate-x-0 active:translate-y-0"
            style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}
          >
            <Search className="h-4 w-4" />
            Search
          </button>
        </form>

        <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
          <span className="text-xs font-bold text-foreground">Popular:</span>
          {POPULAR.map((p) => (
            <Link
              key={p}
              to="/search"
              search={{ q: p }}
              className="rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-2.5 py-1 text-xs font-semibold text-foreground transition hover:bg-coral hover:text-white"
            >
              {p}
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
