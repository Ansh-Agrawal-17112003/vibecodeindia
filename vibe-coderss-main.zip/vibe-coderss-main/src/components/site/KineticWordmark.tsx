import { KineticText } from "@/components/ui/kinetic-text";

/**
 * Big kinetic "vibecoder" wordmark section — used at the bottom of
 * marketing pages (below the footer) to echo the landing page.
 */
export function KineticWordmark() {
  return (
    <section
      className="relative overflow-hidden py-20 md:py-28"
      style={{ background: "#0F0F0F" }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(700px circle at 50% 60%, rgba(232,98,58,0.14), transparent 65%)",
        }}
      />
      <div className="relative flex items-center justify-center">
        <KineticText
          text="vibecoder"
          splitAt={4}
          className="text-[22vw] tracking-[-0.06em] md:text-[16rem]"
        />
      </div>
      <div
        className="relative mx-auto mt-6 text-center font-mono text-[11px] uppercase tracking-[0.3em]"
        style={{ color: "#5a5a5a" }}
      >
        Built in India · For builders, by builders
      </div>
    </section>
  );
}
