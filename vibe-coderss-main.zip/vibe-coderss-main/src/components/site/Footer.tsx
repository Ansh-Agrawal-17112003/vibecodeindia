import { Link, useLocation } from "@tanstack/react-router";
import { useState } from "react";
import { VibeCodeMark } from "./Logo";
import { BrandTile } from "./ToolLogo";
import { ReportBugModal } from "./ReportBugModal";

type FLink = { label: string; to?: string; slug?: string; href?: string; action?: "report-bug" };

const PLATFORM: FLink[] = [
  { label: "Explore Builders", to: "/explore" },
  { label: "Find AI Jobs", to: "/jobs" },
  { label: "Hire Services", to: "/services" },
  { label: "Communities", to: "/communities" },
  { label: "Leaderboard", to: "/leaderboard" },
  { label: "Real Wins", to: "/wins" },
];

const LIBRARY: FLink[] = [
  { label: "Prompts Library", to: "/prompts" },
  { label: "n8n Workflows", to: "/workflows" },
  { label: "AI Tools Directory", to: "/tools" },
  { label: "Templates", to: "/templates" },
  { label: "Tutorials", slug: "tutorials" },
  { label: "Blog", slug: "blog" },
];

const COMPANY: FLink[] = [
  { label: "About", slug: "about" },
  { label: "Manifesto", slug: "manifesto" },
  { label: "Careers", to: "/jobs" },
  { label: "Press Kit", slug: "press" },
  { label: "Contact", href: "mailto:hello@vibecode.in" },
];

const RESOURCES: FLink[] = [
  { label: "Help Center", slug: "help" },
  { label: "Builder Guide", slug: "guide" },
  { label: "API Docs", slug: "api" },
  { label: "Status", slug: "status" },
  { label: "Changelog", slug: "changelog" },
  { label: "Report Bug", action: "report-bug" },
];

const LEGAL: FLink[] = [
  { label: "Privacy", to: "/privacy-policy" },
  { label: "Terms", to: "/terms" },
  { label: "Code of Conduct", slug: "coc" },
  { label: "Cookies", slug: "cookies" },
  { label: "DPA", slug: "dpa" },
];

type SocialLink = { name: string; href: string; path: string };
// Inline simple-icons paths (viewBox 0 0 24 24) — no external CDN dependency.
const SOCIAL: SocialLink[] = [
  {
    name: "Twitter",
    href: "https://twitter.com/joinvibecode",
    path: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z",
  },
  {
    name: "LinkedIn",
    href: "https://www.linkedin.com/company/joinvibecode",
    path: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.063 2.063 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z",
  },
  {
    name: "YouTube",
    href: "https://youtube.com/@joinvibecode",
    path: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z",
  },
  {
    name: "Instagram",
    href: "https://instagram.com/joinvibecode",
    path: "M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z",
  },
  {
    name: "Discord",
    href: "https://discord.gg/joinvibecode",
    path: "M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z",
  },
];

const INTEGRATIONS: { name: string; src: string }[] = [
  { name: "GitHub", src: "/brands/github.svg" },
  { name: "Stripe", src: "/brands/stripe.svg" },
  { name: "Notion", src: "/brands/notion.svg" },
  { name: "Figma", src: "/brands/figma.svg" },
  { name: "Linear", src: "/brands/linear.svg" },
  { name: "Supabase", src: "/brands/supabase.svg" },
  { name: "Vercel", src: "/brands/vercel.svg" },
  { name: "n8n", src: "/brands/n8n.svg" },
  { name: "Zapier", src: "/brands/zapier.svg" },
  { name: "Discord", src: "/brands/discord.svg" },
  { name: "Anthropic", src: "/brands/anthropic.svg" },
  { name: "OpenAI", src: "/brands/openai.svg" },
  { name: "Cursor", src: "/brands/cursor.svg" },
  { name: "Replit", src: "/brands/replit.svg" },
  { name: "Make", src: "/brands/make.svg" },
  { name: "ClickUp", src: "/brands/clickup.svg" },
];

function LinkItem({ l, onReportBug, muted = false }: { l: FLink; onReportBug: () => void; muted?: boolean }) {
  const base = muted
    ? "text-xs text-muted-foreground transition hover:text-foreground"
    : "text-sm font-medium text-foreground/75 transition hover:text-coral hover:underline underline-offset-4 decoration-coral/60";
  if (l.action === "report-bug") {
    return <button type="button" onClick={onReportBug} className={`text-left ${base}`}>{l.label}</button>;
  }
  if (l.to) return <Link to={l.to} className={base}>{l.label}</Link>;
  if (l.slug) return <Link to="/p/$slug" params={{ slug: l.slug }} className={base}>{l.label}</Link>;
  return <a href={l.href} className={base}>{l.label}</a>;
}

function FooterCol({ title, links, exploreTo, onReportBug }: { title: string; links: FLink[]; exploreTo?: string; onReportBug: () => void }) {
  return (
    <div>
      <div className="mb-5 font-display text-xs font-bold text-foreground">{title}</div>
      <ul className="space-y-3">
        {links.map((l) => <li key={l.label}><LinkItem l={l} onReportBug={onReportBug} /></li>)}
      </ul>
      {exploreTo && (
        <Link to={exploreTo} className="mt-5 inline-block text-xs font-bold text-coral transition hover:underline underline-offset-4">
          Explore all →
        </Link>
      )}
    </div>
  );
}

export function Footer() {
  const [bugOpen, setBugOpen] = useState(false);
  const openBug = () => setBugOpen(true);
  const location = useLocation();
  const showIntegrations = location.pathname === "/landing";

  return (
    <footer className="border-t-[1.5px] border-[#0F0F0F] bg-card">
      {/* Optional integrations strip (landing only) */}
      {showIntegrations && (
        <div className="border-b border-[#0F0F0F]/10">
          <div className="container-page py-10">
            <div className="mb-5 text-center text-xs font-bold text-muted-foreground md:text-left">Integrates with your stack</div>
            <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-5 md:justify-start">
              {INTEGRATIONS.map((b) => (
                <img
                  key={b.name}
                  src={b.src}
                  alt={b.name}
                  title={b.name}
                  loading="lazy"
                  className="h-6 w-auto opacity-80 grayscale transition duration-300 hover:opacity-100 hover:grayscale-0"
                  style={{ filter: "brightness(0)" }}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main footer body */}
      <div className="container-page py-16 md:py-20">
        <div className="grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-6 md:gap-10">
          {/* Brand block — 2 cols on desktop */}
          <div className="col-span-2 md:col-span-2">
            <Link to="/" className="flex items-center gap-2">
              <VibeCodeMark size={40} />
              <span className="font-display text-2xl font-extrabold tracking-tight leading-none">
                <span className="text-foreground">vibe</span><span className="text-coral">coder</span>
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm text-muted-foreground">
              India's largest AI builder community.
            </p>

            {/* Signature coral CTA — the one loud moment */}
            <Link
              to="/auth"
              className="mt-6 inline-flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-5 py-2.5 text-sm font-bold text-white transition hover:-translate-y-0.5"
              style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
            >
              Create profile →
            </Link>

            {/* Socials */}
            <div className="mt-8 flex flex-wrap items-center gap-5">
              {SOCIAL.map((s) => (
                <a
                  key={s.name}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.name}
                  title={s.name}
                  className="text-[#0F0F0F]/70 transition hover:text-[#0F0F0F]"
                >
                  <svg
                    role="img"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5"
                    fill="currentColor"
                    aria-hidden="true"
                  >
                    <path d={s.path} />
                  </svg>
                </a>
              ))}
            </div>


            <p className="mt-6 text-xs text-muted-foreground">Made in Bengaluru 🇮🇳 · for the world</p>
          </div>

          {/* Link columns */}
          <FooterCol title="Platform" links={PLATFORM} exploreTo="/explore" onReportBug={openBug} />
          <FooterCol title="Library" links={LIBRARY} exploreTo="/prompts" onReportBug={openBug} />
          <FooterCol title="Company" links={COMPANY} onReportBug={openBug} />
          <FooterCol title="Resources" links={RESOURCES} onReportBug={openBug} />
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-[#0F0F0F]/10">
        <div className="container-page flex flex-col items-center justify-between gap-4 py-6 text-center sm:flex-row sm:text-left">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="h-2 w-2 animate-blink rounded-full bg-success" />
            All systems operational
          </div>
          <p className="text-xs text-muted-foreground">© 2026 VibeCode Labs Pvt. Ltd.</p>
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 sm:justify-end">
            {LEGAL.map((l, i) => (
              <div key={l.label} className="flex items-center gap-4">
                <LinkItem l={l} onReportBug={openBug} muted />
                {i < LEGAL.length - 1 && <span className="text-muted-foreground/40">·</span>}
              </div>
            ))}
          </div>
        </div>
      </div>

      <ReportBugModal open={bugOpen} onClose={() => setBugOpen(false)} />
    </footer>
  );
}
