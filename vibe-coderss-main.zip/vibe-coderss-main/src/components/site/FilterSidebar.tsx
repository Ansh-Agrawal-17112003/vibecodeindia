import type { ReactNode } from "react";

export function FilterSidebar({ children }: { children: ReactNode }) {
  return (
    <aside className="card-editorial sticky top-32 h-fit p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-display text-base font-bold">Filters</h3>
        <button className="text-xs font-bold text-coral hover:underline">Clear all</button>
      </div>
      <div className="space-y-5">{children}</div>
    </aside>
  );
}

export function FilterGroup({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div>
      <div className="mb-2 text-xs font-bold uppercase tracking-wider text-foreground">{title}</div>
      <div className="space-y-1.5">{children}</div>
    </div>
  );
}

export function FilterCheckbox({ label, count }: { label: string; count?: number }) {
  return (
    <label className="flex cursor-pointer items-center gap-2 text-sm text-foreground/80 hover:text-foreground">
      <input type="checkbox" className="h-3.5 w-3.5 rounded border-border accent-coral" />
      <span className="flex-1">{label}</span>
      {count !== undefined && <span className="text-xs text-muted-foreground">{count}</span>}
    </label>
  );
}
