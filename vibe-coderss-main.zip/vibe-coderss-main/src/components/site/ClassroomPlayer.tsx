import { useEffect, useMemo, useRef, useState } from "react";
import {
  X, ThumbsUp, ThumbsDown, Share2, Bookmark, Bell, BellOff, Check,
  Send, Radio, Upload, MoreHorizontal,
} from "lucide-react";
import { toast } from "sonner";
import { builders } from "@/lib/mock-data";

export type ClassroomResource = {
  id: string;
  title: string;
  category: string;
  builderIdx: number;
  date: string;
  downloads: number;
  rating: number;
  kind: string;
};

type Comment = {
  id: string;
  builderIdx: number;
  body: string;
  time: string;
  likes: number;
};

const SAMPLE_LIVE = [
  "This part was 🔥",
  "Wait, can you repeat that prompt?",
  "Which model are you using here?",
  "Following along — building the same thing",
  "10/10 lecture 🙌",
  "Timestamp this please",
  "Bookmarking this section",
  "Just replicated it, works!",
  "Hey from Bangalore 👋",
  "How do we handle rate limits here?",
];

const SAMPLE_VIDEOS = [
  // Royalty-free MP4 sources
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
];

function hash(s: string) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }

export function ClassroomPlayer({
  resource,
  onClose,
  isLive: initialLive = false,
}: {
  resource: ClassroomResource;
  onClose: () => void;
  isLive?: boolean;
}) {
  const teacher = builders[resource.builderIdx % builders.length];
  const [liked, setLiked] = useState(false);
  const [disliked, setDisliked] = useState(false);
  const [subscribed, setSubscribed] = useState(false);
  const [notified, setNotified] = useState(true);
  const [saved, setSaved] = useState(false);
  const [likes, setLikes] = useState(120 + (hash(resource.id) % 3000));
  const [subs, setSubs] = useState(1200 + (hash(teacher.username) % 12000));
  const [viewers, setViewers] = useState(initialLive ? 40 + (hash(resource.id) % 300) : 0);
  const [comments, setComments] = useState<Comment[]>(() =>
    Array.from({ length: 6 }).map((_, i) => ({
      id: `c-${i}`,
      builderIdx: (hash(resource.id) + i * 3) % builders.length,
      body: SAMPLE_LIVE[(hash(resource.id) + i) % SAMPLE_LIVE.length],
      time: `${i + 1}m ago`,
      likes: Math.floor(Math.random() * 20),
    })),
  );
  const [draft, setDraft] = useState("");
  const [isLive] = useState(initialLive);
  const videoSrc = useMemo(() => SAMPLE_VIDEOS[hash(resource.id) % SAMPLE_VIDEOS.length], [resource.id]);
  const commentsRef = useRef<HTMLDivElement>(null);

  // Live simulation
  useEffect(() => {
    if (!isLive) return;
    const viewerT = setInterval(() => setViewers((v) => Math.max(20, v + Math.floor(Math.random() * 11) - 5)), 4000);
    const chatT = setInterval(() => {
      const b = builders[Math.floor(Math.random() * builders.length)];
      const idx = Math.floor(Math.random() * builders.length);
      setComments((prev) => [
        ...prev,
        {
          id: `l-${Date.now()}-${Math.random()}`,
          builderIdx: idx,
          body: SAMPLE_LIVE[Math.floor(Math.random() * SAMPLE_LIVE.length)],
          time: "just now",
          likes: 0,
        },
      ].slice(-40));
      setTimeout(() => commentsRef.current?.scrollTo({ top: commentsRef.current.scrollHeight, behavior: "smooth" }), 50);
    }, 3500);
    return () => { clearInterval(viewerT); clearInterval(chatT); };
  }, [isLive]);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, []);

  const submitComment = () => {
    if (!draft.trim()) return;
    setComments((prev) => [...prev, {
      id: `u-${Date.now()}`, builderIdx: 0, body: draft.trim(), time: "just now", likes: 0,
    }]);
    setDraft("");
    setTimeout(() => commentsRef.current?.scrollTo({ top: commentsRef.current.scrollHeight, behavior: "smooth" }), 50);
    toast.success("Sent");
  };

  const toggleLike = () => {
    if (liked) { setLiked(false); setLikes((n) => n - 1); return; }
    setLiked(true); setLikes((n) => n + 1);
    if (disliked) setDisliked(false);
  };
  const toggleDislike = () => {
    if (disliked) { setDisliked(false); return; }
    setDisliked(true);
    if (liked) { setLiked(false); setLikes((n) => n - 1); }
  };
  const toggleSubscribe = () => {
    if (subscribed) { setSubscribed(false); setSubs((n) => n - 1); toast("Unsubscribed"); return; }
    setSubscribed(true); setSubs((n) => n + 1); toast.success(`Subscribed to ${teacher.name}`);
  };
  const share = () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    navigator.clipboard?.writeText(url).then(() => toast.success("Link copied"));
  };

  return (
    <div className="fixed inset-0 z-[110] flex flex-col bg-black/80 lg:items-center lg:justify-center lg:p-4" onClick={onClose}>
      <div
        className="relative flex h-full w-full flex-col overflow-hidden bg-white lg:h-[92vh] lg:max-w-6xl lg:rounded-2xl lg:border-[1.5px] lg:border-[#0F0F0F]"
        style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute right-3 top-3 z-20 grid h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white shadow-[2px_2px_0_0_#0F0F0F]"
          aria-label="Close"
        ><X className="h-4 w-4" /></button>

        <div className="flex min-h-0 flex-1 flex-col overflow-y-auto lg:flex-row lg:overflow-hidden">
          {/* Video + info */}
          <div className="flex min-w-0 flex-col lg:flex-1 lg:overflow-y-auto">
            <div className="relative aspect-video w-full bg-black">
              {isLive && (
                <div className="absolute left-3 top-3 z-10 flex items-center gap-2">
                  <span className="flex items-center gap-1 rounded-md bg-red-600 px-2 py-0.5 text-[10px] font-extrabold uppercase text-white">
                    <Radio className="h-3 w-3 animate-pulse" /> Live
                  </span>
                  <span className="rounded-md bg-black/70 px-2 py-0.5 text-[10px] font-bold text-white">
                    👁 {viewers.toLocaleString()} watching
                  </span>
                </div>
              )}
              <video
                key={videoSrc}
                src={videoSrc}
                controls
                autoPlay={false}
                playsInline
                className="h-full w-full bg-black"
                poster={`https://picsum.photos/seed/${resource.id}/1280/720`}
              />
            </div>

            <div className="border-b-[1.5px] border-[#0F0F0F]/10 p-3 lg:p-4">
              <h1 className="font-display text-base font-extrabold leading-snug lg:text-xl">{resource.title}</h1>
              <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] font-bold text-muted-foreground lg:text-xs">
                <span className="rounded bg-cream px-1.5 py-0.5 text-foreground/70">{resource.category}</span>
                <span>{Math.floor(likes * 8).toLocaleString()} views</span>
                <span>· {resource.date}</span>
              </div>

              {/* Channel + subscribe */}
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <a href={`/u/${teacher.username}`} className="flex min-w-0 items-center gap-2">
                  <img src={teacher.avatar} alt="" className="h-10 w-10 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]" />
                  <div className="min-w-0">
                    <div className="truncate text-sm font-extrabold">{teacher.name}</div>
                    <div className="text-[11px] font-bold text-muted-foreground">{subs.toLocaleString()} subscribers</div>
                  </div>
                </a>
                <button
                  onClick={toggleSubscribe}
                  className={`ml-auto flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1.5 text-xs font-extrabold ${
                    subscribed ? "bg-white text-foreground" : "bg-[#0F0F0F] text-white"
                  }`}
                  style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                >
                  {subscribed ? <><Check className="h-3.5 w-3.5" /> Subscribed</> : "Subscribe"}
                </button>
                {subscribed && (
                  <button
                    onClick={() => { setNotified((n) => !n); toast(notified ? "Notifications off" : "All notifications on"); }}
                    className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white"
                    aria-label="Notifications"
                  >
                    {notified ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
                  </button>
                )}
              </div>

              {/* Action row */}
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <div className="flex items-center overflow-hidden rounded-full border-[1.5px] border-[#0F0F0F] bg-cream" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                  <button onClick={toggleLike} className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-extrabold ${liked ? "text-coral" : ""}`}>
                    <ThumbsUp className={`h-3.5 w-3.5 ${liked ? "fill-current" : ""}`} /> {likes.toLocaleString()}
                  </button>
                  <span className="h-5 w-px bg-[#0F0F0F]/20" />
                  <button onClick={toggleDislike} className={`px-3 py-1.5 text-xs font-extrabold ${disliked ? "text-coral" : ""}`}>
                    <ThumbsDown className={`h-3.5 w-3.5 ${disliked ? "fill-current" : ""}`} />
                  </button>
                </div>
                <button onClick={share} className="flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1.5 text-xs font-extrabold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                  <Share2 className="h-3.5 w-3.5" /> Share
                </button>
                <button onClick={() => { setSaved((s) => !s); toast.success(saved ? "Removed" : "Saved"); }} className={`flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1.5 text-xs font-extrabold ${saved ? "bg-coral text-white" : "bg-white"}`} style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                  <Bookmark className={`h-3.5 w-3.5 ${saved ? "fill-current" : ""}`} /> {saved ? "Saved" : "Save"}
                </button>
                <button className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white" aria-label="More">
                  <MoreHorizontal className="h-4 w-4" />
                </button>
              </div>

              {/* Description */}
              <div className="mt-3 rounded-lg border border-[#0F0F0F]/15 bg-cream/60 p-3 text-[13px] leading-relaxed text-foreground/80">
                <p>
                  <strong>{resource.title}</strong> — a {resource.kind.toLowerCase()} from{" "}
                  <a href={`/u/${teacher.username}`} className="font-bold text-coral hover:underline">{teacher.name}</a>.
                  Learn how to ship a production-ready workflow step by step. Ask questions in the chat — the community answers in real time.
                </p>
                <div className="mt-2 flex flex-wrap gap-1.5 text-[11px] font-bold">
                  {["#tutorial", "#" + resource.category.toLowerCase().replace(/\s+/g, "-"), "#" + teacher.username].map((t) => (
                    <span key={t} className="rounded bg-white px-1.5 py-0.5 border border-[#0F0F0F]/15">{t}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Live chat / comments */}
          <aside className="flex min-h-[45vh] flex-col border-t-[1.5px] border-[#0F0F0F]/15 bg-cream/40 lg:h-full lg:w-[340px] lg:min-h-0 lg:border-l-[1.5px] lg:border-t-0">
            <div className="flex items-center justify-between border-b border-[#0F0F0F]/15 bg-white px-3 py-2.5">
              <div className="flex items-center gap-2 text-sm font-extrabold">
                {isLive ? (
                  <><span className="h-2 w-2 rounded-full bg-red-600 animate-pulse" /> Live Chat</>
                ) : (
                  <>💬 Comments <span className="text-xs font-bold text-muted-foreground">({comments.length})</span></>
                )}
              </div>
              <button
                onClick={() => toast("Upload/livestream coming soon — creators only")}
                className="flex items-center gap-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2 py-1 text-[10px] font-extrabold uppercase"
                style={{ boxShadow: "1px 1px 0 0 #0F0F0F" }}
              >
                <Upload className="h-3 w-3" /> Upload
              </button>
            </div>
            <div ref={commentsRef} className="flex-1 space-y-2 overflow-y-auto p-3">
              {comments.map((c) => {
                const b = builders[c.builderIdx % builders.length];
                return (
                  <div key={c.id} className="flex gap-2">
                    <img src={b.avatar} alt="" className="h-7 w-7 shrink-0 rounded-full border border-[#0F0F0F]/30" />
                    <div className="min-w-0 flex-1 text-[12px]">
                      <div className="flex items-baseline gap-1.5">
                        <a href={`/u/${b.username}`} className="truncate text-[11px] font-extrabold hover:text-coral">{b.name.split(" ")[0]}</a>
                        <span className="text-[10px] font-bold text-muted-foreground">{c.time}</span>
                      </div>
                      <div className="leading-snug text-foreground/85">{c.body}</div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center gap-2 border-t border-[#0F0F0F]/15 bg-white p-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submitComment()}
                placeholder={isLive ? "Say something…" : "Add a comment…"}
                className="min-w-0 flex-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-sm outline-none"
              />
              <button
                onClick={submitComment}
                className="grid h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-coral text-white"
                style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                aria-label="Send"
              ><Send className="h-4 w-4" /></button>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
