import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Loader2, Flame, Trophy, Sparkles } from "lucide-react";
import { RIGHT_JOBS_POOL } from "@/lib/vibe-feed-seed";
import { listSuggestedPeople, followUser } from "@/lib/people-api";
import { useAuth } from "@/hooks/useAuth";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { CompanyLogo } from "@/components/site/CompanyLogo";
import { WhoToFollow } from "@/components/vibe/WhoToFollow";

function Card({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
      {children}
    </div>
  );
}

export function RightPane() {
  return (
    <aside className="flex flex-col gap-4 pb-8 pl-2">
      <WhoToFollow />
      <ChallengeCard />
      <JobsCard />
      <PeopleCard />
      <TrendingHashtagsCard />
      <NewsCard />
    </aside>
  );
}

const TRENDING_HASHTAGS = [
  { tag: "lovable", posts: "2,847" },
  { tag: "shipinpublic", posts: "1,923" },
  { tag: "n8n", posts: "1,456" },
  { tag: "claude", posts: "1,201" },
  { tag: "buildinpublic", posts: "987" },
  { tag: "indiehacker", posts: "834" },
  { tag: "automation", posts: "721" },
];

function TrendingHashtagsCard() {
  return (
    <Card>
      <div className="flex items-center justify-between">
        <h3 className="font-display text-sm font-bold">🔥 Trending This Week</h3>
      </div>
      <div className="mt-3 space-y-0.5">
        {TRENDING_HASHTAGS.map((h, i) => (
          <Link
            key={h.tag}
            to="/search"
            search={{ q: `#${h.tag}` }}
            className="group flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left transition-colors hover:bg-coral hover:text-white"
          >
            <span className="flex items-center gap-2 text-[13px] font-semibold">
              <span className="w-4 text-[11px] text-muted-foreground group-hover:text-white/80">{i + 1}</span>
              #{h.tag}
            </span>
            <span className="text-[11px] text-muted-foreground group-hover:text-white/80">{h.posts} posts</span>
          </Link>
        ))}
      </div>
    </Card>
  );
}

function useMidnightISTCountdown() {
  const [time, setTime] = useState("");
  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const ist = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
      const midnight = new Date(ist);
      midnight.setHours(24, 0, 0, 0);
      const diff = midnight.getTime() - ist.getTime();
      const h = Math.floor(diff / 3600000).toString().padStart(2, "0");
      const m = Math.floor((diff % 3600000) / 60000).toString().padStart(2, "0");
      const s = Math.floor((diff % 60000) / 1000).toString().padStart(2, "0");
      setTime(`${h}:${m}:${s}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return time;
}

function ChallengeCard() {
  const t = useMidnightISTCountdown();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  return (
    <Card>
      <div className="flex items-center justify-between">
        <h3 className="font-display text-sm font-bold">🔥 Today's Vibe Challenge</h3>
        <Link to="/rewards" className="text-[11px] font-bold text-coral hover:underline">View all</Link>
      </div>
      <div className="mt-3 rounded-lg bg-surface p-3">
        <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Wednesday</div>
        <div className="mt-1 text-sm font-semibold leading-snug">Drop your latest project for community feedback!</div>
      </div>
      <div className="mt-3 flex items-center justify-between text-xs">
        <span className="text-muted-foreground">⏰ Resets in:</span>
        <span className="font-mono font-bold tabular-nums text-coral">{t || "00:00:00"}</span>
      </div>
      <div className="mt-1 text-[11px] text-muted-foreground">🎁 Top post wins 100 VibeCoins</div>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="btn-coral mt-3 block w-full !py-2 text-center text-xs"
      >
        Join Challenge →
      </button>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="w-full overflow-y-auto border-l-[1.5px] border-[#0F0F0F] bg-background p-0 sm:max-w-md">
          <SheetHeader className="border-b-[1.5px] border-[#0F0F0F]/10 px-5 py-4 text-left">
            <SheetTitle className="flex items-center gap-2 text-base font-black">
              <Flame className="h-4 w-4 text-coral" /> Today's Vibe Challenge
            </SheetTitle>
            <SheetDescription className="text-xs">
              Drop your latest project for community feedback. Top post wins 100 VibeCoins.
            </SheetDescription>
          </SheetHeader>
          <div className="space-y-4 p-5">
            <div className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-surface p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">⏰ Challenge resets in</span>
                <span className="font-mono font-bold tabular-nums text-coral">{t || "00:00:00"}</span>
              </div>
              <div className="mt-3 flex items-center gap-2 text-xs">
                <Trophy className="h-3.5 w-3.5 text-gold" />
                <span className="font-semibold">Top post wins 100 VibeCoins</span>
              </div>
              <div className="mt-1 flex items-center gap-2 text-xs">
                <Sparkles className="h-3.5 w-3.5 text-coral" />
                <span className="font-semibold">All entries get bonus feed reach</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-black uppercase tracking-wider text-muted-foreground">How to enter</div>
              <ol className="space-y-2 text-sm">
                <li className="flex gap-2"><span className="font-black text-coral">1.</span> Add your project with cover, problem & solution.</li>
                <li className="flex gap-2"><span className="font-black text-coral">2.</span> Share it to the feed for community feedback.</li>
                <li className="flex gap-2"><span className="font-black text-coral">3.</span> Reply to every comment — engagement counts.</li>
              </ol>
            </div>

            <div className="flex flex-col gap-2">
              <Link
                to={user ? "/submit-project" : "/auth"}
                onClick={() => setOpen(false)}
                className="btn-coral block w-full text-center text-sm"
              >
                {user ? "Submit your project" : "Sign in to submit"}
              </Link>
              <Link
                to="/rewards"
                onClick={() => setOpen(false)}
                className="block w-full rounded-xl border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-center text-sm font-bold hover:bg-surface"
                style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
              >
                See all challenges
              </Link>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </Card>
  );
}

function useRotator(size: number, count: number, ms: number) {
  const [i, setI] = useState(0);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => { setI((x) => (x + count) % size); setTick((x) => x + 1); }, ms);
    return () => clearInterval(t);
  }, [size, count, ms]);
  return { i, tick, rotate: () => { setI((x) => (x + count) % size); setTick((x) => x + 1); } };
}

function JobsCard() {
  const { i, tick } = useRotator(RIGHT_JOBS_POOL.length, 3, 300000);
  const visible = [0, 1, 2].map((k) => RIGHT_JOBS_POOL[(i + k) % RIGHT_JOBS_POOL.length]);
  return (
    <Card>
      <div className="flex items-center justify-between">
        <h3 className="font-display text-sm font-bold">💼 Jobs For You</h3>
        <Link to="/jobs" className="text-[11px] font-bold text-coral hover:underline">View all</Link>
      </div>
      <div className="mt-1 text-[10px] text-muted-foreground">Matched to your skills:</div>
      <div key={tick} className="mt-3 space-y-3 animate-fade-in">
        {visible.map((j) => (
          <div key={j.id} className="flex items-start gap-2.5">
            <CompanyLogo name={j.company} size={32} radius={6} />
            <div className="min-w-0 flex-1">
              <Link to="/jobs/$id" params={{ id: j.id }} className="line-clamp-1 text-xs font-bold hover:text-coral">{j.title}</Link>
              <div className="truncate text-[10px] text-muted-foreground">{j.company} · {j.remote}</div>
              <div className="mt-0.5 text-[10px] font-semibold text-coral">{j.salary}</div>
            </div>
            <Link to="/jobs/$id" params={{ id: j.id }} className="shrink-0 rounded-full bg-coral px-2 py-0.5 text-[10px] font-bold text-white">Quick Apply</Link>
          </div>
        ))}
      </div>
    </Card>
  );
}

function PeopleCard() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const [followed, setFollowed] = useState<Set<string>>(new Set());
  const { data: people = [], isLoading } = useQuery({
    queryKey: ["suggested-people"],
    queryFn: () => listSuggestedPeople(15),
    staleTime: 60_000,
  });

  const followMut = useMutation({
    mutationFn: (id: string) => followUser(id),
    onSuccess: (_d, id) => {
      setFollowed((s) => new Set(s).add(id));
      
      qc.invalidateQueries({ queryKey: ["suggested-people"] });
    },
    onError: (e: any) => {
      if (String(e?.message).includes("Not signed in")) toast.error("Sign in to follow");
      else toast.error(e?.message || "Couldn't follow");
    },
  });

  const visible = people.slice(0, 3);

  return (
    <Card>
      <div className="flex items-center justify-between">
        <h3 className="font-display text-sm font-bold">👥 People to Follow</h3>
        <Link to="/explore" search={{ mode: "real" }} className="text-[11px] font-bold text-coral hover:underline">See all</Link>
      </div>
      <div className="mt-3 space-y-3 animate-fade-in">
        {isLoading && (
          <div className="grid place-items-center py-3 text-[11px] text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
          </div>
        )}
        {!isLoading && visible.length === 0 && (
          <div className="text-[11px] text-muted-foreground">No suggestions yet.</div>
        )}
        {visible.map((b) => {
          const isFollowed = followed.has(b.id);
          return (
            <div key={b.id} className="flex items-center gap-2.5">
              <Link to="/u/$username" params={{ username: b.username || "" }} className="shrink-0">
                <img
                  src={b.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${b.username || b.id}`}
                  alt=""
                  className="h-8 w-8 rounded-full border-[1.5px] border-[#0F0F0F] object-cover"
                />
              </Link>
              <Link to="/u/$username" params={{ username: b.username || "" }} className="min-w-0 flex-1">
                <div className="truncate text-xs font-bold hover:text-coral">{b.display_name || b.username}</div>
                <div className="truncate text-[10px] text-muted-foreground">
                  {(b.roles && b.roles[0]) || b.bio || "Builder"}
                </div>
              </Link>
              <button
                onClick={() => { if (!user) { toast.error("Sign in to follow"); return; } if (!isFollowed) followMut.mutate(b.id); }}
                disabled={isFollowed || followMut.isPending}
                className={`shrink-0 rounded-full border-[1.5px] px-2.5 py-0.5 text-[10px] font-bold disabled:opacity-70 ${
                  isFollowed ? "border-[#0F0F0F] bg-[#0F0F0F] text-white" : "border-coral text-coral hover:bg-coral hover:text-white"
                }`}
              >
                {isFollowed ? "Following ✓" : "+ Follow"}
              </button>
            </div>
          );
        })}
      </div>
    </Card>
  );
}


const AI_NEWS_ITEMS = [
  { title: "OpenAI launches GPT-4o mini with 8x faster inference", source: "TechCrunch", time: "2h ago", url: "https://techcrunch.com" },
  { title: "Anthropic Claude 3.5 Sonnet tops all coding benchmarks", source: "The Verge", time: "4h ago", url: "https://theverge.com" },
  { title: "India's AI startup funding crosses $2B in H1 2025", source: "Inc42", time: "6h ago", url: "https://inc42.com" },
  { title: "n8n raises $35M Series B to expand automation platform", source: "VentureBeat", time: "1d ago", url: "https://venturebeat.com" },
  { title: "Google Gemini 2.0 Flash now free for developers", source: "Google Blog", time: "1d ago", url: "https://blog.google" },
  { title: "Meta releases Llama 4 with multimodal reasoning", source: "Reuters", time: "2d ago", url: "https://reuters.com" },
  { title: "Lovable crosses 500K users, launches enterprise plan", source: "Product Hunt", time: "2d ago", url: "https://producthunt.com" },
  { title: "Perplexity AI raises $250M at $9B valuation", source: "Bloomberg", time: "3d ago", url: "https://bloomberg.com" },
];

export function NewsCard() {
  const [offset, setOffset] = useState(0);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => {
      setOffset((o) => (o + 4) % AI_NEWS_ITEMS.length);
      setTick((t) => t + 1);
    }, 90_000);
    return () => clearInterval(id);
  }, []);
  const visible = [0, 1, 2, 3].map((k) => AI_NEWS_ITEMS[(offset + k) % AI_NEWS_ITEMS.length]);
  return (
    <Card>
      <div className="flex items-center justify-between">
        <h3 className="font-display text-sm font-bold">🤖 AI News</h3>
        <span className="flex items-center gap-1 text-[10px] font-bold text-muted-foreground">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-500" /> LIVE
        </span>
      </div>
      <div key={tick} className="mt-3 space-y-3 animate-fade-in">
        {visible.map((n) => (
          <a
            key={n.title}
            href={n.url}
            target="_blank"
            rel="noreferrer noopener"
            className="flex gap-2 hover:opacity-90"
          >
            <div className="mt-0.5 h-3 w-3 shrink-0 rounded bg-coral" />
            <div className="min-w-0">
              <div className="line-clamp-2 text-[13px] font-bold leading-snug">{n.title}</div>
              <div className="mt-0.5 text-[11px] text-muted-foreground">{n.source} · {n.time}</div>
            </div>
          </a>
        ))}
      </div>
      <a href="https://news.google.com/search?q=AI" target="_blank" rel="noreferrer noopener" className="mt-3 block text-[11px] font-bold text-coral hover:underline">See more AI news →</a>
    </Card>
  );
}
