import { useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { MoreHorizontal, MessageSquare, Share2, Bookmark, Copy, ExternalLink, Github, ThumbsUp, Flame, Lightbulb, PartyPopper, HandHeart } from "lucide-react";
import type { FeedPost } from "@/lib/vibe-feed-seed";
import { getBuilder } from "@/lib/vibe-feed-seed";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { xpToast, xpToastFirstCopy } from "@/lib/xp-toast";

const REACTIONS = [
  { k: "like", icon: ThumbsUp, label: "Like", color: "#2563EB" },
  { k: "celebrate", icon: PartyPopper, label: "Celebrate", color: "#F59E0B" },
  { k: "fire", icon: Flame, label: "Fire", color: "#E8623A" },
  { k: "insightful", icon: Lightbulb, label: "Insightful", color: "#7C3AED" },
  { k: "support", icon: HandHeart, label: "Support", color: "#22C55E" },
] as const;

const typeBadge: Record<FeedPost["type"], { label: string; bg: string; fg: string }> = {
  project: { label: "PROJECT", bg: "#E8623A", fg: "#fff" },
  prompt: { label: "PROMPT", bg: "#0F0F0F", fg: "#fff" },
  workflow: { label: "WORKFLOW", bg: "#F5A623", fg: "#0F0F0F" },
  update: { label: "UPDATE", bg: "#2DD4BF", fg: "#0F0F0F" },
  question: { label: "QUESTION", bg: "#7C3AED", fg: "#fff" },
};

export function VibeFeedCard({ post, mobile }: { post: FeedPost; mobile?: boolean }) {
  const author = getBuilder(post.authorId);
  const [reactions, setReactions] = useState(post.reactions);
  const [userReaction, setUserReaction] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [showPicker, setShowPicker] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [showHeart, setShowHeart] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const tapTimer = useRef<number | null>(null);
  const total = Object.values(reactions).reduce((a, b) => a + b, 0);

  const react = (key: string) => {
    setReactions((prev) => {
      const next = { ...prev } as any;
      if (userReaction) next[userReaction] = Math.max(0, next[userReaction] - 1);
      next[key] = (next[key] ?? 0) + 1;
      return next;
    });
    setUserReaction(key);
    setShowPicker(false);
  };

  const handleContentTap = () => {
    if (!mobile) return;
    if (tapTimer.current) {
      window.clearTimeout(tapTimer.current);
      tapTimer.current = null;
      if (!userReaction) react("like");
      setShowHeart(true);
      window.setTimeout(() => setShowHeart(false), 500);
    } else {
      tapTimer.current = window.setTimeout(() => {
        tapTimer.current = null;
      }, 250);
    }
  };

  const b = typeBadge[post.type];

  return (
    <article
      className={cn(
        "relative border-[1.5px] border-[#0F0F0F] bg-white",
        mobile ? "rounded-none" : "rounded-2xl",
      )}
      style={{ boxShadow: mobile ? "none" : "3px 3px 0 0 #0F0F0F" }}
    >
      {/* header */}
      <div className="flex items-start gap-3 p-4">
        <Link to="/u/$username" params={{ username: author.username }} className="shrink-0">
          <img src={author.avatar} alt={author.name} className="h-10 w-10 rounded-full border-[1.5px] border-[#0F0F0F]" />
        </Link>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <Link to="/u/$username" params={{ username: author.username }} className="truncate font-display text-sm font-bold hover:underline">
              {author.name}
            </Link>
            {author.verified && <span className="text-xs text-coral">✓</span>}
          </div>
          <div className="truncate text-xs text-muted-foreground">
            {author.title} · 📍 {author.location} · {post.createdAgo}
          </div>
        </div>
        <span
          className="pill-badge shrink-0 text-[10px]"
          style={{ background: b.bg, color: b.fg }}
        >
          {b.label}
        </span>
        <button aria-label="More" className="grid h-8 w-8 shrink-0 place-items-center rounded-full hover:bg-surface">
          <MoreHorizontal className="h-4 w-4" />
        </button>
      </div>

      {/* text */}
      {post.text && (
        <div className="px-4 pb-3 text-sm leading-relaxed">
          {expanded || post.text.length < 220 ? post.text : (
            <>
              {post.text.slice(0, 200)}…{" "}
              <button onClick={() => setExpanded(true)} className="text-coral hover:underline">see more</button>
            </>
          )}
        </div>
      )}

      {/* content block */}
      <div className="relative px-4" onClick={handleContentTap}>
        <ContentBlock post={post} />
        {showHeart && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center">
            <ThumbsUp className="h-24 w-24 animate-scale-in text-coral drop-shadow-lg" />
          </div>
        )}
      </div>

      {/* hashtags */}
      {post.hashtags.length > 0 && (
        <div className="flex flex-wrap gap-1.5 px-4 pt-3">
          {post.hashtags.map((h) => (
            <span key={h} className="text-xs font-semibold text-coral hover:underline">#{h}</span>
          ))}
        </div>
      )}

      {/* counts */}
      <div className="mt-3 flex items-center justify-between border-t-[1.5px] border-[#0F0F0F]/10 px-4 py-2 text-xs text-muted-foreground">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-foreground">{formatNum(total)} reactions</span>
          {post.views > 0 && <span>· 👁 {formatNum(post.views)} views</span>}
        </div>
        <div className="flex items-center gap-3">
          <span>💬 {post.comments}</span>
          <span>↗ {post.shares}</span>
        </div>
      </div>

      {/* actions */}
      <div className="grid grid-cols-4 border-t-[1.5px] border-[#0F0F0F]/10">
        <div
          className="relative"
          onMouseEnter={() => !mobile && setShowPicker(true)}
          onMouseLeave={() => !mobile && setShowPicker(false)}
        >
          <button
            onClick={() => react(userReaction ? userReaction : "like")}
            className={cn(
              "flex w-full items-center justify-center gap-1.5 py-2.5 text-xs font-bold transition-colors hover:bg-surface",
              userReaction && "text-coral",
            )}
          >
            <ThumbsUp className="h-4 w-4" /> {userReaction ? cap(userReaction) : "Like"}
          </button>
          {showPicker && (
            <div className="absolute bottom-full left-1/2 z-30 mb-2 flex -translate-x-1/2 gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-2 py-1.5 shadow-[3px_3px_0_0_#0F0F0F]">
              {REACTIONS.map(({ k, icon: Icon, label, color }) => (
                <button
                  key={k}
                  onClick={() => react(k)}
                  title={label}
                  aria-label={label}
                  className="grid h-9 w-9 place-items-center rounded-full transition-transform hover:scale-125 hover:bg-surface"
                  style={{ color }}
                >
                  <Icon className="h-5 w-5" />
                </button>
              ))}
            </div>
          )}
        </div>
        <button
          onClick={() => setShowComments((x) => !x)}
          className="flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface"
        >
          <MessageSquare className="h-4 w-4" /> Comment
        </button>
        <button
          onClick={() => { navigator.clipboard?.writeText(window.location.href).catch(() => {}); toast.success("Link copied"); }}
          className="flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface"
        >
          <Share2 className="h-4 w-4" /> Share
        </button>
        <button
          onClick={() => { setSaved((s) => { const next = !s; if (next) xpToast(5); return next; }); toast.success(saved ? "Unsaved" : "Saved"); }}
          className={cn("flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface", saved && "text-coral")}
        >
          <Bookmark className={cn("h-4 w-4", saved && "fill-coral")} /> {saved ? "Saved" : "Save"}
        </button>
      </div>

      {/* top comment */}
      {(post.topComment || showComments) && (
        <div className="border-t-[1.5px] border-[#0F0F0F]/10 bg-surface/40 p-4">
          {post.topComment && (
            <div className="flex gap-2.5">
              <img src={getBuilder(post.topComment.authorId).avatar} className="h-7 w-7 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]" alt="" />
              <div className="min-w-0 flex-1 text-xs">
                <div>
                  <span className="font-bold">{getBuilder(post.topComment.authorId).name}</span>{" "}
                  <span>{post.topComment.text}</span>
                </div>
                <div className="mt-1 text-[10px] text-muted-foreground">👍 {post.topComment.likes} · Reply · {post.topComment.ago}</div>
              </div>
            </div>
          )}
          {showComments && (
            <div className="mt-3 flex gap-2">
              <input
                placeholder="Write a comment…"
                className="flex-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-coral"
              />
              <button className="rounded-full bg-coral px-4 text-xs font-bold text-white">Post</button>
            </div>
          )}
        </div>
      )}
    </article>
  );
}

function ContentBlock({ post }: { post: FeedPost }) {
  if (post.type === "project" && post.project) {
    const p = post.project;
    return (
      <div className="overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F]">
        <img src={p.cover} alt={p.title} className="aspect-video w-full object-cover" />
        <div className="p-3">
          <div className="font-display text-sm font-bold">{p.title}</div>
          <div className="mt-1.5 flex flex-wrap gap-1">
            {p.tools.map((t) => (
              <span key={t} className="rounded-full border border-[#0F0F0F]/20 bg-surface px-2 py-0.5 text-[10px] font-semibold">{t}</span>
            ))}
          </div>
          <div className="mt-3 flex gap-2">
            {p.demoUrl && <a href={p.demoUrl} className="inline-flex items-center gap-1 rounded-full bg-coral px-3 py-1 text-[11px] font-bold text-white"><ExternalLink className="h-3 w-3" /> Live Demo</a>}
            {p.githubUrl && <a href={p.githubUrl} className="inline-flex items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1 text-[11px] font-bold"><Github className="h-3 w-3" /> GitHub</a>}
          </div>
        </div>
      </div>
    );
  }
  if (post.type === "prompt" && post.prompt) {
    const p = post.prompt;
    return (
      <div className="overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] text-[#E8E0D6]">
        <div className="flex items-center justify-between border-b border-white/10 px-3 py-2">
          <span className="rounded-full bg-coral px-2 py-0.5 text-[10px] font-bold text-white">{p.model}</span>
          <button
            onClick={() => { navigator.clipboard?.writeText(p.text); toast.success("Prompt copied"); xpToastFirstCopy(post.id, 5); }}
            className="inline-flex items-center gap-1 rounded-full bg-white px-3 py-1 text-[11px] font-bold text-[#0F0F0F]"
          >
            <Copy className="h-3 w-3" /> Copy Prompt
          </button>
        </div>
        <pre className="max-h-56 overflow-auto whitespace-pre-wrap p-3 font-mono text-[11px] leading-relaxed">{p.text}</pre>
      </div>
    );
  }
  if (post.type === "workflow" && post.workflow) {
    const w = post.workflow;
    return (
      <div className="overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F]">
        <img src={w.thumb} alt={w.title} className="aspect-video w-full object-cover" />
        <div className="flex items-center justify-between p-3">
          <div className="min-w-0">
            <div className="truncate font-display text-sm font-bold">{w.title}</div>
            <div className="mt-1 flex flex-wrap gap-1">
              {w.tools.map((t) => <span key={t} className="rounded-full border border-[#0F0F0F]/20 bg-surface px-2 py-0.5 text-[10px] font-semibold">{t}</span>)}
            </div>
          </div>
          <button className="shrink-0 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1 text-[11px] font-bold">View Workflow</button>
        </div>
      </div>
    );
  }
  if (post.type === "question") {
    return (
      <div className="flex items-center justify-between rounded-xl border-[1.5px] border-[#7C3AED]/40 bg-[#F8F5FF] px-4 py-3">
        <div className="text-xs font-semibold text-[#7C3AED]">Community Question · help wanted</div>
        <button className="rounded-full bg-[#7C3AED] px-3 py-1 text-[11px] font-bold text-white">Answer</button>
      </div>
    );
  }
  return null;
}

function formatNum(n: number) {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return String(n);
}
function cap(s: string) { return s.charAt(0).toUpperCase() + s.slice(1); }
