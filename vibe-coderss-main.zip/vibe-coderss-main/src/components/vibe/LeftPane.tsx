import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { RefreshCw, Users, Folder, Star, Flame, Coins, Loader2, MapPin } from "lucide-react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { communities } from "@/lib/mock-data";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { listSuggestedPeople, followUser, type SuggestedPerson } from "@/lib/people-api";
import { levelFor, nextLevel, progressToNext } from "@/lib/xp";

export function LeftPane() {
  return (
    <aside className="flex flex-col gap-4 pb-8 pr-2">
      <ProfileCard />
      <SuggestedForYou />
      <MyCommunities />
    </aside>
  );
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-xl border-[1.5px] border-[#0F0F0F] bg-white ${className}`}
      style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
    >
      {children}
    </div>
  );
}

type MyProfile = {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  location: string | null;
  roles: string[] | null;
  follower_count: number | null;
  total_xp: number | null;
  vibecoin_balance: number | null;
  login_streak: number | null;
};

function ProfileCard() {
  const { user } = useAuth();
  const { data: profile, isLoading } = useQuery({
    queryKey: ["me-profile-card", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, username, display_name, avatar_url, bio, location, roles, follower_count, total_xp, vibecoin_balance, login_streak")
        .eq("id", user!.id)
        .maybeSingle();
      return data as MyProfile | null;
    },
    staleTime: 30_000,
  });

  const { data: projectCount = 0 } = useQuery({
    queryKey: ["me-project-count", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { count } = await supabase
        .from("projects")
        .select("id", { count: "exact", head: true })
        .eq("builder_id", user!.id);
      return count ?? 0;
    },
    staleTime: 60_000,
  });

  if (!user) {
    return (
      <Card className="p-4 text-center">
        <div className="font-display text-sm font-bold">Join the vibe</div>
        <p className="mt-1 text-xs text-muted-foreground">Sign in to track your XP, streak & VibeCoins.</p>
        <Link to="/auth" className="mt-3 inline-block rounded-full bg-coral px-4 py-1.5 text-xs font-bold text-white">
          Sign in
        </Link>
      </Card>
    );
  }

  if (isLoading || !profile) {
    return (
      <Card className="p-4">
        <div className="grid place-items-center py-6 text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
        </div>
      </Card>
    );
  }

  const name = profile.display_name || profile.username || user.email?.split("@")[0] || "Vibe Builder";
  const avatar = profile.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${profile.username || profile.id}`;
  const roleLabel = (profile.roles && profile.roles[0]) || "Builder";
  const xp = profile.total_xp ?? 0;
  const coins = profile.vibecoin_balance ?? 0;
  const streak = profile.login_streak ?? 0;
  const followers = profile.follower_count ?? 0;
  const lvl = levelFor(xp);
  const nxt = nextLevel(xp);
  const { pct, needed } = progressToNext(xp);
  const profileTo = profile.username || null;

  return (
    <Card className="overflow-hidden">
      <div className="h-16" style={{ background: `linear-gradient(90deg, ${lvl.color}, ${nxt?.color ?? "#F5A623"})` }} />
      <div className="px-4 pb-4">
        {profileTo ? (
          <Link to="/u/$username" params={{ username: profileTo }} className="block">
            <img src={avatar} alt={name} className="-mt-8 h-14 w-14 rounded-full border-[3px] border-white ring-[1.5px] ring-[#0F0F0F] object-cover" />
            <div className="mt-2 font-display text-base font-bold leading-tight hover:text-coral">{name}</div>
          </Link>
        ) : (
          <>
            <img src={avatar} alt={name} className="-mt-8 h-14 w-14 rounded-full border-[3px] border-white ring-[1.5px] ring-[#0F0F0F] object-cover" />
            <div className="mt-2 font-display text-base font-bold leading-tight">{name}</div>
          </>
        )}
        <div className="text-xs text-muted-foreground">
          {roleLabel}
          {profile.username ? ` · @${profile.username}` : ""}
        </div>
        {profile.location && (
          <div className="mt-0.5 flex items-center gap-1 text-[11px] text-muted-foreground">
            <MapPin className="h-3 w-3" /> {profile.location}
          </div>
        )}

        <div className="mt-4 grid grid-cols-3 gap-1 border-y-[1.5px] border-[#0F0F0F]/10 py-3 text-center">
          <Stat icon={<Users className="h-3 w-3" />} v={followers.toLocaleString()} l="Followers" />
          <Stat icon={<Folder className="h-3 w-3" />} v={projectCount.toLocaleString()} l="Projects" />
          <Stat icon={<Star className="h-3 w-3" />} v={xp.toLocaleString()} l="XP" />
        </div>

        <div className="mt-3 flex items-center gap-1.5 text-xs">
          <Flame className="h-3.5 w-3.5 text-coral" />
          <span className="font-bold">{streak}-day streak</span>
        </div>
        <div className="mt-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-bold">{lvl.emoji} {lvl.name}</span>
            <span className="text-muted-foreground">{xp.toLocaleString()} XP</span>
          </div>
          <div className="mt-1 h-1.5 rounded-full bg-surface">
            <div className="h-full rounded-full" style={{ width: `${pct}%`, background: lvl.color }} />
          </div>
          <div className="mt-1 text-[10px] text-muted-foreground">
            {nxt ? `${needed.toLocaleString()} XP to ${nxt.name}` : "Top level reached 👑"}
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between rounded-lg border-[1.5px] border-[#F5A623] bg-[#FFF7E0] px-3 py-2">
          <div className="flex items-center gap-1.5 text-xs font-bold">
            <Coins className="h-4 w-4 text-[#F5A623]" /> {coins.toLocaleString()} VibeCoins
          </div>
          <Link to="/rewards" className="text-[11px] font-bold text-coral hover:underline">Redeem →</Link>
        </div>

        {profileTo ? (
          <Link
            to="/u/$username"
            params={{ username: profileTo }}
            className="mt-3 block w-full rounded-full border-[1.5px] border-coral py-1.5 text-center text-xs font-bold text-coral hover:bg-coral hover:text-white"
          >
            View My Profile
          </Link>
        ) : (
          <Link
            to="/onboarding"
            className="mt-3 block w-full rounded-full border-[1.5px] border-coral py-1.5 text-center text-xs font-bold text-coral hover:bg-coral hover:text-white"
          >
            Complete your profile
          </Link>
        )}
      </div>
    </Card>
  );
}

function Stat({ icon, v, l }: { icon: React.ReactNode; v: string; l: string }) {
  return (
    <div>
      <div className="mx-auto mb-0.5 grid h-5 w-5 place-items-center text-muted-foreground">{icon}</div>
      <div className="font-display text-sm font-extrabold leading-none">{v}</div>
      <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">{l}</div>
    </div>
  );
}

function SuggestedForYou() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const [offset, setOffset] = useState(0);
  const { data: people = [], isLoading, refetch, isFetching } = useQuery({
    queryKey: ["suggested-people"],
    queryFn: () => listSuggestedPeople(15),
    staleTime: 60_000,
  });

  const visible: SuggestedPerson[] = people.length
    ? [0, 1, 2].map((k) => people[(offset + k) % people.length])
    : [];

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-sm font-bold">Suggested For You</h3>
        <Link to="/explore" search={{ mode: "real" }} className="text-[11px] font-bold text-coral hover:underline">See all</Link>
      </div>
      <div className="mt-3 space-y-3 animate-fade-in">
        {isLoading && (
          <div className="grid place-items-center py-4 text-[11px] text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
          </div>
        )}
        {!isLoading && visible.length === 0 && (
          <div className="text-[11px] text-muted-foreground">No suggestions yet — check back soon.</div>
        )}
        {visible.map((b) => (
          <div key={b.id} className="flex items-center gap-2.5">
            <Link
              to="/u/$username"
              params={{ username: b.username || "" }}
              className="relative shrink-0"
            >
              <img
                src={b.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${b.username || b.id}`}
                alt={b.display_name || b.username || ""}
                className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F] object-cover"
              />
              {b.availability_status === "available" && (
                <span className="absolute -right-0.5 -bottom-0.5 h-2.5 w-2.5 rounded-full border-2 border-white bg-green-500" />
              )}
            </Link>
            <Link
              to="/u/$username"
              params={{ username: b.username || "" }}
              className="min-w-0 flex-1 hover:opacity-90"
            >
              <div className="truncate text-xs font-bold hover:text-coral">{b.display_name || b.username}</div>
              <div className="truncate text-[10px] text-muted-foreground">
                {(b.roles && b.roles[0]) || "Builder"}
              </div>
              {b.bio && <div className="truncate text-[10px] text-muted-foreground">{b.bio}</div>}
            </Link>
            <FollowButton
              targetId={b.id}
              disabled={!user}
              onFollowed={() => qc.invalidateQueries({ queryKey: ["suggested-people"] })}
            />
          </div>
        ))}
      </div>
      <button
        onClick={() => { setOffset((x) => x + 3); if (!isFetching) refetch(); }}
        className="mt-3 flex items-center gap-1 text-[11px] font-semibold text-muted-foreground hover:text-foreground"
      >
        <RefreshCw className={`h-3 w-3 ${isFetching ? "animate-spin" : ""}`} /> Refresh suggestions
      </button>
    </Card>
  );
}


function FollowButton({
  targetId,
  disabled,
  onFollowed,
}: {
  targetId: string;
  disabled?: boolean;
  onFollowed?: () => void;
}) {
  const [f, setF] = useState(false);
  const mut = useMutation({
    mutationFn: async () => followUser(targetId),
    onSuccess: () => {
      setF(true);
      onFollowed?.();
    },
    onError: (e: any) => {
      if (String(e?.message).includes("Not signed in")) toast.error("Sign in to follow");
      else toast.error(e?.message || "Couldn't follow");
    },
  });
  return (
    <button
      onClick={() => { if (!f && !disabled) mut.mutate(); }}
      disabled={disabled || mut.isPending || f}
      className={`shrink-0 rounded-full border-[1.5px] px-2.5 py-1 text-[10px] font-bold disabled:opacity-70 ${
        f ? "border-[#0F0F0F] bg-[#0F0F0F] text-white" : "border-coral text-coral hover:bg-coral hover:text-white"
      }`}
    >
      {f ? "Following ✓" : "+ Follow"}
    </button>
  );
}


function MyCommunities() {
  const mine = communities.slice(0, 3);
  return (
    <Card className="p-4">
      <h3 className="font-display text-sm font-bold">My Communities</h3>
      <div className="mt-3 space-y-2.5">
        {mine.map((c, i) => (
          <Link key={c.id} to="/communities/$slug" params={{ slug: c.slug }} className="flex items-center gap-2.5 hover:opacity-80">
            <div className="grid h-6 w-6 shrink-0 place-items-center rounded border-[1.5px] border-[#0F0F0F] bg-surface text-xs">{c.icon}</div>
            <div className="min-w-0 flex-1 truncate text-xs font-semibold">{c.name}</div>
            <div className="flex shrink-0 items-center gap-1 text-[10px] text-muted-foreground">
              <span className={`h-1.5 w-1.5 rounded-full ${i < 2 ? "bg-green-500" : "bg-gray-400"}`} />
              {12 + i * 40}
            </div>
          </Link>
        ))}
      </div>
      <Link to="/communities" className="mt-3 block text-[11px] font-bold text-coral hover:underline">+ Discover Communities</Link>
    </Card>
  );
}
