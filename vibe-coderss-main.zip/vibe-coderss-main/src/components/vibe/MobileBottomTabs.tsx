import { Link, useLocation } from "@tanstack/react-router";
import { Home, Compass, Plus, Users, Bell } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { PostComposerModal } from "./PostComposerModal";

export function MobileBottomTabs() {
  const location = useLocation();
  const path = location.pathname;
  const { session, loading } = useAuth();
  const [sheet, setSheet] = useState(false);

  // Only show the bottom tab bar to signed-in users. Public/landing pages
  // stay chromeless on mobile.
  if (loading || !session) return null;


  const tabs = [
    { to: "/vibe", label: "Vibe", icon: Home, active: path === "/vibe" },
    { to: "/explore", label: "Explore", icon: Compass, active: path.startsWith("/explore") },
    { to: "/communities", label: "Communities", icon: Users, active: path.startsWith("/communities") },
    { to: "/notifications", label: "Alerts", icon: Bell, active: path.includes("/notifications"), dot: true },
  ] as const;

  return (
    <>
      <nav
        className="fixed inset-x-0 bottom-0 z-40 flex items-center justify-around border-t-[3px] border-[#0F0F0F] bg-[#FAF6F1] px-2 pt-2 lg:hidden"
        style={{ height: "calc(72px + env(safe-area-inset-bottom))", paddingBottom: "calc(12px + env(safe-area-inset-bottom))" }}
      >
        {tabs.slice(0, 2).map((t) => <TabItem key={t.label} {...t} />)}
        <div className="relative flex w-full justify-center">
          <button
            onClick={() => setSheet(true)}
            aria-label="Create post"
            className="absolute -top-9 grid h-14 w-14 shrink-0 place-items-center rounded-2xl border-[2.5px] border-[#0F0F0F] bg-coral text-white transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
            style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}
          >
            <Plus className="h-7 w-7" strokeWidth={3} />
          </button>
        </div>
        {tabs.slice(2).map((t) => <TabItem key={t.label} {...t} />)}
      </nav>
      {sheet && <PostSheet onClose={() => setSheet(false)} />}
    </>
  );
}

function TabItem({ to, label, icon: Icon, active, dot }: any) {
  return (
    <Link
      to={to}
      className={cn(
        "flex h-full w-full flex-col items-center justify-center gap-1 pt-1 transition-transform active:scale-95",
        active ? "text-coral" : "text-[#0F0F0F]/70"
      )}
    >
      <span className="relative grid h-6 w-6 place-items-center">
        <Icon className="h-[22px] w-[22px]" strokeWidth={active ? 2.5 : 2} fill={active ? "currentColor" : "none"} />
        {dot && (
          <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full border border-[#0F0F0F] bg-coral" />
        )}
      </span>
      <span className={cn("text-[10px] uppercase tracking-tight", active ? "font-bold" : "font-semibold")}>{label}</span>
    </Link>
  );
}

function PostSheet({ onClose }: { onClose: () => void }) {
  const [kind, setKind] = useState<null | "update" | "project" | "prompt" | "workflow" | "question" | "collab">(null);
  const opts: { label: string; icon: string; kind: "update" | "project" | "prompt" | "workflow" | "question" | "collab" }[] = [
    { label: "Post", icon: "📝", kind: "update" },
    { label: "Project", icon: "🖼", kind: "project" },
    { label: "Prompt", icon: "💡", kind: "prompt" },
    { label: "Workflow", icon: "⚙️", kind: "workflow" },
    { label: "Question", icon: "❓", kind: "question" },
    { label: "Collab", icon: "🤝", kind: "collab" },
  ];
  if (kind) {
    return <PostComposerModal kind={kind} onClose={onClose} />;
  }
  return (
    <div className="fixed inset-0 z-50 lg:hidden" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div
        className="absolute inset-x-0 bottom-0 rounded-t-2xl border-t-[1.5px] border-[#0F0F0F] bg-white p-5 pb-8 animate-slide-in-right"
        style={{ animation: "fade-in 200ms ease" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-[#0F0F0F]/20" />
        <h3 className="font-display text-lg font-bold">What do you want to drop?</h3>
        <div className="mt-4 grid grid-cols-2 gap-3">
          {opts.map((o) => (
            <button
              key={o.label}
              onClick={() => setKind(o.kind)}
              className="flex items-center gap-3 rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-3 text-left"
              style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
            >
              <span className="text-2xl">{o.icon}</span>
              <span className="text-sm font-bold">{o.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

