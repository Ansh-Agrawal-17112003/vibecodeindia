import { useMemo } from "react";
import { Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

type Story = {
  id: string;
  name: string;
  username: string;
  avatar: string;
  isLive?: boolean;
  hasNew?: boolean;
};

// Seeded story reel — represents active builders "shipping today".
const STORIES: Story[] = [
  { id: "s1", name: "Aditya", username: "aditya", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=aditya", isLive: true, hasNew: true },
  { id: "s2", name: "Priya", username: "priya", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=priya", hasNew: true },
  { id: "s3", name: "Rahul", username: "rahul", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=rahul", hasNew: true },
  { id: "s4", name: "Sneha", username: "sneha", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=sneha", isLive: true, hasNew: true },
  { id: "s5", name: "Ishaan", username: "ishaan", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=ishaan", hasNew: true },
  { id: "s6", name: "Meera", username: "meera", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=meera", hasNew: true },
  { id: "s7", name: "Kunal", username: "kunal", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=kunal" },
  { id: "s8", name: "Ananya", username: "ananya", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=ananya", hasNew: true },
  { id: "s9", name: "Vikram", username: "vikram", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=vikram" },
  { id: "s10", name: "Riya", username: "riya", avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=riya", hasNew: true },
];

export function StoriesRow({ mobile }: { mobile?: boolean }) {
  const { user } = useAuth();
  const myAvatar = useMemo(
    () =>
      (user as any)?.user_metadata?.avatar_url ||
      `https://api.dicebear.com/7.x/notionists/svg?seed=${user?.email ?? "you"}`,
    [user],
  );

  return (
    <div
      className={cn(
        "border-[1.5px] border-[#0F0F0F] bg-white",
        mobile ? "rounded-none border-x-0" : "rounded-xl",
      )}
      style={{ boxShadow: mobile ? "none" : "3px 3px 0 0 #0F0F0F" }}
    >
      <div className="flex items-center justify-between px-4 pt-3">
        <h3 className="font-display text-xs font-bold uppercase tracking-wider text-muted-foreground">
          🚀 Shipping today
        </h3>
        <Link to="/explore" search={{ mode: "real" }} className="text-[11px] font-bold text-coral hover:underline">
          See all
        </Link>
      </div>
      <div className="no-scrollbar flex gap-3 overflow-x-auto px-4 py-3">
        {/* Your story — add new */}
        <button
          type="button"
          className="group flex w-[64px] shrink-0 flex-col items-center gap-1"
          onClick={() => {
            const el = document.querySelector<HTMLTextAreaElement>("textarea");
            el?.focus();
          }}
        >
          <div className="relative">
            <img
              src={myAvatar}
              alt="Your story"
              className="h-14 w-14 rounded-full border-[1.5px] border-[#0F0F0F] object-cover"
            />
            <span className="absolute -bottom-0.5 -right-0.5 grid h-5 w-5 place-items-center rounded-full border-[1.5px] border-white bg-coral text-white">
              <Plus className="h-3 w-3" />
            </span>
          </div>
          <span className="truncate text-[10px] font-semibold">Your story</span>
        </button>

        {STORIES.map((s) => (
          <Link
            key={s.id}
            to="/u/$username"
            params={{ username: s.username }}
            className="group flex w-[64px] shrink-0 flex-col items-center gap-1"
          >
            <div
              className={cn(
                "relative rounded-full p-[2px]",
                s.hasNew
                  ? "bg-gradient-to-tr from-coral via-amber-400 to-fuchsia-500"
                  : "bg-[#E8E0D6]",
              )}
            >
              <img
                src={s.avatar}
                alt={s.name}
                className="h-14 w-14 rounded-full border-[1.5px] border-white object-cover"
              />
              {s.isLive && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 rounded-full border border-white bg-red-500 px-1.5 text-[8px] font-black uppercase tracking-wider text-white">
                  Live
                </span>
              )}
            </div>
            <span className="truncate text-[10px] font-semibold group-hover:text-coral">
              {s.name}
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
