import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Search, SlidersHorizontal, Sparkles, Image as ImageIcon, Lightbulb, Workflow as WorkflowIcon, HelpCircle, MessageSquare, MessageCircle, LayoutDashboard, User as UserIcon, Bookmark, Trophy, BarChart3, Settings as SettingsIcon, LogOut, Home, Compass, Users, Briefcase, Wrench, FolderGit2, Package, LayoutTemplate, BookOpen, Bell, PlusCircle, Rocket, Bookmark as BookmarkIcon } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { LeftPane } from "./LeftPane";
import { RightPane, NewsCard } from "./RightPane";
import { LiveFeed } from "./LiveFeed";
import { useAuth } from "@/hooks/useAuth";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import type { PostType } from "@/lib/vibe-feed-seed";

type FilterKey = PostType | "all";

const FILTERS: { k: FilterKey; label: string; icon: any }[] = [
  { k: "all", label: "All", icon: Sparkles },
  { k: "project", label: "Projects", icon: ImageIcon },
  { k: "prompt", label: "Prompts", icon: Lightbulb },
  { k: "workflow", label: "Workflows", icon: WorkflowIcon },
  { k: "question", label: "Questions", icon: HelpCircle },
  { k: "update", label: "Updates", icon: MessageSquare },
];

export function VibeHome() {
  const { user } = useAuth();
  const avatar = (user as any)?.user_metadata?.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${user?.email ?? "guest"}`;
  const displayName = (user as any)?.user_metadata?.full_name || user?.email?.split("@")[0] || "You";
  const [openFilters, setOpenFilters] = useState(false);
  const [openMenu, setOpenMenu] = useState(false);
  const [filter, setFilter] = useState<FilterKey>("all");

  const exploreItems = [
    { to: "/", label: "Vibe", icon: Home },
    { to: "/explore", label: "Explore", icon: Compass },
    { to: "/communities", label: "Communities", icon: Users },
    { to: "/jobs", label: "Jobs", icon: Briefcase },
    { to: "/services", label: "Services", icon: Wrench },
    { to: "/projects", label: "Projects", icon: FolderGit2 },
    { to: "/prompts", label: "Prompts", icon: Lightbulb },
    { to: "/workflows", label: "Workflows", icon: WorkflowIcon },
    { to: "/tools", label: "Tools", icon: Package },
    { to: "/templates", label: "Templates", icon: LayoutTemplate },
    { to: "/blog", label: "Blog", icon: BookOpen },
  ] as const;

  const accountItems = [
    { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { to: "/u/$username", params: { username: (user as any)?.user_metadata?.username ?? "me" }, label: "My Profile", icon: UserIcon },
    { to: "/notifications", label: "Notifications", icon: Bell },
    { to: "/messages", label: "Messages", icon: MessageCircle },
    { to: "/saved", label: "Saved", icon: Bookmark },
    { to: "/saved-jobs", label: "Saved Jobs", icon: BookmarkIcon },
    { to: "/rewards", label: "Rewards", icon: Trophy },
    { to: "/analytics", label: "Analytics", icon: BarChart3 },
    { to: "/settings", label: "Settings", icon: SettingsIcon },
  ] as const;

  return (
    <Shell hideFooter mobileChromeless>
      {/* Desktop 3-col — app shell: only the center feed scrolls */}
      <div className="hidden h-[calc(100vh-64px)] overflow-hidden lg:block">
        <div className="mx-auto grid h-full max-w-[1200px] grid-cols-[240px_minmax(0,560px)_300px] gap-6 px-4">
          <div className="h-full overflow-y-auto no-scrollbar py-4">
            <LeftPane />
          </div>
          <div className="h-full overflow-y-auto py-4">
            <LiveFeed />
          </div>
          <div className="h-full overflow-y-auto no-scrollbar py-4">
            <RightPane />
          </div>
        </div>
      </div>

      {/* Mobile immersive feed */}
      <div className="lg:hidden">
        {/* Sticky top bar: profile avatar + search + filter + chat */}
        <div className="sticky top-0 z-30 w-full overflow-x-hidden border-b-[1.5px] border-[#0F0F0F] bg-background/95 px-2 py-2 backdrop-blur">
          <div className="flex w-full min-w-0 items-center gap-1.5">
            <button
              type="button"
              onClick={() => setOpenMenu(true)}
              aria-label="Open menu"
              className="grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full border-[1.5px] border-[#0F0F0F] bg-card"
              style={{ boxShadow: "1px 1px 0 0 #0F0F0F" }}
            >
              <img src={avatar} alt="" className="h-full w-full" />
            </button>
            <Link
              to="/search"
              className="flex min-w-0 flex-1 items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2"
              style={{ boxShadow: "1px 1px 0 0 #0F0F0F" }}
            >
              <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
              <span className="truncate text-sm text-muted-foreground">Search builders, prompts, jobs…</span>
            </Link>
            <button
              type="button"
              onClick={() => setOpenFilters(true)}
              aria-label="Filter feed"
              className="relative grid h-9 w-9 shrink-0 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white"
              style={{ boxShadow: "1px 1px 0 0 #0F0F0F" }}
            >
              <SlidersHorizontal className="h-4 w-4" />
              {filter !== "all" && (
                <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border border-[#0F0F0F] bg-coral" />
              )}
            </button>
            <Link
              to="/messages"
              aria-label="Messages"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white"
              style={{ boxShadow: "1px 1px 0 0 #0F0F0F" }}
            >
              <MessageCircle className="h-4 w-4" />
            </Link>
          </div>
        </div>

        <div className="bg-surface pb-4">
          <LiveFeed mobile />
        </div>

        <Sheet open={openFilters} onOpenChange={setOpenFilters}>
          <SheetContent side="bottom" className="rounded-t-2xl border-t-[1.5px] border-[#0F0F0F] p-0">
            <SheetHeader className="border-b-[1.5px] border-[#0F0F0F]/10 px-5 py-4 text-left">
              <SheetTitle className="text-base font-black">Filter feed</SheetTitle>
              <p className="text-xs text-muted-foreground">Choose what you want to see. Feed auto-adjusts based on engagement.</p>
            </SheetHeader>
            <div className="grid grid-cols-2 gap-2 p-4">
              {FILTERS.map((f) => {
                const Icon = f.icon;
                const active = filter === f.k;
                return (
                  <button
                    key={f.k}
                    onClick={() => {
                      setFilter(f.k);
                      setOpenFilters(false);
                    }}
                    className={cn(
                      "flex items-center gap-2 rounded-xl border-[1.5px] border-[#0F0F0F] px-3 py-3 text-sm font-bold transition-all",
                      active ? "bg-coral text-white" : "bg-white text-foreground",
                    )}
                    style={{ boxShadow: active ? "3px 3px 0 0 #0F0F0F" : "2px 2px 0 0 #0F0F0F" }}
                  >
                    <Icon className="h-4 w-4" />
                    {f.label}
                  </button>
                );
              })}
            </div>
          </SheetContent>
        </Sheet>

        <Sheet open={openMenu} onOpenChange={setOpenMenu}>
          <SheetContent side="left" className="flex w-[300px] flex-col border-r-[1.5px] border-[#0F0F0F] bg-background p-0">
            <div className="flex items-center gap-3 border-b-[1.5px] border-[#0F0F0F] p-4">
              <div
                className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-full border-[1.5px] border-[#0F0F0F] bg-card"
                style={{ boxShadow: "1px 1px 0 0 #0F0F0F" }}
              >
                <img src={avatar} alt="" className="h-full w-full" />
              </div>
              <div className="min-w-0">
                <div className="truncate text-sm font-bold">{displayName}</div>
                <div className="truncate text-xs text-muted-foreground">{user?.email}</div>
              </div>
            </div>

            <nav className="flex-1 overflow-y-auto p-3">
              <div className="mb-1 px-3 text-[10px] font-black uppercase tracking-wider text-muted-foreground">Explore</div>
              <div className="flex flex-col gap-0.5">
                {exploreItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.label}
                      to={item.to as any}
                      onClick={() => setOpenMenu(false)}
                      className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-surface"
                    >
                      <Icon className="h-4 w-4" />
                      {item.label}
                    </Link>
                  );
                })}
              </div>

              <div className="mb-1 mt-4 px-3 text-[10px] font-black uppercase tracking-wider text-muted-foreground">Account</div>
              <div className="flex flex-col gap-0.5">
                {accountItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.label}
                      to={item.to as any}
                      params={("params" in item ? (item as any).params : undefined) as any}
                      onClick={() => setOpenMenu(false)}
                      className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-surface"
                    >
                      <Icon className="h-4 w-4" />
                      {item.label}
                    </Link>
                  );
                })}
              </div>

              <div className="mb-1 mt-4 flex flex-col gap-2 px-1">
                <Link
                  to="/early-access"
                  onClick={() => setOpenMenu(false)}
                  className="flex items-center justify-center gap-2 rounded-xl border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-2.5 text-sm font-extrabold text-white"
                  style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                >
                  <Rocket className="h-4 w-4" />
                  Join Early Access
                </Link>
                <Link
                  to="/submit"
                  onClick={() => setOpenMenu(false)}
                  className="flex items-center justify-center gap-2 rounded-xl border-[1.5px] border-[#0F0F0F] bg-gold px-3 py-2.5 text-sm font-extrabold text-[#0F0F0F]"
                  style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                >
                  <PlusCircle className="h-4 w-4" />
                  Submit
                </Link>
              </div>
            </nav>

            <button
              type="button"
              onClick={async () => {
                setOpenMenu(false);
                await supabase.auth.signOut();
              }}
              className="flex items-center gap-3 border-t-[1.5px] border-[#0F0F0F]/10 px-5 py-3 text-left text-sm font-semibold text-error hover:bg-error/5"
            >
              <LogOut className="h-4 w-4" />
              Sign out
            </button>
          </SheetContent>
        </Sheet>
      </div>
    </Shell>
  );
}
