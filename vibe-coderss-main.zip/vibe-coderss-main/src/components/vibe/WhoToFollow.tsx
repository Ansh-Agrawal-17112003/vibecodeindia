import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Loader2, UserPlus, Sparkles } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { listSuggestedPeople, followUser, type SuggestedPerson } from "@/lib/people-api";

/**
 * Persistent onboarding-style widget shown only to signed-in users whose
 * following_count is < 5. Pre-checks 5 suggestions matched on the user's tools
 * and lets them Follow All in one tap — accelerates the social graph so the
 * feed stops feeling empty within the first session.
 */
export function WhoToFollow() {
  const qc = useQueryClient();
  const { user } = useAuth();

  const { data: me } = useQuery({
    queryKey: ["me-follow-gate", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, following_count, tools")
        .eq("id", user!.id)
        .maybeSingle();
      return data as { id: string; following_count: number | null; tools: string[] | null } | null;
    },
    staleTime: 30_000,
  });

  const { data: pool = [], isLoading } = useQuery({
    queryKey: ["who-to-follow-pool"],
    enabled: !!user && (me?.following_count ?? 0) < 5,
    queryFn: () => listSuggestedPeople(20),
    staleTime: 120_000,
  });

  const suggestions = useMemo<SuggestedPerson[]>(() => {
    if (!pool.length) return [];
    const tools = (me?.tools ?? []).map((t) => t.toLowerCase());
    const scored = pool.map((p) => {
      const hay = `${p.bio ?? ""} ${(p.roles ?? []).join(" ")}`.toLowerCase();
      const overlap = tools.reduce((n, t) => n + (t && hay.includes(t) ? 1 : 0), 0);
      return { p, overlap };
    });
    scored.sort((a, b) => b.overlap - a.overlap || (b.p.follower_count ?? 0) - (a.p.follower_count ?? 0));
    return scored.slice(0, 5).map((s) => s.p);
  }, [pool, me?.tools]);

  const [checked, setChecked] = useState<Record<string, boolean>>({});
  const [followedIds, setFollowedIds] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  const initialChecked = useMemo(() => {
    const o: Record<string, boolean> = {};
    suggestions.forEach((s) => { o[s.id] = true; });
    return o;
  }, [suggestions]);

  const effective = { ...initialChecked, ...checked };

  const followAll = useMutation({
    mutationFn: async () => {
      const ids = suggestions.filter((s) => effective[s.id] && !followedIds.has(s.id)).map((s) => s.id);
      setBusy(true);
      let ok = 0;
      for (const id of ids) {
        try { await followUser(id); ok++; } catch { /* skip */ }
      }
      return { ok, total: ids.length };
    },
    onSuccess: ({ ok }) => {
      setFollowedIds((prev) => {
        const next = new Set(prev);
        suggestions.forEach((s) => { if (effective[s.id]) next.add(s.id); });
        return next;
      });
      toast.success(ok > 0 ? `Following ${ok} builder${ok === 1 ? "" : "s"} — your feed just got better` : "Nothing to follow");
      qc.invalidateQueries({ queryKey: ["me-follow-gate"] });
      qc.invalidateQueries({ queryKey: ["suggested-people"] });
    },
    onError: (e: any) => toast.error(e?.message || "Couldn't follow"),
    onSettled: () => setBusy(false),
  });

  if (!user) return null;
  if (me && (me.following_count ?? 0) >= 5) return null;

  return (
    <div
      className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-4"
      style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
    >
      <div className="flex items-center gap-1.5">
        <Sparkles className="h-3.5 w-3.5 text-coral" />
        <h3 className="font-display text-sm font-bold">Level up your feed</h3>
      </div>
      <p className="mt-0.5 text-[11px] text-muted-foreground">
        Follow 5 builders and your Vibe home stops feeling empty.
      </p>

      <div className="mt-3 space-y-2.5">
        {isLoading && (
          <div className="grid place-items-center py-4 text-[11px] text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
          </div>
        )}
        {!isLoading && suggestions.length === 0 && (
          <div className="text-[11px] text-muted-foreground">No suggestions right now.</div>
        )}
        {suggestions.map((b) => {
          const isChecked = effective[b.id] ?? true;
          const isFollowed = followedIds.has(b.id);
          return (
            <label
              key={b.id}
              className={`flex cursor-pointer items-center gap-2.5 rounded-lg border-[1.5px] px-2 py-1.5 transition-colors ${
                isFollowed ? "border-[#0F0F0F] bg-[#0F0F0F]/5" : isChecked ? "border-coral/40 bg-coral/5" : "border-[#0F0F0F]/10"
              }`}
            >
              <input
                type="checkbox"
                className="h-4 w-4 shrink-0 accent-[#F07A54]"
                checked={isChecked}
                disabled={isFollowed || busy}
                onChange={(e) => setChecked((c) => ({ ...c, [b.id]: e.target.checked }))}
              />
              <Link
                to="/u/$username"
                params={{ username: b.username || "" }}
                className="shrink-0"
                onClick={(e) => e.stopPropagation()}
              >
                <img
                  src={b.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${b.username || b.id}`}
                  alt=""
                  className="h-8 w-8 rounded-full border-[1.5px] border-[#0F0F0F] object-cover"
                />
              </Link>
              <div className="min-w-0 flex-1">
                <div className="truncate text-xs font-bold">{b.display_name || b.username}</div>
                <div className="truncate text-[10px] text-muted-foreground">
                  {(b.roles && b.roles[0]) || b.bio || "Builder"}
                </div>
              </div>
              {isFollowed && (
                <span className="shrink-0 text-[10px] font-bold text-green-600">Following ✓</span>
              )}
            </label>
          );
        })}
      </div>

      {suggestions.length > 0 && (
        <button
          onClick={() => followAll.mutate()}
          disabled={busy || suggestions.every((s) => followedIds.has(s.id))}
          className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-full bg-coral py-2 text-xs font-bold text-white shadow-[2px_2px_0_0_#0F0F0F] transition-transform hover:-translate-y-0.5 disabled:opacity-70"
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <UserPlus className="h-3.5 w-3.5" />}
          Follow selected
        </button>
      )}
    </div>
  );
}
