import { useEffect, useMemo, useRef, useState } from "react";
import { Search, Image, Lightbulb, Workflow, HelpCircle } from "lucide-react";
import { VibeFeedCard } from "./VibeFeedCard";
import { SEED_POSTS, makeInfinitePage, shuffleFeed, type FeedPost, type PostType } from "@/lib/vibe-feed-seed";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { subscribeNewPost } from "@/lib/vibe-feed-store";
import { PostComposerModal } from "./PostComposerModal";

// Auto-mixed algorithmic feed: interleaves types and boosts high-engagement posts.
function autoMix(list: FeedPost[]): FeedPost[] {
  const score = (p: FeedPost) => {
    const r = p.reactions;
    return (r.like + r.fire * 2 + r.celebrate + r.insightful * 1.5 + r.support) + p.comments * 3 + p.shares * 4;
  };
  const buckets: Record<string, FeedPost[]> = {};
  [...list].sort((a, b) => score(b) - score(a)).forEach((p) => {
    (buckets[p.type] ||= []).push(p);
  });
  const order = ["project", "prompt", "workflow", "update", "question"];
  const out: FeedPost[] = [];
  let added = true;
  while (added) {
    added = false;
    for (const t of order) {
      const b = buckets[t];
      if (b && b.length) { out.push(b.shift()!); added = true; }
    }
  }
  return out;
}

export function CenterFeed({ mobile, filterType = "all" }: { mobile?: boolean; filterType?: PostType | "all" }) {
  const { user } = useAuth();
  const [posts, setPosts] = useState<FeedPost[]>(() => autoMix(SEED_POSTS).slice(0, 12));
  const [loading, setLoading] = useState(false);
  const sentinel = useRef<HTMLDivElement>(null);
  const [refreshing, setRefreshing] = useState(false);
  const pullY = useRef(0);
  const [pullDist, setPullDist] = useState(0);

  const visiblePosts = useMemo(
    () => (filterType === "all" ? posts : posts.filter((p) => p.type === filterType)),
    [posts, filterType],
  );

  useEffect(() => {
    if (!sentinel.current) return;
    const io = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !loading) {
        setLoading(true);
        window.setTimeout(() => {
          setPosts((p) => [...p, ...makeInfinitePage(p.length, 10)]);
          setLoading(false);
        }, 400);
      }
    }, { rootMargin: "400px" });
    io.observe(sentinel.current);
    return () => io.disconnect();
  }, [loading]);

  // random reaction bumps (visual live-feel)
  useEffect(() => {
    const t = setInterval(() => {
      setPosts((prev) => {
        if (!prev.length) return prev;
        const idx = Math.floor(Math.random() * Math.min(5, prev.length));
        const keys = ["like", "fire", "insightful"] as const;
        const k = keys[Math.floor(Math.random() * keys.length)];
        const inc = 1 + Math.floor(Math.random() * 3);
        const copy = [...prev];
        copy[idx] = { ...copy[idx], reactions: { ...copy[idx].reactions, [k]: (copy[idx].reactions as any)[k] + inc } };
        return copy;
      });
    }, 45000 + Math.random() * 45000);
  }, []);

  useEffect(() => {
    return subscribeNewPost((p) => setPosts((prev) => [p, ...prev]));
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    window.setTimeout(() => {
      setPosts(autoMix(shuffleFeed(SEED_POSTS)).slice(0, 12));
      setRefreshing(false);
      setPullDist(0);
      toast.success("Feed refreshed");
    }, 700);
  };

  // pull-to-refresh (mobile)
  const onTouchStart = (e: React.TouchEvent) => {
    if (window.scrollY <= 0) pullY.current = e.touches[0].clientY;
  };
  const onTouchMove = (e: React.TouchEvent) => {
    if (pullY.current === 0) return;
    const d = e.touches[0].clientY - pullY.current;
    if (d > 0) setPullDist(Math.min(80, d));
  };
  const onTouchEnd = () => {
    if (pullDist > 60) handleRefresh();
    else setPullDist(0);
    pullY.current = 0;
  };

  return (
    <div
      className={cn("min-h-[70vh]", mobile ? "px-0" : "px-1")}
      onTouchStart={mobile ? onTouchStart : undefined}
      onTouchMove={mobile ? onTouchMove : undefined}
      onTouchEnd={mobile ? onTouchEnd : undefined}
    >
      {mobile && pullDist > 0 && (
        <div className="grid place-items-center py-2 text-xs text-muted-foreground" style={{ height: pullDist }}>
          {refreshing ? "Refreshing…" : pullDist > 60 ? "Release to refresh" : "Pull to refresh"}
        </div>
      )}

      {/* search (desktop only inside feed) */}
      {!mobile && (
        <div className="mb-4">
          <div className="flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-4 py-2.5" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
            <Search className="h-4 w-4 text-muted-foreground" />
            <input className="flex-1 bg-transparent text-sm outline-none" placeholder="Search builders, prompts, projects, jobs…" />
          </div>
        </div>
      )}

      {/* composer (desktop only) */}
      {!mobile && <PostComposer mobile={mobile} />}

      {/* feed */}
      <div className={cn("space-y-3", mobile ? "mt-0" : "mt-4 space-y-4") }>
        {visiblePosts.map((p) => (
          <div key={p.id} className={mobile ? "" : ""}>
            <VibeFeedCard post={p} mobile={mobile} />
          </div>
        ))}
        {visiblePosts.length === 0 && (
          <div className="grid place-items-center py-16 text-sm text-muted-foreground">
            No posts match this filter yet.
          </div>
        )}
        {loading && (
          <>
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-64 animate-pulse rounded-xl border-[1.5px] border-[#0F0F0F]/10 bg-white" />
            ))}
          </>
        )}
        <div ref={sentinel} className="h-4" />
      </div>
    </div>
  );
}

function PostComposer({ mobile }: { mobile?: boolean }) {
  const { user } = useAuth();
  const [text, setText] = useState("");
  const [composer, setComposer] = useState<null | "project" | "prompt" | "workflow" | "update" | "question">(null);
  const avatar = (user as any)?.user_metadata?.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${user?.email ?? "guest"}`;
  return (
    <div className={cn("border-[1.5px] border-[#0F0F0F] bg-white", mobile ? "rounded-none" : "rounded-xl")} style={{ boxShadow: mobile ? "none" : "3px 3px 0 0 #0F0F0F" }}>
      {!mobile && (
        <div className="flex items-center gap-3 p-4">
          <img src={avatar} alt="" className="h-10 w-10 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]" />
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onFocus={() => setComposer("update")}
            placeholder="What are you building today?"
            className="flex-1 rounded-full border-[1.5px] border-[#0F0F0F]/20 bg-surface px-4 py-2 text-sm outline-none focus:border-coral"
          />
        </div>
      )}
      <div className="grid grid-cols-4 border-t-[1.5px] border-[#0F0F0F]/10">
        <ComposerAction icon={<Image className="h-4 w-4" />} label="Project" onClick={() => setComposer("project")} />
        <ComposerAction icon={<Lightbulb className="h-4 w-4" />} label="Prompt" onClick={() => setComposer("prompt")} />
        <ComposerAction icon={<Workflow className="h-4 w-4" />} label="Workflow" onClick={() => setComposer("workflow")} />
        <ComposerAction icon={<HelpCircle className="h-4 w-4" />} label="Question" onClick={() => setComposer("question")} />
      </div>
      {composer && <PostComposerModal kind={composer} onClose={() => { setComposer(null); setText(""); }} />}
    </div>
  );
}

function ComposerAction({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface"
    >
      <span className="text-coral">{icon}</span> {label}
    </button>
  );
}

