import { useEffect, useRef, useState } from "react";
import { X, Image as ImageIcon, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { uploadPostImage } from "@/lib/feed-api";

export type ComposerKind = "update" | "project" | "prompt" | "workflow" | "question" | "collab";

const MAX_CHARS = 2000;
const MAX_IMAGES = 4;

const CONFIG: Record<ComposerKind, { title: string; placeholder: string; cta: string }> = {
  update: { title: "Create a post", placeholder: "What are you building today? Share an update, a win, a lesson…", cta: "Post" },
  project: { title: "Share a project", placeholder: "What did you build? What problem does it solve?", cta: "Ship project" },
  prompt: { title: "Share a prompt", placeholder: "What does this prompt do and who is it for?", cta: "Publish prompt" },
  workflow: { title: "Share a workflow", placeholder: "Describe the automation and what it saves.", cta: "Publish workflow" },
  question: { title: "Ask the community", placeholder: "Ask a clear, specific question…", cta: "Ask" },
  collab: { title: "Find a collaborator", placeholder: "Who are you looking for? Skills, scope, time commitment…", cta: "Post collab" },
};

export function PostComposerModal({ kind, onClose }: { kind: ComposerKind; onClose: () => void }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const cfg = CONFIG[kind];

  const [body, setBody] = useState("");
  const [title, setTitle] = useState("");
  const [tools, setTools] = useState("");
  const [demoUrl, setDemoUrl] = useState("");
  const [githubUrl, setGithubUrl] = useState("");
  const [model, setModel] = useState("GPT-4o");
  const [category, setCategory] = useState("");
  const [promptBody, setPromptBody] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && !submitting && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [onClose, submitting]);

  useEffect(() => {
    const urls = files.map((f) => URL.createObjectURL(f));
    setPreviews(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
  }, [files]);

  const showTitle = kind === "project" || kind === "workflow" || kind === "prompt";
  const showImages = kind === "update" || kind === "project" || kind === "collab" || kind === "question";

  const onPickFiles = (list: FileList | null) => {
    if (!list) return;
    const incoming = Array.from(list).filter((f) => f.type.startsWith("image/"));
    const next = [...files, ...incoming].slice(0, MAX_IMAGES);
    setFiles(next);
  };

  const validate = (): string | null => {
    if (!user) return "Please sign in to post.";
    if (body.length > MAX_CHARS) return `Keep it under ${MAX_CHARS} characters.`;
    if (kind === "prompt") {
      if (!title.trim()) return "Give your prompt a title.";
      if (!promptBody.trim()) return "Paste the prompt text.";
      return null;
    }
    if (kind === "project" || kind === "workflow") {
      if (!title.trim()) return `Give your ${kind} a title.`;
      if (!body.trim()) return `Describe your ${kind}.`;
      return null;
    }
    if (!body.trim() && files.length === 0) return "Say something or add an image.";
    return null;
  };

  const submit = async () => {
    const err = validate();
    if (err) { toast.error(err); return; }
    setSubmitting(true);
    try {
      // Upload images first (if any). Reused for both feed posts and project covers.
      const imageUrls: string[] = [];
      for (const f of files) {
        const url = await uploadPostImage(f);
        imageUrls.push(url);
      }

      if (kind === "project") {
        const toolsArr = tools.split(",").map((s) => s.trim()).filter(Boolean);
        const { error } = await (supabase.from("projects") as any).insert({
          builder_id: user!.id,
          title: title.trim(),
          problem_solved: null,
          solution: body.trim() || null,
          tools_used: toolsArr,
          live_demo_url: demoUrl.trim() || null,
          github_url: githubUrl.trim() || null,
          cover_image_url: imageUrls[0] ?? null,
        });
        if (error) throw error;
      } else if (kind === "prompt") {
        const { error } = await (supabase.from("prompts") as any).insert({
          author_id: user!.id,
          title: title.trim(),
          model,
          category: category.trim() || null,
          body: promptBody.trim(),
          preview: body.trim() || null,
        });
        if (error) throw error;
      } else if (kind === "workflow") {
        const toolsArr = tools.split(",").map((s) => s.trim()).filter(Boolean);
        const { error } = await (supabase.from("workflows") as any).insert({
          author_id: user!.id,
          title: title.trim(),
          category: category.trim() || null,
          description: body.trim(),
          tools: toolsArr,
          cover_image_url: imageUrls[0] ?? null,
        });
        if (error) throw error;
      } else {
        // update / question / collab — direct feed post
        const prefix = kind === "question" ? "❓ " : kind === "collab" ? "🤝 Looking to collab — " : "";
        const bodyText = `${prefix}${body.trim()}`.slice(0, MAX_CHARS);
        const postKind = imageUrls.length ? "image" : "text";
        const { error } = await (supabase.from("posts") as any).insert({
          author_id: user!.id,
          kind: postKind,
          body: bodyText || null,
          image_urls: imageUrls,
        });
        if (error) throw error;
      }

      toast.success(kind === "project" ? "Project shipped!" : kind === "prompt" ? "Prompt published!" : kind === "workflow" ? "Workflow published!" : "Posted!");
      // Refresh feed + the dedicated listing pages if user is on one.
      qc.invalidateQueries({ queryKey: ["feed"] });
      qc.invalidateQueries({ queryKey: ["projects"] });
      qc.invalidateQueries({ queryKey: ["prompts"] });
      qc.invalidateQueries({ queryKey: ["workflows"] });
      onClose();
    } catch (e: any) {
      toast.error(e?.message || "Couldn't post. Try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const charsLeft = MAX_CHARS - body.length;

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center" onClick={() => !submitting && onClose()}>
      <div className="absolute inset-0 bg-black/50" />
      <div
        className="relative flex max-h-[92vh] w-full max-w-lg flex-col rounded-t-2xl border-[1.5px] border-[#0F0F0F] bg-white sm:rounded-2xl"
        style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b-[1.5px] border-[#0F0F0F]/10 p-4">
          <h3 className="font-display text-lg font-bold">{cfg.title}</h3>
          <button
            onClick={onClose}
            disabled={submitting}
            className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card disabled:opacity-50"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {showTitle && (
            <Field label="Title">
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value.slice(0, 120))}
                placeholder={kind === "project" ? "My awesome project" : kind === "prompt" ? "Killer research prompt" : "My workflow"}
                className="composer-input"
              />
            </Field>
          )}

          <Field label={kind === "prompt" ? "Short pitch" : "What's on your mind?"}>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value.slice(0, MAX_CHARS))}
              placeholder={cfg.placeholder}
              rows={kind === "update" || kind === "question" || kind === "collab" ? 6 : 4}
              className="composer-input resize-none"
            />
            <div className={`mt-1 text-right text-[11px] ${charsLeft < 100 ? "text-coral" : "text-muted-foreground"}`}>
              {charsLeft} characters left
            </div>
          </Field>

          {kind === "prompt" && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Model">
                  <select value={model} onChange={(e) => setModel(e.target.value)} className="composer-input">
                    {["GPT-4o", "GPT-4", "Claude", "Gemini", "Llama", "Other"].map((m) => <option key={m}>{m}</option>)}
                  </select>
                </Field>
                <Field label="Category">
                  <input value={category} onChange={(e) => setCategory(e.target.value.slice(0, 40))} placeholder="e.g. research" className="composer-input" />
                </Field>
              </div>
              <Field label="Prompt text">
                <textarea
                  value={promptBody}
                  onChange={(e) => setPromptBody(e.target.value.slice(0, 8000))}
                  rows={6}
                  placeholder="Paste the full prompt…"
                  className="composer-input resize-none font-mono text-xs"
                />
              </Field>
            </>
          )}

          {(kind === "project" || kind === "workflow") && (
            <Field label="Tools (comma separated)">
              <input value={tools} onChange={(e) => setTools(e.target.value)} placeholder="Lovable, Supabase, n8n" className="composer-input" />
            </Field>
          )}

          {kind === "workflow" && (
            <Field label="Category">
              <input value={category} onChange={(e) => setCategory(e.target.value.slice(0, 40))} placeholder="e.g. sales, ops" className="composer-input" />
            </Field>
          )}

          {kind === "project" && (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Demo URL">
                <input value={demoUrl} onChange={(e) => setDemoUrl(e.target.value)} placeholder="https://…" className="composer-input" />
              </Field>
              <Field label="GitHub URL">
                <input value={githubUrl} onChange={(e) => setGithubUrl(e.target.value)} placeholder="https://github.com/…" className="composer-input" />
              </Field>
            </div>
          )}

          {showImages && (
            <div>
              <div className="mb-1 text-xs font-bold uppercase tracking-wide text-[#0F0F0F]/70">
                Images {kind === "project" && <span className="text-[10px] font-normal text-muted-foreground">(first image = cover)</span>}
              </div>
              {previews.length > 0 && (
                <div className="mb-2 grid grid-cols-4 gap-2">
                  {previews.map((src, i) => (
                    <div key={src} className="relative overflow-hidden rounded-lg border-[1.5px] border-[#0F0F0F]/30">
                      <img src={src} alt="" className="aspect-square w-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setFiles(files.filter((_, idx) => idx !== i))}
                        className="absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-black/70 text-white"
                        aria-label="Remove image"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              {files.length < MAX_IMAGES && (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F]/25 bg-white px-3 py-1.5 text-xs font-bold hover:bg-surface"
                >
                  <ImageIcon className="h-3.5 w-3.5 text-coral" /> Add image ({files.length}/{MAX_IMAGES})
                </button>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => { onPickFiles(e.target.files); e.target.value = ""; }}
              />
            </div>
          )}

          <p className="text-[11px] text-muted-foreground">Tip: add <span className="font-mono">#tags</span> in your text to categorize.</p>
        </div>

        <div className="flex items-center justify-end gap-2 border-t-[1.5px] border-[#0F0F0F]/10 p-4">
          <button
            onClick={onClose}
            disabled={submitting}
            className="rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-4 py-2 text-sm font-bold disabled:opacity-50"
            style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
          >
            Cancel
          </button>
          <button
            onClick={submit}
            disabled={submitting}
            className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-4 py-2 text-sm font-bold text-white disabled:opacity-60"
            style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
          >
            {submitting && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {cfg.cta}
          </button>
        </div>
      </div>

      <style>{`.composer-input{width:100%;border:1.5px solid #0F0F0F33;border-radius:10px;padding:8px 12px;font-size:14px;background:#fff;outline:none}.composer-input:focus{border-color:#E8623A}`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-bold uppercase tracking-wide text-[#0F0F0F]/70">{label}</span>
      {children}
    </label>
  );
}
