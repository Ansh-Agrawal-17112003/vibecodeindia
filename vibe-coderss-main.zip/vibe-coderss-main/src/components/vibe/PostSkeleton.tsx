import { cn } from "@/lib/utils";

export function PostSkeleton({ mobile }: { mobile?: boolean }) {
  return (
    <div
      className={cn(
        "animate-pulse border-[1.5px] border-[#0F0F0F]/20 bg-white",
        mobile ? "rounded-none" : "rounded-2xl",
      )}
      style={{ boxShadow: mobile ? "none" : "3px 3px 0 0 rgba(15,15,15,0.15)" }}
    >
      <div className="flex items-start gap-3 p-4">
        <div className="h-10 w-10 shrink-0 rounded-full bg-[#E8E0D6]" />
        <div className="flex-1 space-y-2">
          <div className="h-3 w-1/3 rounded bg-[#E8E0D6]" />
          <div className="h-2.5 w-1/2 rounded bg-[#F0EAE0]" />
        </div>
        <div className="h-5 w-16 rounded-full bg-[#F0EAE0]" />
      </div>
      <div className="space-y-2 px-4 pb-3">
        <div className="h-3 w-full rounded bg-[#F0EAE0]" />
        <div className="h-3 w-11/12 rounded bg-[#F0EAE0]" />
        <div className="h-3 w-2/3 rounded bg-[#F0EAE0]" />
      </div>
      <div className="mx-4 mb-3 aspect-video rounded-xl bg-[#E8E0D6]" />
      <div className="grid grid-cols-4 border-t-[1.5px] border-[#0F0F0F]/10">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="flex items-center justify-center py-2.5">
            <div className="h-3 w-14 rounded bg-[#F0EAE0]" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function FeedSkeleton({ mobile, count = 3 }: { mobile?: boolean; count?: number }) {
  return (
    <div className={cn("space-y-3", !mobile && "space-y-4")}>
      {Array.from({ length: count }).map((_, i) => (
        <PostSkeleton key={i} mobile={mobile} />
      ))}
    </div>
  );
}
