import { useMemo, useState } from "react";
import { Heart, MessageSquare, Share2, Repeat2, Sparkles, Zap, Workflow as WorkflowIcon, HelpCircle, ThumbsUp } from "lucide-react";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";
import type { FeedPost } from "@/lib/vibe-feed-seed";
import { getBuilder } from "@/lib/vibe-feed-seed";
import { builders } from "@/lib/mock-data";
import { cn } from "@/lib/utils";
import { xpToastFirstCopy } from "@/lib/xp-toast";

const TYPE_META: Record<FeedPost["type"], { icon: any; label: string; tint: string }> = {
  project: { icon: Sparkles, label: "Project", tint: "bg-coral/10 text-coral" },
  prompt: { icon: Zap, label: "Prompt", tint: "bg-amber-500/10 text-amber-700" },
  workflow: { icon: WorkflowIcon, label: "Workflow", tint: "bg-teal-500/10 text-teal-700" },
  question: { icon: HelpCircle, label: "Question", tint: "bg-violet-500/10 text-violet-700" },
  update: { icon: Sparkles, label: "Update", tint: "bg-blue-500/10 text-blue-700" },
};

function totalReactions(p: FeedPost) {
  const r = p.reactions;
  return r.like + r.celebrate + r.fire + r.insightful + r.support;
}

/* ---------- Dummy comment generator (deterministic per post) ---------- */

const COMMENT_POOL: Record<FeedPost["type"], string[]> = {
  project: [
    "Congrats on the launch! What's the tech stack under the hood?",
    "This is genuinely impressive — how long did it take from idea to ship?",
    "Been following your build logs for weeks. Finally trying it today 🔥",
    "The onboarding is so clean. Who did the design?",
    "How are you handling scale on the backend? Any bottlenecks yet?",
    "Bookmarking this. My team could use exactly this next quarter.",
  ],
  prompt: [
    "Just tried it on my copy — 2x better than what I had. Thank you!",
    "Any tweaks you'd recommend for GPT-4o vs Claude?",
    "Saving this in my library. Big upgrade over the prompt I was using.",
    "The role framing at the top is doing all the heavy lifting here.",
    "How do you handle the case when the input is too vague?",
    "Forked and adapted for my newsletter. Works like a charm.",
  ],
  workflow: [
    "Elegant. How are you handling retries on failed nodes?",
    "Do you have this as an exportable JSON I can import into my n8n?",
    "Been trying to build this exact flow for a month. Thank you!",
    "What are you using for the trigger — webhook or polling?",
    "Cost per run? Curious how the LLM step compares at scale.",
    "This is going straight into our ops playbook Monday morning.",
  ],
  question: [
    "Ran into the same thing last month — solved it by chunking the response.",
    "There's a Discord thread on this if you want, DM me and I'll share.",
    "Try switching to streaming with SSE, made a big difference for us.",
    "Following — I've been stuck on this too.",
    "Have you tried the beta API? They fixed a similar issue last week.",
  ],
  update: [
    "Congrats — earned every bit of it 🙌",
    "Two years of grinding, love to see it pay off.",
    "This should be pinned. The realest take I've read this week.",
    "Rooting for you. Keep going.",
    "Saving this as motivation for my Monday standup.",
  ],
};

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

type DemoComment = { id: string; authorId: string; text: string; likes: number; ago: string };

function generateDemoComments(post: FeedPost): DemoComment[] {
  const pool = COMMENT_POOL[post.type] ?? COMMENT_POOL.update;
  const target = Math.min(Math.max(3, Math.min(post.comments, 5)), pool.length);
  const seed = hash(post.id);
  const agos = ["12m ago", "38m ago", "1h ago", "2h ago", "4h ago", "6h ago", "1d ago"];
  const out: DemoComment[] = [];

  // Include top comment first if present
  if (post.topComment) {
    out.push({
      id: `${post.id}-tc`,
      authorId: post.topComment.authorId,
      text: post.topComment.text,
      likes: post.topComment.likes,
      ago: post.topComment.ago,
    });
  }

  const used = new Set<number>();
  let i = 0;
  while (out.length < target && used.size < pool.length) {
    const idx = (seed + i * 31) % pool.length;
    if (!used.has(idx)) {
      used.add(idx);
      const bIdx = (seed + i * 17) % builders.length;
      out.push({
        id: `${post.id}-c${i}`,
        authorId: builders[bIdx].id,
        text: pool[idx],
        likes: ((seed + i * 7) % 24) + 1,
        ago: agos[(seed + i) % agos.length],
      });
    }
    i++;
  }
  return out;
}

/* ---------------------------------------------------------------- */

export function DemoPostCard({ post, mobile }: { post: FeedPost; mobile?: boolean }) {
  const author = getBuilder(post.authorId);
  const meta = TYPE_META[post.type];
  const Icon = meta.icon;

  const [showComments, setShowComments] = useState(false);
  const demoComments = useMemo(() => generateDemoComments(post), [post]);

  const demoAction = (label: string) => () => {
    toast(label, { description: "This is a demo post. Sign in and share your own to interact for real." });
  };

  return (
    <article
      className={cn(
        "relative border-[1.5px] border-[#0F0F0F] bg-white",
        mobile ? "rounded-none" : "rounded-2xl",
      )}
      style={{ boxShadow: mobile ? "none" : "3px 3px 0 0 #0F0F0F" }}
    >
      <div className="flex items-start gap-3 p-4">
        <Link to="/u/$username" params={{ username: author.username }} className="shrink-0">
          <img src={author.avatar} alt="" className="h-10 w-10 rounded-full border-[1.5px] border-[#0F0F0F] object-cover" />
        </Link>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <Link
              to="/u/$username"
              params={{ username: author.username }}
              className="truncate font-display text-sm font-bold hover:underline"
            >
              {author.name}
            </Link>
            <span className="inline-flex items-center gap-1 rounded-full border border-dashed border-[#0F0F0F]/40 bg-surface px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-muted-foreground">
              Demo
            </span>
            <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold", meta.tint)}>
              <Icon className="h-3 w-3" /> {meta.label}
            </span>
          </div>
          <div className="truncate text-xs text-muted-foreground">@{author.username} · {post.createdAgo}</div>
        </div>
      </div>

      {post.text && (
        <div className="whitespace-pre-wrap px-4 pb-3 text-sm leading-relaxed">{post.text}</div>
      )}

      {post.hashtags?.length > 0 && (
        <div className="flex flex-wrap gap-1.5 px-4 pb-3">
          {post.hashtags.map((h) => (
            <span key={h} className="rounded-full bg-surface px-2 py-0.5 text-[10px] font-bold text-coral">#{h}</span>
          ))}
        </div>
      )}

      {/* Project block */}
      {post.type === "project" && post.project && (
        <div className="mx-4 mb-3 overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F]">
          <img src={post.project.cover} alt={post.project.title} className="aspect-video w-full object-cover" />
          <div className="p-3">
            <div className="font-display text-sm font-bold">{post.project.title}</div>
            <div className="mt-1 flex flex-wrap gap-1">
              {post.project.tools.map((t) => (
                <span key={t} className="rounded-full bg-surface px-2 py-0.5 text-[10px] font-bold text-foreground/80">{t}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Prompt block */}
      {post.type === "prompt" && post.prompt && (
        <div className="mx-4 mb-3 rounded-xl border-[1.5px] border-[#0F0F0F] bg-surface p-3">
          <div className="mb-1 flex items-center gap-2 text-[10px] font-black uppercase tracking-wider text-coral">
            <Zap className="h-3 w-3" /> {post.prompt.model}
          </div>
          <pre className="max-h-52 overflow-auto whitespace-pre-wrap break-words rounded-lg bg-white p-3 text-[11px] leading-relaxed">{post.prompt.text}</pre>
          <button
            onClick={() => {
              try { navigator.clipboard.writeText(post.prompt!.text); toast.success("Prompt copied"); xpToastFirstCopy(post.id, 5); } catch { /* ignore */ }
            }}
            className="mt-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1 text-[11px] font-bold hover:bg-surface"
          >
            Copy prompt
          </button>
        </div>
      )}

      {/* Workflow block */}
      {post.type === "workflow" && post.workflow && (
        <div className="mx-4 mb-3 overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F]">
          <img src={post.workflow.thumb} alt={post.workflow.title} className="aspect-video w-full object-cover" />
          <div className="p-3">
            <div className="flex items-center gap-2 font-display text-sm font-bold">
              <WorkflowIcon className="h-4 w-4 text-teal-600" /> {post.workflow.title}
            </div>
            <div className="mt-1 flex flex-wrap gap-1">
              {post.workflow.tools.map((t) => (
                <span key={t} className="rounded-full bg-surface px-2 py-0.5 text-[10px] font-bold text-foreground/80">{t}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Question block */}
      {post.type === "question" && post.question && (
        <div className="mx-4 mb-3 rounded-xl border-[1.5px] border-dashed border-violet-500/40 bg-violet-50/40 p-3">
          <div className="mb-1 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-violet-700">
            <HelpCircle className="h-3 w-3" /> Community question
          </div>
          {post.question.tags.length > 0 && (
            <div className="mt-1 flex flex-wrap gap-1">
              {post.question.tags.map((t) => (
                <span key={t} className="rounded-full bg-white px-2 py-0.5 text-[10px] font-bold text-violet-700">#{t}</span>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="flex items-center justify-between border-t-[1.5px] border-[#0F0F0F]/10 px-4 py-1.5 text-[11px] text-muted-foreground">
        <span>{totalReactions(post)} reactions · {post.comments} comments · {post.shares} reposts</span>
      </div>

      <div className="grid grid-cols-4 border-t-[1.5px] border-[#0F0F0F]/10">
        <button onClick={demoAction("Like reserved for real posts")} className="flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface">
          <Heart className="h-4 w-4" /> Like
        </button>
        <button
          onClick={() => setShowComments((v) => !v)}
          className={cn(
            "flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface",
            showComments && "text-coral",
          )}
          aria-expanded={showComments}
        >
          <MessageSquare className="h-4 w-4" /> Comment
        </button>
        <button onClick={demoAction("Reposting available on real posts")} className="flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface">
          <Repeat2 className="h-4 w-4" /> Repost
        </button>
        <button onClick={demoAction("Sharing available on real posts")} className="flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface">
          <Share2 className="h-4 w-4" /> Share
        </button>
      </div>

      {showComments && (
        <div className="border-t-[1.5px] border-[#0F0F0F]/10 bg-surface/40 px-4 py-3 space-y-3">
          {demoComments.map((c) => {
            const cAuthor = getBuilder(c.authorId);
            return (
              <div key={c.id} className="flex items-start gap-2.5">
                <img
                  src={cAuthor.avatar}
                  alt=""
                  className="h-8 w-8 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F] object-cover"
                />
                <div className="min-w-0 flex-1">
                  <div className="rounded-2xl border-[1.5px] border-[#0F0F0F]/15 bg-white px-3 py-2">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-bold">{cAuthor.name}</span>
                      <span className="text-muted-foreground">· {c.ago}</span>
                    </div>
                    <div className="mt-0.5 text-sm leading-snug">{c.text}</div>
                  </div>
                  <div className="mt-1 flex items-center gap-3 pl-1 text-[11px] text-muted-foreground">
                    <span className="inline-flex items-center gap-1">
                      <ThumbsUp className="h-3 w-3" /> {c.likes}
                    </span>
                    <button
                      onClick={demoAction("Replies open on real posts")}
                      className="font-semibold hover:text-foreground"
                    >
                      Reply
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          <button
            onClick={demoAction("Comments open on real posts")}
            className="w-full rounded-full border-[1.5px] border-dashed border-[#0F0F0F]/30 bg-white px-3 py-2 text-[11px] font-bold text-muted-foreground hover:text-foreground"
          >
            Sign in to add your comment
          </button>
        </div>
      )}
    </article>
  );
}
