import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Heart, MessageSquare, Share2, Repeat2, Trash2, Loader2, X, ImageIcon, Send, ArrowUp, RefreshCw, Bookmark, MoreHorizontal, Link2, Pencil, Flag, EyeOff, Check, Flame, Clock } from "lucide-react";
import { toast } from "sonner";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import {
  addComment,
  createPost,
  deleteComment,
  deletePost,
  editComment,
  editPost,
  getHiddenPosts,
  hidePostLocally,
  listComments,
  listFeed,
  listFollowingIds,
  listMyProjects,
  repostPost,
  reportPost,
  setReaction,
  timeAgo,
  toggleBookmark,
  toggleFollow,
  uploadPostImage,
  REACTION_META,
  REACTION_TYPES,
  type FeedSort,
  type LiveComment,
  type LivePost,
  type ReactionType,
  type RefEntity,
} from "@/lib/feed-api";

import { EmojiPicker } from "@/components/ui/emoji-picker";
import { useAuth } from "@/hooks/useAuth";
import { useCommentsRealtime, useFeedRealtime } from "@/hooks/useFeedRealtime";
import { cn } from "@/lib/utils";
import { SEED_POSTS, type FeedPost } from "@/lib/vibe-feed-seed";
import { xpToast } from "@/lib/xp-toast";
import { DemoPostCard } from "./DemoPostCard";
import { StoriesRow } from "./StoriesRow";
import { FeedSkeleton } from "./PostSkeleton";
import { MemberBadges } from "@/components/ui/MemberBadges";


const TRENDING_TAGS = [
  { icon: "🔥", tag: "lovable" },
  { icon: "⚡", tag: "n8n" },
  { icon: "🤖", tag: "claude" },
  { icon: "🚀", tag: "shipinpublic" },
  { icon: "💡", tag: "prompts" },
  { icon: "🏗", tag: "buildinpublic" },
  { icon: "💰", tag: "indiehacker" },
  { icon: "🧠", tag: "ai-agents" },
  { icon: "📱", tag: "nocode" },
  { icon: "🇮🇳", tag: "madeinindia" },
];

type FeedTab = "foryou" | "trending" | "following" | "prompt" | "workflow" | "project";

export function LiveFeed({ mobile }: { mobile?: boolean }) {
  const qc = useQueryClient();
  const { user } = useAuth();
  const [tab, setTab] = useState<FeedTab>("foryou");
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const sort: FeedSort = tab === "trending" ? "top" : "latest";
  const [hiddenTick, setHiddenTick] = useState(0);
  const hidden = useMemo(() => getHiddenPosts(), [hiddenTick]);

  const { data: rawPosts = [], isLoading, isError, refetch, isFetching, dataUpdatedAt } = useQuery({
    queryKey: ["feed", "list", sort],
    queryFn: () => listFeed(50, sort),
    staleTime: 3_000,
    refetchInterval: 10_000,
    refetchOnWindowFocus: true,
  });
  const posts = useMemo(() => rawPosts.filter((p) => !hidden.has(p.id)), [rawPosts, hidden]);

  // Rotate seed posts every 15s so the feed never looks empty. Daily seed
  // keeps ordering stable within the day, then reshuffles on the next day.
  const [seedTick, setSeedTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setSeedTick((t) => t + 1), 15_000);
    return () => clearInterval(id);
  }, []);

  const { data: followingSet = new Set<string>() } = useQuery({
    queryKey: ["feed", "following", user?.id],
    queryFn: listFollowingIds,
    enabled: !!user,
    staleTime: 60_000,
  });

  useFeedRealtime(() => qc.invalidateQueries({ queryKey: ["feed", "list"] }));

  // Track new posts arriving while user is scrolled down — show "new posts" pill.
  const [seenTopId, setSeenTopId] = useState<string | null>(null);
  const [newCount, setNewCount] = useState(0);
  const topRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (posts.length === 0) return;
    const topId = posts[0].id;
    if (seenTopId === null) {
      setSeenTopId(topId);
      return;
    }
    if (topId === seenTopId) return;
    // Count how many new posts landed above the previously seen top.
    const idx = posts.findIndex((p) => p.id === seenTopId);
    const added = idx === -1 ? posts.length : idx;
    // If user is near the top, auto-adopt; otherwise show pill.
    if (window.scrollY < 200) {
      setSeenTopId(topId);
      setNewCount(0);
    } else {
      setNewCount(added);
    }
  }, [posts, seenTopId]);

  const jumpToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (posts[0]) setSeenTopId(posts[0].id);
    setNewCount(0);
  };

  // Pull-to-refresh (mobile). LinkedIn-style: overscroll at top, drag down, release to refresh.
  const scrollHostRef = useRef<HTMLDivElement | null>(null);
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startY = useRef<number | null>(null);
  const THRESHOLD = 70;

  const onTouchStart = (e: React.TouchEvent) => {
    if (window.scrollY > 0) { startY.current = null; return; }
    startY.current = e.touches[0].clientY;
  };
  const onTouchMove = (e: React.TouchEvent) => {
    if (startY.current === null || refreshing) return;
    const dy = e.touches[0].clientY - startY.current;
    if (dy > 0) {
      // Dampen the pull for a springy feel.
      setPull(Math.min(120, dy * 0.5));
    }
  };
  const onTouchEnd = async () => {
    if (startY.current === null) return;
    startY.current = null;
    if (pull >= THRESHOLD) {
      setRefreshing(true);
      setPull(56);
      try {
        await refetch();
        if (posts[0]) setSeenTopId(posts[0].id);
        setNewCount(0);
      } finally {
        setRefreshing(false);
        setPull(0);
      }
    } else {
      setPull(0);
    }
  };

  const manualRefresh = async () => {
    setRefreshing(true);
    try {
      await refetch();
      if (posts[0]) setSeenTopId(posts[0].id);
      setNewCount(0);
    } finally {
      setRefreshing(false);
    }
  };

  // Interleave: 2 real posts, then a demo post, and so on. When there are
  // few or no real posts yet, the demo stream keeps the feed feeling alive.
  const merged = useMemo(() => {
    // Daily rotation seed: same order for the whole day, reshuffled tomorrow.
    const dayKey = Math.floor(Date.now() / (24 * 60 * 60 * 1000));
    const rotate = <T,>(arr: T[], offset: number) =>
      arr.length ? arr.slice(offset % arr.length).concat(arr.slice(0, offset % arr.length)) : arr;
    const shuffleDaily = <T,>(arr: T[]): T[] => {
      const out = [...arr];
      // Fisher-Yates seeded by dayKey (stable within a day)
      let s = dayKey || 1;
      const rand = () => {
        s = (s * 9301 + 49297) % 233280;
        return s / 233280;
      };
      for (let i = out.length - 1; i > 0; i--) {
        const j = Math.floor(rand() * (i + 1));
        [out[i], out[j]] = [out[j], out[i]];
      }
      return out;
    };

    const demosSorted = shuffleDaily(SEED_POSTS);

    // Type-tab: show only demos of the matching type (real posts don't
    // carry a type field yet, so type-filtered tabs are demo-only).
    const typeMap: Record<string, FeedPost["type"] | null> = {
      prompt: "prompt",
      workflow: "workflow",
      project: "project",
    };
    const typeFilter = typeMap[tab] ?? null;
    if (typeFilter) {
      let filtered = demosSorted.filter((d) => d.type === typeFilter);
      if (activeTag) filtered = filtered.filter((d) => d.hashtags.includes(activeTag));
      filtered = rotate(filtered, seedTick);
      return filtered.map((post) => ({ kind: "demo" as const, post }));
    }

    // Following: only real posts from authors the user follows.
    if (tab === "following") {
      return posts
        .filter((p) => followingSet.has(p.author_id))
        .map((post) => ({ kind: "real" as const, post }));
    }

    // When there are no real posts, rotate the seed feed every 15s so the
    // page never looks empty. Keeps a fresh order for returning visitors.
    if (posts.length === 0) {
      let demos = rotate(demosSorted, seedTick);
      if (activeTag) demos = demos.filter((d) => d.hashtags.includes(activeTag));
      return demos.map((post) => ({ kind: "demo" as const, post }));
    }

    const demos = rotate(demosSorted, seedTick);
    const out: Array<{ kind: "real"; post: LivePost } | { kind: "demo"; post: FeedPost }> = [];
    let di = 0;
    posts.forEach((p, i) => {
      out.push({ kind: "real", post: p });
      if ((i + 1) % 2 === 0 && di < demos.length) {
        out.push({ kind: "demo", post: demos[di++] });
      }
    });
    while (di < demos.length) out.push({ kind: "demo", post: demos[di++] });

    if (activeTag) {
      return out.filter((e) =>
        e.kind === "demo"
          ? e.post.hashtags.includes(activeTag)
          : (e.post.body || "").toLowerCase().includes(`#${activeTag}`),
      );
    }
    return out;
  }, [posts, tab, activeTag, followingSet, seedTick]);

  return (
    <div
      ref={scrollHostRef}
      className={cn("min-h-[70vh] relative", mobile ? "px-0" : "px-1")}
      onTouchStart={mobile ? onTouchStart : undefined}
      onTouchMove={mobile ? onTouchMove : undefined}
      onTouchEnd={mobile ? onTouchEnd : undefined}
    >
      {/* Pull-to-refresh indicator */}
      {(pull > 0 || refreshing) && (
        <div
          className="pointer-events-none absolute left-1/2 top-0 z-20 -translate-x-1/2"
          style={{ transform: `translate(-50%, ${Math.max(0, pull - 24)}px)` }}
        >
          <div className="grid h-10 w-10 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white shadow-[3px_3px_0_0_#0F0F0F]">
            <RefreshCw
              className={cn(
                "h-4 w-4 text-coral",
                refreshing ? "animate-spin" : "transition-transform",
              )}
              style={!refreshing ? { transform: `rotate(${Math.min(360, pull * 4)}deg)` } : undefined}
            />
          </div>
        </div>
      )}

      {/* Pushdown to visually reveal the pull */}
      <div
        ref={topRef}
        style={{ transform: `translateY(${pull}px)`, transition: refreshing || pull === 0 ? "transform 200ms ease-out" : undefined }}
      >
        <StoriesRow mobile={mobile} />
        <div className={mobile ? "h-3" : "h-4"} />
        {!mobile && <LiveComposer />}
        {/* Mobile composer is handled by the "+" FAB in MobileBottomTabs — no inline composer here to avoid a duplicate input under the sticky search. */}


        {/* Trending topics strip */}
        <div className={cn("no-scrollbar -mx-1 flex items-center gap-2 overflow-x-auto", mobile ? "px-3 pt-3" : "mt-4 px-1")}>
          <span className="shrink-0 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Trending:</span>
          {TRENDING_TAGS.map((t) => {
            const active = activeTag === t.tag;
            return (
              <button
                key={t.tag}
                type="button"
                onClick={() => setActiveTag(active ? null : t.tag)}
                className={cn(
                  "shrink-0 whitespace-nowrap rounded-full border px-3 py-1 text-xs font-semibold transition-colors",
                  active
                    ? "border-coral bg-coral text-white"
                    : "border-[#E8E0D6] bg-white text-[#333] hover:border-coral hover:text-coral",
                )}
              >
                <span className="mr-1">{t.icon}</span>#{t.tag}
              </button>
            );
          })}
          {activeTag && (
            <button
              onClick={() => setActiveTag(null)}
              className="shrink-0 text-[11px] font-bold text-muted-foreground hover:text-coral"
            >
              Clear
            </button>
          )}
        </div>

        {/* Feed filter tabs — pill style */}
        <div
          className={cn(
            "no-scrollbar mt-3 flex items-center gap-1 overflow-x-auto rounded-xl bg-[#F5F0E8] p-1",
            mobile ? "mx-3" : "",
          )}
        >
          {[
            { k: "foryou", label: "✨ For You" },
            { k: "trending", label: "🔥 Trending" },
            { k: "following", label: "👥 Following" },
            { k: "prompt", label: "💡 Prompts" },
            { k: "workflow", label: "⚙️ Workflows" },
            { k: "project", label: "📁 Projects" },
          ].map((t) => {
            const active = tab === (t.k as FeedTab);
            return (
              <button
                key={t.k}
                onClick={() => setTab(t.k as FeedTab)}
                className={cn(
                  "shrink-0 whitespace-nowrap rounded-lg px-3 py-1.5 text-[13px] transition-all",
                  active
                    ? "bg-white font-semibold text-[#0F0F0F] shadow-[0_1px_4px_rgba(0,0,0,0.08)]"
                    : "font-medium text-[#666] hover:text-[#0F0F0F]",
                )}
              >
                {t.label}
              </button>
            );
          })}
        </div>



        {/* "New posts" pill — LinkedIn style */}
        {newCount > 0 && (
          <div className="sticky top-2 z-10 flex justify-center pt-2">
            <button
              onClick={jumpToTop}
              className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1.5 text-xs font-bold text-white shadow-[3px_3px_0_0_#0F0F0F] hover:brightness-110"
            >
              <ArrowUp className="h-3.5 w-3.5" />
              {newCount} new post{newCount > 1 ? "s" : ""}
            </button>
          </div>
        )}

        <div className={cn("mt-4 space-y-3", !mobile && "space-y-4")}>
          {isLoading && <FeedSkeleton mobile={mobile} count={3} />}

          {isError && (
            <div className="grid place-items-center py-10 text-sm text-error">
              Couldn't load the feed. <button onClick={() => refetch()} className="ml-2 underline">Retry</button>
            </div>
          )}
          {!isLoading && posts.length === 0 && (
            <div className="rounded-xl border-[1.5px] border-dashed border-[#0F0F0F]/25 bg-white p-4 text-center">
              <div className="text-sm font-bold">Be first — the real feed is waiting for you.</div>
              <p className="mt-1 text-xs text-muted-foreground">
                Posts below are demo inspiration. Share yours to go live for everyone in real time.
              </p>
            </div>
          )}
          {merged.map((entry) =>
            entry.kind === "real" ? (
              <LivePostCard
                key={`r-${entry.post.id}`}
                post={entry.post}
                mobile={mobile}
                isFollowingAuthor={followingSet.has(entry.post.author_id)}
                onHidden={() => { hidePostLocally(entry.post.id); setHiddenTick((t) => t + 1); }}
              />
            ) : (
              <DemoPostCard key={`d-${entry.post.id}`} post={entry.post} mobile={mobile} />
            ),
          )}

          {/* Subtle live indicator at the bottom */}
          {!isLoading && posts.length > 0 && (
            <div className="flex items-center justify-center gap-2 py-4 text-[11px] text-muted-foreground">
              <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-coral" />
              {isFetching ? "Refreshing…" : `Live · updated ${timeAgo(new Date(dataUpdatedAt).toISOString())}`}
              <button onClick={manualRefresh} className="ml-1 underline hover:text-coral">refresh</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}


/* -------------------- Composer -------------------- */

export function LiveComposer({ mobile }: { mobile?: boolean }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [projectId, setProjectId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const { data: myProjects = [] } = useQuery({
    queryKey: ["feed", "my-projects", user?.id],
    queryFn: listMyProjects,
    enabled: !!user,
  });

  useEffect(() => {
    const urls = files.map((f) => URL.createObjectURL(f));
    setPreviews(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
  }, [files]);

  const onSelectFiles = (list: FileList | null) => {
    if (!list) return;
    const next = [...files, ...Array.from(list)].slice(0, 4);
    setFiles(next);
  };

  const reset = () => {
    setText("");
    setFiles([]);
    setProjectId(null);
    setOpen(false);
  };

  const submit = async () => {
    if (!user) {
      navigate({ to: "/auth" });
      return;
    }
    if (!text.trim() && files.length === 0 && !projectId) {
      toast.error("Add some text, an image, or a project.");
      return;
    }
    setSubmitting(true);
    try {
      let imageUrls: string[] = [];
      for (const f of files) {
        const url = await uploadPostImage(f);
        imageUrls.push(url);
      }
      await createPost({ body: text, imageUrls, projectId, kind: "text" });
      toast.success("Posted!");
      reset();
      qc.invalidateQueries({ queryKey: ["feed"] });
    } catch (e: any) {
      toast.error(e?.message || "Failed to post");
    } finally {
      setSubmitting(false);
    }
  };

  if (!user) {
    return (
      <div
        className={cn(
          "flex items-center justify-between gap-3 border-[1.5px] border-[#0F0F0F] bg-white p-4",
          mobile ? "rounded-none" : "rounded-xl",
        )}
        style={{ boxShadow: mobile ? "none" : "3px 3px 0 0 #0F0F0F" }}
      >
        <span className="text-sm text-muted-foreground">Sign in to post, like, and comment.</span>
        <Link to="/auth" className="rounded-full bg-coral px-4 py-1.5 text-xs font-bold text-white">Sign in</Link>
      </div>
    );
  }

  return (
    <div
      className={cn("border-[1.5px] border-[#0F0F0F] bg-white", mobile ? "rounded-none" : "rounded-xl")}
      style={{ boxShadow: mobile ? "none" : "3px 3px 0 0 #0F0F0F" }}
    >
      <div className="flex items-start gap-3 p-4">
        <img
          src={
            (user as any)?.user_metadata?.avatar_url ||
            `https://api.dicebear.com/7.x/notionists/svg?seed=${user?.email ?? "you"}`
          }
          alt=""
          className="h-10 w-10 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]"
        />
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onFocus={() => setOpen(true)}
          rows={open ? 3 : 1}
          placeholder="What are you building today?"
          className="flex-1 resize-none rounded-2xl border-[1.5px] border-[#0F0F0F]/20 bg-surface px-4 py-2 text-sm outline-none focus:border-coral"
          maxLength={2000}
        />
      </div>

      {open && (
        <>
          {previews.length > 0 && (
            <div className="grid grid-cols-4 gap-2 px-4 pb-2">
              {previews.map((src, i) => (
                <div key={src} className="relative overflow-hidden rounded-lg border border-[#0F0F0F]/20">
                  <img src={src} alt="" className="aspect-square w-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setFiles(files.filter((_, idx) => idx !== i))}
                    className="absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-black/70 text-white"
                    aria-label="Remove image"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {projectId && (
            <div className="mx-4 mb-2 flex items-center justify-between rounded-lg border border-[#0F0F0F]/20 bg-surface px-3 py-2 text-xs">
              <span>Attached project: <b>{myProjects.find((p) => p.id === projectId)?.title}</b></span>
              <button onClick={() => setProjectId(null)} className="text-coral hover:underline">Remove</button>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-2 border-t-[1.5px] border-[#0F0F0F]/10 p-3">
            <div className="flex items-center gap-2">
              <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F]/20 px-3 py-1.5 text-xs font-bold hover:bg-surface">
                <ImageIcon className="h-3.5 w-3.5 text-coral" /> Image
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={(e) => onSelectFiles(e.target.files)}
                />
              </label>
              {myProjects.length > 0 && (
                <select
                  value={projectId ?? ""}
                  onChange={(e) => setProjectId(e.target.value || null)}
                  className="rounded-full border-[1.5px] border-[#0F0F0F]/20 bg-white px-3 py-1.5 text-xs font-bold outline-none"
                >
                  <option value="">Attach a project…</option>
                  {myProjects.map((p) => (
                    <option key={p.id} value={p.id}>{p.title}</option>
                  ))}
                </select>
              )}
              <span className="text-[10px] text-muted-foreground">{text.length}/2000</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={reset}
                type="button"
                className="rounded-full border-[1.5px] border-[#0F0F0F]/20 bg-white px-3 py-1.5 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={submit}
                disabled={submitting}
                className="inline-flex items-center gap-1.5 rounded-full bg-coral px-4 py-1.5 text-xs font-bold text-white disabled:opacity-60"
              >
                {submitting && <Loader2 className="h-3 w-3 animate-spin" />}
                Post
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

/* -------------------- Sort tabs -------------------- */

function SortTab({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-bold transition-colors",
        active ? "border-coral text-coral" : "border-transparent text-muted-foreground hover:text-foreground",
      )}
    >
      {icon}
      {label}
    </button>
  );
}

/* -------------------- Rich text: @mentions & #hashtags -------------------- */

function RichBody({ text }: { text: string }) {
  const parts = text.split(/(\s+)/);
  return (
    <>
      {parts.map((part, i) => {
        const m = /^@([A-Za-z0-9_]{2,32})$/.exec(part);
        const h = /^#([A-Za-z0-9_]{2,40})$/.exec(part);
        if (m) return <Link key={i} to="/u/$username" params={{ username: m[1] }} className="font-bold text-coral hover:underline">@{m[1]}</Link>;
        if (h) return <Link key={i} to="/search" search={{ q: `#${h[1]}` } as any} className="font-bold text-coral hover:underline">#{h[1]}</Link>;
        if (/^https?:\/\/\S+$/.test(part)) return <a key={i} href={part} target="_blank" rel="noreferrer noopener" className="text-coral underline break-all">{part}</a>;
        return <span key={i}>{part}</span>;
      })}
    </>
  );
}

/* -------------------- Card -------------------- */

function LivePostCard({ post, mobile, isFollowingAuthor, onHidden }: { post: LivePost; mobile?: boolean; isFollowingAuthor?: boolean; onHidden?: () => void }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [showComments, setShowComments] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState(post.body ?? "");
  const [confirmDel, setConfirmDel] = useState(false);
  const [reporting, setReporting] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const target = post.repost_of && post.reposted ? post.reposted : post;
  const author = post.author;
  const isOwn = user?.id === post.author_id;
  const canFollow = !!user && !isOwn && !!author?.id;

  useEffect(() => {
    if (!menuOpen) return;
    const onDoc = (e: MouseEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [menuOpen]);

  const invalidateFeed = () => qc.invalidateQueries({ queryKey: ["feed"] });

  const reactionMut = useMutation({
    mutationFn: async (next: ReactionType | null) => setReaction(post.id, next),
    onSuccess: (_d, next) => {
      if (next) xpToast(10);
      invalidateFeed();
    },
    onError: (e: any) => {
      if (String(e?.message).includes("Not signed in")) toast.error("Sign in to react");
      else toast.error("Couldn't update reaction");
    },
  });


  const bookmarkMut = useMutation({
    mutationFn: async () => toggleBookmark(post.id, !!post.bookmarked_by_me),
    onSuccess: () => {
      const wasSaved = !!post.bookmarked_by_me;
      toast.success(wasSaved ? "Removed from saved" : "Saved");
      if (!wasSaved) xpToast(5);
      invalidateFeed();
      qc.invalidateQueries({ queryKey: ["saved"] });
    },
    onError: (e: any) => toast.error(e?.message || "Couldn't save"),
  });

  const repostMut = useMutation({
    mutationFn: async () => repostPost(post.id),
    onSuccess: () => { toast.success("Reposted"); invalidateFeed(); },
    onError: (e: any) => toast.error(e?.message || "Couldn't repost"),
  });

  const delMut = useMutation({
    mutationFn: async () => deletePost(post.id),
    onSuccess: () => { toast.success("Post deleted"); setConfirmDel(false); invalidateFeed(); },
    onError: (e: any) => { toast.error(e?.message || "Couldn't delete post"); setConfirmDel(false); },
  });

  const editMut = useMutation({
    mutationFn: async () => editPost(post.id, editText),
    onSuccess: () => { toast.success("Post updated"); setEditing(false); invalidateFeed(); },
    onError: (e: any) => toast.error(e?.message || "Couldn't update"),
  });

  const followMut = useMutation({
    mutationFn: async () => toggleFollow(post.author_id, !!isFollowingAuthor),
    onSuccess: () => {
      
      qc.invalidateQueries({ queryKey: ["feed", "following"] });
    },
    onError: (e: any) => toast.error(e?.message || "Couldn't update follow"),
  });

  const copyLink = async () => {
    const url = `${window.location.origin}/vibe#post-${post.id}`;
    try { await navigator.clipboard.writeText(url); toast.success("Link copied"); }
    catch { toast.error("Couldn't copy link"); }
  };

  const share = async () => {
    const url = `${window.location.origin}/vibe#post-${post.id}`;
    try {
      if (navigator.share) await navigator.share({ url, title: "Post on VibeCode" });
      else { await navigator.clipboard.writeText(url); toast.success("Link copied"); }
    } catch { /* user cancelled */ }
  };

  const submitReport = async (reason: string) => {
    try {
      await reportPost(post.id, reason);
      toast.success("Reported — thanks");
      setReporting(false);
      onHidden?.();
    } catch (e: any) {
      toast.error(e?.message || "Couldn't report");
    }
  };

  return (
    <article
      id={`post-${post.id}`}
      className={cn(
        "relative border-[1.5px] border-[#0F0F0F] bg-white",
        mobile ? "rounded-none" : "rounded-2xl",
      )}
      style={{ boxShadow: mobile ? "none" : "3px 3px 0 0 #0F0F0F" }}
    >
      {post.repost_of && (
        <div className="flex items-center gap-1.5 border-b border-[#0F0F0F]/10 px-4 py-1.5 text-[11px] font-bold text-muted-foreground">
          <Repeat2 className="h-3 w-3" /> {author?.display_name || author?.username || "Someone"} reposted
        </div>
      )}
      <div className="flex items-start gap-3 p-4">
        <Link to="/u/$username" params={{ username: target.author?.username || "unknown" }} className="shrink-0">
          <img
            src={target.author?.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${target.author?.username ?? target.author_id}`}
            alt=""
            className="h-10 w-10 rounded-full border-[1.5px] border-[#0F0F0F] object-cover"
          />
        </Link>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <Link
              to="/u/$username"
              params={{ username: target.author?.username || "unknown" }}
              className="truncate font-display text-sm font-bold hover:underline"
            >
              {target.author?.display_name || target.author?.username || "Anonymous"}
            </Link>
            {target.author && <MemberBadges profile={target.author} size="xs" />}
            {canFollow && (
              <button
                onClick={() => followMut.mutate()}
                disabled={followMut.isPending}
                className={cn(
                  "shrink-0 rounded-full border-[1.5px] px-2 py-0.5 text-[10px] font-black uppercase tracking-wide",
                  isFollowingAuthor
                    ? "border-[#0F0F0F]/20 bg-white text-muted-foreground"
                    : "border-coral bg-coral text-white",
                )}
              >
                {isFollowingAuthor ? "Following" : "+ Follow"}
              </button>
            )}
          </div>
          <div className="truncate text-xs text-muted-foreground">
            {target.author?.username && <>@{target.author.username} · </>}{timeAgo(target.created_at)}
            {post.edited_at && <> · edited</>}
          </div>
        </div>

        {/* Kebab menu */}
        <div ref={menuRef} className="relative shrink-0">
          <button
            onClick={() => setMenuOpen((o) => !o)}
            aria-label="More"
            className="grid h-8 w-8 place-items-center rounded-full text-muted-foreground hover:bg-surface hover:text-foreground"
          >
            <MoreHorizontal className="h-4 w-4" />
          </button>
          {menuOpen && (
            <div className="absolute right-0 top-9 z-20 w-48 overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F] bg-white text-sm shadow-[3px_3px_0_0_#0F0F0F]">
              <MenuItem icon={<Bookmark className={cn("h-4 w-4", post.bookmarked_by_me && "fill-coral text-coral")} />} onClick={() => { setMenuOpen(false); if (!user) return toast.error("Sign in to save"); bookmarkMut.mutate(); }}>
                {post.bookmarked_by_me ? "Unsave" : "Save post"}
              </MenuItem>
              <MenuItem icon={<Link2 className="h-4 w-4" />} onClick={() => { setMenuOpen(false); copyLink(); }}>Copy link</MenuItem>
              {isOwn && (
                <MenuItem icon={<Pencil className="h-4 w-4" />} onClick={() => { setMenuOpen(false); setEditText(post.body ?? ""); setEditing(true); }}>
                  Edit post
                </MenuItem>
              )}
              {!isOwn && (
                <>
                  <MenuItem icon={<EyeOff className="h-4 w-4" />} onClick={() => { setMenuOpen(false); onHidden?.(); toast.success("Hidden from your feed"); }}>
                    Not interested
                  </MenuItem>
                  <MenuItem icon={<Flag className="h-4 w-4" />} onClick={() => { setMenuOpen(false); if (!user) return toast.error("Sign in to report"); setReporting(true); }}>
                    Report post
                  </MenuItem>
                </>
              )}
              {isOwn && (
                <MenuItem danger icon={<Trash2 className="h-4 w-4" />} onClick={() => { setMenuOpen(false); setConfirmDel(true); }}>
                  Delete post
                </MenuItem>
              )}
            </div>
          )}
        </div>
      </div>

      {editing ? (
        <div className="px-4 pb-3">
          <textarea
            value={editText}
            onChange={(e) => setEditText(e.target.value.slice(0, 2000))}
            rows={4}
            className="w-full rounded-xl border-[1.5px] border-[#0F0F0F]/25 bg-surface p-3 text-sm outline-none focus:border-coral"
          />
          <div className="mt-2 flex items-center justify-between text-[11px] text-muted-foreground">
            <span>{2000 - editText.length} characters left</span>
            <div className="flex items-center gap-2">
              <button onClick={() => setEditing(false)} className="rounded-full border-[1.5px] border-[#0F0F0F]/25 bg-white px-3 py-1 text-xs font-bold">Cancel</button>
              <button
                onClick={() => editMut.mutate()}
                disabled={editMut.isPending || !editText.trim()}
                className="inline-flex items-center gap-1 rounded-full bg-coral px-3 py-1 text-xs font-bold text-white disabled:opacity-60"
              >
                {editMut.isPending && <Loader2 className="h-3 w-3 animate-spin" />} Save
              </button>
            </div>
          </div>
        </div>
      ) : (
        target.body && (
          <div className="whitespace-pre-wrap px-4 pb-3 text-sm leading-relaxed">
            <RichBody text={target.body} />
          </div>
        )
      )}

      {target.image_urls.length > 0 && (
        <div className={cn("grid gap-1 px-4 pb-3", target.image_urls.length === 1 ? "grid-cols-1" : "grid-cols-2")}>
          {target.image_urls.map((u, i) => (
            <a key={u + i} href={u} target="_blank" rel="noreferrer" className="block overflow-hidden rounded-lg border border-[#0F0F0F]/20">
              <img src={u} alt="" className="max-h-[420px] w-full object-cover" loading="lazy" />
            </a>
          ))}
        </div>
      )}

      {target.project && (
        <div className="mx-4 mb-3 overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F]">
          {target.project.cover_image_url && (
            <img src={target.project.cover_image_url} alt={target.project.title} className="aspect-video w-full object-cover" />
          )}
          <div className="p-3">
            <div className="font-display text-sm font-bold">{target.project.title}</div>
            <Link to="/projects/$id" params={{ id: target.project.id }} className="mt-1 inline-block text-[11px] font-bold text-coral hover:underline">
              View project →
            </Link>
          </div>
        </div>
      )}

      {target.ref_entity && <RefEntityCard entity={target.ref_entity} kind={target.kind} />}

      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 border-t-[1.5px] border-[#0F0F0F]/10 px-4 py-1.5 text-[11px] text-muted-foreground">
        <ReactionSummary counts={post.reaction_counts} total={post.like_count} />
        <span className="truncate">· {post.comment_count} comments · {post.repost_count} reposts</span>
      </div>


      <div className="grid grid-cols-5 border-t-[1.5px] border-[#0F0F0F]/10">
        <ReactionButton
          my={post.my_reaction ?? null}
          disabled={reactionMut.isPending}
          requireSignIn={!user}
          onPick={(next) => {
            if (!user) return toast.error("Sign in to react");
            reactionMut.mutate(next);
          }}
        />
        <ActionBtn onClick={() => setShowComments((s) => !s)} icon={<MessageSquare className="h-4 w-4" />} label="Comment" />
        <ActionBtn onClick={() => { if (!user) return toast.error("Sign in to repost"); repostMut.mutate(); }} icon={<Repeat2 className="h-4 w-4" />} label="Repost" />
        <ActionBtn onClick={() => { if (!user) return toast.error("Sign in to save"); bookmarkMut.mutate(); }} active={!!post.bookmarked_by_me} icon={<Bookmark className={cn("h-4 w-4", post.bookmarked_by_me && "fill-coral")} />} label="Save" />
        <ActionBtn onClick={share} icon={<Share2 className="h-4 w-4" />} label="Share" />
      </div>


      {showComments && <CommentThread postId={post.id} postAuthorId={post.author_id} />}

      {/* Inline delete confirmation */}
      {confirmDel && (
        <div className="absolute inset-0 z-30 flex items-center justify-center rounded-2xl bg-black/40 p-4">
          <div className="w-full max-w-xs rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-4 shadow-[4px_4px_0_0_#0F0F0F]">
            <div className="font-display text-sm font-bold">Delete this post?</div>
            <p className="mt-1 text-xs text-muted-foreground">This can't be undone.</p>
            <div className="mt-3 flex justify-end gap-2">
              <button onClick={() => setConfirmDel(false)} className="rounded-full border-[1.5px] border-[#0F0F0F]/25 bg-white px-3 py-1 text-xs font-bold">Cancel</button>
              <button
                onClick={() => delMut.mutate()}
                disabled={delMut.isPending}
                className="inline-flex items-center gap-1 rounded-full bg-error px-3 py-1 text-xs font-bold text-white disabled:opacity-60"
              >
                {delMut.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />} Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Inline report sheet */}
      {reporting && (
        <div className="absolute inset-0 z-30 flex items-center justify-center rounded-2xl bg-black/40 p-4">
          <div className="w-full max-w-xs rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-4 shadow-[4px_4px_0_0_#0F0F0F]">
            <div className="font-display text-sm font-bold">Report this post</div>
            <p className="mt-1 text-xs text-muted-foreground">Why are you reporting?</p>
            <div className="mt-3 space-y-1.5">
              {["Spam", "Harassment", "Misinformation", "Inappropriate", "Other"].map((r) => (
                <button key={r} onClick={() => submitReport(r.toLowerCase())} className="flex w-full items-center justify-between rounded-lg border-[1.5px] border-[#0F0F0F]/15 bg-white px-3 py-2 text-xs font-bold hover:bg-surface">
                  {r} <Check className="h-3.5 w-3.5 opacity-0 group-hover:opacity-100" />
                </button>
              ))}
            </div>
            <div className="mt-3 flex justify-end">
              <button onClick={() => setReporting(false)} className="rounded-full border-[1.5px] border-[#0F0F0F]/25 bg-white px-3 py-1 text-xs font-bold">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </article>
  );
}

function MenuItem({ icon, children, onClick, danger }: { icon: React.ReactNode; children: React.ReactNode; onClick: () => void; danger?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-2.5 px-3 py-2 text-left text-xs font-bold hover:bg-surface",
        danger && "text-error hover:bg-error/10",
      )}
    >
      <span className="grid h-6 w-6 place-items-center">{icon}</span>
      <span>{children}</span>
    </button>
  );
}

function ActionBtn({ onClick, icon, label, active }: { onClick: () => void; icon: React.ReactNode; label: string; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface",
        active && "text-coral",
      )}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}

/* -------------------- Multi-reaction button (LinkedIn-style picker) -------------------- */

function ReactionButton({
  my,
  disabled,
  requireSignIn,
  onPick,
}: {
  my: ReactionType | null;
  disabled?: boolean;
  requireSignIn?: boolean;
  onPick: (next: ReactionType | null) => void;
}) {
  const [open, setOpen] = useState(false);
  const closeTimer = useRef<number | null>(null);
  const longPressTimer = useRef<number | null>(null);
  const longPressed = useRef(false);

  const scheduleClose = () => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current);
    closeTimer.current = window.setTimeout(() => setOpen(false), 180);
  };
  const cancelClose = () => {
    if (closeTimer.current) { window.clearTimeout(closeTimer.current); closeTimer.current = null; }
  };

  const meta = my ? REACTION_META[my] : null;
  const label = meta?.label ?? "Like";

  const handleTap = () => {
    if (longPressed.current) { longPressed.current = false; return; }
    // No reaction yet → add "like". Already reacted → clear.
    onPick(my ? null : "like");
  };

  const handleTouchStart = () => {
    if (requireSignIn) return;
    longPressed.current = false;
    if (longPressTimer.current) window.clearTimeout(longPressTimer.current);
    longPressTimer.current = window.setTimeout(() => {
      longPressed.current = true;
      setOpen(true);
    }, 350);
  };
  const handleTouchEnd = () => {
    if (longPressTimer.current) { window.clearTimeout(longPressTimer.current); longPressTimer.current = null; }
  };

  return (
    <div
      className="relative"
      onMouseEnter={() => { if (!requireSignIn) { cancelClose(); setOpen(true); } }}
      onMouseLeave={scheduleClose}
    >
      <button
        onClick={handleTap}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchEnd}
        disabled={disabled}
        aria-label={my ? `Reacted: ${label}. Tap to remove, long-press to change.` : "React to post"}
        className={cn(
          "flex w-full items-center justify-center gap-1.5 py-2.5 text-xs font-bold hover:bg-surface disabled:opacity-60",
          my && "text-coral",
        )}
      >
        {my ? (
          <span className="text-base leading-none">{meta!.emoji}</span>
        ) : (
          <Heart className="h-4 w-4" />
        )}
        <span className="hidden sm:inline">{label}</span>
      </button>

      {open && (
        <div
          onMouseEnter={cancelClose}
          onMouseLeave={scheduleClose}
          role="menu"
          className="absolute bottom-full left-0 z-30 mb-2 flex max-w-[calc(100vw-1.5rem)] items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white p-1.5 shadow-[3px_3px_0_0_#0F0F0F] sm:left-1/2 sm:-translate-x-1/2"
        >
          {REACTION_TYPES.map((t) => {
            const m = REACTION_META[t];
            const active = my === t;
            return (
              <button
                key={t}
                onClick={(e) => {
                  e.stopPropagation();
                  setOpen(false);
                  onPick(active ? null : t);
                }}
                aria-label={m.label}
                title={m.label}
                className={cn(
                  "grid h-8 w-8 shrink-0 place-items-center rounded-full text-lg transition hover:-translate-y-0.5 hover:scale-110 sm:h-9 sm:w-9 sm:text-xl",
                  active && "bg-coral/15 ring-2 ring-coral",
                )}
              >
                <span aria-hidden>{m.emoji}</span>
              </button>
            );
          })}
        </div>
      )}

    </div>
  );
}

/* -------------------- Reaction summary line -------------------- */

function ReactionSummary({ counts, total }: { counts: LivePost["reaction_counts"]; total: number }) {
  const entries = REACTION_TYPES
    .map((t) => ({ t, n: counts?.[t] ?? 0 }))
    .filter((r) => r.n > 0)
    .sort((a, b) => b.n - a.n)
    .slice(0, 3);
  if (!total) return <span>0 reactions</span>;
  return (
    <span className="inline-flex items-center gap-1">
      <span className="inline-flex -space-x-1">
        {entries.map(({ t }) => (
          <span key={t} className="grid h-4 w-4 place-items-center rounded-full bg-white text-[10px] ring-1 ring-[#0F0F0F]/20">
            {REACTION_META[t].emoji}
          </span>
        ))}
      </span>
      <span>{total} {total === 1 ? "reaction" : "reactions"}</span>
    </span>
  );
}



/* -------------------- Entity ref card (auto-post from submissions) -------------------- */

function RefEntityCard({ entity, kind }: { entity: RefEntity; kind: LivePost["kind"] }) {
  const kindLabel: Record<string, { label: string; bg: string }> = {
    job: { label: "NEW JOB", bg: "#0F0F0F" },
    service: { label: "NEW SERVICE", bg: "#FF4D8D" },
    community: { label: "NEW COMMUNITY", bg: "#7C3AED" },
  };
  const meta = kindLabel[kind] ?? { label: "NEW", bg: "#0F0F0F" };

  const inner = (
    <div className="overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F]">
      {entity.cover ? (
        <img src={entity.cover} alt={entity.title} className="aspect-video w-full object-cover" />
      ) : (
        <div
          className="grid aspect-video w-full place-items-center"
          style={{ background: `linear-gradient(135deg, ${meta.bg}, #0F0F0F)` }}
        >
          <span className="font-display text-3xl font-black text-white/90">{entity.title.slice(0, 1)}</span>
        </div>
      )}
      <div className="flex items-center justify-between gap-2 p-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-wider text-white" style={{ background: meta.bg }}>
              {meta.label}
            </span>
          </div>
          <div className="mt-1 truncate font-display text-sm font-bold">{entity.title}</div>
          {entity.subtitle && (
            <div className="mt-0.5 truncate text-[11px] text-muted-foreground">{entity.subtitle}</div>
          )}
        </div>
        <span className="shrink-0 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1 text-[11px] font-bold">
          View →
        </span>
      </div>
    </div>
  );

  const wrapperClass = "mx-4 mb-3 block transition hover:-translate-y-0.5";
  if (entity.table === "jobs") {
    return <Link to="/jobs/$id" params={{ id: entity.id }} className={wrapperClass}>{inner}</Link>;
  }
  if (entity.table === "services") {
    return <Link to="/services/$id" params={{ id: entity.id }} className={wrapperClass}>{inner}</Link>;
  }
  return <Link to="/communities/$slug" params={{ slug: entity.slug ?? entity.id }} className={wrapperClass}>{inner}</Link>;
}


/* -------------------- Comments -------------------- */

function CommentThread({ postId, postAuthorId }: { postId: string; postAuthorId: string }) {
  const qc = useQueryClient();
  const { user } = useAuth();
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [replyTo, setReplyTo] = useState<{ id: string; name: string } | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [confirmDelId, setConfirmDelId] = useState<string | null>(null);
  const { data: comments = [], isLoading } = useQuery({
    queryKey: ["feed", "comments", postId],
    queryFn: () => listComments(postId),
  });

  useCommentsRealtime(postId, () => {
    qc.invalidateQueries({ queryKey: ["feed", "comments", postId] });
    qc.invalidateQueries({ queryKey: ["feed", "list"] });
  });

  const submit = async (parentId: string | null = null) => {
    if (!user) { toast.error("Sign in to comment"); return; }
    if (!text.trim()) return;
    setSending(true);
    try {
      await addComment(postId, text, parentId);
      xpToast(10);
      setText("");
      setReplyTo(null);
    } catch (e: any) {
      toast.error(e?.message || "Failed to comment");
    } finally {
      setSending(false);
    }
  };

  const saveEdit = async (id: string) => {
    if (!editText.trim()) return;
    try {
      await editComment(id, editText);
      toast.success("Comment updated");
      setEditingId(null);
      qc.invalidateQueries({ queryKey: ["feed", "comments", postId] });
    } catch (e: any) {
      toast.error(e?.message || "Couldn't update (edit window is 30 min)");
    }
  };

  const doDelete = async (id: string) => {
    try {
      await deleteComment(id);
      toast.success("Comment deleted");
      setConfirmDelId(null);
      qc.invalidateQueries({ queryKey: ["feed", "comments", postId] });
      qc.invalidateQueries({ queryKey: ["feed", "list"] });
    } catch (e: any) {
      toast.error(e?.message || "Couldn't delete");
    }
  };

  // Group replies by parent id
  const roots = comments.filter((c) => !c.parent_comment_id);
  const repliesByParent = new Map<string, LiveComment[]>();
  comments.forEach((c) => {
    if (c.parent_comment_id) {
      const arr = repliesByParent.get(c.parent_comment_id) ?? [];
      arr.push(c);
      repliesByParent.set(c.parent_comment_id, arr);
    }
  });

  const renderOne = (c: LiveComment, isReply = false) => {
    const isPostAuthor = c.author_id === postAuthorId;
    const isMine = user?.id === c.author_id;
    const withinEditWindow = Date.now() - new Date(c.created_at).getTime() < 30 * 60 * 1000;
    const isEditing = editingId === c.id;
    return (
      <div key={c.id} className={cn("group/comment flex gap-2.5", isReply && "ml-8")}>
        <Link to="/u/$username" params={{ username: c.author?.username || "unknown" }} className="shrink-0">
          <img
            src={c.author?.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${c.author_id}`}
            className={cn("rounded-full border-[1.5px] border-[#0F0F0F]", isReply ? "h-6 w-6" : "h-7 w-7")}
            alt=""
          />
        </Link>
        <div className="min-w-0 flex-1">
          <div className="rounded-2xl bg-white px-3 py-2 text-xs">
            <div className="flex flex-wrap items-center gap-1.5">
              <Link
                to="/u/$username"
                params={{ username: c.author?.username || "unknown" }}
                className="font-bold hover:underline"
              >
                {c.author?.display_name || c.author?.username || "User"}
              </Link>
              {isPostAuthor && (
                <span className="rounded-full bg-coral/10 px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wider text-coral">
                  Author
                </span>
              )}
            </div>
            {isEditing ? (
              <div className="mt-1">
                <textarea
                  autoFocus
                  value={editText}
                  onChange={(e) => setEditText(e.target.value.slice(0, 1000))}
                  rows={2}
                  className="w-full resize-none rounded-lg border-[1.5px] border-[#0F0F0F]/20 bg-surface px-2 py-1.5 text-xs outline-none focus:border-coral"
                />
                <div className="mt-1.5 flex items-center justify-end gap-1.5">
                  <button onClick={() => setEditingId(null)} className="rounded-full border border-[#0F0F0F]/20 bg-white px-2 py-0.5 text-[10px] font-bold">Cancel</button>
                  <button onClick={() => saveEdit(c.id)} className="rounded-full bg-coral px-2.5 py-0.5 text-[10px] font-bold text-white">Save</button>
                </div>
              </div>
            ) : (
              <div className="mt-0.5 whitespace-pre-wrap">
                {c.body}
                {c.edited_at && <span className="ml-1 text-[9px] text-muted-foreground">(edited)</span>}
              </div>
            )}
          </div>
          <div className="mt-1 flex items-center gap-3 pl-3 text-[10px] text-muted-foreground">
            <span>{timeAgo(c.created_at)}</span>
            {!isReply && user && !isEditing && (
              <button
                onClick={() => {
                  setReplyTo({ id: c.id, name: c.author?.display_name || c.author?.username || "User" });
                  setText("");
                }}
                className="font-bold hover:text-coral"
              >
                Reply
              </button>
            )}
            {isMine && !isEditing && withinEditWindow && (
              <button
                onClick={() => { setEditingId(c.id); setEditText(c.body); }}
                className="font-bold hover:text-coral"
              >
                Edit
              </button>
            )}
            {isMine && !isEditing && (
              <button
                onClick={() => setConfirmDelId(c.id)}
                className="font-bold hover:text-error"
              >
                Delete
              </button>
            )}
          </div>

          {confirmDelId === c.id && (
            <div className="mt-1.5 flex items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F]/20 bg-white px-2 py-1.5 text-[11px]">
              <span className="font-semibold">Delete this comment?</span>
              <button onClick={() => doDelete(c.id)} className="ml-auto rounded-full bg-error px-2 py-0.5 text-[10px] font-bold text-white">Delete</button>
              <button onClick={() => setConfirmDelId(null)} className="rounded-full border border-[#0F0F0F]/20 bg-white px-2 py-0.5 text-[10px] font-bold">Cancel</button>
            </div>
          )}

          {/* Nested replies */}
          {!isReply && (repliesByParent.get(c.id) ?? []).map((r) => renderOne(r, true))}

          {/* Inline reply composer */}
          {!isReply && replyTo?.id === c.id && user && (
            <div className="relative mt-2 ml-8 flex items-center gap-2">
              <EmojiPicker onPick={(e) => setText((t) => t + e)} />
              <input
                autoFocus
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && (e.preventDefault(), submit(c.id))}
                placeholder={`Reply to ${replyTo.name}…`}
                maxLength={1000}
                className="flex-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-coral"
              />
              <button
                onClick={() => submit(c.id)}
                disabled={sending}
                className="inline-flex items-center gap-1 rounded-full bg-coral px-3 py-1.5 text-xs font-bold text-white disabled:opacity-60"
              >
                {sending ? <Loader2 className="h-3 w-3 animate-spin" /> : <Send className="h-3 w-3" />}
              </button>
              <button
                onClick={() => { setReplyTo(null); setText(""); }}
                className="rounded-full border-[1.5px] border-[#0F0F0F]/20 bg-white px-3 py-1.5 text-xs font-bold"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-3 border-t-[1.5px] border-[#0F0F0F]/10 bg-surface/40 p-4">
      {isLoading && <div className="text-xs text-muted-foreground">Loading comments…</div>}
      {roots.map((c) => renderOne(c))}
      {user && !replyTo ? (
        <div className="relative flex items-center gap-2 pt-1">
          <EmojiPicker onPick={(e) => setText((t) => t + e)} />
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && (e.preventDefault(), submit(null))}
            placeholder="Write a comment…"
            maxLength={1000}
            className="flex-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-coral"
          />
          <button
            onClick={() => submit(null)}
            disabled={sending}
            className="inline-flex items-center gap-1 rounded-full bg-coral px-4 py-1.5 text-xs font-bold text-white disabled:opacity-60"
          >
            {sending ? <Loader2 className="h-3 w-3 animate-spin" /> : <Send className="h-3 w-3" />} Post
          </button>
        </div>
      ) : !user ? (
        <div className="pt-1 text-xs text-muted-foreground">
          <Link to="/auth" className="font-bold text-coral hover:underline">Sign in</Link> to comment.
        </div>
      ) : null}
    </div>
  );
}

