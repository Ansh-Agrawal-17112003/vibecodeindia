import { useEffect, useRef, useState } from "react";
import { Play, X, Quote, Newspaper, Sparkles, TrendingUp, Users, Rocket, Star } from "lucide-react";
import { CompanyLogo } from "@/components/site/CompanyLogo";
import { Highlighter } from "@/registry/magicui/highlighter";

/* Brand tokens */
const CORAL = "#E8623A";
const DARK = "#0F0F0F";
const CREAM = "#FAF6F1";
const WHITE = "#FFFFFF";
const MUTED = "#7a7a7a";

const avatarUrl = (seed: string) =>
  `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed || "og")}`;

/* ========================================================================
   #5 Trust Metrics Counter Bar
   ======================================================================== */
export function TrustMetricsBar({
  taken,
  remaining,
}: {
  taken: number;
  remaining: number;
}) {
  const metrics = [
    { icon: Users, label: "Builders onboard", value: taken, suffix: "" },
    { icon: Rocket, label: "Cities in India", value: 47, suffix: "+" },
    { icon: TrendingUp, label: "Avg project ships", value: 12, suffix: "hrs" },
    { icon: Sparkles, label: "OG seats left", value: remaining, suffix: "/100", accent: true },
  ];
  return (
    <section className="relative w-full overflow-hidden py-10 md:py-14" style={{ background: DARK }}>
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{ background: "radial-gradient(600px circle at 50% 50%, rgba(232,98,58,0.14), transparent 60%)" }}
      />
      <div className="relative mx-auto grid w-full max-w-[1100px] grid-cols-2 gap-4 px-4 md:grid-cols-4 md:gap-6 md:px-8">
        {metrics.map((m, i) => (
          <div
            key={i}
            className="rounded-[16px] p-4 md:p-5"
            style={{
              background: m.accent ? "rgba(232,98,58,0.12)" : "rgba(255,255,255,0.04)",
              border: `1.5px solid ${m.accent ? CORAL : "rgba(255,255,255,0.14)"}`,
            }}
          >
            <div className="flex items-center gap-2 text-white/60">
              <m.icon className="h-3.5 w-3.5" style={{ color: m.accent ? CORAL : "rgba(255,255,255,0.55)" }} />
              <span className="text-[10px] font-bold uppercase tracking-[0.16em]">{m.label}</span>
            </div>
            <div
              className="mt-2 font-display font-black tabular-nums leading-none"
              style={{ fontSize: "clamp(28px,5vw,44px)", color: m.accent ? CORAL : WHITE, letterSpacing: "-0.03em" }}
            >
              {m.value}
              <span className="ml-0.5 text-[0.5em] font-bold" style={{ color: "rgba(255,255,255,0.4)" }}>
                {m.suffix}
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ========================================================================
   #2 Investor / Backer Strip
   ======================================================================== */
// TODO: swap with real backer names when live
const BACKERS = [
  "Peak XV Scout",
  "Better Capital",
  "First Cheque",
  "Titan Capital",
  "AngelList India",
  "100X.VC",
];

export function BackerStrip() {
  return (
    <section className="relative w-full py-10 md:py-14" style={{ background: CREAM, borderTop: `1.5px solid ${DARK}`, borderBottom: `1.5px solid ${DARK}` }}>
      <div className="mx-auto w-full max-w-[1100px] px-4 md:px-8">
        <div className="mb-6 flex items-center justify-center gap-3">
          <div className="h-px w-8" style={{ background: DARK, opacity: 0.2 }} />
          <span className="font-mono text-[10px] font-bold uppercase tracking-[0.24em]" style={{ color: MUTED }}>
            Backed by angels · builders · operators
          </span>
          <div className="h-px w-8" style={{ background: DARK, opacity: 0.2 }} />
        </div>
        <div className="grid grid-cols-2 items-center gap-6 sm:grid-cols-3 md:grid-cols-6">
          {BACKERS.map((name) => (
            <div key={name} className="flex items-center justify-center">
              <span
                className="text-center font-display text-[13px] font-extrabold uppercase tracking-[0.08em] transition-opacity hover:opacity-100 md:text-[14px]"
                style={{ color: DARK, opacity: 0.55 }}
              >
                {name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ========================================================================
   #4 Press Mentions Ticker
   ======================================================================== */
// TODO: swap with real press mentions when live
const PRESS = [
  { name: "YourStory", quote: "The Bengaluru community redefining what 'builder' means" },
  { name: "Inc42", quote: "India's answer to Product Hunt for AI-native creators" },
  { name: "Analytics India Mag", quote: "Where the next wave of Indian AI founders are being minted" },
  { name: "The Ken", quote: "A movement, not a directory" },
  { name: "MoneyControl", quote: "One of 2026's most watched Indian communities" },
];

export function PressTicker() {
  return (
    <section className="relative w-full overflow-hidden py-10 md:py-14" style={{ background: WHITE }}>
      <div className="mx-auto mb-6 flex w-full max-w-[1100px] items-center justify-center gap-2 px-4 md:px-8">
        <Newspaper className="h-3.5 w-3.5" style={{ color: CORAL }} />
        <span className="font-mono text-[10px] font-bold uppercase tracking-[0.24em]" style={{ color: MUTED }}>
          In the press · early conversations
        </span>
      </div>
      <div className="relative w-full">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16" style={{ background: `linear-gradient(90deg, ${WHITE}, transparent)` }} />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16" style={{ background: `linear-gradient(-90deg, ${WHITE}, transparent)` }} />
        <div className="flex overflow-hidden">
          <div className="flex shrink-0 items-stretch gap-4 pr-4" style={{ animation: "ea-press-marquee 55s linear infinite" }}>
            {[...PRESS, ...PRESS].map((p, i) => (
              <div
                key={i}
                className="w-[300px] shrink-0 rounded-[14px] p-4 md:w-[360px]"
                style={{ background: CREAM, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${DARK}` }}
              >
                <div className="font-display text-[13px] font-extrabold uppercase tracking-[0.14em]" style={{ color: CORAL }}>
                  {p.name}
                </div>
                <div className="mt-2 text-[13px] leading-[1.55] italic" style={{ color: DARK }}>
                  "{p.quote}"
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <style>{`@keyframes ea-press-marquee { from { transform: translateX(0);} to { transform: translateX(-50%);} }`}</style>
    </section>
  );
}

/* ========================================================================
   #3 Founder Video Loom Card
   ======================================================================== */
export function FounderVideoCard({
  videoUrl,
  posterUrl,
}: {
  videoUrl?: string;
  posterUrl?: string;
}) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [open]);

  return (
    <section className="relative w-full overflow-hidden py-16 md:py-24" style={{ background: WHITE }}>
      <div className="relative mx-auto grid w-full max-w-[1100px] grid-cols-1 items-center gap-10 px-4 md:grid-cols-[1fr_1.1fr] md:gap-14 md:px-8">
        <div>
          <div
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]"
            style={{ background: "#FFF1EA", borderColor: CORAL, color: CORAL }}
          >
            <Play className="h-3 w-3" /> 90-second story
          </div>
          <h2 className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ fontSize: "clamp(28px,5vw,52px)", color: DARK }}>
            Why we're <Highlighter action="underline" color={CORAL} strokeWidth={2.5} padding={1} animationDuration={900}>building this</Highlighter>.
          </h2>
          <p className="mt-4 text-[15px] leading-[1.7] md:text-[16px]" style={{ color: MUTED }}>
            No pitch deck. No fundraising deck. Just the founder, a webcam, and 90 seconds on why India's AI builders deserve a home of their own.
          </p>
          <button
            onClick={() => setOpen(true)}
            className="mt-6 inline-flex items-center gap-2 rounded-full px-5 py-3 text-[13px] font-extrabold transition hover:-translate-y-0.5"
            style={{ background: DARK, color: WHITE, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${CORAL}` }}
          >
            <Play className="h-3.5 w-3.5" /> Watch the story
          </button>
        </div>

        <button
          onClick={() => setOpen(true)}
          className="group relative aspect-video w-full overflow-hidden rounded-[20px]"
          style={{ background: DARK, border: `1.5px solid ${DARK}`, boxShadow: `8px 8px 0 0 ${CORAL}` }}
        >
          {posterUrl ? (
            <img src={posterUrl} alt="Founder video" className="h-full w-full object-cover opacity-90 transition group-hover:opacity-100" />
          ) : (
            <div
              className="grid h-full w-full place-items-center"
              style={{
                background: `radial-gradient(circle at 30% 40%, rgba(232,98,58,0.35), ${DARK} 65%)`,
              }}
            >
              <div className="text-center text-white">
                <div className="font-mono text-[10px] font-bold uppercase tracking-[0.24em] opacity-60">Founder message</div>
                <div className="mt-2 font-display text-[22px] font-black tracking-[-0.02em]">"Read this before you sign up."</div>
              </div>
            </div>
          )}
          <div className="absolute inset-0 grid place-items-center">
            <span
              className="grid h-20 w-20 place-items-center rounded-full transition-transform group-hover:scale-110"
              style={{ background: CORAL, border: `1.5px solid ${DARK}`, boxShadow: `4px 4px 0 0 ${DARK}` }}
            >
              <Play className="h-8 w-8 fill-white text-white" style={{ marginLeft: 3 }} />
            </span>
          </div>
          <div className="absolute bottom-3 left-3 rounded-full px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.2em]" style={{ background: "rgba(0,0,0,0.6)", color: WHITE, backdropFilter: "blur(6px)" }}>
            1:32 · Founder loom
          </div>
        </button>
      </div>

      {open && (
        <div
          className="fixed inset-0 z-[280] grid place-items-center px-4"
          style={{ background: "rgba(15,15,15,0.9)", backdropFilter: "blur(10px)" }}
          onClick={() => setOpen(false)}
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-[900px]" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setOpen(false)}
              className="absolute -top-12 right-0 grid h-10 w-10 place-items-center rounded-full text-white transition hover:bg-white/10"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
            <div
              className="aspect-video overflow-hidden rounded-[16px]"
              style={{ background: DARK, border: `1.5px solid ${WHITE}`, boxShadow: `6px 6px 0 0 ${CORAL}` }}
            >
              {videoUrl ? (
                <iframe
                  src={videoUrl}
                  title="Founder story"
                  className="h-full w-full"
                  allow="autoplay; fullscreen; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <div className="grid h-full w-full place-items-center text-center text-white/70">
                  <div>
                    <Play className="mx-auto mb-4 h-12 w-12" />
                    <div className="font-mono text-[11px] font-bold uppercase tracking-[0.24em]">Video coming soon</div>
                    <div className="mt-2 text-[14px]">Founder recording drops before launch. Claim your OG spot to be notified first.</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

/* ========================================================================
   #7 "Who's Already In" — Company Logo Cloud
   ======================================================================== */
const WORKPLACE_COMPANIES = [
  "Razorpay", "CRED", "Zomato", "Swiggy", "Flipkart", "Paytm", "PhonePe",
  "Meesho", "Nykaa", "Postman", "Freshworks", "Zepto", "Unacademy",
  "Acko", "Sarvam AI", "Atlassian", "Browserstack", "Infosys",
];

export function WorkplaceCloud() {
  return (
    <section className="relative w-full overflow-hidden py-16 md:py-24" style={{ background: CREAM }}>
      <div className="relative mx-auto w-full max-w-[1100px] px-4 md:px-8">
        <div className="text-center">
          <div
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]"
            style={{ background: WHITE, borderColor: DARK, color: DARK }}
          >
            <Users className="h-3 w-3" style={{ color: CORAL }} /> Your future teammates
          </div>
          <h2 className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ fontSize: "clamp(26px,5vw,52px)", color: DARK }}>
            Builders here ship at <Highlighter action="highlight" color="rgba(245,166,35,0.32)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>India's best</Highlighter>.
          </h2>
          <p className="mx-auto mt-4 max-w-[540px] text-[14px] leading-[1.7] md:text-[15px]" style={{ color: MUTED }}>
            The OGs come from unicorns, seed-stage startups, and stealth AI labs — plus a lot of solo builders. Here's a slice.
          </p>
        </div>

        <div
          className="mx-auto mt-10 grid gap-3 rounded-[20px] p-5 md:p-8"
          style={{
            gridTemplateColumns: "repeat(auto-fit, minmax(96px, 1fr))",
            background: WHITE,
            border: `1.5px solid ${DARK}`,
            boxShadow: `5px 5px 0 0 ${DARK}`,
          }}
        >
          {WORKPLACE_COMPANIES.map((name) => (
            <div
              key={name}
              className="group flex flex-col items-center gap-2 rounded-[12px] p-3 transition-transform hover:-translate-y-1"
              title={name}
            >
              <CompanyLogo name={name} size={44} radius={12} />
              <span className="truncate text-[11px] font-bold" style={{ color: DARK }}>{name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ========================================================================
   #6 Community Testimonial Masonry
   ======================================================================== */
const TESTIMONIALS = [
  { name: "Chirag Dhamija", role: "Founder", city: "New Delhi", og: 7, quote: "I found my kind of builders on VibeCode in week two. That alone paid for the next decade of my career.", tilt: -1.5 },
  { name: "Sarvam", role: "AI Automation Freelancer", city: "Jhansi", og: 4, quote: "Landed three retainer clients from my profile in the first month. This is the only builder platform in India that actually converts.", tilt: 1 },
  { name: "Harsh Purwar", role: "Student · Custom GPTs", city: "New Delhi", og: 8, quote: "I'm a student. My first project got real attention here — founders actually DMed me. VibeCode is basically LinkedIn but for people who ship.", tilt: -0.5 },
  { name: "Shubham Agarwal", role: "Researcher & Builder", city: "Bangalore", og: 6, quote: "Every other 'community' is a Discord graveyard. VibeCode's feed is actually alive.", tilt: 2 },
  { name: "Aliasgar Haji", role: "Agency · AI Growth", city: "Mumbai", og: 10, quote: "The Wall isn't a vanity metric — it's a client funnel. Two serious inbound leads within a week of going live.", tilt: -1 },
  { name: "Syed Kaifuddin", role: "Solo Builder", city: "Bengaluru", og: 18, quote: "I ship prompts, workflows, and templates weekly. The XP system makes it addictive in the best way.", tilt: 1.5 },
];

export function TestimonialMasonry() {
  return (
    <section className="relative w-full overflow-hidden py-16 md:py-24" style={{ background: WHITE }}>
      <div className="relative mx-auto w-full max-w-[1200px] px-4 md:px-8">
        <div className="text-center">
          <div
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]"
            style={{ background: CREAM, borderColor: DARK, color: DARK }}
          >
            <Quote className="h-3 w-3" style={{ color: CORAL }} /> From the OGs
          </div>
          <h2 className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ fontSize: "clamp(28px,5vw,54px)", color: DARK }}>
            Real builders. <Highlighter action="underline" color={CORAL} strokeWidth={2.5} padding={1} animationDuration={900}>Real receipts</Highlighter>.
          </h2>
        </div>

        <div className="mt-12 columns-1 gap-5 md:columns-2 lg:columns-3">
          {TESTIMONIALS.map((t, i) => (
            <div
              key={i}
              className="mb-5 break-inside-avoid rounded-[16px] p-5"
              style={{
                background: i % 2 === 0 ? CREAM : WHITE,
                border: `1.5px solid ${DARK}`,
                boxShadow: `4px 4px 0 0 ${i % 3 === 0 ? CORAL : DARK}`,
                transform: `rotate(${t.tilt}deg)`,
              }}
            >
              <div className="mb-3 flex items-start gap-2">
                {Array.from({ length: 5 }).map((_, s) => (
                  <Star key={s} className="h-3.5 w-3.5" style={{ color: CORAL, fill: CORAL }} />
                ))}
              </div>
              <p className="text-[14.5px] leading-[1.6] md:text-[15px]" style={{ color: DARK }}>
                "{t.quote}"
              </p>
              <div className="mt-4 flex items-center gap-3 border-t pt-4" style={{ borderColor: "rgba(15,15,15,0.1)" }}>
                <img src={avatarUrl(t.name)} alt="" className="h-10 w-10 rounded-full" style={{ background: WHITE, border: `1.5px solid ${DARK}` }} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13px] font-extrabold" style={{ color: DARK }}>{t.name}</div>
                  <div className="truncate text-[11px] font-semibold" style={{ color: MUTED }}>{t.role} · {t.city}</div>
                </div>
                <div
                  className="shrink-0 rounded-full px-2 py-1 font-mono text-[10px] font-bold tabular-nums"
                  style={{ background: DARK, color: CORAL }}
                >
                  #{String(t.og).padStart(3, "0")}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
