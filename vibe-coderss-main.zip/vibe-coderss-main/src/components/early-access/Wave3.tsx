import { useEffect, useMemo, useRef, useState } from "react";
import {
  Check, X, Crown, Sparkles, Zap, Trophy, Gift, Rocket, Users, Code2,
  Palette, Brain, Wrench, RefreshCw, ChevronRight, Activity, Circle,
} from "lucide-react";
import { Highlighter } from "@/registry/magicui/highlighter";

const CORAL = "#E8623A";
const DARK = "#0F0F0F";
const CREAM = "#FAF6F1";
const WHITE = "#FFFFFF";
const MUTED = "#7a7a7a";

const avatarUrl = (seed: string) =>
  `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed || "og")}`;

/* ========================================================================
   #9 Perks Comparison Table — OG vs Regular vs Free
   ======================================================================== */
const PERK_ROWS: Array<{ label: string; free: boolean | string; regular: boolean | string; og: boolean | string; hot?: boolean }> = [
  { label: "Public builder profile", free: true, regular: true, og: true },
  { label: "Post to the Wall", free: "3/mo", regular: true, og: true },
  { label: "DM other builders", free: false, regular: true, og: true },
  { label: "Founding OG badge (#001–#100)", free: false, regular: false, og: true, hot: true },
  { label: "Lifetime premium — never billed", free: false, regular: false, og: true, hot: true },
  { label: "Private OG-only lounge", free: false, regular: false, og: true },
  { label: "Weekly office hours w/ founders", free: false, regular: false, og: true },
  { label: "Vote on the product roadmap", free: false, regular: false, og: true },
  { label: "Priority hiring visibility", free: false, "regular": "boost", og: "top" },
  { label: "Job board access", free: "read", regular: true, og: true },
  { label: "Featured in launch press", free: false, regular: false, og: true },
];

function Cell({ v }: { v: boolean | string }) {
  if (v === true) return <Check className="mx-auto h-4 w-4" style={{ color: CORAL }} strokeWidth={3} />;
  if (v === false) return <X className="mx-auto h-4 w-4" style={{ color: "rgba(15,15,15,0.25)" }} strokeWidth={2.5} />;
  return <span className="font-mono text-[10px] font-bold uppercase tracking-[0.1em]" style={{ color: DARK }}>{v}</span>;
}

export function PerksComparisonTable() {
  return (
    <section className="relative w-full py-16 md:py-24" style={{ background: CREAM }}>
      <div className="mx-auto w-full max-w-[1100px] px-4 md:px-8">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]" style={{ background: WHITE, borderColor: DARK, color: DARK }}>
            <Trophy className="h-3 w-3" style={{ color: CORAL }} /> The receipts
          </div>
          <h2 className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ fontSize: "clamp(28px,5vw,52px)", color: DARK }}>
            What OG actually <Highlighter action="highlight" color="rgba(245,166,35,0.32)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>unlocks</Highlighter>.
          </h2>
          <p className="mx-auto mt-4 max-w-[560px] text-[15px] leading-[1.7]" style={{ color: MUTED }}>
            Every row below is a permanent difference. OG isn't a discount — it's a different tier of membership, for life.
          </p>
        </div>

        {/* Desktop table */}
        <div className="mt-12 hidden overflow-hidden rounded-[20px] md:block" style={{ background: WHITE, border: `1.5px solid ${DARK}`, boxShadow: `6px 6px 0 0 ${DARK}` }}>
          <div className="grid grid-cols-[1.6fr_1fr_1fr_1.15fr] items-stretch" style={{ background: DARK, color: WHITE }}>
            <div className="px-6 py-4 font-mono text-[10px] font-bold uppercase tracking-[0.22em] opacity-70">Perk</div>
            <div className="px-4 py-4 text-center font-display text-[13px] font-extrabold uppercase tracking-[0.14em]">Free</div>
            <div className="px-4 py-4 text-center font-display text-[13px] font-extrabold uppercase tracking-[0.14em]">Regular</div>
            <div className="relative px-4 py-4 text-center font-display text-[13px] font-extrabold uppercase tracking-[0.14em]" style={{ background: CORAL, color: DARK }}>
              <Crown className="mr-1 inline h-3.5 w-3.5" /> OG (100 seats)
            </div>
          </div>
          {PERK_ROWS.map((row, i) => (
            <div
              key={i}
              className="grid grid-cols-[1.6fr_1fr_1fr_1.15fr] items-center"
              style={{ borderTop: i === 0 ? "none" : `1px solid rgba(15,15,15,0.08)`, background: row.hot ? "rgba(232,98,58,0.06)" : WHITE }}
            >
              <div className="flex items-center gap-2 px-6 py-4 text-[14px] font-semibold" style={{ color: DARK }}>
                {row.hot && <Sparkles className="h-3.5 w-3.5" style={{ color: CORAL }} />}
                {row.label}
              </div>
              <div className="px-4 py-4 text-center"><Cell v={row.free} /></div>
              <div className="px-4 py-4 text-center"><Cell v={row.regular} /></div>
              <div className="px-4 py-4 text-center" style={{ background: "rgba(232,98,58,0.08)" }}><Cell v={row.og} /></div>
            </div>
          ))}
        </div>

        {/* Mobile stacked cards */}
        <div className="mt-10 grid gap-4 md:hidden">
          {(["free", "regular", "og"] as const).map((tier) => {
            const label = tier === "og" ? "OG · 100 seats" : tier === "regular" ? "Regular" : "Free";
            const isOg = tier === "og";
            return (
              <div key={tier} className="rounded-[16px] p-5" style={{ background: isOg ? DARK : WHITE, color: isOg ? WHITE : DARK, border: `1.5px solid ${DARK}`, boxShadow: `4px 4px 0 0 ${isOg ? CORAL : DARK}` }}>
                <div className="mb-3 flex items-center justify-between">
                  <div className="font-display text-[16px] font-extrabold uppercase tracking-[0.1em]">
                    {isOg && <Crown className="mr-1 inline h-4 w-4" style={{ color: CORAL }} />}
                    {label}
                  </div>
                </div>
                <ul className="space-y-2">
                  {PERK_ROWS.map((row, i) => {
                    const v = row[tier];
                    return (
                      <li key={i} className="flex items-start gap-2 text-[13px]">
                        {v === true ? <Check className="mt-0.5 h-3.5 w-3.5 shrink-0" style={{ color: CORAL }} strokeWidth={3} /> :
                          v === false ? <X className="mt-0.5 h-3.5 w-3.5 shrink-0 opacity-40" strokeWidth={2.5} /> :
                          <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0" style={{ color: CORAL }} />}
                        <span style={{ opacity: v === false ? 0.4 : 1 }}>
                          {row.label}{typeof v === "string" ? ` — ${v}` : ""}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ========================================================================
   #10 Scroll-Jacked Journey Timeline
   ======================================================================== */
const JOURNEY = [
  { k: "Step 1", title: "Claim your OG seat", body: "Fill the 90-second form and lock a permanent OG number between #001 and #100. The moment you hit submit, that number is reserved in your name — forever.", icon: Crown },
  { k: "Step 2", title: "Thank-you confirmation lands", body: "You get an instant confirmation email with your OG number, your Founders Wall entry, and everything that unlocks on August 4. No spam sequences — one clean receipt.", icon: Sparkles },
  { k: "Step 3", title: "Your name goes on the Founders Wall", body: "Within minutes your name, city and tagline appear on the public Founders Wall at joinvibecode.xyz/founders-wall — a permanent, screenshot-able record of being one of the first 100.", icon: Users },
  { k: "Aug 04", title: "Launch day — claim your profile", body: "On August 4, 2026 VibeCode goes live. Sign in with the same email and your OG profile auto-activates with the #OG badge visible to every visitor.", icon: Rocket },
  { k: "Aug 04+", title: "Premium features worth ₹6,000+ unlock", body: "1 full year of Pro (₹5,988), 500 VibeCoins, top-of-search placement, verified badge, priority job apps, profile analytics, and the private OG WhatsApp group — all switched on automatically.", icon: Gift },
];

export function ScrollJourneyTimeline() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const nodes = Array.from(el.querySelectorAll<HTMLElement>("[data-step]"));
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            const idx = Number((e.target as HTMLElement).dataset.step);
            setActive(idx);
          }
        });
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: 0 }
    );
    nodes.forEach((n) => io.observe(n));
    return () => io.disconnect();
  }, []);

  return (
    <section className="relative w-full overflow-hidden py-16 md:py-24" style={{ background: WHITE }}>
      <div className="mx-auto w-full max-w-[1200px] px-4 md:px-8">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]" style={{ background: CREAM, borderColor: DARK, color: DARK }}>
            <Zap className="h-3 w-3" style={{ color: CORAL }} /> The journey
          </div>
          <h2 className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ fontSize: "clamp(28px,5vw,52px)", color: DARK }}>
            From signup to <Highlighter action="underline" color={CORAL} strokeWidth={2.5} padding={1} animationDuration={900}>shipping</Highlighter>.
          </h2>
          <p className="mx-auto mt-4 max-w-[520px] text-[15px] leading-[1.7]" style={{ color: MUTED }}>
            Every step you'll actually experience — no vague roadmap, no "coming soon" — just what happens after you claim your OG number.
          </p>
        </div>

        <div ref={wrapRef} className="mt-14 grid md:grid-cols-[1fr_1.4fr] md:gap-12">
          {/* Sticky visual */}
          <div className="hidden md:block">
            <div className="sticky top-24">
              <div
                className="relative aspect-square w-full overflow-hidden rounded-[28px]"
                style={{ background: DARK, border: `1.5px solid ${DARK}`, boxShadow: `8px 8px 0 0 ${CORAL}` }}
              >
                <div
                  aria-hidden
                  className="absolute inset-0 opacity-60"
                  style={{ background: `radial-gradient(circle at 30% 30%, rgba(232,98,58,0.35), transparent 60%)` }}
                />
                <div className="relative grid h-full w-full place-items-center p-8 text-center text-white">
                  <div>
                    <div className="mx-auto grid h-20 w-20 place-items-center rounded-2xl" style={{ background: CORAL, border: `1.5px solid ${WHITE}`, boxShadow: `4px 4px 0 0 ${WHITE}` }}>
                      {(() => { const I = JOURNEY[active].icon; return <I className="h-10 w-10" style={{ color: DARK }} strokeWidth={2.2} />; })()}
                    </div>
                    <div className="mt-6 font-mono text-[10px] font-bold uppercase tracking-[0.24em] opacity-60">Stage {active + 1} of {JOURNEY.length}</div>
                    <div className="mt-3 font-display text-[36px] font-black tracking-[-0.03em]" style={{ color: CORAL }}>{JOURNEY[active].k}</div>
                    <div className="mt-2 font-display text-[20px] font-extrabold">{JOURNEY[active].title}</div>
                  </div>
                </div>
                {/* progress dots */}
                <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 items-center gap-2">
                  {JOURNEY.map((_, i) => (
                    <div key={i} className="h-1.5 rounded-full transition-all" style={{ width: i === active ? 24 : 8, background: i === active ? CORAL : "rgba(255,255,255,0.25)" }} />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Scrolling steps */}
          <div className="relative">
            {/* vertical rail */}
            <div className="absolute left-4 top-4 bottom-4 w-px md:left-6" style={{ background: "rgba(15,15,15,0.1)" }} />
            <div className="space-y-6 md:space-y-10">
              {JOURNEY.map((s, i) => {
                const on = i === active;
                return (
                  <div key={i} data-step={i} className="relative min-h-[220px] pl-12 md:pl-16 md:min-h-[280px]">
                    <div
                      className="absolute left-0 top-2 grid h-8 w-8 place-items-center rounded-full transition-all md:h-12 md:w-12"
                      style={{ background: on ? CORAL : WHITE, border: `1.5px solid ${DARK}`, boxShadow: on ? `3px 3px 0 0 ${DARK}` : "none", transform: on ? "scale(1.05)" : "scale(1)" }}
                    >
                      <s.icon className="h-4 w-4 md:h-5 md:w-5" style={{ color: on ? WHITE : DARK }} strokeWidth={2.2} />
                    </div>
                    <div className="font-mono text-[10px] font-bold uppercase tracking-[0.22em]" style={{ color: on ? CORAL : MUTED }}>{s.k}</div>
                    <div className="mt-2 font-display text-[22px] font-extrabold tracking-[-0.02em] md:text-[28px]" style={{ color: DARK }}>{s.title}</div>
                    <p className="mt-3 max-w-[520px] text-[14px] leading-[1.7] md:text-[15px]" style={{ color: MUTED }}>{s.body}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========================================================================
   #12 Spin-the-Wheel Perk Reveal
   ======================================================================== */
const WHEEL_PERKS = [
  { label: "500 VibeCoins", color: "#E8623A" },
  { label: "Zoom w/ Founder", color: "#0F0F0F" },
  { label: "Wall Feature", color: "#E8623A" },
  { label: "Profile Boost", color: "#0F0F0F" },
  { label: "Roadmap Vote x3", color: "#E8623A" },
  { label: "Lifetime Badge", color: "#0F0F0F" },
  { label: "Job Post Boost", color: "#E8623A" },
  { label: "Prompt Pack", color: "#0F0F0F" },
];

export function SpinWheelPerkReveal() {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const segments = WHEEL_PERKS.length;
  const segAngle = 360 / segments;

  const spin = () => {
    if (spinning) return;
    setResult(null);
    const winIdx = Math.floor(Math.random() * segments);
    const turns = 6 + Math.random() * 2;
    // pointer at top (0deg). Segment i center = i * segAngle + segAngle/2
    const targetOffset = 360 - (winIdx * segAngle + segAngle / 2);
    const total = rotation + turns * 360 + targetOffset - (rotation % 360);
    setRotation(total);
    setSpinning(true);
    window.setTimeout(() => {
      setSpinning(false);
      setResult(winIdx);
    }, 4200);
  };

  // Build conic gradient
  const gradient = useMemo(() => {
    const stops = WHEEL_PERKS.map((p, i) => `${p.color} ${i * segAngle}deg ${(i + 1) * segAngle}deg`).join(", ");
    return `conic-gradient(from 0deg, ${stops})`;
  }, [segAngle]);

  return (
    <section className="relative w-full overflow-hidden py-16 md:py-24" style={{ background: DARK }}>
      <div aria-hidden className="pointer-events-none absolute inset-0 opacity-60" style={{ background: `radial-gradient(700px circle at 50% 20%, rgba(232,98,58,0.18), transparent 60%)` }} />
      <div className="relative mx-auto grid w-full max-w-[1100px] grid-cols-1 items-center gap-10 px-4 md:grid-cols-[1.1fr_1fr] md:gap-16 md:px-8">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]" style={{ background: "rgba(255,255,255,0.06)", borderColor: CORAL, color: CORAL }}>
            <Gift className="h-3 w-3" /> Every OG spins
          </div>
          <h2 className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em] text-white" style={{ fontSize: "clamp(28px,5vw,54px)" }}>
            One free perk. <br /><Highlighter action="highlight" color="rgba(232,98,58,0.4)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>On the house</Highlighter>.
          </h2>
          <p className="mt-4 max-w-[440px] text-[15px] leading-[1.7] text-white/70">
            After you sign up, you'll spin this once. Whatever it lands on — hoodie, dinner, boost — is yours, no questions. Try it now.
          </p>
          {result !== null && !spinning && (
            <div className="mt-6 inline-flex items-center gap-3 rounded-[14px] px-4 py-3" style={{ background: CORAL, color: DARK, border: `1.5px solid ${WHITE}`, boxShadow: `4px 4px 0 0 ${WHITE}` }}>
              <Gift className="h-5 w-5" />
              <div>
                <div className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] opacity-70">You'd win</div>
                <div className="font-display text-[16px] font-extrabold">{WHEEL_PERKS[result].label}</div>
              </div>
            </div>
          )}
          <div className="mt-6">
            <button
              onClick={spin}
              disabled={spinning}
              className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-[13px] font-extrabold uppercase tracking-[0.12em] transition hover:-translate-y-0.5 disabled:opacity-60"
              style={{ background: CORAL, color: DARK, border: `1.5px solid ${WHITE}`, boxShadow: `4px 4px 0 0 ${WHITE}` }}
            >
              {spinning ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" /> Spinning…</> : result !== null ? <>Spin again</> : <><Sparkles className="h-3.5 w-3.5" /> Spin the wheel</>}
            </button>
          </div>
        </div>

        <div className="relative mx-auto aspect-square w-full max-w-[420px]">
          {/* Pointer */}
          <div className="absolute left-1/2 top-[-6px] z-20 -translate-x-1/2">
            <div className="h-0 w-0" style={{ borderLeft: "14px solid transparent", borderRight: "14px solid transparent", borderTop: `22px solid ${WHITE}`, filter: `drop-shadow(0 2px 0 ${DARK})` }} />
          </div>
          {/* Wheel */}
          <div
            className="relative aspect-square w-full rounded-full"
            style={{
              background: gradient,
              border: `4px solid ${WHITE}`,
              boxShadow: `0 0 0 4px ${DARK}, 8px 8px 0 0 ${CORAL}`,
              transform: `rotate(${rotation}deg)`,
              transition: spinning ? "transform 4s cubic-bezier(0.15, 0.85, 0.25, 1)" : "none",
            }}
          >
            {/* Text labels along each segment */}
            <svg viewBox="-100 -100 200 200" className="absolute inset-0 h-full w-full" aria-hidden>
              <defs>
                {WHEEL_PERKS.map((_, i) => {
                  // Arc path from segment start to end at radius 62, so text sits mid-slice reading outward.
                  const start = i * segAngle - 90;
                  const end = (i + 1) * segAngle - 90;
                  const r = 62;
                  const toXY = (deg: number) => {
                    const rad = (deg * Math.PI) / 180;
                    return [Math.cos(rad) * r, Math.sin(rad) * r];
                  };
                  const [x1, y1] = toXY(start);
                  const [x2, y2] = toXY(end);
                  return (
                    <path
                      key={i}
                      id={`wheel-arc-${i}`}
                      d={`M ${x1} ${y1} A ${r} ${r} 0 0 1 ${x2} ${y2}`}
                      fill="none"
                    />
                  );
                })}
              </defs>
              {WHEEL_PERKS.map((p, i) => (
                <text
                  key={i}
                  fill="#FFFFFF"
                  style={{
                    fontFamily: "var(--font-display, ui-sans-serif, system-ui)",
                    fontWeight: 800,
                    fontSize: 9,
                    letterSpacing: "0.06em",
                    textTransform: "uppercase",
                  }}
                >
                  <textPath href={`#wheel-arc-${i}`} startOffset="50%" textAnchor="middle">
                    {p.label}
                  </textPath>
                </text>
              ))}
              {/* Spoke dividers for crispness */}
              {WHEEL_PERKS.map((_, i) => {
                const a = ((i * segAngle - 90) * Math.PI) / 180;
                return (
                  <line
                    key={`sp-${i}`}
                    x1={0}
                    y1={0}
                    x2={Math.cos(a) * 96}
                    y2={Math.sin(a) * 96}
                    stroke="rgba(255,255,255,0.18)"
                    strokeWidth={0.6}
                  />
                );
              })}
            </svg>
            {/* center hub */}
            <div className="absolute left-1/2 top-1/2 grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full" style={{ background: WHITE, border: `3px solid ${DARK}` }}>
              <Crown className="h-6 w-6" style={{ color: CORAL }} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========================================================================
   #13 Builder Personality Quiz
   ======================================================================== */
type Archetype = "shipper" | "designer" | "thinker" | "tinkerer";
const ARCHETYPES: Record<Archetype, { title: string; tagline: string; body: string; color: string; icon: any; emoji: string }> = {
  shipper: { title: "The Shipper", tagline: "You'd rather ship v0.1 than plan v1.0", body: "You post updates the moment code compiles. Your wall will be a receipt of relentless output. OGs like you set the tempo for the whole community.", color: CORAL, icon: Rocket, emoji: "🚀" },
  designer: { title: "The Craftsperson", tagline: "Pixels matter. So does how a button feels.", body: "You'll be the one people DM for taste. Expect design-review threads, dribbble-tier profile shots, and a following built on quality.", color: "#0F0F0F", icon: Palette, emoji: "🎨" },
  thinker: { title: "The Systems Thinker", tagline: "You see the graph before the feature", body: "Prompt libraries, workflows, agent stacks — your posts will be the ones people bookmark. Long-tail authority is your game.", color: CORAL, icon: Brain, emoji: "🧠" },
  tinkerer: { title: "The Tinkerer", tagline: "You break things to understand them", body: "You'll live in the tools tab. Micro-projects, weird APIs, one-weekend hacks. The community loves people who share the messy middle.", color: "#0F0F0F", icon: Wrench, emoji: "🔧" },
};

const QUIZ: Array<{ q: string; opts: Array<{ label: string; a: Archetype }> }> = [
  {
    q: "Friday night. Your laptop is open. You're most likely to be…",
    opts: [
      { label: "Pushing a hotfix at 2am", a: "shipper" },
      { label: "Redesigning the same modal for the fourth time", a: "designer" },
      { label: "Reading a 12,000-word blog on agent frameworks", a: "thinker" },
      { label: "Wiring an ESP32 to something that shouldn't blink", a: "tinkerer" },
    ],
  },
  {
    q: "A new AI model drops. Your first move?",
    opts: [
      { label: "Ship a demo before the hype dies", a: "shipper" },
      { label: "Build a landing page for the demo you'll ship", a: "designer" },
      { label: "Sketch the mental model on paper", a: "thinker" },
      { label: "Chain it with three tools it wasn't meant for", a: "tinkerer" },
    ],
  },
  {
    q: "Your ideal first post on VibeCode is…",
    opts: [
      { label: "A launch — with a link and a video", a: "shipper" },
      { label: "A case study — with 12 crisp screenshots", a: "designer" },
      { label: "A framework post — 'here's how I think about X'", a: "thinker" },
      { label: "A weird hack — 'made this in 3 hours, YOLO'", a: "tinkerer" },
    ],
  },
  {
    q: "Pick your uniform.",
    opts: [
      { label: "Black tee, laptop stickers", a: "shipper" },
      { label: "One good jacket, always", a: "designer" },
      { label: "Whatever's on top of the pile", a: "thinker" },
      { label: "Whatever has the most pockets", a: "tinkerer" },
    ],
  },
];

export function BuilderPersonalityQuiz() {
  const [step, setStep] = useState(0);
  const [scores, setScores] = useState<Record<Archetype, number>>({ shipper: 0, designer: 0, thinker: 0, tinkerer: 0 });
  const done = step >= QUIZ.length;
  const winner: Archetype | null = done
    ? (Object.entries(scores).sort((a, b) => b[1] - a[1])[0][0] as Archetype)
    : null;

  const pick = (a: Archetype) => {
    setScores((s) => ({ ...s, [a]: s[a] + 1 }));
    setStep((n) => n + 1);
  };
  const reset = () => { setStep(0); setScores({ shipper: 0, designer: 0, thinker: 0, tinkerer: 0 }); };

  return (
    <section className="relative w-full overflow-hidden py-16 md:py-24" style={{ background: CREAM }}>
      <div className="mx-auto w-full max-w-[900px] px-4 md:px-8">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]" style={{ background: WHITE, borderColor: DARK, color: DARK }}>
            <Code2 className="h-3 w-3" style={{ color: CORAL }} /> 60-second quiz
          </div>
          <h2 className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ fontSize: "clamp(28px,5vw,52px)", color: DARK }}>
            What kind of <Highlighter action="underline" color={CORAL} strokeWidth={2.5} padding={1} animationDuration={900}>builder</Highlighter> are you?
          </h2>
          <p className="mx-auto mt-4 max-w-[500px] text-[15px] leading-[1.7]" style={{ color: MUTED }}>
            Four questions. One archetype. Your OG profile will hint at this from day one.
          </p>
        </div>

        <div
          className="mx-auto mt-10 rounded-[24px] p-6 md:p-10"
          style={{ background: WHITE, border: `1.5px solid ${DARK}`, boxShadow: `6px 6px 0 0 ${CORAL}` }}
        >
          {!done && (
            <>
              {/* Progress */}
              <div className="mb-6 flex items-center gap-2">
                {QUIZ.map((_, i) => (
                  <div key={i} className="h-2 flex-1 rounded-full" style={{ background: i <= step ? CORAL : "rgba(15,15,15,0.08)" }} />
                ))}
              </div>
              <div className="font-mono text-[10px] font-bold uppercase tracking-[0.22em]" style={{ color: MUTED }}>
                Question {step + 1} of {QUIZ.length}
              </div>
              <div className="mt-3 font-display text-[22px] font-extrabold leading-[1.2] tracking-[-0.02em] md:text-[28px]" style={{ color: DARK }}>
                {QUIZ[step].q}
              </div>
              <div className="mt-6 grid gap-3">
                {QUIZ[step].opts.map((o, i) => (
                  <button
                    key={i}
                    onClick={() => pick(o.a)}
                    className="group flex items-center justify-between gap-3 rounded-[14px] px-4 py-4 text-left transition hover:-translate-y-0.5"
                    style={{ background: CREAM, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${DARK}` }}
                  >
                    <span className="text-[14px] font-semibold md:text-[15px]" style={{ color: DARK }}>{o.label}</span>
                    <ChevronRight className="h-4 w-4 shrink-0 transition-transform group-hover:translate-x-1" style={{ color: CORAL }} />
                  </button>
                ))}
              </div>
            </>
          )}

          {done && winner && (
            <div className="text-center">
              <div className="text-6xl">{ARCHETYPES[winner].emoji}</div>
              <div className="mt-3 font-mono text-[10px] font-bold uppercase tracking-[0.22em]" style={{ color: MUTED }}>You are</div>
              <div className="mt-2 font-display font-black leading-[1.05] tracking-[-0.02em]" style={{ fontSize: "clamp(30px,5vw,52px)", color: ARCHETYPES[winner].color }}>
                {ARCHETYPES[winner].title}
              </div>
              <div className="mt-3 font-display text-[16px] font-extrabold italic" style={{ color: DARK }}>
                "{ARCHETYPES[winner].tagline}"
              </div>
              <p className="mx-auto mt-4 max-w-[520px] text-[14px] leading-[1.7] md:text-[15px]" style={{ color: MUTED }}>
                {ARCHETYPES[winner].body}
              </p>
              <button
                onClick={reset}
                className="mt-6 inline-flex items-center gap-2 rounded-full px-4 py-2 text-[12px] font-extrabold uppercase tracking-[0.12em]"
                style={{ background: WHITE, color: DARK, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${DARK}` }}
              >
                <RefreshCw className="h-3 w-3" /> Retake
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

/* ========================================================================
   #14 Live Activity Feed (floating sidebar / toast stack)
   ======================================================================== */
type ActivityKind = "claim" | "post" | "boost" | "join";
const ACT_NAMES = ["Priya S.", "Arjun M.", "Riya K.", "Karthik I.", "Ananya B.", "Rohan G.", "Meera V.", "Ishaan D.", "Kavya R.", "Aditya P.", "Sneha L.", "Vikram S."];
const ACT_CITIES = ["Bengaluru", "Mumbai", "Delhi", "Pune", "Kochi", "Hyderabad", "Chennai", "Ahmedabad", "Jaipur", "Indore"];
const ACT_TEMPLATES: Array<{ kind: ActivityKind; icon: any; verb: string; color: string }> = [
  { kind: "claim", icon: Crown, verb: "claimed OG", color: CORAL },
  { kind: "post", icon: Sparkles, verb: "shipped a project", color: DARK },
  { kind: "boost", icon: Rocket, verb: "boosted a builder", color: CORAL },
  { kind: "join", icon: Users, verb: "joined the wall", color: DARK },
];

function randomActivity(id: number) {
  const name = ACT_NAMES[Math.floor(Math.random() * ACT_NAMES.length)];
  const city = ACT_CITIES[Math.floor(Math.random() * ACT_CITIES.length)];
  const t = ACT_TEMPLATES[Math.floor(Math.random() * ACT_TEMPLATES.length)];
  const ogNum = Math.floor(Math.random() * 100) + 1;
  return { id, name, city, ...t, ogNum };
}

export function LiveActivitySidebar() {
  const [items, setItems] = useState<ReturnType<typeof randomActivity>[]>([]);
  const [dismissed, setDismissed] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const idRef = useRef(0);

  useEffect(() => {
    if (dismissed) return;
    // Seed
    const seed = [randomActivity(idRef.current++), randomActivity(idRef.current++)];
    setItems(seed);
    const t = window.setInterval(() => {
      setItems((prev) => {
        const next = [randomActivity(idRef.current++), ...prev].slice(0, 3);
        return next;
      });
    }, 5200);
    return () => window.clearInterval(t);
  }, [dismissed]);

  if (dismissed) return null;

  return (
    <div className="pointer-events-none fixed bottom-24 right-4 z-[240] md:bottom-6 md:right-6">
      <div className="pointer-events-auto">
        {/* Header pill */}
        <div className="mb-2 flex items-center gap-2">
          <button
            onClick={() => setCollapsed((c) => !c)}
            className="inline-flex items-center gap-2 rounded-full px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-[0.18em] transition hover:-translate-y-0.5"
            style={{ background: DARK, color: WHITE, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${CORAL}` }}
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-75" style={{ background: CORAL }} />
              <span className="relative inline-flex h-2 w-2 rounded-full" style={{ background: CORAL }} />
            </span>
            <Activity className="h-3 w-3" style={{ color: CORAL }} />
            Live · {collapsed ? "show" : "hide"}
          </button>
          <button
            onClick={() => setDismissed(true)}
            aria-label="Dismiss live feed"
            className="grid h-6 w-6 place-items-center rounded-full"
            style={{ background: WHITE, color: DARK, border: `1.5px solid ${DARK}` }}
          >
            <X className="h-3 w-3" />
          </button>
        </div>

        {!collapsed && (
          <div className="flex w-[260px] flex-col gap-2 md:w-[300px]">
            {items.map((it, i) => (
              <div
                key={it.id}
                className="flex items-center gap-3 rounded-[14px] p-3 animate-fade-in"
                style={{
                  background: WHITE,
                  border: `1.5px solid ${DARK}`,
                  boxShadow: `3px 3px 0 0 ${i === 0 ? CORAL : DARK}`,
                  opacity: 1 - i * 0.15,
                }}
              >
                <img src={avatarUrl(it.name)} alt="" className="h-9 w-9 shrink-0 rounded-full" style={{ background: CREAM, border: `1.5px solid ${DARK}` }} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[12px] font-semibold" style={{ color: DARK }}>
                    <span className="font-extrabold">{it.name}</span>{" "}
                    <span style={{ color: MUTED }}>{it.verb}</span>
                  </div>
                  <div className="mt-0.5 flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-[0.12em]" style={{ color: MUTED }}>
                    <Circle className="h-1.5 w-1.5 fill-current" />
                    <span>{it.city}</span>
                    {it.kind === "claim" && (
                      <span className="ml-1 rounded-full px-1.5 py-0.5" style={{ background: DARK, color: CORAL }}>
                        #{String(it.ogNum).padStart(3, "0")}
                      </span>
                    )}
                  </div>
                </div>
                <it.icon className="h-3.5 w-3.5 shrink-0" style={{ color: it.color }} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
