import { useEffect, useMemo, useRef, useState } from "react";
import { Flame, ArrowRight, Sparkles, X, Share2, Zap, Users } from "lucide-react";
import { Highlighter } from "@/registry/magicui/highlighter";

/* Brand tokens (mirror early-access C) */
const CORAL = "#E8623A";
const DARK = "#0F0F0F";
const CREAM = "#FAF6F1";
const WHITE = "#FFFFFF";
const MUTED = "#7a7a7a";

const avatarUrl = (seed: string) =>
  `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed || "og")}`;

/* ========================================================================
   1. Sticky Claim Bar — appears after hero scroll
   ======================================================================== */
export function StickyClaimBar({
  remaining,
  nextNumber,
  onClaim,
}: {
  remaining: number;
  nextNumber: number;
  onClaim: () => void;
}) {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem("vc_sticky_dismissed") === "1") setDismissed(true);
    const onScroll = () => setVisible(window.scrollY > 900);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  if (dismissed || !visible) return null;

  return (
    <div
      className="fixed inset-x-0 bottom-0 z-[190] px-3 pb-3 md:px-6 md:pb-5"
      style={{ animation: "ea-slide-up 360ms cubic-bezier(0.22,1,0.36,1)" }}
    >
      <style>{`@keyframes ea-slide-up { from { transform: translateY(120%);} to { transform: translateY(0);} }`}</style>
      <div
        className="mx-auto flex max-w-[720px] items-center gap-3 rounded-full pr-2"
        style={{
          background: DARK,
          border: `1.5px solid ${DARK}`,
          boxShadow: `4px 4px 0 0 ${CORAL}`,
          paddingLeft: 14,
          paddingTop: 8,
          paddingBottom: 8,
        }}
      >
        <span
          className="relative flex h-2.5 w-2.5 shrink-0"
          aria-hidden
        >
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full" style={{ background: CORAL, opacity: 0.6 }} />
          <span className="relative inline-flex h-2.5 w-2.5 rounded-full" style={{ background: CORAL }} />
        </span>
        <div className="min-w-0 flex-1 text-white">
          <div className="truncate text-[13px] font-extrabold leading-tight md:text-[14px]">
            Only <span style={{ color: CORAL }} className="tabular-nums">{remaining}</span> OG spots left
          </div>
          <div className="hidden text-[11px] font-medium text-white/60 md:block">Next up: Builder #{String(nextNumber).padStart(3, "0")}</div>
        </div>
        <button
          onClick={onClaim}
          className="hidden items-center gap-1.5 rounded-full px-4 py-2 text-[13px] font-extrabold sm:inline-flex"
          style={{ background: CORAL, color: WHITE, border: `1.5px solid ${DARK}` }}
        >
          <Flame className="h-3.5 w-3.5" /> Claim <ArrowRight className="h-3.5 w-3.5" />
        </button>
        <button
          onClick={onClaim}
          className="inline-flex items-center gap-1 rounded-full px-3 py-2 text-[12px] font-extrabold sm:hidden"
          style={{ background: CORAL, color: WHITE, border: `1.5px solid ${DARK}` }}
          aria-label="Claim your spot"
        >
          Claim <ArrowRight className="h-3 w-3" />
        </button>
        <button
          onClick={() => {
            setDismissed(true);
            try { sessionStorage.setItem("vc_sticky_dismissed", "1"); } catch {}
          }}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-white/60 transition hover:bg-white/10 hover:text-white"
          aria-label="Dismiss"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}

/* ========================================================================
   2. OG Number Simulator — type name, see live card
   ======================================================================== */
export function OGNumberSimulator({
  nextNumber,
  onClaim,
}: {
  nextNumber: number;
  onClaim: () => void;
}) {
  const [name, setName] = useState("");
  const display = name.trim() || "Your Name";
  const padded = String(nextNumber).padStart(3, "0");

  return (
    <section className="relative w-full overflow-hidden py-16 md:py-24" style={{ background: WHITE }}>
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          backgroundImage:
            "radial-gradient(circle at 15% 20%, rgba(232,98,58,0.08) 0, transparent 40%), radial-gradient(circle at 85% 80%, rgba(15,15,15,0.05) 0, transparent 40%)",
        }}
      />
      <div className="relative mx-auto grid w-full max-w-[1100px] grid-cols-1 items-center gap-10 px-4 md:grid-cols-2 md:gap-14 md:px-8">
        <div>
          <div
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]"
            style={{ background: "#FFF1EA", borderColor: CORAL, color: CORAL }}
          >
            <Sparkles className="h-3 w-3" /> Try it — no signup
          </div>
          <h2 className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ fontSize: "clamp(28px,5vw,52px)", color: DARK }}>
            See your <Highlighter action="underline" color={CORAL} strokeWidth={2.5} padding={1} animationDuration={900}>OG card</Highlighter> before you claim.
          </h2>
          <p className="mt-4 text-[15px] leading-[1.7] md:text-[16px]" style={{ color: MUTED }}>
            Type your name below. Watch your permanent founder card render in real-time — same one that goes up on the wall on Aug 4.
          </p>
          <div className="mt-6">
            <label className="mb-2 block text-[11px] font-bold uppercase tracking-[0.16em]" style={{ color: DARK }}>
              Your full name
            </label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value.slice(0, 32))}
              placeholder="e.g. Priya Sharma"
              className="w-full rounded-[12px] px-4 py-3.5 text-[15px] font-semibold outline-none transition focus:-translate-y-0.5"
              style={{
                background: CREAM,
                border: `1.5px solid ${DARK}`,
                boxShadow: `3px 3px 0 0 ${DARK}`,
                color: DARK,
              }}
            />
            <button
              onClick={onClaim}
              className="mt-4 inline-flex items-center gap-2 rounded-full px-6 py-3 text-[14px] font-extrabold transition hover:-translate-y-0.5"
              style={{ background: CORAL, color: WHITE, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${DARK}` }}
            >
              <Flame className="h-4 w-4" /> Claim #{padded} for real <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Live preview card */}
        <div className="flex items-center justify-center">
          <div
            className="relative w-full max-w-[360px] rounded-[22px] p-6"
            style={{
              background: DARK,
              border: `1.5px solid ${DARK}`,
              boxShadow: `10px 10px 0 0 ${CORAL}`,
              transform: "rotate(-1.5deg)",
              transition: "transform 300ms cubic-bezier(0.22,1,0.36,1)",
            }}
          >
            <div className="flex items-center justify-between text-white/60">
              <span className="font-mono text-[10px] font-bold uppercase tracking-[0.24em]">OG Founder</span>
              <span
                className="rounded-full px-2 py-0.5 font-mono text-[9px] font-bold uppercase tracking-[0.2em]"
                style={{ background: "rgba(232,98,58,0.15)", color: CORAL, border: `1px solid ${CORAL}` }}
              >
                Live preview
              </span>
            </div>
            <div className="mt-6 flex items-end justify-between">
              <img
                src={avatarUrl(display)}
                alt=""
                className="h-16 w-16 rounded-full"
                style={{ background: CREAM, border: `2px solid ${CORAL}` }}
              />
              <div
                className="font-display font-black leading-none tabular-nums"
                style={{ fontSize: 68, color: CORAL, letterSpacing: "-0.04em", textShadow: `2px 2px 0 rgba(255,255,255,0.06)` }}
              >
                #{padded}
              </div>
            </div>
            <div className="mt-6 text-white">
              <div className="truncate font-display text-[22px] font-extrabold leading-tight">{display}</div>
              <div className="mt-1 text-[12px] font-semibold text-white/50">Builder · Vibecode.xyz</div>
            </div>
            <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-4">
              <span className="font-mono text-[10px] font-bold uppercase tracking-[0.22em] text-white/40">Aug 04 · 2026</span>
              <span className="font-mono text-[10px] font-bold uppercase tracking-[0.22em]" style={{ color: CORAL }}>Locked ✓</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========================================================================
   3. Availability Heatmap — 100 tiles, taken vs open
   ======================================================================== */
export function AvailabilityHeatmap({
  taken,
  total,
  nextNumber,
}: {
  taken: number;
  total: number;
  nextNumber: number;
}) {
  const tiles = useMemo(() => Array.from({ length: total }, (_, i) => i + 1), [total]);
  return (
    <section className="relative w-full overflow-hidden py-16 md:py-24" style={{ background: CREAM }}>
      <div className="relative mx-auto w-full max-w-[1000px] px-4 md:px-8">
        <div className="text-center">
          <div
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]"
            style={{ background: WHITE, borderColor: DARK, color: DARK }}
          >
            <Zap className="h-3 w-3" style={{ color: CORAL }} /> Live availability
          </div>
          <h2 className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ fontSize: "clamp(26px,5vw,52px)", color: DARK }}>
            100 spots. <Highlighter action="highlight" color="rgba(232,98,58,0.32)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>{Math.max(0, total - taken)} left.</Highlighter>
          </h2>
          <p className="mx-auto mt-4 max-w-[520px] text-[14px] leading-[1.7] md:text-[15px]" style={{ color: MUTED }}>
            Each square is one permanent founder seat. Coral = taken. Open = yours to grab. The next open square glows.
          </p>
        </div>

        <div
          className="mx-auto mt-10 grid gap-1.5 rounded-[16px] p-4 md:p-6"
          style={{
            gridTemplateColumns: "repeat(10, minmax(0,1fr))",
            background: WHITE,
            border: `1.5px solid ${DARK}`,
            boxShadow: `4px 4px 0 0 ${DARK}`,
            maxWidth: 620,
          }}
        >
          {tiles.map((n) => {
            const isTaken = n <= taken;
            const isNext = n === nextNumber;
            return (
              <div
                key={n}
                title={isTaken ? `#${String(n).padStart(3, "0")} — taken` : isNext ? `#${String(n).padStart(3, "0")} — next` : `#${String(n).padStart(3, "0")} — open`}
                className="relative aspect-square rounded-[4px] transition-transform hover:scale-125"
                style={{
                  background: isTaken ? CORAL : isNext ? "#FFF1EA" : "#F0EAE0",
                  border: isNext ? `1.5px solid ${CORAL}` : `1px solid ${isTaken ? DARK : "rgba(15,15,15,0.12)"}`,
                  boxShadow: isNext ? `0 0 12px rgba(232,98,58,0.6)` : "none",
                  animation: isNext ? "ea-tile-pulse 1.8s ease-in-out infinite" : undefined,
                }}
              />
            );
          })}
        </div>
        <style>{`@keyframes ea-tile-pulse { 0%,100% { transform: scale(1); box-shadow: 0 0 8px rgba(232,98,58,0.5);} 50% { transform: scale(1.15); box-shadow: 0 0 18px rgba(232,98,58,0.9);} }`}</style>

        {/* Legend */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-5 text-[12px] font-semibold" style={{ color: DARK }}>
          <div className="flex items-center gap-2"><span className="h-3 w-3 rounded-[3px]" style={{ background: CORAL, border: `1px solid ${DARK}` }} /> Taken ({taken})</div>
          <div className="flex items-center gap-2"><span className="h-3 w-3 rounded-[3px]" style={{ background: "#FFF1EA", border: `1.5px solid ${CORAL}` }} /> Next: #{String(nextNumber).padStart(3, "0")}</div>
          <div className="flex items-center gap-2"><span className="h-3 w-3 rounded-[3px]" style={{ background: "#F0EAE0", border: `1px solid rgba(15,15,15,0.2)` }} /> Open</div>
        </div>
      </div>
    </section>
  );
}

/* ========================================================================
   4. Kinetic Manifesto — scroll-revealed statement
   ======================================================================== */
const MANIFESTO_STANZAS: Array<Array<{ text: string; accent?: boolean }>> = [
  [
    { text: "We believe " },
    { text: "the next unicorn", accent: true },
    { text: " won't come from an IIT lab." },
  ],
  [
    { text: "It'll come from a 19-year-old in " },
    { text: "Indore", accent: true },
    { text: ", prompting on a borrowed laptop." },
  ],
  [
    { text: "This is for ", },
    { text: "them.", accent: true },
  ],
];

export function KineticManifesto() {
  const [visibleIdx, setVisibleIdx] = useState(-1);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const el = ref.current;
    const onScroll = () => {
      const rect = el.getBoundingClientRect();
      const viewport = window.innerHeight;
      const progress = 1 - Math.max(0, Math.min(1, (rect.top + rect.height * 0.2) / viewport));
      const idx = Math.floor(progress * MANIFESTO_STANZAS.length);
      setVisibleIdx(idx);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <section ref={ref} className="relative w-full overflow-hidden py-20 md:py-32" style={{ background: DARK }}>
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{ background: "radial-gradient(800px circle at 50% 50%, rgba(232,98,58,0.14), transparent 65%)" }}
      />
      <div className="relative mx-auto w-full max-w-[900px] px-5 md:px-8">
        <div className="mb-10 flex justify-center md:mb-14">
          <div
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]"
            style={{ background: "rgba(255,255,255,0.06)", borderColor: "rgba(232,98,58,0.5)", color: CORAL }}
          >
            <Sparkles className="h-3 w-3" /> The manifesto
          </div>
        </div>

        <div className="space-y-8 text-center md:space-y-10">
          {MANIFESTO_STANZAS.map((stanza, i) => (
            <p
              key={i}
              className="font-display font-black leading-[1.15] tracking-[-0.02em] transition-all duration-700"
              style={{
                fontSize: "clamp(24px, 4.6vw, 52px)",
                color: i <= visibleIdx ? WHITE : "rgba(255,255,255,0.28)",
                opacity: i <= visibleIdx ? 1 : 0.5,
                transform: i <= visibleIdx ? "translateY(0)" : "translateY(14px)",
              }}
            >
              {stanza.map((seg, j) => (
                <span key={j} style={{ color: seg.accent ? CORAL : "inherit" }}>
                  {seg.text}
                </span>
              ))}
            </p>
          ))}
        </div>

        <div className="mt-14 text-center md:mt-20">
          <div className="mx-auto h-[2px] w-24" style={{ background: `linear-gradient(90deg, transparent, ${CORAL}, transparent)` }} />
          <div className="mt-4 font-mono text-[11px] font-bold uppercase tracking-[0.28em] text-white/40">
            — the vibecode team, bengaluru
          </div>
        </div>
      </div>
    </section>
  );
}


/* ========================================================================
   5. Live Joins Strip — pulse of newest wall members
   ======================================================================== */
export function LiveJoinsStrip({
  members,
}: {
  members: Array<{ og_number: number; full_name: string; city: string | null }>;
}) {
  const latest = useMemo(
    () => [...members].sort((a, b) => b.og_number - a.og_number).slice(0, 8),
    [members]
  );

  if (latest.length === 0) return null;

  return (
    <div
      className="mx-auto mb-8 flex max-w-[880px] items-center gap-3 overflow-hidden rounded-full px-3 py-2"
      style={{ background: WHITE, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${DARK}` }}
    >
      <span
        className="inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[9px] font-bold uppercase tracking-[0.2em]"
        style={{ background: CORAL, color: WHITE }}
      >
        <span className="relative flex h-1.5 w-1.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-70" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-white" />
        </span>
        Just now
      </span>
      <div className="flex-1 overflow-hidden">
        <div className="flex items-center gap-3" style={{ animation: "ea-joins-marquee 24s linear infinite" }}>
          {[...latest, ...latest].map((m, i) => (
            <div key={`${m.og_number}-${i}`} className="flex shrink-0 items-center gap-2">
              <img src={avatarUrl(m.full_name)} alt="" className="h-6 w-6 rounded-full" style={{ background: CREAM, border: `1.5px solid ${DARK}` }} />
              <span className="text-[12px] font-bold" style={{ color: DARK }}>
                {m.full_name.split(" ")[0]} <span className="tabular-nums" style={{ color: CORAL }}>#{String(m.og_number).padStart(3, "0")}</span>
                {m.city ? <span className="ml-1 font-medium" style={{ color: MUTED }}>· {m.city}</span> : null}
              </span>
              <span className="mx-1 text-[10px]" style={{ color: MUTED }}>•</span>
            </div>
          ))}
        </div>
      </div>
      <style>{`@keyframes ea-joins-marquee { from { transform: translateX(0);} to { transform: translateX(-50%);} }`}</style>
    </div>
  );
}

/* ========================================================================
   6. Celebration Overlay — post-claim takeover
   ======================================================================== */
export function CelebrationOverlay({
  open,
  ogNumber,
  name,
  onClose,
}: {
  open: boolean;
  ogNumber: number | null;
  name: string;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [open]);

  if (!open || !ogNumber) return null;

  const padded = String(ogNumber).padStart(3, "0");
  const shareText = `I just claimed OG Founder #${padded} on VibeCode 🔥 India's largest AI builder community. Launching Aug 4, 2026. Only 100 seats — grab yours: https://joinvibecode.xyz/early-access`;
  const shareTwitter = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`;
  const shareLinkedIn = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent("https://joinvibecode.xyz/early-access")}`;
  const shareWhatsApp = `https://wa.me/?text=${encodeURIComponent(shareText)}`;

  const confetti = Array.from({ length: 60 }, (_, i) => i);
  const colors = [CORAL, "#F4B740", "#5CBDB9", WHITE, "#E23744"];

  return (
    <div
      className="fixed inset-0 z-[300] grid place-items-center px-4"
      style={{
        background: "rgba(15,15,15,0.85)",
        backdropFilter: "blur(12px)",
        animation: "ea-fade-in 300ms ease-out",
      }}
      role="dialog"
      aria-modal="true"
    >
      <style>{`
        @keyframes ea-fade-in { from { opacity: 0;} to { opacity: 1;} }
        @keyframes ea-pop-in { 0% { opacity: 0; transform: scale(0.7) rotate(-6deg);} 60% { transform: scale(1.05) rotate(2deg);} 100% { opacity: 1; transform: scale(1) rotate(0);} }
        @keyframes ea-confetti-drop { to { transform: translate(var(--tx), 110vh) rotate(720deg); opacity: 0;} }
      `}</style>

      {/* Confetti */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {confetti.map((i) => {
          const left = Math.random() * 100;
          const tx = (Math.random() - 0.5) * 200;
          const delay = Math.random() * 800;
          const size = 6 + Math.random() * 8;
          return (
            <span
              key={i}
              className="absolute"
              style={{
                left: `${left}%`,
                top: "-20px",
                width: size,
                height: size * 1.4,
                background: colors[i % colors.length],
                ["--tx" as any]: `${tx}px`,
                animation: `ea-confetti-drop ${2600 + Math.random() * 1400}ms cubic-bezier(0.2,0.7,0.4,1) ${delay}ms forwards`,
                borderRadius: 2,
              }}
            />
          );
        })}
      </div>

      <div
        className="relative w-full max-w-[520px] rounded-[24px] p-8 md:p-10"
        style={{
          background: WHITE,
          border: `1.5px solid ${DARK}`,
          boxShadow: `10px 10px 0 0 ${CORAL}`,
          animation: "ea-pop-in 600ms cubic-bezier(0.22,1,0.36,1)",
        }}
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full"
          style={{ background: CREAM, border: `1.5px solid ${DARK}` }}
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="text-center">
          <div
            className="inline-flex items-center gap-2 rounded-full px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]"
            style={{ background: "#FFF1EA", color: CORAL, border: `1.5px solid ${CORAL}` }}
          >
            <Sparkles className="h-3 w-3" /> Locked. Forever.
          </div>
          <div
            className="mt-6 font-display font-black leading-none tabular-nums"
            style={{ fontSize: "clamp(72px,14vw,140px)", color: CORAL, letterSpacing: "-0.05em" }}
          >
            #{padded}
          </div>
          <h2 className="mt-2 font-display text-[22px] font-extrabold md:text-[26px]" style={{ color: DARK }}>
            Welcome, <Highlighter action="underline" color={CORAL} strokeWidth={2.5} padding={1} animationDuration={900}>{name.split(" ")[0] || "Builder"}</Highlighter>.
          </h2>
          <p className="mx-auto mt-3 max-w-[380px] text-[14px] leading-[1.7]" style={{ color: MUTED }}>
            You're now permanent OG Founder <b style={{ color: DARK }}>#{padded}</b>. Your card goes live on the wall Aug 4, 2026. Tell one friend — that's how movements start.
          </p>

          <div className="mt-6 flex flex-col items-center gap-2">
            <div className="text-[11px] font-bold uppercase tracking-[0.18em]" style={{ color: MUTED }}>Share the flex</div>
            <div className="flex flex-wrap items-center justify-center gap-2">
              <a
                href={shareTwitter}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-[13px] font-extrabold transition hover:-translate-y-0.5"
                style={{ background: DARK, color: WHITE, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${CORAL}` }}
              >
                <Share2 className="h-3.5 w-3.5" /> Twitter / X
              </a>
              <a
                href={shareLinkedIn}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-[13px] font-extrabold transition hover:-translate-y-0.5"
                style={{ background: "#0077B5", color: WHITE, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${DARK}` }}
              >
                LinkedIn
              </a>
              <a
                href={shareWhatsApp}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-[13px] font-extrabold transition hover:-translate-y-0.5"
                style={{ background: "#25D366", color: WHITE, border: `1.5px solid ${DARK}`, boxShadow: `3px 3px 0 0 ${DARK}` }}
              >
                WhatsApp
              </a>
            </div>
          </div>

          <div className="mt-6 flex items-center justify-center gap-2 text-[12px] font-semibold" style={{ color: MUTED }}>
            <Users className="h-3.5 w-3.5" /> You're the {padded}<sup>{ordinalSuffix(ogNumber)}</sup> founder in history.
          </div>
        </div>
      </div>
    </div>
  );
}

function ordinalSuffix(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return s[(v - 20) % 10] || s[v] || s[0];
}
