"use client";

import { motion, useInView, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useEffect, useRef, ReactNode } from "react";
import { cn } from "@/lib/utils";

/* Animated numeric counter that runs when scrolled into view */
export function AnimatedCounter({
  value,
  className,
  duration = 1.4,
}: {
  value: number;
  className?: string;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: false, margin: "-20% 0px" });
  const mv = useMotionValue(0);
  const spring = useSpring(mv, { stiffness: 60, damping: 20, mass: 1 });
  const rounded = useTransform(spring, (v) => Math.round(v).toString());

  useEffect(() => {
    if (inView) {
      mv.set(0);
      const t = setTimeout(() => mv.set(value), 40);
      return () => clearTimeout(t);
    }
  }, [inView, value, mv, duration]);

  useEffect(() => {
    return rounded.on("change", (v) => {
      if (ref.current) ref.current.textContent = v;
    });
  }, [rounded]);

  return <span ref={ref} className={className}>0</span>;
}

/* Scroll-reveal wrapper — fade + rise */
export function Reveal({
  children,
  delay = 0,
  y = 24,
  className,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10% 0px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* Highlight-reveal text: word-by-word ink sweep from muted → foreground.
   Perfect for editorial "as you scroll, the phrase lights up" moments. */
export function HighlightText({
  text,
  className,
  from = "rgba(15,15,15,0.22)",
  to = "#0F0F0F",
  accent,
  accentColor = "#E8623A",
}: {
  text: string;
  className?: string;
  from?: string;
  to?: string;
  accent?: string[]; // words to render in accent color
  accentColor?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-20% 0px" });
  const words = text.split(" ");
  return (
    <span ref={ref} className={cn("inline", className)}>
      {words.map((w, i) => {
        const isAccent = accent?.includes(w.replace(/[.,!?]/g, ""));
        return (
          <motion.span
            key={`${w}-${i}`}
            initial={{ color: from }}
            animate={inView ? { color: isAccent ? accentColor : to } : {}}
            transition={{ duration: 0.5, delay: i * 0.06, ease: "easeOut" }}
            className="inline"
          >
            {w}
            {i < words.length - 1 ? " " : ""}
          </motion.span>
        );
      })}
    </span>
  );
}

/* Motion wrapper for bento cards with a tilt / rise on view + magnetic hover */
export function BentoMotion({
  children,
  index = 0,
  className,
}: {
  children: ReactNode;
  index?: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.96 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-8% 0px" }}
      transition={{
        duration: 0.6,
        delay: (index % 6) * 0.08,
        ease: [0.22, 1, 0.36, 1],
      }}
      whileHover={{ y: -6, transition: { duration: 0.25, ease: "easeOut" } }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
