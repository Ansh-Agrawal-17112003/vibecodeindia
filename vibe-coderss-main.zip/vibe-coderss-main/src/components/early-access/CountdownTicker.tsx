"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { GlareHover } from "@/registry/magicui/glare-hover";

/* Countdown ticker to a fixed target date. Renders D / H / M / S cards. */
export function CountdownTicker({
  target,
  variant = "light",
  compact = false,
}: {
  target: Date | string;
  variant?: "light" | "dark";
  compact?: boolean;
}) {
  const targetTs = typeof target === "string" ? new Date(target).getTime() : target.getTime();
  const [mounted, setMounted] = useState(false);
  const [now, setNow] = useState(targetTs);

  useEffect(() => {
    setMounted(true);
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);


  const diff = Math.max(0, targetTs - now);
  const days = Math.floor(diff / 86_400_000);
  const hours = Math.floor((diff % 86_400_000) / 3_600_000);
  const mins = Math.floor((diff % 3_600_000) / 60_000);
  const secs = Math.floor((diff % 60_000) / 1_000);

  const units: Array<{ v: number; l: string; pad: number }> = [
    { v: days, l: "Days", pad: 2 },
    { v: hours, l: "Hrs", pad: 2 },
    { v: mins, l: "Min", pad: 2 },
    { v: secs, l: "Sec", pad: 2 },
  ];

  const isDark = variant === "dark";
  const cardBg = isDark ? "#161616" : "#FFFFFF";
  const cardBorder = isDark ? "#2a2a2a" : "#0F0F0F";
  const shadow = isDark ? "3px 3px 0 0 #E8623A" : "3px 3px 0 0 #0F0F0F";
  const numColor = isDark ? "#FFFFFF" : "#0F0F0F";
  const labelColor = isDark ? "rgba(255,255,255,0.55)" : "#7a7a7a";
  const sepColor = isDark ? "#E8623A" : "#E8623A";
  const size = compact ? "clamp(20px, 5vw, 34px)" : "clamp(24px, 6vw, 52px)";
  const cardPad = compact ? "px-2 py-1.5 md:px-3 md:py-2" : "px-2.5 py-2 md:px-5 md:py-4";
  const minW = compact ? 48 : 56;

  return (
    <div className="inline-flex items-center gap-1.5 md:gap-2.5">
      {units.map((u, i) => (
        <div key={u.l} className="flex items-center gap-1.5 md:gap-2.5">
          <GlareHover
            className={`rounded-[12px] border-[1.5px] ${cardPad}`}
            duration={900}
            glareColor={isDark ? "rgba(232,98,58,0.35)" : "rgba(255,255,255,0.7)"}
            style={{
              background: cardBg,
              borderColor: cardBorder,
              boxShadow: shadow,
              minWidth: minW,
            }}
          >
            <div
              className="text-center font-display font-extrabold leading-none tabular-nums"
              style={{ color: numColor, fontSize: size, fontFeatureSettings: "'tnum'" }}
            >
              <AnimatePresence mode="popLayout" initial={false}>
                <motion.span
                  key={u.v}
                  initial={{ y: "-100%", opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: "100%", opacity: 0 }}
                  transition={{ type: "spring", stiffness: 260, damping: 22 }}
                  className="inline-block"
                >
                  {String(u.v).padStart(u.pad, "0")}
                </motion.span>
              </AnimatePresence>
            </div>
            <div
              className="mt-1.5 text-center text-[9px] font-bold uppercase tracking-[0.18em] md:text-[10px]"
              style={{ color: labelColor }}
            >
              {u.l}
            </div>
          </GlareHover>
          {i < units.length - 1 && (
            <span
              className="font-display text-[22px] font-extrabold md:text-[28px]"
              style={{ color: sepColor }}
            >
              :
            </span>
          )}
        </div>
      ))}
    </div>
  );
}
