import { useEffect, useRef, useState } from "react";
import { Loader2, Upload, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

type AiContent = {
  headline?: string;
  about_long?: string;
  what_i_do?: string[];
  expertise?: string[];
  approach?: string[];
  why_work_with_me?: string[];
  achievements?: string[];
  values?: string[];
  faq?: { q: string; a: string }[];
};

type ProfileRow = {
  id: string;
  username: string | null;
  display_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  banner_url: string | null;
  website_url: string | null;
  x_url: string | null;
  github_url: string | null;
  linkedin_url: string | null;
  accent_color: string | null;
  ai_content: AiContent | null;
};

const EMPTY: ProfileRow = {
  id: "",
  username: "",
  display_name: "",
  bio: "",
  avatar_url: "",
  banner_url: "",
  website_url: "",
  x_url: "",
  github_url: "",
  linkedin_url: "",
  accent_color: "#FF6B4A",
  ai_content: null,
};

const linesToArr = (s: string) => s.split("\n").map((l) => l.trim()).filter(Boolean);
const arrToLines = (a?: string[]) => (a ?? []).join("\n");
const faqToText = (f?: { q: string; a: string }[]) =>
  (f ?? []).map((x) => `Q: ${x.q}\nA: ${x.a}`).join("\n\n");
const textToFaq = (s: string): { q: string; a: string }[] => {
  const out: { q: string; a: string }[] = [];
  const blocks = s.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);
  for (const b of blocks) {
    const qm = b.match(/^Q:\s*(.+?)(?:\n|$)/i);
    const am = b.match(/A:\s*([\s\S]+)$/i);
    if (qm && am) out.push({ q: qm[1].trim(), a: am[1].trim() });
  }
  return out;
};

export function ProfileEditor() {
  const { user, refreshProfile } = useAuth();
  const [row, setRow] = useState<ProfileRow>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    (async () => {
      setLoading(true);
      const { data, error } = await (supabase.from("profiles") as any)
        .select("id, username, display_name, bio, avatar_url, banner_url, website_url, x_url, github_url, linkedin_url, accent_color, ai_content")
        .eq("id", user.id)
        .maybeSingle();
      if (!error && data) {
        const r = { ...EMPTY, ...(data as ProfileRow) };
        // If profile has no AI content, seed from og_members (so OG users can edit their pre-generated content)
        if (!r.ai_content || Object.keys(r.ai_content).length === 0) {
          if (r.username) {
            const { data: og } = await (supabase as any).from("og_members").select("ai_content").eq("username", r.username).maybeSingle();
            if (og?.ai_content) r.ai_content = og.ai_content as AiContent;
          }
        }
        setRow(r);
      }
      setLoading(false);
    })();
  }, [user]);

  const upload = async (bucket: "avatars" | "banners", file: File): Promise<string | null> => {
    if (!user) return null;
    const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
    const path = `${user.id}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from(bucket).upload(path, file, {
      contentType: file.type || "image/jpeg",
      upsert: true,
    });
    if (error) { toast.error(error.message); return null; }
    const { data: signed } = await supabase.storage.from(bucket).createSignedUrl(path, 60 * 60 * 24 * 365);
    return signed?.signedUrl ?? null;
  };

  const updateAi = (patch: Partial<AiContent>) => setRow((r) => ({ ...r, ai_content: { ...(r.ai_content ?? {}), ...patch } }));

  const save = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const ai = row.ai_content ?? {};
      const cleanedAi: AiContent = {
        headline: ai.headline?.trim() || undefined,
        about_long: ai.about_long?.trim() || undefined,
        what_i_do: ai.what_i_do?.length ? ai.what_i_do : undefined,
        expertise: ai.expertise?.length ? ai.expertise : undefined,
        approach: ai.approach?.length ? ai.approach : undefined,
        why_work_with_me: ai.why_work_with_me?.length ? ai.why_work_with_me : undefined,
        achievements: ai.achievements?.length ? ai.achievements : undefined,
        values: ai.values?.length ? ai.values : undefined,
        faq: ai.faq?.length ? ai.faq : undefined,
      };
      const hasAny = Object.values(cleanedAi).some((v) => v !== undefined);
      const patch: any = {
        display_name: row.display_name?.trim() || null,
        bio: row.bio?.trim() || null,
        avatar_url: row.avatar_url || null,
        banner_url: row.banner_url || null,
        website_url: row.website_url?.trim() || null,
        x_url: row.x_url?.trim() || null,
        github_url: row.github_url?.trim() || null,
        linkedin_url: row.linkedin_url?.trim() || null,
        accent_color: row.accent_color || "#FF6B4A",
        ai_content: hasAny ? cleanedAi : null,
      };
      const { error } = await (supabase.from("profiles") as any).update(patch).eq("id", user.id);
      if (error) throw error;
      toast.success("Profile saved");
      await refreshProfile();
    } catch (e: any) {
      toast.error(e?.message || "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  if (!user) return <p className="text-sm text-muted-foreground">Sign in to edit your profile.</p>;
  if (loading) return <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>;

  return (
    <div className="space-y-5">
      {/* Banner + Avatar */}
      <div className="overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F] bg-white">
        <div
          className="relative h-32 w-full bg-cover bg-center"
          style={{ background: row.banner_url ? `url(${row.banner_url}) center/cover` : `linear-gradient(90deg, ${row.accent_color}22, ${row.accent_color})` }}
        >
          <ImageUpload label="Change banner" onFile={async (f) => { const url = await upload("banners", f); if (url) setRow({ ...row, banner_url: url }); }} />
        </div>
        <div className="flex items-center gap-4 p-4">
          <div className="relative -mt-10">
            <img
              src={row.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${user.email ?? user.id}`}
              alt=""
              className="h-20 w-20 rounded-full border-[1.5px] border-[#0F0F0F] bg-white object-cover"
            />
            <ImageUpload
              small
              label="Change"
              onFile={async (f) => { const url = await upload("avatars", f); if (url) setRow({ ...row, avatar_url: url }); }}
            />
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-bold">{row.display_name || row.username || user.email}</div>
            <div className="truncate text-xs text-muted-foreground">@{row.username || "no-username-yet"}</div>
          </div>
        </div>
      </div>

      <Field label="Display name">
        <input className="input" value={row.display_name ?? ""} onChange={(e) => setRow({ ...row, display_name: e.target.value })} maxLength={80} />
      </Field>
      <Field label="Bio">
        <textarea rows={3} className="input" value={row.bio ?? ""} onChange={(e) => setRow({ ...row, bio: e.target.value })} maxLength={400} />
      </Field>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Field label="Website"><input className="input" value={row.website_url ?? ""} onChange={(e) => setRow({ ...row, website_url: e.target.value })} placeholder="https://…" /></Field>
        <Field label="X / Twitter"><input className="input" value={row.x_url ?? ""} onChange={(e) => setRow({ ...row, x_url: e.target.value })} placeholder="https://x.com/…" /></Field>
        <Field label="GitHub"><input className="input" value={row.github_url ?? ""} onChange={(e) => setRow({ ...row, github_url: e.target.value })} placeholder="https://github.com/…" /></Field>
        <Field label="LinkedIn"><input className="input" value={row.linkedin_url ?? ""} onChange={(e) => setRow({ ...row, linkedin_url: e.target.value })} placeholder="https://linkedin.com/in/…" /></Field>
      </div>
      <Field label="Accent color">
        <div className="flex items-center gap-3">
          <input
            type="color"
            value={row.accent_color || "#FF6B4A"}
            onChange={(e) => setRow({ ...row, accent_color: e.target.value })}
            className="h-10 w-16 cursor-pointer rounded border-[1.5px] border-[#0F0F0F] bg-white"
          />
          <input className="input" value={row.accent_color ?? ""} onChange={(e) => setRow({ ...row, accent_color: e.target.value })} placeholder="#FF6B4A" />
          <div className="h-10 flex-1 rounded" style={{ background: row.accent_color || "#FF6B4A" }} />
        </div>
      </Field>

      {/* AI-generated profile sections — fully editable */}
      <div className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-gold/20 p-4">
        <div className="mb-3 flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-coral" />
          <h3 className="text-sm font-black uppercase tracking-wide">AI Profile Sections</h3>
        </div>
        <p className="mb-4 text-xs text-muted-foreground">
          These sections appear on your public profile at <code>/u/{row.username || "your-username"}</code>. Edit anything — one item per line for lists.
        </p>
        <div className="space-y-3">
          <Field label="Headline (one line)">
            <input className="input" value={row.ai_content?.headline ?? ""} onChange={(e) => updateAi({ headline: e.target.value })} maxLength={140} placeholder="e.g. Building AI automations for local business" />
          </Field>
          <Field label="About (long-form)">
            <textarea rows={5} className="input" value={row.ai_content?.about_long ?? ""} onChange={(e) => updateAi({ about_long: e.target.value })} placeholder="A few paragraphs about who you are, what you build, why you build it…" />
          </Field>
          <Field label="What I Do (one per line)">
            <textarea rows={4} className="input" value={arrToLines(row.ai_content?.what_i_do)} onChange={(e) => updateAi({ what_i_do: linesToArr(e.target.value) })} />
          </Field>
          <Field label="Areas of Expertise (one per line)">
            <textarea rows={4} className="input" value={arrToLines(row.ai_content?.expertise)} onChange={(e) => updateAi({ expertise: linesToArr(e.target.value) })} />
          </Field>
          <Field label="My Approach (one per line)">
            <textarea rows={4} className="input" value={arrToLines(row.ai_content?.approach)} onChange={(e) => updateAi({ approach: linesToArr(e.target.value) })} />
          </Field>
          <Field label="Why Work With Me (one per line)">
            <textarea rows={4} className="input" value={arrToLines(row.ai_content?.why_work_with_me)} onChange={(e) => updateAi({ why_work_with_me: linesToArr(e.target.value) })} />
          </Field>
          <Field label="Highlights & Achievements (one per line)">
            <textarea rows={4} className="input" value={arrToLines(row.ai_content?.achievements)} onChange={(e) => updateAi({ achievements: linesToArr(e.target.value) })} />
          </Field>
          <Field label="Values I Ship By (one per line)">
            <textarea rows={3} className="input" value={arrToLines(row.ai_content?.values)} onChange={(e) => updateAi({ values: linesToArr(e.target.value) })} />
          </Field>
          <Field label='FAQ (format: "Q: question" then "A: answer", blank line between entries)'>
            <textarea rows={6} className="input" value={faqToText(row.ai_content?.faq)} onChange={(e) => updateAi({ faq: textToFaq(e.target.value) })} placeholder={"Q: What can I hire you for?\nA: End-to-end AI product building.\n\nQ: Are you available for collabs?\nA: Yes — reach out after Aug 4 launch."} />
          </Field>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2 text-sm font-bold text-white shadow-[2px_2px_0_0_#0F0F0F] disabled:opacity-60"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />} Save profile
        </button>
      </div>

      <style>{`.input{width:100%;border:1.5px solid #0F0F0F33;border-radius:10px;padding:8px 12px;font-size:14px;background:#fff;outline:none}.input:focus{border-color:#E8623A}`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-bold uppercase tracking-wide text-[#0F0F0F]/70">{label}</span>
      {children}
    </label>
  );
}

function ImageUpload({ label, onFile, small }: { label: string; onFile: (f: File) => void | Promise<void>; small?: boolean }) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  return (
    <>
      <button
        type="button"
        onClick={() => ref.current?.click()}
        className={
          small
            ? "absolute -bottom-1 -right-1 grid h-7 w-7 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white text-[#0F0F0F] shadow"
            : "absolute bottom-2 right-2 inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-white/90 px-3 py-1 text-xs font-bold text-[#0F0F0F]"
        }
        aria-label={label}
      >
        {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Upload className="h-3 w-3" />}
        {!small && <span>{label}</span>}
      </button>
      <input
        ref={ref}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          setBusy(true);
          try { await onFile(f); } finally { setBusy(false); if (ref.current) ref.current.value = ""; }
        }}
      />
    </>
  );
}
