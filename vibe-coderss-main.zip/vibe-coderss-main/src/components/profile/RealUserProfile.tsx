import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import {
  Github, Linkedin, Globe, Twitter, MapPin, Flame, Loader2, Coins, UserPlus, UserCheck,
  MessageSquare, Share2, BadgeCheck, Star, Sparkles, Briefcase, Trophy, Zap, Rocket,
  Users, Award, Calendar, TrendingUp, Package, Layers, Activity, Heart, ExternalLink,
  IndianRupee, FileText, Workflow, LayoutTemplate, Copy, ArrowLeft, ArrowRight,
  Target, CheckCircle2, HelpCircle, Compass, ShieldCheck, Eye, ThumbsUp,
} from "lucide-react";
import { toast } from "sonner";
import { Shell } from "@/components/site/Shell";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { listUserPosts, listBookmarks, timeAgo, toggleFollow, type LivePost } from "@/lib/feed-api";
import { sharePage } from "@/lib/share";

type RealProfile = {
  id: string; username: string | null; display_name: string | null;
  avatar_url: string | null; banner_url: string | null; bio: string | null;
  location: string | null; website_url: string | null; x_url: string | null;
  github_url: string | null; linkedin_url: string | null; accent_color: string | null;
  roles: string[] | null; availability_status: string | null;
  follower_count: number | null; following_count: number | null;
  total_xp: number | null; current_level: string | null; vibecoin_balance: number | null;
  login_streak: number | null; longest_streak: number | null; streak_badges: string[] | null;
  onboarded_at: string | null; created_at: string;
  ai_content: AiContent | null;
};
type AiContent = {
  headline?: string; about_long?: string;
  what_i_do?: string[]; expertise?: string[]; services_offered?: string[];
  approach?: string[]; why_work_with_me?: string[]; achievements?: string[];
  values?: string[]; nice_to_haves?: string[];
  faq?: { q: string; a: string }[];
};
type BuilderDetails = { title: string | null; skills: string[] | null; ai_tools: string[] | null; experience_level: string | null; builder_type: string | null; verified: boolean | null };
type ProfileService = { id: string; title: string; description: string | null; cover_image_url: string | null; category: string | null; rating_avg: number | null; packages: any };
type ProfileProject = { id: string; title: string; cover_image_url: string | null; tags: string[] | null; upvote_count: number | null; industry: string | null };
type ProfileCommunity = { id: string; name: string; slug: string; icon: string | null; category: string | null; member_count: number | null };
type ProfileReview = { id: string; rating: number; comment: string | null; created_at: string; reviewer_id: string; reviewer?: { display_name: string | null; avatar_url: string | null; username: string | null } | null };
type MiniProfile = { id: string; username: string | null; display_name: string | null; avatar_url: string | null };
type Prompt = { id: string; title: string; category: string | null; upvote_count: number; model: string | null };
type WorkflowRow = { id: string; title: string; category: string | null; upvote_count: number; tools: string[] };
type TemplateRow = { id: string; title: string; slug: string; category: string | null; downloads: number; cover_image_url: string | null };
type SimilarBuilder = { id: string; username: string | null; display_name: string | null; avatar_url: string | null; builder_details?: { title: string | null } | null };

const LEVELS = [
  { name: "Vibe Starter", min: 0, max: 500 }, { name: "Vibe Builder", min: 500, max: 2000 },
  { name: "Vibe Maker", min: 2000, max: 5000 }, { name: "Vibe Pro", min: 5000, max: 15000 },
  { name: "Vibe Legend", min: 15000, max: 50000 }, { name: "Vibe Master", min: 50000, max: Infinity },
];
function levelFor(xp: number) {
  const cur = LEVELS.find((l) => xp >= l.min && xp < l.max) ?? LEVELS[LEVELS.length - 1];
  const next = LEVELS[LEVELS.indexOf(cur) + 1];
  const pct = next ? Math.min(100, Math.round(((xp - cur.min) / (cur.max - cur.min)) * 100)) : 100;
  return { cur, next, pct, remaining: next ? next.min - xp : 0 };
}
function priceFromPackages(pkgs: any): number | null {
  if (!pkgs) return null;
  const arr = Array.isArray(pkgs) ? pkgs : (Array.isArray((pkgs as any).items) ? (pkgs as any).items : []);
  const prices = arr.map((p: any) => Number(p?.price ?? p?.price_from ?? p?.amount)).filter((n: number) => Number.isFinite(n) && n > 0);
  return prices.length ? Math.min(...prices) : null;
}

async function fetchProfile(username: string): Promise<(RealProfile & { og_number?: number | null }) | null> {
  const { data, error } = await supabase.from("profiles").select("id, username, display_name, avatar_url, banner_url, bio, location, website_url, x_url, github_url, linkedin_url, accent_color, roles, availability_status, follower_count, following_count, total_xp, current_level, vibecoin_balance, login_streak, longest_streak, streak_badges, onboarded_at, created_at, ai_content" as any).eq("username", username).maybeSingle();
  if (error) throw error;
  // Always attempt to load matching OG member so we can attach the OG badge + fall back ai_content
  const { getOgMemberByUsername } = await import("@/lib/og-members-api");
  const og = await getOgMemberByUsername(username).catch(() => null);
  if (data) {
    const merged: any = { ...(data as any) };
    if ((!merged.ai_content || Object.keys(merged.ai_content).length === 0) && og?.ai_content) {
      merged.ai_content = og.ai_content;
    }
    merged.og_number = og?.og_number ?? null;
    return merged;
  }
  if (!og) return null;
  const ai = (og.ai_content ?? {}) as any;
  const name = og.full_name || og.username || `OG #${og.og_number}`;
  const location = [og.city, og.state].filter(Boolean).join(", ") || "India";
  const synthetic: RealProfile & { og_number: number } = {
    id: `og-${og.og_number}`,
    username: og.username,
    display_name: name,
    avatar_url: `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(og.username || String(og.og_number))}&backgroundColor=E8623A,F5A623,2DD4BF,7C3AED`,
    banner_url: null,
    bio: (ai.headline as string) || og.wall_tagline || `OG Founding Member #${og.og_number}`,
    location,
    website_url: null,
    x_url: og.twitter_url,
    github_url: og.github_url,
    linkedin_url: og.linkedin_url,
    accent_color: "#E8623A",
    roles: ["builder"],
    availability_status: "available",
    follower_count: 0,
    following_count: 0,
    total_xp: 100 * og.og_number,
    current_level: "Vibe Builder",
    vibecoin_balance: 500,
    login_streak: 0,
    longest_streak: 0,
    streak_badges: [`OG #${og.og_number}`],
    onboarded_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
    ai_content: og.ai_content ?? {
      headline: og.wall_tagline || `OG Founding Member #${og.og_number}`,
      about_long: `${name} is one of the original founding members of VibeCode (OG #${og.og_number}) — an early builder from ${location} shaping India's AI-native builder community from day one.`,
    },
    og_number: og.og_number,
  };
  return synthetic;
}
async function fetchBuilder(id: string) { const { data } = await supabase.from("builder_details").select("title, skills, ai_tools, experience_level, builder_type, verified").eq("profile_id", id).maybeSingle(); return (data as BuilderDetails | null) ?? null; }
async function fetchServices(id: string) { const { data } = await supabase.from("services").select("id, title, description, cover_image_url, category, rating_avg, packages").eq("builder_id", id).order("created_at", { ascending: false }).limit(6); return (data as ProfileService[]) ?? []; }
async function fetchProjects(id: string) { const { data } = await supabase.from("projects").select("id, title, cover_image_url, tags, upvote_count, industry").eq("builder_id", id).order("upvote_count", { ascending: false }).limit(6); return (data as ProfileProject[]) ?? []; }
async function fetchCommunities(id: string) {
  const { data } = await supabase.from("community_members").select("community_id, communities(id, name, slug, icon, category, member_count)").eq("profile_id", id).limit(12);
  return ((data as any[]) ?? []).map((r) => r.communities).filter(Boolean) as ProfileCommunity[];
}
async function fetchReviews(id: string) {
  const { data } = await supabase.from("reviews").select("id, rating, comment, created_at, reviewer_id").eq("reviewed_profile_id", id).order("created_at", { ascending: false }).limit(20);
  const rows = (data as ProfileReview[]) ?? [];
  if (!rows.length) return rows;
  const ids = Array.from(new Set(rows.map((r) => r.reviewer_id)));
  const { data: profs } = await supabase.from("profiles").select("id, display_name, avatar_url, username").in("id", ids);
  const map = new Map<string, any>();
  (profs ?? []).forEach((p: any) => map.set(p.id, { display_name: p.display_name, avatar_url: p.avatar_url, username: p.username }));
  return rows.map((r) => ({ ...r, reviewer: map.get(r.reviewer_id) ?? null }));
}
async function fetchPrompts(id: string) { const { data } = await supabase.from("prompts").select("id, title, category, upvote_count, model").eq("author_id", id).order("upvote_count", { ascending: false }).limit(6); return (data as Prompt[]) ?? []; }
async function fetchWorkflows(id: string) { const { data } = await supabase.from("workflows").select("id, title, category, upvote_count, tools").eq("author_id", id).order("upvote_count", { ascending: false }).limit(6); return (data as WorkflowRow[]) ?? []; }
async function fetchTemplates(id: string) { const { data } = await supabase.from("templates").select("id, title, slug, category, downloads, cover_image_url").eq("author_id", id).order("downloads", { ascending: false }).limit(6); return (data as TemplateRow[]) ?? []; }
async function fetchTopFollowers(id: string): Promise<MiniProfile[]> {
  const { data } = await supabase.from("follows").select("follower_id").eq("following_id", id).limit(12);
  const ids = (data ?? []).map((r: any) => r.follower_id);
  if (!ids.length) return [];
  const { data: profs } = await supabase.from("profiles").select("id, username, display_name, avatar_url").in("id", ids);
  return (profs as MiniProfile[]) ?? [];
}
async function fetchSimilar(id: string, skills: string[] | null): Promise<SimilarBuilder[]> {
  let q = supabase.from("profiles").select("id, username, display_name, avatar_url, builder_details(title)").neq("id", id).not("onboarded_at", "is", null).not("username", "is", null).limit(4);
  if (skills?.length) q = q.contains("builder_details.skills" as any, skills.slice(0, 2) as any);
  const { data } = await q;
  return (data as any as SimilarBuilder[]) ?? [];
}
async function isFollowing(myId: string, targetId: string): Promise<boolean> {
  const { data } = await supabase.from("follows").select("follower_id").eq("follower_id", myId).eq("following_id", targetId).maybeSingle();
  return !!data;
}

// ── Building blocks ───────────────────────────────────────────────────────────
function Section({ icon: Icon, title, children }: { icon: any; title: string; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="flex items-center gap-2 font-display text-lg font-extrabold">
        <span className="grid h-7 w-7 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-gold"><Icon className="h-4 w-4" /></span>
        {title}
      </h3>
      <div className="mt-2.5 text-sm leading-relaxed text-foreground/85">{children}</div>
    </section>
  );
}
function CheckList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-2">
      {items.map((it, i) => (
        <li key={i} className="flex items-start gap-2 text-sm">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-coral" />
          <span>{it}</span>
        </li>
      ))}
    </ul>
  );
}
function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="ml-4 list-disc space-y-1.5 text-sm marker:text-foreground/40">
      {items.map((it, i) => <li key={i} className="pl-1">{it}</li>)}
    </ul>
  );
}
function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <dt className="text-muted-foreground">{k}</dt>
      <dd className="min-w-0 break-words text-right font-extrabold">{v}</dd>
    </div>
  );
}
function MiniAvatar({ p }: { p: MiniProfile }) {
  const src = p.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${p.username ?? p.id}`;
  return p.username ? (
    <Link to="/u/$username" params={{ username: p.username }} className="group relative block">
      <img src={src} alt={p.display_name || p.username || ""} title={p.display_name || p.username || ""} loading="lazy"
        className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F] object-cover transition group-hover:-translate-y-0.5" />
    </Link>
  ) : (<img src={src} alt="" className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F] object-cover" />);
}

// ── Component ─────────────────────────────────────────────────────────────────
export function RealUserProfile({ username }: { username: string }) {
  const qc = useQueryClient();
  const { user } = useAuth();

  const { data: profile, isLoading, isError } = useQuery({ queryKey: ["profile", "by-username", username], queryFn: () => fetchProfile(username) });
  const uid = profile?.id;
  const isOg = !!uid && uid.startsWith("og-");
  const enabled = !!uid && !isOg;
  const { data: posts = [] } = useQuery({ queryKey: ["profile", "posts", uid], queryFn: () => listUserPosts(uid!, 15), enabled });
  const { data: builder } = useQuery({ queryKey: ["profile", "builder", uid], queryFn: () => fetchBuilder(uid!), enabled });
  const { data: services = [] } = useQuery({ queryKey: ["profile", "services", uid], queryFn: () => fetchServices(uid!), enabled });
  const { data: projects = [] } = useQuery({ queryKey: ["profile", "projects", uid], queryFn: () => fetchProjects(uid!), enabled });
  const { data: communities = [] } = useQuery({ queryKey: ["profile", "communities", uid], queryFn: () => fetchCommunities(uid!), enabled });
  const { data: reviews = [] } = useQuery({ queryKey: ["profile", "reviews", uid], queryFn: () => fetchReviews(uid!), enabled });
  const { data: prompts = [] } = useQuery({ queryKey: ["profile", "prompts", uid], queryFn: () => fetchPrompts(uid!), enabled });
  const { data: workflows = [] } = useQuery({ queryKey: ["profile", "workflows", uid], queryFn: () => fetchWorkflows(uid!), enabled });
  const { data: templates = [] } = useQuery({ queryKey: ["profile", "templates", uid], queryFn: () => fetchTemplates(uid!), enabled });
  const { data: topFollowers = [] } = useQuery({ queryKey: ["profile", "followers-preview", uid], queryFn: () => fetchTopFollowers(uid!), enabled });
  const { data: similar = [] } = useQuery({ queryKey: ["profile", "similar", uid, builder?.skills?.join(",")], queryFn: () => fetchSimilar(uid!, builder?.skills ?? null), enabled });
  const { data: followingMe = false } = useQuery({
    queryKey: ["profile", "follows-me", user?.id, uid],
    queryFn: () => (user?.id && uid ? isFollowing(user.id, uid) : Promise.resolve(false)),
    enabled: !!user?.id && !!uid && !isOg && user.id !== uid,
  });

  const [followBusy, setFollowBusy] = useState(false);
  const isMe = !!(user?.id && uid && user.id === uid);
  const avgRating = useMemo(() => reviews.length ? (reviews.reduce((a, r) => a + (r.rating || 0), 0) / reviews.length).toFixed(1) : null, [reviews]);

  // Owner-only: saved (bookmarked) posts
  const { data: saved = [] } = useQuery({
    queryKey: ["profile", "saved", user?.id],
    queryFn: () => listBookmarks(30),
    enabled: isMe,
  });


  // Live viewer counter
  const [liveViewers, setLiveViewers] = useState(() => 3 + Math.floor(Math.random() * 8));
  useEffect(() => { const t = setInterval(() => setLiveViewers((v) => Math.max(2, v + (Math.random() > 0.5 ? 1 : -1))), 5000); return () => clearInterval(t); }, []);

  // Track profile views (Pro analytics). Non-blocking, skips self.
  useEffect(() => {
    if (!uid || isOg || (user?.id && user.id === uid)) return;
    import("@/lib/feed-algorithm").then(({ trackProfileView }) =>
      trackProfileView(uid, user?.id ?? null, "direct"),
    ).catch(() => {});
  }, [uid, isOg, user?.id]);


  useEffect(() => {
    if (!uid || isOg) return;
    const invalidate = () => {
      ["by-username", "posts", "services", "projects", "communities", "reviews", "builder", "prompts", "workflows", "templates", "followers-preview"].forEach((k) =>
        qc.invalidateQueries({ queryKey: ["profile", k, k === "by-username" ? username : uid] }));
    };
    const ch = supabase.channel(`profile:${uid}:${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles", filter: `id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "posts", filter: `author_id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "projects", filter: `builder_id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "services", filter: `builder_id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "prompts", filter: `author_id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "workflows", filter: `author_id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "templates", filter: `author_id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "reviews", filter: `reviewed_profile_id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "follows", filter: `following_id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "xp_transactions", filter: `profile_id=eq.${uid}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "builder_details", filter: `profile_id=eq.${uid}` }, invalidate)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [uid, qc, username, isOg]);

  async function onFollow() {
    if (!user) { toast.error("Sign in to follow"); return; }
    if (!profile) return;
    setFollowBusy(true);
    try {
      await toggleFollow(profile.id, followingMe);
      qc.invalidateQueries({ queryKey: ["profile", "follows-me", user.id, profile.id] });
      qc.invalidateQueries({ queryKey: ["profile", "by-username", username] });
      qc.invalidateQueries({ queryKey: ["profile", "followers-preview", profile.id] });
      toast.success(followingMe ? "Unfollowed" : `Following ${profile.display_name || profile.username}`);
    } catch (e: any) { toast.error(e?.message ?? "Failed"); }
    finally { setFollowBusy(false); }
  }
  function onShare() { sharePage(`${profile?.display_name || profile?.username} · VibeCode`, profile?.bio || ""); }
  function copyProfileLink() {
    const url = typeof window !== "undefined" ? `${window.location.origin}/u/${profile?.username}` : "";
    navigator.clipboard?.writeText(url); toast.success("Profile link copied");
  }

  if (isLoading) return <Shell><div className="container-page grid place-items-center py-24 text-sm text-muted-foreground"><Loader2 className="mb-2 h-5 w-5 animate-spin" /> Loading profile…</div></Shell>;
  if (isError || !profile) return (
    <Shell><div className="container-page py-20 text-center">
      <div className="text-2xl font-black">Profile not found</div>
      <p className="mt-2 text-sm text-muted-foreground">No user with username @{username}.</p>
      <Link to="/vibe" className="mt-4 inline-block rounded-full bg-coral px-4 py-2 text-xs font-bold text-white">Back to Feed</Link>
    </div></Shell>
  );
  if (!profile.onboarded_at || !profile.bio || !profile.username) return (
    <Shell><div className="container-page py-16 text-center">
      <Sparkles className="mx-auto h-8 w-8 text-coral" />
      <h1 className="mt-3 font-display text-2xl font-black">This profile isn't live yet</h1>
      <p className="mt-2 text-sm text-muted-foreground">The owner hasn't completed their profile. Check back soon.</p>
      {isMe && <Link to="/onboarding" className="mt-4 inline-block rounded-full bg-coral px-4 py-2 text-xs font-bold text-white">Complete your profile</Link>}
    </div></Shell>
  );

  const name = profile.display_name || profile.username || "Anonymous";
  const isBuilder = (profile.roles ?? []).includes("builder");
  const isHirer = (profile.roles ?? []).includes("hirer");
  const xp = profile.total_xp ?? 0;
  const lvl = levelFor(xp);
  const availability = profile.availability_status || (isBuilder ? "Open to work" : null);
  const joined = new Date(profile.created_at).toLocaleDateString("en-US", { month: "short", year: "numeric" });
  const rateFrom = services.reduce<number | null>((acc, s) => { const p = priceFromPackages(s.packages); if (p != null) return acc == null ? p : Math.min(acc, p); return acc; }, null);
  const totalShips = projects.length + prompts.length + workflows.length + templates.length + services.length;
  const totalUpvotes = projects.reduce((a, p) => a + (p.upvote_count ?? 0), 0) + prompts.reduce((a, p) => a + p.upvote_count, 0) + workflows.reduce((a, w) => a + w.upvote_count, 0);
  const isNewMember = (Date.now() - new Date(profile.created_at).getTime()) < 1000 * 60 * 60 * 24 * 30;

  const ai = profile.ai_content ?? {};
  const aboutLong = ai.about_long || profile.bio || "";
  const headline = ai.headline || builder?.title || (isBuilder ? "AI Builder" : "Member");

  return (
    <Shell>
      <div className="container-page py-6">
        {/* Breadcrumb / actions */}
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="text-muted-foreground">
            <Link to="/vibe" className="font-bold hover:text-foreground">People</Link>
            <span className="mx-1.5">›</span>
            <span className="font-bold text-foreground">{name}</span>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/vibe" className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 py-1.5 font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <ArrowLeft className="h-3 w-3" /> Back
            </Link>
            <button onClick={onShare} className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 py-1.5 font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <Share2 className="h-3 w-3" /> Share
            </button>
          </div>
        </div>

        <div className="grid min-w-0 gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
          {/* ─── MAIN COLUMN ─── */}
          <div className="min-w-0 space-y-6">
            {/* Header card */}
            <div className="card-editorial max-w-full p-4 md:p-6">
              <div className="grid grid-cols-[auto_minmax(0,1fr)] items-start gap-3 sm:grid-cols-[auto_minmax(0,1fr)_auto] md:gap-4">
                <img
                  src={profile.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${profile.username ?? profile.id}`}
                  alt={name}
                  className="h-14 w-14 shrink-0 rounded-2xl border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] object-cover md:h-20 md:w-20"
                  style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}
                />
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h1 className="min-w-0 break-words font-display text-lg font-extrabold leading-tight tracking-tight [overflow-wrap:anywhere] sm:text-2xl md:text-3xl">{name}</h1>
                    {(profile as any).og_number != null && (
                      <span
                        title={`VibeCode OG Founding Member #${(profile as any).og_number} · Premium`}
                        className="inline-flex items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-gradient-to-r from-[#F5A623] via-[#E8623A] to-[#7C3AED] px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-white"
                        style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                      >
                        <Star className="h-3 w-3 fill-white" /> OG #{(profile as any).og_number} · Premium
                      </span>
                    )}
                    {isNewMember && <span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white">New</span>}
                  </div>
                  <div className="mt-1 flex min-w-0 items-center gap-1.5 text-sm font-bold">
                    <span className="truncate">{headline}</span>
                    {(builder?.verified || (profile as any).og_number != null) && <BadgeCheck className="h-4 w-4 shrink-0 text-coral" />}
                  </div>
                </div>
                {!isMe ? (
                  <button
                    onClick={onFollow} disabled={followBusy}
                    className={`col-span-2 grid h-9 w-full shrink-0 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] sm:col-span-1 sm:w-9 ${followingMe ? "bg-foreground text-white" : "bg-coral text-white"}`}
                    style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }} aria-label="Follow"
                  >
                    {followBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : followingMe ? <UserCheck className="h-4 w-4" /> : <UserPlus className="h-4 w-4" />}
                  </button>
                ) : (
                  <Link to="/settings" className="col-span-2 inline-flex h-9 w-full shrink-0 items-center justify-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-gold px-3 text-xs font-black sm:col-span-1 sm:w-auto" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                    <Sparkles className="h-3.5 w-3.5" /> Edit Profile
                  </Link>
                )}
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground">
                {profile.location && <span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5 shrink-0" /> {profile.location}</span>}
                {availability && <span className="flex items-center gap-1.5"><Briefcase className="h-3.5 w-3.5 shrink-0" /> {availability}</span>}
                {builder?.experience_level && <span className="flex items-center gap-1.5"><TrendingUp className="h-3.5 w-3.5 shrink-0" /> {builder.experience_level}</span>}
                {rateFrom != null && <span className="flex items-center gap-1 font-bold text-foreground"><IndianRupee className="h-3.5 w-3.5 shrink-0" />{rateFrom.toLocaleString()}+</span>}
                {profile.username && <span>@{profile.username}</span>}
              </div>
              {!!builder?.skills?.length && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {builder.skills.slice(0, 6).map((s) => (
                    <span key={s} className="max-w-full break-words rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-2 py-1 text-[11px] font-bold [overflow-wrap:anywhere]">{s}</span>
                  ))}
                </div>
              )}
              <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 border-t-[1.5px] border-dashed border-[#0F0F0F]/30 pt-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> Joined {joined}</span>
                <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {(profile.follower_count ?? 0).toLocaleString()} followers</span>
                <span className="flex items-center gap-1"><Rocket className="h-3.5 w-3.5" /> {totalShips} ships</span>
                {totalUpvotes > 0 && <span className="flex items-center gap-1"><ThumbsUp className="h-3.5 w-3.5" /> {totalUpvotes.toLocaleString()} upvotes</span>}
              </div>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="overview" className="min-w-0 max-w-full">
              <TabsList className="w-full">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="work">Work</TabsTrigger>
                <TabsTrigger value="services">Services</TabsTrigger>
                <TabsTrigger value="reviews">Reviews {reviews.length ? `(${reviews.length})` : ""}</TabsTrigger>
                <TabsTrigger value="activity">Activity</TabsTrigger>
                {isMe && <TabsTrigger value="saved">Saved {saved.length ? `(${saved.length})` : ""}</TabsTrigger>}
              </TabsList>


              {/* OVERVIEW */}
              <TabsContent value="overview" className="min-w-0 max-w-full space-y-6 py-6">
                <Section icon={Sparkles} title={`About ${name.split(" ")[0]}`}>
                  <p className="whitespace-pre-wrap">{aboutLong}</p>
                </Section>

                {!!ai.what_i_do?.length && (
                  <Section icon={Target} title="What I Do">
                    <CheckList items={ai.what_i_do} />
                  </Section>
                )}

                {(!!ai.expertise?.length || !!builder?.skills?.length) && (
                  <Section icon={Layers} title="Areas of Expertise">
                    {ai.expertise?.length ? <BulletList items={ai.expertise} /> : (
                      <div className="flex flex-wrap gap-2">{(builder!.skills ?? []).map((s) => (
                        <span key={s} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-2.5 py-1 text-xs font-bold">{s}</span>
                      ))}</div>
                    )}
                  </Section>
                )}

                {!!ai.approach?.length && (
                  <Section icon={Compass} title="My Approach">
                    <BulletList items={ai.approach} />
                  </Section>
                )}

                {!!ai.why_work_with_me?.length && (
                  <Section icon={Heart} title={`Why work with ${name.split(" ")[0]}?`}>
                    <BulletList items={ai.why_work_with_me} />
                  </Section>
                )}

                {!!ai.values?.length && (
                  <Section icon={ShieldCheck} title="Values I Ship By">
                    <BulletList items={ai.values} />
                  </Section>
                )}

                {(!!builder?.ai_tools?.length || !!ai.nice_to_haves?.length) && (
                  <Section icon={Zap} title="Tools & Stack">
                    <div className="flex flex-wrap gap-2">
                      {(builder?.ai_tools ?? ai.nice_to_haves ?? []).map((t) => (
                        <span key={t} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-2.5 py-1 text-xs font-bold">{t}</span>
                      ))}
                    </div>
                  </Section>
                )}

                {!!ai.achievements?.length && (
                  <Section icon={Trophy} title="Highlights & Achievements">
                    <CheckList items={ai.achievements} />
                  </Section>
                )}

                {!!ai.faq?.length && (
                  <Section icon={HelpCircle} title="Frequently Asked">
                    <div className="space-y-3">
                      {ai.faq.map((f, i) => (
                        <div key={i} className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3">
                          <div className="text-sm font-extrabold">{f.q}</div>
                          <p className="mt-1 text-sm text-foreground/80">{f.a}</p>
                        </div>
                      ))}
                    </div>
                  </Section>
                )}

                {!ai.about_long && isMe && (
                  <div className="rounded-xl border-[1.5px] border-dashed border-coral bg-coral/5 p-4 text-sm">
                    <div className="flex items-center gap-2 font-extrabold"><Sparkles className="h-4 w-4 text-coral" /> Make your profile pop</div>
                    <p className="mt-1 text-muted-foreground">Run AI Autofill from onboarding to generate a proper detailed profile with all sections.</p>
                    <Link to="/onboarding" className="mt-3 inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1.5 text-xs font-black text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                      <Sparkles className="h-3 w-3" /> Autofill now
                    </Link>
                  </div>
                )}
              </TabsContent>

              {/* WORK */}
              <TabsContent value="work" className="min-w-0 max-w-full space-y-6 py-6">
                <Section icon={Rocket} title="Featured Projects">
                  {projects.length === 0 ? <p className="text-muted-foreground">No projects yet.</p> : (
                    <div className="grid gap-3 sm:grid-cols-2">
                      {projects.map((p) => (
                        <Link key={p.id} to="/projects/$id" params={{ id: p.id }} className="card-editorial group block overflow-hidden !p-0">
                          {p.cover_image_url && <img src={p.cover_image_url} alt="" className="h-32 w-full object-cover" loading="lazy" />}
                          <div className="p-3">
                            {p.industry && <div className="text-[10px] font-black uppercase tracking-wider text-coral">{p.industry}</div>}
                            <div className="mt-0.5 line-clamp-2 font-display text-sm font-black">{p.title}</div>
                            <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-muted-foreground"><Heart className="h-3 w-3" /> {p.upvote_count ?? 0}</div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                </Section>
                {prompts.length > 0 && (
                  <Section icon={FileText} title="Prompts">
                    <div className="grid gap-2 sm:grid-cols-2">
                      {prompts.map((p) => (
                        <Link key={p.id} to="/prompts/$id" params={{ id: p.id }} className="card-editorial flex items-start gap-2 !p-3">
                          <FileText className="mt-0.5 h-3.5 w-3.5 shrink-0 text-coral" />
                          <div className="min-w-0 flex-1">
                            <div className="line-clamp-1 text-[13px] font-black">{p.title}</div>
                            <div className="mt-0.5 flex items-center gap-2 text-[10px] text-muted-foreground">
                              {p.category && <span className="uppercase">{p.category}</span>}
                              {p.model && <span>· {p.model}</span>}
                              <span className="ml-auto">▲ {p.upvote_count}</span>
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </Section>
                )}
                {workflows.length > 0 && (
                  <Section icon={Workflow} title="Workflows">
                    <div className="grid gap-2 sm:grid-cols-2">
                      {workflows.map((w) => (
                        <Link key={w.id} to="/workflows/$id" params={{ id: w.id }} className="card-editorial !p-3">
                          <div className="line-clamp-1 text-[13px] font-black">{w.title}</div>
                          <div className="mt-1 flex flex-wrap items-center gap-1">
                            {(w.tools ?? []).slice(0, 4).map((t) => <span key={t} className="rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-1.5 py-0.5 text-[9px] font-bold">{t}</span>)}
                            <span className="ml-auto text-[10px] font-bold text-muted-foreground">▲ {w.upvote_count}</span>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </Section>
                )}
                {templates.length > 0 && (
                  <Section icon={LayoutTemplate} title="Templates">
                    <div className="grid gap-3 sm:grid-cols-2">
                      {templates.map((t) => (
                        <Link key={t.id} to="/templates/$slug" params={{ slug: t.slug }} className="card-editorial block overflow-hidden !p-0">
                          {t.cover_image_url && <img src={t.cover_image_url} alt="" className="h-24 w-full object-cover" loading="lazy" />}
                          <div className="p-2.5">
                            <div className="line-clamp-1 text-[13px] font-black">{t.title}</div>
                            <div className="mt-0.5 flex items-center justify-between text-[10px] text-muted-foreground">
                              <span className="uppercase">{t.category ?? "Template"}</span>
                              <span>{t.downloads.toLocaleString()} dl</span>
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </Section>
                )}
                {!!communities.length && (
                  <Section icon={Users} title="Communities">
                    <div className="flex flex-wrap gap-2">
                      {communities.map((c) => (
                        <Link key={c.id} to="/communities/$slug" params={{ slug: c.slug }} className="inline-flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 py-1.5 text-xs font-bold">
                          {c.icon && <span className="text-sm">{c.icon}</span>}
                          {c.name}
                          <span className="text-[10px] text-muted-foreground">· {c.member_count ?? 0}</span>
                        </Link>
                      ))}
                    </div>
                  </Section>
                )}
              </TabsContent>

              {/* SERVICES */}
              <TabsContent value="services" className="min-w-0 max-w-full space-y-6 py-6">
                {!!ai.services_offered?.length && (
                  <Section icon={Package} title="What I Offer">
                    <CheckList items={ai.services_offered} />
                  </Section>
                )}
                <Section icon={Briefcase} title="Available Services">
                  {services.length === 0 ? <p className="text-muted-foreground">No packages listed yet.</p> : (
                    <div className="grid gap-3 sm:grid-cols-2">
                      {services.map((s) => {
                        const pf = priceFromPackages(s.packages);
                        return (
                          <Link key={s.id} to="/services/$id" params={{ id: s.id }} className="card-editorial block !p-3">
                            {s.cover_image_url && <img src={s.cover_image_url} alt="" className="mb-2 h-28 w-full rounded-lg border-[1.5px] border-[#0F0F0F] object-cover" loading="lazy" />}
                            <div className="text-[10px] font-black uppercase text-muted-foreground">{s.category ?? "Service"}</div>
                            <div className="mt-1 font-display text-sm font-black">{s.title}</div>
                            {s.description && <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{s.description}</p>}
                            <div className="mt-2 flex items-center justify-between">
                              {typeof s.rating_avg === "number" && s.rating_avg > 0 ? <span className="inline-flex items-center gap-1 text-[11px]"><Star className="h-3 w-3 fill-[#F5A623] text-[#F5A623]" /> {s.rating_avg.toFixed(1)}</span> : <span />}
                              {pf != null && <span className="inline-flex items-center gap-0.5 text-[11px] font-black text-coral"><IndianRupee className="h-3 w-3" />{pf.toLocaleString()}+</span>}
                            </div>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </Section>
              </TabsContent>

              {/* REVIEWS */}
              <TabsContent value="reviews" className="min-w-0 max-w-full space-y-4 py-6">
                <div className="card-editorial p-4 sm:p-5">
                  <div className="flex flex-wrap items-center gap-4">
                    <div className="font-display text-4xl font-extrabold">{avgRating ?? "—"}</div>
                    <div className="inline-flex">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className={`h-4 w-4 ${avgRating && i < Math.round(Number(avgRating)) ? "fill-[#F5A623] text-[#F5A623]" : "text-muted-foreground/40"}`} />)}</div>
                    <span className="text-xs text-muted-foreground">{reviews.length} review{reviews.length === 1 ? "" : "s"}</span>
                  </div>
                </div>
                {reviews.length === 0 ? <p className="text-sm text-muted-foreground">No reviews yet.</p> : reviews.slice(0, 10).map((r) => (
                  <div key={r.id} className="card-editorial p-4">
                    <div className="flex items-center gap-2">
                      <img src={r.reviewer?.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${r.reviewer_id}`} alt="" className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F] object-cover" />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-bold">{r.reviewer?.display_name || r.reviewer?.username || "Anonymous"}</div>
                        <div className="text-[10px] text-muted-foreground">{timeAgo(r.created_at)}</div>
                      </div>
                      <div className="inline-flex">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className={`h-3 w-3 ${i < r.rating ? "fill-[#F5A623] text-[#F5A623]" : "text-muted-foreground/40"}`} />)}</div>
                    </div>
                    {r.comment && <p className="mt-2 whitespace-pre-wrap text-sm">{r.comment}</p>}
                  </div>
                ))}
              </TabsContent>

              {/* ACTIVITY */}
              <TabsContent value="activity" className="min-w-0 max-w-full space-y-3 py-6">
                {posts.length === 0 ? <p className="text-sm text-muted-foreground">No posts yet.</p> : posts.slice(0, 12).map((p: LivePost) => (
                  <article key={p.id} className="card-editorial p-4">
                    <div className="text-[10px] font-bold uppercase text-muted-foreground">{timeAgo(p.created_at)}</div>
                    {p.body && <div className="mt-1 whitespace-pre-wrap text-sm">{p.body}</div>}
                    {p.image_urls.length > 0 && (
                      <div className="mt-2 grid grid-cols-3 gap-1">
                        {p.image_urls.slice(0, 3).map((u, i) => <img key={u + i} src={u} alt="" className="h-24 w-full rounded-md border-[1.5px] border-[#0F0F0F] object-cover" loading="lazy" />)}
                      </div>
                    )}
                    <div className="mt-2 flex items-center gap-3 text-[10px] text-muted-foreground">
                      <span>♥ {p.like_count}</span><span>💬 {p.comment_count}</span><span>🔁 {p.repost_count}</span>
                    </div>
                  </article>
                ))}
              </TabsContent>

              {/* SAVED (owner only) */}
              {isMe && (
                <TabsContent value="saved" className="min-w-0 max-w-full space-y-3 py-6">
                  {saved.length === 0 ? (
                    <p className="text-sm text-muted-foreground">
                      Nothing saved yet. Tap the bookmark icon on any post to save it here.
                    </p>
                  ) : (
                    saved.map((p: LivePost) => (
                      <article key={p.id} className="card-editorial p-4">
                        <div className="flex items-center gap-2 text-[10px] font-bold uppercase text-muted-foreground">
                          <span>Saved</span>
                          <span>·</span>
                          <span>by {p.author?.display_name || p.author?.username || "someone"}</span>
                          <span>·</span>
                          <span>{timeAgo(p.created_at)}</span>
                        </div>
                        {p.body && <div className="mt-1 whitespace-pre-wrap text-sm">{p.body}</div>}
                        {p.image_urls.length > 0 && (
                          <div className="mt-2 grid grid-cols-3 gap-1">
                            {p.image_urls.slice(0, 3).map((u, i) => (
                              <img key={u + i} src={u} alt="" className="h-24 w-full rounded-md border-[1.5px] border-[#0F0F0F] object-cover" loading="lazy" />
                            ))}
                          </div>
                        )}
                        <div className="mt-2 flex items-center gap-3 text-[10px] text-muted-foreground">
                          <span>♥ {p.like_count}</span><span>💬 {p.comment_count}</span><span>🔁 {p.repost_count}</span>
                        </div>
                        <div className="mt-3">
                          <Link to="/vibe" className="text-[11px] font-bold text-coral hover:underline">
                            Open in feed →
                          </Link>
                        </div>
                      </article>
                    ))
                  )}
                </TabsContent>
              )}
            </Tabs>

          </div>

          {/* ─── SIDEBAR ─── */}
          <aside className="min-w-0 max-w-full space-y-4 lg:sticky lg:top-20 lg:self-start">
            {/* Profile Overview */}
            <div className="card-editorial max-w-full p-4 sm:p-5">
              <h4 className="font-display text-base font-extrabold">Profile Overview</h4>
              <dl className="mt-3 space-y-2 text-sm">
                <Row k="Role" v={isBuilder ? "Builder" : isHirer ? "Hiring" : "Member"} />
                {builder?.experience_level && <Row k="Experience" v={builder.experience_level} />}
                {profile.location && <Row k="Location" v={profile.location} />}
                {availability && <Row k="Status" v={availability} />}
                {rateFrom != null && <Row k="Starting at" v={<span className="inline-flex items-center gap-0.5 text-coral"><IndianRupee className="h-3 w-3" />{rateFrom.toLocaleString()}</span>} />}
                <Row k="Joined" v={joined} />
                <Row k="Followers" v={(profile.follower_count ?? 0).toLocaleString()} />
                <Row k="Ships" v={totalShips} />
              </dl>

              {/* Live viewers */}
              <div className="mt-4 flex items-center gap-2 rounded-md border-[1.5px] border-dashed border-[#0F0F0F]/40 bg-card px-3 py-2 text-xs">
                <span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-coral opacity-75" /><span className="relative inline-flex h-2 w-2 rounded-full bg-coral" /></span>
                <Eye className="h-3.5 w-3.5" /> <b className="tabular-nums">{liveViewers}</b> viewing right now
              </div>

              {!isMe ? (
                <>
                  <button
                    onClick={onFollow} disabled={followBusy}
                    className={`mt-5 inline-flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] py-2.5 text-sm font-bold ${followingMe ? "bg-foreground text-white" : "bg-coral text-white"}`}
                    style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                  >
                    {followBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : followingMe ? <UserCheck className="h-4 w-4" /> : <UserPlus className="h-4 w-4" />}
                    {followingMe ? "Following" : "Follow"}
                  </button>
                  <Link to="/messages" search={{ to: profile.id }} className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-card py-2.5 text-sm font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                    <MessageSquare className="h-4 w-4" /> Message
                  </Link>
                  <button onClick={copyProfileLink} className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-card py-2 text-xs font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                    <Copy className="h-3.5 w-3.5" /> Copy Link
                  </button>
                </>
              ) : (
                <Link to="/onboarding" className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral py-2.5 text-sm font-bold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                  Edit profile <ArrowRight className="h-4 w-4" />
                </Link>
              )}
            </div>

            {/* Hire card (builders) */}
            {isBuilder && !isMe && (
              <div className="card-editorial max-w-full bg-teal/15 p-4 sm:p-5">
                <div className="flex items-center gap-2 font-display font-extrabold"><Zap className="h-4 w-4 text-coral" /> Hire {name.split(" ")[0]}</div>
                <p className="mt-1 text-xs text-foreground/80">Skip the search. Send a project brief or offer directly.</p>
                <Link to="/submit-job" className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-card py-2.5 text-sm font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                  Post a Job <ArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/messages" search={{ to: profile.id }} className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral py-2.5 text-sm font-bold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                  Send a Message →
                </Link>
              </div>
            )}

            {/* XP & Level */}
            <div className="card-editorial max-w-full p-4 sm:p-5">
              <div className="flex items-center justify-between">
                <h4 className="flex items-center gap-1.5 font-display text-base font-extrabold"><Trophy className="h-4 w-4 text-coral" /> Level</h4>
                <span className="text-[10px] font-black uppercase text-muted-foreground">{xp.toLocaleString()} XP</span>
              </div>
              <div className="mt-2 font-display text-lg font-black">{profile.current_level || lvl.cur.name}</div>
              <div className="mt-2 h-2 w-full overflow-hidden rounded-full border-[1.5px] border-[#0F0F0F] bg-cream">
                <div className="h-full bg-coral transition-all" style={{ width: `${lvl.pct}%` }} />
              </div>
              <div className="mt-1.5 flex items-center justify-between text-[10px] font-bold text-muted-foreground">
                <span>{lvl.pct}% to next</span>
                {lvl.next ? <span>{lvl.remaining.toLocaleString()} XP → {lvl.next.name}</span> : <span>MAX 🏆</span>}
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 border-t-[1.5px] border-dashed border-[#0F0F0F]/25 pt-3 text-center">
                <div>
                  <div className="inline-flex items-center gap-1 font-display text-sm font-black"><Coins className="h-3 w-3 text-[#B8452A]" /> {(profile.vibecoin_balance ?? 0).toLocaleString()}</div>
                  <div className="text-[9px] font-bold uppercase text-muted-foreground">VibeCoins</div>
                </div>
                <div>
                  <div className="inline-flex items-center gap-1 font-display text-sm font-black"><Flame className="h-3 w-3 text-coral" /> {profile.login_streak ?? 0}d</div>
                  <div className="text-[9px] font-bold uppercase text-muted-foreground">Streak</div>
                </div>
                <div>
                  <div className="inline-flex items-center gap-1 font-display text-sm font-black"><Award className="h-3 w-3 text-emerald-600" /> {profile.streak_badges?.length ?? 0}</div>
                  <div className="text-[9px] font-bold uppercase text-muted-foreground">Badges</div>
                </div>
              </div>
            </div>

            {/* Links */}
            {(profile.website_url || profile.x_url || profile.github_url || profile.linkedin_url) && (
              <div className="card-editorial max-w-full p-4 sm:p-5">
                <h4 className="font-display text-base font-extrabold">Links</h4>
                <div className="mt-3 space-y-1.5">
                  {profile.website_url && <a href={profile.website_url} target="_blank" rel="noreferrer noopener" className="flex items-center justify-between rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 py-2 text-xs font-bold"><span className="inline-flex items-center gap-2"><Globe className="h-3.5 w-3.5" /> Website</span><ExternalLink className="h-3 w-3 text-muted-foreground" /></a>}
                  {profile.linkedin_url && <a href={profile.linkedin_url} target="_blank" rel="noreferrer noopener" className="flex items-center justify-between rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 py-2 text-xs font-bold"><span className="inline-flex items-center gap-2"><Linkedin className="h-3.5 w-3.5" /> LinkedIn</span><ExternalLink className="h-3 w-3 text-muted-foreground" /></a>}
                  {profile.github_url && <a href={profile.github_url} target="_blank" rel="noreferrer noopener" className="flex items-center justify-between rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 py-2 text-xs font-bold"><span className="inline-flex items-center gap-2"><Github className="h-3.5 w-3.5" /> GitHub</span><ExternalLink className="h-3 w-3 text-muted-foreground" /></a>}
                  {profile.x_url && <a href={profile.x_url} target="_blank" rel="noreferrer noopener" className="flex items-center justify-between rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 py-2 text-xs font-bold"><span className="inline-flex items-center gap-2"><Twitter className="h-3.5 w-3.5" /> X / Twitter</span><ExternalLink className="h-3 w-3 text-muted-foreground" /></a>}
                </div>
              </div>
            )}

            {/* Recent followers */}
            {topFollowers.length > 0 && (
              <div className="card-editorial max-w-full p-4 sm:p-5">
                <h4 className="font-display text-base font-extrabold">Recent Followers</h4>
                <div className="mt-3 flex flex-wrap gap-1.5">{topFollowers.slice(0, 10).map((p) => <MiniAvatar key={p.id} p={p} />)}</div>
              </div>
            )}

            {/* Similar builders */}
            {similar.length > 0 && (
              <div className="card-editorial max-w-full p-4 sm:p-5">
                <h4 className="font-display text-base font-extrabold">Similar Builders</h4>
                <div className="mt-3 space-y-3">
                  {similar.map((s) => s.username && (
                    <Link key={s.id} to="/u/$username" params={{ username: s.username }} className="-mx-2 flex min-w-0 items-start gap-3 rounded-md p-2 hover:bg-card">
                      <img src={s.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${s.username}`} alt="" className="h-10 w-10 shrink-0 rounded-lg border-[1.5px] border-[#0F0F0F] object-cover" />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-bold">{s.display_name || s.username}</div>
                        <div className="truncate text-xs text-muted-foreground">{s.builder_details?.title || `@${s.username}`}</div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </aside>
        </div>
      </div>
    </Shell>
  );
}
