import type { LucideIcon } from "lucide-react";
import { ChevronDown } from "lucide-react";
import { AnimatedSection } from "@/components/landing/AnimatedSection";
import { BrowserFrame } from "./BrowserFrame";

const INK = "#0F0F0F";
const CORAL = "#E8623A";
const IVORY = "#FAF6F1";

export type UseCase = { icon: LucideIcon; persona: string; line: string };
export type Template = { title: string; tag: string; image?: string; alt: string };
export type FAQ = { q: string; a: string };

export function UseCaseGrid({ items }: { items: UseCase[] }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {items.map((u, i) => {
        const Icon = u.icon;
        return (
          <AnimatedSection key={u.persona} delay={i * 80}>
            <div className="h-full rounded-2xl border-[1.5px] bg-white p-5 transition-transform hover:-translate-y-1" style={{ borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}>
              <span className="grid h-10 w-10 place-items-center rounded-md border-[1.5px]" style={{ background: IVORY, borderColor: INK, color: INK }}>
                <Icon className="h-5 w-5" />
              </span>
              <div className="mt-4 font-display text-base font-extrabold">{u.persona}</div>
              <p className="mt-1 text-sm text-neutral-700">{u.line}</p>
            </div>
          </AnimatedSection>
        );
      })}
    </div>
  );
}

export function TemplateGallery({ items }: { items: Template[] }) {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {items.map((t, i) => (
        <AnimatedSection key={t.title} delay={i * 80}>
          <div className="group">
            <BrowserFrame src={t.image} alt={t.alt} label={t.alt} aspect="4/3" />
            <div className="mt-3 flex items-center justify-between">
              <div className="font-display text-sm font-extrabold" style={{ color: INK }}>{t.title}</div>
              <span className="rounded-full border-[1.5px] bg-white px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider" style={{ borderColor: INK, color: CORAL }}>
                {t.tag}
              </span>
            </div>
          </div>
        </AnimatedSection>
      ))}
    </div>
  );
}

const INTEGRATIONS_FALLBACK = ["GitHub", "Vercel", "Supabase", "n8n", "Cursor", "Anthropic", "Discord", "ClickUp"];

const BRAND_SVG: Record<string, string> = {
  GitHub: "/brands/github.svg",
  Vercel: "/brands/vercel.svg",
  Supabase: "/brands/supabase.svg",
  n8n: "/brands/n8n.svg",
  Cursor: "/brands/cursor.svg",
  Anthropic: "/brands/anthropic.svg",
  Discord: "/brands/discord.svg",
  ClickUp: "/brands/clickup.svg",
};

export function IntegrationsGrid({ items }: { items?: string[] }) {
  const list = items?.length ? items : INTEGRATIONS_FALLBACK;
  return (
    <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6">
      {list.map((name, i) => {
        const svg = BRAND_SVG[name];
        return (
          <AnimatedSection key={name} delay={i * 30}>
            <div className="grid h-16 place-items-center rounded-xl border-[1.5px] bg-white transition-transform hover:-translate-y-0.5" style={{ borderColor: INK, color: INK, boxShadow: `3px 3px 0 0 ${INK}` }} title={name}>
              {svg ? (
                <img src={svg} alt={name} className="h-7 w-auto max-w-[70%] object-contain" loading="lazy" />
              ) : (
                <span className="text-sm font-bold">{name}</span>
              )}
            </div>
          </AnimatedSection>
        );
      })}
    </div>
  );
}

export function FAQAccordion({ items }: { items: FAQ[] }) {
  return (
    <div className="space-y-3">
      {items.map((f, i) => (
        <AnimatedSection key={f.q} delay={i * 60}>
          <details className="group rounded-xl border-[1.5px] bg-white p-5 open:shadow-none" style={{ borderColor: INK, boxShadow: `3px 3px 0 0 ${INK}` }}>
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display text-base font-extrabold" style={{ color: INK }}>
              <span>{f.q}</span>
              <ChevronDown className="h-5 w-5 flex-shrink-0 transition-transform group-open:rotate-180" style={{ color: CORAL }} />
            </summary>
            <p className="mt-3 text-sm text-neutral-700 md:text-base">{f.a}</p>
          </details>
        </AnimatedSection>
      ))}
    </div>
  );
}
