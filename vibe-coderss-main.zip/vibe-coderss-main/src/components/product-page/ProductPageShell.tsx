import { Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import { MegaNav } from "@/components/landing/MegaNav";
import { Footer } from "@/components/site/Footer";
import { KineticWordmark } from "@/components/site/KineticWordmark";
import { AnimatedSection } from "@/components/landing/AnimatedSection";
import { BrowserFrame } from "./BrowserFrame";
import { FeatureRow } from "./FeatureRow";
import { UseCaseGrid, TemplateGallery, IntegrationsGrid, FAQAccordion } from "./ProductSections";
import { InteractiveDemo } from "./InteractiveDemos";
import type { ProductPageConfig } from "@/lib/product-pages";

const INK = "#0F0F0F";
const CORAL = "#E8623A";
const IVORY = "#FAF6F1";

function SectionHeader({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle?: string }) {
  return (
    <div className="mx-auto mb-12 max-w-2xl text-center">
      <div className="text-[11px] font-bold uppercase tracking-wider" style={{ color: CORAL }}>{eyebrow}</div>
      <h2 className="mt-2 font-display text-3xl font-extrabold md:text-4xl">{title}</h2>
      {subtitle && <p className="mt-3 text-base text-neutral-700">{subtitle}</p>}
    </div>
  );
}

export function ProductPageShell({ config }: { config: ProductPageConfig }) {
  return (
    <div className="min-h-screen" style={{ background: IVORY, color: INK }}>
      <MegaNav />

      {/* HERO */}
      <section className="border-b-[1.5px]" style={{ borderColor: INK }}>
        <div className="mx-auto max-w-[1180px] px-4 pb-8 pt-14 md:px-8 md:pb-14 md:pt-20">
          <AnimatedSection>
            <div className="mx-auto max-w-3xl text-center">
              <span
                className="inline-flex items-center rounded-full border-[1.5px] bg-white px-3 py-1 text-[11px] font-bold uppercase tracking-wider"
                style={{ borderColor: INK, color: INK, boxShadow: `2px 2px 0 0 ${INK}` }}
              >
                {config.eyebrow}
              </span>
              <h1 className="mt-5 font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-7xl lg:text-8xl">
                {config.title}
              </h1>

              <p className="mx-auto mt-5 max-w-2xl text-base text-neutral-700 md:text-lg">{config.subtitle}</p>

              <div className="mt-6 flex flex-wrap justify-center gap-2">
                {config.heroBadges.map((b) => (
                  <span key={b} className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] bg-white px-3 py-1 text-[11px] font-semibold" style={{ borderColor: INK }}>
                    <Check className="h-3 w-3" style={{ color: CORAL }} /> {b}
                  </span>
                ))}
              </div>

              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <Link
                  to="/auth"
                  className="inline-flex items-center gap-1.5 rounded-md border-[1.5px] px-5 py-3 text-sm font-extrabold text-white"
                  style={{ background: CORAL, borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
                >
                  Join VibeCode <ArrowRight className="h-4 w-4" />
                </Link>
                <a
                  href="#features"
                  className="inline-flex items-center rounded-md border-[1.5px] bg-white px-5 py-3 text-sm font-extrabold"
                  style={{ borderColor: INK, color: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
                >
                  See how it works
                </a>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection delay={150}>
            <div className="mx-auto mt-12 max-w-5xl md:mt-16">
              <BrowserFrame src={config.heroShot.src} video={config.heroShot.video} alt={config.heroShot.alt} label={config.heroShot.label} aspect="16/10" />
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* LOGO STRIP */}
      <section className="border-b-[1.5px]" style={{ borderColor: INK, background: "#fff" }}>
        <div className="mx-auto max-w-[1180px] px-4 py-8 md:px-8">
          <div className="text-center text-[11px] font-bold uppercase tracking-wider text-neutral-500">
            Trusted by builders shipping with
          </div>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-x-10 gap-y-5">
            {[
              { name: "GitHub", src: "/brands/github.svg" },
              { name: "Vercel", src: "/brands/vercel.svg" },
              { name: "Supabase", src: "/brands/supabase.svg" },
              { name: "n8n", src: "/brands/n8n.svg" },
              { name: "Cursor", src: "/brands/cursor.svg" },
              { name: "Anthropic", src: "/brands/anthropic.svg" },
              { name: "Discord", src: "/brands/discord.svg" },
              { name: "ClickUp", src: "/brands/clickup.svg" },
            ].map((b) => (
              <img
                key={b.name}
                src={b.src}
                alt={b.name}
                title={b.name}
                className="h-7 w-auto opacity-70 grayscale transition hover:opacity-100 hover:grayscale-0"
                loading="lazy"
              />
            ))}
          </div>
        </div>
      </section>

      {/* FEATURE ROWS */}
      <section id="features" className="border-b-[1.5px]" style={{ borderColor: INK }}>
        <div className="mx-auto max-w-[1180px] space-y-24 px-4 py-20 md:px-8 md:py-28">
          {config.featureRows.map((row, i) => (
            <FeatureRow
              key={row.title}
              data={row}
              reverse={i % 2 === 1}
              accent={i === 1 ? <InteractiveDemo slug={config.slug} /> : undefined}
            />
          ))}
        </div>
      </section>

      {/* FOUNDERS STRIP */}
      <section>
        <div className="mx-auto max-w-[1180px] px-4 pt-16 md:px-8 md:pt-24">
          <AnimatedSection>
            <div className="mx-auto flex max-w-2xl flex-col items-center gap-4 text-center md:flex-row md:justify-center md:text-left">
              <div className="flex -space-x-3">
                {["Aarav", "Meera", "Rohan", "Diya", "Ishaan"].map((seed) => (
                  <img
                    key={seed}
                    src={`https://api.dicebear.com/9.x/notionists/svg?seed=${seed}&backgroundColor=fce8dc,f5d6c6,ffd7c2,f6c8ae&radius=50`}
                    alt={seed}
                    loading="lazy"
                    className="h-12 w-12 rounded-full border-[1.5px] bg-white"
                    style={{ borderColor: INK }}
                  />
                ))}
              </div>
              <div className="md:ml-2">
                <div className="font-display text-xl font-extrabold md:text-2xl" style={{ color: INK }}>
                  Founders already inside
                </div>
                <div className="mt-1 text-sm text-neutral-600 md:text-base">
                  Building for India's builders since day zero.
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* FINAL CTA */}
      <section>
        <div className="mx-auto max-w-[900px] px-4 pb-8 pt-10 text-center md:px-8 md:pb-10 md:pt-14">

          <AnimatedSection>
            <h2 className="font-display text-4xl font-extrabold md:text-5xl">
              You need to <span style={{ color: CORAL }}>join</span> to use it.
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-base text-neutral-700">
              Everything on VibeCode is builder-only. Sign up in 30 seconds and get access to the full platform.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link
                to="/auth"
                className="inline-flex items-center gap-1.5 rounded-md border-[1.5px] px-6 py-3 text-sm font-extrabold text-white"
                style={{ background: CORAL, borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
              >
                Join VibeCode — free <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/landing"
                className="inline-flex items-center rounded-md border-[1.5px] bg-white px-6 py-3 text-sm font-extrabold"
                style={{ borderColor: INK, color: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
              >
                Back to overview
              </Link>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <Footer />
      <KineticWordmark />
    </div>
  );
}
