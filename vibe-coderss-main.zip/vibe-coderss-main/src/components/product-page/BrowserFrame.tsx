import { useState } from "react";

const INK = "#0F0F0F";
const CORAL = "#E8623A";
const IVORY = "#FAF6F1";

export function BrowserFrame({
  src,
  video,
  alt,
  label,
  aspect = "16/10",
  tilt = false,
  chrome = true,
}: {
  src?: string;
  video?: string;
  alt: string;
  label?: string;
  aspect?: string;
  tilt?: boolean;
  chrome?: boolean;
}) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const showPlaceholder = !video && (!src || failed || !loaded);

  if (!chrome) {
    // Video: render bare — no card, no border, no bg. Just the media + ambient halo.
    if (video) {
      return (
        <div className="relative">
          <div
            aria-hidden
            className="pointer-events-none absolute -inset-10 -z-10 rounded-[40px] opacity-70 blur-3xl"
            style={{ background: `radial-gradient(55% 55% at 50% 50%, ${CORAL}40, transparent 70%)` }}
          />
          <video
            src={video}
            autoPlay
            loop
            muted
            playsInline
            preload="metadata"
            aria-label={alt}
            className="block h-auto w-full"
            style={{ background: "transparent" }}
          />
        </div>
      );
    }

    // Image / placeholder chromeless variant keeps a soft card
    return (
      <div className="relative">
        <div
          aria-hidden
          className="pointer-events-none absolute -inset-6 -z-10 rounded-[32px] opacity-60 blur-2xl"
          style={{ background: `radial-gradient(60% 60% at 50% 50%, ${CORAL}33, transparent 70%)` }}
        />
        <div
          className="relative overflow-hidden rounded-2xl border-[1.5px] bg-white transition-transform"
          style={{
            borderColor: INK,
            boxShadow: `4px 4px 0 0 ${INK}`,
            transform: tilt ? "rotate(-1.2deg)" : undefined,
          }}
        >
          <div
            className="relative w-full"
            style={{ aspectRatio: aspect, background: `linear-gradient(135deg, ${CORAL}14, ${IVORY})` }}
          >
            {src && !failed && (
              <img
                src={src}
                alt={alt}
                loading="lazy"
                onLoad={() => setLoaded(true)}
                onError={() => setFailed(true)}
                className="absolute inset-0 h-full w-full object-cover"
              />
            )}
            {showPlaceholder && (
              <div className="absolute inset-0 grid place-items-center p-6 text-center">
                <div>
                  <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full border-[1.5px] bg-white font-black" style={{ borderColor: INK, color: CORAL, boxShadow: `3px 3px 0 0 ${INK}` }}>
                    📸
                  </div>
                  <div className="text-[11px] font-bold uppercase tracking-wider" style={{ color: INK }}>
                    Screenshot placeholder
                  </div>
                  {label && (
                    <div className="mt-1 max-w-xs text-xs text-neutral-600">{label}</div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }


  return (
    <div
      className="relative overflow-hidden rounded-xl border-[1.5px] bg-white transition-transform"
      style={{
        borderColor: INK,
        boxShadow: `3px 3px 0 0 ${INK}`,
        transform: tilt ? "rotate(-1.2deg)" : undefined,
      }}
    >
      {/* Title bar */}
      <div
        className="flex items-center gap-1.5 border-b-[1.5px] px-3 py-2"
        style={{ borderColor: INK, background: IVORY }}
      >
        <span className="h-2.5 w-2.5 rounded-full border-[1px]" style={{ background: "#FF5F57", borderColor: INK }} />
        <span className="h-2.5 w-2.5 rounded-full border-[1px]" style={{ background: "#FEBC2E", borderColor: INK }} />
        <span className="h-2.5 w-2.5 rounded-full border-[1px]" style={{ background: "#28C840", borderColor: INK }} />
        <div className="mx-auto rounded-md border-[1px] bg-white px-3 py-0.5 text-[10px] font-semibold text-neutral-500" style={{ borderColor: INK }}>
          joinvibecode.xyz
        </div>
      </div>

      {/* Content */}
      <div
        className="relative w-full"
        style={{
          aspectRatio: video ? undefined : aspect,
          background: `linear-gradient(135deg, ${CORAL}14, ${IVORY})`,
        }}
      >
        {video ? (
          <video
            src={video}
            autoPlay
            loop
            muted
            playsInline
            preload="metadata"
            aria-label={alt}
            className="block h-auto w-full"
          />
        ) : src && !failed && (
          <img
            src={src}
            alt={alt}
            loading="lazy"
            onLoad={() => setLoaded(true)}
            onError={() => setFailed(true)}
            className="absolute inset-0 h-full w-full object-cover"
          />
        )}
        {showPlaceholder && (
          <div className="absolute inset-0 grid place-items-center p-6 text-center">
            <div>
              <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full border-[1.5px] bg-white font-black" style={{ borderColor: INK, color: CORAL, boxShadow: `3px 3px 0 0 ${INK}` }}>
                📸
              </div>
              <div className="text-[11px] font-bold uppercase tracking-wider" style={{ color: INK }}>
                Screenshot placeholder
              </div>
              {label && (
                <div className="mt-1 max-w-xs text-xs text-neutral-600">{label}</div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
