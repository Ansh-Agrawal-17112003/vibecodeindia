import { useEffect, useState, type ReactElement } from "react";
import { Sparkles, Heart, MessageCircle, Repeat2, Flame, Award, Users, Send, Briefcase, IndianRupee, Wand2, Star, ArrowRight, Rocket } from "lucide-react";

const INK = "#0F0F0F";
const CORAL = "#E8623A";
const IVORY = "#FAF6F1";

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-2xl border-[1.5px] bg-white p-5 ${className}`}
      style={{ borderColor: INK, boxShadow: `4px 4px 0 0 ${INK}` }}
    >
      {children}
    </div>
  );
}

/* --- Vibe Feed --- */
function VibeFeedDemo() {
  const [likes, setLikes] = useState(23);
  const [pop, setPop] = useState(false);
  useEffect(() => {
    const id = setInterval(() => {
      setLikes((n) => n + 1);
      setPop(true);
      setTimeout(() => setPop(false), 300);
    }, 2200);
    return () => clearInterval(id);
  }, []);
  return (
    <Card className="max-w-md mx-auto">
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 rounded-full border-[1.5px]" style={{ background: CORAL, borderColor: INK }} />
        <div>
          <div className="text-sm font-bold" style={{ color: INK }}>Aarav K.</div>
          <div className="text-xs text-neutral-500">shipped an AI agent · 2m</div>
        </div>
      </div>
      <p className="mt-3 text-sm" style={{ color: INK }}>
        Just shipped a research agent that scrapes + summarizes 50 PDFs in under a minute. Prompt in comments 👇
      </p>
      <div className="mt-4 flex items-center gap-5 text-sm" style={{ color: INK }}>
        <button className="flex items-center gap-1.5 font-semibold" style={{ color: CORAL }}>
          <Heart className={`h-4 w-4 transition-transform ${pop ? "scale-125" : ""}`} fill={CORAL} />
          {likes}
        </button>
        <span className="flex items-center gap-1.5"><MessageCircle className="h-4 w-4" /> 6</span>
        <span className="flex items-center gap-1.5"><Repeat2 className="h-4 w-4" /> 3</span>
      </div>
    </Card>
  );
}

/* --- Builder Profiles --- */
function BuilderProfilesDemo() {
  const [xp, setXp] = useState(0);
  useEffect(() => {
    let n = 0;
    const id = setInterval(() => {
      n = Math.min(n + 3, 78);
      setXp(n);
      if (n >= 78) clearInterval(id);
    }, 40);
    return () => clearInterval(id);
  }, []);
  const badges = [
    { icon: Award, label: "OG" },
    { icon: Flame, label: "7-day" },
    { icon: Sparkles, label: "Top Prompt" },
    { icon: Star, label: "First Ship" },
  ];
  return (
    <Card className="max-w-md mx-auto">
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 rounded-full border-[1.5px]" style={{ background: CORAL, borderColor: INK }} />
        <div className="flex-1">
          <div className="text-sm font-bold" style={{ color: INK }}>Meera S.</div>
          <div className="text-xs text-neutral-500">Level 4 · 780 XP</div>
        </div>
        <span className="flex items-center gap-1 text-xs font-bold" style={{ color: CORAL }}>
          <Flame className="h-4 w-4" fill={CORAL} /> 12
        </span>
      </div>
      <div className="mt-4">
        <div className="mb-1.5 flex justify-between text-xs font-semibold" style={{ color: INK }}>
          <span>XP to Level 5</span><span>{xp}%</span>
        </div>
        <div className="h-2.5 w-full rounded-full border-[1.5px] bg-white overflow-hidden" style={{ borderColor: INK }}>
          <div className="h-full transition-[width] duration-100" style={{ width: `${xp}%`, background: CORAL }} />
        </div>
      </div>
      <div className="mt-4 grid grid-cols-4 gap-2">
        {badges.map(({ icon: I, label }, i) => (
          <div key={label} className="flex flex-col items-center gap-1 rounded-md border-[1.5px] p-2" style={{ borderColor: INK, animation: `pop-in 500ms ${i * 120}ms both` }}>
            <I className="h-4 w-4" style={{ color: CORAL }} />
            <span className="text-[10px] font-semibold" style={{ color: INK }}>{label}</span>
          </div>
        ))}
      </div>
      <style>{`@keyframes pop-in {from{opacity:0;transform:scale(.7)}to{opacity:1;transform:scale(1)}}`}</style>
    </Card>
  );
}

/* --- Communities --- */
function CommunitiesDemo() {
  const msgs = [
    { who: "Rohan", text: "just shipped my RAG demo, feedback?" },
    { who: "Diya", text: "🔥 the prompt in step 2 is chef's kiss" },
    { who: "Ishaan", text: "sharing my n8n workflow — link inside" },
  ];
  const [visible, setVisible] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setVisible((v) => (v + 1) % (msgs.length + 1)), 1600);
    return () => clearInterval(id);
  }, []);
  return (
    <Card className="max-w-md mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-bold" style={{ color: INK }}>
          <Users className="h-4 w-4" /> #langchain-india
        </div>
        <span className="flex items-center gap-1.5 text-xs font-semibold" style={{ color: CORAL }}>
          <span className="h-2 w-2 rounded-full animate-pulse" style={{ background: CORAL }} /> 214 online
        </span>
      </div>
      <div className="mt-4 space-y-2 min-h-[160px]">
        {msgs.slice(0, visible).map((m, i) => (
          <div key={i} className="flex items-start gap-2 rounded-md border-[1.5px] p-2" style={{ borderColor: INK, background: IVORY, animation: "slide-in 300ms both" }}>
            <div className="h-6 w-6 shrink-0 rounded-full border-[1.5px]" style={{ background: CORAL, borderColor: INK }} />
            <div className="text-xs" style={{ color: INK }}>
              <span className="font-bold">{m.who}</span> · <span>{m.text}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-2 rounded-md border-[1.5px] px-3 py-2" style={{ borderColor: INK }}>
        <input className="flex-1 bg-transparent text-xs outline-none" placeholder="Message #langchain-india" readOnly />
        <Send className="h-4 w-4" style={{ color: CORAL }} />
      </div>
      <style>{`@keyframes slide-in {from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}`}</style>
    </Card>
  );
}

/* --- Jobs Board --- */
function JobsBoardDemo() {
  const jobs = [
    { title: "AI Engineer", co: "Stealth Fintech", loc: "Remote · India", pay: "₹28–42 L" },
    { title: "LLM Ops Lead", co: "Y-Combinator SaaS", loc: "Bengaluru", pay: "₹35–55 L" },
    { title: "Prompt Engineer", co: "Content Studio", loc: "Remote", pay: "₹18–26 L" },
  ];
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setIdx((i) => (i + 1) % jobs.length), 2200);
    return () => clearInterval(id);
  }, [jobs.length]);
  const j = jobs[idx];
  return (
    <Card className="max-w-md mx-auto">
      <div className="flex items-center justify-between text-xs font-semibold" style={{ color: INK }}>
        <span className="flex items-center gap-1.5"><Briefcase className="h-4 w-4" /> New role</span>
        <span className="rounded-full px-2 py-0.5 text-[10px] font-bold text-white" style={{ background: CORAL }}>NEW</span>
      </div>
      <div key={idx} style={{ animation: "slide-in 350ms both" }}>
        <div className="mt-3 text-lg font-extrabold" style={{ color: INK }}>{j.title}</div>
        <div className="text-sm text-neutral-500">{j.co}</div>
        <div className="mt-3 flex items-center justify-between text-xs" style={{ color: INK }}>
          <span>{j.loc}</span>
          <span className="flex items-center gap-1 font-bold" style={{ color: CORAL }}>
            <IndianRupee className="h-3.5 w-3.5" />{j.pay}
          </span>
        </div>
      </div>
      <button className="mt-4 w-full rounded-md border-[1.5px] px-3 py-2 text-xs font-bold text-white" style={{ background: INK, borderColor: INK }}>
        Apply with profile →
      </button>
      <style>{`@keyframes slide-in {from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}`}</style>
    </Card>
  );
}

/* --- Prompt Library --- */
function PromptLibraryDemo() {
  const prompts = [
    "You are a senior React reviewer. Roast this component…",
    "Act as an AI recruiter. Summarize this profile in 3 bullets…",
    "Given this PDF, extract every claim with a citation…",
  ];
  const [i, setI] = useState(0);
  const [chars, setChars] = useState(0);
  useEffect(() => {
    const p = prompts[i];
    if (chars < p.length) {
      const t = setTimeout(() => setChars(chars + 1), 25);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => { setChars(0); setI((i + 1) % prompts.length); }, 1400);
    return () => clearTimeout(t);
  }, [chars, i]);
  return (
    <Card className="max-w-md mx-auto">
      <div className="flex items-center gap-2 text-xs font-semibold" style={{ color: INK }}>
        <Wand2 className="h-4 w-4" style={{ color: CORAL }} /> Prompt · {i === 0 ? "code-review" : i === 1 ? "recruiter" : "research"}
      </div>
      <pre className="mt-3 min-h-[110px] whitespace-pre-wrap rounded-md border-[1.5px] p-3 font-mono text-xs" style={{ borderColor: INK, background: IVORY, color: INK }}>
        {prompts[i].slice(0, chars)}<span className="inline-block w-1.5 h-3 align-middle" style={{ background: CORAL, animation: "blink 900ms steps(1) infinite" }} />
      </pre>
      <div className="mt-3 flex gap-2">
        <button className="flex-1 rounded-md border-[1.5px] px-3 py-1.5 text-xs font-bold" style={{ borderColor: INK, color: INK }}>Copy</button>
        <button className="flex-1 rounded-md border-[1.5px] px-3 py-1.5 text-xs font-bold text-white" style={{ background: CORAL, borderColor: INK }}>Fork & remix</button>
      </div>
      <style>{`@keyframes blink {50%{opacity:0}}`}</style>
    </Card>
  );
}

/* --- AI Tools --- */
function AIToolsDemo() {
  const tools = [
    { name: "Cursor", tag: "IDE", stars: 5 },
    { name: "n8n", tag: "Automation", stars: 5 },
    { name: "Groq", tag: "Inference", stars: 4 },
  ];
  return (
    <div className="mx-auto grid max-w-md gap-2">
      {tools.map((t, i) => (
        <div key={t.name} className="flex items-center justify-between rounded-xl border-[1.5px] bg-white p-3" style={{ borderColor: INK, boxShadow: `3px 3px 0 0 ${INK}`, animation: `fade-up 500ms ${i * 120}ms both` }}>
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-md border-[1.5px] font-bold" style={{ borderColor: INK, background: IVORY, color: INK }}>{t.name[0]}</div>
            <div>
              <div className="text-sm font-bold" style={{ color: INK }}>{t.name}</div>
              <div className="text-[11px] text-neutral-500">{t.tag}</div>
            </div>
          </div>
          <div className="flex gap-0.5">
            {Array.from({ length: 5 }).map((_, s) => (
              <Star key={s} className="h-3.5 w-3.5" fill={s < t.stars ? CORAL : "none"} stroke={CORAL} />
            ))}
          </div>
        </div>
      ))}
      <style>{`@keyframes fade-up {from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}`}</style>
    </div>
  );
}

/* --- Workflow Templates --- */
function WorkflowTemplatesDemo() {
  const nodes = [
    { x: 10, y: 40, label: "Trigger" },
    { x: 40, y: 20, label: "Scrape" },
    { x: 40, y: 60, label: "Summarize" },
    { x: 75, y: 40, label: "Notify" },
  ];
  return (
    <Card className="max-w-md mx-auto">
      <div className="flex items-center gap-2 text-xs font-semibold" style={{ color: INK }}>
        <span className="h-2 w-2 rounded-full" style={{ background: CORAL }} /> pdf-summarizer.json
      </div>
      <div className="relative mt-3 h-[180px] rounded-md border-[1.5px]" style={{ borderColor: INK, background: IVORY }}>
        <svg className="absolute inset-0 h-full w-full" viewBox="0 0 100 80" preserveAspectRatio="none">
          <path d="M14 42 L38 22" stroke={INK} strokeWidth="0.6" fill="none" />
          <path d="M14 42 L38 62" stroke={INK} strokeWidth="0.6" fill="none" />
          <path d="M46 22 L73 40" stroke={INK} strokeWidth="0.6" fill="none" />
          <path d="M46 62 L73 42" stroke={INK} strokeWidth="0.6" fill="none" />
          <circle r="1.4" fill={CORAL}>
            <animateMotion dur="3.2s" repeatCount="indefinite" path="M14 42 L38 22 L73 40" />
          </circle>
        </svg>
        {nodes.map((n) => (
          <div key={n.label} className="absolute -translate-x-1/2 -translate-y-1/2 rounded-md border-[1.5px] bg-white px-2 py-1 text-[10px] font-bold" style={{ left: `${n.x}%`, top: `${n.y}%`, borderColor: INK, color: INK, boxShadow: `2px 2px 0 0 ${INK}` }}>
            {n.label}
          </div>
        ))}
      </div>
      <button className="mt-4 w-full rounded-md border-[1.5px] px-3 py-2 text-xs font-bold text-white" style={{ background: CORAL, borderColor: INK }}>
        Fork template →
      </button>
    </Card>
  );
}

/* --- Project Showcase --- */
function ProjectShowcaseDemo() {
  const projects = [
    { title: "RAG Notes", stack: "Next · Pinecone", h: 120 },
    { title: "Agentic CSV", stack: "n8n · Groq", h: 90 },
    { title: "PromptOps", stack: "React · SB", h: 140 },
    { title: "Voice Coach", stack: "Whisper · GPT", h: 100 },
  ];
  return (
    <div className="mx-auto grid max-w-md grid-cols-2 gap-3">
      {projects.map((p, i) => (
        <div key={p.title} className="rounded-xl border-[1.5px] bg-white p-3 transition-transform hover:-translate-y-1" style={{ borderColor: INK, boxShadow: `3px 3px 0 0 ${INK}`, animation: `fade-up 500ms ${i * 100}ms both` }}>
          <div className="mb-2 rounded-md" style={{ height: p.h, background: `linear-gradient(135deg, ${CORAL}, ${IVORY})`, border: `1.5px solid ${INK}` }} />
          <div className="flex items-center gap-1.5 text-[13px] font-bold" style={{ color: INK }}>
            <Rocket className="h-3.5 w-3.5" style={{ color: CORAL }} /> {p.title}
          </div>
          <div className="text-[10px] text-neutral-500">{p.stack} · shipped 2h ago</div>
        </div>
      ))}
      <style>{`@keyframes fade-up {from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}`}</style>
    </div>
  );
}

const REGISTRY: Record<string, () => ReactElement> = {
  "vibe-feed": VibeFeedDemo,
  "builder-profiles": BuilderProfilesDemo,
  "communities": CommunitiesDemo,
  "jobs-board": JobsBoardDemo,
  "prompt-library": PromptLibraryDemo,
  "ai-tools": AIToolsDemo,
  "workflow-templates": WorkflowTemplatesDemo,
  "project-showcase": ProjectShowcaseDemo,
};

export function InteractiveDemo({ slug }: { slug: string }) {
  const C = REGISTRY[slug];
  if (!C) return null;
  return <C />;
}

export { ArrowRight };
