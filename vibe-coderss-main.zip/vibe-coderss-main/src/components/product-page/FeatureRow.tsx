import type { LucideIcon } from "lucide-react";
import { Check } from "lucide-react";
import { AnimatedSection } from "@/components/landing/AnimatedSection";
import { BrowserFrame } from "./BrowserFrame";

const INK = "#0F0F0F";
const CORAL = "#E8623A";

export type FeatureRowData = {
  icon: LucideIcon;
  eyebrow: string;
  title: string;
  body: string;
  bullets: string[];
  image?: string;
  video?: string;
  imageAlt: string;
  imageLabel: string;
};

export function FeatureRow({ data, reverse = false, accent }: { data: FeatureRowData; reverse?: boolean; accent?: React.ReactNode }) {
  const Icon = data.icon;
  return (
    <div className={`grid items-center gap-10 lg:grid-cols-2 lg:gap-16 ${reverse ? "lg:[&>*:first-child]:order-2" : ""}`}>
      <AnimatedSection>
        <div className="mx-auto w-full max-w-[420px] lg:max-w-none">
          <BrowserFrame src={data.image} video={data.video} alt={data.imageAlt} label={data.imageLabel} chrome={!data.video} tilt={!data.video} />
        </div>
        {accent && <div className="mt-6">{accent}</div>}
      </AnimatedSection>
      <AnimatedSection delay={100}>
        <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider" style={{ color: CORAL }}>
          <Icon className="h-3.5 w-3.5" /> {data.eyebrow}
        </span>
        <h3 className="mt-3 font-display text-3xl font-extrabold leading-tight md:text-4xl">{data.title}</h3>
        <p className="mt-4 text-base text-neutral-700 md:text-lg">{data.body}</p>
        <ul className="mt-6 space-y-3">
          {data.bullets.map((b) => (
            <li key={b} className="flex items-start gap-2.5 text-sm md:text-base">
              <span className="mt-0.5 grid h-5 w-5 flex-shrink-0 place-items-center rounded-full border-[1.5px]" style={{ background: CORAL, borderColor: INK }}>
                <Check className="h-3 w-3 text-white" strokeWidth={3} />
              </span>
              <span className="text-neutral-800">{b}</span>
            </li>
          ))}
        </ul>
      </AnimatedSection>
    </div>
  );
}
