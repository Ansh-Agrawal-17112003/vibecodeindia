import { useEffect, useRef, useState } from "react";
import { X, Upload, Loader2, Film, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import {
  captureThumbnail,
  createDraftLecture,
  deleteLecture,
  updateLecture,
  uploadLectureThumbnail,
  uploadLectureVideo,
} from "@/lib/lectures-api";

const MAX_BYTES = 500 * 1024 * 1024; // 500MB
const ALLOWED = ["video/mp4", "video/webm", "video/quicktime"];

export function UploadLectureModal({
  communityId,
  onClose,
  onCreated,
}: {
  communityId: string;
  onClose: () => void;
  onCreated: () => void;
}) {
  const { user } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [tagsInput, setTagsInput] = useState("");
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<"idle" | "uploading" | "thumbnailing" | "publishing" | "done">("idle");
  const inputRef = useRef<HTMLInputElement | null>(null);
  const previewUrl = useRef<string | null>(null);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && phase === "idle" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
      if (previewUrl.current) URL.revokeObjectURL(previewUrl.current);
    };
  }, [onClose, phase]);

  function pickFile(f: File | null) {
    if (!f) return;
    if (!ALLOWED.includes(f.type)) {
      toast.error("Only MP4, WebM or MOV videos are supported");
      return;
    }
    if (f.size > MAX_BYTES) {
      toast.error("Max file size is 500 MB");
      return;
    }
    setFile(f);
    if (!title) setTitle(f.name.replace(/\.[^.]+$/, "").slice(0, 120));
    if (previewUrl.current) URL.revokeObjectURL(previewUrl.current);
    previewUrl.current = URL.createObjectURL(f);
  }

  async function submit() {
    if (!user) { toast.error("Please sign in"); return; }
    if (!file) { toast.error("Pick a video first"); return; }
    if (!title.trim()) { toast.error("Give it a title"); return; }

    let draftId: string | null = null;
    try {
      setPhase("uploading");
      setProgress(5);
      const draft = await createDraftLecture({
        community_id: communityId,
        uploader_id: user.id,
        title: title.trim(),
        description: description.trim() || null,
        tags: tagsInput.split(",").map((s) => s.trim()).filter(Boolean),
      });
      draftId = draft.id;

      const videoPath = await uploadLectureVideo({
        communityId,
        lectureId: draft.id,
        file,
        onProgress: (p) => setProgress(10 + Math.round(p * 0.7)),
      });

      setPhase("thumbnailing");
      setProgress(85);
      let thumbPath: string | null = null;
      let durationSec: number | null = null;
      try {
        const { blob, durationSec: d } = await captureThumbnail(file, 2);
        durationSec = d;
        thumbPath = await uploadLectureThumbnail({
          communityId,
          lectureId: draft.id,
          blob,
        });
      } catch (e) {
        console.warn("thumbnail capture failed", e);
      }

      setPhase("publishing");
      setProgress(95);
      await updateLecture(draft.id, {
        video_url: videoPath,
        thumbnail_url: thumbPath,
        duration_sec: durationSec ?? null,
        is_published: true,
      });

      setPhase("done");
      setProgress(100);
      toast.success("Lecture published — sharing to Vibe feed");
      onCreated();
      onClose();
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || "Upload failed");
      if (draftId) {
        try { await deleteLecture(draftId); } catch { /* noop */ }
      }
      setPhase("idle");
      setProgress(0);
    }
  }

  const busy = phase !== "idle" && phase !== "done";

  return (
    <div
      className="fixed inset-0 z-[80] flex items-end justify-center sm:items-center"
      onClick={() => !busy && onClose()}
    >
      <div className="absolute inset-0 bg-black/55" />
      <div
        className="relative flex max-h-[92vh] w-full max-w-lg flex-col rounded-t-2xl border-[1.5px] border-[#0F0F0F] bg-white sm:rounded-2xl"
        style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b-[1.5px] border-[#0F0F0F]/10 p-4">
          <h3 className="font-display text-lg font-bold">Add a lecture</h3>
          <button
            onClick={onClose}
            disabled={busy}
            className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white disabled:opacity-50"
            aria-label="Close"
          ><X className="h-4 w-4" /></button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {!file ? (
            <button
              onClick={() => inputRef.current?.click()}
              className="flex w-full flex-col items-center gap-2 rounded-xl border-[1.5px] border-dashed border-[#0F0F0F]/40 bg-cream/40 p-8 text-center hover:bg-cream/70"
            >
              <div className="grid h-12 w-12 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white">
                <Upload className="h-5 w-5 text-coral" />
              </div>
              <div className="text-sm font-bold">Choose a video</div>
              <div className="text-[11px] text-muted-foreground">MP4, WebM or MOV · up to 500 MB</div>
            </button>
          ) : (
            <div className="flex gap-3 rounded-xl border-[1.5px] border-[#0F0F0F]/25 bg-cream/30 p-3">
              <div className="grid h-16 w-16 shrink-0 place-items-center rounded-md border border-[#0F0F0F]/20 bg-black text-white">
                <Film className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-bold">{file.name}</div>
                <div className="text-[11px] text-muted-foreground">
                  {(file.size / (1024 * 1024)).toFixed(1)} MB · {file.type.split("/")[1]?.toUpperCase()}
                </div>
                {!busy && (
                  <button
                    onClick={() => { setFile(null); setProgress(0); }}
                    className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-coral"
                  ><Trash2 className="h-3 w-3" /> Remove</button>
                )}
              </div>
            </div>
          )}
          <input
            ref={inputRef}
            type="file"
            accept="video/mp4,video/webm,video/quicktime"
            className="hidden"
            onChange={(e) => { pickFile(e.target.files?.[0] ?? null); e.target.value = ""; }}
          />

          <label className="block">
            <span className="mb-1 block text-xs font-bold uppercase tracking-wide text-[#0F0F0F]/70">Title</span>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value.slice(0, 120))}
              placeholder="What is this lecture about?"
              className="w-full rounded-lg border-[1.5px] border-[#0F0F0F]/30 bg-white px-3 py-2 text-sm outline-none focus:border-coral"
              disabled={busy}
            />
          </label>

          <label className="block">
            <span className="mb-1 block text-xs font-bold uppercase tracking-wide text-[#0F0F0F]/70">Description</span>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value.slice(0, 2000))}
              rows={3}
              placeholder="What will members learn?"
              className="w-full resize-none rounded-lg border-[1.5px] border-[#0F0F0F]/30 bg-white px-3 py-2 text-sm outline-none focus:border-coral"
              disabled={busy}
            />
          </label>

          <label className="block">
            <span className="mb-1 block text-xs font-bold uppercase tracking-wide text-[#0F0F0F]/70">Tags (comma separated)</span>
            <input
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="prompts, n8n, launch"
              className="w-full rounded-lg border-[1.5px] border-[#0F0F0F]/30 bg-white px-3 py-2 text-sm outline-none focus:border-coral"
              disabled={busy}
            />
          </label>

          {busy && (
            <div className="rounded-lg border-[1.5px] border-[#0F0F0F]/15 bg-white p-3">
              <div className="mb-1 flex items-center justify-between text-[11px] font-bold">
                <span>
                  {phase === "uploading" && "Uploading video…"}
                  {phase === "thumbnailing" && "Capturing thumbnail…"}
                  {phase === "publishing" && "Publishing…"}
                </span>
                <span>{progress}%</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-cream">
                <div className="h-full bg-coral transition-[width]" style={{ width: `${progress}%` }} />
              </div>
            </div>
          )}

          <p className="text-[11px] text-muted-foreground">
            Publishing also shares this lecture to the Vibe feed automatically.
          </p>
        </div>

        <div className="flex items-center justify-end gap-2 border-t-[1.5px] border-[#0F0F0F]/10 p-4">
          <button
            onClick={onClose}
            disabled={busy}
            className="rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-4 py-2 text-sm font-bold disabled:opacity-50"
            style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
          >Cancel</button>
          <button
            onClick={submit}
            disabled={busy || !file || !title.trim()}
            className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-4 py-2 text-sm font-bold text-white disabled:opacity-60"
            style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
          >
            {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {busy ? "Publishing…" : "Publish lecture"}
          </button>
        </div>
      </div>
    </div>
  );
}
