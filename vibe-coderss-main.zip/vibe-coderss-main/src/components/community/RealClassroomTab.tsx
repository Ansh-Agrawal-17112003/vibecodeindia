import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Loader2, Plus, Upload } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { listLectures, getSignedUrl, type Lecture } from "@/lib/lectures-api";
import { UploadLectureModal } from "@/components/community/UploadLectureModal";

function fmtDuration(sec: number | null | undefined) {
  if (!sec || sec < 1) return "";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function LectureThumb({ lecture }: { lecture: Lecture }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    if (!lecture.thumbnail_url) { setSrc(null); return; }
    getSignedUrl(lecture.thumbnail_url, 3600).then((u) => { if (alive) setSrc(u); }).catch(() => {});
    return () => { alive = false; };
  }, [lecture.thumbnail_url]);
  if (!src) {
    return (
      <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, #E8623A, #F5A623)" }} />
    );
  }
  return <img src={src} alt="" className="absolute inset-0 h-full w-full object-cover" />;
}

export function RealClassroomTab({
  slug,
  communityId,
  canUpload,
}: {
  slug: string;
  communityId: string;
  canUpload: boolean;
}) {
  const [lectures, setLectures] = useState<Lecture[] | null>(null);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [filter, setFilter] = useState<string>("All");

  const load = async () => {
    try {
      const rows = await listLectures(communityId);
      setLectures(rows);
    } catch (e: any) {
      console.warn("[classroom] load failed", e);
      setLectures([]);
    }
  };

  useEffect(() => {
    load();
    const channel = supabase
      .channel(`lectures:${communityId}:${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "community_lectures", filter: `community_id=eq.${communityId}` },
        () => load(),
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [communityId]);

  const tagOptions = useMemo(() => {
    const set = new Set<string>();
    (lectures ?? []).forEach((l) => l.tags?.forEach((t) => set.add(t)));
    return ["All", ...Array.from(set).slice(0, 8)];
  }, [lectures]);

  const filtered = filter === "All"
    ? (lectures ?? [])
    : (lectures ?? []).filter((l) => l.tags?.includes(filter));

  return (
    <section className="p-3 lg:p-0">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-display text-xl font-extrabold">Classroom</h2>
        {canUpload && (
          <button
            onClick={() => setUploadOpen(true)}
            className="flex items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1.5 text-xs font-extrabold text-white"
            style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
          >
            <Plus className="h-3.5 w-3.5" /> Add lecture
          </button>
        )}
      </div>

      {tagOptions.length > 1 && (
        <div className="mb-3 flex gap-1.5 overflow-x-auto">
          {tagOptions.map((t) => (
            <button
              key={t}
              onClick={() => setFilter(t)}
              className={`shrink-0 rounded-full border-[1.5px] px-3 py-1 text-xs font-bold ${filter === t ? "border-[#0F0F0F] bg-coral text-white" : "border-[#0F0F0F]/40 bg-white"}`}
            >{t === "All" ? "All" : `#${t}`}</button>
          ))}
        </div>
      )}

      {lectures === null && (
        <div className="grid place-items-center py-12 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      )}

      {lectures !== null && filtered.length === 0 && (
        <div className="rounded-xl border-[1.5px] border-dashed border-[#0F0F0F]/30 bg-white p-8 text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-cream">
            <Upload className="h-5 w-5 text-coral" />
          </div>
          <div className="mt-3 text-sm font-bold">No lectures yet</div>
          <div className="mt-1 text-[12px] text-muted-foreground">
            {canUpload ? "Be the first to upload one for this community." : "Check back soon — lectures will appear here as they're published."}
          </div>
          {canUpload && (
            <button
              onClick={() => setUploadOpen(true)}
              className="mt-4 inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-4 py-2 text-xs font-extrabold text-white"
              style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
            >
              <Plus className="h-3.5 w-3.5" /> Add the first lecture
            </button>
          )}
        </div>
      )}

      {filtered.length > 0 && (
        <div className="grid gap-3 sm:grid-cols-2">
          {filtered.map((l) => (
            <Link
              key={l.id}
              to="/communities/$slug/watch/$id"
              params={{ slug, id: l.id }}
              className="group text-left rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-3 hover:bg-cream/40"
              style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
            >
              <div className="relative aspect-video overflow-hidden rounded-md border border-[#0F0F0F]/20 bg-black">
                <LectureThumb lecture={l} />
                <div className="absolute inset-0 grid place-items-center bg-black/10 opacity-90 group-hover:opacity-100">
                  <div className="grid h-12 w-12 place-items-center rounded-full bg-black/60 text-white">▶</div>
                </div>
                {l.duration_sec ? (
                  <span className="absolute bottom-2 right-2 rounded bg-black/70 px-1.5 py-0.5 text-[10px] font-bold text-white">
                    {fmtDuration(l.duration_sec)}
                  </span>
                ) : null}
              </div>
              <div className="mt-2 flex items-start justify-between gap-2">
                <h3 className="text-sm font-extrabold leading-snug">{l.title}</h3>
              </div>
              {l.description && (
                <p className="mt-1 line-clamp-2 text-[12px] text-muted-foreground">{l.description}</p>
              )}
              <div className="mt-2 flex items-center justify-between text-[11px] font-bold">
                <span className="text-muted-foreground">👁 {l.view_count.toLocaleString()} · {timeAgo(l.created_at)}</span>
                <span className="rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2 py-1 text-[11px] font-extrabold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>Watch →</span>
              </div>
              {l.tags?.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {l.tags.slice(0, 3).map((t) => (
                    <span key={t} className="rounded bg-cream px-1.5 py-0.5 text-[10px] font-bold text-foreground/70">#{t}</span>
                  ))}
                </div>
              )}
            </Link>
          ))}
        </div>
      )}

      {uploadOpen && (
        <UploadLectureModal
          communityId={communityId}
          onClose={() => setUploadOpen(false)}
          onCreated={() => { load(); toast.success("Lecture is live"); }}
        />
      )}
    </section>
  );
}
