import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/solutions/indie-builders")({
  head: () => ({
    meta: [
      { title: "For Indie Builders · VibeCode" },
      { name: "description", content: "The fastest way for solo AI builders in India to launch, get feedback, and find collaborators — without shouting into the void." },
      { property: "og:title", content: "For Indie Builders · VibeCode" },
      { property: "og:description", content: "The fastest way for solo AI builders in India to launch, get feedback, and find collaborators — without shouting into the void." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/solutions/indie-builders" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/solutions/indie-builders" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="For Indie Builders"
      breadcrumb={[{"label":"Solutions","to":"/"}]}
      title="Ship in public. Find your crew."
      intro="The fastest way for solo AI builders in India to launch, get feedback, and find collaborators — without shouting into the void."
      toc={[{"id":"why","label":"Why indie builders pick VibeCode"},{"id":"loop","label":"The indie shipping loop"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="why" title="Why indie builders pick VibeCode"><NotionFeatureGrid items={[{"title":"Loud discoverability","description":"Every post lands on the Vibe Feed where 120k+ builders scroll daily."},{"title":"Zero setup portfolio","description":"Your profile auto-grows every time you ship — projects, prompts, workflows."},{"title":"Real feedback fast","description":"Comments from people who actually build with the same stack."},{"title":"Warm inbound","description":"Founders and hirers DM you when your work fits."}]} /></NotionSection>
      <NotionSection id="loop" title="The indie shipping loop"><NotionList items={["Post a build → get seen by the algorithm within minutes","Collect reactions, replies, and saves from real builders","Convert saves into DMs, collabs, and paid gigs","Level up your XP, streaks, and badges as you keep shipping"]} /></NotionSection>
      <NotionCallout emoji="🚀" tone="coral">Free forever for builders. You never pay to post, follow, apply, or DM.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Do I need to be experienced?" a="No. Half the community is shipping their first AI project. Post rough drafts — the feed rewards momentum." />
          <NotionToggle q="How do I get discovered?" a="Post consistently, use tags, and drop screenshots/videos. The feed algorithm boosts high-signal posts within the first hour." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
