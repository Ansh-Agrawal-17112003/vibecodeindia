import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { Shell } from "@/components/site/Shell";
import { ServiceCard } from "@/components/cards/ServiceCard";
import { FilterSidebar, FilterGroup, FilterCheckbox } from "@/components/site/FilterSidebar";
import { AutocompleteInput } from "@/components/site/AutocompleteInput";
import { StatsStrip } from "@/components/site/StatsStrip";
import { allServices, AI_TOOLS } from "@/lib/mock-data";
import { useLiveTable, mapService } from "@/lib/entity-live";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: 'Services Marketplace · VibeCode' },
      { name: "description", content: 'Hire vetted Indian AI builders — from Lovable devs to n8n automation experts and prompt engineers.' },
      { property: "og:title", content: 'Services Marketplace · VibeCode' },
      { property: "og:description", content: 'Hire vetted Indian AI builders — from Lovable devs to n8n automation experts and prompt engineers.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/services' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Services Marketplace · VibeCode' },
      { name: "twitter:description", content: 'Hire vetted Indian AI builders — from Lovable devs to n8n automation experts and prompt engineers.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/services' }],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const [q, setQ] = useState("");
  const dbRows = useLiveTable("services", mapService);
  const list = useMemo(() => {
    const seen = new Set(dbRows.map((s) => s.id));
    return [...dbRows, ...allServices().filter((s) => !seen.has(s.id))];
  }, [dbRows]);
  const suggestions = useMemo(
    () => list.flatMap((s) => [s.title, s.category, ...s.tags]),
    [list],
  );
  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return list;
    return list.filter(
      (s) =>
        s.title.toLowerCase().includes(term) ||
        s.category.toLowerCase().includes(term) ||
        s.tags.some((t) => t.toLowerCase().includes(term)),
    );
  }, [q, list]);

  return (
    <Shell>
      <div className="container-page py-5 sm:py-8">
        <div className="mb-6 text-center sm:text-left">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground sm:text-xs">Marketplace</div>
          <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight sm:text-3xl md:text-4xl">Hire AI Builders for Services</h1>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">Vetted services from India's top vibe coders.</p>
        </div>

        <div className="hidden sm:block">
          <StatsStrip items={[
            { label: "Services", value: allServices().length },
            { label: "Vetted Sellers", value: 320, suffix: "+" },
            { label: "Orders Delivered", value: 4800, suffix: "+" },
            { label: "Avg Rating", value: 9, prefix: "4." },
          ]} />
        </div>


        {/* Mobile-only search bar (filters hidden) */}
        <div className="mb-5 lg:hidden">
          <div className="card-flat flex items-center gap-2 p-2">
            <Search className="ml-2 h-4 w-4 text-muted-foreground" />
            <AutocompleteInput
              value={q}
              onChange={setQ}
              placeholder="Search services, categories, tags..."
              typewriter={["Build me an MVP in 7 days...", "AI chatbot for my store...", "Automate my sales pipeline...", "Design a SaaS landing page...", "Fine-tune GPT for support..."]}
              className="h-9 w-full bg-transparent text-sm outline-none"
              suggestions={suggestions}
            />
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <div className="sticky top-24 hidden h-[calc(100vh-7rem)] overflow-y-auto lg:block">
            <FilterSidebar>
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-[18px] z-10 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <AutocompleteInput
                  value={q}
                  onChange={setQ}
                  placeholder="Search services..."
                  typewriter={["Build me an MVP in 7 days...", "AI chatbot for my store...", "Automate my sales pipeline...", "SaaS landing page...", "Fine-tune GPT for support..."]}
                  wrapperClassName="relative w-full"
                  className="h-9 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-background pl-9 pr-3 text-sm outline-none"
                  suggestions={suggestions}
                />
              </div>
              <FilterGroup title="Category">
                {["Development", "Automation", "Design", "Consulting", "Agency"].map((c) => (
                  <FilterCheckbox key={c} label={c} />
                ))}
              </FilterGroup>
              <FilterGroup title="Budget">
                {["Under ₹10K", "₹10K – ₹50K", "₹50K – ₹2L", "₹2L+"].map((b) => (
                  <FilterCheckbox key={b} label={b} />
                ))}
              </FilterGroup>
              <FilterGroup title="Delivery Time">
                {["1 day", "3 days", "1 week", "2+ weeks"].map((d) => (
                  <FilterCheckbox key={d} label={d} />
                ))}
              </FilterGroup>
              <FilterGroup title="Tools Used">
                {AI_TOOLS.slice(0, 6).map((t) => (
                  <FilterCheckbox key={t} label={t} />
                ))}
              </FilterGroup>
              <FilterCheckbox label="Verified Only" />
            </FilterSidebar>
          </div>

          <div>
            <div className="card-flat mb-5 hidden px-4 py-3 text-sm sm:block">
              <span className="font-bold text-foreground">{filtered.length}</span>{" "}
              <span className="text-muted-foreground">services available</span>
            </div>

            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {filtered.map((s) => (
                <ServiceCard key={s.id} s={s} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}
