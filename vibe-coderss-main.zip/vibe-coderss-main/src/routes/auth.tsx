import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

import { useAuth } from "@/hooks/useAuth";
import { VibeCodeLogo } from "@/components/site/Logo";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: 'Sign in · VibeCode' },
      { name: "description", content: "Sign in or create your VibeCode account — India's largest community for AI builders." },
      { property: "og:title", content: 'Sign in · VibeCode' },
      { property: "og:description", content: "Sign in or create your VibeCode account — India's largest community for AI builders." },
      { property: "og:url", content: 'https://joinvibecode.xyz/auth' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Sign in · VibeCode' },
      { name: "twitter:description", content: "Sign in or create your VibeCode account — India's largest community for AI builders." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/auth' }],
  }),
  component: AuthPage,
});

function AuthPage() {
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const { session, profile, loading, isAdmin, refreshProfile } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Pick up prefill from landing RegistrationCard (leave in storage for onboarding).
    try {
      const raw = sessionStorage.getItem("vc_signup_prefill");
      if (raw) {
        const p = JSON.parse(raw);
        if (p?.email) setEmail(p.email);
        if (p?.display_name) setName(p.display_name);
        setMode("signup");
      }
    } catch {}
    // Honor ?mode=signup search param.
    if (typeof window !== "undefined" && window.location.search.includes("mode=signup")) {
      setMode("signup");
    }
  }, []);

  useEffect(() => {
    if (loading || !session) return;
    // Wait for the profile (which carries role) to load so admins land on /admin,
    // not /vibe, right after signing in.
    if (!profile) return;
    const dest = isAdmin ? "/admin" : "/vibe";
    navigate({ to: dest, replace: true });
  }, [session, profile, loading, isAdmin, navigate]);

  const pwRules = {
    length: password.length >= 8,
    upper: /[A-Z]/.test(password),
    lower: /[a-z]/.test(password),
    number: /\d/.test(password),
    special: /[_!@#$%^&*(),.?":{}|<>\-+=~`[\]\\/;']/.test(password),
  };
  const pwValid = Object.values(pwRules).every(Boolean);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (mode === "signup" && !pwValid) {
      toast.error("Password needs 8+ chars with uppercase, lowercase, number & special character (e.g. _).");
      return;
    }
    setBusy(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin, data: { display_name: name } },
        });
        if (error) throw error;
        if (!data.session) {
          toast.success("Account created — check your email to confirm.");
        } else {
          toast.success("Account created — welcome!");
          navigate({ to: "/vibe" });
        }
      } else if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Welcome back!");
        // Redirect handled by the effect above once profile role loads;
        // fall back to /vibe if role fetch is slow.
        await refreshProfile();
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        toast.success("Check your email for a reset link.");
        setMode("signin");
      }
    } catch (err: any) {
      toast.error(err?.message ?? "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/auth-callback?next=/vibe` },
    });
    if (error) toast.error(error.message);
  }

  return (
    <div className="grid min-h-screen place-items-center bg-background px-6 py-10">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-6 flex items-center justify-center"><VibeCodeLogo /></Link>
        <div className="rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-6" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}>
          <h1 className="font-display text-2xl font-extrabold">
            {mode === "signup" ? "Join VibeCode" : mode === "forgot" ? "Reset password" : "Welcome back"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {mode === "signup" ? "Build, ship, get hired." : mode === "forgot" ? "We'll email you a reset link." : "Sign in to continue."}
          </p>

          {mode !== "forgot" && (
            <button onClick={google} className="mt-5 flex h-11 w-full items-center justify-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card text-sm font-bold transition hover:-translate-y-0.5" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <span className="inline-block h-4 w-4 rounded-sm bg-gradient-to-br from-red-500 via-yellow-400 to-blue-500" />
              Continue with Google
            </button>
          )}

          {mode !== "forgot" && (
            <div className="my-4 flex items-center gap-3 text-xs text-muted-foreground">
              <div className="h-px flex-1 bg-border" /> OR <div className="h-px flex-1 bg-border" />
            </div>
          )}

          <form onSubmit={submit} className="space-y-3">
            {mode === "signup" && (
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" required />
            )}
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" required />
            {mode !== "forgot" && (
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" minLength={8} className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" required />
            )}
            {mode === "signup" && password.length > 0 && (
              <ul className="grid grid-cols-2 gap-1 text-[11px] text-muted-foreground">
                {[
                  ["length", "8+ characters"],
                  ["upper", "Uppercase (A-Z)"],
                  ["lower", "Lowercase (a-z)"],
                  ["number", "Number (0-9)"],
                  ["special", "Special (_ ! @ #)"],
                ].map(([k, label]) => (
                  <li key={k} className={pwRules[k as keyof typeof pwRules] ? "text-green-600" : ""}>
                    {pwRules[k as keyof typeof pwRules] ? "✓" : "•"} {label}
                  </li>
                ))}
              </ul>
            )}
            <button disabled={busy} className="btn-coral h-11 w-full">
              {busy ? "Please wait…" : mode === "signup" ? "Create account →" : mode === "forgot" ? "Send reset link" : "Sign in →"}
            </button>
          </form>

          <div className="mt-4 flex items-center justify-between text-xs">
            {mode === "signin" ? (
              <>
                <button onClick={() => setMode("forgot")} className="text-muted-foreground hover:text-foreground">Forgot password?</button>
                <button onClick={() => setMode("signup")} className="font-bold text-coral hover:underline">Create account</button>
              </>
            ) : (
              <button onClick={() => setMode("signin")} className="font-bold text-coral hover:underline">← Back to sign in</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
