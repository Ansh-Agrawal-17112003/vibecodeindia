import { createFileRoute, Link } from "@tanstack/react-router";
import { AlertTriangle, ShieldCheck, ScrollText, Scale, Copyright, Users, CreditCard, Ban, Mail, FileWarning, Gavel, Handshake, Eye } from "lucide-react";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: 'Terms & Conditions — VibeCode' },
      { name: "description", content: "The rules of using VibeCode — India's largest community for AI builders." },
      { property: "og:title", content: 'Terms & Conditions — VibeCode' },
      { property: "og:description", content: "The rules of using VibeCode — India's largest community for AI builders." },
      { property: "og:url", content: 'https://joinvibecode.xyz/terms' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Terms & Conditions — VibeCode' },
      { name: "twitter:description", content: "The rules of using VibeCode — India's largest community for AI builders." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/terms' }],
  }),
  component: TermsPage,
});

const EFFECTIVE = "July 7, 2026";

function TermsPage() {
  return (
    <main className="min-h-screen bg-[#FAF7F0] text-[#0F0F0F]">
      {/* Header */}
      <header className="border-b border-[#0F0F0F]/10 bg-white">
        <div className="mx-auto max-w-[900px] px-6 py-14 md:py-20">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.16em] text-[#0F0F0F]/60 transition hover:text-[#E8623A]"
          >
            ← Back to VibeCode
          </Link>
          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-[#0F0F0F]/15 bg-[#FAF7F0] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-[#0F0F0F]/70">
            <ScrollText className="h-3.5 w-3.5" />
            Legal — Terms of Service
          </div>
          <h1
            className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
            style={{ fontSize: "clamp(36px, 6vw, 64px)" }}
          >
            Terms & Conditions
          </h1>
          <p className="mt-4 max-w-[640px] text-[16px] leading-[1.7] text-[#0F0F0F]/70 md:text-[17px]">
            Please read these Terms carefully before using VibeCode. By creating an account, browsing profiles, hiring
            a builder, or listing your services, you agree to be bound by everything below.
          </p>
          <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-[13px] text-[#0F0F0F]/60">
            <span>
              <b>Effective:</b> {EFFECTIVE}
            </span>
            <span>
              <b>Governing law:</b> India
            </span>
            <span>
              <b>Operator:</b> VibeCode (joinvibecode.xyz)
            </span>
          </div>
        </div>
      </header>

      {/* Prominent marketplace disclaimer */}
      <section className="border-b border-[#0F0F0F]/10 bg-[#FFF3EE]">
        <div className="mx-auto max-w-[900px] px-6 py-8">
          <div className="flex items-start gap-4 rounded-2xl border-2 border-[#E8623A] bg-white p-5 md:p-6">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border-[1.5px] border-[#0F0F0F] bg-[#E8623A] text-white">
              <AlertTriangle className="h-5 w-5" />
            </div>
            <div>
              <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#E8623A]">
                Read this first — marketplace disclaimer
              </div>
              <p className="mt-2 text-[15px] leading-[1.65] text-[#0F0F0F] md:text-[16px]">
                <b>VibeCode is a marketplace</b> that connects hirers with AI builders, freelancers, communities, and
                template creators. <b>We are not a party</b> to any agreement, transaction, project, or payment made
                between users. We <b>do not guarantee</b> the quality, legality, safety, or outcome of any work, and{" "}
                <b>we cannot guarantee that every user is genuine</b> or free from fraud. Like Fiverr, Upwork, or any
                open marketplace, some listings may be misleading or malicious.{" "}
                <b>Always vet the person you work with, start with a small paid milestone, verify deliverables, and
                never transfer large sums or share credentials before you have confirmed the counterparty is real and
                capable.</b>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* TOC */}
      <nav aria-label="Table of contents" className="border-b border-[#0F0F0F]/10 bg-white">
        <div className="mx-auto max-w-[900px] px-6 py-8">
          <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#0F0F0F]/50">On this page</div>
          <ol className="mt-4 grid gap-2 text-[14px] md:grid-cols-2">
            {SECTIONS.map((s, i) => (
              <li key={s.id}>
                <a
                  href={`#${s.id}`}
                  className="inline-flex items-baseline gap-2 text-[#0F0F0F]/80 transition hover:text-[#E8623A]"
                >
                  <span className="font-mono text-[11px] text-[#0F0F0F]/40">{String(i + 1).padStart(2, "0")}</span>
                  {s.title}
                </a>
              </li>
            ))}
          </ol>
        </div>
      </nav>

      {/* Body */}
      <article className="mx-auto max-w-[820px] px-6 py-14 md:py-20">
        <Section id="acceptance" icon={<Handshake />} n={1} title="Acceptance of these Terms">
          <p>
            These Terms & Conditions ("<b>Terms</b>") form a binding legal agreement between you ("<b>you</b>", "
            <b>user</b>") and VibeCode ("<b>VibeCode</b>", "<b>we</b>", "<b>us</b>"). By creating an account, accessing
            joinvibecode.xyz, or using any part of the platform (the "<b>Service</b>"), you confirm that you have read,
            understood, and agree to be bound by these Terms and by our Privacy Policy and Cookie Policy.
          </p>
          <p>
            If you do not agree, you must not use the Service. Continued use after any amendment constitutes acceptance
            of the amended Terms.
          </p>
        </Section>

        <Section id="eligibility" icon={<Users />} n={2} title="Eligibility & account">
          <ul>
            <li>You must be at least <b>16 years old</b> to create an account. Users under 18 must have consent from a parent or legal guardian.</li>
            <li>You agree to provide accurate, complete, and current information about yourself and your work.</li>
            <li>You are responsible for keeping your login credentials secure. All activity under your account is your responsibility.</li>
            <li>One person = one primary account. Fake profiles, duplicate accounts, or bot-generated identities are prohibited and may be removed without notice.</li>
            <li>We may refuse, suspend, or terminate any account at our sole discretion, including where we reasonably suspect fraud, impersonation, abuse, or a breach of these Terms.</li>
          </ul>
        </Section>

        <Section id="nature" icon={<ShieldCheck />} n={3} title="Nature of the platform (marketplace)">
          <p>
            VibeCode operates a <b>neutral marketplace</b>. We connect three types of users:
          </p>
          <ul>
            <li><b>Builders / Freelancers</b> — individuals offering AI-native services, code, templates, workflows, or full builds.</li>
            <li><b>Hirers / Founders / Companies</b> — individuals or organisations looking to hire, license, or commission work.</li>
            <li><b>Communities & Creators</b> — group hosts, template authors, and educators.</li>
          </ul>
          <p>
            When a hirer engages a builder, or when a buyer purchases a template, community access, or job listing,{" "}
            <b>the resulting contract is directly between those users</b>. VibeCode is not a party to it. VibeCode does
            not employ builders, is not an agency, and is not a broker of professional services.
          </p>
          <Callout tone="warn" icon={<FileWarning className="h-4 w-4" />}>
            We do not verify the identity, qualifications, references, tax status, or work-authorisation of any user
            beyond basic email confirmation and, where offered, optional badges. Verification badges are indicative,
            not a guarantee.
          </Callout>
        </Section>

        <Section id="no-guarantee" icon={<AlertTriangle />} n={4} title="No guarantee against scams or fraud">
          <p>
            Because VibeCode is an open marketplace with a very large number of independent users, we cannot and do not
            guarantee that every listing, message, quote, project, portfolio, or payment request is genuine, accurate,
            lawful, or safe. Fraud, scams, phishing, impersonation, plagiarised portfolios, and low-quality delivery
            can occur on any marketplace, and they can occur on VibeCode.
          </p>
          <p><b>Your responsibility as a user:</b></p>
          <ul>
            <li><b>Verify before you pay.</b> Ask for a live video call, a screen share, and a small paid milestone (e.g. 5–10% of the total) before releasing any meaningful amount.</li>
            <li><b>Test the work.</b> Ask the builder to reproduce a small feature live, or to make a trivial edit to a portfolio project on-camera. Real builders can do this in minutes.</li>
            <li><b>Never share secrets.</b> Never share passwords, OTPs, private keys, seed phrases, service-account credentials, or full production database URLs.</li>
            <li><b>Use traceable payments.</b> Prefer platform-supported payments, escrow, or reputable rails (UPI collect requests, Razorpay, Stripe, verified bank transfer). Avoid crypto to unknown wallets and irreversible gift-card payments.</li>
            <li><b>Read reviews carefully.</b> Look for detail, dates, and consistency. A wall of five-star one-line reviews on a brand-new profile is a red flag.</li>
            <li><b>Trust your gut.</b> If the deal feels too cheap, too fast, or too pushy — walk away and report.</li>
          </ul>
          <Callout tone="danger" icon={<Ban className="h-4 w-4" />}>
            <b>To the maximum extent permitted by law, VibeCode is not liable for any loss, damage, delay, data leak,
            reputational harm, missed deadline, or financial loss that results from your dealings with another user.</b>
            You transact with other users at your own risk. Where you suspect fraud, report it at{" "}
            <a href="mailto:trust@joinvibecode.xyz" className="text-[#E8623A] underline">trust@joinvibecode.xyz</a> and
            also file a complaint with your local police / cyber-crime authority.
          </Callout>
        </Section>

        <Section id="conduct" icon={<Scale />} n={5} title="Acceptable use & user conduct">
          <p>You agree that you will not, and will not attempt to:</p>
          <ul>
            <li>Post content that is unlawful, defamatory, harassing, hateful, sexually explicit, or infringes anyone's rights;</li>
            <li>Impersonate any person, organisation, employer, or team, or misrepresent your affiliation, skills, or credentials;</li>
            <li>Post plagiarised or AI-fabricated portfolios claiming work that is not yours;</li>
            <li>Solicit users to transact off-platform in order to evade fees, safety review, or dispute handling, in a way that harms the counterparty;</li>
            <li>Use the Service to distribute malware, run phishing, scrape data at scale, or run automated agents that bypass rate limits;</li>
            <li>Reverse engineer, decompile, or otherwise attempt to derive source code of non-public parts of the Service;</li>
            <li>Interfere with, disrupt, or place unreasonable load on the Service, its APIs, or its underlying infrastructure;</li>
            <li>Use the Service for money laundering, sanctions evasion, tax evasion, or any activity prohibited by Indian law or the law of the user's jurisdiction.</li>
          </ul>
          <p>Violations may result in content removal, feature restriction, temporary suspension, permanent ban, forfeiture of unpaid balances, and referral to law enforcement.</p>
        </Section>

        <Section id="payments" icon={<CreditCard />} n={6} title="Payments, fees & taxes">
          <ul>
            <li><b>Free tier & Pro:</b> Some features are free, others require an active Pro subscription. Prices, benefits, and limits are shown at checkout and may change with 30 days' notice.</li>
            <li><b>Marketplace transactions:</b> When platform-managed payments are used, VibeCode may charge a service fee, a payment-processing fee, and applicable taxes. Fees are shown before you confirm.</li>
            <li><b>Off-platform transactions:</b> When you agree to pay a builder outside of VibeCode's payment rails, VibeCode is not involved, has no visibility into the transaction, and offers no dispute handling. This is entirely at your own risk.</li>
            <li><b>Refunds:</b> Refund eligibility depends on the specific product (subscription, template, community access, hired service). Where a refund is available, it will be processed to the original payment method within a reasonable time.</li>
            <li><b>Chargebacks:</b> Abusive chargebacks after receiving delivered work may result in account suspension and legal recovery.</li>
            <li><b>Taxes:</b> You are responsible for reporting and paying any income tax, GST, VAT, or other tax obligations on income you earn through VibeCode. VibeCode may collect and remit indirect taxes where legally required.</li>
          </ul>
        </Section>

        <Section id="ip" icon={<Copyright />} n={7} title="Intellectual property & copyright">
          <p>
            <b>Your content:</b> You retain ownership of the code, designs, text, images, videos, and other content
            that you upload or create ("<b>User Content</b>"). By posting User Content, you grant VibeCode a worldwide,
            non-exclusive, royalty-free, sublicensable licence to host, store, reproduce, adapt, publicly display, and
            distribute that content strictly for the purpose of operating, promoting, and improving the Service. You
            may revoke this licence for a specific piece of content by deleting it, subject to reasonable technical
            retention (backups, caches, legal holds).
          </p>
          <p>
            <b>Our content:</b> The VibeCode name, logo, brand marks, product design, UI, source code, documentation,
            and platform copy are owned by VibeCode and protected by copyright, trademark, and other laws. Nothing in
            these Terms grants you any right to use our marks without our prior written consent.
          </p>
          <p>
            <b>Third-party content:</b> You must have the rights to everything you upload. Do not upload copyrighted
            code, images, videos, music, or writing that you do not own or have permission to use.
          </p>
          <p>
            <b>Copyright complaints (DMCA-style notice):</b> If you believe content on VibeCode infringes your
            copyright, email{" "}
            <a href="mailto:copyright@joinvibecode.xyz" className="text-[#E8623A] underline">copyright@joinvibecode.xyz</a>{" "}
            with: (a) identification of the copyrighted work, (b) the exact URL of the allegedly infringing content,
            (c) your contact information, (d) a statement made in good faith that the use is not authorised, and (e) a
            statement, under penalty of perjury, that the information is accurate and you are the rights-holder or
            authorised to act on their behalf. We will review and, where appropriate, take down the content and notify
            the poster, who may submit a counter-notice.
          </p>
        </Section>

        <Section id="ai" icon={<ScrollText />} n={8} title="AI-generated content & tools">
          <p>
            VibeCode surfaces work built with AI tools (Lovable, Cursor, Claude, n8n, GPT-4o, Gemini, and others) and
            may itself offer AI-assisted features (matchmaking, ranking, writing assistance). AI outputs can be
            inaccurate, biased, incomplete, or infringe rights. You are responsible for reviewing every AI-generated
            output you publish, sell, or deliver, and for complying with the terms of the underlying model providers.
          </p>
          <p>
            Do not present AI-generated portfolio pieces as human-only work unless clearly labelled, and do not use AI
            to fabricate reviews, ratings, or engagement.
          </p>
        </Section>

        <Section id="thirdparty" icon={<Handshake />} n={9} title="Third-party services & links">
          <p>
            The Service integrates with or links to third-party services (payment providers, OAuth providers, email
            infrastructure, chat/streaming providers, analytics, hosting, and others). Your use of those services is
            governed by their own terms and privacy policies. We do not control and are not responsible for third-party
            services, and their availability is not guaranteed.
          </p>
        </Section>

        <Section id="privacy" icon={<Eye />} n={10} title="Privacy, cookies & data">
          <p>
            We collect and process personal data as described in our{" "}
            <Link to="/privacy-policy" className="text-[#E8623A] underline">Privacy Policy</Link>{" "}
            and use cookies and similar technologies as described in our{" "}
            <Link to="/p/$slug" params={{ slug: "cookies" }} className="text-[#E8623A] underline">Cookie Policy</Link>.
            By using the Service you consent to that processing. You have the right to access, correct, export, or
            delete your personal data, subject to legal exceptions, by writing to{" "}
            <a href="mailto:privacy@joinvibecode.xyz" className="text-[#E8623A] underline">privacy@joinvibecode.xyz</a>.
          </p>
        </Section>

        <Section id="disclaimer" icon={<AlertTriangle />} n={11} title="Disclaimer of warranties">
          <p>
            The Service is provided <b>"as is" and "as available"</b>, without warranty of any kind, express or
            implied, including any implied warranty of merchantability, fitness for a particular purpose,
            non-infringement, uptime, accuracy, or that the Service will be uninterrupted, secure, or error-free. Any
            reliance on content, ratings, recommendations, matches, or search results is at your own risk.
          </p>
        </Section>

        <Section id="liability" icon={<Ban />} n={12} title="Limitation of liability">
          <p>
            To the maximum extent permitted by applicable law, VibeCode, its officers, employees, and affiliates will{" "}
            <b>not</b> be liable for any indirect, incidental, special, consequential, exemplary, or punitive damages,
            or for any loss of profits, revenue, data, goodwill, or business, arising out of or in connection with your
            use of the Service or your dealings with any other user.
          </p>
          <p>
            Our aggregate liability to you for all claims arising out of or relating to the Service in any 12-month
            period will not exceed the greater of (a) the total amount you paid to VibeCode in that 12-month period, or
            (b) INR 5,000.
          </p>
        </Section>

        <Section id="indemnity" icon={<Gavel />} n={13} title="Indemnity">
          <p>
            You agree to indemnify and hold harmless VibeCode from and against any claim, demand, loss, damage, cost,
            or expense (including reasonable legal fees) arising out of: (a) your User Content, (b) your use of the
            Service, (c) your breach of these Terms, (d) your violation of any law or the rights of another party, or
            (e) any dispute between you and another user of the Service.
          </p>
        </Section>

        <Section id="termination" icon={<Ban />} n={14} title="Suspension & termination">
          <p>
            You may stop using the Service and delete your account at any time from your profile settings, or by
            writing to <a href="mailto:support@joinvibecode.xyz" className="text-[#E8623A] underline">support@joinvibecode.xyz</a>.
          </p>
          <p>
            We may suspend or terminate your account, remove content, or restrict features immediately and without
            notice if we reasonably believe you have breached these Terms, put other users at risk, or exposed us to
            legal or reputational harm. On termination, the provisions that by their nature should survive (IP,
            disclaimers, limitation of liability, indemnity, governing law) will survive.
          </p>
        </Section>

        <Section id="law" icon={<Gavel />} n={15} title="Governing law & disputes">
          <p>
            These Terms are governed by the laws of India, without regard to conflict-of-law rules. Subject to any
            non-waivable statutory right, the courts at <b>Bengaluru, Karnataka, India</b> have exclusive jurisdiction
            over any dispute arising out of or in connection with these Terms or the Service. Before starting formal
            proceedings, you agree to attempt to resolve the dispute informally by contacting{" "}
            <a href="mailto:legal@joinvibecode.xyz" className="text-[#E8623A] underline">legal@joinvibecode.xyz</a>.
          </p>
        </Section>

        <Section id="changes" icon={<ScrollText />} n={16} title="Changes to these Terms">
          <p>
            We may update these Terms from time to time. When we do, we will change the "Effective" date at the top and,
            for material changes, notify you by email or by an in-product notice. Your continued use of the Service
            after the changes take effect constitutes acceptance of the updated Terms. If you do not agree, please stop
            using the Service and delete your account.
          </p>
        </Section>

        <Section id="contact" icon={<Mail />} n={17} title="Contact">
          <p>Questions about these Terms? We're happy to help.</p>
          <ul>
            <li><b>General:</b> <a href="mailto:support@joinvibecode.xyz" className="text-[#E8623A] underline">support@joinvibecode.xyz</a></li>
            <li><b>Trust & safety / report a scam:</b> <a href="mailto:trust@joinvibecode.xyz" className="text-[#E8623A] underline">trust@joinvibecode.xyz</a></li>
            <li><b>Copyright:</b> <a href="mailto:copyright@joinvibecode.xyz" className="text-[#E8623A] underline">copyright@joinvibecode.xyz</a></li>
            <li><b>Privacy:</b> <a href="mailto:privacy@joinvibecode.xyz" className="text-[#E8623A] underline">privacy@joinvibecode.xyz</a></li>
            <li><b>Legal:</b> <a href="mailto:legal@joinvibecode.xyz" className="text-[#E8623A] underline">legal@joinvibecode.xyz</a></li>
          </ul>
        </Section>

        <div className="mt-16 flex flex-col items-start gap-4 rounded-2xl border border-[#0F0F0F]/10 bg-white p-6 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#0F0F0F]/50">Copyright</div>
            <div className="mt-1 text-[14px] text-[#0F0F0F]/80">
              © {new Date().getFullYear()} VibeCode. All rights reserved. "VibeCode", the VibeCode logo, and related
              marks are trademarks of VibeCode.
            </div>
          </div>
          <Link
            to="/"
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] px-5 py-2.5 text-[13px] font-extrabold uppercase tracking-[0.12em] text-white transition-transform active:scale-95"
            style={{ boxShadow: "2px 2px 0 0 #E8623A" }}
          >
            Back to VibeCode →
          </Link>
        </div>
      </article>
    </main>
  );
}

/* ---------- helpers ---------- */
const SECTIONS = [
  { id: "acceptance", title: "Acceptance of these Terms" },
  { id: "eligibility", title: "Eligibility & account" },
  { id: "nature", title: "Nature of the platform (marketplace)" },
  { id: "no-guarantee", title: "No guarantee against scams or fraud" },
  { id: "conduct", title: "Acceptable use & user conduct" },
  { id: "payments", title: "Payments, fees & taxes" },
  { id: "ip", title: "Intellectual property & copyright" },
  { id: "ai", title: "AI-generated content & tools" },
  { id: "thirdparty", title: "Third-party services & links" },
  { id: "privacy", title: "Privacy, cookies & data" },
  { id: "disclaimer", title: "Disclaimer of warranties" },
  { id: "liability", title: "Limitation of liability" },
  { id: "indemnity", title: "Indemnity" },
  { id: "termination", title: "Suspension & termination" },
  { id: "law", title: "Governing law & disputes" },
  { id: "changes", title: "Changes to these Terms" },
  { id: "contact", title: "Contact" },
];

function Section({
  id,
  n,
  title,
  icon,
  children,
}: {
  id: string;
  n: number;
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24 border-b border-[#0F0F0F]/10 py-10 last:border-none">
      <div className="flex items-center gap-3">
        <span
          className="grid h-10 w-10 place-items-center rounded-xl border-[1.5px] border-[#0F0F0F] bg-white text-[#0F0F0F]"
          style={{ boxShadow: "1.5px 1.5px 0 0 #0F0F0F" }}
        >
          <span className="[&_svg]:h-4 [&_svg]:w-4">{icon}</span>
        </span>
        <div className="font-mono text-[11px] font-bold uppercase tracking-[0.16em] text-[#0F0F0F]/50">
          Section {String(n).padStart(2, "0")}
        </div>
      </div>
      <h2 className="mt-3 font-display text-[24px] font-extrabold leading-tight md:text-[30px]">{title}</h2>
      <div className="prose-terms mt-4 space-y-4 text-[15px] leading-[1.75] text-[#0F0F0F]/80 md:text-[16px] [&_ul]:list-disc [&_ul]:space-y-2 [&_ul]:pl-6 [&_a]:font-semibold">
        {children}
      </div>
    </section>
  );
}

function Callout({
  tone,
  icon,
  children,
}: {
  tone: "warn" | "danger" | "info";
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  const styles =
    tone === "danger"
      ? { border: "#E8623A", bg: "#FFF3EE", fg: "#7a1e00" }
      : tone === "warn"
        ? { border: "#F5A623", bg: "#FFF7E8", fg: "#5a3a00" }
        : { border: "#0F0F0F", bg: "#FAF7F0", fg: "#0F0F0F" };
  return (
    <div
      className="my-3 flex items-start gap-3 rounded-xl border-[1.5px] p-4 text-[14.5px] leading-[1.65]"
      style={{ borderColor: styles.border, background: styles.bg, color: styles.fg }}
    >
      <span className="mt-0.5 shrink-0">{icon}</span>
      <div>{children}</div>
    </div>
  );
}
