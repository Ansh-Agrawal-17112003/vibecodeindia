import { createClient } from "@supabase/supabase-js";
import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { BLOGS } from "@/lib/blog-data";

const BASE_URL = "https://joinvibecode.xyz";

interface SitemapEntry {
  path: string;
  lastmod?: string;
  changefreq?: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
  priority?: string;
}

const STATIC_PUBLIC_PATHS: SitemapEntry[] = [
  { path: "/", changefreq: "weekly", priority: "1.0" },
  { path: "/landing", changefreq: "weekly", priority: "0.8" },
  { path: "/early-access", changefreq: "weekly", priority: "0.8" },
  { path: "/founders-wall", changefreq: "weekly", priority: "0.7" },
  { path: "/explore", changefreq: "weekly", priority: "0.7" },
  { path: "/jobs", changefreq: "daily", priority: "0.8" },
  { path: "/projects", changefreq: "daily", priority: "0.8" },
  { path: "/services", changefreq: "daily", priority: "0.8" },
  { path: "/tools", changefreq: "daily", priority: "0.8" },
  { path: "/templates", changefreq: "daily", priority: "0.8" },
  { path: "/prompts", changefreq: "daily", priority: "0.8" },
  { path: "/workflows", changefreq: "daily", priority: "0.8" },
  { path: "/communities", changefreq: "daily", priority: "0.8" },
  { path: "/vibe", changefreq: "daily", priority: "0.7" },
  { path: "/leaderboard", changefreq: "weekly", priority: "0.6" },
  { path: "/pricing", changefreq: "weekly", priority: "0.8" },
  { path: "/blog", changefreq: "weekly", priority: "0.8" },
  { path: "/testimonials", changefreq: "weekly", priority: "0.6" },
  { path: "/search", changefreq: "weekly", priority: "0.6" },
  { path: "/terms", changefreq: "monthly", priority: "0.4" },
  { path: "/privacy-policy", changefreq: "monthly", priority: "0.4" },
];

const STATIC_PAGE_SLUGS = [
  "about",
  "manifesto",
  "press",
  "brand",
  "playbook",
  "api",
  "status",
  "tutorials",
  "blog",
  "changelog",
  "help",
  "guide",
  "privacy",
  "terms",
  "coc",
  "cookies",
  "dpa",
];

function escapeXml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function toUrlXml(entry: SitemapEntry) {
  const loc = `${BASE_URL}${escapeXml(entry.path)}`;
  const lines = [`  <url>`, `    <loc>${loc}</loc>`];
  if (entry.lastmod) lines.push(`    <lastmod>${entry.lastmod}</lastmod>`);
  if (entry.changefreq) lines.push(`    <changefreq>${entry.changefreq}</changefreq>`);
  if (entry.priority) lines.push(`    <priority>${entry.priority}</priority>`);
  lines.push(`  </url>`);
  return lines.join("\n");
}

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries: SitemapEntry[] = [...STATIC_PUBLIC_PATHS];

        // Static /p pages
        for (const slug of STATIC_PAGE_SLUGS) {
          entries.push({ path: `/p/${slug}`, changefreq: "monthly", priority: "0.5" });
        }

        // Static blog posts
        for (const blog of BLOGS) {
          entries.push({ path: `/blog/${blog.slug}`, changefreq: "monthly", priority: "0.6" });
        }

        try {
          const supabase = createClient(
            process.env.SUPABASE_URL!,
            process.env.SUPABASE_PUBLISHABLE_KEY!,
          );

          const [
            jobs,
            projects,
            services,
            communities,
            tools,
            templates,
            workflows,
            prompts,
            profiles,
          ] = await Promise.all([
            supabase.from("jobs").select("id").eq("status", "active"),
            supabase.from("projects").select("id"),
            supabase.from("services").select("id"),
            supabase.from("communities").select("id, slug").eq("status", "approved"),
            supabase.from("ai_tools").select("id, slug"),
            supabase.from("templates").select("id, slug"),
            supabase.from("workflows").select("id"),
            supabase.from("prompts").select("id"),
            supabase.from("profiles").select("id, username").not("username", "is", null),
          ]);

          if (jobs.data) {
            for (const j of jobs.data) entries.push({ path: `/jobs/${j.id}`, changefreq: "weekly", priority: "0.6" });
          }
          if (projects.data) {
            for (const p of projects.data) entries.push({ path: `/projects/${p.id}`, changefreq: "weekly", priority: "0.6" });
          }
          if (services.data) {
            for (const s of services.data) entries.push({ path: `/services/${s.id}`, changefreq: "weekly", priority: "0.6" });
          }
          if (communities.data) {
            for (const c of communities.data) entries.push({ path: `/communities/${c.slug}`, changefreq: "weekly", priority: "0.6" });
          }
          if (tools.data) {
            for (const t of tools.data) entries.push({ path: `/tools/${t.slug}`, changefreq: "weekly", priority: "0.6" });
          }
          if (templates.data) {
            for (const t of templates.data) entries.push({ path: `/templates/${t.slug}`, changefreq: "weekly", priority: "0.6" });
          }
          if (workflows.data) {
            for (const w of workflows.data) entries.push({ path: `/workflows/${w.id}`, changefreq: "weekly", priority: "0.6" });
          }
          if (prompts.data) {
            for (const p of prompts.data) entries.push({ path: `/prompts/${p.id}`, changefreq: "weekly", priority: "0.6" });
          }
          if (profiles.data) {
            for (const p of profiles.data) entries.push({ path: `/u/${p.username}`, changefreq: "weekly", priority: "0.5" });
          }
        } catch (err) {
          // If DB is unavailable, still serve the static sitemap.
          console.error("[sitemap] failed to fetch dynamic entries", err);
        }

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...entries.map(toUrlXml),
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml; charset=utf-8",
            "Cache-Control": "public, max-age=3600, s-maxage=3600",
          },
        });
      },
    },
  },
});
