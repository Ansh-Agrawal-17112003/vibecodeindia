import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/developers/api")({
  head: () => ({
    meta: [
      { title: "API Docs · VibeCode" },
      { name: "description", content: "REST endpoints for the Vibe Feed, jobs, prompts, and builder profiles. OAuth-based, versioned, rate-limited." },
      { property: "og:title", content: "API Docs · VibeCode" },
      { property: "og:description", content: "REST endpoints for the Vibe Feed, jobs, prompts, and builder profiles. OAuth-based, versioned, rate-limited." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/developers/api" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/developers/api" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="API Docs"
      breadcrumb={[{"label":"Developers","to":"/"}]}
      title="Query the platform."
      intro="REST endpoints for the Vibe Feed, jobs, prompts, and builder profiles. OAuth-based, versioned, rate-limited."
      toc={[{"id":"endpoints","label":"Core endpoints"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="endpoints" title="Core endpoints"><NotionFeatureGrid items={[{"title":"GET /feed","description":"Paginated Vibe Feed with filters by tag, user, and time."},{"title":"GET /jobs","description":"Job listings with stack, city, and remote filters."},{"title":"GET /prompts","description":"Prompt library with model, score, and category filters."},{"title":"GET /profile/:username","description":"Builder profile with projects, XP, and streaks."}]} /></NotionSection>
      <NotionCallout emoji="🔑" tone="cream">API access is free during beta. Rate limit: 100 requests/minute per key.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Do you support webhooks?" a="Yes — see the Webhooks page for the full event catalog." />
          <NotionToggle q="Is there a GraphQL endpoint?" a="Not yet. REST only for v1. GraphQL is on the roadmap for Q2." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
