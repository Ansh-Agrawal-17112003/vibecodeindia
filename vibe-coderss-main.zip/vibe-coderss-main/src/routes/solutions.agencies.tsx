import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/solutions/agencies")({
  head: () => ({
    meta: [
      { title: "For Agencies · VibeCode" },
      { name: "description", content: "A single place to find vetted AI builders, ship case studies, and turn your studio into a magnet for inbound." },
      { property: "og:title", content: "For Agencies · VibeCode" },
      { property: "og:description", content: "A single place to find vetted AI builders, ship case studies, and turn your studio into a magnet for inbound." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/solutions/agencies" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/solutions/agencies" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="For Agencies"
      breadcrumb={[{"label":"Solutions","to":"/"}]}
      title="Source talent. Showcase work. Win clients."
      intro="A single place to find vetted AI builders, ship case studies, and turn your studio into a magnet for inbound."
      toc={[{"id":"stack","label":"What agencies use"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="stack" title="What agencies use"><NotionFeatureGrid items={[{"title":"Talent search","description":"Filter builders by stack, city, and availability in seconds."},{"title":"Studio profile","description":"Show your team, wins, and open roles on one branded page."},{"title":"Case-study feed","description":"Every shipped project = a public case study."},{"title":"Inbound inbox","description":"Founders DM you directly with briefs and budgets."}]} /></NotionSection>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Can multiple teammates use one account?" a="Yes — Business plan includes 3 seats. Talk to us for more." />
          <NotionToggle q="Do you take a cut of client deals?" a="No. VibeCode is a discovery layer, never a middleman." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
