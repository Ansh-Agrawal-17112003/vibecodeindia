import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/developers/sdks")({
  head: () => ({
    meta: [
      { title: "SDKs & Libraries · VibeCode" },
      { name: "description", content: "Official SDKs with typed clients, retry logic, and streaming support baked in." },
      { property: "og:title", content: "SDKs & Libraries · VibeCode" },
      { property: "og:description", content: "Official SDKs with typed clients, retry logic, and streaming support baked in." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/developers/sdks" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/developers/sdks" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="SDKs & Libraries"
      breadcrumb={[{"label":"Developers","to":"/"}]}
      title="TypeScript. Python. More coming."
      intro="Official SDKs with typed clients, retry logic, and streaming support baked in."
      toc={[{"id":"sdks","label":"What is shipped"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="sdks" title="What is shipped"><NotionFeatureGrid items={[{"title":"vibecode-js","description":"TypeScript client for Node and browser. Zero config."},{"title":"vibecode-py","description":"Async Python client with type hints."},{"title":"vibecode-go","description":"Coming Q2. Idiomatic Go bindings."},{"title":"CLI","description":"Post from your terminal. Ship without leaving your editor."}]} /></NotionSection>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Where is the source?" a="Every SDK is open source on GitHub — links on the API docs page." />
          <NotionToggle q="Can I contribute?" a="Yes. PRs welcome. We ship a release every Friday." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
