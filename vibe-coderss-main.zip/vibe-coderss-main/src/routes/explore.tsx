import { createFileRoute } from "@tanstack/react-router";
import { Search, X, Users } from "lucide-react";
import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Shell } from "@/components/site/Shell";
import { BuilderCard } from "@/components/cards/BuilderCard";
import { AutocompleteInput } from "@/components/site/AutocompleteInput";
import { allBuilders, AI_TOOLS, INDUSTRIES, LOCATIONS, type Builder } from "@/lib/mock-data";
import { listOgMembers, ogToBuilder } from "@/lib/og-members-api";

type SearchSchema = { category?: string; q?: string; mode?: string };

export const Route = createFileRoute("/explore")({
  validateSearch: (s: Record<string, unknown>): SearchSchema => ({
    category: typeof s.category === "string" ? s.category : undefined,
    q: typeof s.q === "string" ? s.q : undefined,
    mode: typeof s.mode === "string" ? s.mode : undefined,
  }),
  head: () => ({
    meta: [
      { title: 'Explore Builders · VibeCode' },
      { name: "description", content: 'Search 120,000+ Indian AI builders by tool, city, industry and availability.' },
      { property: "og:title", content: 'Explore Builders · VibeCode' },
      { property: "og:description", content: 'Search 120,000+ Indian AI builders by tool, city, industry and availability.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/explore' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Explore Builders · VibeCode' },
      { name: "twitter:description", content: 'Search 120,000+ Indian AI builders by tool, city, industry and availability.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/explore' }],
  }),
  component: Explore,
});

// Map browse-by-category names to filter dimensions
const CATEGORY_MAP: Record<string, { skills?: string[]; tools?: string[]; industries?: string[]; types?: string[] }> = {
  "AI Agents": { skills: ["RAG", "Prompt Engineering"], tools: ["Claude", "GPT-4"] },
  "Web Apps": { skills: ["Full-stack", "UI/UX"], tools: ["Lovable", "Cursor"] },
  "Automation": { skills: ["Automation"], tools: ["n8n", "Make"] },
  "SaaS": { industries: ["SaaS"] },
  "Mobile Apps": { skills: ["Full-stack"] },
  "Open Source": { skills: ["Open Source"] },
  "No Code": { tools: ["Lovable", "Bolt", "n8n"] },
  "Design": { skills: ["Design", "UI/UX", "Brand"] },
};

const TYPES = ["Freelancer", "Agency", "Student", "Founder"] as const;
const EXP = ["Beginner", "Intermediate", "Expert"] as const;

function toggle<T>(arr: T[], v: T): T[] { return arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]; }

function Explore() {
  const { category, q: urlQ, mode } = Route.useSearch();
  const realOnly = mode === "real";
  const navigate = Route.useNavigate();

  const { data: ogMembers = [] } = useQuery({
    queryKey: ["og-members-explore"],
    queryFn: () => listOgMembers(50),
    staleTime: 60_000,
  });
  const ogBuilders: Builder[] = useMemo(() => ogMembers.map(ogToBuilder), [ogMembers]);

  const [sort, setSort] = useState("Trending");
  const [q, setQ] = useState(urlQ ?? "");
  const [industries, setIndustries] = useState<string[]>([]);
  const [tools, setTools] = useState<string[]>([]);
  const [types, setTypes] = useState<string[]>([]);
  const [locations, setLocations] = useState<string[]>([]);
  const [experience, setExperience] = useState<string[]>([]);
  const [availability, setAvailability] = useState<"All" | "Available">("All");
  const [verified, setVerified] = useState(false);
  const [maxRate, setMaxRate] = useState(10000);

  const catFilter = category ? CATEGORY_MAP[category] : undefined;

  const builderSuggestions = useMemo(
    () => allBuilders().flatMap((b) => [b.name, b.title, ...b.skills, ...b.tools]),
    [],
  );


  const filtered = useMemo(() => {
    // Real-only mode: show ONLY the actual OG founding members (real users).
    // Default mode: OG members first (real, non-demo), followed by mock builders.
    let list: Builder[] = realOnly ? [...ogBuilders] : [...ogBuilders, ...allBuilders()];
    const term = q.trim().toLowerCase();
    if (term) list = list.filter((b) => b.name.toLowerCase().includes(term) || b.title.toLowerCase().includes(term) || b.bio.toLowerCase().includes(term) || b.skills.some((s) => s.toLowerCase().includes(term)) || b.tools.some((t) => t.toLowerCase().includes(term)));
    if (industries.length) list = list.filter((b) => b.industry.some((i) => industries.includes(i)));
    if (tools.length) list = list.filter((b) => b.tools.some((t) => tools.includes(t)));
    if (types.length) list = list.filter((b) => types.includes(b.type));
    if (locations.length) list = list.filter((b) => locations.includes(b.location));
    if (experience.length) list = list.filter((b) => experience.includes(b.experience));
    if (availability === "Available") list = list.filter((b) => b.available);
    if (verified) list = list.filter((b) => b.verified);
    list = list.filter((b) => b.hourlyRate <= maxRate);
    if (catFilter && !realOnly) {
      list = list.filter((b) => {
        const okSkill = !catFilter.skills?.length || b.skills.some((s) => catFilter.skills!.includes(s));
        const okTool = !catFilter.tools?.length || b.tools.some((t) => catFilter.tools!.includes(t));
        const okInd = !catFilter.industries?.length || b.industry.some((i) => catFilter.industries!.includes(i));
        const okType = !catFilter.types?.length || catFilter.types!.includes(b.type);
        return okSkill && okTool && okInd && okType;
      });
    }
    // Keep OG members pinned on top in default view; sort mock section only.
    const ogHead = list.filter((b) => b.id.startsWith("og-"));
    let rest = list.filter((b) => !b.id.startsWith("og-"));
    if (sort === "Top Rated") rest.sort((a, b) => b.rating - a.rating);
    else if (sort === "Newest") rest.sort((a, b) => Number(b.id) - Number(a.id));
    else rest.sort((a, b) => b.followers - a.followers);
    return [...ogHead, ...rest];
  }, [q, industries, tools, types, locations, experience, availability, verified, maxRate, catFilter, sort, ogBuilders, realOnly]);


  const clearAll = () => { setQ(""); setIndustries([]); setTools([]); setTypes([]); setLocations([]); setExperience([]); setAvailability("All"); setVerified(false); setMaxRate(10000); navigate({ search: {}, replace: true }); };

  return (
    <Shell>
      <div className="container-page py-5 sm:py-8">
        <div className="mb-4 flex flex-wrap items-end justify-center gap-3 text-center sm:mb-6 sm:justify-between sm:text-left">
          <div className="w-full sm:w-auto">
            <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground sm:text-xs">Directory</div>
            <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight sm:text-3xl md:text-4xl">
              {realOnly ? "Real Builders on VibeCode" : "Explore Builders"}
            </h1>
            <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
              {realOnly
                ? `${filtered.length} verified OG founding members`
                : `${filtered.length} vibe coders match your filters`}.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => navigate({ search: (p: SearchSchema) => ({ ...p, mode: realOnly ? undefined : "real" }), replace: true })}
              className={`inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1.5 text-xs font-bold transition ${realOnly ? "bg-coral text-white" : "bg-white text-foreground hover:bg-cream"}`}
              style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
            >
              <Users className="h-3.5 w-3.5" />
              {realOnly ? "Showing real users" : "Real users only"}
            </button>
            {category && (
              <div className="hidden sm:flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-4 py-1.5 text-xs font-bold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                Category: {category}
                <button onClick={() => navigate({ search: (p: SearchSchema) => ({ ...p, category: undefined }), replace: true })} aria-label="clear"><X className="h-3.5 w-3.5" /></button>
              </div>
            )}
          </div>
        </div>



        {/* Mobile-only search bar (filters hidden) */}
        <div className="mb-5 lg:hidden">
          <div className="card-flat flex items-center gap-2 p-2">
            <Search className="ml-2 h-4 w-4 text-muted-foreground" />
            <AutocompleteInput
              value={q}
              onChange={setQ}
              placeholder="Search builders, skills, tools..."
              typewriter={["Full-stack + LangChain...", "n8n automation expert...", "Prompt engineer...", "Designer who ships MVPs...", "Indie hacker from Bengaluru..."]}
              className="h-9 w-full bg-transparent text-sm outline-none"
              suggestions={builderSuggestions}
            />
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <div className="hidden lg:block">
            <FilterSidebarWithClear onClear={clearAll}>
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-[18px] z-10 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <AutocompleteInput
                  value={q}
                  onChange={setQ}
                  placeholder="Search builders..."
                  typewriter={["Full-stack + LangChain...", "n8n expert...", "Prompt engineer...", "Designer who ships...", "Indie hacker..."]}
                  wrapperClassName="relative w-full"
                  className="h-9 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-background pl-9 pr-3 text-sm outline-none"
                  suggestions={builderSuggestions}
                />
              </div>
              <Group title="Industry">{INDUSTRIES.map((i) => <Check key={i} label={i} checked={industries.includes(i)} onChange={() => setIndustries((p) => toggle(p, i))} />)}</Group>
              <Group title="AI Tools Used">{AI_TOOLS.slice(0, 8).map((t) => <Check key={t} label={t} checked={tools.includes(t)} onChange={() => setTools((p) => toggle(p, t))} />)}</Group>
              <Group title="Availability">
                {(["All", "Available"] as const).map((a) => (
                  <label key={a} className="flex cursor-pointer items-center gap-2 text-sm"><input type="radio" name="av" checked={availability === a} onChange={() => setAvailability(a)} className="accent-coral" /> {a === "Available" ? "Available Now" : "All"}</label>
                ))}
              </Group>
              <Group title="Builder Type">{TYPES.map((t) => <Check key={t} label={t} checked={types.includes(t)} onChange={() => setTypes((p) => toggle(p, t))} />)}</Group>
              <Group title="Location">{LOCATIONS.map((l) => <Check key={l} label={l} checked={locations.includes(l)} onChange={() => setLocations((p) => toggle(p, l))} />)}</Group>
              <Group title="Experience">{EXP.map((l) => <Check key={l} label={l} checked={experience.includes(l)} onChange={() => setExperience((p) => toggle(p, l))} />)}</Group>
              <Group title={`Max Hourly Rate: ₹${maxRate.toLocaleString()}`}>
                <input type="range" min={500} max={10000} step={500} value={maxRate} onChange={(e) => setMaxRate(Number(e.target.value))} className="w-full accent-coral" />
              </Group>
              <div className="border-t-[1.5px] border-[#0F0F0F] pt-4">
                <Check label="Verified Only" checked={verified} onChange={() => setVerified((v) => !v)} />
              </div>
            </FilterSidebarWithClear>
          </div>


          <div>
            <div className="card-flat mb-5 hidden items-center justify-between p-3 sm:flex">
              <div className="text-sm"><span className="font-bold text-foreground">{filtered.length}</span> <span className="text-muted-foreground">builders found</span></div>
              <div className="flex items-center gap-1">
                {["Trending", "Newest", "Top Rated"].map((s) => (
                  <button key={s} onClick={() => setSort(s)} className={`rounded-md px-3 py-1.5 text-xs font-bold transition ${sort === s ? "bg-coral text-white" : "text-muted-foreground hover:text-foreground"}`}>{s}</button>
                ))}
              </div>
            </div>

            {filtered.length ? (
              <div className="grid gap-4 sm:gap-5 md:grid-cols-2 xl:grid-cols-3">{filtered.map((b) => <BuilderCard key={b.id} b={b} />)}</div>
            ) : (
              <div className="card-editorial p-12 text-center"><div className="text-2xl">🤷</div><p className="mt-2 text-sm text-muted-foreground">No builders match. Try clearing some filters.</p></div>
            )}
          </div>
        </div>
      </div>
    </Shell>
  );
}

function FilterSidebarWithClear({ children, onClear }: { children: React.ReactNode; onClear: () => void }) {
  return (
    <aside className="card-editorial sticky top-32 h-fit p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-display text-base font-bold">Filters</h3>
        <button onClick={onClear} className="text-xs font-bold text-coral hover:underline">Clear all</button>
      </div>
      <div className="space-y-5">{children}</div>
    </aside>
  );
}
function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return <div><div className="mb-2 text-xs font-bold uppercase tracking-wider text-foreground">{title}</div><div className="space-y-1.5">{children}</div></div>;
}
function Check({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return <label className="flex cursor-pointer items-center gap-2 text-sm text-foreground/80 hover:text-foreground"><input type="checkbox" checked={checked} onChange={onChange} className="h-3.5 w-3.5 accent-coral" /><span className="flex-1">{label}</span></label>;
}
