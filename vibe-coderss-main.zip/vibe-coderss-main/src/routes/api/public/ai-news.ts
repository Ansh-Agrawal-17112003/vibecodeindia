import { createFileRoute } from "@tanstack/react-router";

// Server-side cache to be friendly to the upstream feed even under 10s polling.
let cache: { at: number; body: string } | null = null;
const TTL_MS = 30_000;
const FEED_URL =
  "https://news.google.com/rss/search?q=artificial+intelligence+OR+%22AI%22&hl=en-US&gl=US&ceid=US:en";

type Item = {
  title: string;
  link: string;
  source: string | null;
  publishedAt: string | null;
  snippet: string | null;
};

function pick(xml: string, tag: string): string | null {
  const m = xml.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, "i"));
  if (!m) return null;
  return m[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").trim();
}

function stripHtml(s: string): string {
  return s.replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();
}

function parseRss(xml: string): Item[] {
  const items: Item[] = [];
  const re = /<item>([\s\S]*?)<\/item>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    const chunk = m[1];
    const title = pick(chunk, "title") ?? "";
    const link = pick(chunk, "link") ?? "";
    const pubDate = pick(chunk, "pubDate");
    const source = pick(chunk, "source");
    const desc = pick(chunk, "description");
    if (!title || !link) continue;
    items.push({
      title: stripHtml(title),
      link,
      source: source ? stripHtml(source) : null,
      publishedAt: pubDate ? new Date(pubDate).toISOString() : null,
      snippet: desc ? stripHtml(desc).slice(0, 220) : null,
    });
    if (items.length >= 25) break;
  }
  return items;
}

async function fetchFeed(): Promise<string> {
  const now = Date.now();
  if (cache && now - cache.at < TTL_MS) return cache.body;
  try {
    const res = await fetch(FEED_URL, {
      headers: { "user-agent": "VibeCoderIndia/1.0 (+https://vibecoderindia.lovable.app)" },
    });
    if (!res.ok) throw new Error(`upstream ${res.status}`);
    const xml = await res.text();
    const items = parseRss(xml);
    const body = JSON.stringify({ items, fetchedAt: new Date().toISOString() });
    cache = { at: now, body };
    return body;
  } catch (err) {
    if (cache) return cache.body; // serve stale on failure
    return JSON.stringify({ items: [], fetchedAt: new Date().toISOString(), error: String(err) });
  }
}

export const Route = createFileRoute("/api/public/ai-news")({
  server: {
    handlers: {
      GET: async () => {
        const body = await fetchFeed();
        return new Response(body, {
          headers: {
            "content-type": "application/json; charset=utf-8",
            "cache-control": "public, max-age=10, s-maxage=30",
          },
        });
      },
    },
  },
});
