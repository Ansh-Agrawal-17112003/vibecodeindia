import { createFileRoute } from "@tanstack/react-router";

/**
 * Drains public.mirror_outbox into the external Supabase project.
 * Called every 30s by pg_cron (see migrations). Also callable manually
 * with the shared MIRROR_CRON_SECRET header for backfills.
 *
 * Auth: requires header `x-mirror-secret: <MIRROR_CRON_SECRET>`.
 */

const BATCH_SIZE = 200;
const MAX_ATTEMPTS = 8;

// Tables whose deletes cannot be resolved by "id=eq.<pk>" alone.
// We upsert them fine; on delete we skip to avoid clogging the queue.
const COMPOSITE_PK_TABLES = new Set<string>([
  "community_members",
  "post_likes",
  "post_bookmarks",
  "post_reactions",
  "saved_jobs",
  "follows",
  "upvotes",
  "user_roles",
  "builder_details",
  "og_claim_stats",
  "platform_settings",
]);

export const Route = createFileRoute("/api/public/mirror-drain")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = request.headers.get("x-mirror-secret");
        const expected = process.env.MIRROR_CRON_SECRET;
        if (!expected || secret !== expected) {
          return new Response("unauthorized", { status: 401 });
        }

        const extUrl = process.env.EXTERNAL_SUPABASE_URL;
        const extKey = process.env.EXTERNAL_SUPABASE_SERVICE_ROLE_KEY;
        if (!extUrl || !extKey) {
          return new Response("external supabase not configured", { status: 500 });
        }

        // IMPORTANT: build a Lovable-Cloud-only client here. The generated
        // supabaseAdmin prefers EXTERNAL_SUPABASE_* env vars, which would point
        // this whole drain (queue reads + updates) at the external DB.
        const localUrl = process.env.SUPABASE_URL;
        const localKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
        if (!localUrl || !localKey) {
          return new Response("local supabase env missing", { status: 500 });
        }
        const { createClient } = await import("@supabase/supabase-js");
        const isOpaqueKey = localKey.startsWith("sb_secret_") || localKey.startsWith("sb_publishable_");
        const supabaseAdmin = createClient(localUrl, localKey, {
          auth: { persistSession: false, autoRefreshToken: false },
          global: {
            fetch: (input, init) => {
              const headers = new Headers(init?.headers ?? undefined);
              if (isOpaqueKey && headers.get("Authorization") === `Bearer ${localKey}`) {
                headers.delete("Authorization");
              }
              headers.set("apikey", localKey);
              return fetch(input, { ...init, headers });
            },
          },
        });

        const { data: rows, error } = await supabaseAdmin
          .from("mirror_outbox")
          .select("id, table_name, op, row_pk, payload, attempts")
          .is("sent_at", null)
          .lt("attempts", MAX_ATTEMPTS)
          .order("id", { ascending: true })
          .limit(BATCH_SIZE);

        if (error) {
          return Response.json({ ok: false, error: error.message }, { status: 500 });
        }
        if (!rows || rows.length === 0) {
          return Response.json({ ok: true, processed: 0 });
        }

        let sent = 0;
        let failed = 0;

        for (const row of rows) {
          try {
            const url = `${extUrl}/rest/v1/${row.table_name}`;
            let resp: Response;

            if (row.op === "D") {
              if (COMPOSITE_PK_TABLES.has(row.table_name) || !(row.payload as any)?.id) {
                // Can't safely resolve composite delete via row_pk alone — drop it.
                await supabaseAdmin
                  .from("mirror_outbox")
                  .update({ sent_at: new Date().toISOString(), last_error: "skipped: composite delete" })
                  .eq("id", row.id);
                sent++;
                continue;
              }
              resp = await fetch(`${url}?id=eq.${encodeURIComponent(row.row_pk)}`, {
                method: "DELETE",
                headers: {
                  apikey: extKey,
                  Authorization: `Bearer ${extKey}`,
                  Prefer: "return=minimal",
                },
              });
            } else {
              // Insert / Update -> upsert
              resp = await fetch(url, {
                method: "POST",
                headers: {
                  apikey: extKey,
                  Authorization: `Bearer ${extKey}`,
                  "Content-Type": "application/json",
                  Prefer: "resolution=merge-duplicates,return=minimal",
                },
                body: JSON.stringify([row.payload]),
              });
            }

            if (resp.ok || resp.status === 201 || resp.status === 204) {
              await supabaseAdmin
                .from("mirror_outbox")
                .update({ sent_at: new Date().toISOString(), last_error: null })
                .eq("id", row.id);
              sent++;
            } else {
              const body = await resp.text();
              await supabaseAdmin
                .from("mirror_outbox")
                .update({
                  attempts: (row.attempts ?? 0) + 1,
                  last_error: `${resp.status}: ${body.slice(0, 500)}`,
                })
                .eq("id", row.id);
              failed++;
            }
          } catch (e: any) {
            await supabaseAdmin
              .from("mirror_outbox")
              .update({
                attempts: (row.attempts ?? 0) + 1,
                last_error: String(e?.message ?? e).slice(0, 500),
              })
              .eq("id", row.id);
            failed++;
          }
        }

        return Response.json({ ok: true, v: 2, processed: rows.length, sent, failed });
      },
    },
  },
});
