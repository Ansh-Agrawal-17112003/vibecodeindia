import { createFileRoute } from '@tanstack/react-router'
import { createClient } from '@supabase/supabase-js'
import { enqueueRetentionEmail } from '@/lib/retention/enqueue.server'

/**
 * Win-back — daily 10:00 IST.
 * Users whose last_login_date is exactly 7 days ago (IST) get a
 * "you missed something" email once.
 */
export const Route = createFileRoute('/api/public/hooks/winback')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apikey = request.headers.get('apikey')
        const anon = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY
        if (!apikey || !anon || apikey !== anon) return new Response('unauthorized', { status: 401 })

        const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
          auth: { persistSession: false, autoRefreshToken: false },
        })

        const nowIst = new Date(Date.now() + 5.5 * 3600 * 1000)
        const sevenAgo = new Date(nowIst.getTime() - 7 * 24 * 3600 * 1000).toISOString().slice(0, 10)
        const sinceIso = new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString()

        const { data: users } = await supabase
          .from('profiles')
          .select('id, display_name, username, login_streak, notify_winback, is_demo')
          .eq('notify_winback', true)
          .eq('is_demo', false)
          .eq('last_login_date', sevenAgo)
          .limit(5000)

        if (!users?.length) return Response.json({ sent: 0 })

        // Global highlights (2 top posts, jobs count, top community)
        const [{ data: topPosts }, { count: jobsCount }] = await Promise.all([
          supabase
            .from('posts')
            .select('id, body, author:profiles!author_id(display_name, username)')
            .gte('created_at', sinceIso)
            .order('like_count', { ascending: false })
            .limit(2),
          supabase.from('jobs').select('id', { count: 'exact', head: true }).eq('status', 'open').gte('created_at', sinceIso),
        ])

        const highlights: string[] = []
        for (const p of topPosts ?? []) {
          const author = (p as any).author?.display_name || (p as any).author?.username || 'A builder'
          const snippet = String((p as any).body || '').slice(0, 80).trim()
          if (snippet) highlights.push(`${author} shared — "${snippet}${snippet.length >= 80 ? '…' : ''}"`)
        }

        let sent = 0
        for (const u of users) {
          try {
            const [{ count: pv }, { count: sa }] = await Promise.all([
              supabase.from('profile_views').select('id', { count: 'exact', head: true }).eq('viewed_profile_id', u.id).gte('viewed_at', sinceIso),
              supabase.from('search_appearances').select('id', { count: 'exact', head: true }).eq('profile_id', u.id).gte('appeared_at', sinceIso),
            ])
            const { data: authUser } = await supabase.auth.admin.getUserById(u.id)
            const email = authUser?.user?.email
            if (!email) continue
            const firstName = (u.display_name || u.username || '').split(' ')[0] || 'there'
            const res = await enqueueRetentionEmail(supabase, {
              templateName: 'winback',
              recipientEmail: email,
              idempotencyKey: `winback-${u.id}-${sevenAgo}`,
              templateData: {
                firstName,
                profileViews: pv ?? 0,
                searchAppearances: sa ?? 0,
                streak: u.login_streak || 0,
                highlights,
                jobsCount: jobsCount ?? 0,
              },
            })
            if (res.ok) sent++
          } catch (e) { console.warn('winback failed', u.id, e) }
        }
        return Response.json({ sent, total: users.length })
      },
    },
  },
})
