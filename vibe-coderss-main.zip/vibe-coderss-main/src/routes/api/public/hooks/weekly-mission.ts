import { createFileRoute } from '@tanstack/react-router'
import { createClient } from '@supabase/supabase-js'
import { enqueueRetentionEmail } from '@/lib/retention/enqueue.server'

/**
 * Weekly mission — Monday 09:00 IST.
 * Sends the current mission to all opted-in users with top-3 leaderboard + their rank.
 */
export const Route = createFileRoute('/api/public/hooks/weekly-mission')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apikey = request.headers.get('apikey')
        const anon = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY
        if (!apikey || !anon || apikey !== anon) return new Response('unauthorized', { status: 401 })

        const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
          auth: { persistSession: false, autoRefreshToken: false },
        })

        // Current mission: latest with week_start <= today
        const today = new Date().toISOString().slice(0, 10)
        const { data: mission } = await supabase
          .from('weekly_missions')
          .select('*')
          .lte('week_start', today)
          .order('week_start', { ascending: false })
          .limit(1)
          .maybeSingle()

        if (!mission) return Response.json({ sent: 0, reason: 'no_mission' })

        // Top 3 by XP
        const { data: top3 } = await supabase
          .from('profiles')
          .select('id, display_name, username, total_xp')
          .eq('is_demo', false)
          .order('total_xp', { ascending: false })
          .limit(3)

        const leaderboard = (top3 ?? []).map((p) => ({
          name: p.display_name || p.username || 'Builder',
          xp: p.total_xp || 0,
        }))

        const activeSince = new Date(Date.now() - 60 * 24 * 3600 * 1000).toISOString()
        const { data: users } = await supabase
          .from('profiles')
          .select('id, display_name, username, total_xp, notify_weekly_digest, is_demo')
          .eq('notify_weekly_digest', true)
          .eq('is_demo', false)
          .gte('updated_at', activeSince)
          .limit(5000)

        if (!users?.length) return Response.json({ sent: 0 })

        let sent = 0
        for (const u of users) {
          try {
            // Rough rank: count of users with more XP + 1
            const { count: better } = await supabase
              .from('profiles')
              .select('id', { count: 'exact', head: true })
              .gt('total_xp', u.total_xp || 0)
              .eq('is_demo', false)
            const { data: authUser } = await supabase.auth.admin.getUserById(u.id)
            const email = authUser?.user?.email
            if (!email) continue
            const firstName = (u.display_name || u.username || '').split(' ')[0] || 'there'
            const res = await enqueueRetentionEmail(supabase, {
              templateName: 'weekly-mission',
              recipientEmail: email,
              idempotencyKey: `mission-${u.id}-${mission.week_start}`,
              templateData: {
                firstName,
                missionTitle: mission.title,
                missionDescription: mission.description,
                rewardCoins: mission.reward_coins,
                bonusCoins: mission.bonus_coins,
                bonusFirstN: mission.bonus_first_n,
                ctaLabel: mission.cta_label,
                ctaHref: `https://www.joinvibecode.xyz${mission.cta_href}`,
                leaderboard,
                yourRank: (better ?? 0) + 1,
                yourXp: u.total_xp || 0,
              },
            })
            if (res.ok) sent++
          } catch (e) { console.warn('mission mail failed', u.id, e) }
        }
        return Response.json({ sent, mission: mission.title })
      },
    },
  },
})
