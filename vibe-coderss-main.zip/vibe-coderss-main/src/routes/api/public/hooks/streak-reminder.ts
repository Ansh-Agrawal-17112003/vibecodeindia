import { createFileRoute } from '@tanstack/react-router'
import { createClient } from '@supabase/supabase-js'
import { enqueueRetentionEmail } from '@/lib/retention/enqueue.server'

/**
 * Streak reminder — daily 20:00 IST.
 * Emails users with a 3+ day streak who haven't logged in today (IST).
 */
export const Route = createFileRoute('/api/public/hooks/streak-reminder')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apikey = request.headers.get('apikey')
        const anon = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY
        if (!apikey || !anon || apikey !== anon) return new Response('unauthorized', { status: 401 })

        const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
          auth: { persistSession: false, autoRefreshToken: false },
        })

        // Today in IST
        const nowIst = new Date(Date.now() + 5.5 * 3600 * 1000)
        const todayIso = nowIst.toISOString().slice(0, 10)

        const { data: users } = await supabase
          .from('profiles')
          .select('id, display_name, username, login_streak, last_login_date, notify_streak_reminder, is_demo')
          .eq('notify_streak_reminder', true)
          .eq('is_demo', false)
          .gte('login_streak', 3)
          .neq('last_login_date', todayIso)
          .limit(5000)

        if (!users?.length) return Response.json({ sent: 0 })

        let sent = 0
        for (const u of users) {
          try {
            const { data: authUser } = await supabase.auth.admin.getUserById(u.id)
            const email = authUser?.user?.email
            if (!email) continue
            const firstName = (u.display_name || u.username || '').split(' ')[0] || 'there'
            const res = await enqueueRetentionEmail(supabase, {
              templateName: 'streak-at-risk',
              recipientEmail: email,
              idempotencyKey: `streak-${u.id}-${todayIso}`,
              templateData: { firstName, streak: u.login_streak },
            })
            if (res.ok) sent++
          } catch (e) { console.warn('streak reminder failed', u.id, e) }
        }
        return Response.json({ sent, total: users.length })
      },
    },
  },
})
