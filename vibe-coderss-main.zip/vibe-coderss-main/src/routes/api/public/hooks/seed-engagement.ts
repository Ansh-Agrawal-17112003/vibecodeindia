import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import {
  ENGAGEMENT_PLAN,
  pickBots,
  pickReactions,
  renderComments,
  renderDMs,
  randInRange,
} from "@/lib/retention/seed-engagement";

/**
 * Seed-bot engagement scan. Runs every 2 minutes via pg_cron.
 *
 * For each post created 5-25 min ago with zero real engagement:
 *   - drops 5-9 reactions from random seed bots
 *   - drops 2-4 comments tagging the author
 *   - sends 3-5 short DMs from bots to the author
 *   - flags the post so it's never processed again
 *
 * If ANY real (non-seed) user has already reacted or commented, the post
 * is marked processed and skipped — bots never step on organic reach.
 */
export const Route = createFileRoute("/api/public/hooks/seed-engagement")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apikey = request.headers.get("apikey");
        const anon = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY;
        if (!apikey || !anon || apikey !== anon) return new Response("unauthorized", { status: 401 });

        const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
          auth: { persistSession: false, autoRefreshToken: false },
        });

        // 1. Load the seed bot pool.
        const { data: bots } = await supabase
          .from("profiles")
          .select("id, username, display_name")
          .eq("is_seed", true);

        if (!bots || bots.length < 5) {
          return Response.json({ ok: true, skipped: "no_bots", bot_count: bots?.length ?? 0 });
        }

        // 2. Candidate posts: 5-25 min old, unprocessed, not deleted, real author (not a seed).
        const now = Date.now();
        const olderThan = new Date(now - 5 * 60 * 1000).toISOString();
        const newerThan = new Date(now - 25 * 60 * 1000).toISOString();

        const botIds = new Set(bots.map((b) => b.id));

        const { data: candidates } = await supabase
          .from("posts")
          .select("id, author_id, body, created_at")
          .is("bot_engaged_at", null)
          .eq("is_deleted", false)
          .lt("created_at", olderThan)
          .gt("created_at", newerThan)
          .limit(50);

        if (!candidates?.length) return Response.json({ ok: true, processed: 0 });

        const results: Array<{ post: string; action: string }> = [];

        for (const post of candidates) {
          // Skip posts authored by a seed bot itself.
          if (botIds.has(post.author_id)) {
            await supabase.from("posts").update({ bot_engaged_at: new Date().toISOString() }).eq("id", post.id);
            results.push({ post: post.id, action: "skip_bot_author" });
            continue;
          }

          // Check for real engagement from non-seed users.
          const [{ data: rx }, { data: cm }] = await Promise.all([
            supabase.from("post_reactions").select("user_id").eq("post_id", post.id).limit(50),
            supabase.from("post_comments").select("author_id").eq("post_id", post.id).limit(50),
          ]);
          const realRx = (rx ?? []).some((r) => !botIds.has(r.user_id));
          const realCm = (cm ?? []).some((c) => !botIds.has(c.author_id));

          if (realRx || realCm) {
            await supabase.from("posts").update({ bot_engaged_at: new Date().toISOString() }).eq("id", post.id);
            results.push({ post: post.id, action: "skip_has_real_engagement" });
            continue;
          }

          // Fetch author display info.
          const { data: author } = await supabase
            .from("profiles")
            .select("id, username, display_name")
            .eq("id", post.author_id)
            .maybeSingle();
          if (!author) continue;

          const authorHandle = author.username || (author.display_name ?? "builder").split(" ")[0].toLowerCase();
          const firstName = (author.display_name ?? authorHandle).split(" ")[0] || "there";
          const title = (post.body ?? "").slice(0, 60);

          // Seed the RNG from the post id (deterministic per post).
          const seed = Math.abs(hashStr(post.id));

          const rxCount = randInRange(ENGAGEMENT_PLAN.reactions.min, ENGAGEMENT_PLAN.reactions.max, seed);
          const cmCount = randInRange(ENGAGEMENT_PLAN.comments.min, ENGAGEMENT_PLAN.comments.max, seed + 1);
          const dmCount = randInRange(ENGAGEMENT_PLAN.dms.min, ENGAGEMENT_PLAN.dms.max, seed + 2);

          const chosenForRx = pickBots(bots, rxCount, seed + 10);
          const chosenForCm = pickBots(bots, cmCount, seed + 20);
          const chosenForDm = pickBots(bots, dmCount, seed + 30);

          const reactions = pickReactions(rxCount, seed + 40);
          const comments = renderComments(cmCount, seed + 50, { author: authorHandle, title });
          const dms = renderDMs(dmCount, seed + 60, { firstName });

          // 3a. Reactions (spread over the next couple of minutes for realism — but insert immediately).
          const rxRows = chosenForRx.map((bot, i) => ({
            post_id: post.id,
            user_id: bot.id,
            reaction_type: reactions[i] ?? "like",
          }));
          if (rxRows.length) await supabase.from("post_reactions").insert(rxRows);

          // 3b. Comments.
          const cmRows = chosenForCm.map((bot, i) => ({
            post_id: post.id,
            author_id: bot.id,
            body: comments[i] ?? "Love this 🔥",
          }));
          if (cmRows.length) await supabase.from("post_comments").insert(cmRows);

          // 3c. DMs — need conversations rows first.
          let dmCounter = 0;
          for (let i = 0; i < chosenForDm.length; i++) {
            const bot = chosenForDm[i];
            const body = dms[i] ?? `hey ${firstName}, nice ship 🔥`;
            try {
              // Deterministic ordering for the (user_a < user_b) constraint.
              const [a, b] = [bot.id, author.id].sort();
              const { data: existingConv } = await supabase
                .from("conversations")
                .select("id")
                .eq("user_a", a)
                .eq("user_b", b)
                .maybeSingle();

              let convId = existingConv?.id;
              if (!convId) {
                const { data: newConv, error: cErr } = await supabase
                  .from("conversations")
                  .insert({ user_a: a, user_b: b })
                  .select("id")
                  .single();
                if (cErr || !newConv) continue;
                convId = newConv.id;
              }

              await supabase.from("messages").insert({
                conversation_id: convId,
                sender_id: bot.id,
                recipient_id: author.id,
                body,
              });
              dmCounter++;
            } catch (e) {
              console.warn("[seed-engagement] dm failed", post.id, bot.id, e);
            }
          }

          // 4. Mark post processed.
          await supabase.from("posts").update({ bot_engaged_at: new Date().toISOString() }).eq("id", post.id);

          results.push({
            post: post.id,
            action: `engaged rx=${rxRows.length} cm=${cmRows.length} dm=${dmCounter}`,
          });
        }

        return Response.json({ ok: true, processed: results.length, results });
      },
    },
  },
});

function hashStr(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
}
