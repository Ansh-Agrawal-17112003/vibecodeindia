import { createFileRoute } from '@tanstack/react-router'
import { createClient } from '@supabase/supabase-js'
import { enqueueRetentionEmail } from '@/lib/retention/enqueue.server'

/**
 * Weekly digest — Sunday 19:00 IST.
 * Sends per-user activity recap (profile views, followers, top post, etc.).
 * Auth: apikey header (Supabase anon key), per project cron convention.
 */
export const Route = createFileRoute('/api/public/hooks/weekly-digest')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apikey = request.headers.get('apikey')
        const anon = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY
        if (!apikey || !anon || apikey !== anon) {
          return new Response('unauthorized', { status: 401 })
        }

        const url = process.env.SUPABASE_URL!
        const svc = process.env.SUPABASE_SERVICE_ROLE_KEY!
        const supabase = createClient(url, svc, { auth: { persistSession: false, autoRefreshToken: false } })

        const sinceIso = new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString()

        // Candidate users: opted-in + active in last 60 days
        const activeSince = new Date(Date.now() - 60 * 24 * 3600 * 1000).toISOString()
        const { data: users } = await supabase
          .from('profiles')
          .select('id, display_name, username, last_login_date, notify_weekly_digest, is_demo')
          .eq('notify_weekly_digest', true)
          .eq('is_demo', false)
          .gte('updated_at', activeSince)
          .limit(5000)

        if (!users?.length) return Response.json({ sent: 0 })

        // Batch email lookup via auth admin
        let sent = 0
        let skipped = 0
        const isoWeek = new Date().toISOString().slice(0, 10)

        for (const u of users) {
          try {
            const [{ count: pv }, { count: sa }, { count: nf }, topPost, saves] = await Promise.all([
              supabase.from('profile_views').select('id', { count: 'exact', head: true }).eq('viewed_profile_id', u.id).gte('viewed_at', sinceIso),
              supabase.from('search_appearances').select('id', { count: 'exact', head: true }).eq('profile_id', u.id).gte('appeared_at', sinceIso),
              supabase.from('follows').select('follower_id', { count: 'exact', head: true }).eq('following_id', u.id).gte('created_at', sinceIso),
              supabase.from('posts').select('id, body, like_count, comment_count').eq('author_id', u.id).gte('created_at', sinceIso).order('like_count', { ascending: false }).limit(1).maybeSingle(),
              supabase.from('post_bookmarks').select('post_id', { count: 'exact', head: true }).gte('created_at', sinceIso),
            ])

            const total = (pv ?? 0) + (sa ?? 0) + (nf ?? 0)
            if (total === 0) { skipped++; continue }

            const { data: authUser } = await supabase.auth.admin.getUserById(u.id)
            const email = authUser?.user?.email
            if (!email) { skipped++; continue }

            const firstName = (u.display_name || u.username || '').split(' ')[0] || 'there'
            const topBody = topPost?.data?.body ? String(topPost.data.body).slice(0, 60) : null

            const res = await enqueueRetentionEmail(supabase, {
              templateName: 'weekly-digest',
              recipientEmail: email,
              idempotencyKey: `weekly-digest-${u.id}-${isoWeek}`,
              templateData: {
                firstName,
                profileViews: pv ?? 0,
                searchAppearances: sa ?? 0,
                newFollowers: nf ?? 0,
                topPostTitle: topBody,
                topPostViews: (topPost?.data?.like_count ?? 0) + (topPost?.data?.comment_count ?? 0),
                saves: saves?.count ?? 0,
              },
            })
            if (res.ok) sent++
            else skipped++
          } catch (e) {
            console.warn('digest per-user failed', u.id, e)
            skipped++
          }
        }

        return Response.json({ sent, skipped, total: users.length })
      },
    },
  },
})
