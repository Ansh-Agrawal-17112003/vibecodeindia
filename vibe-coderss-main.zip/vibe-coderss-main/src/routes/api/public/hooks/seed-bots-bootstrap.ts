import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { SEED_PERSONAS } from "@/lib/retention/seed-engagement";

/**
 * One-shot bootstrap that creates the seed bot accounts + profiles.
 * Idempotent — safe to call repeatedly. Auth via anon apikey header.
 * Trigger manually from an admin console or via a single pg_cron shot.
 */
export const Route = createFileRoute("/api/public/hooks/seed-bots-bootstrap")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apikey = request.headers.get("apikey");
        const anon = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY;
        if (!apikey || !anon || apikey !== anon) return new Response("unauthorized", { status: 401 });

        const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
          auth: { persistSession: false, autoRefreshToken: false },
        });

        let created = 0;
        let updated = 0;

        for (const p of SEED_PERSONAS) {
          const email = `${p.handle}@seed.vibecode.internal`;
          let userId: string | null = null;

          // Look up by email — if not found, create.
          try {
            const { data: existing } = await supabase.auth.admin.listUsers({ page: 1, perPage: 1000 });
            const match = existing?.users.find((u) => u.email?.toLowerCase() === email);
            if (match) {
              userId = match.id;
            } else {
              const { data: newUser, error } = await supabase.auth.admin.createUser({
                email,
                password: crypto.randomUUID() + crypto.randomUUID(),
                email_confirm: true,
                user_metadata: { display_name: p.name },
              });
              if (error) {
                console.warn("[seed-bootstrap] createUser failed", email, error.message);
                continue;
              }
              userId = newUser.user?.id ?? null;
              if (userId) created++;
            }
          } catch (e) {
            console.warn("[seed-bootstrap] lookup/create failed", email, e);
            continue;
          }

          if (!userId) continue;

          // Upsert the profile fields we care about.
          const { error: pErr } = await supabase
            .from("profiles")
            .update({
              is_seed: true,
              username: p.handle,
              display_name: p.name,
              bio: p.bio,
              avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${p.avatarSeed}`,
              onboarded_at: new Date().toISOString(),
            })
            .eq("id", userId);
          if (!pErr) updated++;
        }

        return Response.json({ ok: true, personas: SEED_PERSONAS.length, created, updated });
      },
    },
  },
});
