import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth-callback")({
  head: () => ({
    meta: [
      { title: "Finishing sign in · VibeCode" },
      { name: "description", content: "Completing your VibeCode sign-in." },
    ],
  }),
  component: AuthCallbackPage,
});

function safeNext(value: string | null) {
  if (!value) return "/vibe";
  if (!value.startsWith("/") || value.startsWith("//")) return "/vibe";
  return value;
}

function AuthCallbackPage() {
  const navigate = useNavigate();
  const [message, setMessage] = useState("Completing sign in…");
  const next = useMemo(() => {
    if (typeof window === "undefined") return "/vibe";
    return safeNext(new URLSearchParams(window.location.search).get("next"));
  }, []);

  useEffect(() => {
    let active = true;

    async function finish() {
      try {
        const url = new URL(window.location.href);
        const code = url.searchParams.get("code");
        const error = url.searchParams.get("error_description") || url.searchParams.get("error");

        if (error) throw new Error(error);

        if (code) {
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
          if (exchangeError) throw exchangeError;
        }

        const { data, error: sessionError } = await supabase.auth.getSession();
        if (sessionError) throw sessionError;
        if (!data.session) throw new Error("No sign-in session was created. Please try Google sign-in again.");

        if (active) navigate({ to: next as any, replace: true });
      } catch (err: any) {
        if (!active) return;
        setMessage(err?.message || "Google sign-in could not be completed.");
      }
    }

    finish();
    return () => {
      active = false;
    };
  }, [navigate, next]);

  return (
    <main className="grid min-h-screen place-items-center bg-background px-6 py-10">
      <section className="w-full max-w-sm rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-6 text-center" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}>
        <h1 className="font-display text-2xl font-extrabold">Google sign-in</h1>
        <p className="mt-2 text-sm text-muted-foreground">{message}</p>
        {message !== "Completing sign in…" && (
          <button className="btn-coral mt-5 h-11 w-full" onClick={() => navigate({ to: "/auth", replace: true })}>
            Back to sign in
          </button>
        )}
      </section>
    </main>
  );
}