import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/resources/tutorials")({
  head: () => ({
    meta: [
      { title: "Tutorials & Guides · VibeCode" },
      { name: "description", content: "Short, high-signal tutorials for AI builders. Every guide ends with a working artifact — a prompt, a workflow, a deploy." },
      { property: "og:title", content: "Tutorials & Guides · VibeCode" },
      { property: "og:description", content: "Short, high-signal tutorials for AI builders. Every guide ends with a working artifact — a prompt, a workflow, a deploy." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/resources/tutorials" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/resources/tutorials" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Tutorials & Guides"
      breadcrumb={[{"label":"Resources","to":"/"}]}
      title="Learn by shipping."
      intro="Short, high-signal tutorials for AI builders. Every guide ends with a working artifact — a prompt, a workflow, a deploy."
      toc={[{"id":"tracks","label":"Popular tracks"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="tracks" title="Popular tracks"><NotionFeatureGrid items={[{"title":"Prompt Engineering 101","description":"From zero to production prompts in 12 lessons."},{"title":"Build with n8n","description":"Automate the boring, keep the shipping."},{"title":"Ship a SaaS with Lovable","description":"Zero to paying users in a weekend."},{"title":"RAG in production","description":"Chunking, retrieval, eval — the whole stack."}]} /></NotionSection>
      <NotionCallout emoji="📚" tone="cream">All tutorials are free. Sign in to track progress, earn XP, and unlock certifications.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Who writes these?" a="Working AI engineers from our community. Every author has shipped what they teach." />
          <NotionToggle q="Are the tutorials video or text?" a="Both. You pick the format — every lesson has a written and a 5-min video version." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
