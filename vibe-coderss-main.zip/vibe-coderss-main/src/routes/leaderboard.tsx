import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Shell } from "@/components/site/Shell";
import { LevelBadge } from "@/components/site/LevelBadge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { builders } from "@/lib/mock-data";
import { Trophy, Medal, Award, Sparkles } from "lucide-react";

export const Route = createFileRoute("/leaderboard")({
  head: () => ({
    meta: [
      { title: 'Leaderboard · VibeCode' },
      { name: "description", content: 'Top AI builders in India this week — ranked by shipped projects, prompts and community XP.' },
      { property: "og:title", content: 'Leaderboard · VibeCode' },
      { property: "og:description", content: 'Top AI builders in India this week — ranked by shipped projects, prompts and community XP.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/leaderboard' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Leaderboard · VibeCode' },
      { name: "twitter:description", content: 'Top AI builders in India this week — ranked by shipped projects, prompts and community XP.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/leaderboard' }],
  }),
  component: Leaderboard,
});

type Category = "builders" | "contributors" | "creators" | "rising";
type Range = "week" | "month" | "all";

function seededXp(seed: number, base: number) {
  // Deterministic pseudo-score so SSR/CSR match
  const x = Math.sin(seed * 9973) * 10000;
  return base + Math.floor(Math.abs(x - Math.floor(x)) * base * 0.6);
}

function useCountdown(target: Date) {
  const [now, setNow] = useState(() => new Date(target.getTime() - 1000 * 60 * 60 * 24 * 3));
  useEffect(() => {
    setNow(new Date());
    const iv = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(iv);
  }, []);
  const ms = Math.max(0, target.getTime() - now.getTime());
  const d = Math.floor(ms / 86_400_000);
  const h = Math.floor((ms % 86_400_000) / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  const s = Math.floor((ms % 60_000) / 1000);
  return { d, h, m, s };
}

function Leaderboard() {
  const [cat, setCat] = useState<Category>("builders");
  const [range, setRange] = useState<Range>("week");

  const rows = useMemo(() => {
    const rangeMult = range === "week" ? 1 : range === "month" ? 4 : 26;
    const withScores = builders.map((b, i) => {
      const xpBase = 300 + b.followers * 4;
      const xp = seededXp(i + 1, xpBase * rangeMult);
      const posts = seededXp(i + 7, 40 + b.followers / 3) * rangeMult;
      const creations = seededXp(i + 13, (b.projects ?? 3) * 60) * rangeMult;
      const weekGain = seededXp(i + 19, 600);
      return { ...b, xp, posts, creations, weekGain };
    });
    const sortKey =
      cat === "contributors" ? (r: any) => r.posts :
      cat === "creators" ? (r: any) => r.creations :
      cat === "rising" ? (r: any) => r.weekGain :
      (r: any) => r.xp;
    return [...withScores].sort((a, b) => sortKey(b) - sortKey(a)).slice(0, 25);
  }, [cat, range]);

  const monthEnd = useMemo(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth() + 1, 1);
  }, []);
  const { d, h, m, s } = useCountdown(monthEnd);

  return (
    <Shell>
      <div className="container-page py-8">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">India's builder charts</div>
            <h1 className="mt-1 font-display text-3xl font-extrabold sm:text-4xl">Leaderboard</h1>
            <p className="mt-1 text-sm text-muted-foreground">The vibe coders shipping, teaching and helping the most.</p>
          </div>
          <Tabs value={range} onValueChange={(v) => setRange(v as Range)}>
            <TabsList>
              <TabsTrigger value="week">This Week</TabsTrigger>
              <TabsTrigger value="month">This Month</TabsTrigger>
              <TabsTrigger value="all">All Time</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="mb-6 flex flex-wrap gap-2">
          {([
            { k: "builders", label: "Top Builders", desc: "by XP earned" },
            { k: "contributors", label: "Top Contributors", desc: "posts + comments" },
            { k: "creators", label: "Top Creators", desc: "projects + prompts" },
            { k: "rising", label: "Rising Stars", desc: "biggest XP gain" },
          ] as { k: Category; label: string; desc: string }[]).map((c) => (
            <button
              key={c.k}
              onClick={() => setCat(c.k)}
              className={`rounded-full border-[1.5px] border-[#0F0F0F] px-3.5 py-1.5 text-xs font-extrabold transition ${cat === c.k ? "bg-coral text-white" : "bg-white hover:-translate-y-0.5"}`}
              style={{ boxShadow: cat === c.k ? "2px 2px 0 0 #0F0F0F" : "1px 1px 0 0 #0F0F0F" }}
              title={c.desc}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
          <Tabs value={range}>
            <TabsContent value={range} className="mt-0">
              <div className="card-editorial overflow-hidden p-0">
                <div className="hidden grid-cols-[60px_1fr_140px_140px_100px] gap-4 border-b-[1.5px] border-[#0F0F0F] bg-white/60 px-5 py-3 text-[11px] font-extrabold uppercase tracking-wider text-muted-foreground md:grid">
                  <div>Rank</div><div>Builder</div><div>Level</div><div>Score</div><div className="text-right">Followers</div>
                </div>
                {rows.map((b: any, i) => {
                  const score =
                    cat === "contributors" ? b.posts :
                    cat === "creators" ? b.creations :
                    cat === "rising" ? b.weekGain : b.xp;
                  const tint = i === 0 ? "bg-[#FFF3D1]" : i === 1 ? "bg-[#F1F1F1]" : i === 2 ? "bg-[#F3E0CC]" : "";
                  const rankIcon = i === 0 ? <Trophy className="h-4 w-4 text-[#EAB308]" /> : i === 1 ? <Medal className="h-4 w-4 text-[#9CA3AF]" /> : i === 2 ? <Award className="h-4 w-4 text-[#CD7F32]" /> : null;
                  return (
                    <Link
                      key={b.id}
                      to="/u/$username"
                      params={{ username: b.username }}
                      className={`grid grid-cols-[40px_1fr_auto] gap-3 border-b-[1.5px] border-[#0F0F0F]/10 px-4 py-4 transition hover:bg-cream md:grid-cols-[60px_1fr_140px_140px_100px] md:gap-4 md:px-5 ${tint}`}
                    >
                      <div className="flex items-center gap-1.5 font-display text-lg font-extrabold text-foreground">
                        {rankIcon}#{i + 1}
                      </div>
                      <div className="flex min-w-0 items-center gap-3">
                        <img src={b.avatar} className="h-9 w-9 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]" alt="" />
                        <div className="min-w-0">
                          <div className="truncate text-sm font-extrabold">{b.name}</div>
                          <div className="truncate text-xs text-muted-foreground">{b.title}</div>
                        </div>
                      </div>
                      <div className="hidden md:block"><LevelBadge xp={b.xp} size="xs" /></div>
                      <div className="hidden text-sm font-bold tabular-nums md:block">
                        {score.toLocaleString()} <span className="text-[11px] font-bold text-muted-foreground">{cat === "builders" ? "XP" : "pts"}</span>
                      </div>
                      <div className="hidden text-right text-sm text-muted-foreground md:block">{b.followers.toLocaleString()}</div>
                      <div className="text-right text-sm md:hidden">
                        <div className="font-bold tabular-nums">{score.toLocaleString()}</div>
                        <LevelBadge xp={b.xp} size="xs" showName={false} />
                      </div>
                    </Link>
                  );
                })}
              </div>
            </TabsContent>
          </Tabs>

          <aside className="space-y-5">
            <div className="card-editorial p-5">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                <Sparkles className="h-4 w-4 text-coral" /> Monthly prize pool
              </div>
              <ul className="mt-3 space-y-2 text-sm font-bold">
                <li className="flex items-center justify-between"><span>🏆 #1 Builder</span><span className="text-coral">₹2,500</span></li>
                <li className="flex items-center justify-between"><span>🥈 #2 Builder</span><span className="text-coral">₹1,500</span></li>
                <li className="flex items-center justify-between"><span>🥉 Best Project</span><span className="text-coral">₹1,000</span></li>
              </ul>
              <div className="mt-4 rounded-md border-[1.5px] border-[#0F0F0F] bg-cream p-3">
                <div className="text-[11px] font-extrabold uppercase tracking-wider text-muted-foreground">Resets in</div>
                <div className="mt-1 font-display text-xl font-extrabold tabular-nums">
                  {d}d {String(h).padStart(2, "0")}h {String(m).padStart(2, "0")}m {String(s).padStart(2, "0")}s
                </div>
              </div>
            </div>

            <div className="card-editorial p-5">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">How XP works</div>
              <ul className="mt-3 space-y-1.5 text-xs text-muted-foreground">
                <li>+250 XP per project shipped</li>
                <li>+150 XP per prompt shared</li>
                <li>+25 XP daily login (+100/500/1000 streak bonuses)</li>
                <li>+300 XP per referral converted</li>
              </ul>
              <Link to="/rewards" className="btn-coral mt-4 h-9 w-full text-xs">Redeem VibeCoins</Link>
            </div>
          </aside>
        </div>
      </div>
    </Shell>
  );
}
