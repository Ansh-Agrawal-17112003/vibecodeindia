import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, Lock, Database, Cookie, Mail, UserCheck, Globe, FileWarning } from "lucide-react";

export const Route = createFileRoute("/privacy-policy")({
  head: () => ({
    meta: [
      { title: 'Privacy Policy — VibeCode' },
      { name: "description", content: "How VibeCode collects, uses and protects your data under India's DPDP Act." },
      { property: "og:title", content: 'Privacy Policy — VibeCode' },
      { property: "og:description", content: "How VibeCode collects, uses and protects your data under India's DPDP Act." },
      { property: "og:url", content: 'https://joinvibecode.xyz/privacy-policy' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Privacy Policy — VibeCode' },
      { name: "twitter:description", content: "How VibeCode collects, uses and protects your data under India's DPDP Act." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/privacy-policy' }],
  }),
  component: PrivacyPage,
});

const EFFECTIVE = "July 7, 2026";

function Section({
  icon: Icon,
  title,
  children,
}: {
  icon: any;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mt-10 border-t border-[#0F0F0F]/10 pt-8">
      <div className="mb-4 flex items-center gap-3">
        <span
          className="grid h-9 w-9 place-items-center rounded-xl border-[1.5px] border-[#0F0F0F] bg-[#E8623A] text-white"
          style={{ boxShadow: "1.5px 1.5px 0 0 #0F0F0F" }}
        >
          <Icon className="h-4 w-4" />
        </span>
        <h2 className="font-display text-[22px] font-extrabold tracking-[-0.01em] md:text-[26px]">{title}</h2>
      </div>
      <div className="space-y-3 text-[15px] leading-[1.75] text-[#0F0F0F]/80">{children}</div>
    </section>
  );
}

function PrivacyPage() {
  return (
    <main className="min-h-screen bg-[#FAF7F0] text-[#0F0F0F]">
      <header className="border-b border-[#0F0F0F]/10 bg-white">
        <div className="mx-auto max-w-[900px] px-6 py-14 md:py-20">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.16em] text-[#0F0F0F]/60 transition hover:text-[#E8623A]"
          >
            ← Back to VibeCode
          </Link>
          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-[#0F0F0F]/15 bg-[#FAF7F0] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-[#0F0F0F]/70">
            <ShieldCheck className="h-3.5 w-3.5" />
            Legal — Privacy Policy
          </div>
          <h1
            className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
            style={{ fontSize: "clamp(36px, 6vw, 64px)" }}
          >
            Privacy Policy
          </h1>
          <p className="mt-4 max-w-[640px] text-[16px] leading-[1.7] text-[#0F0F0F]/70 md:text-[17px]">
            Your privacy matters. This policy explains what personal information VibeCode collects, how we use it,
            who we share it with, and the choices you have.
          </p>
          <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-[13px] text-[#0F0F0F]/60">
            <span><b>Effective:</b> {EFFECTIVE}</span>
            <span><b>Governing law:</b> India (DPDP Act, 2023)</span>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-[900px] px-6 py-12 md:py-16">
        <Section icon={Database} title="1. What we collect">
          <p>
            When you create an account or claim an OG spot, we collect: your <b>name, email, chosen username, city,
            role/builder type, primary AI tools, and a short tagline</b> about what you build. If you sign in with
            Google, we receive your basic profile (name, email, avatar).
          </p>
          <p>
            When you use the platform, we automatically log <b>IP address, device/browser info, pages visited, and
            interaction events</b> so we can prevent abuse and improve the product.
          </p>
          <p>Payment details (when you buy Pro or a service) are handled directly by our payment processors — we never store your card number.</p>
        </Section>

        <Section icon={UserCheck} title="2. How we use your data">
          <ul className="list-disc space-y-2 pl-6">
            <li>Create and secure your account, badge, and profile.</li>
            <li>Show you on the public builder wall, leaderboard, or search — only if you opted in.</li>
            <li>Match you with jobs, hires, communities, and content relevant to you.</li>
            <li>Send transactional emails (account, receipts, security alerts) and, if you opt in, product updates.</li>
            <li>Detect fraud, spam, scams, and abuse — and enforce our Terms.</li>
            <li>Analyse aggregate usage so we can improve VibeCode.</li>
          </ul>
        </Section>

        <Section icon={Globe} title="3. Who we share it with">
          <p>
            We do <b>not</b> sell your personal data. We share limited data only with:
          </p>
          <ul className="list-disc space-y-2 pl-6">
            <li><b>Infrastructure providers</b> (hosting, database, email delivery, analytics) strictly to operate the service.</li>
            <li><b>Payment processors</b> (e.g. Stripe, Razorpay) when you make a purchase.</li>
            <li><b>Other users</b> — the parts of your profile you chose to make public.</li>
            <li><b>Law enforcement</b> when legally compelled or to prevent imminent harm.</li>
          </ul>
        </Section>

        <Section icon={Cookie} title="4. Cookies & tracking">
          <p>
            We use <b>essential cookies</b> to keep you signed in and <b>analytics cookies</b> to understand how the
            product is used. You can clear cookies in your browser at any time — signing you out.
          </p>
        </Section>

        <Section icon={Lock} title="5. How we protect your data">
          <p>
            Data is encrypted in transit (TLS) and at rest. Access is limited to authorised staff on a need-to-know
            basis. We use row-level security on our database so users can only reach the rows they own.
          </p>
        </Section>

        <Section icon={FileWarning} title="6. Your rights">
          <p>Under the Digital Personal Data Protection Act, 2023, you have the right to:</p>
          <ul className="list-disc space-y-2 pl-6">
            <li>Access the personal data we hold about you.</li>
            <li>Correct inaccurate data or update your profile.</li>
            <li>Withdraw consent or delete your account at any time.</li>
            <li>Grieve any misuse — contact our Grievance Officer at{" "}
              <a href="mailto:privacy@joinvibecode.xyz" className="text-[#E8623A] underline">privacy@joinvibecode.xyz</a>.
            </li>
          </ul>
        </Section>

        <Section icon={Database} title="7. Data retention">
          <p>
            We keep your account data for as long as your account is active. If you delete your account, we remove
            your profile within 30 days, except where we're legally required to keep records (e.g. tax invoices).
          </p>
        </Section>

        <Section icon={Mail} title="8. Contact us">
          <p>
            Questions, requests, or complaints? Email{" "}
            <a href="mailto:privacy@joinvibecode.xyz" className="text-[#E8623A] underline">privacy@joinvibecode.xyz</a>.
            For security reports, use{" "}
            <a href="mailto:trust@joinvibecode.xyz" className="text-[#E8623A] underline">trust@joinvibecode.xyz</a>.
          </p>
        </Section>

        <div className="mt-14 flex flex-wrap items-center justify-between gap-4 rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-6 shadow-[4px_4px_0_0_#0F0F0F]">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#E8623A]">Also read</div>
            <div className="mt-1 font-display text-[18px] font-extrabold">Our Terms & Conditions</div>
          </div>
          <Link
            to="/terms"
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-[#E8623A] px-5 py-2.5 text-[13px] font-extrabold uppercase tracking-[0.1em] text-white"
            style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
          >
            Read Terms →
          </Link>
        </div>
      </div>
    </main>
  );
}
