import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useState, useEffect, useMemo } from "react";
import { Shell } from "@/components/site/Shell";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BuilderCard } from "@/components/cards/BuilderCard";
import { ProjectCard } from "@/components/cards/ProjectCard";
import { ServiceCard } from "@/components/cards/ServiceCard";
import { PromptCard } from "@/components/cards/PromptCard";
import { WorkflowCard } from "@/components/cards/WorkflowCard";
import { CommunityCard } from "@/components/cards/CommunityCard";
import { JobCard } from "@/components/cards/JobCard";
import { builders, projects, services, prompts, workflows, communities, jobs } from "@/lib/mock-data";
import { supabase } from "@/integrations/supabase/client";
import { MemberBadges } from "@/components/ui/MemberBadges";

type SearchSchema = { q?: string; location?: string };

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>): SearchSchema => ({
    q: typeof s.q === "string" ? s.q : undefined,
    location: typeof s.location === "string" ? s.location : undefined,
  }),
  head: () => ({
    meta: [
      { title: 'Search · VibeCode' },
      { name: "description", content: 'Search builders, projects, prompts, tools, workflows and jobs across VibeCode.' },
      { property: "og:title", content: 'Search · VibeCode' },
      { property: "og:description", content: 'Search builders, projects, prompts, tools, workflows and jobs across VibeCode.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/search' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Search · VibeCode' },
      { name: "twitter:description", content: 'Search builders, projects, prompts, tools, workflows and jobs across VibeCode.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/search' }],
  }),
  component: SearchPage,
});

const includes = (s: string | undefined, q: string) => (s ?? "").toLowerCase().includes(q);

function SearchPage() {
  const navigate = useNavigate({ from: "/search" });
  const { q: urlQ = "", location: urlLoc = "" } = Route.useSearch();
  const [q, setQ] = useState(urlQ);
  const [loc, setLoc] = useState(urlLoc);

  useEffect(() => { setQ(urlQ); setLoc(urlLoc); }, [urlQ, urlLoc]);

  // Sync URL as user types (debounced)
  useEffect(() => {
    const id = setTimeout(() => {
      navigate({ search: { q: q.trim() || undefined, location: loc.trim() || undefined }, replace: true });
    }, 250);
    return () => clearTimeout(id);
  }, [q, loc, navigate]);

  const term = q.trim().toLowerCase();
  const locTerm = loc.trim().toLowerCase();

  const fBuilders = useMemo(() => builders.filter((b) =>
    (!term || includes(b.name, term) || includes(b.title, term) || includes(b.bio, term) || b.skills.some((s) => includes(s, term)) || b.tools.some((t) => includes(t, term))) &&
    (!locTerm || includes(b.location, locTerm))
  ), [term, locTerm]);

  const fProjects = useMemo(() => projects.filter((p) => !term || includes(p.title, term) || includes(p.description, term) || p.tools.some((t) => includes(t, term)) || includes(p.industry, term)), [term]);
  const fServices = useMemo(() => services.filter((s) => !term || includes(s.title, term) || s.tags.some((t) => includes(t, term)) || includes(s.category, term)), [term]);
  const fPrompts = useMemo(() => prompts.filter((p) => !term || includes(p.title, term) || includes(p.preview, term) || includes(p.category, term) || includes(p.model, term)), [term]);
  const fWorkflows = useMemo(() => workflows.filter((w) => !term || includes(w.title, term) || includes(w.description, term) || includes(w.category, term) || w.tools.some((t) => includes(t, term))), [term]);
  const fCommunities = useMemo(() => communities.filter((c) => !term || includes(c.name, term) || includes(c.description, term)), [term]);
  const fJobs = useMemo(() => jobs.filter((j) =>
    (!term || includes(j.title, term) || includes(j.company, term) || includes(j.description, term) || j.tools.some((t) => includes(t, term)) || includes(j.industry, term)) &&
    (!locTerm || includes(j.location, locTerm))
  ), [term, locTerm]);

  const totalCount = fBuilders.length + fProjects.length + fServices.length + fPrompts.length + fWorkflows.length + fCommunities.length + fJobs.length;

  // Real ranked builders from DB (OG/Pro/Boosted first via get_ranked_builders RPC).
  const [featured, setFeatured] = useState<Array<{ id: string; username: string | null; display_name: string | null; avatar_url: string | null; is_og_member: boolean | null; og_number: number | null; is_verified: boolean | null; subscription_plan: string | null; is_boosted: boolean | null }>>([]);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { data } = await (supabase as any).rpc("get_ranked_builders", { p_search: term || null, p_limit: 8 });
        if (!cancelled && Array.isArray(data)) setFeatured(data);
      } catch {
        // RPC optional — silently skip if unavailable.
      }
    })();
    return () => { cancelled = true; };
  }, [term]);

  return (
    <Shell>
      <div className="sticky top-16 z-30 border-b-[1.5px] border-[#0F0F0F] bg-background/95 backdrop-blur">
        <div className="container-page py-4">
          <div className="card-flat flex flex-col gap-2 p-2 sm:flex-row sm:items-center">
            <div className="flex flex-1 items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-background px-3 py-2.5">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search builders, projects, jobs, prompts…" className="h-full flex-1 bg-transparent text-sm outline-none" autoFocus />
            </div>
            <input value={loc} onChange={(e) => setLoc(e.target.value)} placeholder="Location (optional)" className="rounded-md border-[1.5px] border-[#0F0F0F] bg-background px-3 py-2.5 text-sm outline-none sm:w-48" />
          </div>
          <div className="mt-2 text-xs text-muted-foreground">
            {term || locTerm ? <><b className="text-foreground">{totalCount}</b> results for "{term}"{locTerm && ` in ${locTerm}`}</> : "Type to search across the entire community."}
          </div>
        </div>
      </div>
      <div className="container-page py-6">
        {featured.length > 0 && (
          <div className="mb-6">
            <h2 className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
              🔥 Featured builders {term && `matching "${term}"`}
            </h2>
            <div className="flex gap-3 overflow-x-auto pb-2">
              {featured.map((b) => (
                <Link
                  key={b.id}
                  to="/u/$username"
                  params={{ username: b.username || "unknown" }}
                  className="group shrink-0 rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-3 shadow-[2px_2px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:border-coral"
                  style={{ minWidth: 200 }}
                >
                  <div className="flex items-center gap-2">
                    <img
                      src={b.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${b.username ?? b.id}`}
                      alt=""
                      className="h-10 w-10 rounded-full border-[1.5px] border-[#0F0F0F] object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-bold">{b.display_name || b.username || "Builder"}</div>
                      {b.username && <div className="truncate text-[11px] text-muted-foreground">@{b.username}</div>}
                    </div>
                  </div>
                  <div className="mt-2"><MemberBadges profile={b} size="xs" /></div>
                </Link>
              ))}
            </div>
          </div>
        )}

        <Tabs defaultValue="all">
          <TabsList>
            <TabsTrigger value="all">All ({totalCount})</TabsTrigger>
            <TabsTrigger value="builders">Builders ({fBuilders.length})</TabsTrigger>
            <TabsTrigger value="projects">Projects ({fProjects.length})</TabsTrigger>
            <TabsTrigger value="jobs">Jobs ({fJobs.length})</TabsTrigger>
            <TabsTrigger value="services">Services ({fServices.length})</TabsTrigger>
            <TabsTrigger value="prompts">Prompts ({fPrompts.length})</TabsTrigger>
            <TabsTrigger value="workflows">Workflows ({fWorkflows.length})</TabsTrigger>
            <TabsTrigger value="communities">Communities ({fCommunities.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-10 py-6">
            {fBuilders.length > 0 && <Section title="Builders"><Grid>{fBuilders.slice(0, 3).map((b) => <BuilderCard key={b.id} b={b} />)}</Grid></Section>}
            {fProjects.length > 0 && <Section title="Projects"><Grid>{fProjects.slice(0, 3).map((p) => <ProjectCard key={p.id} p={p} />)}</Grid></Section>}
            {fJobs.length > 0 && <Section title="Jobs"><div className="space-y-3">{fJobs.slice(0, 4).map((j) => <JobCard key={j.id} j={j} />)}</div></Section>}
            {fPrompts.length > 0 && <Section title="Prompts"><Grid>{fPrompts.slice(0, 3).map((p) => <PromptCard key={p.id} p={p} />)}</Grid></Section>}
            {fWorkflows.length > 0 && <Section title="Workflows"><Grid>{fWorkflows.slice(0, 3).map((w) => <WorkflowCard key={w.id} w={w} />)}</Grid></Section>}
            {fCommunities.length > 0 && <Section title="Communities"><Grid>{fCommunities.slice(0, 3).map((c) => <CommunityCard key={c.id} c={c} />)}</Grid></Section>}
            {totalCount === 0 && <EmptyState />}
          </TabsContent>
          <TabsContent value="builders" className="py-6">{fBuilders.length ? <Grid>{fBuilders.map((b) => <BuilderCard key={b.id} b={b} />)}</Grid> : <EmptyState />}</TabsContent>
          <TabsContent value="projects" className="py-6">{fProjects.length ? <Grid>{fProjects.map((p) => <ProjectCard key={p.id} p={p} />)}</Grid> : <EmptyState />}</TabsContent>
          <TabsContent value="jobs" className="py-6">{fJobs.length ? <div className="space-y-3">{fJobs.map((j) => <JobCard key={j.id} j={j} />)}</div> : <EmptyState />}</TabsContent>
          <TabsContent value="services" className="py-6">{fServices.length ? <Grid>{fServices.map((s) => <ServiceCard key={s.id} s={s} />)}</Grid> : <EmptyState />}</TabsContent>
          <TabsContent value="prompts" className="py-6">{fPrompts.length ? <Grid>{fPrompts.map((p) => <PromptCard key={p.id} p={p} />)}</Grid> : <EmptyState />}</TabsContent>
          <TabsContent value="workflows" className="py-6">{fWorkflows.length ? <Grid>{fWorkflows.map((w) => <WorkflowCard key={w.id} w={w} />)}</Grid> : <EmptyState />}</TabsContent>
          <TabsContent value="communities" className="py-6">{fCommunities.length ? <Grid>{fCommunities.map((c) => <CommunityCard key={c.id} c={c} />)}</Grid> : <EmptyState />}</TabsContent>
        </Tabs>
      </div>
    </Shell>
  );
}

function EmptyState() {
  return <div className="card-editorial p-12 text-center"><div className="text-2xl">🔍</div><p className="mt-2 text-sm text-muted-foreground">No results. Try a different keyword.</p></div>;
}
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <div><h2 className="mb-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">{title}</h2>{children}</div>;
}
function Grid({ children }: { children: React.ReactNode }) {
  return <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{children}</div>;
}
