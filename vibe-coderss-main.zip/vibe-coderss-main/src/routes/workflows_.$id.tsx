import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowUp, Download, Copy, Share2, Clock, Zap } from "lucide-react";
import { sharePage } from "@/lib/share";
import { useState } from "react";
import { toast } from "sonner";
import { Shell } from "@/components/site/Shell";
import { ToolLogos } from "@/components/site/ToolLogo";
import { WorkflowCard } from "@/components/cards/WorkflowCard";
import { getBuilder, workflows } from "@/lib/mock-data";

export const Route = createFileRoute("/workflows_/$id")({
  loader: ({ params }) => {
    const w = workflows.find((x) => x.id === params.id);
    if (!w) throw notFound();
    return { workflow: w };
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.workflow.title} · VibeCode` }] }),
  component: WorkflowDetail,
  notFoundComponent: () => (
    <Shell>
      <div className="container-page py-20 text-center">
        <h1 className="font-display text-3xl font-extrabold">Workflow not found</h1>
        <Link to="/workflows" className="mt-4 inline-block text-coral underline">Browse all workflows</Link>
      </div>
    </Shell>
  ),
});

const STEPS = [
  { t: "Trigger", d: "Webhook / schedule / form submission fires the workflow." },
  { t: "Validate & Enrich", d: "Inputs are sanitized; missing data is enriched via API lookups." },
  { t: "AI Step", d: "GPT or Claude classifies, summarizes, or generates the next action." },
  { t: "Branch & Route", d: "Conditional logic routes to the right downstream system." },
  { t: "Write to Destination", d: "Final payload is delivered to CRM / DB / Slack / email." },
  { t: "Observability", d: "Failures route to an alert channel with full payload context." },
];

function WorkflowDetail() {
  const { workflow: w } = Route.useLoaderData();
  const b = getBuilder(w.builderId);
  const [copied, setCopied] = useState(false);
  const [upvoted, setUpvoted] = useState(false);
  const [upvoteCount, setUpvoteCount] = useState(w.upvotes);
  const related = workflows.filter((x) => x.id !== w.id && x.category === w.category).slice(0, 3);

  const workflowJson = () => JSON.stringify({
    name: w.title, description: w.description, category: w.category,
    tools: w.tools, nodes: STEPS.map((s, i) => ({ id: i + 1, name: s.t, description: s.d })),
  }, null, 2);

  const downloadJson = () => {
    const blob = new Blob([workflowJson()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `${w.id}-${w.title.replace(/\W+/g, "-").toLowerCase()}.json`; a.click();
    URL.revokeObjectURL(url);
    toast.success("Workflow JSON downloaded");
  };
  const copyJson = () => {
    navigator.clipboard?.writeText(workflowJson());
    setCopied(true); toast.success("Template copied to clipboard");
    setTimeout(() => setCopied(false), 1500);
  };
  const toggleUpvote = () => {
    const next = !upvoted;
    setUpvoted(next);
    setUpvoteCount((c: number) => c + (next ? 1 : -1));
    toast.success(next ? "Upvoted!" : "Removed upvote");
  };


  return (
    <Shell>
      <div className="container-page py-8">
        <div className="mb-6 text-xs font-bold text-muted-foreground">
          <Link to="/workflows" className="hover:text-coral">Workflows</Link> / <span className="text-foreground">{w.title}</span>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <div>
            <div className="card-editorial overflow-hidden">
              <img src={w.cover} alt="" className="aspect-[16/9] w-full object-cover" />
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-2">
              <span className="rounded-md border-[1.5px] border-[#0F0F0F] bg-teal/25 px-2.5 py-1 text-[10px] font-bold uppercase text-[#0a6b5e]">{w.category}</span>
              <span className="rounded-md border-[1.5px] border-[#0F0F0F] bg-gold px-2.5 py-1 text-[10px] font-bold uppercase">n8n compatible</span>
              <span className="flex items-center gap-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-2.5 py-1 text-[10px] font-bold uppercase"><Clock className="h-3 w-3" />~15 min setup</span>
            </div>
            <h1 className="mt-3 font-display text-4xl font-extrabold leading-tight tracking-tight">{w.title}</h1>
            <p className="mt-3 text-base text-muted-foreground">{w.description}</p>

            <div className="mt-4"><ToolLogos names={w.tools} max={6} /></div>

            <div className="mt-8">
              <h3 className="mb-3 font-display text-xl font-extrabold">How it works</h3>
              <ol className="space-y-3">
                {STEPS.map((s, i) => (
                  <li key={i} className="card-editorial flex gap-4 p-4">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border-[1.5px] border-[#0F0F0F] bg-coral font-display text-base font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>{i + 1}</span>
                    <div>
                      <div className="font-display font-bold">{s.t}</div>
                      <div className="mt-0.5 text-sm text-muted-foreground">{s.d}</div>
                    </div>
                  </li>
                ))}
              </ol>
            </div>

            <div className="mt-8 card-editorial p-5">
              <h3 className="font-display text-lg font-extrabold">Requirements</h3>
              <ul className="mt-3 space-y-2 text-sm text-foreground/80">
                <li className="flex gap-2"><Zap className="mt-0.5 h-4 w-4 shrink-0 text-coral" />Active n8n instance (self-hosted or cloud)</li>
                <li className="flex gap-2"><Zap className="mt-0.5 h-4 w-4 shrink-0 text-coral" />API keys for: {w.tools.join(", ")}</li>
                <li className="flex gap-2"><Zap className="mt-0.5 h-4 w-4 shrink-0 text-coral" />Basic understanding of webhooks and JSON</li>
                <li className="flex gap-2"><Zap className="mt-0.5 h-4 w-4 shrink-0 text-coral" />Optional: A Slack channel for alerts</li>
              </ul>
            </div>

            {related.length > 0 && (
              <div className="mt-10">
                <h3 className="mb-4 font-display text-xl font-extrabold">Related workflows</h3>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{related.map((r) => <WorkflowCard key={r.id} w={r} />)}</div>
              </div>
            )}
          </div>

          <aside className="space-y-4">
            <div className="card-editorial space-y-2 p-4">
              <button onClick={downloadJson} className="btn-coral w-full"><Download className="h-4 w-4" />Download JSON</button>
              <button onClick={copyJson} className="btn-outline-dark w-full"><Copy className="h-4 w-4" />{copied ? "Copied!" : "Copy template"}</button>
              <button onClick={() => sharePage(w.title, w.description)} className="btn-outline-dark w-full"><Share2 className="h-4 w-4" />Share</button>
              <button onClick={toggleUpvote} className="flex w-full items-center justify-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] px-4 py-2.5 text-sm font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F", background: upvoted ? "#E8623A" : "#F5A623", color: upvoted ? "#fff" : "#0F0F0F" }}>
                <ArrowUp className="h-4 w-4" />{upvoted ? "Upvoted" : "Upvote"} · {upvoteCount}
              </button>
            </div>
            <div className="card-editorial p-4">
              <h4 className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Author</h4>
              <Link to="/u/$username" params={{ username: b.username }} className="flex items-center gap-3">
                <img src={b.avatar} className="h-10 w-10 rounded-full border-[1.5px] border-[#0F0F0F]" alt="" />
                <div>
                  <div className="font-bold">{b.name}</div>
                  <div className="text-xs text-muted-foreground">{b.title}</div>
                </div>
              </Link>
            </div>
            <div className="card-editorial p-4">
              <h4 className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Stats</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Upvotes</span><span className="font-bold">{w.upvotes}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Forks</span><span className="font-bold">{Math.round(w.upvotes * 0.4)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Avg setup time</span><span className="font-bold">15 min</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">License</span><span className="font-bold">MIT</span></div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </Shell>
  );
}
