import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/developers/integrations")({
  head: () => ({
    meta: [
      { title: "Integrations · VibeCode" },
      { name: "description", content: "Prebuilt connectors for the tools you already use — Notion, Slack, Discord, GitHub, and 40 more." },
      { property: "og:title", content: "Integrations · VibeCode" },
      { property: "og:description", content: "Prebuilt connectors for the tools you already use — Notion, Slack, Discord, GitHub, and 40 more." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/developers/integrations" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/developers/integrations" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Integrations"
      breadcrumb={[{"label":"Developers","to":"/"}]}
      title="Plug into your stack."
      intro="Prebuilt connectors for the tools you already use — Notion, Slack, Discord, GitHub, and 40 more."
      toc={[{"id":"popular","label":"Popular integrations"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="popular" title="Popular integrations"><NotionFeatureGrid items={[{"title":"Slack","description":"Ship a post → drop a link in #wins automatically."},{"title":"Notion","description":"Sync your build log to a Notion database."},{"title":"GitHub","description":"Push a commit → auto-post a build update."},{"title":"n8n / Zapier / Make","description":"Trigger any workflow on any platform event."}]} /></NotionSection>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Do integrations cost extra?" a="No. All integrations are free on every plan." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
