import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/enterprise/talent-sourcing")({
  head: () => ({
    meta: [
      { title: "Talent Sourcing · VibeCode" },
      { name: "description", content: "Your dedicated sourcing partner for AI and vibe-coding hires in India. We shortlist, you interview." },
      { property: "og:title", content: "Talent Sourcing · VibeCode" },
      { property: "og:description", content: "Your dedicated sourcing partner for AI and vibe-coding hires in India. We shortlist, you interview." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/enterprise/talent-sourcing" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/enterprise/talent-sourcing" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Talent Sourcing"
      breadcrumb={[{"label":"Enterprise","to":"/"}]}
      title="Vetted builders. On demand."
      intro="Your dedicated sourcing partner for AI and vibe-coding hires in India. We shortlist, you interview."
      toc={[{"id":"how","label":"How it works"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="how" title="How it works"><NotionList items={["Kickoff call — we scope the role, stack, and culture in 30 minutes","Shortlist in 72 hours — 5-8 pre-screened builders with portfolios","You interview — we handle scheduling, reference checks, and offer prep","Placement guarantee — free replacement in the first 90 days"]} /></NotionSection>
      <NotionCallout emoji="🎯" tone="coral">Flat fee, no percentage of CTC. Talk to sales for a quote scoped to your hiring plan.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Which roles do you fill?" a="ML engineers, AI product engineers, prompt engineers, MLOps, and applied research." />
          <NotionToggle q="Do you do contract-to-hire?" a="Yes — many of our placements start as 3-month contracts." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
