import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/resources/events")({
  head: () => ({
    meta: [
      { title: "Events & Meetups · VibeCode" },
      { name: "description", content: "Monthly meetups across Bangalore, Delhi, Mumbai, Hyderabad, and Pune. Ship demos, meet hirers, drink chai." },
      { property: "og:title", content: "Events & Meetups · VibeCode" },
      { property: "og:description", content: "Monthly meetups across Bangalore, Delhi, Mumbai, Hyderabad, and Pune. Ship demos, meet hirers, drink chai." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/resources/events" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/resources/events" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Events & Meetups"
      breadcrumb={[{"label":"Resources","to":"/"}]}
      title="IRL vibe sessions."
      intro="Monthly meetups across Bangalore, Delhi, Mumbai, Hyderabad, and Pune. Ship demos, meet hirers, drink chai."
      toc={[{"id":"kinds","label":"What we host"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="kinds" title="What we host"><NotionFeatureGrid items={[{"title":"Demo nights","description":"Ship-and-tell with 8 builders per city."},{"title":"Hiring mixers","description":"Startups meet builders. No suits."},{"title":"Hackathons","description":"48-hour builds with cash prizes."},{"title":"Workshops","description":"Hands-on sessions with tool creators."}]} /></NotionSection>
      <NotionCallout emoji="📍" tone="cream">All events are free for verified builders. RSVP opens 10 days before each meetup.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="How do I host one in my city?" a="DM us — we sponsor venue, food, and swag for community-run events." />
          <NotionToggle q="Are events online?" a="Some. Most are IRL because that is where hiring actually happens." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
