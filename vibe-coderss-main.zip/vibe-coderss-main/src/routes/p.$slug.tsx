import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Shell } from "@/components/site/Shell";
import { CoralWord } from "@/components/site/SectionHeader";

type Page = { title: string; tagline: string; body: { h?: string; p?: string; list?: string[] }[]; cta?: { label: string; to?: string; href?: string } };

const PAGES: Record<string, Page> = {
  about: {
    title: "About VibeCode",
    tagline: "India's largest community of AI builders.",
    body: [
      { p: "VibeCode started in 2024 as a Telegram group of 30 indie hackers shipping with Lovable and Cursor. Today it's home to 120,000+ AI builders across India — solo founders, agencies, students and product folks at AI-first startups." },
      { h: "Our mission", p: "Make it stupidly easy for any builder in India to ship AI-first products, find collaborators, and get paid for their craft." },
      { h: "What we believe", list: ["Builders > talkers", "Open knowledge beats locked playbooks", "Indian builders deserve world-class tooling", "Shipping in public is the new resume"] },
    ],
    cta: { label: "Join the community", to: "/signup" },
  },
  manifesto: {
    title: "The VibeCode Manifesto",
    tagline: "Why we exist, in plain words.",
    body: [
      { p: "We're done waiting for permission. We don't need a CS degree, a YC stamp, or a Silicon Valley address to build the next decade of software." },
      { h: "We are vibe coders.", p: "We ship in public. We sweat the details. We share our prompts and our workflows. We help each other before we help ourselves." },
      { h: "Our promises", list: ["Free forever for builders","Zero recruiter spam","No commission on freelance income","Open templates, open workflows, open prompts","Built by builders, owned by builders"] },
    ],
  },
  press: { title: "Press Kit", tagline: "Logos, founder bios, brand assets.", body: [{ p: "For press inquiries write to press@vibecode.in. Brand assets and product screenshots are available on request." }] },
  brand: { title: "Brand Guidelines", tagline: "Use our name and marks the right way.", body: [{ h: "Logo", p: "Use the wordmark on cream or dark backgrounds. Don't recolour the coral period." }, { h: "Voice", list: ["Warm, chunky, builder-first","Hindi/English code-switching is welcome","No corporate jargon, ever"] }] },
  playbook: { title: "Founder Playbook", tagline: "How indie founders ship with AI.", body: [{ p: "A growing collection of essays, teardowns and templates from founders shipping AI products in India." }, { list: ["From idea to MVP in a weekend","Pricing your first SaaS","Hiring your first vibe coder","Going from $0 to $10K MRR with Lovable"] }] },
  api: { title: "VibeCode API", tagline: "Public APIs are coming soon.", body: [{ p: "We're shipping a public API for builders directories, jobs, and the templates library. Drop us a note if you want early access." }] },
  status: { title: "Status", tagline: "All systems operational.", body: [{ list: ["API · operational","Website · operational","Auth · operational","Email · operational","Search · operational"] }, { p: "Subscribe to incidents at status@vibecode.in." }] },
  tutorials: { title: "Tutorials", tagline: "Step-by-step videos and walk-throughs.", body: [{ p: "From your first Lovable app to advanced n8n agent workflows — community-contributed tutorials, all free." }] },
  blog: { title: "Build Logs", tagline: "Notes from the road.", body: [{ p: "Founder essays, behind-the-scenes ships, and community highlights. New posts every week." }] },
  changelog: { title: "Changelog", tagline: "Everything we shipped.", body: [{ h: "v2.4 — June 2026", list: ["Mobile hamburger menu","Two new libraries: Tools + Templates","Public submission flow for builders, jobs, services"] }, { h: "v2.3 — May 2026", list: ["Neo-brutalist visual refresh","Counter animations","Real brand logos via simple-icons"] }] },
  help: { title: "Help Center", tagline: "Get unblocked, fast.", body: [{ h: "Popular topics", list: ["Creating your profile","Posting a job","Listing a service","Joining a community","Reporting a bug"] }, { p: "Can't find an answer? Email hello@vibecode.in." }] },
  guide: { title: "Builder Guide", tagline: "The opinionated guide to shipping AI.", body: [{ list: ["Pick a tool stack and stick to it for 90 days","Ship in public — every Friday","One project, one community, one job channel","Bill in INR, charge in USD when you can"] }] },
  privacy: { title: "Privacy Policy", tagline: "What we collect and why.", body: [{ p: "We collect the minimum needed to run the platform: email, profile data, and analytics events. We never sell your data. We never share your email with recruiters or third parties." }, { h: "Your rights", list: ["Export your data anytime","Delete your account in one click","Opt out of all marketing"] }] },
  terms: { title: "Terms of Service", tagline: "The rules of using VibeCode.", body: [{ p: "By using VibeCode you agree to these terms. You're responsible for the content you post. We can suspend accounts that violate our Code of Conduct." }] },
  coc: { title: "Code of Conduct", tagline: "Be a good human.", body: [{ list: ["No harassment, hate, or discrimination","No recruiter spam","No misleading job posts","No copy-pasted prompts without credit","Help newcomers — we all started somewhere"] }] },
  cookies: { title: "Cookie Policy", tagline: "What we store in your browser.", body: [{ p: "Essential cookies for auth + theme. Anonymous analytics for product improvement. No third-party advertising cookies." }] },
  dpa: { title: "Data Processing Addendum", tagline: "For our enterprise customers.", body: [{ p: "Our DPA covers GDPR Article 28 obligations and is available on request for any paid Hiring or Enterprise plan." }] },
};

export const Route = createFileRoute("/p/$slug")({
  head: ({ params }) => ({ meta: [{ title: `${PAGES[params.slug]?.title ?? "VibeCode"} · VibeCode` }] }),
  loader: ({ params }) => {
    const page = PAGES[params.slug];
    if (!page) throw notFound();
    return { page };
  },
  notFoundComponent: () => (
    <Shell><div className="container-page py-20 text-center"><h1 className="font-display text-3xl font-extrabold">Page not found</h1><Link to="/" className="mt-4 inline-block text-coral underline">Go home</Link></div></Shell>
  ),
  component: StaticPage,
});

function StaticPage() {
  const { page } = Route.useLoaderData() as { page: Page };
  const words = page.title.split(" ");
  return (
    <Shell>
      <section className="border-b-[1.5px] border-[#0F0F0F] bg-card">
        <div className="container-page py-14">
          <h1 className="font-display text-4xl font-extrabold tracking-tight md:text-5xl">
            {words.map((w: string, i: number) => i === words.length - 1 ? <CoralWord key={i}>{w}</CoralWord> : <span key={i}>{w} </span>)}
          </h1>
          <p className="mt-3 max-w-2xl text-base text-muted-foreground md:text-lg">{page.tagline}</p>
        </div>
      </section>
      <article className="container-page py-12">
        <div className="mx-auto max-w-3xl space-y-6">
          {page.body.map((b, i: number) => (
            <div key={i} className="card-editorial p-6">
              {b.h && <h2 className="font-display text-xl font-extrabold">{b.h}</h2>}
              {b.p && <p className={`text-sm leading-relaxed text-foreground/80 ${b.h ? "mt-3" : ""}`}>{b.p}</p>}
              {b.list && (
                <ul className={`space-y-2 text-sm ${b.h || b.p ? "mt-4" : ""}`}>
                  {b.list.map((li: string) => (
                    <li key={li} className="flex gap-2"><span className="text-coral">▸</span> {li}</li>
                  ))}
                </ul>
              )}
            </div>
          ))}

          {page.cta && (
            <div className="text-center">
              {page.cta.to ? (
                <Link to={page.cta.to} className="btn-coral">{page.cta.label} →</Link>
              ) : (
                <a href={page.cta.href} className="btn-coral">{page.cta.label} →</a>
              )}
            </div>
          )}
        </div>
      </article>
    </Shell>
  );
}
