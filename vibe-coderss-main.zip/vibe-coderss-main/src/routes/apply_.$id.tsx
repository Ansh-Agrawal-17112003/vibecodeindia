import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Upload, CheckCircle2, Briefcase, MapPin, IndianRupee, FileText } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { allJobs } from "@/lib/mock-data";

export const Route = createFileRoute("/apply_/$id")({
  component: ApplyPage,
});

function ApplyPage() {
  const { id } = Route.useParams();
  const job = allJobs().find((x) => x.id === id);
  const navigate = useNavigate();
  const [step, setStep] = useState<"form" | "done">("form");
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    location: "",
    experience: "0-2",
    role: "",
    interest: "",
    portfolio: "",
    cover: "",
  });
  const [resume, setResume] = useState<File | null>(null);

  if (!job) return <Shell><div className="container-page py-20 text-center text-muted-foreground">Job not found.</div></Shell>;

  function set<K extends keyof typeof form>(k: K, v: string) { setForm((f) => ({ ...f, [k]: v })); }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !form.email) { toast.error("Name and email are required"); return; }
    if (!resume) { toast.error("Please attach your resume (PDF)"); return; }
    if (resume.type !== "application/pdf") { toast.error("Resume must be a PDF file"); return; }
    if (resume.size > 10 * 1024 * 1024) { toast.error("Resume must be under 10MB"); return; }
    setStep("done");
  }

  if (step === "done") {
    return (
      <Shell>
        <div className="container-page grid place-items-center py-16">
          <div className="card-editorial max-w-lg p-8 text-center">
            <CheckCircle2 className="mx-auto h-14 w-14 text-coral" />
            <h1 className="mt-3 font-display text-2xl font-extrabold">Application sent!</h1>
            <p className="mt-2 text-sm text-muted-foreground">Your application for <b>{job.title}</b> at <b>{job.company}</b> has been submitted. The team will reach out via email at <b>{form.email}</b>.</p>
            <div className="mt-5 flex flex-wrap justify-center gap-2">
              <Link to="/jobs" className="btn-coral h-10 px-4">Browse more jobs</Link>
              <button onClick={() => navigate({ to: "/jobs/$id", params: { id: job.id } })} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-4 py-2 text-sm font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>Back to job</button>
            </div>
          </div>
        </div>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="container-page py-6">
        <Link to="/jobs/$id" params={{ id: job.id }} className="inline-flex items-center gap-1.5 text-xs font-bold text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3 w-3" /> Back to job
        </Link>

        <div className="mt-4 grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
          <form onSubmit={submit} className="card-editorial min-w-0 p-5 md:p-7">
            <h1 className="font-display text-2xl font-extrabold md:text-3xl">Apply for {job.title}</h1>
            <p className="mt-1 text-sm text-muted-foreground">Fill in the details below — takes under 2 minutes.</p>

            <h3 className="mt-6 font-display text-sm font-extrabold uppercase tracking-wider text-coral">Basic details</h3>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Field label="Full name *"><input required value={form.name} onChange={(e) => set("name", e.target.value)} className={input} placeholder="Priya Sharma" /></Field>
              <Field label="Email *"><input required type="email" value={form.email} onChange={(e) => set("email", e.target.value)} className={input} placeholder="you@email.com" /></Field>
              <Field label="Phone"><input value={form.phone} onChange={(e) => set("phone", e.target.value)} className={input} placeholder="+91 9xxxxxxxxx" /></Field>
              <Field label="Location"><input value={form.location} onChange={(e) => set("location", e.target.value)} className={input} placeholder="Bengaluru, India" /></Field>
            </div>

            <h3 className="mt-6 font-display text-sm font-extrabold uppercase tracking-wider text-coral">Experience</h3>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Field label="Years of experience">
                <select value={form.experience} onChange={(e) => set("experience", e.target.value)} className={input}>
                  <option value="0-1">0 – 1 years</option>
                  <option value="1-3">1 – 3 years</option>
                  <option value="3-5">3 – 5 years</option>
                  <option value="5-8">5 – 8 years</option>
                  <option value="8+">8+ years</option>
                </select>
              </Field>
              <Field label="Current role / title"><input value={form.role} onChange={(e) => set("role", e.target.value)} className={input} placeholder="Full-stack Engineer" /></Field>
              <Field label="Portfolio / LinkedIn / GitHub" full><input value={form.portfolio} onChange={(e) => set("portfolio", e.target.value)} className={input} placeholder="https://github.com/…" /></Field>
            </div>

            <h3 className="mt-6 font-display text-sm font-extrabold uppercase tracking-wider text-coral">Interest</h3>
            <Field label="Why are you a great fit for this role?">
              <textarea rows={5} value={form.interest} onChange={(e) => set("interest", e.target.value)} className={input} placeholder="Tell us about relevant projects, what excites you about this role, and what you'd ship in the first 30 days…" />
            </Field>

            <h3 className="mt-6 font-display text-sm font-extrabold uppercase tracking-wider text-coral">Resume</h3>
            <label className="mt-3 flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-[1.5px] border-dashed border-[#0F0F0F] bg-card p-6 text-center transition hover:bg-background">
              <Upload className="h-6 w-6" />
              <div className="text-sm font-bold">{resume ? resume.name : "Click to upload your resume from your computer"}</div>
              <div className="text-xs text-muted-foreground">{resume ? `${(resume.size / 1024).toFixed(0)} KB · PDF` : "PDF only · Max 10MB"}</div>
              <input type="file" accept="application/pdf,.pdf" className="hidden" onChange={(e) => setResume(e.target.files?.[0] ?? null)} />
            </label>
            {resume && (
              <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                <FileText className="h-3.5 w-3.5" /> {resume.name}
                <button type="button" onClick={() => setResume(null)} className="ml-auto font-bold text-coral hover:underline">Remove</button>
              </div>
            )}

            <button type="submit" className="btn-coral mt-7 h-12 w-full text-base">Submit application →</button>
          </form>

          <aside className="min-w-0 space-y-4 lg:sticky lg:top-20 lg:self-start">
            <div className="card-editorial p-5">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">You're applying for</div>
              <h3 className="mt-2 font-display text-lg font-extrabold">{job.title}</h3>
              <div className="mt-1 text-sm font-bold">{job.company}</div>
              <dl className="mt-4 space-y-2 text-sm">
                <SidebarRow icon={Briefcase} k="Type" v={job.type} />
                <SidebarRow icon={MapPin} k="Location" v={`${job.remote} · ${job.location}`} />
                <SidebarRow icon={IndianRupee} k="Salary" v={job.salary} />
              </dl>
            </div>
          </aside>
        </div>
      </div>
    </Shell>
  );
}

const input = "w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-coral/30";

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <label className={`block ${full ? "sm:col-span-2" : ""}`}>
      <span className="mb-1 block text-xs font-bold text-foreground">{label}</span>
      {children}
    </label>
  );
}

function SidebarRow({ icon: Icon, k, v }: { icon: any; k: string; v: string }) {
  return (
    <div className="flex items-start gap-2">
      <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
      <div className="min-w-0 flex-1">
        <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{k}</div>
        <div className="break-words text-sm font-bold [overflow-wrap:anywhere]">{v}</div>
      </div>
    </div>
  );
}
