import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowUp, Bookmark, Share2 } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getBuilder, projects } from "@/lib/mock-data";
import { sharePage } from "@/lib/share";

export const Route = createFileRoute("/projects/$id")({
  loader: ({ params }) => {
    const p = projects.find((x) => x.id === params.id);
    if (!p) throw notFound();
    return { project: p };
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.project.title} · VibeCode` }] }),
  component: ProjectDetail,
  notFoundComponent: () => <Shell><div className="container-page py-20 text-center text-muted-foreground">Project not found.</div></Shell>,
});

function ProjectDetail() {
  const { project: p } = Route.useLoaderData();
  const b = getBuilder(p.builderId);
  const related = projects.filter((x) => x.id !== p.id).slice(0, 3);

  return (
    <Shell>
      <div className="container-page py-8">
        <div className="mb-6 text-xs text-muted-foreground">
          <Link to="/explore" className="hover:text-foreground">Explore</Link> / <span className="text-foreground">{p.title}</span>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <div>
            <div className="card-surface overflow-hidden">
              <img src={p.cover} alt={p.title} className="aspect-[16/9] w-full object-cover" />
            </div>
            <div className="mt-6">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded border border-border px-2 py-0.5 text-[10px] text-muted-foreground">{p.industry}</span>
              </div>
              <h1 className="mt-3 text-3xl font-semibold tracking-tight">{p.title}</h1>
              <div className="mt-3 flex items-center gap-3">
                <img src={b.avatar} className="h-8 w-8 rounded-full" alt="" />
                <div className="text-sm">
                  <Link to="/u/$username" params={{ username: b.username }} className="font-medium hover:text-primary">{b.name}</Link>
                  <span className="text-muted-foreground"> · {p.date}</span>
                </div>
              </div>
            </div>

            <Tabs defaultValue="overview" className="mt-6">
              <TabsList className="border-b border-border bg-transparent">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="case">Case Study</TabsTrigger>
                <TabsTrigger value="stack">Tech Stack</TabsTrigger>
                <TabsTrigger value="links">Links</TabsTrigger>
              </TabsList>
              <TabsContent value="overview" className="space-y-5 py-6">
                <Section heading="Problem">
                  <p>{p.description} Existing solutions are clunky, expensive, or built for the US market.</p>
                </Section>
                <Section heading="Solution">
                  <p>A focused, India-first AI workflow that solves the core job-to-be-done in under 60 seconds.</p>
                </Section>
                <Section heading="Outcomes">
                  <ul className="list-inside list-disc space-y-1 text-foreground/90">
                    <li>Saved customers ~14 hours/week per user</li>
                    <li>5,200 monthly active users in the first quarter</li>
                    <li>NPS of 62 across 320 surveys</li>
                  </ul>
                </Section>
              </TabsContent>
              <TabsContent value="case" className="prose prose-invert py-6">
                <p className="leading-relaxed text-foreground/90">Full case study with research, design iterations, technical decisions and post-launch learnings would render here as rich markdown.</p>
              </TabsContent>
              <TabsContent value="stack" className="py-6">
                <div className="grid gap-3 sm:grid-cols-2">
                  {p.tools.map((t: string) => (
                    <div key={t} className="card-surface p-4">
                      <div className="font-mono text-sm text-primary">{t}</div>
                      <div className="mt-1 text-xs text-muted-foreground">Used for core product workflows.</div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="links" className="py-6">
                <div className="space-y-2">
                  <a href="#" className="card-surface block p-3 text-sm hover:border-primary">Live Demo ↗</a>
                  <a href="#" className="card-surface block p-3 text-sm hover:border-primary">GitHub ↗</a>
                  <a href="#" className="card-surface block p-3 text-sm hover:border-primary">Case Study PDF ↗</a>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <aside className="space-y-4">
            <div className="card-surface p-4">
              <button className="flex w-full items-center justify-center gap-2 rounded-md bg-primary py-2 text-sm font-medium text-primary-foreground transition hover:bg-primary-hover">
                <ArrowUp className="h-4 w-4" /> Upvote · {p.upvotes}
              </button>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button className="flex items-center justify-center gap-1.5 rounded-md border border-border bg-surface py-2 text-xs hover:border-[#333]"><Bookmark className="h-3 w-3" /> Save</button>
                <button onClick={() => sharePage(p.title, p.description)} className="flex items-center justify-center gap-1.5 rounded-md border border-border bg-surface py-2 text-xs hover:border-[#333]"><Share2 className="h-3 w-3" /> Share</button>
              </div>
            </div>
            <div className="card-surface p-4">
              <h4 className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">About the Builder</h4>
              <Link to="/u/$username" params={{ username: b.username }} className="flex items-center gap-3">
                <img src={b.avatar} className="h-10 w-10 rounded-full" alt="" />
                <div>
                  <div className="text-sm font-medium">{b.name}</div>
                  <div className="text-xs text-muted-foreground">{b.title}</div>
                </div>
              </Link>
              <p className="mt-3 line-clamp-3 text-xs text-muted-foreground">{b.bio}</p>
            </div>
            <div className="card-surface p-4">
              <h4 className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Related</h4>
              <div className="space-y-2">
                {related.map((r) => (
                  <Link key={r.id} to="/projects/$id" params={{ id: r.id }} className="flex gap-3 hover:opacity-80">
                    <img src={r.cover} alt="" className="h-12 w-16 rounded object-cover" />
                    <div className="min-w-0 flex-1 text-xs">
                      <div className="line-clamp-2 font-medium text-foreground">{r.title}</div>
                      <div className="mt-1 text-muted-foreground">▲ {r.upvotes}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </Shell>
  );
}

function Section({ heading, children }: { heading: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-2 text-sm font-medium uppercase tracking-wider text-muted-foreground">{heading}</h3>
      <div className="leading-relaxed text-foreground/90">{children}</div>
    </div>
  );
}
