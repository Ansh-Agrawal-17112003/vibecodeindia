import { createFileRoute } from "@tanstack/react-router";
import { VibeHome } from "@/components/vibe/VibeHome";
import { Landing, FAQ } from "@/routes/landing";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VibeCode — India's Largest AI Builder Community" },
      { name: "description", content: "The home feed for India's AI builders. Ship in public, share prompts, workflows and projects, and get discovered by 120,000+ vibe coders." },
      { property: "og:title", content: "VibeCode — India's Largest AI Builder Community" },
      { property: "og:description", content: "Home feed for AI builders in India. Projects, prompts, workflows, jobs and communities." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: FAQ.map((f) => ({
            "@type": "Question",
            name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
        }),
      },
    ],
  }),
  component: IndexRoute,
});

function IndexRoute() {
  const { session, loading } = useAuth();

  if (loading) {
    return (
      <div style={{ height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#FAF6F1" }}>
        <div style={{ textAlign: "center" }}>
          <div
            style={{
              width: 40,
              height: 40,
              border: "3px solid #E8E0D6",
              borderTop: "3px solid #E8623A",
              borderRadius: "50%",
              animation: "vc-spin 0.8s linear infinite",
              margin: "0 auto 12px",
            }}
          />
          <p style={{ color: "#999", fontSize: 14 }}>Loading VibeCode...</p>
        </div>
        <style>{`@keyframes vc-spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return session ? <VibeHome /> : <Landing />;
}
