import { createFileRoute } from "@tanstack/react-router";
import { ProductPageShell } from "@/components/product-page/ProductPageShell";
import { PRODUCT_PAGES } from "@/lib/product-pages";

const cfg = PRODUCT_PAGES["vibe-feed"];

export const Route = createFileRoute("/product/vibe-feed")({
  head: () => ({
    meta: [
      { title: cfg.meta.title },
      { name: "description", content: cfg.meta.description },
      { property: "og:title", content: cfg.meta.title },
      { property: "og:description", content: cfg.meta.description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <ProductPageShell config={cfg} />,
});
