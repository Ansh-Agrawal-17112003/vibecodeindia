import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, Check, Shield, Lock, Sparkles, CreditCard, Smartphone, Building2, Wallet, QrCode, Clock } from "lucide-react";
import { toast } from "sonner";
import { Shell } from "@/components/site/Shell";
import { PaymentOTPModal } from "@/components/site/PaymentOTPModal";
import { allServices, services, getBuilder } from "@/lib/mock-data";
import { PAYEE_UPI_ID, PAYEE_NAME, upiIntent, upiQrUrl } from "@/lib/payee";
import { PaymentBrand } from "@/components/site/PaymentBrand";

export const Route = createFileRoute("/checkout/service/$id")({
  loader: ({ params }) => {
    const s = allServices().find((x) => x.id === params.id) ?? services.find((x) => x.id === params.id);
    if (!s) throw notFound();
    return { service: s };
  },
  component: ServiceCheckout,
  notFoundComponent: () => (
    <Shell>
      <div className="container-page py-20 text-center text-muted-foreground">Service not found.</div>
    </Shell>
  ),
});

type Method = "upi" | "card" | "netbanking" | "wallet" | "qr";

const UPI_APPS = [
  { id: "gpay", name: "Google Pay", slug: "googlepay" },
  { id: "phonepe", name: "PhonePe", slug: "phonepe", color: "5F259F" },
  { id: "paytm", name: "Paytm", slug: "paytm" },
  { id: "amazonpay", name: "Amazon Pay", slug: "amazonpay" },
  { id: "cred", name: "CRED", slug: "cred", color: "0F0F0F" },
  { id: "whatsapp", name: "WhatsApp Pay", slug: "whatsapp", color: "25D366" },
];
const BANKS = ["HDFC Bank", "ICICI Bank", "State Bank of India", "Axis Bank", "Kotak Mahindra", "Yes Bank", "IDFC FIRST", "IndusInd Bank"];
const WALLETS = [
  { id: "paytm", name: "Paytm Wallet", slug: "paytmwallet" },
  { id: "mobikwik", name: "MobiKwik", slug: "mobikwik" },
  { id: "freecharge", name: "Freecharge", slug: "freecharge" },
  { id: "amazon", name: "Amazon Pay Balance", slug: "amazonpaybalance" },
];

function ServiceCheckout() {
  const { service: s } = Route.useLoaderData();
  const b = getBuilder(s.builderId);
  const navigate = useNavigate();

  const [pkgIdx, setPkgIdx] = useState(0);
  const packages = [
    { name: "Starter", price: s.price, delivery: s.delivery },
    { name: "Standard", price: Math.round(s.price * 2.2), delivery: s.delivery + 4 },
    { name: "Premium", price: Math.round(s.price * 4.5), delivery: s.delivery + 10 },
  ];
  const pkg = packages[pkgIdx];

  const [method, setMethod] = useState<Method>("upi");
  const [gateway, setGateway] = useState<"razorpay" | "stripe" | "cashfree">("razorpay");
  const [upiId, setUpiId] = useState("");
  const [selectedUpiApp, setSelectedUpiApp] = useState<string | null>(null);
  const [card, setCard] = useState({ number: "", name: "", exp: "", cvv: "" });
  const [bank, setBank] = useState(BANKS[0]);
  const [wallet, setWallet] = useState(WALLETS[0].id);
  const [coupon, setCoupon] = useState("");
  const [discount, setDiscount] = useState(0);
  const [otpOpen, setOtpOpen] = useState(false);
  const [buyer, setBuyer] = useState({ name: "", email: "", phone: "", brief: "" });

  const platformFee = Math.round(pkg.price * 0.03);
  const gst = useMemo(() => Math.round((pkg.price + platformFee - discount) * 0.18), [pkg.price, platformFee, discount]);
  const total = Math.max(0, pkg.price + platformFee - discount + gst);

  const applyCoupon = () => {
    const c = coupon.trim().toUpperCase();
    if (c === "VIBE10") { setDiscount(Math.round(pkg.price * 0.1)); toast.success("Coupon applied — 10% off"); }
    else if (c === "INDIA50") { setDiscount(Math.round(pkg.price * 0.5)); toast.success("Coupon applied — 50% off 🎉"); }
    else { setDiscount(0); toast.error("Invalid coupon"); }
  };

  const pay = () => {
    if (!buyer.name.trim() || !/^\S+@\S+\.\S+$/.test(buyer.email) || buyer.phone.length < 10) {
      toast.error("Please fill your name, valid email and phone");
      return;
    }
    if (method === "upi" && !selectedUpiApp && !/^[\w.\-]{2,}@[\w]{2,}$/.test(upiId)) {
      toast.error("Enter a valid UPI ID or pick an app");
      return;
    }
    if (method === "card" && (card.number.replace(/\s/g, "").length < 12 || card.cvv.length < 3)) {
      toast.error("Enter valid card details");
      return;
    }
    setOtpOpen(true);
  };

  const onVerified = async () => {
    toast.success(`₹${total.toLocaleString("en-IN")} paid to ${b.name} via ${gateway.toUpperCase()}`);
    navigate({ to: "/" });
  };

  return (
    <Shell>
      <div className="border-b-[1.5px] border-[#0F0F0F] bg-card">
        <div className="container-page py-3 md:py-4">
          <Link to="/services/$id" params={{ id: s.id }} className="inline-flex items-center gap-2 text-sm font-bold hover:text-coral">
            <ArrowLeft className="h-4 w-4" /> Back to service
          </Link>
        </div>
      </div>

      {/* MOBILE — compact price header */}
      <div className="sticky top-0 z-30 border-b-[1.5px] border-[#0F0F0F] bg-cream/95 backdrop-blur lg:hidden">
        <div className="container-page flex items-center justify-between gap-3 py-2.5">
          <div className="min-w-0">
            <div className="truncate text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{pkg.name} · {pkg.delivery}-day delivery</div>
            <div className="truncate font-display text-lg font-extrabold leading-none">₹{total.toLocaleString("en-IN")}</div>
          </div>
          <span className="pill-badge shrink-0 bg-gold text-[#0F0F0F]">ESCROW</span>
        </div>
      </div>

      <section className="container-page pb-28 pt-4 md:py-10 lg:pb-10">
        <div className="grid min-w-0 gap-5 lg:grid-cols-[minmax(0,1fr)_400px] lg:gap-8">
          <div className="space-y-4 md:space-y-6">
            <div className="hidden md:block">
              <span className="pill-badge bg-gold text-[#0F0F0F]">SECURE CHECKOUT · ESCROW</span>
              <h1 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Order this service</h1>
              <p className="mt-2 text-sm text-muted-foreground md:text-base">Funds are held in escrow and released to the seller only after you approve delivery.</p>
            </div>


            {/* Package selector */}
            <div className="card-editorial p-5">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Choose your package</div>
              <div className="mt-3 grid gap-2 sm:grid-cols-3">
                {packages.map((p, i) => (
                  <button key={p.name} onClick={() => setPkgIdx(i)} className={`rounded-lg border-[1.5px] border-[#0F0F0F] p-3 text-left transition ${pkgIdx === i ? "bg-coral text-white shadow-[4px_4px_0_0_#0F0F0F]" : "bg-white hover:bg-cream"}`}>
                    <div className="font-display text-sm font-extrabold">{p.name}</div>
                    <div className="mt-1 font-display text-lg font-extrabold">₹{p.price.toLocaleString("en-IN")}</div>
                    <div className="mt-0.5 flex items-center gap-1 text-[11px] opacity-80"><Clock className="h-3 w-3" /> {p.delivery} days</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Buyer details */}
            <div className="card-editorial p-5">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Your details</div>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <input value={buyer.name} onChange={(e) => setBuyer({ ...buyer, name: e.target.value })} placeholder="Full name" className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                <input value={buyer.email} onChange={(e) => setBuyer({ ...buyer, email: e.target.value })} placeholder="Email for invoice" className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                <input value={buyer.phone} onChange={(e) => setBuyer({ ...buyer, phone: e.target.value.replace(/\D/g, "").slice(0, 10) })} placeholder="Phone (10 digits)" className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                <textarea value={buyer.brief} onChange={(e) => setBuyer({ ...buyer, brief: e.target.value })} placeholder="Short brief for the seller (optional)" className="sm:col-span-2 min-h-[80px] rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
              </div>
            </div>

            {/* Gateway */}
            <div className="card-editorial p-4 sm:p-5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Payment gateway</div>
              <div className="mt-2.5 grid grid-cols-3 gap-2 sm:gap-3">
                {(["razorpay", "stripe", "cashfree"] as const).map((g) => (
                  <button key={g} onClick={() => setGateway(g)} className={`rounded-lg border-[1.5px] border-[#0F0F0F] px-2 py-2.5 text-xs font-bold capitalize transition sm:py-3 sm:text-sm ${gateway === g ? "bg-[#0F0F0F] text-white shadow-[3px_3px_0_0_#E8623A]" : "bg-white hover:bg-cream"}`}>
                    {g}
                  </button>
                ))}
              </div>
            </div>

            {/* Method */}
            <div className="card-editorial p-4 sm:p-5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Payment method</div>
              <div className="mt-2.5 grid grid-cols-5 gap-1.5 sm:gap-2">
                {([
                  { id: "upi", icon: Smartphone, label: "UPI" },
                  { id: "card", icon: CreditCard, label: "Card" },
                  { id: "netbanking", icon: Building2, label: "Bank" },
                  { id: "wallet", icon: Wallet, label: "Wallet" },
                  { id: "qr", icon: QrCode, label: "QR" },
                ] as const).map((m) => (
                  <button key={m.id} onClick={() => setMethod(m.id)} className={`flex flex-col items-center gap-1 rounded-lg border-[1.5px] border-[#0F0F0F] px-1 py-2.5 text-[10px] font-bold transition sm:py-3 sm:text-xs ${method === m.id ? "bg-coral text-white shadow-[3px_3px_0_0_#0F0F0F]" : "bg-white hover:bg-cream"}`}>
                    <m.icon className="h-4 w-4 sm:h-5 sm:w-5" /> {m.label}
                  </button>
                ))}
              </div>

              <div className="mt-5 sm:mt-6">
                {method === "upi" && (
                  <div className="space-y-4">
                    <div className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-cream px-3 py-2 text-[11px] sm:text-xs">
                      Paying to <b>{PAYEE_NAME}</b> · <span className="font-mono font-bold">{PAYEE_UPI_ID}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
                      {UPI_APPS.map((a) => (
                        <a
                          key={a.id}
                          href={upiIntent({ amount: total, note: `VibeCode svc ${s.id}`, ref: `svc-${s.id}-${Date.now()}` })}
                          onClick={() => setSelectedUpiApp(a.id)}
                          className={`flex flex-col items-center gap-1.5 rounded-lg border-[1.5px] border-[#0F0F0F] p-2 text-[10px] font-bold leading-tight transition sm:p-3 sm:text-[11px] ${selectedUpiApp === a.id ? "bg-cream shadow-[3px_3px_0_0_#0F0F0F]" : "bg-white hover:bg-cream"}`}
                        >
                          <span className="flex h-9 w-full items-center justify-center rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-1.5 py-1 sm:h-12 sm:px-3 sm:py-1.5">
                            <PaymentBrand slug={a.slug} color={a.color} alt={a.name} className="h-full w-full object-contain" />
                          </span>
                          <span className="truncate">{a.name}</span>
                        </a>
                      ))}
                    </div>
                    <div className="text-center text-[10px] font-bold text-muted-foreground sm:text-xs">— OR ENTER UPI ID FOR A COLLECT REQUEST —</div>
                    <input value={upiId} onChange={(e) => { setUpiId(e.target.value); setSelectedUpiApp(null); }} placeholder="yourname@okhdfc" className="w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                  </div>
                )}

                {method === "card" && (
                  <div className="grid gap-3 sm:grid-cols-2">
                    <input value={card.number} onChange={(e) => setCard({ ...card, number: e.target.value.replace(/[^\d ]/g, "").slice(0, 19) })} placeholder="1234 5678 9012 3456" className="sm:col-span-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                    <input value={card.name} onChange={(e) => setCard({ ...card, name: e.target.value })} placeholder="Name on card" className="sm:col-span-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                    <input value={card.exp} onChange={(e) => setCard({ ...card, exp: e.target.value.replace(/[^\d/]/g, "").slice(0, 5) })} placeholder="MM/YY" className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                    <input value={card.cvv} onChange={(e) => setCard({ ...card, cvv: e.target.value.replace(/\D/g, "").slice(0, 4) })} placeholder="CVV" type="password" className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />

                    <div className="sm:col-span-2 flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-3 sm:gap-4 sm:px-4">
                      <span className="w-full text-[11px] font-bold uppercase tracking-wider text-muted-foreground sm:w-auto">Accepted:</span>
                      <PaymentBrand slug="visa" alt="Visa" className="h-6 w-auto sm:h-7" />
                      <PaymentBrand slug="mastercard" alt="Mastercard" className="h-6 w-auto sm:h-7" />
                      <PaymentBrand slug="americanexpress" alt="American Express" className="h-6 w-auto sm:h-7" />
                      <PaymentBrand slug="dinersclub" alt="Diners Club" className="h-6 w-auto sm:h-7" />
                      <span className="rounded border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] px-2 py-1 text-[10px] font-extrabold tracking-wider text-white sm:text-[11px]">RuPay</span>
                    </div>
                    <p className="sm:col-span-2 text-xs text-muted-foreground">Visa, Mastercard, RuPay, Amex &amp; Diners supported.</p>
                  </div>
                )}

                {method === "netbanking" && (
                  <select value={bank} onChange={(e) => setBank(e.target.value)} className="w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none">
                    {BANKS.map((bk) => <option key={bk}>{bk}</option>)}
                  </select>
                )}

                {method === "wallet" && (
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-2">
                    {WALLETS.map((w) => (
                      <button key={w.id} onClick={() => setWallet(w.id)} className={`flex items-center justify-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] px-4 py-4 text-xs font-bold transition ${wallet === w.id ? "bg-cream shadow-[3px_3px_0_0_#0F0F0F]" : "bg-white hover:bg-cream"}`}>
                        <span className="flex h-10 w-full items-center justify-center">
                          <PaymentBrand slug={w.slug} alt={w.name} className="h-10 w-auto max-w-full object-contain" />
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {method === "qr" && (
                  <div className="flex flex-col items-center gap-3 py-4">
                    <img
                      src={upiQrUrl({ amount: total, note: `VibeCode svc ${s.id}`, ref: `svc-${s.id}-${Date.now()}`, size: 260 })}
                      alt={`Scan to pay ₹${total} to ${PAYEE_UPI_ID}`}
                      className="h-56 w-56 rounded-md border-[1.5px] border-[#0F0F0F] bg-white p-2"
                    />
                    <p className="text-sm font-bold">Scan with any UPI app</p>
                    <p className="text-xs text-muted-foreground"><span className="font-mono font-bold">{PAYEE_UPI_ID}</span> · ₹{total.toLocaleString("en-IN")}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><Lock className="h-3.5 w-3.5" /> 256-bit SSL</span>
              <span className="inline-flex items-center gap-1.5"><Shield className="h-3.5 w-3.5" /> PCI DSS compliant</span>
              <span className="inline-flex items-center gap-1.5"><Sparkles className="h-3.5 w-3.5" /> Escrow-protected</span>
            </div>
          </div>

          {/* Summary */}
          <aside className="min-w-0 lg:sticky lg:top-24 lg:self-start">
            <div className="card-editorial w-full max-w-full overflow-hidden p-4 sm:p-5 md:p-6">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Order summary</div>
              <div className="mt-2 min-w-0 break-words font-display text-xl font-extrabold leading-tight">{s.title}</div>
              <div className="mt-1 text-sm text-muted-foreground">by {b.name}</div>

              <div className="mt-4 grid grid-cols-[auto_minmax(0,1fr)] items-center gap-2">
                <span className="pill-badge shrink-0 bg-coral text-white">{pkg.name}</span>
                <span className="min-w-0 text-xs text-muted-foreground"><Clock className="mr-1 inline h-3 w-3" />{pkg.delivery}-day delivery</span>
              </div>

              <div className="mt-5 grid grid-cols-[minmax(0,1fr)_auto] gap-2 border-t-[1.5px] border-dashed border-[#0F0F0F]/30 pt-4">
                <input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="Coupon code" className="min-w-0 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-sm focus:outline-none" />
                <button onClick={applyCoupon} className="shrink-0 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-sm font-bold hover:bg-cream">Apply</button>
              </div>
              <p className="mt-1.5 text-[11px] text-muted-foreground">Try <b>VIBE10</b> or <b>INDIA50</b></p>

              <div className="mt-4 space-y-1.5 text-sm">
                <Row label={`${pkg.name} package`} value={`₹${pkg.price.toLocaleString("en-IN")}`} />
                <Row label="Platform fee (3%)" value={`₹${platformFee.toLocaleString("en-IN")}`} />
                {discount > 0 && <Row label="Discount" value={`− ₹${discount.toLocaleString("en-IN")}`} accent />}
                <Row label="GST (18%)" value={`₹${gst.toLocaleString("en-IN")}`} />
                <div className="my-2 border-t-[1.5px] border-[#0F0F0F]" />
                <Row label="Total" value={`₹${total.toLocaleString("en-IN")}`} bold />
              </div>

              <button onClick={pay} className="btn-coral mt-5 w-full justify-center text-center">
                Pay ₹{total.toLocaleString("en-IN")} securely
              </button>
              <p className="mt-3 text-center text-[11px] text-muted-foreground">By paying, you agree to VibeCode's escrow terms. 100% refund if seller doesn't deliver.</p>
            </div>
          </aside>
        </div>
      </section>

      {/* MOBILE — sticky bottom pay bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t-[1.5px] border-[#0F0F0F] bg-cream/95 backdrop-blur lg:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="container-page flex items-center gap-3 py-2.5">
          <div className="min-w-0 flex-1">
            <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Total payable</div>
            <div className="font-display text-xl font-extrabold leading-none">₹{total.toLocaleString("en-IN")}</div>
          </div>
          <button onClick={pay} className="btn-coral shrink-0 px-5 py-3 text-sm">Pay securely →</button>
        </div>
      </div>


      <PaymentOTPModal
        open={otpOpen}
        onOpenChange={setOtpOpen}
        amount={total}
        purpose={`service:${s.id}:${pkg.name}`}
        reference={`${gateway}-svc-${s.id}-${Date.now()}`}
        method={method.toUpperCase()}
        onVerified={onVerified}
      />
    </Shell>
  );
}

function Row({ label, value, bold, accent }: { label: string; value: string; bold?: boolean; accent?: boolean }) {
  return (
    <div className={`grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-3 ${bold ? "font-display text-lg font-extrabold" : ""} ${accent ? "text-coral" : ""}`}>
      <span className="min-w-0 break-words">{label}</span><span className="shrink-0 whitespace-nowrap text-right">{value}</span>
    </div>
  );
}
