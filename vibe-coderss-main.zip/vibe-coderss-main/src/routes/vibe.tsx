import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { VibeHome } from "@/components/vibe/VibeHome";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/vibe")({
  head: () => ({
    meta: [
      { title: 'Vibe Feed · VibeCode' },
      { name: "description", content: "The live feed for India's AI builders — projects, prompts, workflows and jobs, in real time." },
      { property: "og:title", content: 'Vibe Feed · VibeCode' },
      { property: "og:description", content: "The live feed for India's AI builders — projects, prompts, workflows and jobs, in real time." },
      { property: "og:url", content: 'https://joinvibecode.xyz/vibe' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Vibe Feed · VibeCode' },
      { name: "twitter:description", content: "The live feed for India's AI builders — projects, prompts, workflows and jobs, in real time." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/vibe' }],
  }),
  component: VibeRoute,
});

function VibeRoute() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !session) navigate({ to: "/landing", replace: true });
  }, [loading, session, navigate]);

  if (loading || !session) return null;
  return <VibeHome />;
}
