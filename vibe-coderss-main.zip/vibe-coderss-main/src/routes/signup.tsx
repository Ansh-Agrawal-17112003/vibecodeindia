import { createFileRoute, Link } from "@tanstack/react-router";
import { Github, Check } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/signup")({
  head: () => ({ meta: [{ title: "Join VibeCode" }] }),
  component: SignupPage,
});

function SignupPage() {
  const [step, setStep] = useState(0);
  return (
    <div className="grid min-h-screen place-items-center px-6 py-10">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-8 flex items-center justify-center gap-2">
          <div className="h-7 w-7 rounded-md bg-gradient-to-br from-primary to-[#8b5cf6]" />
          <span className="font-display text-lg font-semibold">vibecode</span>
        </Link>
        <div className="card-surface p-6">
          {/* Stepper */}
          <div className="mb-6 flex items-center gap-2">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className={`h-1 flex-1 rounded-full ${i <= step ? "bg-primary" : "bg-border"}`} />
            ))}
          </div>

          {step === 0 && (
            <>
              <h1 className="text-xl font-semibold">Create your account</h1>
              <p className="mt-1 text-sm text-muted-foreground">Join 12,000+ AI builders.</p>
              <div className="mt-6 space-y-2">
                <button className="flex w-full items-center justify-center gap-2 rounded-md border border-border bg-surface px-3 py-2 text-sm hover:border-[#333]">
                  <span className="h-4 w-4 rounded-sm bg-foreground" /> Continue with Google
                </button>
                <button className="flex w-full items-center justify-center gap-2 rounded-md border border-border bg-surface px-3 py-2 text-sm hover:border-[#333]">
                  <Github className="h-4 w-4" /> Continue with GitHub
                </button>
              </div>
              <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><div className="h-px flex-1 bg-border" /> OR <div className="h-px flex-1 bg-border" /></div>
              <div className="space-y-3">
                <input type="email" placeholder="Email" className="h-10 w-full rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary" />
                <input type="password" placeholder="Password" className="h-10 w-full rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary" />
                <button onClick={() => setStep(1)} className="w-full rounded-md bg-primary py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary-hover">Continue</button>
              </div>
            </>
          )}

          {step === 1 && (
            <>
              <h2 className="text-lg font-semibold">What kind of builder are you?</h2>
              <p className="mt-1 text-sm text-muted-foreground">Pick the closest match. You can change it later.</p>
              <div className="mt-5 grid grid-cols-2 gap-2">
                {["Freelancer", "Founder", "Agency", "Student"].map((t) => (
                  <button key={t} className="card-surface card-hover p-4 text-left">
                    <div className="text-sm font-medium">{t}</div>
                  </button>
                ))}
              </div>
              <button onClick={() => setStep(2)} className="mt-6 w-full rounded-md bg-primary py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary-hover">Continue</button>
            </>
          )}

          {step === 2 && (
            <>
              <h2 className="text-lg font-semibold">Pick your skills & tools</h2>
              <p className="mt-1 text-sm text-muted-foreground">Select all that apply.</p>
              <div className="mt-5 flex flex-wrap gap-2">
                {["ChatGPT", "Claude", "Cursor", "Lovable", "n8n", "Midjourney", "Bolt", "Replit", "Gemini"].map((t) => (
                  <button key={t} className="rounded-full border border-border bg-surface px-3 py-1 text-xs hover:border-primary hover:text-primary">{t}</button>
                ))}
              </div>
              <button onClick={() => setStep(3)} className="mt-6 w-full rounded-md bg-primary py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary-hover">Continue</button>
            </>
          )}

          {step === 3 && (
            <>
              <h2 className="text-lg font-semibold">You're in 🎉</h2>
              <p className="mt-1 text-sm text-muted-foreground">Drop your first project, share a prompt, or just lurk.</p>
              <div className="mt-5 space-y-2">
                {["Add your first project", "Share a prompt", "Browse the directory"].map((a) => (
                  <div key={a} className="card-surface flex items-center gap-3 p-3 text-sm">
                    <Check className="h-4 w-4 text-success" /> {a}
                  </div>
                ))}
              </div>
              <Link to="/dashboard" className="mt-6 block w-full rounded-md bg-primary py-2.5 text-center text-sm font-medium text-primary-foreground hover:bg-primary-hover">Go to dashboard</Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
