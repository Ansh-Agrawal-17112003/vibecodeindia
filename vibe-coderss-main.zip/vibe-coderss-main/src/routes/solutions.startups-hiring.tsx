import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/solutions/startups-hiring")({
  head: () => ({
    meta: [
      { title: "For Startups Hiring · VibeCode" },
      { name: "description", content: "Stop paying LinkedIn for spam. Post AI and vibe-coding roles in front of people who actually ship — with verified portfolios, not resumes." },
      { property: "og:title", content: "For Startups Hiring · VibeCode" },
      { property: "og:description", content: "Stop paying LinkedIn for spam. Post AI and vibe-coding roles in front of people who actually ship — with verified portfolios, not resumes." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/solutions/startups-hiring" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/solutions/startups-hiring" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="For Startups Hiring"
      breadcrumb={[{"label":"Solutions","to":"/"}]}
      title="Reach 120,000+ vetted builders."
      intro="Stop paying LinkedIn for spam. Post AI and vibe-coding roles in front of people who actually ship — with verified portfolios, not resumes."
      toc={[{"id":"why","label":"Why startups hire here"},{"id":"pricing","label":"Simple pricing"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="why" title="Why startups hire here"><NotionFeatureGrid items={[{"title":"Portfolios, not PDFs","description":"Every applicant has shipped work you can inspect in one click."},{"title":"XP-based ranking","description":"Sort candidates by shipped projects, streaks, and community reputation."},{"title":"India-first pipeline","description":"Reach builders in every tier-2/3 city, not just Bangalore."},{"title":"Featured slots","description":"Business plan gets your role on the home feed for 7 days."}]} /></NotionSection>
      <NotionSection id="pricing" title="Simple pricing"><p>One free post per month. Featured, unlimited posts, and saved candidate pools are on the Business plan.</p></NotionSection>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="How long does a post stay live?" a="30 days. You can refresh once for free." />
          <NotionToggle q="Can I filter by city or stack?" a="Yes — location, stack, experience, and availability filters are all searchable." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
