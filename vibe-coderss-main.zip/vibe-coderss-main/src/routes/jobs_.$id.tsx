import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, Bookmark, BadgeCheck, Briefcase, Building2, Calendar, CheckCircle2, ChevronLeft, ChevronRight, Clock, Eye, Globe, GraduationCap, Heart, IndianRupee, Layers, Mail, MapPin, Share2, Sparkles, Star, Target, TrendingUp, Upload, Users, Zap } from "lucide-react";
import { toast } from "sonner";
import { Shell } from "@/components/site/Shell";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { allJobs, jobs as seededJobs, type Job } from "@/lib/mock-data";
import { useSavedJobs } from "@/lib/saved-jobs";
import { supabase } from "@/integrations/supabase/client";
import { sharePage } from "@/lib/share";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const REVIEWS = [
  { quote: "Amazing place to learn and work on cutting-edge AI projects. The team is super supportive and the work is truly impactful.", name: "Rohit Sharma", role: "AI Engineer", date: "2 months ago", initial: "R" },
  { quote: "High ownership from day one. I shipped a production agent in my first month and the founders genuinely care about craft.", name: "Ananya Gupta", role: "Senior ML Engineer", date: "5 weeks ago", initial: "A" },
  { quote: "Best engineering culture I've experienced. Fast decisions, no politics, and a real bias for shipping over slideware.", name: "Vikram Reddy", role: "Founding Engineer", date: "3 months ago", initial: "V" },
  { quote: "Comp is competitive, learning budget is real, and the team genuinely invests in your growth. Hard to go back to a normal job.", name: "Neha Kulkarni", role: "Product Engineer", date: "6 weeks ago", initial: "N" },
];

export const Route = createFileRoute("/jobs_/$id")({
  loader: ({ params }) => {
    const j = seededJobs.find((x) => x.id === params.id);
    return { id: params.id, job: j ?? null };
  },
  head: ({ loaderData }) => {
    const j = loaderData?.job;
    const title = `${j?.title ?? "Job"} at ${j?.company ?? "Company"} · VibeCode`;
    const desc = j?.description ?? "AI builder job opening on VibeCode.";
    const meta = [
      { title },
      { name: "description", content: desc },
      { property: "og:title", content: title },
      { property: "og:description", content: desc },
      { property: "og:type", content: "article" },
    ];
    if (!j) return { meta };
    const employmentType = ({ "Full-time": "FULL_TIME", "Part-time": "PART_TIME", Contract: "CONTRACTOR", Internship: "INTERN" } as const)[j.type] ?? "FULL_TIME";
    return {
      meta,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "JobPosting",
            title: j.title,
            description: j.description,
            employmentType,
            datePosted: new Date().toISOString().slice(0, 10),
            hiringOrganization: { "@type": "Organization", name: j.company },
            jobLocation: {
              "@type": "Place",
              address: { "@type": "PostalAddress", addressLocality: j.location, addressCountry: "IN" },
            },
            ...(j.remote === "Remote" ? { jobLocationType: "TELECOMMUTE" } : {}),
            directApply: true,
            skills: j.tools.join(", "),
            industry: j.industry,
          }),
        },
      ],
    };
  },
  component: JobDetail,
  notFoundComponent: () => (
    <Shell>
      <div className="container-page py-20 text-center text-muted-foreground">Job not found.</div>
    </Shell>
  ),
});

// ---------- Deterministic per-job content generators ----------

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}
const pick = <T,>(arr: T[], seed: number, n: number) => {
  const out: T[] = [];
  const used = new Set<number>();
  let s = seed;
  while (out.length < Math.min(n, arr.length)) {
    s = (s * 9301 + 49297) % 233280;
    const i = s % arr.length;
    if (!used.has(i)) { used.add(i); out.push(arr[i]); }
  }
  return out;
};

const EXP_RANGE = { Entry: "0–2", Mid: "2–4", Senior: "4–7", Lead: "7+" } as const;
const SIZE = ["11–50", "51–200", "201–500", "500–1000"];
const FOUNDED = [2018, 2019, 2020, 2021, 2022, 2023];
const FUNDING = ["Bootstrapped", "Seed · $2M", "Series A · $8M", "Series B · $25M", "Pre-Series A · $4.5M"];
const STAGE = ["Early Stage", "Growth Stage", "Scale-up", "Profitable"];

function jobContent(j: Job) {
  const h = hash(j.id + j.title + j.company);
  const exp = EXP_RANGE[j.level];
  const role = j.title;
  const t1 = j.tools[0] ?? "AI tools";
  const t2 = j.tools[1] ?? t1;
  const t3 = j.tools[2] ?? t2;
  const ind = j.industry.toLowerCase();

  const responsibilities = pick([
    `Design, build, and ship production-grade AI features using ${j.tools.join(", ")}`,
    `Architect end-to-end ${ind} workflows that integrate LLMs (OpenAI, Anthropic, Gemini) with internal systems`,
    `Own the full lifecycle of features — from spec, prototype, A/B test, to rollout`,
    `Write clean, well-tested code in Python / TypeScript and review PRs from peers`,
    `Build retrieval, RAG, and agent pipelines that scale to thousands of concurrent users`,
    `Collaborate with product, design, and customer teams to translate business problems into AI solutions`,
    `Instrument observability — eval pipelines, prompt versioning, cost dashboards`,
    `Mentor junior builders and contribute to engineering standards`,
    `Optimise inference cost, latency, and reliability across services`,
    `Lead architectural reviews for new ${j.industry} initiatives`,
  ], h, j.level === "Lead" || j.level === "Senior" ? 7 : 6);

  const requirements = pick([
    `${exp} years of experience as a ${role} or in a closely related role`,
    `Strong hands-on experience with ${j.tools.join(" / ")} in real production environments`,
    `Solid understanding of REST APIs, webhooks, queues, and event-driven design`,
    `Have shipped LLM-powered products to real users (not just prototypes)`,
    `Proficiency in Python, TypeScript, or both`,
    `Experience with prompt engineering, evals, and prompt-versioning workflows`,
    `Comfort working with vector databases (pgvector, Pinecone, Weaviate)`,
    `Strong written communication — you can document decisions clearly`,
    `Bias for shipping — comfortable owning ambiguous problems end-to-end`,
    `Bachelor's degree in CS, Engineering, or equivalent hands-on portfolio`,
  ], h + 3, 7);

  const niceToHave = pick([
    "Open source contributions to AI / dev-tools projects",
    "Experience with LangChain, LlamaIndex, or DSPy",
    "Built and operated agentic systems in production",
    "Familiarity with Cloudflare Workers / serverless edge runtimes",
    `Past work in the ${j.industry} domain`,
    "Have written publicly (blog posts, talks, OSS) about AI engineering",
    "Comfort with Kubernetes, Terraform, or modern infra-as-code",
  ], h + 7, 4);

  const benefits = pick([
    "Competitive cash + meaningful ESOPs in a fast-growing company",
    "100% remote-first or hybrid out of our office — your choice",
    "Annual ₹1,00,000 learning & conference budget",
    "Top-tier hardware: MacBook Pro M-series + 4K external display",
    "Comprehensive health insurance for you, partner, parents & kids",
    "Quarterly off-sites in places like Goa, Bir, and Bali",
    "Flexible PTO — take what you need, we measure outcomes not hours",
    "Wellness allowance: gym, therapy, or meditation apps",
    "Monthly stipend for AI tools, APIs, and dev subscriptions",
    "Founders who've shipped before — fast decisions, no politics",
  ], h + 11, 7);

  const process = [
    { step: "Intro call", detail: "30-min call with our talent partner to understand your background and what you're looking for." },
    { step: "Take-home / portfolio review", detail: `Either share a past project or take ~2 hours to build a small ${j.industry} prototype using ${t1}.` },
    { step: "Technical deep-dive", detail: `60–90 minutes with two engineers walking through your work, architecture decisions, and live problem solving with ${t2}.` },
    { step: "Founder + culture chat", detail: "Meet a founder. Ask anything — comp, vision, runway, the messy stuff." },
    { step: "Offer + reference", detail: "Offer rolled out within 48 hours, references in parallel. Start within 2–4 weeks." },
  ];

  const aboutCompany = `${j.company} is a ${STAGE[h % STAGE.length].toLowerCase()} ${j.industry} company headquartered in ${j.location}. We're a tight-knit team of ${SIZE[h % SIZE.length]} builders shipping AI-native products that ${ind === "saas" ? "help businesses automate operations" : `transform how ${ind} teams work`}. Customers include fast-growing Indian startups, mid-market companies, and a handful of global enterprises. We've been ${FUNDING[h % FUNDING.length].toLowerCase()} since founding in ${FOUNDED[h % FOUNDED.length]}.`;

  const why = [
    `Work on problems that genuinely move the needle in ${j.industry}`,
    `Direct ownership — your code reaches real users within days, not quarters`,
    `Learn from a team that has shipped at scale and built with ${t1}, ${t2}, ${t3} from day one`,
    "Tiny team, big surface area — wear multiple hats and grow fast",
  ];

  const teamMembers = pick([
    { name: "Aarav Mehta", role: "Co-founder & CTO", bg: "Ex-Razorpay, IIT Bombay" },
    { name: "Priya Iyer", role: "Head of Engineering", bg: "Ex-Stripe, BITS Pilani" },
    { name: "Rohan Shah", role: "Founding Engineer", bg: "Ex-Postman, NIT Trichy" },
    { name: "Ananya Reddy", role: "Product Lead", bg: "Ex-Zerodha, IIM-A" },
    { name: "Kabir Khan", role: "Design Lead", bg: "Ex-Swiggy, NID" },
    { name: "Ishita Verma", role: "Founding AI Engineer", bg: "Ex-Microsoft Research" },
  ], h + 5, 3);

  return { responsibilities, requirements, niceToHave, benefits, process, aboutCompany, why, teamMembers, exp };
}

// --------------------------------- Component ---------------------------------

function JobDetail() {
  const { id, job: seedJob } = Route.useLoaderData();
  const [dbJob, setDbJob] = useState<Job | null>(null);
  const [notFoundFlag, setNotFoundFlag] = useState(false);
  const { isSaved, toggle: toggleSaved } = useSavedJobs();

  useEffect(() => {
    if (!UUID_RE.test(id) || seedJob) return;
    supabase
      .from("jobs")
      .select("id,title,description,location,job_type,remote_type,experience_level,tools_required,salary_min,salary_max,created_at,companies(name)")
      .eq("id", id)
      .maybeSingle()
      .then(({ data }) => {
        if (!data) { setNotFoundFlag(true); return; }
        const company = (data as any).companies?.name ?? "Independent";
        const salary = data.salary_min && data.salary_max ? `₹${Math.round(data.salary_min/100000)}-${Math.round(data.salary_max/100000)}L` : "Competitive";
        setDbJob({
          id: data.id,
          title: data.title,
          company,
          logo: "",
          location: data.location ?? "Remote",
          type: (data.job_type === "freelance" ? "Contract" : data.job_type === "internship" ? "Internship" : data.job_type === "part-time" ? "Part-time" : "Full-time") as Job["type"],
          remote: (data.remote_type === "onsite" ? "On-site" : data.remote_type === "hybrid" ? "Hybrid" : "Remote") as Job["remote"],
          level: "Mid",
          salary,
          posted: "recent",
          description: data.description ?? "",
          tools: data.tools_required ?? [],
          industry: "SaaS",
        });
      });
  }, [id, seedJob]);

  const j = seedJob ?? dbJob ?? allJobs().find((x) => x.id === id);
  if (!j && notFoundFlag) throw notFound();
  if (!j) return <Shell><div className="container-page py-20 text-center text-muted-foreground">Loading…</div></Shell>;

  const isRealDbJob = UUID_RE.test(j.id);

  const c = jobContent(j);
  const similar = allJobs().filter((x) => x.id !== j.id && (x.industry === j.industry || x.tools.some((t) => j.tools.includes(t)))).slice(0, 4);
  const applied = 30 + (hash(j.id) % 220);
  const views = 800 + (hash(j.id + "v") % 4200);

  const saved = isSaved(j.id);
  const [rIdx, setRIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setRIdx((i) => (i + 1) % REVIEWS.length), 6000);
    return () => clearInterval(t);
  }, []);
  const review = REVIEWS[rIdx];

  // Live: deadline countdown + live viewer counter
  const deadlineMs = 1000 * 60 * 60 * 24 * (3 + (hash(j.id + "d") % 25)); // 3–27 days
  const [deadline] = useState(() => Date.now() + deadlineMs);
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);
  const remaining = Math.max(0, deadline - now);
  const days = Math.floor(remaining / 86400000);
  const hours = Math.floor((remaining % 86400000) / 3600000);
  const mins = Math.floor((remaining % 3600000) / 60000);
  const secs = Math.floor((remaining % 60000) / 1000);

  const [liveViewers, setLiveViewers] = useState(() => 4 + (hash(j.id + "lv") % 12));
  useEffect(() => {
    const t = setInterval(() => setLiveViewers((v) => Math.max(2, v + (Math.random() > 0.5 ? 1 : -1))), 4500);
    return () => clearInterval(t);
  }, []);
  const [liveApplied, setLiveApplied] = useState(applied);
  useEffect(() => {
    const t = setInterval(() => setLiveApplied((n) => n + (Math.random() > 0.7 ? 1 : 0)), 8000);
    return () => clearInterval(t);
  }, []);

  const fileInputRef = { current: null as HTMLInputElement | null };
  function onResumePicked(f: File | null) {
    if (!f) return;
    if (f.type !== "application/pdf") { toast.error("Please upload a PDF file"); return; }
    if (f.size > 10 * 1024 * 1024) { toast.error("Resume must be under 10MB"); return; }
    toast.success(`${f.name} attached. Continue to apply →`);
  }

  return (
    <Shell>
      <div className="container-page py-6">
        {/* Breadcrumb / actions */}
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="text-muted-foreground">
            <Link to="/jobs" className="font-bold hover:text-foreground">Jobs</Link>
            <span className="mx-1.5">›</span>
            <span className="font-bold text-foreground">{j.title}</span>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/jobs" className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 py-1.5 font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <ArrowLeft className="h-3 w-3" /> Back to Jobs
            </Link>
            <button onClick={() => sharePage(`${j.title} at ${j.company}`, j.description)} className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 py-1.5 font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <Share2 className="h-3 w-3" /> Share
            </button>
          </div>
        </div>

        <div className="grid min-w-0 gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
          {/* Main column */}
          <div className="min-w-0 space-y-6">
            {/* Header card */}
            <div className="card-editorial max-w-full p-4 md:p-6">
              <div className="grid grid-cols-[auto_minmax(0,1fr)] items-start gap-3 sm:grid-cols-[auto_minmax(0,1fr)_auto] md:gap-4">
                <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] text-2xl font-extrabold text-white md:h-20 md:w-20 md:text-3xl" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}>
                  {j.company.charAt(0)}
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h1 className="min-w-0 break-words font-display text-lg font-extrabold leading-tight tracking-tight [overflow-wrap:anywhere] sm:text-2xl md:text-3xl">{j.title}</h1>
                    <span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white">New</span>
                  </div>
                  <div className="mt-1 flex min-w-0 items-center gap-1.5 text-sm font-bold">
                    <span className="truncate">{j.company}</span> <BadgeCheck className="h-4 w-4 shrink-0 text-coral" />
                  </div>
                </div>
                <button onClick={() => { toggleSaved(j.id); toast.success(saved ? "Removed from saved" : "Saved to your list"); }} className="col-span-2 grid h-9 w-full shrink-0 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card sm:col-span-1 sm:w-9" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }} aria-label="Save job">
                  <Bookmark className={`h-4 w-4 ${saved ? "fill-coral text-coral" : ""}`} />
                </button>
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground">
                <span className="flex min-w-0 max-w-full items-center gap-1.5 break-words"><MapPin className="h-3.5 w-3.5 shrink-0" /> <span className="min-w-0 [overflow-wrap:anywhere]">{j.remote} · {j.location}</span></span>
                <span className="flex items-center gap-1.5"><Briefcase className="h-3.5 w-3.5 shrink-0" /> {j.type}</span>
                <span className="flex items-center gap-1.5"><GraduationCap className="h-3.5 w-3.5 shrink-0" /> {c.exp} yrs</span>
                <span className="flex min-w-0 max-w-full items-center gap-1 font-bold text-foreground"><IndianRupee className="h-3.5 w-3.5 shrink-0" /><span className="min-w-0 [overflow-wrap:anywhere]">{j.salary.replace("₹", "")}</span></span>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {j.tools.map((t: string) => (
                  <span key={t} className="max-w-full break-words rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-2 py-1 text-[11px] font-bold [overflow-wrap:anywhere]">{t}</span>
                ))}
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 border-t-[1.5px] border-dashed border-[#0F0F0F]/30 pt-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> Posted {j.posted}</span>
                <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {applied} applied</span>
                <span className="flex items-center gap-1"><TrendingUp className="h-3.5 w-3.5" /> {views.toLocaleString()} views</span>
              </div>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="description" className="min-w-0 max-w-full">
              <TabsList className="w-full">
                <TabsTrigger value="description">Job Description</TabsTrigger>
                <TabsTrigger value="company">About Company</TabsTrigger>
                <TabsTrigger value="benefits">Benefits</TabsTrigger>
                <TabsTrigger value="process">Hiring Process</TabsTrigger>
                <TabsTrigger value="reviews">Reviews (24)</TabsTrigger>
              </TabsList>

              <TabsContent value="description" className="min-w-0 max-w-full space-y-6 py-6">
                <Section icon={<Sparkles className="h-4 w-4" />} title="About the Role">
                  <p>{j.description}</p>
                  <p className="mt-2">
                    As a <b>{j.title}</b> at <b>{j.company}</b>, you'll join a small, senior team building AI-native {j.industry.toLowerCase()} products from the ground up. You'll work daily with {j.tools.join(", ")} to design, ship, and scale features that customers use every day. This is a high-ownership role — you'll have direct input on what we build and how we build it.
                  </p>
                </Section>

                <Section icon={<Target className="h-4 w-4" />} title="What You'll Do">
                  <CheckList items={c.responsibilities} />
                </Section>

                <Section icon={<CheckCircle2 className="h-4 w-4" />} title="What We're Looking For">
                  <BulletList items={c.requirements} />
                </Section>

                <Section icon={<Star className="h-4 w-4" />} title="Nice to Have">
                  <BulletList items={c.niceToHave} />
                </Section>

                <Section icon={<Heart className="h-4 w-4" />} title={`Why join ${j.company}?`}>
                  <BulletList items={c.why} />
                </Section>

                <div className="card-editorial mt-2 max-w-full p-4 sm:p-5">
                  <div className="mb-3 flex min-w-0 items-center gap-2">
                    <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] font-extrabold text-white">{j.company.charAt(0)}</div>
                    <div className="min-w-0">
                      <div className="flex min-w-0 items-center gap-1 text-sm font-extrabold"><span className="min-w-0 break-words [overflow-wrap:anywhere]">{j.company}</span> <BadgeCheck className="h-3.5 w-3.5 shrink-0 text-coral" /></div>
                      <div className="text-[11px] text-muted-foreground">About the Company</div>
                    </div>
                  </div>
                  <p className="text-sm text-foreground/80 [overflow-wrap:anywhere]">{c.aboutCompany}</p>
                  <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {SIZE[hash(j.company) % SIZE.length]} employees</span>
                    <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {j.location}</span>
                    <span className="flex items-center gap-1"><Building2 className="h-3 w-3" /> {j.industry}</span>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="company" className="min-w-0 max-w-full space-y-6 py-6">
                <Section icon={<Building2 className="h-4 w-4" />} title={`About ${j.company}`}>
                  <p>{c.aboutCompany}</p>
                </Section>
                <div className="grid gap-3 sm:grid-cols-2">
                  <Fact icon={<Users className="h-4 w-4" />} label="Team size" value={`${SIZE[hash(j.company) % SIZE.length]} people`} />
                  <Fact icon={<Calendar className="h-4 w-4" />} label="Founded" value={String(FOUNDED[hash(j.company + "f") % FOUNDED.length])} />
                  <Fact icon={<TrendingUp className="h-4 w-4" />} label="Funding" value={FUNDING[hash(j.company + "$") % FUNDING.length]} />
                  <Fact icon={<Globe className="h-4 w-4" />} label="Website" value={`${j.company.toLowerCase().replace(/\s+/g, "")}.com`} />
                </div>
                <Section icon={<Layers className="h-4 w-4" />} title="Tech Stack">
                  <div className="flex flex-wrap gap-2">
                    {j.tools.map((t: string) => <span key={t} className="max-w-full break-words rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-2.5 py-1 text-xs font-bold [overflow-wrap:anywhere]">{t}</span>)}
                    {["Python", "TypeScript", "Postgres", "Cloudflare"].map((t) => (
                      <span key={t} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-2.5 py-1 text-xs font-bold">{t}</span>
                    ))}
                  </div>
                </Section>
                <Section icon={<Users className="h-4 w-4" />} title="Meet the Team">
                  <div className="grid min-w-0 gap-3 sm:grid-cols-3">
                    {c.teamMembers.map((m) => (
                      <div key={m.name} className="card-editorial min-w-0 p-4">
                        <div className="grid h-10 w-10 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-gold font-extrabold">{m.name.charAt(0)}</div>
                        <div className="mt-2 break-words text-sm font-extrabold [overflow-wrap:anywhere]">{m.name}</div>
                        <div className="break-words text-xs text-muted-foreground [overflow-wrap:anywhere]">{m.role}</div>
                        <div className="mt-1 break-words text-[11px] text-foreground/70 [overflow-wrap:anywhere]">{m.bg}</div>
                      </div>
                    ))}
                  </div>
                </Section>
              </TabsContent>

              <TabsContent value="benefits" className="min-w-0 max-w-full py-6">
                <Section icon={<Heart className="h-4 w-4" />} title="What We Offer">
                  <CheckList items={c.benefits} />
                </Section>
              </TabsContent>

              <TabsContent value="process" className="min-w-0 max-w-full py-6">
                <Section icon={<Layers className="h-4 w-4" />} title="Our Hiring Process">
                  <ol className="space-y-3">
                    {c.process.map((p, i) => (
                      <li key={p.step} className="card-editorial flex min-w-0 gap-3 p-4">
                        <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-coral font-extrabold text-white">{i + 1}</div>
                        <div className="min-w-0">
                          <div className="break-words text-sm font-extrabold [overflow-wrap:anywhere]">{p.step}</div>
                          <div className="mt-0.5 break-words text-xs text-foreground/75 [overflow-wrap:anywhere]">{p.detail}</div>
                        </div>
                      </li>
                    ))}
                  </ol>
                </Section>
              </TabsContent>

              <TabsContent value="reviews" className="min-w-0 max-w-full py-6">
                <div className="card-editorial max-w-full p-4 sm:p-5">
                  <div className="flex flex-wrap items-center gap-4">
                    <div className="font-display text-4xl font-extrabold">4.6</div>
                    <Stars value={4.6} />
                    <span className="text-xs text-muted-foreground">24 reviews</span>
                  </div>
                  <div className="mt-5 grid gap-4 text-sm sm:grid-cols-3">
                    {[["Work Life Balance", 4.5], ["Growth & Learning", 4.7], ["Culture & Values", 4.6]].map(([label, v]) => (
                      <div key={label as string} className="text-center sm:text-left">
                        <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{label}</div>
                        <div className="mt-1 flex items-center justify-center gap-2 font-bold sm:justify-start">{v}<Stars value={Number(v)} small /></div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="card-editorial mt-4 max-w-full bg-[#F5F0E8] p-4 sm:p-5">
                  <div className="flex items-center gap-3">
                    <button onClick={() => setRIdx((i) => (i - 1 + REVIEWS.length) % REVIEWS.length)} className="grid h-9 w-9 shrink-0 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card" aria-label="Previous review">
                      <ChevronLeft className="h-4 w-4" />
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm italic text-foreground/85">"{review.quote}"</p>
                      <div className="mt-3 flex items-center justify-between gap-2">
                        <div className="flex min-w-0 items-center gap-2 text-xs">
                          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-gold font-extrabold">{review.initial}</div>
                          <div className="min-w-0">
                            <div className="break-words font-bold [overflow-wrap:anywhere]">{review.name}</div>
                            <div className="break-words text-muted-foreground [overflow-wrap:anywhere]">{review.role}</div>
                          </div>
                        </div>
                        <div className="text-xs text-muted-foreground">{review.date}</div>
                      </div>
                    </div>
                    <button onClick={() => setRIdx((i) => (i + 1) % REVIEWS.length)} className="grid h-9 w-9 shrink-0 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card" aria-label="Next review">
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="mt-4 flex items-center justify-center gap-1.5">
                    {REVIEWS.map((_, i) => (
                      <button key={i} onClick={() => setRIdx(i)} aria-label={`Review ${i + 1}`} className={`h-2 rounded-full transition-all ${i === rIdx ? "w-6 bg-coral" : "w-2 bg-foreground/25"}`} />
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <aside className="min-w-0 max-w-full space-y-4 lg:sticky lg:top-20 lg:self-start">
            <div className="card-editorial max-w-full p-4 sm:p-5">
              <h4 className="font-display text-base font-extrabold">Job Overview</h4>
              <dl className="mt-3 space-y-2 text-sm">
                <Row k="Job Type" v={j.type} />
                <Row k="Experience" v={`${c.exp} years`} />
                <Row k="Location" v={`${j.remote} · ${j.location}`} />
                <Row k="Salary" v={j.salary} />
                <Row k="Industry" v={j.industry} />
                <Row k="Posted" v={j.posted} />
                <Row k="Applications" v={`${liveApplied} applied`} />
              </dl>

              {/* Live countdown */}
              <div className="mt-4 rounded-lg border-[1.5px] border-[#0F0F0F] bg-gold/40 p-3">
                <div className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider"><Clock className="h-3 w-3" /> Applications close in</div>
                <div className="mt-1.5 grid grid-cols-4 gap-1.5 text-center">
                  {[["Days", days], ["Hrs", hours], ["Min", mins], ["Sec", secs]].map(([k, v]) => (
                    <div key={k as string} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-card py-1">
                      <div className="font-display text-base font-extrabold leading-none tabular-nums">{String(v).padStart(2, "0")}</div>
                      <div className="text-[9px] font-bold text-muted-foreground">{k}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Live viewers */}
              <div className="mt-3 flex items-center gap-2 rounded-md border-[1.5px] border-dashed border-[#0F0F0F]/40 bg-card px-3 py-2 text-xs">
                <span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-coral opacity-75" /><span className="relative inline-flex h-2 w-2 rounded-full bg-coral" /></span>
                <Eye className="h-3.5 w-3.5" /> <b className="tabular-nums">{liveViewers}</b> people viewing right now
              </div>

              <Link to="/apply/$id" params={{ id: j.id }} className="btn-coral mt-5 w-full">Apply Now <ArrowRight className="h-4 w-4" /></Link>
              <button
                onClick={() => { toggleSaved(j.id); toast.success(saved ? "Removed from saved" : "Saved to your list"); }}
                className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-card py-2.5 text-sm font-bold transition"
                style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
              >
                {saved ? "Saved ✓" : "Save Job"} <Bookmark className={`h-4 w-4 ${saved ? "fill-coral text-coral" : ""}`} />
              </button>
            </div>

            <div className="card-editorial max-w-full bg-teal/15 p-4 sm:p-5">
              <div className="flex items-center gap-2 font-display font-extrabold"><Zap className="h-4 w-4 text-coral" /> Fast Apply</div>
              <p className="mt-1 text-xs text-foreground/80">Upload your resume from your computer and jump straight to the application.</p>
              <label className="mt-3 inline-flex w-full cursor-pointer items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-card py-2.5 text-sm font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                Upload Resume <Upload className="h-4 w-4" />
                <input type="file" accept="application/pdf,.pdf" className="hidden" onChange={(e) => onResumePicked(e.target.files?.[0] ?? null)} />
              </label>
              <Link to="/apply/$id" params={{ id: j.id }} className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral py-2.5 text-sm font-bold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                Continue to Application →
              </Link>
            </div>

            <div className="card-editorial max-w-full p-4 sm:p-5">
              <h4 className="font-display text-base font-extrabold">Similar Jobs</h4>
              <div className="mt-3 space-y-3">
                {similar.map((s) => (
                    <Link key={s.id} to="/jobs/$id" params={{ id: s.id }} className="-mx-2 flex min-w-0 items-start gap-3 rounded-md p-2 hover:bg-card">
                    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] font-extrabold text-white">{s.company.charAt(0)}</div>
                      <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-bold">{s.title}</div>
                        <div className="truncate text-xs text-muted-foreground">{s.company}</div>
                        <div className="mt-0.5 flex min-w-0 flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                          <MapPin className="h-3 w-3 shrink-0" /> {s.remote}
                        <span>·</span>
                          <span className="min-w-0 break-words [overflow-wrap:anywhere]">{s.salary}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
              <Link to="/jobs" className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-card py-2 text-sm font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                View All Jobs <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </aside>
        </div>

        {/* Newsletter strip */}
        <section className="card-editorial mt-10 max-w-full bg-gold/30 p-4 sm:p-5 md:p-8">
          <div className="grid items-center gap-5 md:grid-cols-[1fr_auto_auto]">
            <div className="text-center md:text-left">
              <h3 className="font-display text-xl font-extrabold md:text-2xl">Don't Miss New Opportunities</h3>
              <p className="mt-1 text-sm text-foreground/75">Get the latest AI jobs and opportunities delivered to your inbox.</p>
            </div>
            <form
              onSubmit={(e) => { e.preventDefault(); (e.currentTarget.querySelector("input") as HTMLInputElement).value = ""; }}
              className="flex w-full flex-col items-stretch gap-2 sm:flex-row md:w-auto"
            >
              <input
                type="email"
                required
                placeholder="Enter your email"
                className="w-full min-w-0 rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 py-2.5 text-sm font-medium outline-none md:w-72"
                style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
              />
              <button type="submit" className="btn-coral w-full whitespace-nowrap sm:w-auto">Subscribe</button>
            </form>
            <div className="hidden h-14 w-14 place-items-center rounded-xl border-[1.5px] border-[#0F0F0F] bg-card md:grid" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
              <Mail className="h-6 w-6 text-coral" />
            </div>
          </div>
        </section>
      </div>
    </Shell>
  );
}

function Section({ title, children, icon }: { title: string; children: React.ReactNode; icon?: React.ReactNode }) {
  return (
    <div>
      <h3 className="flex items-center gap-2 font-display text-lg font-extrabold">
        {icon && <span className="grid h-7 w-7 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-gold">{icon}</span>}
        {title}
      </h3>
      <div className="mt-2 text-sm leading-relaxed text-foreground/85">{children}</div>
    </div>
  );
}

function Fact({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="card-editorial flex items-center gap-3 p-3">
      <div className="grid h-8 w-8 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-card">{icon}</div>
      <div>
        <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="text-sm font-bold">{value}</div>
      </div>
    </div>
  );
}

function CheckList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-2">
      {items.map((it) => (
        <li key={it} className="flex items-start gap-2 text-sm">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-coral" />
          <span>{it}</span>
        </li>
      ))}
    </ul>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="ml-5 list-disc space-y-1.5 text-sm">
      {items.map((it) => <li key={it}>{it}</li>)}
    </ul>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border/60 py-1.5 last:border-b-0">
      <dt className="text-muted-foreground">{k}</dt>
      <dd className="font-bold text-right">{v}</dd>
    </div>
  );
}

function Stars({ value, small }: { value: number; small?: boolean }) {
  const size = small ? "h-3 w-3" : "h-4 w-4";
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} className={`${size} ${i <= Math.round(value) ? "fill-gold text-gold" : "text-muted-foreground/40"}`} />
      ))}
    </div>
  );
}
