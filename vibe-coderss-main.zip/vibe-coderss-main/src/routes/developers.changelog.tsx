import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/developers/changelog")({
  head: () => ({
    meta: [
      { title: "Changelog · VibeCode" },
      { name: "description", content: "Every release, every fix, every experiment. Updated weekly by the team." },
      { property: "og:title", content: "Changelog · VibeCode" },
      { property: "og:description", content: "Every release, every fix, every experiment. Updated weekly by the team." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/developers/changelog" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/developers/changelog" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Changelog"
      breadcrumb={[{"label":"Developers","to":"/"}]}
      title="What shipped this week."
      intro="Every release, every fix, every experiment. Updated weekly by the team."
      toc={[{"id":"recent","label":"This week"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="recent" title="This week"><NotionList items={["New Vibe Feed ranking model — 22% more engagement on high-quality builds","Prompt library filters now support cost/token estimation","Jobs board added city-level heatmap for hirers","Webhooks now signed with HMAC-SHA256 (breaking change — see docs)"]} /></NotionSection>
      <NotionCallout emoji="📰" tone="cream">Subscribe to the changelog via RSS or the weekly newsletter — same content, your inbox.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Where is the full history?" a="Every release since day one is archived. Ask in Discord for the RSS URL." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
