import { createFileRoute, Link } from "@tanstack/react-router";
import { Bookmark, Briefcase } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { JobCard } from "@/components/cards/JobCard";
import { allJobs } from "@/lib/mock-data";
import { useSavedJobs } from "@/lib/saved-jobs";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/saved-jobs")({
  head: () => ({
    meta: [
      { title: 'Saved Jobs · VibeCode' },
      { name: "description", content: "Jobs you've bookmarked on VibeCode, ready to apply when you are." },
      { property: "og:title", content: 'Saved Jobs · VibeCode' },
      { property: "og:description", content: "Jobs you've bookmarked on VibeCode, ready to apply when you are." },
      { property: "og:url", content: 'https://joinvibecode.xyz/saved-jobs' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Saved Jobs · VibeCode' },
      { name: "twitter:description", content: "Jobs you've bookmarked on VibeCode, ready to apply when you are." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/saved-jobs' }],
  }),
  component: SavedJobsPage,
});

function SavedJobsPage() {
  const { user } = useAuth();
  const { ids, toggle } = useSavedJobs();
  const all = allJobs();
  const jobs = ids.map((id) => all.find((j) => j.id === id)).filter(Boolean) as ReturnType<typeof allJobs>;

  if (!user) {
    return (
      <Shell>
        <div className="container-page py-8">
          <div className="card-editorial mt-8 grid place-items-center p-14 text-center">
            <div className="text-5xl">🔖</div>
            <h1 className="mt-3 font-display text-2xl font-extrabold">Save jobs you love</h1>
            <p className="mt-1 max-w-md text-sm text-muted-foreground">Sign in to save jobs and come back to them anytime.</p>
            <Link to="/auth" className="btn-coral mt-5 h-10 px-4 text-sm">Sign in to Save Jobs</Link>
          </div>
        </div>
      </Shell>
    );
  }


  return (
    <Shell>
      <div className="container-page py-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-3xl font-extrabold tracking-tight md:text-4xl">Saved Jobs</h1>
            <p className="mt-1 text-sm text-muted-foreground">{jobs.length} job{jobs.length === 1 ? "" : "s"} saved for later</p>
          </div>
          <Link to="/jobs" className="btn-coral h-10 px-4 text-sm"><Briefcase className="h-4 w-4" /> Browse jobs</Link>
        </div>

        {jobs.length === 0 ? (
          <div className="card-editorial mt-8 grid place-items-center p-14 text-center">
            <Bookmark className="h-10 w-10 text-muted-foreground" />
            <h3 className="mt-3 font-display text-lg font-extrabold">No saved jobs yet</h3>
            <p className="mt-1 max-w-md text-sm text-muted-foreground">Tap the bookmark on any job to save it here and come back later.</p>
            <Link to="/jobs" className="btn-coral mt-5 h-10 px-4 text-sm">Explore jobs →</Link>
          </div>
        ) : (
          <div className="mt-6 grid gap-4">
            {jobs.map((j) => (
              <div key={j.id} className="relative">
                <JobCard j={j} />
                <button
                  onClick={() => toggle(j.id)}
                  className="absolute right-4 top-4 rounded-full border-[1.5px] border-[#0F0F0F] bg-card p-1.5 text-xs font-bold"
                  style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                  aria-label="Remove from saved"
                >
                  <Bookmark className="h-4 w-4 fill-coral text-coral" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </Shell>
  );
}
