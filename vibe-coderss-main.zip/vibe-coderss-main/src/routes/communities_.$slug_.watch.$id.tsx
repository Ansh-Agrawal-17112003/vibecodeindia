import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  ArrowLeft, ThumbsUp, ThumbsDown, Share2, Bookmark, Bell, BellOff, Check,
  Send, Radio, MoreHorizontal, Play,
} from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { allCommunities, builders, communities as seededCommunities } from "@/lib/mock-data";
import { getResources, type Resource } from "@/lib/community-seed";
import { useAuth } from "@/hooks/useAuth";
import { getLecture, getSignedUrl, bumpLectureViewCount, recordLectureProgress, type Lecture } from "@/lib/lectures-api";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export const Route = createFileRoute("/communities_/$slug_/watch/$id")({
  loader: ({ params }) => {
    const c = seededCommunities.find((x) => x.slug === params.slug);
    return { slug: params.slug, id: params.id, community: c ?? null };
  },
  head: ({ loaderData }) => ({
    meta: [{ title: `${loaderData?.community?.name ?? "Community"} · Watch · VibeCoder` }],
  }),
  component: WatchPage,
  notFoundComponent: () => (
    <Shell>
      <div className="container-page py-20 text-center">
        <h1 className="font-display text-3xl font-extrabold">Video not found</h1>
        <Link to="/communities" className="mt-4 inline-block text-coral underline">Browse communities</Link>
      </div>
    </Shell>
  ),
});

const SAMPLE_VIDEOS = [
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
];

const SAMPLE_LIVE = [
  "This part was 🔥", "Wait, can you repeat that prompt?", "Which model are you using here?",
  "Following along — building the same thing", "10/10 lecture 🙌", "Timestamp this please",
  "Bookmarking this section", "Just replicated it, works!", "Hey from Bangalore 👋",
  "How do we handle rate limits here?",
];

function hash(s: string) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }

type Comment = { id: string; builderIdx: number; body: string; time: string; likes: number };

function WatchPage() {
  const { slug, id, community: seed } = Route.useLoaderData();
  const nav = useNavigate();
  const c = seed ?? allCommunities().find((x) => x.slug === slug);
  if (!c) throw notFound();

  const { user } = useAuth();
  const isRealId = UUID_RE.test(id);

  // Real DB lecture (fetched async when id is a UUID)
  const [realLecture, setRealLecture] = useState<Lecture | null>(null);
  const [realVideoUrl, setRealVideoUrl] = useState<string | null>(null);
  const [realThumbUrl, setRealThumbUrl] = useState<string | null>(null);
  const [realLoading, setRealLoading] = useState<boolean>(isRealId);

  useEffect(() => {
    if (!isRealId) return;
    let alive = true;
    (async () => {
      try {
        const l = await getLecture(id);
        if (!alive || !l) { setRealLoading(false); return; }
        setRealLecture(l);
        if (l.video_url) {
          const [v, t] = await Promise.all([
            getSignedUrl(l.video_url, 3600),
            l.thumbnail_url ? getSignedUrl(l.thumbnail_url, 3600) : Promise.resolve<string | null>(null),
          ]);
          if (!alive) return;
          setRealVideoUrl(v);
          setRealThumbUrl(t);
        }
        setRealLoading(false);
        // Bump view count once per session
        bumpLectureViewCount(l.id).catch(() => {});
      } catch (e) {
        console.warn("[watch] real lecture fetch failed", e);
        setRealLoading(false);
      }
    })();
    return () => { alive = false; };
  }, [id, isRealId]);

  // Fallback seed lookup (only when this is NOT a real UUID)
  const resources = useMemo(() => (isRealId ? [] : getResources(c.slug, c.name)), [c.slug, c.name, isRealId]);
  const seedResource = resources.find((r) => r.id === id) ?? resources[0];
  if (!isRealId && !seedResource) throw notFound();
  if (isRealId && !realLoading && !realLecture) throw notFound();

  // Unified view model — real lecture overrides seed values.
  const resource: Resource = realLecture
    ? {
        id: realLecture.id,
        title: realLecture.title,
        category: (realLecture.tags?.[0] ?? "Lecture") as any,
        builderIdx: 0,
        date: new Date(realLecture.created_at).toLocaleDateString(),
        downloads: realLecture.view_count,
        rating: 5,
        kind: "Video",
      }
    : (seedResource as Resource);

  const teacher = builders[resource.builderIdx % builders.length];
  const upNext = resources.filter((r) => r.id !== resource.id).slice(0, 8);

  // Live: treat the first Video resource as a live stream (parity with feed page)
  const liveId = resources.find((r) => r.kind === "Video")?.id ?? resources[0]?.id;
  const isLive = !realLecture && resource.id === liveId;

  const videoSrc = useMemo(
    () => realVideoUrl ?? SAMPLE_VIDEOS[hash(resource.id) % SAMPLE_VIDEOS.length],
    [resource.id, realVideoUrl],
  );
  const posterUrl = realThumbUrl ?? `https://picsum.photos/seed/${resource.id}/1280/720`;

  const [liked, setLiked] = useState(false);
  const [disliked, setDisliked] = useState(false);
  const [subscribed, setSubscribed] = useState(false);
  const [notified, setNotified] = useState(true);
  const [saved, setSaved] = useState(false);
  const [likes, setLikes] = useState(120 + (hash(resource.id) % 3000));
  const [subs, setSubs] = useState(1200 + (hash(teacher.username) % 12000));
  const [viewers, setViewers] = useState(isLive ? 40 + (hash(resource.id) % 300) : 0);
  const [showDesc, setShowDesc] = useState(false);
  const [comments, setComments] = useState<Comment[]>(() =>
    Array.from({ length: 8 }).map((_, i) => ({
      id: `c-${i}`,
      builderIdx: (hash(resource.id) + i * 3) % builders.length,
      body: SAMPLE_LIVE[(hash(resource.id) + i) % SAMPLE_LIVE.length],
      time: `${i + 1}m ago`,
      likes: Math.floor(Math.random() * 20),
    })),
  );
  const [draft, setDraft] = useState("");
  const chatRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Persist view progress for real DB lectures
  useEffect(() => {
    if (!realLecture || !user) return;
    const v = videoRef.current;
    if (!v) return;
    const id = window.setInterval(() => {
      const pos = Math.floor(v.currentTime || 0);
      if (pos <= 0) return;
      recordLectureProgress({
        lectureId: realLecture.id,
        viewerId: user.id,
        watchedSec: pos,
        lastPositionSec: pos,
      }).catch(() => {});
    }, 15000);
    return () => window.clearInterval(id);
  }, [realLecture, user]);


  // Reset transient state on navigation between videos
  useEffect(() => {
    setLiked(false); setDisliked(false); setSaved(false); setShowDesc(false);
    setLikes(120 + (hash(resource.id) % 3000));
    setViewers(isLive ? 40 + (hash(resource.id) % 300) : 0);
    setComments(Array.from({ length: 8 }).map((_, i) => ({
      id: `c-${i}`,
      builderIdx: (hash(resource.id) + i * 3) % builders.length,
      body: SAMPLE_LIVE[(hash(resource.id) + i) % SAMPLE_LIVE.length],
      time: `${i + 1}m ago`,
      likes: Math.floor(Math.random() * 20),
    })));
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [resource.id, isLive]);

  // Live simulation
  useEffect(() => {
    if (!isLive) return;
    const viewerT = setInterval(() => setViewers((v) => Math.max(20, v + Math.floor(Math.random() * 11) - 5)), 4000);
    const chatT = setInterval(() => {
      const idx = Math.floor(Math.random() * builders.length);
      setComments((prev) => [...prev, {
        id: `l-${Date.now()}-${Math.random()}`,
        builderIdx: idx,
        body: SAMPLE_LIVE[Math.floor(Math.random() * SAMPLE_LIVE.length)],
        time: "just now", likes: 0,
      }].slice(-60));
      setTimeout(() => chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight, behavior: "smooth" }), 50);
    }, 3500);
    return () => { clearInterval(viewerT); clearInterval(chatT); };
  }, [isLive]);

  const submitComment = () => {
    if (!draft.trim()) return;
    setComments((prev) => [...prev, { id: `u-${Date.now()}`, builderIdx: 0, body: draft.trim(), time: "just now", likes: 0 }]);
    setDraft("");
    setTimeout(() => chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight, behavior: "smooth" }), 50);
    toast.success("Sent");
  };

  const toggleLike = () => {
    if (liked) { setLiked(false); setLikes((n) => n - 1); return; }
    setLiked(true); setLikes((n) => n + 1);
    if (disliked) setDisliked(false);
  };
  const toggleDislike = () => {
    if (disliked) { setDisliked(false); return; }
    setDisliked(true);
    if (liked) { setLiked(false); setLikes((n) => n - 1); }
  };
  const toggleSubscribe = () => {
    if (subscribed) { setSubscribed(false); setSubs((n) => n - 1); toast("Unsubscribed"); return; }
    setSubscribed(true); setSubs((n) => n + 1); toast.success(`Subscribed to ${teacher.name}`);
  };
  const share = () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    navigator.clipboard?.writeText(url).then(() => toast.success("Link copied"));
  };

  const views = Math.floor(likes * 8);

  return (
    <Shell hideFooter>
      <div className="min-h-screen bg-cream/30">
        {/* Sticky mini-header */}
        <div className="sticky top-0 z-20 flex items-center gap-2 border-b-[1.5px] border-[#0F0F0F]/15 bg-white px-3 py-2 lg:px-6">
          <button
            onClick={() => nav({ to: "/communities/$slug/feed", params: { slug: c.slug } })}
            className="flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1.5 text-xs font-extrabold"
            style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </button>
          <div className="min-w-0 truncate text-sm font-extrabold">
            <span className="text-muted-foreground">Classroom · </span>{c.name}
          </div>
        </div>

        <div className="mx-auto grid max-w-7xl gap-4 p-3 lg:grid-cols-[minmax(0,1fr)_360px] lg:p-6">
          {/* MAIN */}
          <div className="min-w-0">
            {/* Player */}
            <div className="relative aspect-video w-full overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F] bg-black" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}>
              {isLive && (
                <div className="absolute left-3 top-3 z-10 flex items-center gap-2">
                  <span className="flex items-center gap-1 rounded-md bg-red-600 px-2 py-0.5 text-[10px] font-extrabold uppercase text-white">
                    <Radio className="h-3 w-3 animate-pulse" /> Live
                  </span>
                  <span className="rounded-md bg-black/70 px-2 py-0.5 text-[10px] font-bold text-white">
                    👁 {viewers.toLocaleString()} watching
                  </span>
                </div>
              )}
              {realLoading ? (
                <div className="grid h-full w-full place-items-center text-white/80 text-sm">Loading lecture…</div>
              ) : (
                <video
                  key={videoSrc}
                  ref={videoRef}
                  src={videoSrc}
                  controls
                  playsInline
                  className="h-full w-full bg-black"
                  poster={posterUrl}
                />
              )}
            </div>


            {/* Title */}
            <h1 className="mt-3 font-display text-lg font-extrabold leading-snug lg:text-2xl">{resource.title}</h1>
            <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] font-bold text-muted-foreground lg:text-xs">
              <span className="rounded bg-cream px-1.5 py-0.5 text-foreground/70">{resource.category}</span>
              <span>{views.toLocaleString()} views</span>
              <span>· {resource.date}</span>
            </div>

            {/* Channel + actions */}
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <Link to="/u/$username" params={{ username: teacher.username }} className="flex min-w-0 items-center gap-2">
                <img src={teacher.avatar} alt="" className="h-11 w-11 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]" />
                <div className="min-w-0">
                  <div className="truncate text-sm font-extrabold">{teacher.name}</div>
                  <div className="text-[11px] font-bold text-muted-foreground">{subs.toLocaleString()} subscribers</div>
                </div>
              </Link>
              <button
                onClick={toggleSubscribe}
                className={`ml-auto flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1.5 text-xs font-extrabold ${subscribed ? "bg-white text-foreground" : "bg-[#0F0F0F] text-white"}`}
                style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
              >
                {subscribed ? <><Check className="h-3.5 w-3.5" /> Subscribed</> : "Subscribe"}
              </button>
              {subscribed && (
                <button
                  onClick={() => { setNotified((n) => !n); toast(notified ? "Notifications off" : "All notifications on"); }}
                  className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white"
                  aria-label="Notifications"
                >
                  {notified ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
                </button>
              )}
            </div>

            {/* Action row */}
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <div className="flex items-center overflow-hidden rounded-full border-[1.5px] border-[#0F0F0F] bg-cream" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                <button onClick={toggleLike} className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-extrabold ${liked ? "text-coral" : ""}`}>
                  <ThumbsUp className={`h-3.5 w-3.5 ${liked ? "fill-current" : ""}`} /> {likes.toLocaleString()}
                </button>
                <span className="h-5 w-px bg-[#0F0F0F]/20" />
                <button onClick={toggleDislike} className={`px-3 py-1.5 text-xs font-extrabold ${disliked ? "text-coral" : ""}`}>
                  <ThumbsDown className={`h-3.5 w-3.5 ${disliked ? "fill-current" : ""}`} />
                </button>
              </div>
              <button onClick={share} className="flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1.5 text-xs font-extrabold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                <Share2 className="h-3.5 w-3.5" /> Share
              </button>
              <button
                onClick={() => { setSaved((s) => !s); toast.success(saved ? "Removed" : "Saved"); }}
                className={`flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1.5 text-xs font-extrabold ${saved ? "bg-coral text-white" : "bg-white"}`}
                style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
              >
                <Bookmark className={`h-3.5 w-3.5 ${saved ? "fill-current" : ""}`} /> {saved ? "Saved" : "Save"}
              </button>
              <button className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white" aria-label="More">
                <MoreHorizontal className="h-4 w-4" />
              </button>
            </div>

            {/* Description card */}
            <button
              onClick={() => setShowDesc((v) => !v)}
              className="mt-3 w-full rounded-lg border-[1.5px] border-[#0F0F0F]/15 bg-cream/60 p-3 text-left text-[13px] leading-relaxed text-foreground/85"
            >
              <div className="mb-1 flex items-center gap-2 text-[11px] font-extrabold text-muted-foreground">
                <span>{views.toLocaleString()} views</span>
                <span>· {resource.date}</span>
                <span className="ml-auto text-coral">{showDesc ? "Show less" : "…more"}</span>
              </div>
              <p className={showDesc ? "" : "line-clamp-2"}>
                <strong>{resource.title}</strong> — a {resource.kind.toLowerCase()} from{" "}
                <span className="font-bold text-coral">{teacher.name}</span>. Learn how to ship a
                production-ready workflow step by step. Ask questions in the chat — the community
                answers in real time. This session covers architecture, prompt design, evals, and
                deployment. Bring your ideas and build alongside.
              </p>
              {showDesc && (
                <div className="mt-2 flex flex-wrap gap-1.5 text-[11px] font-bold">
                  {["#tutorial", "#" + resource.category.toLowerCase().replace(/\s+/g, "-"), "#" + teacher.username].map((t) => (
                    <span key={t} className="rounded bg-white px-1.5 py-0.5 border border-[#0F0F0F]/15">{t}</span>
                  ))}
                </div>
              )}
            </button>

            {/* Comments */}
            <div className="mt-4 rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-3 lg:p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
              <div className="mb-3 flex items-center gap-2 text-sm font-extrabold">
                {isLive ? (
                  <><span className="h-2 w-2 rounded-full bg-red-600 animate-pulse" /> Live Chat</>
                ) : (
                  <>💬 Comments <span className="text-xs font-bold text-muted-foreground">({comments.length})</span></>
                )}
              </div>

              <div className="mb-3 flex items-center gap-2">
                <input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && submitComment()}
                  placeholder={isLive ? "Say something…" : "Add a comment…"}
                  className="min-w-0 flex-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-sm outline-none"
                />
                <button
                  onClick={submitComment}
                  className="grid h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-coral text-white"
                  style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                  aria-label="Send"
                ><Send className="h-4 w-4" /></button>
              </div>

              <div ref={chatRef} className="max-h-[420px] space-y-3 overflow-y-auto pr-1">
                {comments.map((cm) => {
                  const b = builders[cm.builderIdx % builders.length];
                  return (
                    <div key={cm.id} className="flex gap-2">
                      <img src={b.avatar} alt="" className="h-8 w-8 shrink-0 rounded-full border border-[#0F0F0F]/30" />
                      <div className="min-w-0 flex-1 text-[13px]">
                        <div className="flex items-baseline gap-1.5">
                          <Link to="/u/$username" params={{ username: b.username }} className="truncate text-[12px] font-extrabold hover:text-coral">
                            {b.name.split(" ")[0]}
                          </Link>
                          <span className="text-[10px] font-bold text-muted-foreground">{cm.time}</span>
                        </div>
                        <div className="leading-snug text-foreground/85">{cm.body}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* UP NEXT SIDEBAR */}
          <aside className="min-w-0">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-sm font-extrabold uppercase tracking-wide">Up Next</h2>
              <Link
                to="/communities/$slug/feed" params={{ slug: c.slug }}
                className="text-[11px] font-extrabold text-coral hover:underline"
              >All classroom →</Link>
            </div>
            <div className="space-y-2.5">
              {upNext.map((r) => (
                <UpNextItem key={r.id} slug={c.slug} r={r} liveId={liveId} />
              ))}
            </div>
          </aside>
        </div>
      </div>
    </Shell>
  );
}

function UpNextItem({ slug, r, liveId }: { slug: string; r: Resource; liveId: string | undefined }) {
  const b = builders[r.builderIdx % builders.length];
  const isLive = r.id === liveId;
  const views = (40 + (hash(r.id) % 1400)) * 8;
  return (
    <Link
      to="/communities/$slug/watch/$id" params={{ slug, id: r.id }}
      className="group flex gap-2.5 rounded-lg border-[1.5px] border-transparent p-1.5 hover:border-[#0F0F0F]/15 hover:bg-white"
    >
      <div
        className="relative aspect-video w-40 shrink-0 overflow-hidden rounded-md border border-[#0F0F0F]/20"
        style={{ background: "linear-gradient(135deg,#E8623A,#F5A623)" }}
      >
        <div className="absolute inset-0 grid place-items-center opacity-90 group-hover:opacity-100">
          <div className="grid h-8 w-8 place-items-center rounded-full bg-black/60 text-white">
            <Play className="h-3.5 w-3.5" fill="currentColor" />
          </div>
        </div>
        {isLive && (
          <span className="absolute left-1.5 top-1.5 flex items-center gap-1 rounded bg-red-600 px-1.5 py-0.5 text-[9px] font-extrabold uppercase text-white">
            <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" /> Live
          </span>
        )}
        <span className="absolute bottom-1.5 right-1.5 rounded bg-black/70 px-1 py-0.5 text-[9px] font-bold text-white">12:34</span>
      </div>
      <div className="min-w-0 flex-1">
        <h3 className="line-clamp-2 text-[13px] font-extrabold leading-snug group-hover:text-coral">{r.title}</h3>
        <div className="mt-1 flex items-center gap-1 text-[11px] font-bold text-muted-foreground">
          <img src={b.avatar} className="h-4 w-4 rounded-full" alt="" /> {b.name}
        </div>
        <div className="text-[10px] font-bold text-muted-foreground">
          {views.toLocaleString()} views · {r.date}
        </div>
      </div>
    </Link>
  );
}
