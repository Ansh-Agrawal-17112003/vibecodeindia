import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Shell, PageHeader } from "@/components/site/Shell";
import { BLOGS, type Blog } from "@/lib/blog-data";
import { loadSubmissions } from "@/lib/mock-data";
import { useTypewriter } from "@/hooks/useTypewriter";
import { Search } from "lucide-react";

export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [
      { title: 'Blog — VibeCoder Builder Stories & Playbooks' },
      { name: "description", content: "Playbooks, teardowns and interviews with India's top AI builders and vibe coders." },
      { property: "og:title", content: 'Blog — VibeCoder Builder Stories & Playbooks' },
      { property: "og:description", content: "Playbooks, teardowns and interviews with India's top AI builders and vibe coders." },
      { property: "og:url", content: 'https://joinvibecode.xyz/blog' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Blog — VibeCoder Builder Stories & Playbooks' },
      { name: "twitter:description", content: "Playbooks, teardowns and interviews with India's top AI builders and vibe coders." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/blog' }],
  }),
  component: BlogIndex,
});

function BlogIndex() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("All");
  const [userBlogs, setUserBlogs] = useState<Blog[]>([]);
  const placeholder = useTypewriter([
    "Search essays, tags, authors…",
    "Try 'prompt engineering'",
    "Try 'indie SaaS in India'",
    "Try 'n8n workflows'",
    "Try 'Supabase RLS'",
  ]);

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const subs = loadSubmissions().filter((s: any) => s.kind === "blog").map((s: any) => s.data as Blog);
    setUserBlogs(subs);
  }, []);

  const all = useMemo(() => [...userBlogs, ...BLOGS], [userBlogs]);
  const categories = useMemo(() => ["All", ...Array.from(new Set(all.map((b) => b.category)))], [all]);
  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return all.filter((b) => (cat === "All" || b.category === cat) && (!s || b.title.toLowerCase().includes(s) || b.excerpt.toLowerCase().includes(s) || b.tags.some((t) => t.toLowerCase().includes(s))));
  }, [q, cat, all]);

  const [featured, ...rest] = filtered;

  return (
    <Shell>
      <div className="hidden sm:block">
        <PageHeader breadcrumb="The VibeCoder Journal" title="Stories, playbooks, and build logs" subtitle="25+ deep essays on AI, indie SaaS, and the Indian builder movement — refreshed every week." />
      </div>
      <section className="container-page py-6 sm:py-10">
        <div className="mb-6 text-center sm:hidden">
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">The VibeCoder Journal</div>
          <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight">Stories, playbooks, and build logs</h1>
          <p className="mt-1 text-xs text-muted-foreground">25+ deep essays on AI, indie SaaS, and the Indian builder movement.</p>
        </div>
        <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="relative w-full md:max-w-md">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={placeholder} className="h-11 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-card pl-9 pr-3 text-sm font-medium outline-none" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }} />
          </div>
          <div className="hidden flex-wrap gap-2 md:flex">
            {categories.map((c) => (
              <button key={c} onClick={() => setCat(c)} className={`rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1.5 text-xs font-bold ${cat === c ? "bg-coral text-white" : "bg-card"}`} style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>{c}</button>
            ))}
          </div>
        </div>


        {featured && (
          <Link to="/blog/$slug" params={{ slug: featured.slug }} className="mb-8 grid overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F] bg-card md:grid-cols-2" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}>
            <img src={featured.cover} alt={featured.title} className="h-40 w-full object-cover sm:h-52 md:h-full" />
            <div className="flex flex-col justify-center gap-2 p-4 sm:p-6 md:gap-3 md:p-10">
              <span className="pill-badge w-fit bg-gold text-[#0F0F0F] text-[10px]">Featured · {featured.category}</span>
              <h2 className="font-display text-xl font-extrabold leading-tight sm:text-2xl md:text-4xl">{featured.title}</h2>
              <p className="text-sm text-muted-foreground line-clamp-3 md:line-clamp-none md:text-base">{featured.excerpt}</p>
              <div className="mt-1 text-[10px] font-bold uppercase tracking-wider text-foreground/70 md:text-xs">By {featured.author} · {featured.readMinutes} min read</div>
            </div>
          </Link>
        )}

        <div className="grid gap-4 sm:grid-cols-2 md:gap-6 lg:grid-cols-3">
          {rest.map((b) => (
            <Link key={b.id} to="/blog/$slug" params={{ slug: b.slug }} className="flex flex-col overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F] bg-card transition hover:-translate-y-0.5" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
              <img src={b.cover} alt={b.title} className="h-32 w-full object-cover sm:h-40 md:h-44" />
              <div className="flex flex-1 flex-col gap-1.5 p-4 sm:p-5">
                <span className="pill-badge w-fit bg-coral/10 text-coral text-[10px]">{b.category}</span>
                <h3 className="font-display text-base font-extrabold leading-snug sm:text-lg">{b.title}</h3>
                <p className="text-xs text-muted-foreground line-clamp-2 sm:text-sm">{b.excerpt}</p>
                <div className="mt-auto pt-2 text-[10px] font-bold uppercase tracking-wider text-foreground/60 sm:text-[11px]">{b.author} · {b.readMinutes} min</div>
              </div>
            </Link>
          ))}
        </div>


        {filtered.length === 0 && <div className="py-20 text-center text-muted-foreground">No essays match your search yet.</div>}
      </section>
    </Shell>
  );
}
