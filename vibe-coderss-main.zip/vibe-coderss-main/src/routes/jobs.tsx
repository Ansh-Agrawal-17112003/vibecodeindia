import { createFileRoute, Link } from "@tanstack/react-router";
import { Briefcase, MapPin, Plus, Search } from "lucide-react";

import { useEffect, useMemo, useState } from "react";
import { JobCard } from "@/components/cards/JobCard";
import { CoralWord } from "@/components/site/SectionHeader";
import { Shell } from "@/components/site/Shell";
import { AutocompleteInput } from "@/components/site/AutocompleteInput";
import { AI_TOOLS, INDUSTRIES, allJobs, type Job } from "@/lib/mock-data";
import { INDIA_LOCATIONS } from "@/lib/india-locations";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/jobs")({
  head: () => ({
    meta: [
      { title: 'Find AI Builder Jobs · VibeCode' },
      { name: "description", content: 'Browse AI, GenAI, prompt-engineering and automation jobs from Indian startups and studios hiring on VibeCode.' },
      { property: "og:title", content: 'Find AI Builder Jobs · VibeCode' },
      { property: "og:description", content: 'Browse AI, GenAI, prompt-engineering and automation jobs from Indian startups and studios hiring on VibeCode.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/jobs' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Find AI Builder Jobs · VibeCode' },
      { name: "twitter:description", content: 'Browse AI, GenAI, prompt-engineering and automation jobs from Indian startups and studios hiring on VibeCode.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/jobs' }],
  }),
  component: JobsPage,
});

const TYPES = ["Full-time", "Part-time", "Contract", "Internship"];
const REMOTE = ["Remote", "Hybrid", "On-site"];
const LEVELS = ["Entry", "Mid", "Senior", "Lead"];
const DATES = [
  { label: "Last 24h", days: 1 },
  { label: "Last week", days: 7 },
  { label: "Last month", days: 31 },
];

function parsePosted(p: string): number {
  const m = p.match(/(\d+)\s*([dw])/);
  if (!m) return 999;
  return Number(m[1]) * (m[2] === "w" ? 7 : 1);
}

function toggle<T>(a: T[], v: T) {
  return a.includes(v) ? a.filter((x) => x !== v) : [...a, v];
}

function JobsPage() {
  const [q, setQ] = useState("");
  const [loc, setLoc] = useState("");
  const [date, setDate] = useState<number | null>(null);
  const [types, setTypes] = useState<string[]>([]);
  const [levels, setLevels] = useState<string[]>([]);
  const [remote, setRemote] = useState<string[]>([]);
  const [industries, setIndustries] = useState<string[]>([]);
  const [tools, setTools] = useState<string[]>([]);
  const [dbJobs, setDbJobs] = useState<Job[]>([]);

  const loadJobs = () => {
    supabase
      .from("jobs")
      .select("id,title,description,location,job_type,remote_type,experience_level,tools_required,salary_min,salary_max,created_at,companies(name)")
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        if (!data) return;
        const mapType: Record<string, Job["type"]> = { "full-time": "Full-time", "part-time": "Part-time", freelance: "Contract", internship: "Internship" };
        const mapRemote: Record<string, Job["remote"]> = { remote: "Remote", hybrid: "Hybrid", onsite: "On-site" };
        const mapLevel: Record<string, Job["level"]> = { junior: "Entry", mid: "Mid", senior: "Senior", lead: "Lead" };
        const mapped: Job[] = data.map((r: any) => {
          const company = r.companies?.name ?? "Independent";
          const days = Math.max(0, Math.floor((Date.now() - new Date(r.created_at).getTime()) / 86400000));
          const salary = r.salary_min && r.salary_max ? `₹${Math.round(r.salary_min/100000)}-${Math.round(r.salary_max/100000)}L` : r.salary_min ? `₹${Math.round(r.salary_min/100000)}L+` : "Competitive";
          return {
            id: r.id,
            title: r.title,
            company,
            logo: "",
            location: r.location ?? "Remote",
            type: mapType[r.job_type] ?? "Full-time",
            remote: mapRemote[r.remote_type] ?? "Remote",
            level: mapLevel[r.experience_level ?? "mid"] ?? "Mid",
            salary,
            posted: days === 0 ? "today" : days < 7 ? `${days}d ago` : `${Math.floor(days/7)}w ago`,
            description: r.description ?? "",
            tools: r.tools_required ?? [],
            industry: "SaaS",
          };
        });
        setDbJobs(mapped);
      });
  };

  useEffect(() => {
    loadJobs();
    const channel = supabase
      .channel(`jobs:list:${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "jobs" }, () => loadJobs())
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "jobs" }, () => loadJobs())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    const lt = loc.trim().toLowerCase();
    const all = [...dbJobs, ...allJobs()];
    return all.filter((j) =>
      (!term || j.title.toLowerCase().includes(term) || j.company.toLowerCase().includes(term) || j.description.toLowerCase().includes(term) || j.tools.some((t) => t.toLowerCase().includes(term))) &&
      (!lt || j.location.toLowerCase().includes(lt)) &&
      (!types.length || types.includes(j.type)) &&
      (!levels.length || levels.includes(j.level)) &&
      (!remote.length || remote.includes(j.remote)) &&
      (!industries.length || industries.includes(j.industry)) &&
      (!tools.length || j.tools.some((t) => tools.includes(t))) &&
      (date === null || parsePosted(j.posted) <= date)
    );
  }, [q, loc, date, types, levels, remote, industries, tools, dbJobs]);

  const allJobsList = useMemo(() => [...dbJobs, ...allJobs()], [dbJobs]);
  const jobSuggestions = useMemo(
    () => allJobsList.flatMap((j) => [j.title, j.company, ...j.tools]),
    [allJobsList],
  );

  const clearAll = () => {
    setQ("");
    setLoc("");
    setDate(null);
    setTypes([]);
    setLevels([]);
    setRemote([]);
    setIndustries([]);
    setTools([]);
  };

  return (
    <Shell>
      <section className="relative border-b-[1.5px] border-[#0F0F0F] bg-card">
        <Link
          to="/submit-job"
          className="absolute right-4 top-4 z-10 hidden items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-4 py-2 text-xs font-bold text-white shadow-[3px_3px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:shadow-[5px_5px_0_0_#0F0F0F] sm:inline-flex"
        >
          <Plus className="h-3.5 w-3.5" /> Post a Job
        </Link>
        <div className="container-page py-8 sm:py-14">
          <div className="mx-auto max-w-3xl text-center">

            <h1 className="font-display text-3xl sm:text-5xl font-extrabold tracking-tight md:text-6xl">
              Find your <CoralWord>Dream Job</CoralWord>
            </h1>
            <p className="mt-3 sm:mt-4 text-sm sm:text-base text-muted-foreground md:text-lg">
              Browse our latest AI job openings to view & apply to the best builder jobs today.
            </p>
            <div className="card-flat mt-5 sm:mt-8 grid grid-cols-1 gap-2 p-2 sm:grid-cols-[1fr_1fr_auto]">
              <div className="flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-background px-3 py-2.5">
                <Briefcase className="h-4 w-4 text-muted-foreground" />
                <AutocompleteInput
                  value={q}
                  onChange={setQ}
                  placeholder="Job title or keyword"
                  typewriter={["AI Engineer at a startup...", "Prompt Engineer remote...", "Full-stack + LangChain...", "Founding Engineer...", "GenAI Product Manager..."]}
                  className="flex-1 bg-transparent text-sm outline-none"
                  suggestions={jobSuggestions}
                />
              </div>
              <div className="flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-background px-3 py-2.5">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <AutocompleteInput
                  value={loc}
                  onChange={setLoc}
                  placeholder="Location"
                  typewriter={["Bengaluru, Karnataka...", "Remote, India...", "Mumbai, Maharashtra...", "Delhi NCR...", "Hyderabad, Telangana..."]}
                  className="flex-1 bg-transparent text-sm outline-none"
                  suggestions={INDIA_LOCATIONS}
                />
              </div>
              <button className="btn-coral" onClick={(e) => e.preventDefault()}>
                <Search className="h-4 w-4" /> Search
              </button>
            </div>
          </div>
        </div>
      </section>

      <div className="container-page py-6 sm:py-10">
        <div className="mb-4 sm:mb-6 hidden sm:flex flex-wrap items-end gap-3">
          <h2 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight">Total Jobs</h2>
          <span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 py-1 text-xs font-bold text-foreground">{filtered.length} job results</span>
        </div>
        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <aside className="card-editorial sticky top-24 hidden h-[calc(100vh-7rem)] space-y-5 overflow-y-auto p-5 lg:block">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-base font-bold">Filters</h3>
              <button onClick={clearAll} className="text-xs font-bold text-coral hover:underline">Clear all</button>
            </div>
            <FG title="Date posted">
              {DATES.map((d) => <label key={d.label} className="flex items-center gap-2 text-sm"><input type="radio" name="date" checked={date === d.days} onChange={() => setDate(d.days)} className="accent-coral" />{d.label}</label>)}
              <label className="flex items-center gap-2 text-sm"><input type="radio" name="date" checked={date === null} onChange={() => setDate(null)} className="accent-coral" />Any</label>
            </FG>
            <FG title="Job Type">{TYPES.map((t) => <FC key={t} label={t} checked={types.includes(t)} onChange={() => setTypes((p) => toggle(p, t))} />)}</FG>
            <FG title="Experience">{LEVELS.map((l) => <FC key={l} label={l} checked={levels.includes(l)} onChange={() => setLevels((p) => toggle(p, l))} />)}</FG>
            <FG title="On-site / Remote">{REMOTE.map((r) => <FC key={r} label={r} checked={remote.includes(r)} onChange={() => setRemote((p) => toggle(p, r))} />)}</FG>
            <FG title="Industry">{INDUSTRIES.slice(0, 6).map((i) => <FC key={i} label={i} checked={industries.includes(i)} onChange={() => setIndustries((p) => toggle(p, i))} />)}</FG>
            <FG title="AI Tools">{AI_TOOLS.slice(0, 6).map((t) => <FC key={t} label={t} checked={tools.includes(t)} onChange={() => setTools((p) => toggle(p, t))} />)}</FG>
          </aside>
          <div className="space-y-3">
            {filtered.length ? filtered.map((j) => <JobCard key={j.id} j={j} />) : <div className="card-editorial p-12 text-center"><div className="text-2xl">💼</div><p className="mt-2 text-sm text-muted-foreground">No jobs match your filters.</p></div>}
          </div>
        </div>
      </div>
    </Shell>
  );
}

function FG({ title, children }: { title: string; children: React.ReactNode }) {
  return <div><div className="mb-2 text-xs font-bold uppercase tracking-wider">{title}</div><div className="space-y-1.5">{children}</div></div>;
}

function FC({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return <label className="flex cursor-pointer items-center gap-2 text-sm"><input type="checkbox" checked={checked} onChange={onChange} className="h-3.5 w-3.5 accent-coral" />{label}</label>;
}
