import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/enterprise/employer-branding")({
  head: () => ({
    meta: [
      { title: "Employer Branding · VibeCode" },
      { name: "description", content: "A branded company page, sponsored builds, and always-on inbound from the builders you want to hire." },
      { property: "og:title", content: "Employer Branding · VibeCode" },
      { property: "og:description", content: "A branded company page, sponsored builds, and always-on inbound from the builders you want to hire." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/enterprise/employer-branding" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/enterprise/employer-branding" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Employer Branding"
      breadcrumb={[{"label":"Enterprise","to":"/"}]}
      title="Own your presence here."
      intro="A branded company page, sponsored builds, and always-on inbound from the builders you want to hire."
      toc={[{"id":"includes","label":"What is included"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="includes" title="What is included"><NotionFeatureGrid items={[{"title":"Branded company page","description":"Team, culture, open roles, tech stack, wins."},{"title":"Sponsored builds","description":"Fund community projects using your stack."},{"title":"Featured content","description":"Engineering essays from your team get pinned."},{"title":"Analytics","description":"Track visits, applies, and offer conversions."}]} /></NotionSection>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Is this an ad product?" a="No. Sponsored builds are labelled but they are real projects — no banner ads, ever." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
