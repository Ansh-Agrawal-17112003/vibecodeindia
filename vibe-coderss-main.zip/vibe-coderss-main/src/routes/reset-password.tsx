import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [{ title: "Reset password · VibeCode" }] }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Password updated.");
    navigate({ to: "/dashboard" });
  }

  return (
    <div className="grid min-h-screen place-items-center px-6">
      <form onSubmit={submit} className="w-full max-w-sm rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-6" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}>
        <h1 className="font-display text-2xl font-extrabold">Set a new password</h1>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="New password" minLength={6} required className="mt-5 h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
        <button disabled={busy} className="btn-coral mt-3 h-11 w-full">{busy ? "Updating…" : "Update password"}</button>
      </form>
    </div>
  );
}
