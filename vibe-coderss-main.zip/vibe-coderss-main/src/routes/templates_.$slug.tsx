import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { Download, ArrowLeft, Star, Check, Copy, Eye, GitBranch, Clock, Shield, Zap, Code2, FileText, MessageSquare } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Shell } from "@/components/site/Shell";
import { TemplateCard } from "@/components/cards/TemplateCard";
import { ToolLogos } from "@/components/site/ToolLogo";
import { getTemplate, templates, getBuilder } from "@/lib/mock-data";
import { sharePage } from "@/lib/share";

export const Route = createFileRoute("/templates_/$slug")({
  head: ({ params }) => ({ meta: [{ title: `${params.slug} · Templates · VibeCoder` }] }),
  loader: ({ params }) => {
    const t = getTemplate(params.slug);
    if (!t) throw notFound();
    return { template: t };
  },
  notFoundComponent: () => (
    <Shell><div className="container-page py-20 text-center"><h1 className="font-display text-3xl font-extrabold">Template not found</h1><Link to="/templates" className="mt-4 inline-block text-coral underline">Back to templates</Link></div></Shell>
  ),
  component: TemplateDetail,
});

const FEATURES = [
  { icon: Shield, label: "Auth & protected routes", body: "Email/password + OAuth ready to wire, with server-side session guards." },
  { icon: Code2, label: "Typed database layer", body: "Postgres schema, row-level security policies, generated TypeScript types." },
  { icon: Zap, label: "Production-ready UI", body: "Tailwind design tokens, shadcn primitives, dark mode toggle, motion presets." },
  { icon: GitBranch, label: "CI + deploy scripts", body: "One-click deploy configs plus GitHub Actions for lint, typecheck, preview builds." },
  { icon: FileText, label: "Docs + example content", body: "Rich README, contribution guide, seed data so you can demo immediately." },
  { icon: MessageSquare, label: "Community support", body: "Private thread on VibeCoder for buyers — questions answered within 24h." },
];

const CHANGELOG = [
  { v: "v1.4.0", date: "2 weeks ago", note: "Added Stripe subscriptions + billing portal wiring." },
  { v: "v1.3.1", date: "1 month ago", note: "Upgraded to Tailwind v4 and shadcn latest primitives." },
  { v: "v1.2.0", date: "2 months ago", note: "RLS policies audited + role-based dashboard." },
  { v: "v1.0.0", date: "4 months ago", note: "Initial release." },
];

const FAQ = [
  { q: "Do I get lifetime updates?", a: "Yes. One purchase = every future update on this template, delivered via a version bump inside your buyer thread." },
  { q: "Can I use it for client work?", a: "Absolutely — unlimited commercial projects. You cannot resell the template itself as a standalone product." },
  { q: "What if I get stuck?", a: "Every buyer gets access to a private support thread. Most questions are answered within 24 hours by the author." },
  { q: "Is a refund available?", a: "Digital delivery is final, but we do refund within 48h if the template does not match its description." },
];

function TemplateDetail() {
  const { template: t } = Route.useLoaderData();
  const navigate = useNavigate();
  const author = getBuilder(t.builderId);
  const isFree = /free/i.test(t.price) || t.price === "₹0";
  const amount = Number(t.price.replace(/[^0-9]/g, "")) || 999;
  const [tab, setTab] = useState<"overview" | "features" | "stack" | "changelog" | "faq">("overview");

  const handleGet = () => {
    if (isFree) {
      const content = `# ${t.title}\n\n${t.description}\n\nCategory: ${t.category}\nFramework: ${t.framework}\nStack: ${t.stack.join(", ")}\n\n---\nDownloaded from VibeCoder\n`;
      const blob = new Blob([content], { type: "text/markdown" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `${t.slug}.md`; a.click();
      URL.revokeObjectURL(url);
      toast.success("Template downloaded!");
    } else {
      navigate({ to: "/checkout/$plan", params: { plan: `template-${t.slug}` }, search: { amount, name: t.title, desc: `Template · ${t.category} · ${t.framework}` } });
    }
  };

  const copyInstall = () => {
    navigator.clipboard.writeText(`npx create-vibecoder@latest --template ${t.slug}`);
    toast.success("Install command copied!");
  };

  const related = templates.filter((x) => x.category === t.category && x.slug !== t.slug).slice(0, 3);
  const TABS = [
    { id: "overview", label: "Overview" },
    { id: "features", label: "Features" },
    { id: "stack", label: "Tech stack" },
    { id: "changelog", label: "Changelog" },
    { id: "faq", label: "FAQ" },
  ] as const;

  return (
    <Shell>
      <div className="container-page py-6 md:py-8">
        <Link to="/templates" className="inline-flex items-center gap-1 text-sm font-bold text-coral hover:underline"><ArrowLeft className="h-4 w-4" /> Back to templates</Link>

        <div className="mt-4 grid gap-4 md:gap-6 lg:grid-cols-[1fr_320px]">
          {/* MAIN */}
          <div className="min-w-0">
            <div className="card-editorial overflow-hidden">
              <div className="aspect-[16/9] overflow-hidden border-b-[1.5px] border-[#0F0F0F]">
                <img src={t.cover} alt="" className="h-full w-full object-cover" />
              </div>
              <div className="p-4 sm:p-6">
                <div className="flex flex-wrap gap-2 text-[10px] font-bold uppercase tracking-wider">
                  <span className="rounded-md bg-teal/25 px-2 py-0.5 text-[#0a6b5e]">{t.category}</span>
                  <span className="rounded-md bg-pink px-2 py-0.5 text-[#0F0F0F]">{t.framework}</span>
                  <span className="rounded-md bg-[#0F0F0F]/10 px-2 py-0.5">v1.4.0</span>
                  <span className="rounded-md bg-gold/40 px-2 py-0.5 flex items-center gap-1"><Clock className="h-3 w-3" /> Updated recently</span>
                </div>
                <h1 className="mt-3 font-display text-2xl font-extrabold tracking-tight sm:text-3xl md:text-4xl">{t.title}</h1>
                <p className="mt-2 text-sm text-muted-foreground md:text-base">{t.description}</p>
                <div className="mt-4"><ToolLogos names={t.stack} max={8} /></div>

                <div className="mt-5 flex flex-wrap gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Download className="h-3.5 w-3.5" /> {t.downloads.toLocaleString()} downloads</span>
                  <span className="flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-gold text-gold" /> 4.8 (128 reviews)</span>
                  <span className="flex items-center gap-1"><Eye className="h-3.5 w-3.5" /> 12.4k views</span>
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div className="mt-6 overflow-x-auto">
              <div className="flex min-w-max gap-2 border-b-[1.5px] border-[#0F0F0F]/20 pb-0">
                {TABS.map((x) => (
                  <button key={x.id} onClick={() => setTab(x.id)} className={`px-3 py-2 text-sm font-bold transition ${tab === x.id ? "border-b-[3px] border-coral text-coral" : "text-muted-foreground hover:text-foreground"}`}>{x.label}</button>
                ))}
              </div>
            </div>

            <div className="mt-6">
              {tab === "overview" && (
                <div className="space-y-6">
                  <div className="card-editorial p-4 sm:p-6">
                    <h2 className="font-display text-lg font-extrabold sm:text-xl">About this template</h2>
                    <p className="mt-2 text-sm text-muted-foreground sm:text-base">
                      A production-tested {t.framework} template for shipping {t.category.toLowerCase()} projects in hours instead of weeks. Every piece — auth, database, billing, UI system, deploy scripts — has been used in real revenue-generating apps and refined based on buyer feedback.
                    </p>
                    <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                      {["Ship faster with battle-tested defaults", "Zero boilerplate — start with real features", "Clean, typed, and documented codebase", "Author-supported with weekly updates"].map((b) => (
                        <li key={b} className="flex items-start gap-2 text-sm"><Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /> {b}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="card-editorial p-4 sm:p-6">
                    <h3 className="font-display text-base font-extrabold sm:text-lg">Quick install</h3>
                    <div className="mt-3 flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] p-3 font-mono text-xs text-emerald-300 sm:text-sm">
                      <code className="flex-1 overflow-x-auto whitespace-nowrap">$ npx create-vibecoder@latest --template {t.slug}</code>
                      <button onClick={copyInstall} className="shrink-0 rounded-md border border-white/20 bg-white/10 p-1.5 text-white hover:bg-white/20"><Copy className="h-3.5 w-3.5" /></button>
                    </div>
                    <p className="mt-2 text-xs text-muted-foreground">Requires Node 18+. Full setup takes under 90 seconds.</p>
                  </div>

                  <div className="card-editorial p-4 sm:p-6">
                    <h3 className="font-display text-base font-extrabold sm:text-lg">Perfect for</h3>
                    <div className="mt-3 grid gap-3 sm:grid-cols-3">
                      {["Indie founders shipping MVPs", "Agencies delivering client work", "Hackathon teams needing speed"].map((x) => (
                        <div key={x} className="rounded-md border-[1.5px] border-[#0F0F0F]/70 bg-surface p-3 text-sm font-semibold">{x}</div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {tab === "features" && (
                <div className="grid gap-3 sm:grid-cols-2">
                  {FEATURES.map((f) => (
                    <div key={f.label} className="card-editorial flex gap-3 p-4">
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-coral/10 text-coral"><f.icon className="h-4 w-4" /></span>
                      <div className="min-w-0">
                        <div className="font-bold">{f.label}</div>
                        <p className="mt-0.5 text-xs text-muted-foreground sm:text-sm">{f.body}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {tab === "stack" && (
                <div className="card-editorial p-4 sm:p-6">
                  <h3 className="font-display text-base font-extrabold sm:text-lg">Built with</h3>
                  <div className="mt-4 grid gap-3 sm:grid-cols-2">
                    {t.stack.map((s: string) => (
                      <div key={s} className="flex items-center gap-3 rounded-md border-[1.5px] border-[#0F0F0F]/70 bg-surface p-3">
                        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-cream text-xs font-black">{s.slice(0, 2).toUpperCase()}</div>
                        <div className="min-w-0"><div className="truncate font-bold">{s}</div><div className="text-[11px] text-muted-foreground">Pre-configured</div></div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {tab === "changelog" && (
                <div className="card-editorial p-4 sm:p-6">
                  <h3 className="font-display text-base font-extrabold sm:text-lg">Version history</h3>
                  <ul className="mt-3 space-y-3">
                    {CHANGELOG.map((c) => (
                      <li key={c.v} className="flex flex-col gap-1 border-l-[3px] border-coral/60 pl-3 sm:flex-row sm:items-center sm:gap-3">
                        <span className="rounded-md bg-coral/10 px-2 py-0.5 text-xs font-black text-coral w-fit">{c.v}</span>
                        <span className="text-xs text-muted-foreground">{c.date}</span>
                        <span className="text-sm">{c.note}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {tab === "faq" && (
                <div className="space-y-3">
                  {FAQ.map((f) => (
                    <details key={f.q} className="card-editorial p-4 sm:p-5">
                      <summary className="cursor-pointer font-bold">{f.q}</summary>
                      <p className="mt-2 text-sm text-muted-foreground">{f.a}</p>
                    </details>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* SIDEBAR */}
          <aside className="space-y-4 lg:sticky lg:top-20 lg:h-fit">
            <div className="card-editorial p-4 sm:p-5">
              <div className="font-display text-3xl font-extrabold text-coral">{t.price}</div>
              <div className="text-[11px] text-muted-foreground">One-time · Lifetime updates</div>
              <button onClick={handleGet} className="btn-coral mt-3 w-full"><Download className="h-4 w-4" /> {isFree ? "Download free" : `Get template`}</button>
              <button onClick={() => sharePage(t.title, t.description)} className="btn-outline mt-2 w-full">Share template</button>
              <div className="mt-4 space-y-2 border-t-[1.5px] border-[#0F0F0F]/10 pt-3 text-xs">
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Downloads</span><span className="font-bold">{t.downloads.toLocaleString()}</span></div>
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Framework</span><span className="font-bold">{t.framework}</span></div>
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Category</span><span className="font-bold">{t.category}</span></div>
                <div className="flex items-center justify-between"><span className="text-muted-foreground">License</span><span className="font-bold">Commercial</span></div>
              </div>
            </div>

            <div className="card-editorial p-4 sm:p-5">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Author</div>
              <Link to="/u/$username" params={{ username: author.username }} className="mt-3 flex items-center gap-3">
                <img src={author.avatar} alt="" className="h-10 w-10 rounded-full border-[1.5px] border-[#0F0F0F]" />
                <div className="min-w-0">
                  <div className="truncate font-bold">{author.name}</div>
                  <div className="truncate text-xs text-muted-foreground">{author.title}</div>
                </div>
              </Link>
              <Link to="/messages" className="btn-outline mt-3 w-full">Message author</Link>
            </div>

            <div className="card-editorial bg-cream p-4 sm:p-5">
              <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider"><Shield className="h-4 w-4 text-emerald-700" /> Buyer protection</div>
              <p className="mt-2 text-xs text-muted-foreground">48h refund window · Private support thread · Lifetime updates included.</p>
            </div>
          </aside>
        </div>

        {related.length > 0 && (
          <section className="mt-10">
            <h3 className="mb-4 font-display text-xl font-extrabold">More {t.category} templates</h3>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{related.map((x) => <TemplateCard key={x.id} t={x} />)}</div>
          </section>
        )}
      </div>
    </Shell>
  );
}
