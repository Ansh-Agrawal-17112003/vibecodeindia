import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/solutions/ai-engineers")({
  head: () => ({
    meta: [
      { title: "For AI Engineers · VibeCode" },
      { name: "description", content: "A serious playground for AI engineers who care about eval, latency, cost, and shipping production LLM systems." },
      { property: "og:title", content: "For AI Engineers · VibeCode" },
      { property: "og:description", content: "A serious playground for AI engineers who care about eval, latency, cost, and shipping production LLM systems." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/solutions/ai-engineers" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/solutions/ai-engineers" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="For AI Engineers"
      breadcrumb={[{"label":"Solutions","to":"/"}]}
      title="Deep prompts, tools, and roles."
      intro="A serious playground for AI engineers who care about eval, latency, cost, and shipping production LLM systems."
      toc={[{"id":"built","label":"Built for engineers"},{"id":"depth","label":"Depth over hype"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="built" title="Built for engineers"><NotionFeatureGrid items={[{"title":"Vetted prompt library","description":"Only prompts with real production usage — filter by model, cost, and eval score."},{"title":"Tool reviews with signal","description":"Reviews written by people who shipped, not who tweeted."},{"title":"Workflow blueprints","description":"n8n, LangChain, and agent pipelines you can fork today."},{"title":"Engineering-only jobs","description":"Filter roles by stack: OpenAI, Anthropic, vLLM, RAG, agents."}]} /></NotionSection>
      <NotionSection id="depth" title="Depth over hype"><p>No "10 AI tools you must try" posts. The moderation team scrubs low-signal content daily so your feed stays technical.</p></NotionSection>
      <NotionQuote by="Ankit R., ML Engineer">The prompt library alone saved me a week on our RAG rewrite. Actual production prompts, actual eval numbers.</NotionQuote>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Which models are covered?" a="GPT-4/5, Claude, Gemini, Llama, Mistral, Qwen, and open-source variants. Every prompt tags the model it was validated on." />
          <NotionToggle q="Is there paid content?" a="No. All prompts, tools, and workflows are free to read. Pro is optional for freelancers." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
