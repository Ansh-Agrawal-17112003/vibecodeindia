import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Check, ArrowRight, UserPlus, Briefcase, FolderGit2, Workflow, Sparkles, Wrench, Layers, Users, PenLine } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { CoralWord } from "@/components/site/SectionHeader";
import { saveSubmission } from "@/lib/mock-data";
import { insertEntity } from "@/lib/entity-live";

type Kind = "builder" | "project" | "workflow" | "prompt" | "job" | "service" | "tool" | "template" | "community" | "blog";
type SearchSchema = { kind?: Kind };

export const Route = createFileRoute("/submit")({
  validateSearch: (s: Record<string, unknown>): SearchSchema => ({
    kind: typeof s.kind === "string" ? (s.kind as Kind) : undefined,
  }),
  head: () => ({
    meta: [
      { title: 'Submit to VibeCode · Open to everyone' },
      { name: "description", content: "Submit your project, prompt, workflow, tool or template to India's largest AI builder community." },
      { property: "og:title", content: 'Submit to VibeCode · Open to everyone' },
      { property: "og:description", content: "Submit your project, prompt, workflow, tool or template to India's largest AI builder community." },
      { property: "og:url", content: 'https://joinvibecode.xyz/submit' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Submit to VibeCode · Open to everyone' },
      { name: "twitter:description", content: "Submit your project, prompt, workflow, tool or template to India's largest AI builder community." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/submit' }],
  }),
  component: SubmitPage,
});

const KINDS: { id: Kind; label: string; desc: string; icon: React.ReactNode; color: string }[] = [
  { id: "builder",   label: "Create Profile", desc: "Public profile for HRs, clients and collaborators.", icon: <UserPlus className="h-5 w-5" />,    color: "#E8623A" },
  { id: "project",   label: "Project",        desc: "Showcase what you built.",                            icon: <FolderGit2 className="h-5 w-5" />, color: "#2DD4BF" },
  { id: "workflow",  label: "Workflow",       desc: "Share an n8n / Make automation.",                     icon: <Workflow className="h-5 w-5" />,   color: "#F5A623" },
  { id: "prompt",    label: "Prompt",         desc: "Drop a prompt into the library.",                     icon: <Sparkles className="h-5 w-5" />,   color: "#7C3AED" },
  { id: "job",       label: "Job Posting",    desc: "Hire AI builders directly.",                          icon: <Briefcase className="h-5 w-5" />,  color: "#0F0F0F" },
  { id: "service",   label: "Service",        desc: "List a freelance / agency service.",                  icon: <Wrench className="h-5 w-5" />,     color: "#FF4D8D" },
  { id: "tool",      label: "AI Tool",        desc: "Add a tool to the directory.",                        icon: <Layers className="h-5 w-5" />,     color: "#22C55E" },
  { id: "template",  label: "Template",       desc: "Ship a Lovable / Cursor template.",                   icon: <Layers className="h-5 w-5" />,     color: "#0a6b5e" },
  { id: "community", label: "Community",      desc: "Start a new community space.",                        icon: <Users className="h-5 w-5" />,      color: "#E8623A" },
  { id: "blog",      label: "Write a Blog",   desc: "Publish a long-form essay on the VibeCoder Journal.", icon: <PenLine className="h-5 w-5" />,    color: "#F5A623" },
];

function SubmitPage() {
  const { kind: initialKind } = Route.useSearch();
  const [kind, setKind] = useState<Kind | null>(initialKind ?? null);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});

  function setF(k: string, v: string) { setForm((p) => ({ ...p, [k]: v })); }
  function reset() { setForm({}); setDone(false); setKind(null); }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!kind) return;
    const id = String(Date.now());
    const baseImg = `https://api.dicebear.com/7.x/notionists/svg?seed=${id}`;
    // Build the payload per kind. We persist locally — no backend needed.
    let payload: unknown;
    switch (kind) {
      case "builder":
        payload = { id, username: (form.name || "guest").toLowerCase().replace(/[^a-z]/g, "") + id.slice(-4), name: form.name, title: form.title, avatar: baseImg, location: form.location || "Remote", available: true, verified: false, bio: form.bio, skills: (form.skills || "").split(",").map((s) => s.trim()).filter(Boolean), tools: (form.tools || "").split(",").map((s) => s.trim()).filter(Boolean), rating: 5, reviews: 0, followers: 0, following: 0, projects: 0, industry: [form.industry || "SaaS"], type: "Freelancer", experience: "Intermediate", hourlyRate: Number(form.rate) || 1500 };
        break;
      case "project":
        payload = { id, title: form.title, cover: "", builderId: "1", description: form.description, tools: (form.tools || "").split(",").map((s) => s.trim()), industry: form.industry || "SaaS", upvotes: 0, date: "just now" };
        break;
      case "workflow":
        payload = { id, title: form.title, cover: "", tools: (form.tools || "").split(",").map((s) => s.trim()), category: form.category || "Productivity", description: form.description, upvotes: 0, builderId: "1" };
        break;
      case "prompt":
        payload = { id, title: form.title, model: form.model || "Claude", category: form.category || "Engineering", preview: (form.full || "").slice(0, 140), full: form.full, upvotes: 0, builderId: "1" };
        break;
      case "job":
        payload = { id, title: form.title, company: form.company, logo: "", location: form.location || "Remote", type: form.type || "Full-time", remote: form.remote || "Remote", level: form.level || "Mid", salary: form.salary || "Negotiable", posted: "just now", description: form.description, tools: (form.tools || "").split(",").map((s) => s.trim()), industry: form.industry || "SaaS" };
        break;
      case "service":
        payload = { id, title: form.title, builderId: "1", cover: "", price: Number(form.price) || 10000, delivery: Number(form.delivery) || 7, rating: 5, reviews: 0, tags: (form.tags || "").split(",").map((s) => s.trim()), category: form.category || "Development" };
        break;
      case "tool":
        payload = { id, slug: (form.name || "tool").toLowerCase().replace(/[^a-z0-9]+/g, "-"), name: form.name, tagline: form.tagline, category: form.category || "DevTools", pricing: form.pricing || "Freemium", logoBg: "#0F0F0F", url: form.url, upvotes: 0, description: form.description };
        break;
      case "template":
        payload = { id, slug: (form.title || "template").toLowerCase().replace(/[^a-z0-9]+/g, "-"), title: form.title, cover: "", stack: (form.stack || "").split(",").map((s) => s.trim()), category: form.category || "SaaS", framework: form.framework || "Lovable", price: form.price || "Free", downloads: 0, description: form.description, builderId: "1" };
        break;
      case "community":
        payload = { id, slug: (form.name || "community").toLowerCase().replace(/[^a-z0-9]+/g, "-"), name: form.name, icon: form.icon || "🌐", members: 0, postsThisWeek: 0, description: form.description, hue: 200 };
        break;
      case "blog": {
        const slug = (form.title || "post").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
        const paragraphs = (form.body || "").split(/\n{2,}/).map((p: string) => p.trim()).filter(Boolean);
        const words = (form.body || "").trim().split(/\s+/).length;
        payload = {
          id, slug, title: form.title, excerpt: form.excerpt || (form.body || "").slice(0, 160),
          category: form.category || "Community",
          author: form.author || "Guest Author", authorRole: form.authorRole || "VibeCoder Community",
          readMinutes: Math.max(3, Math.round(words / 200)),
          publishedAt: new Date().toISOString(),
          cover: form.cover || `https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=1200&h=630&fit=crop&auto=format`,
          tags: (form.tags || "").split(",").map((s: string) => s.trim()).filter(Boolean),
          body: paragraphs.length ? paragraphs : [form.body || ""],
        };
        break;
      }
    }
    // Try to persist to backend first (real submissions go live everywhere via realtime).
    // Falls back to local mock save when the user isn't signed in, when the kind
    // isn't backed by a DB table (builder / blog), or if the insert fails.
    const persistable = ["project", "service", "community", "prompt", "workflow", "tool", "template"] as const;
    let backendId: string | null = null;
    if ((persistable as readonly string[]).includes(kind)) {
      backendId = await insertEntity(kind as (typeof persistable)[number], form);
    }
    if (!backendId) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      saveSubmission({ kind, data: payload } as any);
    }
    setDone(true);
  }

  return (
    <Shell>
      <section className="border-b-[1.5px] border-[#0F0F0F] bg-card">
        <div className="container-page py-10">
          <span className="pill-badge bg-gold text-[#0F0F0F]">PUBLISHED INSTANTLY — LIVE IN UNDER 60 SECONDS</span>
          <h1 className="mt-3 font-display text-4xl font-extrabold tracking-tight md:text-5xl">
            Add to <CoralWord>VibeCode</CoralWord> in 60 seconds.
          </h1>
          <p className="mt-3 max-w-2xl text-sm text-muted-foreground md:text-base">
            No reviews, no waiting. Submit a profile, job, project, prompt, workflow, tool, template, service or community and it goes live across the portal immediately.
          </p>

        </div>
      </section>

      <div className="container-page py-10">
        {done ? (
          <div className="card-editorial mx-auto max-w-2xl p-10 text-center">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-teal text-white" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}><Check className="h-8 w-8" /></div>
            <h2 className="mt-5 font-display text-3xl font-extrabold">You're live. 🎉</h2>
            <p className="mt-2 text-sm text-muted-foreground">Your submission is published instantly across VibeCode — it's already visible in the library. No team review required.</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <button onClick={reset} className="btn-coral">Submit another <ArrowRight className="h-4 w-4" /></button>
              <Link to="/explore" className="btn-outline-dark">Browse builders</Link>
            </div>

          </div>
        ) : !kind ? (
          <>
            <h2 className="mb-4 font-display text-2xl font-extrabold">What do you want to add?</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {KINDS.map((k) => (
                <button key={k.id} onClick={() => setKind(k.id)} className="card-editorial group flex items-start gap-4 p-5 text-left transition hover:border-coral hover:-translate-y-0.5">
                  <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl border-[1.5px] border-[#0F0F0F] text-white" style={{ background: k.color, boxShadow: "2px 2px 0 0 #0F0F0F" }}>{k.icon}</div>
                  <div className="min-w-0">
                    <div className="font-display text-lg font-bold">{k.label}</div>
                    <div className="mt-0.5 text-sm text-muted-foreground">{k.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </>
        ) : (
          <div className="mx-auto max-w-2xl">
            <button onClick={() => setKind(null)} className="mb-4 text-sm font-bold text-coral hover:underline">← Choose a different type</button>
            <form onSubmit={submit} className="card-editorial space-y-4 p-6">
              <h2 className="font-display text-2xl font-extrabold">{KINDS.find((k) => k.id === kind)!.label}</h2>
              {fieldsFor(kind).map((f) => (
                <Field key={f.name} {...f} value={form[f.name] || ""} onChange={(v) => setF(f.name, v)} />
              ))}
              <button type="submit" className="btn-coral w-full">Publish instantly <ArrowRight className="h-4 w-4" /></button>
              <p className="text-center text-[11px] text-muted-foreground">Goes live in &lt; 60 seconds. No login. No team review.</p>

            </form>
          </div>
        )}
      </div>
    </Shell>
  );
}

type FieldDef = { name: string; label: string; type?: "text" | "textarea" | "number"; placeholder?: string; required?: boolean };
function fieldsFor(k: Kind): FieldDef[] {
  switch (k) {
    case "builder":  return [{ name: "name", label: "Full name", required: true }, { name: "title", label: "Headline (e.g. AI Workflow Engineer)", required: true }, { name: "location", label: "City" }, { name: "bio", label: "Short bio", type: "textarea" }, { name: "skills", label: "Skills (comma-separated)" }, { name: "tools", label: "Tools (comma-separated)" }, { name: "industry", label: "Primary industry" }, { name: "rate", label: "Hourly rate (₹)", type: "number" }];
    case "project":  return [{ name: "title", label: "Project title", required: true }, { name: "description", label: "What it does", type: "textarea", required: true }, { name: "tools", label: "Tools (comma-separated)" }, { name: "industry", label: "Industry" }];
    case "workflow": return [{ name: "title", label: "Workflow title", required: true }, { name: "category", label: "Category" }, { name: "tools", label: "Tools (comma-separated)" }, { name: "description", label: "What it does", type: "textarea", required: true }];
    case "prompt":   return [{ name: "title", label: "Prompt title", required: true }, { name: "model", label: "Model (Claude, GPT-4o, …)" }, { name: "category", label: "Category" }, { name: "full", label: "The full prompt", type: "textarea", required: true }];
    case "job":      return [{ name: "title", label: "Role title", required: true }, { name: "company", label: "Company", required: true }, { name: "location", label: "Location" }, { name: "type", label: "Type (Full-time / Contract / Internship)" }, { name: "remote", label: "Remote / Hybrid / On-site" }, { name: "level", label: "Level (Entry / Mid / Senior / Lead)" }, { name: "salary", label: "Salary range" }, { name: "tools", label: "Tools (comma-separated)" }, { name: "industry", label: "Industry" }, { name: "description", label: "Job description", type: "textarea", required: true }];
    case "service":  return [{ name: "title", label: "Service title", required: true }, { name: "price", label: "Price (₹)", type: "number" }, { name: "delivery", label: "Delivery (days)", type: "number" }, { name: "category", label: "Category" }, { name: "tags", label: "Tags (comma-separated)" }];
    case "tool":     return [{ name: "name", label: "Tool name", required: true }, { name: "tagline", label: "One-liner", required: true }, { name: "url", label: "Website URL", required: true }, { name: "category", label: "Category" }, { name: "pricing", label: "Pricing (Free / Freemium / Paid)" }, { name: "description", label: "Description", type: "textarea" }];
    case "template": return [{ name: "title", label: "Template title", required: true }, { name: "framework", label: "Framework (Lovable / Cursor / n8n / v0 / Bolt)" }, { name: "stack", label: "Stack (comma-separated)" }, { name: "category", label: "Category" }, { name: "price", label: "Price (Free or ₹xx)" }, { name: "description", label: "Description", type: "textarea" }];
    case "community":return [{ name: "name", label: "Community name", required: true }, { name: "icon", label: "Emoji icon" }, { name: "description", label: "What it's about", type: "textarea", required: true }];
    case "blog":     return [{ name: "title", label: "Blog title", required: true }, { name: "author", label: "Your name" }, { name: "authorRole", label: "Your role (e.g. Indie Founder)" }, { name: "category", label: "Category (Community, AI, Tools, Design…)" }, { name: "tags", label: "Tags (comma-separated)" }, { name: "excerpt", label: "One-line excerpt" }, { name: "cover", label: "Cover image URL" }, { name: "body", label: "Full blog (separate paragraphs with a blank line)", type: "textarea", required: true }];
  }
}

function Field({ name, label, type = "text", placeholder, required, value, onChange }: FieldDef & { value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider">{label}{required && <span className="text-coral"> *</span>}</span>
      {type === "textarea" ? (
        <textarea id={name} value={value} onChange={(e) => onChange(e.target.value)} required={required} placeholder={placeholder} rows={4} className="w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-background px-3 py-2 text-sm outline-none focus:border-coral" />
      ) : (
        <input id={name} value={value} onChange={(e) => onChange(e.target.value)} type={type} required={required} placeholder={placeholder} className="h-10 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-background px-3 text-sm outline-none focus:border-coral" />
      )}
    </label>
  );
}
