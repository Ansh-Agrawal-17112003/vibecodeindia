import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useState, useMemo } from "react";
import { Shell } from "@/components/site/Shell";
import { WorkflowCard } from "@/components/cards/WorkflowCard";
import { AutocompleteInput } from "@/components/site/AutocompleteInput";
import { StatsStrip } from "@/components/site/StatsStrip";
import { workflows as mockWorkflows } from "@/lib/mock-data";
import { useLiveTable, mapWorkflow } from "@/lib/entity-live";

export const Route = createFileRoute("/workflows")({
  head: () => ({
    meta: [
      { title: 'Workflow Library · VibeCode' },
      { name: "description", content: 'n8n, Make, Zapier and agent workflows built and tested by AI operators in India.' },
      { property: "og:title", content: 'Workflow Library · VibeCode' },
      { property: "og:description", content: 'n8n, Make, Zapier and agent workflows built and tested by AI operators in India.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/workflows' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Workflow Library · VibeCode' },
      { name: "twitter:description", content: 'n8n, Make, Zapier and agent workflows built and tested by AI operators in India.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/workflows' }],
  }),
  component: WorkflowsPage,
});

const categories = ["All", "Sales Ops", "Support", "Content", "Finance", "Marketing", "Engineering", "Productivity", "HealthTech"];

function WorkflowsPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const dbRows = useLiveTable("workflows", mapWorkflow);
  const workflows = useMemo(() => {
    const seen = new Set(dbRows.map((w) => w.id));
    return [...dbRows, ...mockWorkflows.filter((w) => !seen.has(w.id))];
  }, [dbRows]);
  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return workflows.filter((w) =>
      (cat === "All" || w.category === cat) &&
      (!t || w.title.toLowerCase().includes(t) || w.description.toLowerCase().includes(t) || w.tools.some((x) => x.toLowerCase().includes(t)))
    );
  }, [q, cat, workflows]);

  return (
    <Shell>
      <div className="container-page py-5 sm:py-8">
        <div className="mb-6 text-center sm:mb-8 sm:text-left">
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground sm:text-xs">Library</div>
          <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight sm:text-3xl md:text-4xl">Workflow Library</h1>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">{filtered.length} production-ready n8n, Make and Zapier workflows. Fork and deploy.</p>
        </div>
        <div className="hidden sm:block">
          <StatsStrip items={[
            { label: "Workflows", value: workflows.length },
            { label: "Categories", value: categories.length - 1 },
            { label: "Total Runs", value: 128000, suffix: "+" },
            { label: "Contributors", value: 640, suffix: "+" },
          ]} />
        </div>
        <div className="card-flat mb-5 flex items-center gap-3 p-2 pl-4">
          <Search className="h-4 w-4 text-muted-foreground" />
          <AutocompleteInput
            value={q}
            onChange={setQ}
            placeholder="Search workflows..."
            typewriter={["Lead enrichment on autopilot...", "Slack → Notion sync...", "n8n invoice automation...", "AI support triage...", "Zapier CRM pipeline..."]}
            suggestions={workflows.flatMap((w) => [w.title, w.category, ...w.tools])}
          />
        </div>
        <div className="mb-6 hidden flex-wrap gap-2 sm:flex">
          {categories.map((c) => (
            <button key={c} onClick={() => setCat(c)} className={`rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1 text-xs font-bold transition ${cat === c ? "bg-coral text-white" : "bg-card text-foreground hover:bg-coral hover:text-white"}`} style={cat === c ? { boxShadow: "2px 2px 0 0 #0F0F0F" } : undefined}>{c}</button>
          ))}
        </div>

        {filtered.length ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{filtered.map((w) => <WorkflowCard key={w.id} w={w} />)}</div>
        ) : <div className="card-editorial p-12 text-center text-sm text-muted-foreground">No workflows match.</div>}
      </div>
    </Shell>
  );
}
