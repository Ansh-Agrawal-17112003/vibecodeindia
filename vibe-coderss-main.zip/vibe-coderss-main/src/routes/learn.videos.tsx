import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/learn/videos")({
  head: () => ({
    meta: [
      { title: "Video Library · VibeCode" },
      { name: "description", content: "Bite-sized videos from working AI engineers. Every video is under 10 minutes and ends with a runnable artifact." },
      { property: "og:title", content: "Video Library · VibeCode" },
      { property: "og:description", content: "Bite-sized videos from working AI engineers. Every video is under 10 minutes and ends with a runnable artifact." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/learn/videos" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/learn/videos" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Video Library"
      breadcrumb={[{"label":"Learn","to":"/"}]}
      title="Watch. Pause. Ship."
      intro="Bite-sized videos from working AI engineers. Every video is under 10 minutes and ends with a runnable artifact."
      toc={[{"id":"kinds","label":"What you can watch"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="kinds" title="What you can watch"><NotionFeatureGrid items={[{"title":"Build-alongs","description":"Ship a small project alongside the creator."},{"title":"Deep dives","description":"10-minute explainers on a single concept."},{"title":"Tool tours","description":"Real workflows in Cursor, Lovable, n8n, Windsurf."},{"title":"Interview replays","description":"Watch senior engineers debug in public."}]} /></NotionSection>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Is video content free?" a="Yes. Everything is free. Pro is optional and only affects freelance visibility." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
