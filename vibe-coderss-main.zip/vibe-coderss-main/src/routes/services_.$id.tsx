import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Check, Star, Clock, Shield, Zap, MessageSquare, ChevronRight, Award, Globe, RefreshCcw, Send, Users, Eye, Timer } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { ServiceCard } from "@/components/cards/ServiceCard";
import { getBuilder, services, allServices } from "@/lib/mock-data";

export const Route = createFileRoute("/services_/$id")({
  loader: ({ params }) => {
    const s = allServices().find((x) => x.id === params.id) ?? services.find((x) => x.id === params.id);
    if (!s) throw notFound();
    return { service: s };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.service.title} · VibeCode` },
      { name: "description", content: `${loaderData?.service.title} — ${loaderData?.service.category} service starting at ₹${loaderData?.service.price.toLocaleString("en-IN")}.` },
    ],
  }),
  component: ServiceDetail,
  notFoundComponent: () => (
    <Shell>
      <div className="container-page py-20 text-center text-muted-foreground">Service not found.</div>
    </Shell>
  ),
});

function ServiceDetail() {
  const { service: s } = Route.useLoaderData();
  const b = getBuilder(s.builderId);

  const packages = [
    {
      name: "Starter",
      price: s.price,
      delivery: s.delivery,
      features: ["Core deliverable", "1 round of revisions", "Email support", "Source files included"],
    },
    {
      name: "Standard",
      price: Math.round(s.price * 2.2),
      delivery: s.delivery + 4,
      popular: true,
      features: [
        "Everything in Starter",
        "3 rounds of revisions",
        "Documentation & handover",
        "Priority chat support",
        "30-min strategy call",
      ],
    },
    {
      name: "Premium",
      price: Math.round(s.price * 4.5),
      delivery: s.delivery + 10,
      features: [
        "Everything in Standard",
        "Unlimited revisions",
        "Deployment & QA",
        "30-day post-launch support",
        "Weekly 1:1 calls",
      ],
    },
  ];

  const responsibilities = [
    `Scoping ${s.category.toLowerCase()} requirements with you in a kickoff call`,
    `Designing the architecture using ${s.tags.join(", ")}`,
    "Building production-ready, well-documented code",
    "QA, testing, and bug-fixing before handover",
    "Deployment guidance and post-launch walkthrough",
  ];

  const requirements = [
    "Clear brief or reference examples of what you want",
    "Access to brand assets (logo, colors) if relevant",
    "API keys / accounts for any third-party tools",
    "A single decision-maker for fast approvals",
  ];

  const process = [
    { step: "Brief", desc: "We hop on a 30-min call to align on goals, scope, and success metrics." },
    { step: "Build", desc: "I work in 2-3 day sprints with daily Loom updates so you're never in the dark." },
    { step: "Review", desc: "You review each milestone and request revisions inside the agreed scope." },
    { step: "Ship", desc: "Final QA, deployment, handover docs, and a launch walkthrough." },
  ];

  const faq = [
    { q: "How do payments work?", a: "50% upfront to start, 50% on delivery. Pay via UPI, card, or international wire — Razorpay invoice provided." },
    { q: "Do you sign an NDA?", a: "Yes. Send your NDA and I'll counter-sign within 24 hours before any work begins." },
    { q: "What if I need changes after delivery?", a: "Every package includes a defined number of revisions. Out-of-scope changes are billed at ₹2,500/hr." },
    { q: "Who owns the code?", a: "You do. Full IP transfer on final payment, including source, design files, and credentials." },
  ];

  const related = allServices()
    .filter((x) => x.id !== s.id && x.category === s.category)
    .slice(0, 3);

  const seedReviews = [
    { name: "Aarav Mehta", rating: 5, text: "Shipped exactly what was promised, ahead of schedule. Code is clean and well documented." },
    { name: "Priya Shah", rating: 5, text: "Communication was top-notch. Daily updates and proactive suggestions made the project effortless." },
    { name: "Rohan Iyer", rating: 5, text: "Took our vague idea and turned it into a real working product. Will hire again." },
    { name: "Ananya Rao", rating: 4, text: "Worth every rupee. The 1:1 calls alone saved us weeks of trial-and-error." },
    { name: "Vikram Singh", rating: 5, text: "Delivered a polished MVP in under 2 weeks. Beyond expectations." },
    { name: "Meera Kapoor", rating: 5, text: "Handled scope changes gracefully. Very transparent about tradeoffs." },
    { name: "Karan Patel", rating: 4, text: "Great engineering, thoughtful UX suggestions along the way." },
  ];
  const storageKey = `svc-reviews-${s.id}`;
  const [reviews, setReviews] = useState<{ name: string; rating: number; text: string }[]>(() => {
    if (typeof window === "undefined") return seedReviews;
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
      return [...saved, ...seedReviews];
    } catch { return seedReviews; }
  });
  const [rName, setRName] = useState("");
  const [rText, setRText] = useState("");
  const [rRating, setRRating] = useState(5);
  const submitReview = () => {
    if (!rName.trim() || rText.trim().length < 8) { toast.error("Add your name and a review of 8+ characters"); return; }
    const next = { name: rName.trim(), rating: rRating, text: rText.trim() };
    const updated = [next, ...reviews];
    setReviews(updated);
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
      localStorage.setItem(storageKey, JSON.stringify([next, ...saved]));
    } catch { /* noop */ }
    setRName(""); setRText(""); setRRating(5);
    toast.success("Review posted — appearing live now");
  };

  // Availability countdown — seller open for the next 3 days
  const deadline = useMemo(() => {
    const seed = parseInt(s.id.replace(/\D/g, "") || "1", 10);
    const hours = 24 * 3 + (seed % 48);
    return Date.now() + hours * 3600_000;
  }, [s.id]);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const remaining = Math.max(0, deadline - now);
  const days = Math.floor(remaining / 86400000);
  const hrs = Math.floor((remaining % 86400000) / 3600000);
  const mins = Math.floor((remaining % 3600000) / 60000);
  const secs = Math.floor((remaining % 60000) / 1000);

  // Live viewer counter
  const [viewers, setViewers] = useState(() => 12 + ((parseInt(s.id.replace(/\D/g, "") || "1", 10)) % 20));
  useEffect(() => {
    const t = setInterval(() => setViewers((v) => Math.max(6, v + (Math.random() > 0.5 ? 1 : -1))), 3500);
    return () => clearInterval(t);
  }, []);

  const marqueeRef = useRef<HTMLDivElement>(null);


  return (
    <Shell>
      {/* Breadcrumb */}
      <div className="border-b-[1.5px] border-[#0F0F0F] bg-surface/40">
        <div className="container-page flex items-center gap-2 py-3 text-xs text-muted-foreground">
          <Link to="/" className="hover:text-coral">Home</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to="/services" className="hover:text-coral">Services</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground">{s.category}</span>
        </div>
      </div>

      <div className="container-page py-8 pb-24">
        <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
          {/* Main */}
          <div className="space-y-8">
            <div className="card-brutal overflow-hidden">
              <img src={s.cover} alt="" className="aspect-[16/9] w-full object-cover" />
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="pill-badge bg-coral text-white">{s.category}</span>
                {s.tags.map((t: string) => (
                  <span key={t} className="pill-badge border-[1.5px] border-[#0F0F0F] bg-background text-foreground">{t}</span>
                ))}
              </div>
              <h1 className="mt-4 font-display text-3xl font-extrabold leading-tight tracking-tight md:text-4xl">{s.title}</h1>
              <div className="mt-4 flex flex-wrap items-center gap-4 text-sm">
                <Link to="/u/$username" params={{ username: b.username }} className="flex items-center gap-2 hover:text-coral">
                  <img src={b.avatar} alt="" className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F]" />
                  <span className="font-bold">{b.name}</span>
                </Link>
                <span className="flex items-center gap-1"><Star className="h-4 w-4 fill-gold text-gold" /> <strong>{s.rating}</strong> <span className="text-muted-foreground">({s.reviews} reviews)</span></span>
                <span className="flex items-center gap-1 text-muted-foreground"><Clock className="h-4 w-4" /> {s.delivery}-day delivery</span>
                <span className="flex items-center gap-1 text-muted-foreground"><Globe className="h-4 w-4" /> Remote · India</span>
              </div>
            </div>

            {/* About */}
            <section className="card-brutal p-6">
              <h2 className="font-display text-xl font-extrabold">About this service</h2>
              <p className="mt-3 leading-relaxed text-foreground/90">
                I'll deliver a production-grade <strong>{s.category.toLowerCase()}</strong> engagement built with{" "}
                <strong>{s.tags.join(", ")}</strong>. Over the last 4+ years I've shipped 50+ projects for founders,
                agencies, and Series A startups — combining AI-first tooling with battle-tested engineering practices so
                you get speed without trading off reliability.
              </p>
              <p className="mt-3 leading-relaxed text-foreground/90">
                This isn't a template. Every deliverable is scoped to your business, written in clean, well-documented
                code, and handed over with a launch walkthrough so your team can own it from day one.
              </p>
              <div className="mt-5 grid gap-3 sm:grid-cols-3">
                {[
                  { icon: Zap, label: "Fast turnaround" },
                  { icon: Shield, label: "NDA-friendly" },
                  { icon: RefreshCcw, label: "Revisions included" },
                ].map((i) => (
                  <div key={i.label} className="flex items-center gap-2 border-[1.5px] border-[#0F0F0F] bg-background px-3 py-2 text-sm font-semibold">
                    <i.icon className="h-4 w-4 text-coral" /> {i.label}
                  </div>
                ))}
              </div>
            </section>

            {/* What's included */}
            <section className="card-brutal p-6">
              <h2 className="font-display text-xl font-extrabold">What I'll do for you</h2>
              <ul className="mt-4 space-y-2.5">
                {responsibilities.map((r) => (
                  <li key={r} className="flex items-start gap-3 text-sm">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-coral" /> {r}
                  </li>
                ))}
              </ul>
            </section>

            {/* Packages */}
            <section>
              <h2 className="font-display text-xl font-extrabold">Pick a package</h2>
              <div className="mt-4 grid gap-4 md:grid-cols-3">
                {packages.map((p) => (
                  <div key={p.name} className={`card-brutal relative p-5 ${p.popular ? "bg-coral/10" : ""}`}>
                    {p.popular && (
                      <span className="absolute -top-3 left-4 pill-badge bg-coral text-white">Most popular</span>
                    )}
                    <div className="font-display text-lg font-extrabold">{p.name}</div>
                    <div className="mt-2 font-display text-3xl font-extrabold text-coral">₹{p.price.toLocaleString("en-IN")}</div>
                    <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><Clock className="h-3 w-3" /> {p.delivery} day delivery</div>
                    <ul className="mt-4 space-y-2 text-sm">
                      {p.features.map((f) => (
                        <li key={f} className="flex items-start gap-2"><Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-coral" /> {f}</li>
                      ))}
                    </ul>
                    <Link
                      to="/checkout/service/$id"
                      params={{ id: s.id }}
                      className="mt-5 block w-full border-[1.5px] border-[#0F0F0F] bg-foreground py-2.5 text-center text-sm font-bold text-background transition hover:bg-coral"
                    >
                      Choose {p.name} →
                    </Link>
                  </div>
                ))}
              </div>
            </section>

            {/* Requirements */}
            <section className="card-brutal p-6">
              <h2 className="font-display text-xl font-extrabold">What I'll need from you</h2>
              <ul className="mt-4 grid gap-2.5 sm:grid-cols-2">
                {requirements.map((r) => (
                  <li key={r} className="flex items-start gap-2 text-sm"><Check className="mt-0.5 h-4 w-4 shrink-0 text-coral" /> {r}</li>
                ))}
              </ul>
            </section>

            {/* Process */}
            <section>
              <h2 className="font-display text-xl font-extrabold">How we'll work together</h2>
              <ol className="mt-4 grid gap-4 md:grid-cols-2">
                {process.map((p, i) => (
                  <li key={p.step} className="card-brutal p-5">
                    <div className="flex items-center gap-3">
                      <span className="flex h-8 w-8 items-center justify-center border-[1.5px] border-[#0F0F0F] bg-coral font-display font-extrabold text-white">{i + 1}</span>
                      <span className="font-display text-lg font-extrabold">{p.step}</span>
                    </div>
                    <p className="mt-3 text-sm text-foreground/80">{p.desc}</p>
                  </li>
                ))}
              </ol>
            </section>

            {/* FAQ */}
            <section className="card-brutal p-6">
              <h2 className="font-display text-xl font-extrabold">FAQs</h2>
              <div className="mt-4 divide-y divide-border">
                {faq.map((f) => (
                  <div key={f.q} className="py-3">
                    <div className="font-bold text-foreground">{f.q}</div>
                    <p className="mt-1 text-sm text-muted-foreground">{f.a}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Reviews summary */}
            <section className="card-brutal p-6">
              <div className="flex items-end justify-between">
                <h2 className="font-display text-xl font-extrabold">Reviews ({reviews.length})</h2>
                <span className="flex items-center gap-1 text-sm font-bold"><Star className="h-4 w-4 fill-gold text-gold" /> {s.rating} average</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">Live reviews stream on the right in real-time. Add yours from the sidebar and watch it appear instantly.</p>
            </section>

            {/* Related */}
            {related.length > 0 && (
              <section>
                <h2 className="font-display text-xl font-extrabold">More {s.category} services</h2>
                <div className="mt-4 grid gap-5 md:grid-cols-3">
                  {related.map((r) => <ServiceCard key={r.id} s={r} />)}
                </div>
              </section>
            )}
          </div>

          {/* Sticky sidebar */}
          <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
            <div className="card-brutal p-5">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Starting at</div>
              <div className="mt-1 font-display text-4xl font-extrabold text-coral">₹{s.price.toLocaleString("en-IN")}</div>
              <div className="mt-1 flex items-center gap-1 text-sm text-muted-foreground"><Clock className="h-4 w-4" /> Delivery in {s.delivery} days</div>

              {/* Availability timer */}
              <div className="mt-4 rounded-lg border-[1.5px] border-[#0F0F0F] bg-gold/20 p-3">
                <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider">
                  <Timer className="h-3.5 w-3.5 text-coral" /> Available for the next
                </div>
                <div className="mt-1.5 grid grid-cols-4 gap-1.5 text-center">
                  {[{ n: days, l: "d" }, { n: hrs, l: "h" }, { n: mins, l: "m" }, { n: secs, l: "s" }].map((t, i) => (
                    <div key={i} className="border-[1.5px] border-[#0F0F0F] bg-white py-1.5">
                      <div className="font-display text-lg font-extrabold leading-none tabular-nums">{String(t.n).padStart(2, "0")}</div>
                      <div className="text-[9px] font-bold text-muted-foreground">{t.l}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Live viewers */}
              <div className="mt-3 flex items-center justify-between rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-xs">
                <span className="flex items-center gap-1.5 font-bold"><Eye className="h-3.5 w-3.5 text-coral" /> {viewers} viewing now</span>
                <span className="relative flex h-2.5 w-2.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-coral opacity-70" />
                  <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-coral" />
                </span>
              </div>

              <Link
                to="/checkout/service/$id"
                params={{ id: s.id }}
                className="mt-4 block w-full border-[1.5px] border-[#0F0F0F] bg-coral py-3 text-center font-display text-sm font-extrabold text-white transition hover:bg-foreground hover:shadow-[4px_4px_0_0_#0F0F0F]"
              >
                Order Now → Pay securely
              </Link>
              <a
                href={`mailto:${b.username}@vibecode.in?subject=${encodeURIComponent("Question about: " + s.title)}`}
                className="mt-2 flex w-full items-center justify-center gap-2 border-[1.5px] border-[#0F0F0F] bg-background py-3 text-sm font-bold hover:bg-surface"
              >
                <MessageSquare className="h-4 w-4" /> Message {b.name.split(" ")[0]}
              </a>

              <div className="mt-5 space-y-2 border-t-[1.5px] border-[#0F0F0F] pt-4 text-sm">
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Revisions</span><strong>Included</strong></div>
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Source files</span><strong>Yes</strong></div>
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Payment</span><strong>Escrow · 100% safe</strong></div>
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Languages</span><strong>EN · HI</strong></div>
              </div>
            </div>

            {/* Live vertical marquee reviews */}
            <div className="card-brutal overflow-hidden p-0">
              <div className="flex items-center justify-between border-b-[1.5px] border-[#0F0F0F] bg-cream px-4 py-2.5">
                <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider">
                  <Users className="h-3.5 w-3.5 text-coral" /> Live reviews
                </div>
                <span className="flex items-center gap-1 text-[11px] font-bold text-coral">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-coral opacity-70" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-coral" />
                  </span>
                  LIVE
                </span>
              </div>
              {/* Mobile: simple stacked list, no marquee overlap */}
              <div className="flex flex-col gap-3 p-3 lg:hidden">
                {reviews.slice(0, 5).map((r, i) => (
                  <div key={i} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-white p-3">
                    <div className="flex items-center gap-2">
                      <img src={`https://api.dicebear.com/7.x/notionists/svg?seed=${r.name}`} alt="" className="h-8 w-8 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]" />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-xs font-bold">{r.name}</div>
                        <div className="text-[10px] text-gold">{"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)}</div>
                      </div>
                    </div>
                    <p className="mt-2 text-xs leading-snug text-foreground/85">{r.text}</p>
                  </div>
                ))}
              </div>
              {/* Desktop: vertical marquee */}
              <div ref={marqueeRef} className="relative hidden h-[440px] overflow-hidden lg:block" onMouseEnter={(e) => { const el = e.currentTarget.querySelector<HTMLDivElement>("[data-track]"); if (el) el.style.animationPlayState = "paused"; }} onMouseLeave={(e) => { const el = e.currentTarget.querySelector<HTMLDivElement>("[data-track]"); if (el) el.style.animationPlayState = "running"; }}>
                <div className="pointer-events-none absolute inset-x-0 top-0 z-10 h-10 bg-gradient-to-b from-cream to-transparent" />
                <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 h-10 bg-gradient-to-t from-cream to-transparent" />
                <div
                  data-track
                  key={reviews.length}
                  className="flex flex-col gap-3 p-3"
                  style={{ animation: `svc-marquee-y ${Math.max(20, reviews.length * 6)}s linear infinite` }}
                >
                  {[...reviews, ...reviews].map((r, i) => (
                    <div key={i} className="shrink-0 rounded-md border-[1.5px] border-[#0F0F0F] bg-white p-3">
                      <div className="flex items-center gap-2">
                        <img src={`https://api.dicebear.com/7.x/notionists/svg?seed=${r.name}`} alt="" className="h-8 w-8 rounded-full border-[1.5px] border-[#0F0F0F]" />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-xs font-bold">{r.name}</div>
                          <div className="text-[10px] text-gold">{"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)}</div>
                        </div>
                      </div>
                      <p className="mt-2 text-xs leading-snug text-foreground/85">{r.text}</p>
                    </div>
                  ))}
                </div>
              </div>
              <style>{`@keyframes svc-marquee-y { from { transform: translateY(0); } to { transform: translateY(-50%); } }`}</style>
            </div>

            {/* Add your review — sits directly under live testimonials */}
            <div className="card-brutal p-4">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider">
                <Send className="h-3.5 w-3.5 text-coral" /> Add your review
              </div>
              <p className="mt-1 text-[11px] text-muted-foreground">Posts appear in the live stream above instantly.</p>
              <div className="mt-3 space-y-2">
                <input value={rName} onChange={(e) => setRName(e.target.value)} placeholder="Your name" className="w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2.5 py-2 text-xs focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                <div className="flex items-center gap-0.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2.5 py-1.5">
                  <span className="mr-1.5 text-[10px] font-bold uppercase text-muted-foreground">Rate</span>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button key={n} type="button" onClick={() => setRRating(n)} className="p-0.5">
                      <Star className={`h-4 w-4 ${n <= rRating ? "fill-gold text-gold" : "text-muted-foreground"}`} />
                    </button>
                  ))}
                </div>
                <textarea value={rText} onChange={(e) => setRText(e.target.value)} placeholder="Share your experience…" className="min-h-[70px] w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2.5 py-2 text-xs focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                <button onClick={submitReview} className="inline-flex w-full items-center justify-center gap-1.5 border-[1.5px] border-[#0F0F0F] bg-coral py-2 text-xs font-bold text-white transition hover:bg-foreground">
                  <Send className="h-3.5 w-3.5" /> Post review
                </button>
              </div>
            </div>


            <div className="card-brutal p-5">
              <div className="flex items-center gap-3">
                <img src={b.avatar} alt="" className="h-12 w-12 rounded-full border-[1.5px] border-[#0F0F0F]" />
                <div>
                  <div className="font-display font-extrabold">{b.name}</div>
                  <div className="text-xs text-muted-foreground">@{b.username}</div>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
                <div className="border-[1.5px] border-[#0F0F0F] bg-background py-2">
                  <div className="font-display text-base font-extrabold">{s.rating}</div>
                  <div className="text-muted-foreground">Rating</div>
                </div>
                <div className="border-[1.5px] border-[#0F0F0F] bg-background py-2">
                  <div className="font-display text-base font-extrabold">{s.reviews}+</div>
                  <div className="text-muted-foreground">Orders</div>
                </div>
                <div className="border-[1.5px] border-[#0F0F0F] bg-background py-2">
                  <div className="font-display text-base font-extrabold">&lt;2h</div>
                  <div className="text-muted-foreground">Reply</div>
                </div>
              </div>
              <Link
                to="/u/$username"
                params={{ username: b.username }}
                className="mt-4 flex items-center justify-center gap-2 border-[1.5px] border-[#0F0F0F] bg-background py-2 text-sm font-bold hover:bg-surface"
              >
                <Award className="h-4 w-4" /> View profile
              </Link>
            </div>
          </aside>
        </div>
      </div>
    </Shell>
  );
}
