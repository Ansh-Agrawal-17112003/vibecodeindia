import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Sparkles, Trophy, Plus } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { StatsStrip } from "@/components/site/StatsStrip";
import {
  fetchFeaturedMoments,
  fetchWeeklyCount,
  KIND_EMOJI,
  KIND_LABEL,
  type RealValueMoment,
} from "@/lib/rvm-api";
import { useAuth } from "@/hooks/useAuth";
import { SubmitMomentDialog } from "@/components/site/SubmitMomentDialog";

export const Route = createFileRoute("/wins")({
  head: () => ({
    meta: [
      { title: "Real Wins · VibeCode" },
      {
        name: "description",
        content:
          "Real outcomes from the VibeCode community — hires, collabs, cashouts, and shipped projects.",
      },
      { property: "og:title", content: "Real Wins · VibeCode" },
      {
        property: "og:description",
        content: "Real outcomes builders got from VibeCode — not vanity metrics.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WinsPage,
});

function WinsPage() {
  const { user } = useAuth();
  const [moments, setMoments] = useState<RealValueMoment[]>([]);
  const [weekly, setWeekly] = useState<{ week_start: string; total: number; verified: number }[]>([]);
  const [openSubmit, setOpenSubmit] = useState(false);
  const [loading, setLoading] = useState(true);

  async function reload() {
    setLoading(true);
    const [m, w] = await Promise.all([fetchFeaturedMoments(40), fetchWeeklyCount()]);
    setMoments(m);
    setWeekly(w);
    setLoading(false);
  }

  useEffect(() => {
    reload();
  }, []);

  const thisWeek = weekly[0]?.verified ?? 0;
  const total = weekly.reduce((s, w) => s + Number(w.verified), 0);
  const hires = moments.filter((m) => m.kind === "hire" || m.kind === "freelance").length;
  const cashouts = moments
    .filter((m) => m.kind === "cashout")
    .reduce((s, m) => s + (m.amount_inr ?? 0), 0);

  return (
    <Shell>
      <div className="container-page py-8 sm:py-12">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border-[1.5px] border-foreground bg-gold px-3 py-1 text-[11px] font-extrabold uppercase tracking-wider">
              <Trophy className="h-3.5 w-3.5" /> Real value, not vanity
            </div>
            <h1 className="mt-3 font-display text-3xl font-extrabold sm:text-5xl">
              Real Wins from real builders
            </h1>
            <p className="mt-2 max-w-2xl text-sm text-muted-foreground sm:text-base">
              Every card below is something a builder got from VibeCode they couldn't have gotten
              elsewhere — a hire, a collab shipped, a prompt that saved hours, real rupees cashed out.
            </p>
          </div>
          <button
            onClick={() => (user ? setOpenSubmit(true) : (window.location.href = "/auth"))}
            className="btn-coral h-10"
          >
            <Plus className="h-4 w-4" /> Share your win
          </button>
        </div>

        <StatsStrip
          items={[
            { label: "Wins this week", value: Number(thisWeek) },
            { label: "Wins (12 wk)", value: Number(total) },
            { label: "Hires & gigs", value: hires },
            { label: "Cashed out", value: cashouts, prefix: "₹" },
          ]}
        />

        {loading ? (
          <div className="py-20 text-center text-sm text-muted-foreground">Loading wins…</div>
        ) : moments.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {moments.map((m) => (
              <WinCard key={m.id} m={m} />
            ))}
          </div>
        )}
      </div>

      {user && (
        <SubmitMomentDialog
          open={openSubmit}
          onClose={() => setOpenSubmit(false)}
          userId={user.id}
          onSubmitted={reload}
        />
      )}
    </Shell>
  );
}

function WinCard({ m }: { m: RealValueMoment }) {
  const p = m.profile;
  const name = p?.display_name ?? p?.username ?? "A builder";
  const avatar =
    p?.avatar_url ??
    `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(name)}`;
  return (
    <div
      className={`card-editorial relative flex h-full flex-col gap-3 p-4 ${
        m.featured ? "ring-2 ring-coral" : ""
      }`}
    >
      {m.featured && (
        <span className="absolute -top-2 right-3 rounded-full border-[1.5px] border-foreground bg-coral px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white">
          ⭐ Featured
        </span>
      )}
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        <span>{KIND_EMOJI[m.kind]}</span>
        <span>{KIND_LABEL[m.kind]}</span>
        <span>·</span>
        <span>{new Date(m.created_at).toLocaleDateString()}</span>
      </div>
      <div className="font-display text-lg font-extrabold leading-snug">{m.title}</div>
      {m.description && (
        <p className="line-clamp-4 text-sm text-foreground/80">{m.description}</p>
      )}
      <div className="mt-auto flex items-center justify-between gap-2 pt-2">
        <Link
          to="/u/$username"
          params={{ username: p?.username ?? "" }}
          className="flex min-w-0 items-center gap-2"
        >
          <img
            src={avatar}
            alt=""
            className="h-8 w-8 shrink-0 rounded-full border-[1.5px] border-foreground bg-card"
          />
          <div className="min-w-0">
            <div className="truncate text-sm font-bold">{name}</div>
            {p?.username && (
              <div className="truncate text-[11px] text-muted-foreground">@{p.username}</div>
            )}
          </div>
        </Link>
        {(m.amount_inr || m.hours_saved) && (
          <span className="rounded-full border-[1.5px] border-foreground bg-gold px-2.5 py-0.5 text-xs font-extrabold">
            {m.amount_inr ? `₹${m.amount_inr.toLocaleString()}` : `${m.hours_saved}h saved`}
          </span>
        )}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="card-editorial flex flex-col items-center gap-3 p-12 text-center">
      <Sparkles className="h-8 w-8 text-coral" />
      <div className="font-display text-lg font-extrabold">No wins featured yet — be the first.</div>
      <p className="max-w-md text-sm text-muted-foreground">
        Got hired, shipped a collab, or saved hours thanks to a prompt here? Share it — we celebrate
        every real outcome on this page.
      </p>
    </div>
  );
}
