import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Shell } from "@/components/site/Shell";
import { BLOGS, getBlogBySlug } from "@/lib/blog-data";
import { ArrowLeft, Clock, Share2 } from "lucide-react";
import { sharePage } from "@/lib/share";

export const Route = createFileRoute("/blog_/$slug")({
  loader: ({ params }) => {
    const blog = getBlogBySlug(params.slug);
    if (!blog) throw notFound();
    return { blog };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.blog.title} — VibeCoder Blog` },
          { name: "description", content: loaderData.blog.excerpt },
          { property: "og:title", content: loaderData.blog.title },
          { property: "og:description", content: loaderData.blog.excerpt },
          { property: "og:image", content: loaderData.blog.cover },
          { property: "og:type", content: "article" },
        ]
      : [{ title: "Blog — VibeCoder" }],
  }),
  component: BlogDetail,
});

function BlogDetail() {
  const { blog } = Route.useLoaderData();
  const related = BLOGS.filter((b) => b.id !== blog.id && b.category === blog.category).slice(0, 3);

  return (
    <Shell>
      <article className="container-page max-w-4xl py-10">
        <Link to="/blog" className="mb-6 inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-coral hover:underline">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to blog
        </Link>

        <div className="mb-6 flex flex-wrap items-center gap-2">
          <span className="pill-badge bg-coral text-white">{blog.category}</span>
          {blog.tags.map((t: string) => (
            <span key={t} className="pill-badge bg-card text-foreground/80">#{t}</span>
          ))}
        </div>

        <h1 className="font-display text-4xl font-extrabold leading-[1.1] tracking-tight md:text-5xl">{blog.title}</h1>
        <p className="mt-4 text-lg text-muted-foreground">{blog.excerpt}</p>

        <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-y-[1.5px] border-[#0F0F0F] py-4">
          <div className="flex items-center gap-3">
            <img src={`https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(blog.author)}`} className="h-10 w-10 rounded-full border-[1.5px] border-[#0F0F0F] bg-card" alt="" />
            <div>
              <div className="text-sm font-bold">{blog.author}</div>
              <div className="text-xs text-muted-foreground">{blog.authorRole} · {new Date(blog.publishedAt).toLocaleDateString()}</div>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs font-bold uppercase tracking-wider text-foreground/70">
            <span className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {blog.readMinutes} min read</span>
            <button onClick={() => sharePage(blog.title, blog.excerpt)} className="inline-flex items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 py-1.5" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <Share2 className="h-3.5 w-3.5" /> Share
            </button>
          </div>
        </div>

        <img src={blog.cover} alt={blog.title} className="mt-8 aspect-[16/8] w-full rounded-xl border-[1.5px] border-[#0F0F0F] object-cover" style={{ boxShadow: "5px 5px 0 0 #0F0F0F" }} />

        <div className="prose prose-lg mt-10 max-w-none">
          {blog.body.map((p: string, i: number) => (
            <p key={i} className="mb-6 text-[17px] leading-[1.75] text-foreground/90">{p}</p>
          ))}
        </div>

        {related.length > 0 && (
          <div className="mt-16 border-t-[1.5px] border-[#0F0F0F] pt-10">
            <h3 className="mb-6 font-display text-2xl font-extrabold">Keep reading</h3>
            <div className="grid gap-5 md:grid-cols-3">
              {related.map((b) => (
                <Link key={b.id} to="/blog/$slug" params={{ slug: b.slug }} className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-card p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
                  <img src={b.cover} alt="" className="mb-3 h-28 w-full rounded-md object-cover" />
                  <div className="text-xs font-bold uppercase tracking-wider text-coral">{b.category}</div>
                  <div className="mt-1 font-display font-extrabold leading-snug">{b.title}</div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </article>
    </Shell>
  );
}
