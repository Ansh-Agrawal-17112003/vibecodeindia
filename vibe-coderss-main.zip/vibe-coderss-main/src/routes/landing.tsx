import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  ChevronDown,
  Flame,
  Trophy,
  Zap,
  Briefcase,
  Users,
  Frown,
  Search,
  Compass,
  Github,
  Linkedin,
  MessageSquare,
  User,
  Hash,
  Circle,
  UserPlus,
  Rocket,
  Send,
  MessageCircle,
  Award,
  Building2,
  GraduationCap,
  Check,
  Star,
  Sparkles,
  Quote,
  BadgeCheck,
  X as XIcon,
} from "lucide-react";
import { useRef, useState } from "react";
import { Shell } from "@/components/site/Shell";
import { LandingDock } from "@/components/site/LandingDock";
import { Hero } from "@/components/site/Hero";
import { Counter } from "@/components/site/Counter";
import { KineticText } from "@/components/ui/kinetic-text";
import { AnimatedBeam } from "@/components/ui/animated-beam";
import { ShineBorder } from "@/components/ui/shine-border";
import { AnimatedList } from "@/components/ui/animated-list";
import { InteractiveHoverLink } from "@/components/ui/interactive-hover-link";
import { ScrollHighlightText } from "@/components/site/ScrollHighlightText";
import { GlareHover } from "@/components/ui/glare-hover";
import { CompareTable } from "@/components/site/CompareTable";
import { PricingCalculator } from "@/components/site/PricingCalculator";
import { LiveActivityTicker } from "@/components/landing/LiveActivityTicker";
import { TrustedByStrip } from "@/components/landing/TrustedByStrip";
import { FeatureShowcase } from "@/components/landing/FeatureShowcase";
import { CursorSpotlight } from "@/components/landing/CursorSpotlight";
import { AnimatedSection } from "@/components/landing/AnimatedSection";
import { ScrollProgressBar } from "@/components/landing/ScrollProgressBar";
import { SectionSpyDots } from "@/components/landing/SectionSpyDots";
import { CommandPalette, CommandKHint } from "@/components/landing/CommandPalette";
import { ConfettiOnCTA } from "@/components/landing/ConfettiOnCTA";
import { RoleSwitcher } from "@/components/landing/RoleSwitcher";
import { SlashCommandDemo } from "@/components/landing/SlashCommandDemo";
import { LiveProfileBuilder } from "@/components/landing/LiveProfileBuilder";
import { MegaNav } from "@/components/landing/MegaNav";
import { ProfileWorks247 } from "@/components/landing/ProfileWorks247";
import { DiscoverBuilders } from "@/components/landing/DiscoverBuilders";
import { EverythingInOnePlace } from "@/components/landing/EverythingInOnePlace";
import { PullQuote } from "@/components/landing/PullQuote";
import { BuildersShipping } from "@/components/landing/BuildersShipping";
import { PartnerLogos } from "@/components/landing/PartnerLogos";
import { FinalCTA } from "@/components/landing/FinalCTA";
import { ProductLoopVideo } from "@/components/landing/ProductLoopVideo";


export const Route = createFileRoute("/landing")({
  head: () => ({
    meta: [
      { title: "VibeCode — India's Largest AI Builder Community" },
      { name: "description", content: "Ship in public, share prompts and workflows, and get discovered by 120,000+ Indian AI builders." },
      { property: "og:title", content: "VibeCode — India's Largest AI Builder Community" },
      { property: "og:description", content: "Ship in public, share prompts and workflows, and get discovered by 120,000+ Indian AI builders." },
      { property: "og:url", content: "https://joinvibecode.xyz/landing" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/landing" }],
  }),
  component: LandingRoute,
});

function LandingRoute() {
  return <Landing />;
}

/* ----------------------------- Design tokens ----------------------------- */
const C = {
  cream: "#FAF6F1",
  creamDeep: "#F3ECDF",
  white: "#FFFFFF",
  dark: "#0F0F0F",
  darkSoft: "#161616",
  border: "#E8E0D6",
  text: "#0F0F0F",
  muted: "#666666",
  coral: "#E8623A",
  coralSoft: "#FFF1EA",
  blue: "#3B82F6",
  green: "#22C55E",
  gold: "#F5A623",
};

/* --------------------------------- Data --------------------------------- */
const MARQUEE_ITEMS = [
  "🇮🇳 Built in India",
  "120,000+ Builders",
  "8,400+ Prompts",
  "3,200+ Projects",
  "55+ Job Openings",
  "450+ Communities",
  "₹0 to join",
  "The Vibe is live",
  "Lovable · Claude · n8n · Cursor · Make · GPT-4o",
  "India's #1 AI Builder Platform",
];

const TESTIMONIALS = [
  { q: "bruh this is so good 🤯", n: "Rhea Kapoor", h: "rheakapoor", r: "Indie Hacker", s: "rhea", v: true },
  { q: "Shipped my first SaaS in 3 weeks after joining VibeCode. The prompt library alone saved me literally 2 months of trial and error. If you're an Indian builder still lurking on Twitter, come here — this is where the actual work happens. I cannot recommend it enough to anyone starting out in 2026.", n: "Aditya Patel", h: "adityabuilds", r: "Solo Founder", s: "aditya", v: true },
  { q: "beautiful product 🥲 finally something built for Indian AI builders that doesn't feel like a LinkedIn clone", n: "Arjun Mehta", h: "arjunmehta", r: "n8n Freelancer", s: "arjunm", v: false },
  { q: "We hired our entire 8-person AI team from VibeCode. No recruiters. Zero fluff. All builders with real shipped projects on their profile. This is the future of hiring for AI-native companies.", n: "Vikram Joshi", h: "vikramjoshi", r: "Agency Lead", s: "vikramj", v: true },
  { q: "the communities here are the friendliest corner of Indian AI Twitter — except it's actually useful ❤️", n: "Isha Verma", h: "ishav", r: "Design Engineer", s: "ishav", v: false },
  { q: "Found my co-founder on VibeCode. We're at ₹2L MRR now, three months in. The kind of serendipity you can't manufacture — but VibeCode came pretty close to manufacturing it for us.", n: "Manav Kochhar", h: "manavk", r: "AI Founder", s: "manav", v: true },
  { q: "I posted my n8n workflow at 11pm. By morning I had 4 client inquiries in DMs. Wild. 🔥", n: "Rohan Sinha", h: "rohansinha", r: "Automation Builder", s: "rohans", v: false },
  { q: "Finally a platform that treats prompt engineering as a real skill, not a Twitter gimmick. My prompt library on VibeCode has become a real portfolio piece — got two consulting gigs off it last month.", n: "Neha Iyer", h: "nehaiyer", r: "Prompt Engineer", s: "nehai", v: true },
  { q: "From first post to first hire: 19 days. VibeCode moves fast 🚀", n: "Karan Bhatia", h: "karanb", r: "Product @ AI Startup", s: "karanb", v: false },
  { q: "landed 3 retainer clients in month one. ROI on Pro in literally one week 💰", n: "Priya Nair", h: "priyanair", r: "AI Consultant", s: "priyan", v: true },
  { q: "VibeCode is what LinkedIn wishes it was for our generation of builders. The signal-to-noise ratio here is unreal — every post is either a real project, a real tool, or a real job.", n: "Siddharth Rao", h: "sidrao", r: "Full-stack Builder", s: "sidr", v: false },
  { q: "shoutout to the vibecode team for building something that actually respects builders' time 🙏", n: "Ananya Reddy", h: "ananyareddy", r: "Product Designer", s: "ananya", v: true },
  { q: "shipped 4 micro-SaaS in 6 months. every single one got its first users from a VibeCode post. no ads, no cold DMs, just… builders talking to builders.", n: "Kabir Malhotra", h: "kabirbuilds", r: "Micro-SaaS Founder", s: "kabir", v: false },
  { q: "the Lovable community here is unreal. asked a question at 2am, had 3 detailed replies by morning ☕", n: "Tanvi Shah", h: "tanvishah", r: "No-code Builder", s: "tanvi", v: true },
  { q: "went from watching YouTube tutorials to shipping paid products in 2 months. vibecode's prompt library is basically a free MBA in AI building 🎓", n: "Devansh Gupta", h: "devanshg", r: "Solo Dev", s: "devansh", v: false },
  { q: "our startup found its first 3 hires here. all from Tier-2 cities. all shipping better than the ex-FAANG folks we interviewed. this platform is quietly rewriting Indian tech hiring.", n: "Ritika Bansal", h: "ritikab", r: "CTO @ AI Startup", s: "ritika", v: true },
  { q: "vibecode is the only tab I keep open all day 🫡", n: "Yash Agarwal", h: "yashagarwal", r: "Automation Engineer", s: "yash", v: false },
  { q: "posted my Cursor workflow → 200 saves in 24h → 6 client leads in a week. this is not normal. this is vibecode.", n: "Meera Krishnan", h: "meerak", r: "AI Consultant", s: "meera", v: true },
  { q: "as a designer who codes with AI, I finally feel seen 🥲 no more explaining what I do at meetups", n: "Zoya Ansari", h: "zoyaansari", r: "Design + AI", s: "zoya", v: false },
  { q: "the daily leaderboard is dangerously addictive. I've shipped more in 30 days than the previous 6 months combined 🏆", n: "Harsh Vardhan", h: "harshv", r: "Full-stack Builder", s: "harshv", v: true },
  { q: "found 3 co-builders for my SaaS through communities here. we ship together every weekend now. this platform changed my trajectory.", n: "Sneha Pillai", h: "snehap", r: "Indie Maker", s: "snehap", v: false },
  { q: "the workflows section is a goldmine. copied one n8n flow, adapted it for a client, billed ₹40k. paid for Pro 40x over 😅", n: "Ayaan Sheikh", h: "ayaansh", r: "n8n Specialist", s: "ayaan", v: true },
  { q: "vibecode feels like Twitter in 2010 — small enough to matter, big enough to grow. don't sleep on this.", n: "Ira Deshmukh", h: "iradesh", r: "Product Builder", s: "ira", v: false },
];


export const FAQ = [
  {
    q: "Is VibeCode actually free?",
    a: "Yes. Completely, permanently free for builders. No credit card. No trial period. No freemium tricks. The Builder plan costs ₹0 forever. We make money from Pro builders who want top placement and from companies that hire through us. Your success is literally our business model.",
  },
  {
    q: "I'm a student / beginner. Am I welcome?",
    a: "Absolutely yes — and this question breaks our heart a little. VibeCode exists precisely for people starting out. Some of our most active members joined as students and are now building products with paying users. Join today. Build something. Share it. The community will cheer you on.",
  },
  {
    q: "How is this different from LinkedIn or Upwork?",
    a: "LinkedIn doesn't know what n8n is. Upwork treats you like a commodity. VibeCode is built specifically for AI builders — your profile shows actual projects, not job titles. Your prompts and workflows become your portfolio. The companies here are looking for vibe coders, not traditional developers. It's a completely different audience.",
  },
  {
    q: "Does VibeCode take a cut of my freelance income?",
    a: "No. Zero. We don't sit between you and your clients. When you connect with a hirer through VibeCode and agree on a project — that's between you two. We're a discovery platform, not a payment processor. We only make money from Pro subscriptions and company hiring plans.",
  },
  {
    q: "What AI tools are supported?",
    a: "All of them. VibeCode is tool-agnostic. Whether you build with Lovable, Claude, GPT-4o, Gemini, Cursor, n8n, Make, Midjourney, Whisper, Supabase, Replit, Bolt — we have communities, prompts, and builders for every tool in the stack. If your tool isn't listed, create a community for it.",
  },
  {
    q: "I'm a founder / company. How do I find builders?",
    a: "Sign up, go to Explore Builders, filter by tools and availability, and start browsing. You can view 3 profiles free. The Hiring plan (₹2,999/month) unlocks unlimited searches, direct DMs, and job posting. Most companies find their first hire within a week.",
  },
  {
    q: "Is my data safe?",
    a: "VibeCode uses enterprise-grade Postgres, Auth with RLS policies, and follows DPDP (India's data protection law) guidelines. We never sell your data. Your profile is yours — delete it anytime.",
  },
];

// Honest, pre-launch numbers. No fake user counts — we haven't launched yet.
// These reflect what's actually true: founding-member spots, perks, and scope.
const STATS = [
  { n: 10000, suffix: "", l: "Founding Spots" },
  { n: 100, suffix: "", l: "Free Pro Seats (first 100)" },
  { n: 12, suffix: "+", l: "AI Tools Supported" },
  { n: 0, prefix: "₹", suffix: "", l: "Cost to Join Early" },
  { n: 1, suffix: "", l: "Platform, Built in India" },
];

/* ------------------------------ Small helpers ---------------------------- */
function Pill({ children, variant = "coral" }: { children: React.ReactNode; variant?: "coral" | "coralOutline" | "coralSoft" }) {
  const styles: React.CSSProperties =
    variant === "coral"
      ? { background: C.coral, color: "#fff", boxShadow: "0 6px 20px -6px rgba(232,98,58,0.6)" }
      : variant === "coralOutline"
      ? { background: "transparent", color: C.coral, border: `1.5px solid ${C.coral}` }
      : { background: C.coralSoft, color: C.coral, border: `1px solid ${C.coral}33` };
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-[0.14em]"
      style={styles}
    >
      <Sparkles className="h-3 w-3" />
      {children}
    </span>
  );
}

function SectionShell({
  bg,
  children,
  id,
  dark = false,
  className = "",
}: {
  bg: string;
  children: React.ReactNode;
  id?: string;
  dark?: boolean;
  className?: string;
}) {
  return (
    <section
      id={id}
      data-reveal
      style={{ background: bg }}
      className={`relative w-full py-16 md:py-24 ${
        dark
          ? "text-white [&_h1]:text-white [&_h2]:text-white [&_h3]:text-white [&_h4]:text-white"
          : ""
      } ${className}`}
    >
      <div className="mx-auto w-full max-w-[1200px] px-5 md:px-8">{children}</div>
    </section>
  );
}

/* ------------------------------ Tweet Card ------------------------------ */
type Tweet = { q: string; n: string; h: string; r: string; s: string; v: boolean };

function TweetCard({ t, index }: { t: Tweet; index: number }) {
  const [open, setOpen] = useState(false);
  const isLong = t.q.length > 180;
  const preview = isLong ? t.q.slice(0, 170).trimEnd() + "…" : t.q;

  return (
    <>
      <article
        className="tw-card group relative mb-5 inline-block w-full break-inside-avoid cursor-pointer overflow-hidden rounded-2xl p-5 transition-all duration-300 ease-out hover:-translate-y-1"
        style={{
          background: C.white,
          border: `1px solid ${C.border}`,
          boxShadow: "0 2px 10px -4px rgba(15,15,15,0.06)",
          animation: `tw-fade-in 0.5s ease-out ${index * 60}ms both`,
        }}
        onClick={() => isLong && setOpen(true)}
      >
        {/* Coral glow on hover */}
        <span
          aria-hidden
          className="pointer-events-none absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{ boxShadow: `0 20px 50px -20px ${C.coral}55, 0 0 0 1px ${C.coral}55 inset` }}
        />

        {/* Blurred content wrapper — blurs smoothly on hover */}
        <div className="relative transition-all duration-300 ease-out group-hover:blur-[3px] group-hover:scale-[0.98] group-hover:opacity-70">
          <header className="flex items-start justify-between gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <img
                src={`https://api.dicebear.com/7.x/notionists/svg?seed=${t.s}`}
                alt=""
                className="h-11 w-11 shrink-0 rounded-full"
                style={{ background: C.cream, border: `1px solid ${C.border}` }}
              />
              <div className="min-w-0">
                <div className="flex items-center gap-1">
                  <span className="truncate text-[15px] font-bold" style={{ color: C.text }}>{t.n}</span>
                  {t.v && <BadgeCheck className="h-4 w-4 shrink-0" style={{ color: "#1d9bf0" }} fill="#1d9bf0" stroke="#fff" strokeWidth={2.5} />}
                </div>
                <div className="truncate text-[13px]" style={{ color: "#8a8a8a" }}>@{t.h}</div>
              </div>
            </div>
            <XIcon
              className="h-4 w-4 shrink-0 transition-transform duration-300 group-hover:scale-110"
              style={{ color: "#c9c9c9" }}
            />
          </header>

          <p
            className="mt-3 whitespace-pre-line text-[14.5px] leading-[1.55]"
            style={{ color: "#2a2a2a" }}
          >
            {preview}
          </p>

          {isLong && (
            <button
              type="button"
              className="mt-2 inline-flex items-center gap-1 text-[13px] font-semibold transition-colors"
              style={{ color: C.coral }}
              onClick={(e) => { e.stopPropagation(); setOpen(true); }}
            >
              Read full review
              <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
            </button>
          )}
        </div>

        {/* Centered "View on Twitter" CTA — appears on hover */}
        <a
          href={`https://twitter.com/${t.h}`}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          aria-label={`View @${t.h} on Twitter`}
          className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center opacity-0 transition-all duration-300 ease-out group-hover:pointer-events-auto group-hover:opacity-100"
        >
          <span
            className="inline-flex translate-y-2 items-center gap-2 rounded-full px-5 py-2.5 text-[13px] font-bold text-white shadow-lg transition-all duration-300 ease-out group-hover:translate-y-0 hover:scale-105"
            style={{ background: "#0F0F0F", boxShadow: "0 12px 30px -8px rgba(15,15,15,0.5)" }}
          >
            <XIcon className="h-3.5 w-3.5" />
            View on Twitter
            <ArrowRight className="h-3.5 w-3.5" />
          </span>
        </a>
      </article>

      {open && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
          style={{ background: "rgba(15,15,15,0.55)", backdropFilter: "blur(6px)", animation: "tw-fade-in 0.2s ease-out" }}
          onClick={() => setOpen(false)}

        >
          <div
            className="relative w-full max-w-[560px] rounded-2xl p-7 md:p-8"
            style={{
              background: C.white,
              border: `1px solid ${C.border}`,
              boxShadow: "0 40px 80px -20px rgba(0,0,0,0.35)",
              animation: "tw-pop-in 0.28s cubic-bezier(0.22,1,0.36,1)",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              aria-label="Close"
              onClick={() => setOpen(false)}
              className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-[#f3f0eb]"
              style={{ color: "#666" }}
            >
              ✕
            </button>
            <div className="flex items-center gap-3">
              <img
                src={`https://api.dicebear.com/7.x/notionists/svg?seed=${t.s}`}
                alt=""
                className="h-12 w-12 rounded-full"
                style={{ background: C.cream, border: `1px solid ${C.border}` }}
              />
              <div>
                <div className="flex items-center gap-1">
                  <span className="text-[16px] font-bold" style={{ color: C.text }}>{t.n}</span>
                  {t.v && <BadgeCheck className="h-4 w-4" style={{ color: "#1d9bf0" }} fill="#1d9bf0" stroke="#fff" strokeWidth={2.5} />}
                </div>
                <div className="text-[13px]" style={{ color: "#8a8a8a" }}>@{t.h} · {t.r}</div>
              </div>
            </div>
            <p className="mt-5 text-[16px] leading-[1.65]" style={{ color: "#1a1a1a" }}>
              {t.q}
            </p>
            <div className="mt-6 flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-current" style={{ color: C.coral }} />
              ))}
              <span className="ml-2 text-[13px]" style={{ color: C.muted }}>Verified builder review</span>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes tw-fade-in { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes tw-pop-in  { from { opacity: 0; transform: scale(0.96) translateY(8px); } to { opacity: 1; transform: scale(1) translateY(0); } }
      `}</style>
    </>
  );
}

/* ================================ Page ================================== */
export function Landing() {
  return (
    <Shell hideNavbar>
      <MegaNav />
      <ScrollProgressBar />
      <SectionSpyDots />
      <CommandPalette />
      <CommandKHint />
      <ConfettiOnCTA />
      <CursorSpotlight />
      <Hero />
      <ProductLoopVideo />
      <TrustedByStrip />
      <WhiteMarqueeSection />
      <ProfileWorks247 />
      <DiscoverBuilders />
      <HowVibeCodeWorks />
      <EverythingInOnePlace />
      <PullQuote />
      <WhatBuildersSay />
      <BuildersShipping />
      <CompareTable />
      <PartnerLogos />
      <JoinTheMovement />
      <FinalCTA />
    </Shell>
  );
}

/* ---------------------------- White marquee ----------------------------- */
function WhiteMarqueeSection() {
  return (
    <div
      className="w-full overflow-hidden"
      style={{
        background: "#FFFFFF",
        borderTop: "1px solid rgba(15,15,15,0.08)",
        borderBottom: "1.5px solid #0F0F0F",
      }}
    >
      <div className="group flex whitespace-nowrap py-4">
        <div
          className="flex shrink-0 items-center gap-10 pr-10 animate-marquee group-hover:[animation-play-state:paused]"
          style={{ animationDuration: "45s" }}
        >
          {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((t, i) => (
            <span key={i} className="flex items-center gap-10 text-sm font-semibold" style={{ color: "#1a1a1a" }}>
              <span>{t}</span>
              <span style={{ color: C.coral }}>◆</span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* --------------------------- How VibeCode Works ------------------------- */
function HowVibeCodeWorks() {
  return (
    <section
      data-reveal
      className="relative w-full border-t-[1.5px]"
      style={{ background: C.white, borderColor: C.dark }}
    >
      <div className="mx-auto w-full max-w-[1200px] px-5 py-16 md:px-8 md:py-24">
        <h2 className="font-display text-[32px] md:text-[52px] font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ color: C.dark }}>
          From zero to recognized builder,
          <br />in your first week.
        </h2>
        <p className="mt-3 max-w-[640px] text-[15px] md:text-[17px]" style={{ color: "#4a463d" }}>
          Four steps. No cover letters, no gatekeeping. Just build, share, and get discovered.
        </p>

        <div className="mt-10">
          <div className="hidden md:block">
            <TimelineWithBeams />
          </div>
          <div className="md:hidden relative pl-8">
            <div className="absolute left-3 top-2 bottom-2 w-[2px]" style={{ background: `${C.coral}66` }} />
            <div className="space-y-8">
              {TIMELINE.map((s, i) => {
                const Icon = s.icon;
                return (
                  <div key={i} className="relative">
                    <div
                      className="absolute -left-[26px] top-1 grid h-6 w-6 place-items-center rounded-full"
                      style={{ background: C.coral, boxShadow: `0 0 0 4px ${C.white}, 0 4px 12px -2px rgba(232,98,58,0.5)` }}
                    >
                      <Icon className="h-3 w-3 text-white" />
                    </div>
                    <TimelineStep step={s} inline />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* --------------------------- What Builders Say -------------------------- */
function WhatBuildersSay() {
  return (
    <section
      data-reveal
      className="relative w-full border-t-[1.5px]"
      style={{ background: C.cream, borderColor: C.dark }}
    >
      <div className="mx-auto w-full max-w-[1200px] px-5 py-16 md:px-8 md:py-24">
        <h2 className="font-display text-[32px] md:text-[52px] font-extrabold leading-[1.05] tracking-[-0.02em]" style={{ color: C.dark }}>
          Loved by India's shippers.
        </h2>
        <p className="mt-3 max-w-[640px] text-[15px] md:text-[17px]" style={{ color: "#4a463d" }}>
          Real posts from real builders. No paid testimonials, no fake screenshots.
        </p>

        <div className="mt-10 columns-1 gap-5 sm:columns-2 lg:columns-3">
          {TESTIMONIALS.slice(0, 15).map((t, i) => (
            <TweetCard key={t.h + i} t={t} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------------------- Join The Movement ------------------------- */
const MOVEMENT_SEEDS = [
  "aarav", "priya", "kabir", "isha", "rohan", "neha", "arjun", "meera",
  "sneha", "yash", "tanvi", "devansh", "ritika", "manav", "karanb", "ananya",
  "sidr", "zoya", "ira", "ayaan", "harshv", "rheakapoor", "adityabuilds", "vikramj",
];

function JoinTheMovement() {
  return (
    <section
      data-reveal
      className="relative w-full overflow-hidden border-t-[1.5px] py-20 md:py-28"
      style={{ background: C.dark, borderColor: C.dark, color: "#fff" }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{ background: "radial-gradient(700px circle at 50% 30%, rgba(232,98,58,0.18), transparent 60%)" }}
      />
      <div className="relative mx-auto w-full max-w-[1200px] px-5 md:px-8">
        <div className="mx-auto max-w-[780px] text-center">
          <Pill>Join The Movement</Pill>
          <h2 className="mt-6 text-[32px] md:text-[56px] lg:text-[72px] font-extrabold leading-[1.02] tracking-[-0.02em] text-white">
            120,000+ Indian builders.
            <br />
            <span style={{ color: C.coral }}>One home.</span>
          </h2>
          <p className="mx-auto mt-5 max-w-[600px] text-base md:text-[18px]" style={{ color: "#b8b8b8" }}>
            Ship in public. Get discovered. Earn XP, VibeCoins, and real work. The vibe is already live — you just need to join it.
          </p>
        </div>

        {/* Avatar constellation */}
        <div className="mx-auto mt-14 max-w-[900px]">
          <div className="flex flex-wrap items-center justify-center gap-2 md:gap-3">
            {MOVEMENT_SEEDS.map((seed, i) => (
              <img
                key={seed}
                src={`https://api.dicebear.com/7.x/notionists/svg?seed=${seed}`}
                alt=""
                loading="lazy"
                className="rounded-full transition-transform hover:scale-110 hover:z-10"
                style={{
                  width: i % 7 === 0 ? 60 : i % 3 === 0 ? 52 : 44,
                  height: i % 7 === 0 ? 60 : i % 3 === 0 ? 52 : 44,
                  background: "#1a1a1a",
                  border: "2px solid #0F0F0F",
                  boxShadow: "0 0 0 2px rgba(232,98,58,0.35)",
                }}
              />
            ))}
            <div
              className="ml-1 flex items-center justify-center rounded-full px-4 text-sm font-extrabold text-white"
              style={{ height: 52, background: C.coral, border: "2px solid #0F0F0F", boxShadow: "3px 3px 0 0 #000" }}
            >
              +119,976
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link
            to="/auth"
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-6 py-3 text-sm font-bold text-white transition hover:-translate-y-0.5"
            style={{ background: C.coral, borderColor: "#0F0F0F", boxShadow: "4px 4px 0 0 #000" }}
          >
            Claim your builder profile <ArrowRight className="h-4 w-4" />
          </Link>
          <Link
            to="/explore"
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] px-6 py-3 text-sm font-bold text-white/90 transition hover:bg-white/5"
            style={{ borderColor: "rgba(255,255,255,0.25)" }}
          >
            Explore builders
          </Link>
        </div>

        <p className="mt-8 text-center text-xs uppercase tracking-[0.24em]" style={{ color: "#666" }}>
          Free forever · No credit card · Made in India
        </p>
      </div>
    </section>
  );
}

function _LandingLegacy_UNUSED() {
  return (
    <Shell hideFooter hideNavbar>
      

      







      {/* 1 — Social proof marquee (cream, syncs with hero) */}
      <div
        className="w-full overflow-hidden"
        style={{
          background: `linear-gradient(180deg, ${C.cream} 0%, ${C.creamDeep} 100%)`,
          borderTop: `1px solid ${C.border}`,
          borderBottom: `1px solid ${C.border}`,
        }}
      >
        <div className="group flex whitespace-nowrap py-4">
          <div
            className="flex shrink-0 items-center gap-10 pr-10 animate-marquee group-hover:[animation-play-state:paused]"
            style={{ animationDuration: "45s" }}
          >
            {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((t, i) => (
              <span key={i} className="flex items-center gap-10 text-sm font-medium" style={{ color: "#5a5044" }}>
                <span>{t}</span>
                <span style={{ color: C.coral }}>◆</span>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* 2 — The Problem */}
      <SectionShell bg="#0B0B0C" dark className="overflow-hidden">
        {/* dotted grid background — Notion workspace feel */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              "radial-gradient(rgba(255,255,255,0.045) 1px, transparent 1px)",
            backgroundSize: "22px 22px",
            maskImage:
              "radial-gradient(ellipse 80% 60% at 50% 40%, #000 40%, transparent 100%)",
          }}
        />
        {/* soft coral glow */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            background: `radial-gradient(700px circle at 50% 0%, rgba(232,98,58,0.10), transparent 60%)`,
          }}
        />

        <div className="relative mx-auto max-w-[760px] text-center">
          <Pill>The Builder's Problem</Pill>
          <h2 className="mt-6 text-[32px] md:text-[64px] lg:text-[80px] font-extrabold leading-[1] tracking-[-0.02em]">
            You're building something{" "}
            <span style={{ color: C.coral }}>incredible</span>.
            <br />
            But you're doing it alone.
          </h2>
          <ScrollHighlightText
            className="mx-auto mt-6 text-base md:text-[18px] leading-[1.8]"
            text="LinkedIn is for corporate resumes. Upwork is a race to the bottom. Twitter is full of noise. Discord is 40 scattered servers."
          />
          <ScrollHighlightText
            className="mx-auto mt-4 text-base md:text-[18px] leading-[1.8]"
            text="There's no home for the new generation of Indian AI builders — people who ship SaaS with Lovable, automate with n8n, build agents with Claude, and launch products in weekends, not quarters."
          />
          <div className="mx-auto my-10 h-px w-16" style={{ background: "#2a2a2a" }} />
        </div>

        {/* Notion-page style cards floating on dark canvas */}
        <div className="relative mx-auto grid max-w-[1200px] gap-6 md:grid-cols-3">
          {[
            {
              file: "problem-01.md",
              emoji: "😶‍🌫️",
              title: "No credibility layer",
              quote: "\u201CMy GitHub has 3 repos. My LinkedIn says \u2018AI enthusiast.\u2019 Recruiters ghost me.\u201D",
              calloutBg: "#FFF1EA",
              calloutBorder: "#F4C7B4",
              bullets: [
                "Portfolio is a dead PDF",
                "GitHub doesn't show what you actually shipped",
                "No way to prove taste, only titles",
              ],
              status: { label: "Broken", dot: "#E8623A" },
              priority: "P0",
            },
            {
              file: "problem-02.md",
              emoji: "🔎",
              title: "Discovery is broken",
              quote: "\u201CI\u2019m senior on Lovable and n8n. Companies still hire from referrals only.\u201D",
              calloutBg: "#FFF7E6",
              calloutBorder: "#F0D68A",
              bullets: [
                "No search engine for AI builders",
                "Job boards don't index prompt / workflow talent",
                "Great work sits at 0 views forever",
              ],
              status: { label: "Broken", dot: "#F5A623" },
              priority: "P0",
            },
            {
              file: "problem-03.md",
              emoji: "🏝️",
              title: "Building in isolation",
              quote: "\u201CI\u2019m in 14 Discords and 8 subreddits. Still no one answers when I ask.\u201D",
              calloutBg: "#EFF6FF",
              calloutBorder: "#B8D4F5",
              bullets: [
                "Discords go silent after week 2",
                "Reddit threads die in an hour",
                "No home for weekend shippers to think together",
              ],
              status: { label: "Broken", dot: "#3B82F6" },
              priority: "P0",
            },
          ].map((tile, idx) => (
            <AnimatedSection key={tile.file} delay={idx * 120}>
              <div
                className="group relative flex h-full flex-col overflow-hidden rounded-xl bg-white transition-all duration-300 hover:-translate-y-1.5 hover:rotate-0"
                style={{
                  border: "1px solid #E8E0D6",
                  boxShadow: "0 1px 0 rgba(255,255,255,0.06), 0 20px 40px -20px rgba(0,0,0,0.55)",
                  transform: `rotate(${idx === 0 ? -0.6 : idx === 2 ? 0.6 : 0}deg)`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.boxShadow =
                    "0 1px 0 rgba(255,255,255,0.06), 0 30px 60px -20px rgba(232,98,58,0.35)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.boxShadow =
                    "0 1px 0 rgba(255,255,255,0.06), 0 20px 40px -20px rgba(0,0,0,0.55)";
                }}
              >
                {/* Notion top bar — file breadcrumb */}
                <div className="flex items-center justify-between border-b px-4 py-2.5" style={{ borderColor: "#EFE9DF", background: "#FAF7F1" }}>
                  <div className="flex items-center gap-1.5 font-mono text-[11px]" style={{ color: "#8a8578" }}>
                    <span>📄</span>
                    <span>vibecode</span>
                    <span style={{ color: "#c9c2b4" }}>/</span>
                    <span>problems</span>
                    <span style={{ color: "#c9c2b4" }}>/</span>
                    <span style={{ color: "#3d3a33" }}>{tile.file}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#e0d9cb" }} />
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#e0d9cb" }} />
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#e0d9cb" }} />
                  </div>
                </div>

                {/* Notion page content */}
                <div className="flex flex-1 flex-col gap-4 p-6">
                  <div className="flex items-start gap-3">
                    <span className="text-4xl leading-none transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6">
                      {tile.emoji}
                    </span>
                    <h3 className="mt-1 font-display text-[22px] font-bold leading-tight" style={{ color: "#1c1a16" }}>
                      {tile.title}
                    </h3>
                  </div>

                  {/* Notion-style callout */}
                  <div
                    className="rounded-lg border-l-[3px] px-4 py-3 text-[13.5px] italic leading-[1.6]"
                    style={{ background: tile.calloutBg, borderColor: tile.calloutBorder, color: "#3d3a33" }}
                  >
                    {tile.quote}
                  </div>

                  {/* Notion bullet list */}
                  <ul className="space-y-1.5 text-[13.5px] leading-[1.6]" style={{ color: "#4a463d" }}>
                    {tile.bullets.map((b) => (
                      <li key={b} className="flex gap-2">
                        <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full" style={{ background: "#8a8578" }} />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Notion database property row */}
                  <div className="mt-auto flex items-center gap-2 border-t pt-3 font-mono text-[11px]" style={{ borderColor: "#EFE9DF", color: "#8a8578" }}>
                    <span className="flex items-center gap-1.5 rounded-md px-2 py-0.5" style={{ background: "#F5F1E8" }}>
                      <span className="h-1.5 w-1.5 rounded-full" style={{ background: tile.status.dot }} />
                      Status: <span style={{ color: "#3d3a33" }}>{tile.status.label}</span>
                    </span>
                    <span className="rounded-md px-2 py-0.5" style={{ background: "#F5F1E8" }}>
                      Priority: <span style={{ color: "#E8623A" }}>{tile.priority}</span>
                    </span>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>

      </SectionShell>

      <FeatureShowcase />

      <SlashCommandDemo />

      {/* 3 — The Solution (Bento) */}

      <SectionShell bg={C.cream}>
        <div className="mx-auto max-w-[760px] text-center">
          <Pill variant="coralSoft">Introducing VibeCode</Pill>
          <h2 className="mt-6 text-[32px] md:text-[64px] lg:text-[80px] font-extrabold leading-[1] tracking-[-0.02em]">
            One platform.
            <br />
            Everything an <span style={{ color: C.coral }}>AI builder</span> needs.
          </h2>
          <p className="mx-auto mt-5 max-w-[600px] text-base md:text-[18px]" style={{ color: C.muted }}>
            Not a job board. Not just a community. VibeCode is the operating system for your career as an AI builder.
          </p>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-5">
          {/* Large — full width */}
          <BentoCard className="md:col-span-5" bg={C.dark} textLight>
            <div className="grid gap-8 md:grid-cols-2 md:items-center">
              <div>
                <IconBadge icon={Flame} bg={C.coral} />
                <h3 className="mt-5 text-[22px] md:text-[26px] font-bold text-white">The Vibe — Your Builder Feed</h3>
                <p className="mt-3 text-[15px] leading-[1.7]" style={{ color: "#b8b8b8" }}>
                  A live feed of what India's best AI builders are shipping, sharing, and asking. Projects, prompts, workflows, questions — all in one intelligent stream. Think LinkedIn, but for people who actually build.
                </p>
                <Link to="/vibe" className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold transition-transform hover:translate-x-1" style={{ color: C.coral }}>
                  See The Vibe <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
              <div className="space-y-3">
              <AnimatedList delay={1200} className="!gap-3">
                {[
                  { name: "Aarav Mehta", text: "Just shipped FlowOps v2 — n8n marketplace 🚀", tag: "#project", seed: "aarav" },
                  { name: "Priya Sharma", text: "Landing page prompt that converts 3x better…", tag: "#prompt", seed: "priya" },
                  { name: "Kabir Singh", text: "MedScribe just crossed ₹1L MRR 🙏", tag: "#milestone", seed: "kabir" },
                ].map((p) => (
                  <div key={p.name} className="flex gap-3 rounded-xl p-3 transition-colors hover:bg-[#1f1f1f]" style={{ background: "#1a1a1a", border: "1px solid #262626" }}>
                    <img src={`https://api.dicebear.com/7.x/notionists/svg?seed=${p.seed}`} alt="" className="h-9 w-9 shrink-0 rounded-full" style={{ background: "#222" }} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 text-xs" style={{ color: "#888" }}>
                        <span className="font-semibold text-white">{p.name}</span>
                        <span style={{ color: C.coral }}>{p.tag}</span>
                      </div>
                      <div className="mt-1 text-sm text-white/90">{p.text}</div>
                    </div>
                  </div>
                ))}
              </AnimatedList>
              </div>
            </div>
          </BentoCard>

          {/* Medium 60% */}
          <BentoCard className="md:col-span-3" bg={C.white}>
            <IconBadge icon={Trophy} bg={C.gold} />
            <h3 className="mt-5 text-[22px] md:text-[26px] font-bold">Builder Profiles That Work</h3>
            <p className="mt-3 text-[15px] leading-[1.7]" style={{ color: C.muted }}>
              Your portfolio isn't a PDF. It's a live, searchable profile showing your XP, projects, prompts, and reputation. Companies find you. Clients DM you. Collaborators follow you.
            </p>
            <Link to="/explore" className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold transition-transform hover:translate-x-1" style={{ color: C.coral }}>
              View example profile <ArrowRight className="h-4 w-4" />
            </Link>
          </BentoCard>

          {/* Small 40% */}
          <BentoCard className="md:col-span-2" bg={C.coral} textLight>
            <IconBadge icon={Zap} bg="rgba(255,255,255,0.2)" iconClass="text-white" />
            <h3 className="mt-5 text-[22px] md:text-[26px] font-bold text-white">XP & VibeCoin Rewards</h3>
            <p className="mt-3 text-[15px] leading-[1.7] text-white/95">
              Every post, project, and prompt earns you XP. Level up. Cash out. Get recognized.
            </p>
          </BentoCard>

          {/* Medium 40% */}
          <BentoCard className="md:col-span-2" bg={C.dark} textLight>
            <IconBadge icon={Briefcase} bg="#232323" iconClass="text-white" />
            <h3 className="mt-5 text-[22px] md:text-[26px] font-bold text-white">Jobs Built for Builders</h3>
            <p className="mt-3 text-[15px] leading-[1.7]" style={{ color: "#b8b8b8" }}>
              300+ AI roles from India's best companies. Apply in 10 seconds using your VibeCode profile. No cover letters. No formality.
            </p>
          </BentoCard>

          {/* Large 60% */}
          <BentoCard className="md:col-span-3" bg={C.white}>
            <IconBadge icon={Users} bg={C.blue} iconClass="text-white" />
            <h3 className="mt-5 text-[22px] md:text-[26px] font-bold">12 Active Communities</h3>
            <p className="mt-3 text-[15px] leading-[1.7]" style={{ color: C.muted }}>
              Lovable Builders. Claude Creators. n8n Automation. Healthcare AI. FinTech Builders. Each with real discussions, resources, live sessions, and a leaderboard.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {["Lovable Builders", "Claude Creators", "n8n Automation", "Healthcare AI"].map((n) => (
                <span key={n} className="rounded-full px-3 py-1 text-xs font-semibold transition-colors hover:bg-white" style={{ background: C.cream, border: `1px solid ${C.border}`, color: C.text }}>
                  {n}
                </span>
              ))}
            </div>
          </BentoCard>
        </div>
      </SectionShell>

      <LiveProfileBuilder />


      {/* 4 — How It Works */}
      <SectionShell bg={C.white}>
        <div className="mx-auto max-w-[760px] text-center">
          <Pill variant="coralSoft">How It Works</Pill>
          <h2 className="mt-6 text-[32px] md:text-[64px] lg:text-[80px] font-extrabold leading-[1] tracking-[-0.02em]">
            From zero to <span style={{ color: C.coral }}>recognized builder</span>
            <br />
            in your first week.
          </h2>
        </div>

        <div className="mt-14">
          {/* Desktop horizontal with animated beams */}
          <div className="hidden md:block">
            <TimelineWithBeams />
          </div>
          {/* Mobile vertical */}
          <div className="md:hidden relative pl-8">
            <div className="absolute left-3 top-2 bottom-2 w-[2px]" style={{ background: `${C.coral}66` }} />
            <div className="space-y-8">
              {TIMELINE.map((s, i) => (
                <div key={i} className="relative">
                  <div
                    className="absolute -left-[26px] top-1 grid h-6 w-6 place-items-center rounded-full"
                    style={{ background: C.coral, boxShadow: `0 0 0 4px ${C.white}, 0 4px 12px -2px rgba(232,98,58,0.5)` }}
                  >
                    <s.icon className="h-3 w-3 text-white" />
                  </div>
                  <TimelineStep step={s} inline />
                </div>
              ))}
            </div>
          </div>
        </div>
      </SectionShell>

      {/* 5 — Live Proof */}
      <SectionShell bg={C.dark} dark className="overflow-hidden">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            background: `radial-gradient(700px circle at 50% 100%, rgba(232,98,58,0.10), transparent 60%)`,
          }}
        />
        <div className="relative mx-auto max-w-[760px] text-center">
          <Pill>
            <span className="mr-1 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
            What's Happening Right Now
          </Pill>
          <h2 className="mt-6 text-[32px] md:text-[64px] lg:text-[80px] font-extrabold leading-[1] tracking-[-0.02em]">
            Real builders. Real work.
            <br />
            Shipping in <span style={{ color: C.coral }}>public</span>.
          </h2>
        </div>

        <div className="relative mt-12 grid gap-6 md:grid-cols-3">
          <LiveColumn title="Latest Projects" icon={<Flame className="h-4 w-4" />} speed={22}>
            {LIVE_PROJECTS.map((p, i) => (
              <div key={i} className="rounded-xl overflow-hidden" style={{ background: C.darkSoft, border: "1px solid #232323" }}>
                <img src={p.img} alt="" className="h-32 w-full object-cover" />
                <div className="p-3.5">
                  <div className="text-sm font-semibold text-white">{p.title}</div>
                  <div className="mt-1.5 flex items-center gap-2 text-xs" style={{ color: "#8a8a8a" }}>
                    <img src={p.avatar} alt="" className="h-5 w-5 rounded-full" style={{ background: "#222" }} />
                    <span>{p.builder} · {p.time}</span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs">
                    <span style={{ color: C.coral }}>{p.tags}</span>
                    <span className="flex items-center gap-1" style={{ color: "#aaa" }}><Flame className="h-3 w-3" style={{ color: C.coral }} /> {p.reactions}</span>
                  </div>
                </div>
              </div>
            ))}
          </LiveColumn>

          <LiveColumn title="Shared Prompts" icon={<Sparkles className="h-4 w-4" />} speed={20}>
            {LIVE_PROMPTS.map((p, i) => (
              <div key={i} className="rounded-xl p-4" style={{ background: C.darkSoft, border: "1px solid #232323" }}>
                <span className="inline-block rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider" style={{ background: C.coral, color: "#fff" }}>
                  {p.model}
                </span>
                <div className="mt-2.5 text-sm text-white/90 leading-relaxed">"{p.text}"</div>
                <div className="mt-3 flex items-center gap-2 text-xs" style={{ color: "#8a8a8a" }}>
                  <img src={p.avatar} alt="" className="h-5 w-5 rounded-full" style={{ background: "#222" }} />
                  <span>{p.builder} · {p.time}</span>
                </div>
                <div className="mt-2 text-xs" style={{ color: "#aaa" }}>Copied {p.copied} times</div>
              </div>
            ))}
          </LiveColumn>

          <LiveColumn title="Community Posts" icon={<MessageCircle className="h-4 w-4" />} speed={24}>
            {LIVE_POSTS.map((p, i) => (
              <div key={i} className="rounded-xl p-4" style={{ background: C.darkSoft, border: "1px solid #232323" }}>
                <div className="flex items-center gap-2">
                  <img src={p.avatar} alt="" className="h-8 w-8 rounded-full" style={{ background: "#222" }} />
                  <span className="text-sm font-semibold text-white">{p.name}</span>
                </div>
                <p className="mt-3 text-sm text-white/90 leading-relaxed">"{p.text}"</p>
                <div className="mt-3 text-xs" style={{ color: "#8a8a8a" }}>❤️ {p.likes} · {p.comments} comments</div>
              </div>
            ))}
          </LiveColumn>
        </div>

        <div className="relative mt-12 text-center">
          <InteractiveHoverLink
            to="/vibe"
            className="px-7 py-3.5 text-white"
            style={{ background: C.coral, boxShadow: "0 12px 32px -8px rgba(232,98,58,0.55)" }}
            revealBg={C.dark}
            revealFg="#fff"
          >
            Join the Vibe
          </InteractiveHoverLink>
          <p className="mt-3 text-sm" style={{ color: "#888" }}>
            Free to join · Already 120,000 builders inside
          </p>
        </div>
      </SectionShell>

      {/* 6 — Who Is This For */}
      <SectionShell bg={C.cream}>
        <div className="mx-auto max-w-[760px] text-center">
          <Pill variant="coralSoft">Who VibeCode Is For</Pill>
          <h2 className="mt-6 text-[32px] md:text-[64px] lg:text-[80px] font-extrabold leading-[1] tracking-[-0.02em]">
            Whether you <span style={{ color: C.coral }}>build</span>, hire, or learn —
            <br />
            there's a place for you here.
          </h2>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {PERSONAS.map((p, idx) => {
            const featured = idx === 1;
            const bg = featured ? C.dark : C.white;
            const fg = featured ? "#fff" : C.text;
            const subFg = featured ? "rgba(255,255,255,0.72)" : C.muted;
            const divider = featured ? "rgba(255,255,255,0.10)" : C.border;
            const accent = C.coral;
            const iconBg = featured ? "rgba(255,255,255,0.08)" : "#FBF4F0";
            const label = ["01 / Builder", "02 / Hiring", "03 / Learner"][idx];
            return (
              <div
                key={p.who}
                className="group relative flex flex-col rounded-[20px] transition-all duration-300 hover:-translate-y-1"
                style={{
                  background: bg,
                  border: `1px solid ${featured ? "rgba(255,255,255,0.08)" : C.border}`,
                  boxShadow: featured
                    ? "0 24px 60px -24px rgba(15,15,15,0.45)"
                    : "0 2px 0 0 rgba(15,15,15,0.02), 0 20px 40px -28px rgba(15,15,15,0.18)",
                }}
              >
                <div className="p-7 md:p-8 flex-1 flex flex-col">
                  <div className="flex items-center justify-between">
                    <div
                      className="grid h-11 w-11 place-items-center rounded-xl"
                      style={{ background: iconBg, color: accent }}
                    >
                      <p.icon className="h-5 w-5" strokeWidth={2.2} />
                    </div>
                    <span
                      className="text-[11px] font-semibold tracking-[0.18em] uppercase"
                      style={{ color: featured ? "rgba(255,255,255,0.55)" : "#9A9A9A" }}
                    >
                      {label}
                    </span>
                  </div>

                  <h3 className="mt-7 text-[24px] font-bold tracking-[-0.01em]" style={{ color: fg }}>
                    {p.who}
                  </h3>
                  <p className="mt-3 text-[14.5px] leading-[1.65]" style={{ color: subFg }}>
                    {p.desc}
                  </p>

                  <div className="my-6 h-px w-full" style={{ background: divider }} />

                  <ul className="space-y-3 flex-1">
                    {p.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-[14px]" style={{ color: featured ? "rgba(255,255,255,0.88)" : C.text }}>
                        <Check className="mt-0.5 h-4 w-4 shrink-0" style={{ color: accent }} strokeWidth={2.6} />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>

                  <InteractiveHoverLink
                    to={p.href}
                    className="mt-8 w-full px-4 py-3.5 text-[14px]"
                    style={
                      featured
                        ? { background: accent, color: "#fff", boxShadow: "0 12px 28px -10px rgba(232,98,58,0.55)" }
                        : { background: C.text, color: "#fff" }
                    }
                    revealBg={featured ? C.dark : accent}
                    revealFg="#fff"
                  >
                    {p.cta}
                  </InteractiveHoverLink>
                </div>
              </div>
            );
          })}
        </div>
      </SectionShell>


      {/* 7 — Real Numbers */}
      <SectionShell bg={C.white}>
        <div className="mx-auto max-w-[820px] text-center">
          <Pill variant="coralSoft">The Honest Numbers</Pill>
          <h2 className="mt-6 text-[32px] md:text-[64px] lg:text-[80px] font-extrabold leading-[1] tracking-[-0.02em]">
            We haven't launched yet.
            <br />
            But <span style={{ color: C.coral }}>you can be first</span>.
          </h2>
          <p className="mx-auto mt-5 max-w-[620px] text-base md:text-[18px]" style={{ color: C.muted }}>
            No inflated user counts. No fake activity. Just what's real today —
            founding-member spots, perks for the first 100, and a platform being built in the open.
          </p>
        </div>

        <div
          className="mt-14 grid grid-cols-2 gap-y-8 rounded-2xl md:grid-cols-5 md:gap-0"
          style={{
            background: `linear-gradient(180deg, ${C.cream}, ${C.creamDeep})`,
            border: `1px solid ${C.border}`,
            padding: "40px 16px",
          }}
        >
          {STATS.map((s, i) => (
            <div
              key={s.l}
              className={`text-center px-3 md:px-5 ${i === 4 ? "col-span-2 md:col-span-1" : ""}`}
              style={{
                borderRight:
                  i < STATS.length - 1
                    ? `1px solid ${C.border}`
                    : undefined,
              }}
            >
              <div className="text-[30px] md:text-[42px] lg:text-[46px] font-black leading-none tracking-tight tabular-nums" style={{ color: C.coral }}>
                <Counter to={s.n} prefix={(s as { prefix?: string }).prefix ?? ""} suffix={s.suffix} locale="en-US" />
              </div>
              <div className="mt-3 text-[11px] md:text-xs font-semibold uppercase tracking-wider" style={{ color: C.muted }}>
                {s.l}
              </div>
            </div>
          ))}
        </div>

        <div className="mx-auto mt-14 max-w-[680px] text-center">
          <Quote className="mx-auto h-8 w-8" style={{ color: C.coral }} />
          <p className="mt-4 text-lg md:text-[22px] italic leading-[1.55]" style={{ color: "#333" }}>
            "From Bangalore to Bhagalpur, Indian AI builders are shipping products that matter. VibeCode is where they meet."
          </p>
          <p className="mt-4 text-sm font-semibold uppercase tracking-wider" style={{ color: C.coral }}>
            — VibeCode Manifesto
          </p>
        </div>
      </SectionShell>

      {/* 8 — Testimonials — Twitter-style masonry wall */}
      <SectionShell bg={C.cream}>
        <div className="mx-auto max-w-[1100px] text-center">
          <Pill variant="coralSoft">What Builders Say</Pill>
          <h2 className="mt-6 text-[40px] sm:text-[56px] md:text-[72px] lg:text-[88px] font-extrabold leading-[0.98] tracking-[-0.03em]">
            What people are saying{" "}
            <span className="whitespace-nowrap">
              on <span style={{ color: C.coral }}>Twitter</span>.
            </span>
          </h2>
          <p className="mx-auto mt-6 max-w-[640px] text-base md:text-[19px] md:leading-[1.55]" style={{ color: C.muted }}>
            Real, unfiltered posts from Indian AI builders shipping every day on VibeCode.
          </p>
        </div>

        <div className="mt-14">
          <style>{`
            .tw-masonry { column-count: 1; column-gap: 1.25rem; }
            @media (min-width: 640px)  { .tw-masonry { column-count: 2; } }
            @media (min-width: 1024px) { .tw-masonry { column-count: 3; } }
            @media (min-width: 1280px) { .tw-masonry { column-count: 4; } }
          `}</style>
          <div className="tw-masonry">
            {TESTIMONIALS.map((t, i) => (
              <TweetCard key={t.h} t={t} index={i} />
            ))}
          </div>
        </div>
      </SectionShell>


      {/* 8b — Compare */}
      <CompareTable />

      {/* 8c — ROI Calculator */}
      <PricingCalculator />

      {/* 9 — Pricing */}
      <SectionShell bg={C.white}>
        <div className="mx-auto max-w-[760px] text-center">
          <Pill variant="coralSoft">Pricing</Pill>
          <h2 className="mt-6 text-[32px] md:text-[64px] lg:text-[80px] font-extrabold leading-[1] tracking-[-0.02em]">
            Free to start.
            <br />
            Pay only when you're <span style={{ color: C.coral }}>ready to scale</span>.
          </h2>
          <p className="mt-4 text-base md:text-[18px]" style={{ color: C.muted }}>
            85% of our builders never pay a rupee. We're serious.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {PLANS.map((p) => (
            <GlareHover
              key={p.title}
              duration={700}
              glareOpacity={p.popular ? 0.55 : 0.35}
              className={`rounded-2xl transition-all duration-300 hover:-translate-y-1 ${p.popular ? "md:-translate-y-2" : ""}`}
              style={{
                background: C.white,
                border: p.popular ? `2px solid ${C.coral}` : `1px solid ${C.border}`,
                boxShadow: p.popular ? "0 20px 60px -20px rgba(232,98,58,0.35)" : "0 4px 20px -12px rgba(0,0,0,0.08)",
              }}
            >
              <div className="relative p-6 md:p-7" style={{ background: p.headerBg, color: p.headerFg }}>
                {p.badge && (
                  <span
                    className="absolute right-4 top-4 rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider"
                    style={{ background: "#fff", color: C.coral }}
                  >
                    {p.badge}
                  </span>
                )}
                <div className="text-xs font-bold uppercase tracking-[0.14em] opacity-90">{p.title}</div>
                <div className="mt-3 flex items-end gap-2">
                  <span className="text-[44px] md:text-[52px] font-extrabold leading-none tracking-tight">{p.price}</span>
                  <span className="mb-2 text-sm opacity-80">{p.per}</span>
                </div>
                <p className="mt-2 text-sm opacity-90">{p.sub}</p>
              </div>
              <div className="p-6 md:p-7">
                <ul className="space-y-2.5">
                  {p.features.map((f) => (
                    <li key={f.t} className="flex items-start gap-2 text-[14px]">
                      {f.on ? (
                        <Check className="mt-0.5 h-4 w-4 shrink-0" style={{ color: C.coral }} />
                      ) : (
                        <span className="mt-0.5 h-4 w-4 shrink-0 text-center leading-none" style={{ color: "#c4c4c4" }}>×</span>
                      )}
                      <span style={{ color: f.on ? C.text : "#aaa" }}>{f.t}</span>
                    </li>
                  ))}
                </ul>
                <InteractiveHoverLink
                  to="/pricing"
                  className="mt-6 w-full px-4 py-3 text-sm"
                  style={{ background: p.ctaBg, color: p.ctaFg, border: p.ctaBorder }}
                  revealBg={p.ctaBg === C.coral ? C.dark : C.coral}
                  revealFg="#fff"
                >
                  {p.cta}
                </InteractiveHoverLink>
              </div>
            </GlareHover>
          ))}
        </div>


        <p className="mx-auto mt-8 max-w-[600px] text-center text-[13px]" style={{ color: "#888" }}>
          All plans include free access to communities, prompts library, and workflow library. Cancel anytime. No questions asked.
        </p>
      </SectionShell>

      {/* 10 — FAQ */}
      <SectionShell bg={C.cream} id="faq">
        <div className="mx-auto max-w-[760px] text-center">
          <Pill variant="coralSoft">FAQ</Pill>
          <h2 className="mt-6 text-[32px] md:text-[64px] lg:text-[80px] font-extrabold leading-[1] tracking-[-0.02em]">
            Questions we get asked a <span style={{ color: C.coral }}>lot</span>.
          </h2>
        </div>

        <div
          className="mx-auto mt-10 max-w-[720px] rounded-2xl px-6 md:px-8"
          style={{ background: C.white, border: `1px solid ${C.border}` }}
        >
          {FAQ.map((f, i) => (
            <FaqItem key={f.q} q={f.q} a={f.a} isLast={i === FAQ.length - 1} />
          ))}
        </div>
      </SectionShell>

      {/* 11 — Final CTA */}
      <section
        data-reveal
        className="relative w-full overflow-hidden"
        style={{ background: C.dark, paddingTop: 96, paddingBottom: 96 }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            background: `radial-gradient(800px circle at 50% 50%, rgba(232,98,58,0.18), transparent 60%)`,
          }}
        />
        <div className="relative mx-auto max-w-[820px] px-5 text-center md:px-8">
          <span
            className="inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-white"
            style={{ background: C.coral, boxShadow: "0 0 30px -4px rgba(232,98,58,0.7)" }}
          >
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
            Join The Movement
          </span>

          <h2 className="mt-6 text-[36px] md:text-[56px] font-black leading-[1.05] tracking-tight text-white">
            India's AI builder revolution
            <br />
            is happening <span style={{ color: C.coral }}>right now</span>.
            <br />
            Are you in?
          </h2>

          <ScrollHighlightText
            className="mx-auto mt-6 text-base md:text-[19px] leading-[1.6]"
            text="120,000 builders are already on VibeCode. They're shipping products, landing clients, earning through prompts, and building the companies that will define Indian tech in 2026 and beyond."
          />
          <ScrollHighlightText
            className="mx-auto mt-4 text-base md:text-[19px] leading-[1.6]"
            text="Your profile takes 60 seconds to create. It could change your career."
          />

          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4">
            <InteractiveHoverLink
              to="/auth"
              className="w-full !rounded-2xl px-7 text-[16px] md:text-[17px] text-white sm:w-auto"
              style={{ background: C.coral, height: 54, boxShadow: "0 16px 40px -12px rgba(232,98,58,0.6)" }}
              revealBg="#ffffff"
              revealFg={C.dark}
            >
              Create Your Profile — Free
            </InteractiveHoverLink>
            <InteractiveHoverLink
              to="/explore"
              className="w-full !rounded-2xl px-7 text-[16px] md:text-[17px] text-white sm:w-auto"
              style={{ background: "transparent", border: "1.5px solid rgba(255,255,255,0.35)", height: 54 }}
              revealBg={C.coral}
              revealFg="#fff"
            >
              Explore the Platform
            </InteractiveHoverLink>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-[13px]" style={{ color: "#888" }}>
            {["Free forever for builders", "No credit card required", "Profile live in 60 seconds", "120,000 builders already inside"].map((t, i) => (
              <span key={t} className="flex items-center gap-1.5">
                <Check className="h-3.5 w-3.5" style={{ color: C.coral }} /> {t}
                {i < 3 && <span className="ml-3 hidden md:inline" style={{ color: "#333" }}>·</span>}
              </span>
            ))}
          </div>

          <div className="mt-12 flex flex-col items-center gap-3">
            <div className="flex -space-x-3">
              {["ana", "ben", "cara", "dev", "eli", "fara", "gav", "hiro"].map((s) => (
                <img
                  key={s}
                  src={`https://api.dicebear.com/7.x/notionists/svg?seed=${s}`}
                  alt=""
                  className="h-11 w-11 rounded-full"
                  style={{ background: "#222", border: "2px solid #0F0F0F" }}
                />
              ))}
              <div
                className="ml-2 flex h-11 items-center justify-center rounded-full px-3 text-xs font-bold text-white"
                style={{ background: C.coral, border: "2px solid #0F0F0F" }}
              >
                +120,000
              </div>
            </div>
            <p className="text-sm" style={{ color: "#888" }}>Join them today</p>
          </div>
        </div>
      </section>

      <LandingDock />

      {/* Kinetic wordmark — below dock */}
      <section
        className="relative overflow-hidden py-20 md:py-28"
        style={{ background: C.dark }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(700px circle at 50% 60%, rgba(232,98,58,0.14), transparent 65%)",
          }}
        />
        <div className="relative flex items-center justify-center">
          <KineticText
            text="vibecoder"
            splitAt={4}
            className="text-[22vw] tracking-[-0.06em] md:text-[16rem]"
          />
        </div>
        <div
          className="relative mx-auto mt-6 text-center font-mono text-[11px] uppercase tracking-[0.3em]"
          style={{ color: "#5a5a5a" }}
        >
          Built in India · For builders, by builders
        </div>
      </section>
    </Shell>
  );
}

/* ------------------------------ Sub-components --------------------------- */

function IconBadge({
  icon: Icon,
  bg,
  iconClass = "text-white",
}: {
  icon: React.ComponentType<{ className?: string }>;
  bg: string;
  iconClass?: string;
}) {
  return (
    <div
      className="grid h-14 w-14 place-items-center rounded-2xl"
      style={{ background: bg, boxShadow: "0 8px 24px -10px rgba(0,0,0,0.25)" }}
    >
      <Icon className={`h-7 w-7 ${iconClass}`} />
    </div>
  );
}

function BentoCard({
  children,
  bg,
  className = "",
  textLight = false,
}: {
  children: React.ReactNode;
  bg: string;
  className?: string;
  textLight?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl p-6 md:p-8 transition-all duration-300 hover:-translate-y-1 ${className}`}
      style={{
        background: bg,
        border: bg === C.white ? `1px solid ${C.border}` : "none",
        color: textLight ? "#fff" : C.text,
        boxShadow: bg === C.white ? "0 4px 20px -12px rgba(0,0,0,0.08)" : "0 12px 40px -16px rgba(0,0,0,0.4)",
      }}
    >
      {children}
    </div>
  );
}

/* ------------------------------- Timeline -------------------------------- */
const TIMELINE = [
  {
    when: "Day 1",
    icon: UserPlus,
    title: "Build your identity in 60 seconds",
    body: "Sign up free. Add your skills, tools, and what you're building. Your builder profile goes live immediately — searchable by companies and collaborators.",
    tag: "FREE · FOREVER",
  },
  {
    when: "Day 2–3",
    icon: Send,
    title: "Share your first build",
    body: "Drop a project, share a prompt, post a workflow. The community reacts, comments, and follows. Your first 100 XP come faster than you think.",
    tag: "EARN XP · GET NOTICED",
  },
  {
    when: "Week 1",
    icon: MessageCircle,
    title: "Get discovered — or discover others",
    body: "Hirers search your profile. Collaborators DM you. You find the builder with exactly the skill you need. The marketplace finds the market.",
    tag: "GET HIRED · HIRE OTHERS",
  },
  {
    when: "Month 1+",
    icon: Award,
    title: "Build reputation. Build income.",
    body: "Your XP compounds. Your leaderboard rank rises. You redeem VibeCoins for real UPI payouts. Companies reach out to YOU.",
    tag: "RANK UP · EARN REAL ₹",
  },
];

function TimelineWithBeams() {
  const containerRef = useRef<HTMLDivElement>(null);
  const r0 = useRef<HTMLDivElement>(null);
  const r1 = useRef<HTMLDivElement>(null);
  const r2 = useRef<HTMLDivElement>(null);
  const r3 = useRef<HTMLDivElement>(null);
  const refs = [r0, r1, r2, r3];

  return (
    <div ref={containerRef} className="relative">
      <div className="grid grid-cols-4 gap-6">
        {TIMELINE.map((s, i) => (
          <TimelineStep key={i} step={s} circleRef={refs[i]} />
        ))}
      </div>
      {[0, 1, 2].map((i) => (
        <AnimatedBeam
          key={i}
          containerRef={containerRef}
          fromRef={refs[i]}
          toRef={refs[i + 1]}
          duration={2.6}
          delay={i * 0.35}
          curvature={-28}
          pathOpacity={0.14}
        />
      ))}
    </div>
  );
}


function TimelineStep({
  step,
  inline = false,
  circleRef,
}: {
  step: typeof TIMELINE[number];
  inline?: boolean;
  circleRef?: React.Ref<HTMLDivElement>;
}) {
  const Icon = step.icon;
  return (
    <div className={inline ? "" : "group relative pt-1 cursor-default"}>
      {!inline && (
        <div
          ref={circleRef}
          className="mx-auto grid h-12 w-12 place-items-center rounded-full relative z-10 transition-all duration-300 group-hover:-translate-y-1 group-hover:scale-110 group-hover:rotate-6"
          style={{ background: C.coral, color: "#fff", boxShadow: `0 0 0 6px ${C.white}, 0 8px 20px -6px rgba(232,98,58,0.5)` }}
        >
          <Icon className="h-5 w-5 transition-transform duration-300 group-hover:scale-110" />
          <span aria-hidden className="pointer-events-none absolute inset-0 rounded-full opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ boxShadow: `0 0 0 10px ${C.coral}22` }} />
        </div>
      )}
      <div className={inline ? "" : "mt-5 text-center transition-transform duration-300 group-hover:-translate-y-0.5"}>
        <div className="text-xs font-bold uppercase tracking-[0.14em]" style={{ color: C.coral }}>
          {step.when}
        </div>
        <h3 className="mt-2 text-[17px] font-bold transition-colors duration-300 group-hover:text-[color:var(--c-coral,#E8623A)]">{step.title}</h3>
        <p className="mt-2 text-[14px] leading-[1.7]" style={{ color: C.muted }}>
          {step.body}
        </p>
        <div className="mt-3 inline-block rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider transition-all duration-300 group-hover:scale-105 group-hover:shadow-[3px_3px_0_0_#0F0F0F]" style={{ background: C.coralSoft, color: C.coral, border: `1px solid ${C.coral}33` }}>
          {step.tag}
        </div>
      </div>
    </div>
  );
}


/* ------------------------------ Live proof ------------------------------- */
function LiveColumn({
  title,
  icon,
  children,
  speed = 22,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  speed?: number;
}) {
  return (
    <div>
      <h3 className="mb-4 flex items-center gap-2 text-lg md:text-xl font-extrabold tracking-tight" style={{ color: "#ffffff" }}>
        <span style={{ color: C.coral }}>{icon}</span>
        {title}
      </h3>
      <div
        className="relative overflow-hidden"
        style={{
          height: 540,
          maskImage: "linear-gradient(to bottom, transparent, black 6%, black 94%, transparent)",
          WebkitMaskImage: "linear-gradient(to bottom, transparent, black 6%, black 94%, transparent)",
        }}
      >
        <div
          className="flex flex-col gap-4"
          style={{ animation: `livescroll ${speed}s linear infinite` }}
        >
          {children}
          {children}
        </div>
      </div>
      <style>{`@keyframes livescroll { from { transform: translateY(0); } to { transform: translateY(-50%); } }`}</style>
    </div>
  );
}

const LIVE_PROJECTS = [
  { img: "https://picsum.photos/seed/proj1/400/200", title: "FlowOps v2 — n8n Marketplace", builder: "Aarav", time: "2h ago", tags: "#n8n #automation", reactions: 391, avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=aarav" },
  { img: "https://picsum.photos/seed/proj2/400/200", title: "PromptForge — Prompt Editor for Teams", builder: "Priya", time: "4h ago", tags: "#saas #prompts", reactions: 218, avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=priya" },
  { img: "https://picsum.photos/seed/proj3/400/200", title: "MedScribe — AI Notes for Doctors", builder: "Kabir", time: "6h ago", tags: "#health #ai", reactions: 512, avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=kabir" },
];

const LIVE_PROMPTS = [
  { model: "Claude", text: "Landing page conversion prompt that beat my old copy by 3x…", builder: "Priya", time: "3h ago", copied: 283, avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=priya" },
  { model: "GPT-4o", text: "Cold email generator for AI freelancers — 42% reply rate.", builder: "Arjun", time: "5h ago", copied: 194, avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=arjun" },
  { model: "Gemini", text: "Product spec writer prompt that produces PRDs in 60 seconds.", builder: "Neha", time: "8h ago", copied: 176, avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=neha" },
];

const LIVE_POSTS = [
  { name: "Kabir Singh", text: "MedScribe just crossed ₹1L MRR 🙏 Two years, four failed projects…", likes: 352, comments: 78, avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=kabir" },
  { name: "Isha Verma", text: "Design engineers of India — what's your favorite Figma-to-code tool?", likes: 128, comments: 44, avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=isha" },
  { name: "Rohan Sinha", text: "Shipped an n8n flow that saved my client 20 hrs/week. Pure magic.", likes: 214, comments: 31, avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=rohan" },
];

/* ------------------------------- Personas -------------------------------- */
const PERSONAS = [
  {
    who: "The AI Builder",
    icon: Rocket,
    color: C.coral,
    desc: "You ship with Lovable, Claude, n8n, Cursor, or any AI tool. You build SaaS, agents, automations, and products. You want to be discovered, hired, and recognized for it.",
    features: ["Builder profile + portfolio", "Project and prompt showcase", "XP, levels, VibeCoin rewards", "Access to all communities", "Job applications in 10 seconds"],
    cta: "Join as Builder — Free",
    href: "/auth",
  },
  {
    who: "The Company / Founder",
    icon: Building2,
    color: C.blue,
    desc: "You need AI talent — fast. Not polished LinkedIn profiles, but people who have actually shipped. VibeCode shows you proof of work, not promises.",
    features: ["Search 120K+ builder profiles", "Filter by tool, skill, location", "Post jobs to active builders", "Direct DM any builder", "See real project portfolios"],
    cta: "Start Hiring — ₹2,999/mo",
    href: "/pricing",
  },
  {
    who: "The Student / Beginner",
    icon: GraduationCap,
    color: C.green,
    desc: "You just started your AI builder journey. You want prompts that work, builders to learn from, and communities that don't gatekeep. This is your home.",
    features: ["8,400+ prompts to copy and use", "3,200+ projects to learn from", "Student-friendly communities", "Mentors who actually respond", "Your first job in the job board"],
    cta: "Join as Learner — Free",
    href: "/auth",
  },
];

/* --------------------------------- Plans --------------------------------- */
const PLANS = [
  {
    title: "Builder",
    price: "₹0",
    per: "/ forever",
    sub: "No card. No expiry. No catch.",
    headerBg: C.cream,
    headerFg: C.text,
    badge: null as string | null,
    popular: false,
    features: [
      { t: "Full profile + portfolio page", on: true },
      { t: "Unlimited project showcase", on: true },
      { t: "Apply to all 55+ jobs", on: true },
      { t: "Access all 450+ communities", on: true },
      { t: "Browse 8,400+ prompts", on: true },
      { t: "Earn XP and VibeCoins", on: true },
      { t: "Top search placement (OG)", on: false },
      { t: "Verified badge (OG)", on: false },
    ],
    cta: "Start Free — No card needed",
    ctaBg: C.white,
    ctaFg: C.text,
    ctaBorder: `1.5px solid ${C.text}`,
  },
  {
    title: "OG Builder",
    price: "₹499",
    per: "/ month",
    sub: "Less than one chai per day.",
    headerBg: C.coral,
    headerFg: "#fff",
    badge: "Most Popular",
    popular: true,
    features: [
      { t: "Everything in Builder", on: true },
      { t: "500 VibeCoins (claim 1 paid community free)", on: true },
      { t: "Top of search results", on: true },
      { t: "Verified Builder badge (premium red)", on: true },
      { t: "Verified OG badge (golden)", on: true },
      { t: "Featured profile placement", on: true },
      { t: "Priority job application", on: true },
      { t: "Advanced profile analytics", on: true },
      { t: "Profile boost (2x / month)", on: true },
      { t: "Early access to new / beta features", on: true },
      { t: "Founding member — name on Founder's Wall forever", on: true },
    ],
    cta: "Go OG — ₹499/month",
    ctaBg: C.dark,
    ctaFg: "#fff",
    ctaBorder: "none",
  },
  {
    title: "Hiring",
    price: "₹2,999",
    per: "/ month",
    sub: "One hire pays for 12 months.",
    headerBg: C.dark,
    headerFg: "#fff",
    badge: null,
    popular: false,
    features: [
      { t: "Everything in Builder", on: true },
      { t: "Unlimited builder searches", on: true },
      { t: "Post unlimited job openings", on: true },
      { t: "Direct DM any builder", on: true },
      { t: "Advanced search + filters", on: true },
      { t: "Saved candidate pools", on: true },
      { t: "Priority placement for jobs", on: true },
      { t: "Dedicated support", on: true },
    ],
    cta: "Start Hiring",
    ctaBg: C.coral,
    ctaFg: "#fff",
    ctaBorder: "none",
  },
];

/* --------------------------------- FAQ ---------------------------------- */
function FaqItem({ q, a, isLast }: { q: string; a: string; isLast?: boolean }) {
  const [open, setOpen] = useState(false);
  const [hover, setHover] = useState(false);
  return (
    <div
      className="group relative rounded-lg transition-colors"
      style={{
        borderBottom: isLast ? "none" : `1px solid ${C.border}`,
        background: open ? "#FFF8F3" : hover ? "#FAF7F1" : "transparent",
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {/* Notion-style left rail when open */}
      <div
        aria-hidden
        className="absolute bottom-2 left-0 top-2 w-[3px] rounded-full transition-all duration-300"
        style={{ background: open ? C.coral : "transparent" }}
      />
      <button
        onClick={() => setOpen((x) => !x)}
        className="flex w-full items-center gap-3 py-5 pl-4 pr-3 text-left"
      >
        {/* Notion toggle triangle */}
        <span
          className="grid h-5 w-5 shrink-0 place-items-center rounded transition-all duration-200"
          style={{
            background: open || hover ? "rgba(232,98,58,0.12)" : "transparent",
            color: C.coral,
            transform: open ? "rotate(90deg)" : "rotate(0deg)",
          }}
        >
          <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor">
            <path d="M2 1 L8 5 L2 9 Z" />
          </svg>
        </span>
        <span className="flex-1 text-[16px] md:text-[17px] font-bold" style={{ color: C.text }}>{q}</span>
        <span
          className="hidden font-mono text-[11px] font-semibold uppercase tracking-wider transition-opacity md:inline"
          style={{ color: C.coral, opacity: hover || open ? 1 : 0 }}
        >
          {open ? "close" : "open"}
        </span>
      </button>
      <div
        className="grid transition-all duration-300 ease-out"
        style={{ gridTemplateRows: open ? "1fr" : "0fr" }}
      >
        <div className="overflow-hidden">
          <div className="pb-5 pl-11 pr-8 text-[15px] leading-[1.75]" style={{ color: "#555" }}>
            {a}
          </div>
        </div>
      </div>
    </div>
  );
}
