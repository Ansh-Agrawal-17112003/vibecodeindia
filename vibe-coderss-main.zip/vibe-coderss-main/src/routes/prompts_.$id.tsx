import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowUp, Copy, Share2, ArrowLeft, Sparkles } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Shell } from "@/components/site/Shell";
import { PromptCard } from "@/components/cards/PromptCard";
import { sharePage } from "@/lib/share";
import { getBuilder, prompts } from "@/lib/mock-data";

export const Route = createFileRoute("/prompts_/$id")({
  loader: ({ params }) => {
    const p = prompts.find((x) => x.id === params.id);
    if (!p) throw notFound();
    return { prompt: p };
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.prompt.title} · VibeCode` }] }),
  component: PromptDetail,
  notFoundComponent: () => (
    <Shell>
      <div className="container-page py-20 text-center">
        <h1 className="font-display text-3xl font-extrabold">Prompt not found</h1>
        <Link to="/prompts" className="mt-4 inline-block text-coral underline">Browse all prompts</Link>
      </div>
    </Shell>
  ),
});

function PromptDetail() {
  const { prompt: p } = Route.useLoaderData();
  const b = getBuilder(p.builderId);
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState(false);
  const [upvoted, setUpvoted] = useState(false);
  const [upvoteCount, setUpvoteCount] = useState(p.upvotes);
  const related = prompts.filter((x) => x.id !== p.id && x.category === p.category).slice(0, 3);

  // Guarantee an extremely detailed 500+ char prompt users can copy/paste as-is.
  const fullPrompt = (() => {
    const base = p.full || p.preview;
    const extended = `${base}

--- CONTEXT ---
You are a senior ${p.category.toLowerCase()} specialist working with the ${p.model} model. Adopt an expert-level tone that is direct, specific, and free of filler.

--- INSTRUCTIONS ---
1. Read the user input carefully and identify the underlying intent, constraints, and desired outcome before responding.
2. Break the response into clearly labelled sections with short paragraphs and bullet points where useful.
3. Whenever a placeholder like {{input}} or {{topic}} appears, replace it with the exact content the user supplied — never leave placeholders in the final output.
4. Prefer concrete examples, numbers, and named tools over generic advice. Cite trade-offs when relevant.
5. If information is missing, state a reasonable assumption in one line and continue — do not stall by asking follow-up questions unless absolutely required.

--- OUTPUT FORMAT ---
- Start with a one-line TL;DR.
- Follow with the detailed body organised under clear H3 headings.
- End with a "Next steps" checklist of 3–5 actionable items the user can execute in under an hour.

--- QUALITY BAR ---
The final answer should read like it was written by a top 1% ${p.category} practitioner: opinionated, concise, immediately useful. Do not hedge, do not repeat the prompt, do not add disclaimers.`;
    return extended.length < 500
      ? extended + "\n\n" + Array(500 - extended.length).fill("").join("")
      : extended;
  })();

  const copy = () => {
    navigator.clipboard?.writeText(fullPrompt);
    setCopied(true);
    toast.success("Full prompt copied — paste into ChatGPT / Claude");
    setTimeout(() => setCopied(false), 1500);
  };
  const share = () => {
    sharePage(p.title, p.preview);
    setShared(true);
    setTimeout(() => setShared(false), 1500);
  };
  const toggleUpvote = () => {
    const next = !upvoted;
    setUpvoted(next);
    setUpvoteCount((c: number) => c + (next ? 1 : -1));
    toast.success(next ? "Upvoted!" : "Removed upvote");
  };


  return (
    <Shell>
      <div className="container-page py-8">
        <Link to="/prompts" className="inline-flex items-center gap-1 text-sm font-bold text-coral hover:underline">
          <ArrowLeft className="h-4 w-4" /> Back to prompts
        </Link>

        <div className="mt-4 grid gap-8 lg:grid-cols-[1fr_320px]">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white">{p.model}</span>
              <span className="rounded-md border-[1.5px] border-[#0F0F0F] bg-gold px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider">{p.category}</span>
              <span className="flex items-center gap-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-2.5 py-1 text-[10px] font-bold uppercase">
                <ArrowUp className="h-3 w-3" /> {p.upvotes}
              </span>
            </div>
            <h1 className="mt-3 font-display text-4xl font-extrabold leading-tight tracking-tight">{p.title}</h1>
            <p className="mt-3 text-base text-muted-foreground">{p.preview}</p>

            <div className="card-editorial mt-6 overflow-hidden">
              <div className="flex items-center justify-between border-b-[1.5px] border-[#0F0F0F] bg-[#FAF6F1] px-4 py-2 text-xs font-bold">
                <span className="flex items-center gap-1.5"><Sparkles className="h-3.5 w-3.5 text-coral" /> prompt.md</span>
                <button
                  onClick={copy}
                  className="flex items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white"
                  style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                >
                  <Copy className="h-3 w-3" /> {copied ? "Copied!" : "Copy Prompt"}
                </button>
              </div>
              <pre className="overflow-x-auto whitespace-pre-wrap break-words p-5 font-mono text-sm leading-relaxed text-foreground"><code>{fullPrompt}</code></pre>
              <div className="border-t-[1.5px] border-[#0F0F0F] bg-[#FAF6F1] px-4 py-2 text-[11px] font-bold text-muted-foreground">{fullPrompt.length} characters · Ready to paste</div>
            </div>

            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              <div className="card-editorial p-5">
                <h3 className="font-display text-lg font-extrabold">How to use</h3>
                <ul className="mt-3 space-y-2 text-sm text-foreground/80">
                  <li>1. Copy the prompt with the button above.</li>
                  <li>2. Replace placeholders like <code className="rounded bg-[#FAF6F1] px-1 font-mono text-xs">{`{{input}}`}</code> with your content.</li>
                  <li>3. Paste into {p.model} (or any frontier model).</li>
                  <li>4. Iterate on the output until it matches your taste.</li>
                </ul>
              </div>
              <div className="card-editorial p-5">
                <h3 className="font-display text-lg font-extrabold">Best for</h3>
                <ul className="mt-3 space-y-2 text-sm text-foreground/80">
                  <li>• {p.category} workflows and use-cases</li>
                  <li>• Optimised for <strong>{p.model}</strong></li>
                  <li>• Portable to Claude, Gemini, GPT-4o</li>
                  <li>• Pair with a system role for consistent format</li>
                </ul>
              </div>
            </div>

            {related.length > 0 && (
              <div className="mt-10">
                <h3 className="mb-4 font-display text-xl font-extrabold">Related {p.category} prompts</h3>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {related.map((r) => <PromptCard key={r.id} p={r} />)}
                </div>
              </div>
            )}
          </div>

          <aside className="space-y-4">
            <div className="card-editorial space-y-2 p-4">
              <button onClick={copy} className="btn-coral w-full">
                <Copy className="h-4 w-4" /> {copied ? "Copied!" : "Copy Prompt"}
              </button>
              <button onClick={share} className="btn-outline-dark w-full">
                <Share2 className="h-4 w-4" /> {shared ? "Link copied!" : "Share"}
              </button>
              <button
                onClick={toggleUpvote}
                className="flex w-full items-center justify-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] px-4 py-2.5 text-sm font-bold"
                style={{ boxShadow: "2px 2px 0 0 #0F0F0F", background: upvoted ? "#E8623A" : "#F5A623", color: upvoted ? "#fff" : "#0F0F0F" }}
              >
                <ArrowUp className="h-4 w-4" /> {upvoted ? "Upvoted" : "Upvote"} · {upvoteCount}
              </button>
            </div>

            <div className="card-editorial p-4">
              <h4 className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Shared by</h4>
              <Link to="/u/$username" params={{ username: b.username }} className="flex items-center gap-3">
                <img src={b.avatar} className="h-10 w-10 rounded-full border-[1.5px] border-[#0F0F0F]" alt="" />
                <div>
                  <div className="font-bold">{b.name}</div>
                  <div className="text-xs text-muted-foreground">{b.title}</div>
                </div>
              </Link>
            </div>

            <div className="card-editorial p-4">
              <h4 className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Stats</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Upvotes</span><span className="font-bold">{upvoteCount}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Model</span><span className="font-bold">{p.model}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Category</span><span className="font-bold">{p.category}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">License</span><span className="font-bold">CC-BY</span></div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </Shell>
  );
}
