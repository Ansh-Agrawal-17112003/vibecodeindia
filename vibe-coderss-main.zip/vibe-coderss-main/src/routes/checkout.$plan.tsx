import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Check, Shield, Lock, Sparkles, CreditCard, Smartphone, Building2, Wallet, QrCode, Timer } from "lucide-react";
import { toast } from "sonner";
import { Shell } from "@/components/site/Shell";
import { PaymentOTPModal } from "@/components/site/PaymentOTPModal";
import { useAuth } from "@/hooks/useAuth";
import { PAYEE_UPI_ID, PAYEE_NAME, upiIntent, upiQrUrl } from "@/lib/payee";
import { PaymentBrand } from "@/components/site/PaymentBrand";

type CheckoutSearch = { amount?: number; name?: string; desc?: string };
export const Route = createFileRoute("/checkout/$plan")({
  validateSearch: (s: Record<string, unknown>): CheckoutSearch => ({
    amount: typeof s.amount === "number" ? s.amount : s.amount ? Number(s.amount) : undefined,
    name: typeof s.name === "string" ? s.name : undefined,
    desc: typeof s.desc === "string" ? s.desc : undefined,
  }),
  component: CheckoutPage,
});

const PLANS: Record<string, { name: string; amount: number; per: string; desc: string; features: string[]; popular?: boolean }> = {
  builder: { name: "Builder", amount: 0, per: "forever", desc: "Free forever for every AI builder.", features: ["Full profile + portfolio", "Apply to unlimited jobs", "Join all 450+ communities", "Browse prompts & workflows"] },
  pro:     { name: "Pro",     amount: 499,  per: "per month", desc: "For freelancers winning more clients.", features: ["Everything in Builder", "Top of search results", "Verified badge", "Featured profile slots", "Advanced analytics", "Priority support"], popular: true },
  hiring:  { name: "Hiring",  amount: 2999, per: "per month", desc: "For founders & agencies hiring fast.", features: ["Post unlimited jobs", "Direct DM any builder", "Advanced search filters", "Saved candidate pools", "Dedicated hiring manager", "Team seats (3)"] },
};

type Method = "upi" | "card" | "netbanking" | "wallet" | "qr";

const UPI_APPS = [
  { id: "gpay", name: "Google Pay", slug: "googlepay" },
  { id: "phonepe", name: "PhonePe", slug: "phonepe", color: "5F259F" },
  { id: "paytm", name: "Paytm", slug: "paytm" },
  { id: "amazonpay", name: "Amazon Pay", slug: "amazonpay" },
  { id: "cred", name: "CRED", slug: "cred", color: "0F0F0F" },
  { id: "whatsapp", name: "WhatsApp Pay", slug: "whatsapp", color: "25D366" },
];
const BANKS = ["HDFC Bank", "ICICI Bank", "State Bank of India", "Axis Bank", "Kotak Mahindra", "Yes Bank", "IDFC FIRST", "IndusInd Bank"];
const WALLETS = [
  { id: "paytm", name: "Paytm Wallet", slug: "paytmwallet" },
  { id: "mobikwik", name: "MobiKwik", slug: "mobikwik" },
  { id: "freecharge", name: "Freecharge", slug: "freecharge" },
  { id: "amazon", name: "Amazon Pay Balance", slug: "amazonpaybalance" },
];

function CheckoutPage() {
  const { plan } = Route.useParams();
  const search = Route.useSearch();
  const navigate = useNavigate();
  const { user } = useAuth();
  const planData = PLANS[plan] ?? {
    name: search.name || plan.replace(/-/g, " "),
    amount: search.amount ?? 999,
    per: "one-time",
    desc: search.desc || "One-time purchase — instant download after payment.",
    features: ["Instant download after payment", "Lifetime access", "Updates included", "Commercial license"],
  };
  const [method, setMethod] = useState<Method>("upi");
  const [gateway, setGateway] = useState<"razorpay" | "stripe" | "cashfree">("razorpay");
  const [upiId, setUpiId] = useState("");
  const [selectedUpiApp, setSelectedUpiApp] = useState<string | null>(null);
  const [card, setCard] = useState({ number: "", name: "", exp: "", cvv: "" });
  const [bank, setBank] = useState(BANKS[0]);
  const [wallet, setWallet] = useState(WALLETS[0].id);
  const [coupon, setCoupon] = useState("");
  const [discount, setDiscount] = useState(0);
  const [otpOpen, setOtpOpen] = useState(false);

  const gst = useMemo(() => Math.round((planData.amount - discount) * 0.18), [planData.amount, discount]);
  const total = Math.max(0, planData.amount - discount + gst);

  const applyCoupon = () => {
    const c = coupon.trim().toUpperCase();
    if (c === "VIBE10") { setDiscount(Math.round(planData.amount * 0.1)); toast.success("Coupon applied — 10% off"); }
    else if (c === "INDIA50") { setDiscount(Math.round(planData.amount * 0.5)); toast.success("Coupon applied — 50% off 🎉"); }
    else { setDiscount(0); toast.error("Invalid coupon"); }
  };

  const pay = () => {
    if (planData.amount === 0) {
      toast.success("Welcome to VibeCode Builder — you're in!");
      navigate({ to: "/" });
      return;
    }
    if (!user) {
      toast.error("Please sign in to continue");
      navigate({ to: "/auth" });
      return;
    }
    if (method === "upi" && !selectedUpiApp && !/^[\w.\-]{2,}@[\w]{2,}$/.test(upiId)) {
      toast.error("Enter a valid UPI ID (e.g. name@okhdfc) or pick an app");
      return;
    }
    if (method === "card" && (card.number.replace(/\s/g, "").length < 12 || card.cvv.length < 3)) {
      toast.error("Enter valid card details");
      return;
    }
    setOtpOpen(true);
  };

  const onVerified = async () => {
    toast.success(`Payment of ₹${total.toLocaleString("en-IN")} confirmed via ${gateway.toUpperCase()}`);
    navigate({ to: "/" });
  };

  // Price-lock reservation timer — 10 minutes
  const RESERVE_MS = 10 * 60 * 1000;
  const [deadline, setDeadline] = useState(() => Date.now() + RESERVE_MS);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const remaining = Math.max(0, deadline - now);
  const rMins = Math.floor(remaining / 60000);
  const rSecs = Math.floor((remaining % 60000) / 1000);
  const expired = remaining === 0;
  const extendReservation = () => { setDeadline(Date.now() + RESERVE_MS); toast.success("Price locked for another 10 minutes"); };



  return (
    <Shell>
      <div className="border-b-[1.5px] border-[#0F0F0F] bg-card">
        <div className="container-page py-3 md:py-4">
          <Link to="/" className="inline-flex items-center gap-2 text-sm font-bold hover:text-coral">
            <ArrowLeft className="h-4 w-4" /> Back to plans
          </Link>
        </div>
      </div>

      {/* MOBILE — compact price header */}
      <div className="sticky top-0 z-30 border-b-[1.5px] border-[#0F0F0F] bg-cream/95 backdrop-blur lg:hidden">
        <div className="container-page flex items-center justify-between gap-3 py-2.5">
          <div className="min-w-0">
            <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{planData.name} · {planData.per}</div>
            <div className="font-display text-lg font-extrabold leading-none">₹{total.toLocaleString("en-IN")}</div>
          </div>
          {planData.amount > 0 && (
            <div className={`inline-flex items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] px-2 py-1 text-[11px] font-extrabold tabular-nums ${expired ? "bg-red-100 text-red-700" : "bg-gold/40"}`}>
              <Timer className="h-3 w-3" />
              {String(rMins).padStart(2, "0")}:{String(rSecs).padStart(2, "0")}
            </div>
          )}
        </div>
      </div>

      <section className="container-page pb-28 pt-4 md:py-10 lg:pb-10">
        <div className="grid min-w-0 gap-5 lg:grid-cols-[minmax(0,1fr)_400px] lg:gap-8">
          {/* LEFT — Payment methods */}
          <div className="space-y-4 md:space-y-6">
            <div className="hidden md:block">
              <span className="pill-badge bg-gold text-[#0F0F0F]">SECURE CHECKOUT</span>
              <h1 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Complete your payment</h1>
              <p className="mt-2 text-sm text-muted-foreground md:text-base">All payment methods available in India — UPI, cards, net banking &amp; wallets.</p>
            </div>


            {/* Gateway switcher */}
            <div className="card-editorial p-4 sm:p-5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Payment gateway</div>
              <div className="mt-2.5 grid grid-cols-3 gap-2 sm:gap-3">
                {(["razorpay", "stripe", "cashfree"] as const).map((g) => (
                  <button key={g} onClick={() => setGateway(g)} className={`rounded-lg border-[1.5px] border-[#0F0F0F] px-2 py-2.5 text-xs font-bold capitalize transition sm:py-3 sm:text-sm ${gateway === g ? "bg-[#0F0F0F] text-white shadow-[3px_3px_0_0_#E8623A]" : "bg-white hover:bg-cream"}`}>
                    {g}
                  </button>
                ))}
              </div>
            </div>

            {/* Method tabs */}
            <div className="card-editorial p-4 sm:p-5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Payment method</div>
              <div className="mt-2.5 grid grid-cols-5 gap-1.5 sm:gap-2">
                {([
                  { id: "upi", icon: Smartphone, label: "UPI" },
                  { id: "card", icon: CreditCard, label: "Card" },
                  { id: "netbanking", icon: Building2, label: "Bank" },
                  { id: "wallet", icon: Wallet, label: "Wallet" },
                  { id: "qr", icon: QrCode, label: "QR" },
                ] as const).map((m) => (
                  <button key={m.id} onClick={() => setMethod(m.id)} className={`flex flex-col items-center gap-1 rounded-lg border-[1.5px] border-[#0F0F0F] px-1 py-2.5 text-[10px] font-bold transition sm:py-3 sm:text-xs ${method === m.id ? "bg-coral text-white shadow-[3px_3px_0_0_#0F0F0F]" : "bg-white hover:bg-cream"}`}>
                    <m.icon className="h-4 w-4 sm:h-5 sm:w-5" /> {m.label}
                  </button>
                ))}
              </div>


              <div className="mt-5 sm:mt-6">
                {method === "upi" && (
                  <div className="space-y-4">
                    <div className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-cream px-3 py-2 text-[11px] sm:text-xs">
                      Paying to <b>{PAYEE_NAME}</b> · <span className="font-mono font-bold">{PAYEE_UPI_ID}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
                      {UPI_APPS.map((a) => (
                        <a
                          key={a.id}
                          href={upiIntent({ amount: total, note: `VibeCode ${plan}`, ref: `${plan}-${Date.now()}` })}
                          onClick={() => setSelectedUpiApp(a.id)}
                          className={`flex flex-col items-center gap-1.5 rounded-lg border-[1.5px] border-[#0F0F0F] p-2 text-[10px] font-bold leading-tight transition sm:p-3 sm:text-[11px] ${selectedUpiApp === a.id ? "bg-cream shadow-[3px_3px_0_0_#0F0F0F]" : "bg-white hover:bg-cream"}`}
                        >
                          <span className="flex h-9 w-full items-center justify-center rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-1.5 py-1 sm:h-12 sm:px-3 sm:py-1.5">
                            <PaymentBrand slug={a.slug} color={a.color} alt={a.name} className="h-full w-full object-contain" />
                          </span>
                          <span className="truncate">{a.name}</span>
                        </a>
                      ))}
                    </div>
                    <div className="text-center text-[10px] font-bold text-muted-foreground sm:text-xs">— OR ENTER UPI ID FOR A COLLECT REQUEST —</div>

                    <div>
                      <label className="text-xs font-bold uppercase tracking-wider">Your UPI ID</label>
                      <input value={upiId} onChange={(e) => { setUpiId(e.target.value); setSelectedUpiApp(null); }} placeholder="yourname@okhdfc" className="mt-1.5 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                      <p className="mt-1.5 text-xs text-muted-foreground">A collect request from <b>{PAYEE_UPI_ID}</b> will appear in your UPI app.</p>
                    </div>
                  </div>
                )}

                {method === "card" && (
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="sm:col-span-2">
                      <label className="text-xs font-bold uppercase tracking-wider">Card number</label>
                      <input value={card.number} onChange={(e) => setCard({ ...card, number: e.target.value.replace(/[^\d ]/g, "").slice(0, 19) })} placeholder="1234 5678 9012 3456" className="mt-1.5 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="text-xs font-bold uppercase tracking-wider">Name on card</label>
                      <input value={card.name} onChange={(e) => setCard({ ...card, name: e.target.value })} placeholder="As printed on card" className="mt-1.5 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                    </div>
                    <div>
                      <label className="text-xs font-bold uppercase tracking-wider">Expiry</label>
                      <input value={card.exp} onChange={(e) => setCard({ ...card, exp: e.target.value.replace(/[^\d/]/g, "").slice(0, 5) })} placeholder="MM/YY" className="mt-1.5 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                    </div>
                    <div>
                      <label className="text-xs font-bold uppercase tracking-wider">CVV</label>
                      <input value={card.cvv} onChange={(e) => setCard({ ...card, cvv: e.target.value.replace(/\D/g, "").slice(0, 4) })} placeholder="123" type="password" className="mt-1.5 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]" />
                    </div>
                    <div className="sm:col-span-2 flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-3 sm:gap-4 sm:px-4">
                      <span className="w-full text-[11px] font-bold uppercase tracking-wider text-muted-foreground sm:w-auto">Accepted:</span>
                      <PaymentBrand slug="visa" alt="Visa" className="h-6 w-auto sm:h-7" />
                      <PaymentBrand slug="mastercard" alt="Mastercard" className="h-6 w-auto sm:h-7" />
                      <PaymentBrand slug="americanexpress" alt="American Express" className="h-6 w-auto sm:h-7" />
                      <PaymentBrand slug="dinersclub" alt="Diners Club" className="h-6 w-auto sm:h-7" />
                      <span className="rounded border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] px-2 py-1 text-[10px] font-extrabold tracking-wider text-white sm:text-[11px]">RuPay</span>
                    </div>
                    <p className="sm:col-span-2 text-xs text-muted-foreground">Visa, Mastercard, RuPay, Amex &amp; Diners supported. Secured by 256-bit encryption.</p>
                  </div>
                )}

                {method === "netbanking" && (
                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider">Select your bank</label>
                    <select value={bank} onChange={(e) => setBank(e.target.value)} className="mt-1.5 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2.5 text-sm focus:outline-none focus:shadow-[3px_3px_0_0_#E8623A]">
                      {BANKS.map((b) => <option key={b}>{b}</option>)}
                    </select>
                    <p className="mt-2 text-xs text-muted-foreground">You'll be redirected to your bank's secure login.</p>
                  </div>
                )}

                {method === "wallet" && (
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-2">
                    {WALLETS.map((w) => (
                      <button key={w.id} onClick={() => setWallet(w.id)} className={`flex items-center justify-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] px-4 py-4 text-xs font-bold transition ${wallet === w.id ? "bg-cream shadow-[3px_3px_0_0_#0F0F0F]" : "bg-white hover:bg-cream"}`}>
                        <span className="flex h-10 w-full items-center justify-center">
                          <PaymentBrand slug={w.slug} alt={w.name} className="h-10 w-auto max-w-full object-contain" />
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {method === "qr" && (
                  <div className="flex flex-col items-center gap-3 py-4">
                    <img
                      src={upiQrUrl({ amount: total, note: `VibeCode ${plan}`, ref: `${plan}-${Date.now()}`, size: 260 })}
                      alt={`Scan to pay ₹${total} to ${PAYEE_UPI_ID}`}
                      className="h-56 w-56 rounded-md border-[1.5px] border-[#0F0F0F] bg-white p-2"
                    />
                    <p className="text-sm font-bold">Scan with any UPI app</p>
                    <p className="text-xs text-muted-foreground"><span className="font-mono font-bold">{PAYEE_UPI_ID}</span> · ₹{total.toLocaleString("en-IN")}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><Lock className="h-3.5 w-3.5" /> 256-bit SSL</span>
              <span className="inline-flex items-center gap-1.5"><Shield className="h-3.5 w-3.5" /> PCI DSS compliant</span>
              <span className="inline-flex items-center gap-1.5"><Sparkles className="h-3.5 w-3.5" /> RBI-regulated</span>
            </div>
          </div>

          {/* RIGHT — Order summary */}
          <aside className="min-w-0 lg:sticky lg:top-24 lg:self-start">
            <div className="card-editorial w-full max-w-full overflow-hidden p-4 sm:p-5 md:p-6">
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 sm:flex sm:flex-wrap sm:justify-between">
                <div className="min-w-0">
                  <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Your plan</div>
                  <div className="mt-1 truncate font-display text-2xl font-extrabold">{planData.name}</div>
                </div>
                {planData.popular && <span className="pill-badge shrink-0 bg-coral text-white">POPULAR</span>}
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{planData.desc}</p>

              {/* Reservation timer */}
              {planData.amount > 0 && (
                <div className={`mt-4 rounded-lg border-[1.5px] border-[#0F0F0F] p-3 ${expired ? "bg-red-50" : "bg-gold/20"}`}>
                  <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
                    <div className="flex min-w-0 items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider">
                      <Timer className={`h-3.5 w-3.5 ${expired ? "text-red-600" : "text-coral"}`} />
                      <span className="truncate">{expired ? "Price reservation expired" : "Price locked for"}</span>
                    </div>
                    <span className="shrink-0 font-mono text-sm font-extrabold tabular-nums">
                      {String(rMins).padStart(2, "0")}:{String(rSecs).padStart(2, "0")}
                    </span>
                  </div>
                  <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full border-[1.5px] border-[#0F0F0F] bg-white">
                    <div className={`h-full ${expired ? "bg-red-500" : "bg-coral"}`} style={{ width: `${(remaining / RESERVE_MS) * 100}%`, transition: "width 1s linear" }} />
                  </div>
                  {expired && (
                    <button onClick={extendReservation} className="mt-2 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-white py-1.5 text-xs font-bold hover:bg-cream">
                      Extend reservation
                    </button>
                  )}
                </div>
              )}

              <ul className="mt-4 space-y-2">
                {planData.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-coral" /> {f}
                  </li>
                ))}
              </ul>

              <div className="mt-5 border-t-[1.5px] border-dashed border-[#0F0F0F]/30 pt-4">
                <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-2">
                  <input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="Coupon code" className="min-w-0 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-sm focus:outline-none" />
                  <button onClick={applyCoupon} className="shrink-0 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-sm font-bold hover:bg-cream">Apply</button>
                </div>
                <p className="mt-1.5 text-[11px] text-muted-foreground">Try <b>VIBE10</b> or <b>INDIA50</b></p>
              </div>

              <div className="mt-4 space-y-1.5 text-sm">
                <Row label={`${planData.name} · ${planData.per}`} value={`₹${planData.amount.toLocaleString("en-IN")}`} />
                {discount > 0 && <Row label="Discount" value={`− ₹${discount.toLocaleString("en-IN")}`} accent />}
                <Row label="GST (18%)" value={`₹${gst.toLocaleString("en-IN")}`} />
                <div className="my-2 border-t-[1.5px] border-[#0F0F0F]" />
                <Row label="Total" value={`₹${total.toLocaleString("en-IN")}`} bold />
              </div>

              <button onClick={expired && planData.amount > 0 ? extendReservation : pay} className="btn-coral mt-5 w-full justify-center text-center">
                {expired && planData.amount > 0 ? <>Extend & Pay ₹{total.toLocaleString("en-IN")}</> : <>Pay ₹{total.toLocaleString("en-IN")} securely</>}
              </button>
              <p className="mt-3 text-center text-[11px] text-muted-foreground">By paying, you agree to our Terms & Refund policy. Cancel anytime.</p>
            </div>
          </aside>
        </div>
      </section>

      {/* MOBILE — sticky bottom pay bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t-[1.5px] border-[#0F0F0F] bg-cream/95 backdrop-blur lg:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="container-page flex items-center gap-3 py-2.5">
          <div className="min-w-0 flex-1">
            <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Total payable</div>
            <div className="font-display text-xl font-extrabold leading-none">₹{total.toLocaleString("en-IN")}</div>
          </div>
          <button onClick={expired && planData.amount > 0 ? extendReservation : pay} className="btn-coral shrink-0 px-5 py-3 text-sm">
            {expired && planData.amount > 0 ? "Extend & Pay →" : "Pay securely →"}
          </button>
        </div>
      </div>


      <PaymentOTPModal
        open={otpOpen}
        onOpenChange={setOtpOpen}
        amount={total}
        purpose={`plan:${plan}`}
        reference={`${gateway}-${plan}-${Date.now()}`}
        method={method.toUpperCase()}
        onVerified={onVerified}
      />
    </Shell>
  );
}

function Row({ label, value, bold, accent }: { label: string; value: string; bold?: boolean; accent?: boolean }) {
  return (
    <div className={`grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-3 ${bold ? "font-display text-lg font-extrabold" : ""} ${accent ? "text-coral" : ""}`}>
      <span className="min-w-0 break-words">{label}</span><span className="shrink-0 whitespace-nowrap text-right">{value}</span>
    </div>
  );
}
