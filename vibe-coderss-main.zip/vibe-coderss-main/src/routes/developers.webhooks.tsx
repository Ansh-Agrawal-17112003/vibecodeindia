import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/developers/webhooks")({
  head: () => ({
    meta: [
      { title: "Webhooks · VibeCode" },
      { name: "description", content: "Get notified the moment something happens on the platform — new posts, DMs, job matches, XP levels." },
      { property: "og:title", content: "Webhooks · VibeCode" },
      { property: "og:description", content: "Get notified the moment something happens on the platform — new posts, DMs, job matches, XP levels." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/developers/webhooks" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/developers/webhooks" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Webhooks"
      breadcrumb={[{"label":"Developers","to":"/"}]}
      title="Realtime event streams."
      intro="Get notified the moment something happens on the platform — new posts, DMs, job matches, XP levels."
      toc={[{"id":"events","label":"Available events"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="events" title="Available events"><NotionFeatureGrid items={[{"title":"post.created","description":"Fires when a new post lands on the Vibe Feed."},{"title":"job.matched","description":"Fires when a role matches your saved filters."},{"title":"dm.received","description":"Fires when a builder DMs you."},{"title":"xp.level_up","description":"Fires when you gain a new level or badge."}]} /></NotionSection>
      <NotionCallout emoji="🔒" tone="cream">Every payload is HMAC-signed with your webhook secret. Verify before processing.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Do you retry failed deliveries?" a="Yes — exponential backoff up to 24 hours." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
