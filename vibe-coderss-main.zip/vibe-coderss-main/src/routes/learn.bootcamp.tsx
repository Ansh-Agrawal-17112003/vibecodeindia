import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/learn/bootcamp")({
  head: () => ({
    meta: [
      { title: "Vibe Coding Bootcamp · VibeCode" },
      { name: "description", content: "An intensive live cohort for builders who want to go from tinkerer to shipping AI engineer — with a job at the end." },
      { property: "og:title", content: "Vibe Coding Bootcamp · VibeCode" },
      { property: "og:description", content: "An intensive live cohort for builders who want to go from tinkerer to shipping AI engineer — with a job at the end." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/learn/bootcamp" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/learn/bootcamp" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Vibe Coding Bootcamp"
      breadcrumb={[{"label":"Learn","to":"/"}]}
      title="12 weeks. Real projects. Real jobs."
      intro="An intensive live cohort for builders who want to go from tinkerer to shipping AI engineer — with a job at the end."
      toc={[{"id":"curriculum","label":"Curriculum"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="curriculum" title="Curriculum"><NotionFeatureGrid items={[{"title":"Weeks 1-3: Foundations","description":"LLMs, prompting, function calling, agents."},{"title":"Weeks 4-6: Retrieval","description":"RAG, embeddings, vector stores, eval."},{"title":"Weeks 7-9: Production","description":"Latency, cost, guardrails, observability."},{"title":"Weeks 10-12: Ship + hire","description":"Capstone project + interview prep + intros."}]} /></NotionSection>
      <NotionCallout emoji="🎓" tone="coral">Cohorts every quarter. 40 seats. Job guarantee for the top 50% of graduates.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="How much does it cost?" a="Income-share option (0 upfront) or one-time fee. Full pricing on the enrollment page." />
          <NotionToggle q="Is it remote?" a="Yes — live sessions IST evenings, recorded for async catch-up." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
