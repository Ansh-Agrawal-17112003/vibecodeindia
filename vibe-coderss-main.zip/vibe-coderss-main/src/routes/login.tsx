import { createFileRoute, Link } from "@tanstack/react-router";
import { Github } from "lucide-react";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Log In · VibeCode" }] }),
  component: LoginPage,
});

function LoginPage() {
  return (
    <div className="grid min-h-screen place-items-center px-6">
      <div className="w-full max-w-sm">
        <Link to="/" className="mb-8 flex items-center justify-center gap-2">
          <div className="h-7 w-7 rounded-md bg-gradient-to-br from-primary to-[#8b5cf6]" />
          <span className="font-display text-lg font-semibold">vibecode</span>
        </Link>
        <div className="card-surface p-6">
          <h1 className="text-xl font-semibold">Welcome back</h1>
          <p className="mt-1 text-sm text-muted-foreground">Log in to your VibeCode account.</p>
          <div className="mt-6 space-y-2">
            <button className="flex w-full items-center justify-center gap-2 rounded-md border border-border bg-surface px-3 py-2 text-sm hover:border-[#333]">
              <span className="h-4 w-4 rounded-sm bg-foreground" /> Continue with Google
            </button>
            <button className="flex w-full items-center justify-center gap-2 rounded-md border border-border bg-surface px-3 py-2 text-sm hover:border-[#333]">
              <Github className="h-4 w-4" /> Continue with GitHub
            </button>
          </div>
          <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><div className="h-px flex-1 bg-border" /> OR <div className="h-px flex-1 bg-border" /></div>
          <div className="space-y-3">
            <input type="email" placeholder="Email" className="h-10 w-full rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary" />
            <input type="password" placeholder="Password" className="h-10 w-full rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary" />
            <button className="w-full rounded-md bg-primary py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary-hover">Log in</button>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs">
            <Link to="/" className="text-muted-foreground hover:text-foreground">Forgot password?</Link>
            <Link to="/signup" className="text-primary hover:underline">Create account</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
