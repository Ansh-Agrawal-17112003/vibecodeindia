import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useState, useMemo } from "react";
import { Shell } from "@/components/site/Shell";
import { PromptCard } from "@/components/cards/PromptCard";
import { AutocompleteInput } from "@/components/site/AutocompleteInput";
import { StatsStrip } from "@/components/site/StatsStrip";
import { prompts as mockPrompts } from "@/lib/mock-data";
import { useLiveTable, mapPrompt } from "@/lib/entity-live";

export const Route = createFileRoute("/prompts")({
  head: () => ({
    meta: [
      { title: 'Prompt Library · VibeCode' },
      { name: "description", content: "8,000+ battle-tested prompts for Claude, GPT, Gemini and more — shared by India's top AI builders." },
      { property: "og:title", content: 'Prompt Library · VibeCode' },
      { property: "og:description", content: "8,000+ battle-tested prompts for Claude, GPT, Gemini and more — shared by India's top AI builders." },
      { property: "og:url", content: 'https://joinvibecode.xyz/prompts' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Prompt Library · VibeCode' },
      { name: "twitter:description", content: "8,000+ battle-tested prompts for Claude, GPT, Gemini and more — shared by India's top AI builders." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/prompts' }],
  }),
  component: PromptsPage,
});

const categories = ["All", "Marketing", "Engineering", "Automation", "Startup", "Research", "Support"];

function PromptsPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const dbRows = useLiveTable("prompts", mapPrompt);
  const prompts = useMemo(() => {
    const seen = new Set(dbRows.map((p) => p.id));
    return [...dbRows, ...mockPrompts.filter((p) => !seen.has(p.id))];
  }, [dbRows]);
  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return prompts.filter((p) =>
      (cat === "All" || p.category === cat) &&
      (!t || p.title.toLowerCase().includes(t) || p.preview.toLowerCase().includes(t) || p.model.toLowerCase().includes(t))
    );
  }, [q, cat, prompts]);

  return (
    <Shell>
      <div className="container-page py-5 sm:py-8">
        <div className="mb-6 text-center sm:mb-8 sm:text-left">
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground sm:text-xs">Library</div>
          <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight sm:text-3xl md:text-4xl">Prompt Library</h1>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">{filtered.length} battle-tested prompts shared by the community. Copy and ship.</p>
        </div>
        <div className="hidden sm:block">
          <StatsStrip items={[
            { label: "Prompts", value: prompts.length },
            { label: "Categories", value: categories.length - 1 },
            { label: "Copies", value: 47800, suffix: "+" },
            { label: "Avg Rating", value: 5, prefix: "4." },
          ]} />
        </div>
        <div className="card-flat mb-5 flex items-center gap-3 p-2 pl-4">
          <Search className="h-4 w-4 text-muted-foreground" />
          <AutocompleteInput
            value={q}
            onChange={setQ}
            placeholder="Search prompts..."
            typewriter={["Cold email that converts...", "GPT-4 system prompt...", "Landing page copy...", "Bug-fix prompt for Claude...", "Startup pitch generator..."]}
            suggestions={prompts.flatMap((p) => [p.title, p.category, p.model])}
          />
        </div>
        <div className="mb-6 hidden flex-wrap gap-2 sm:flex">
          {categories.map((c) => (
            <button key={c} onClick={() => setCat(c)} className={`rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1 text-xs font-bold transition ${cat === c ? "bg-coral text-white" : "bg-card text-foreground hover:bg-coral hover:text-white"}`} style={cat === c ? { boxShadow: "2px 2px 0 0 #0F0F0F" } : undefined}>{c}</button>
          ))}
        </div>

        {filtered.length ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{filtered.map((p) => <PromptCard key={p.id} p={p} />)}</div>
        ) : <div className="card-editorial p-12 text-center text-sm text-muted-foreground">No prompts match.</div>}
      </div>
    </Shell>
  );
}
