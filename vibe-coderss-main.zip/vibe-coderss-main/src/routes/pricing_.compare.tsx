import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/pricing_/compare")({
  head: () => ({
    meta: [
      { title: "Compare Plans · VibeCode" },
      { name: "description", content: "A quick, honest comparison. Pick the plan that matches how you actually use VibeCode." },
      { property: "og:title", content: "Compare Plans · VibeCode" },
      { property: "og:description", content: "A quick, honest comparison. Pick the plan that matches how you actually use VibeCode." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/pricing/compare" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/pricing/compare" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Compare Plans"
      breadcrumb={[{"label":"Pricing","to":"/pricing"}]}
      title="See it side by side."
      intro="A quick, honest comparison. Pick the plan that matches how you actually use VibeCode."
      toc={[]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      
<div className="overflow-hidden rounded-xl border-[1.5px] border-[#0F0F0F] bg-white">
  <table className="w-full text-sm">
    <thead className="bg-cream text-left">
      <tr>
        <th className="p-4 font-display">Feature</th>
        <th className="p-4 font-display">Builder</th>
        <th className="p-4 font-display">Pro</th>
        <th className="p-4 font-display">Business</th>
        <th className="p-4 font-display">Enterprise</th>
      </tr>
    </thead>
    <tbody className="[&>tr]:border-t [&>tr]:border-[#0F0F0F]/10">
      {[
        ["Vibe Feed posts","Unlimited","Unlimited","Unlimited","Unlimited"],
        ["Job applications","Unlimited","Unlimited","—","—"],
        ["Search visibility","Standard","Top of search","Top of search","Top of search"],
        ["Verified badge","—","✓","✓","✓"],
        ["Featured job posts","—","—","✓","✓"],
        ["Team seats","1","1","3","Custom"],
        ["Saved candidate pools","—","—","✓","✓"],
        ["Dedicated CSM","—","—","—","✓"],
        ["SSO + audit logs","—","—","—","✓"],
        ["Price","₹0","₹499/mo","₹2,999/mo","Custom"],
      ].map((row,i) => (
        <tr key={i}>
          {row.map((c,j)=>(<td key={j} className="p-4 text-foreground/85">{c}</td>))}
        </tr>
      ))}
    </tbody>
  </table>
</div>
      <NotionCallout emoji="⚖️" tone="cream">Not sure? Start free. Every paid plan can be trialed for 7 days, no card required.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Can I downgrade later?" a="Yes — anytime. No lock-in, no exit fees, no surprise charges." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
