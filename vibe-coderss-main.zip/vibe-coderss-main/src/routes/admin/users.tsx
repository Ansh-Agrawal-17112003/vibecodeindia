import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, MoreVertical, Download, UserPlus, RefreshCw } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { AdminPage, AdminCard, TableWrap, TH, TD, RolePill, Input, Select, Pill, BtnCoral, BtnGhost, EmptyState } from "@/components/admin/AdminUI";
import { useAuth } from "@/hooks/useAuth";
import { listAdminUsers } from "@/lib/admin-stats.functions";
import { useAdminRealtime } from "@/hooks/useAdminRealtime";

export const Route = createFileRoute("/admin/users")({
  head: () => ({ meta: [{ title: "User Management · VibeCode Admin" }] }),
  component: UsersPage,
});

const PAGE_SIZE = 25;

function UsersPage() {
  useAdminRealtime();
  const { isSuperAdmin } = useAuth();
  const [search, setSearch] = useState("");
  const [role, setRole] = useState<"all" | "super_admin" | "admin" | "user">("all");
  const [page, setPage] = useState(1);

  const fetchUsers = useServerFn(listAdminUsers);
  const { data, isLoading, isFetching, refetch, error } = useQuery({
    queryKey: ["admin", "users"],
    queryFn: () => fetchUsers({ data: { limit: 200 } }),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const all = data?.rows ?? [];
  const filtered = useMemo(() => all.filter((u) =>
    (!search || u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase())) &&
    (role === "all" || u.role === role)
  ), [all, search, role]);
  const total = filtered.length;
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const rows = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const stats = {
    total: all.length,
    admins: all.filter((u) => u.role === "admin" || u.role === "super_admin").length,
    superAdmins: all.filter((u) => u.role === "super_admin").length,
    earlyAccess: all.filter((u) => (u as any).is_early_access).length,
  };

  return (
    <AdminPage
      title="User Management"
      subtitle={isLoading ? "Loading live users…" : `${stats.total.toLocaleString("en-IN")} confirmed users · live from database`}
      actions={
        <>
          <button onClick={() => refetch()} className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[12px] font-bold text-foreground hover:bg-surface sm:text-[13px]">
            <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} /> Refresh
          </button>
          <BtnGhost><Download className="h-3.5 w-3.5" /> Export</BtnGhost>
          <BtnCoral><UserPlus className="h-3.5 w-3.5" /> Invite</BtnCoral>
        </>
      }
    >
      {error && (
        <div className="mb-4 rounded-md border border-[#EF4444]/40 bg-[#EF4444]/10 px-3 py-2 text-[13px] font-bold text-[#F87171]">
          Couldn't load users: {(error as Error).message}
        </div>
      )}

      <div className="mb-5 flex flex-wrap gap-2">
        <Pill>Total: <span className="ml-1 font-extrabold text-foreground">{stats.total}</span></Pill>
        <Pill tone="coral">Admins: <span className="ml-1 font-extrabold text-coral">{stats.admins}</span></Pill>
        <Pill tone="gold">Super Admins: <span className="ml-1 font-extrabold text-[#F5A623]">{stats.superAdmins}</span></Pill>
        <Pill tone="gold">🌱 Early Access: <span className="ml-1 font-extrabold text-[#B87400]">{stats.earlyAccess}</span></Pill>
      </div>

      <AdminCard className="mb-4 p-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
          <div className="relative w-full min-w-0 flex-1 sm:min-w-[240px]">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Search by name or email…" className="w-full pl-9" />
          </div>
          <Select value={role} onChange={(e) => { setRole(e.target.value as any); setPage(1); }} className="w-full sm:w-auto">
            <option value="all">All roles</option>
            <option value="super_admin">Super Admin</option>
            <option value="admin">Admin</option>
            <option value="user">User</option>
          </Select>
        </div>
      </AdminCard>

      {isLoading ? (
        <EmptyState title="Loading users…" description="Fetching live data from the database." />
      ) : rows.length === 0 ? (
        <EmptyState title="No users match your filters" description="Try changing search terms or filters." />
      ) : (
        <TableWrap>
          <thead>
            <tr>
              <TH>User</TH><TH>Role</TH><TH>Joined</TH><TH>Last Sign In</TH><TH>Followers</TH><TH>XP</TH><TH className="text-right">Actions</TH>
            </tr>
          </thead>
          <tbody>
            {rows.map((u) => (
              <tr key={u.id} className="hover:bg-surface">
                <TD>
                  <div className="flex items-center gap-3">
                    <img src={u.avatar_url ?? `https://api.dicebear.com/7.x/notionists/svg?seed=${u.id}`} className="h-9 w-9 rounded-full border border-white/10 bg-white/5" alt="" />
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-semibold text-foreground">{u.name}</span>
                        {(u as any).is_early_access && (
                          <span
                            title="Signed up during early access — will convert to a full user when they log in on launch day"
                            className="inline-flex items-center gap-1 rounded-full border border-[#F5A623]/60 bg-[#F5A623]/15 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-[#B87400]"
                          >
                            🌱 Early{typeof (u as any).og_number === "number" ? ` · OG#${(u as any).og_number}` : ""}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-muted-foreground">{u.email}</div>
                    </div>
                  </div>
                </TD>
                <TD><RolePill role={u.role} /></TD>
                <TD className="text-[12px] text-muted-foreground">{new Date(u.created_at).toLocaleDateString("en-IN")}</TD>
                <TD className="text-[12px] text-muted-foreground">{u.last_sign_in_at ? new Date(u.last_sign_in_at).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "—"}</TD>
                <TD className="font-semibold text-foreground">{u.followers}</TD>
                <TD className="font-semibold text-foreground">{u.xp}</TD>
                <TD className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger className="rounded-md border border-[#0F0F0F]/15 p-1.5 text-muted-foreground hover:bg-surface hover:text-foreground">
                      <MoreVertical className="h-4 w-4" />
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-52 border-[#0F0F0F]/15 bg-card text-foreground">
                      <DropdownMenuItem>👤 View Profile</DropdownMenuItem>
                      {isSuperAdmin && u.role !== "super_admin" && (
                        <>
                          <DropdownMenuSeparator />
                          {u.role === "user"
                            ? <DropdownMenuItem>🛡 Make Admin</DropdownMenuItem>
                            : <DropdownMenuItem>👤 Remove Admin</DropdownMenuItem>}
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TD>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}

      <div className="mt-4 flex items-center justify-between text-[12px] text-muted-foreground">
        <div>Showing {rows.length ? (page - 1) * PAGE_SIZE + 1 : 0}–{(page - 1) * PAGE_SIZE + rows.length} of {total.toLocaleString("en-IN")}</div>
        <div className="flex items-center gap-1">
          <button disabled={page === 1} onClick={() => setPage((p) => p - 1)} className="rounded-md border border-[#0F0F0F]/15 bg-card px-3 py-1.5 font-semibold text-foreground hover:bg-surface disabled:opacity-40">← Prev</button>
          <span className="px-3 py-1.5 font-semibold text-foreground">Page {page} / {pages}</span>
          <button disabled={page === pages} onClick={() => setPage((p) => p + 1)} className="rounded-md border border-[#0F0F0F]/15 bg-card px-3 py-1.5 font-semibold text-foreground hover:bg-surface disabled:opacity-40">Next →</button>
        </div>
      </div>
    </AdminPage>
  );
}
