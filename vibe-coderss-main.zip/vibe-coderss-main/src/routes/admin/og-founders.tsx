import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Crown, Search, CheckCircle2, XCircle, Clock, ExternalLink, RefreshCw, Mail } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin/og-founders")({
  component: OgFoundersAdmin,
});

type Row = {
  email: string;
  signed_up_at: string;
  has_account: boolean;
  user_id: string | null;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  is_og_founder: boolean;
  og_founder_until: string | null;
  plan: string;
  subscription_end: string | null;
  vibecoin_balance: number;
  last_login_date: string | null;
};

function OgFoundersAdmin() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [sendingApology, setSendingApology] = useState(false);
  const [sendingThankYou, setSendingThankYou] = useState(false);
  const [thankYouProgress, setThankYouProgress] = useState<{ done: number; total: number } | null>(null);

  const sendThankYouToAll = async () => {
    if (sendingThankYou) return;
    const targets = Array.from(
      new Map(
        rows
          .filter((r) => r.email && /@/.test(r.email))
          .map((r) => {
            const email = r.email.toLowerCase().trim();
            const firstName =
              (r.display_name || r.username || email.split("@")[0] || "there")
                .toString()
                .trim()
                .split(/\s+/)[0] || "there";
            return [email, { email, firstName }];
          }),
      ).values(),
    );
    if (targets.length === 0) {
      toast.error("No early-access users to email yet");
      return;
    }
    if (
      !confirm(
        `Send the VibeCoder thank-you email to ${targets.length} early-access user${targets.length === 1 ? "" : "s"}?\n\nSafe to re-run — each user only gets it once (idempotent).`,
      )
    )
      return;

    setSendingThankYou(true);
    setThankYouProgress({ done: 0, total: targets.length });
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("You must be signed in as an admin");

      let queued = 0;
      let skipped = 0;
      let failed = 0;

      // Sequential with tiny gap to be gentle on the queue processor.
      for (let i = 0; i < targets.length; i++) {
        const t = targets[i];
        try {
          const res = await fetch("/lovable/email/transactional/send", {
            method: "POST",
            headers: {
              "content-type": "application/json",
              authorization: `Bearer ${session.access_token}`,
            },
            body: JSON.stringify({
              templateName: "early-access-thankyou",
              recipientEmail: t.email,
              idempotencyKey: `ea-thankyou-v1-${t.email}`,
              templateData: {
                firstName: t.firstName,
                wallUrl: "https://www.joinvibecode.xyz/founders-wall",
                launchDate: "4 August 2026",
              },
            }),
          });
          const data = await res.json().catch(() => ({} as any));
          if (!res.ok) {
            failed++;
            console.warn("Thank-you send failed", t.email, data);
          } else if (data?.reason === "email_suppressed") {
            skipped++;
          } else {
            queued++;
          }
        } catch (e) {
          failed++;
          console.warn("Thank-you send crashed", t.email, e);
        }
        setThankYouProgress({ done: i + 1, total: targets.length });
        // Small delay so we don't slam the queue processor
        await new Promise((r) => setTimeout(r, 120));
      }

      toast.success(
        `Thank-you emails: ${queued} queued · ${skipped} skipped · ${failed} failed`,
      );
    } catch (e: any) {
      toast.error(e?.message || "Failed to send thank-you emails");
    } finally {
      setSendingThankYou(false);
      setThankYouProgress(null);
    }
  };

  const sendApologyToSuman = async () => {
    if (sendingApology) return;
    if (!confirm("Send apology email to Suman R (sumanrajpu357@gmail.com)?")) return;
    setSendingApology(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("You must be signed in as an admin");
      const res = await fetch("/lovable/email/transactional/send", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          templateName: "apology-og-restored",
          recipientEmail: "sumanrajpu357@gmail.com",
          idempotencyKey: "og-apology-suman-28-v1",
          templateData: {
            firstName: "Suman",
            ogNumber: 28,
            badgeUrl: "https://www.joinvibecode.xyz/founders-wall#og-28",
          },
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `Send failed (${res.status})`);
      toast.success("Apology email queued for Suman R 💛");
    } catch (e: any) {
      toast.error(e?.message || "Failed to send apology");
    } finally {
      setSendingApology(false);
    }
  };

  const load = async () => {
    setLoading(true);
    setErr(null);
    const { data, error } = await supabase.rpc("admin_list_early_access_readiness" as never);
    if (error) setErr(error.message);
    else setRows((data ?? []) as Row[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter(r =>
      r.email.toLowerCase().includes(s) ||
      (r.username ?? "").toLowerCase().includes(s) ||
      (r.display_name ?? "").toLowerCase().includes(s)
    );
  }, [rows, q]);

  const stats = useMemo(() => {
    const total = rows.length;
    const withAccount = rows.filter(r => r.has_account).length;
    const granted = rows.filter(r => r.is_og_founder).length;
    const pending = withAccount - granted;
    const noAccount = total - withAccount;
    return { total, withAccount, granted, pending, noAccount };
  }, [rows]);

  return (
    <div className="p-4 md:p-8">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="mb-1 inline-flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-gold px-3 py-1 text-[11px] font-extrabold uppercase tracking-wider text-[#0F0F0F]">
            <Crown className="h-3 w-3" /> Early Access · OG Founder Readiness
          </div>
          <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight md:text-4xl">
            OG Founders Check
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Every early-access signup, whether they have an account, and whether the OG plan/badge is live on their profile.
            Auto-grant activates when they sign in on/after <b>4 August 2026 (IST)</b>.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={sendThankYouToAll}
            disabled={sendingThankYou || loading || rows.length === 0}
            className="inline-flex h-10 items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-[#0F0F0F] px-3 text-[12px] font-extrabold text-white shadow-[2px_2px_0_0_#0F0F0F] hover:-translate-y-0.5 hover:shadow-[3px_3px_0_0_#0F0F0F] disabled:opacity-60"
            title="Send the VibeCoder thank-you email to every early-access user (idempotent)"
          >
            <Mail className="h-3.5 w-3.5" />
            {sendingThankYou
              ? `Sending… ${thankYouProgress?.done ?? 0}/${thankYouProgress?.total ?? 0}`
              : `Thank all ${rows.length} early users →`}
          </button>
          <button
            onClick={sendApologyToSuman}
            disabled={sendingApology}
            className="inline-flex h-10 items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-coral px-3 text-[12px] font-extrabold text-white shadow-[2px_2px_0_0_#0F0F0F] hover:-translate-y-0.5 hover:shadow-[3px_3px_0_0_#0F0F0F] disabled:opacity-60"
            title="Send apology + badge-view email to Suman R"
          >
            <Mail className="h-3.5 w-3.5" />
            {sendingApology ? "Sending…" : "Send apology → Suman R"}
          </button>
          <button onClick={load} className="inline-flex h-10 items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 text-[12px] font-extrabold shadow-[2px_2px_0_0_#0F0F0F] hover:-translate-y-0.5 hover:bg-cream hover:shadow-[3px_3px_0_0_#0F0F0F]">
            <RefreshCw className="h-3.5 w-3.5" /> Refresh
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-5">
        {[
          { l: "Total signups", v: stats.total, c: "bg-white" },
          { l: "Have account", v: stats.withAccount, c: "bg-white" },
          { l: "OG active", v: stats.granted, c: "bg-gold" },
          { l: "Pending (needs login)", v: stats.pending, c: "bg-cream" },
          { l: "No account yet", v: stats.noAccount, c: "bg-cream" },
        ].map((s) => (
          <div key={s.l} className={`rounded-xl border-[1.5px] border-[#0F0F0F] ${s.c} p-4 shadow-[3px_3px_0_0_#0F0F0F]`}>
            <div className="text-[11px] font-extrabold uppercase tracking-wider text-muted-foreground">{s.l}</div>
            <div className="mt-1 font-display text-3xl font-extrabold text-[#0F0F0F]">{s.v}</div>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="mb-4 flex items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 shadow-[2px_2px_0_0_#0F0F0F]">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search email, username, name..."
          className="w-full bg-transparent text-sm outline-none"
        />
      </div>

      {err && (
        <div className="mb-4 rounded-lg border-[1.5px] border-red-500 bg-red-50 p-3 text-sm text-red-700">
          {err}
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto rounded-xl border-[1.5px] border-[#0F0F0F] bg-white shadow-[4px_4px_0_0_#0F0F0F]">
        <table className="w-full min-w-[900px] text-sm">
          <thead className="bg-cream text-left text-[11px] font-extrabold uppercase tracking-wider text-[#0F0F0F]">
            <tr>
              <th className="px-3 py-3">User</th>
              <th className="px-3 py-3">Account</th>
              <th className="px-3 py-3">OG Status</th>
              <th className="px-3 py-3">Plan</th>
              <th className="px-3 py-3">Coins</th>
              <th className="px-3 py-3">Signed up</th>
              <th className="px-3 py-3">Profile</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="px-3 py-10 text-center text-muted-foreground">Loading…</td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={7} className="px-3 py-10 text-center text-muted-foreground">No signups match.</td></tr>
            ) : (
              filtered.map((r) => (
                <tr key={r.email} className="border-t border-[#0F0F0F]/10">
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-2">
                      <img
                        src={r.avatar_url ?? `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(r.email)}`}
                        alt=""
                        className="h-8 w-8 rounded-full border border-[#0F0F0F]/20 bg-cream"
                      />
                      <div className="min-w-0">
                        <div className="truncate font-bold text-[#0F0F0F]">{r.display_name ?? r.username ?? "—"}</div>
                        <div className="truncate text-[11px] text-muted-foreground">{r.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-3">
                    {r.has_account ? (
                      <span className="inline-flex items-center gap-1 rounded-full border border-green-600 bg-green-50 px-2 py-0.5 text-[11px] font-bold text-green-700">
                        <CheckCircle2 className="h-3 w-3" /> Yes
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-full border border-[#0F0F0F]/30 bg-cream px-2 py-0.5 text-[11px] font-bold text-muted-foreground">
                        <XCircle className="h-3 w-3" /> Not yet
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-3">
                    {r.is_og_founder ? (
                      <span className="inline-flex items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-gold px-2 py-0.5 text-[11px] font-extrabold text-[#0F0F0F]">
                        <Crown className="h-3 w-3" /> OG Active
                      </span>
                    ) : r.has_account ? (
                      <span className="inline-flex items-center gap-1 rounded-full border border-amber-600 bg-amber-50 px-2 py-0.5 text-[11px] font-bold text-amber-700">
                        <Clock className="h-3 w-3" /> Waiting for login
                      </span>
                    ) : (
                      <span className="text-[11px] text-muted-foreground">—</span>
                    )}
                    {r.og_founder_until && (
                      <div className="mt-0.5 text-[10px] text-muted-foreground">
                        until {new Date(r.og_founder_until).toLocaleDateString()}
                      </div>
                    )}
                  </td>
                  <td className="px-3 py-3">
                    <span className={`rounded-md border px-2 py-0.5 text-[11px] font-bold ${r.plan === "pro" ? "border-coral bg-coral/10 text-coral" : "border-[#0F0F0F]/20 bg-cream text-muted-foreground"}`}>
                      {r.plan}
                    </span>
                    {r.subscription_end && (
                      <div className="mt-0.5 text-[10px] text-muted-foreground">
                        ends {new Date(r.subscription_end).toLocaleDateString()}
                      </div>
                    )}
                  </td>
                  <td className="px-3 py-3 font-bold">{r.vibecoin_balance}</td>
                  <td className="px-3 py-3 text-[11px] text-muted-foreground">
                    {new Date(r.signed_up_at).toLocaleDateString()}
                  </td>
                  <td className="px-3 py-3">
                    {r.username ? (
                      <Link
                        to="/u/$username"
                        params={{ username: r.username }}
                        target="_blank"
                        className="inline-flex items-center gap-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2 py-1 text-[11px] font-bold shadow-[2px_2px_0_0_#0F0F0F] hover:-translate-y-0.5 hover:bg-gold"
                      >
                        View <ExternalLink className="h-3 w-3" />
                      </Link>
                    ) : (
                      <span className="text-[11px] text-muted-foreground">no handle</span>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <p className="mt-4 text-[11px] text-muted-foreground">
        <b>Waiting for login</b> means the user has an account but hasn't signed in on/after 4 Aug 2026 yet — the OG plan, golden badge, 500 VibeCoins and welcome popup fire the first time they log in that day.
      </p>
    </div>
  );
}
