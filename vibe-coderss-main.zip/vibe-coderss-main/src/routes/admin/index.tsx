import { createFileRoute, Link } from "@tanstack/react-router";
import { Users, TrendingUp, Home, Briefcase, FolderKanban, Sparkles, AlertTriangle, Shield, CreditCard, RefreshCw, Award, Crown } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { AdminPage, AdminCard, StatCard, RolePill } from "@/components/admin/AdminUI";
import { getDashboardStats } from "@/lib/admin-stats.functions";
import { useAdminRealtime } from "@/hooks/useAdminRealtime";

export const Route = createFileRoute("/admin/")({
  head: () => ({ meta: [{ title: "Dashboard · VibeCode Admin" }] }),
  component: DashboardPage,
});

function DashboardPage() {
  useAdminRealtime();
  const fetchStats = useServerFn(getDashboardStats);
  const { data, isLoading, isFetching, refetch, error } = useQuery({
    queryKey: ["admin", "dashboard-stats"],
    queryFn: () => fetchStats(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const s = data?.stats;
  const ogStats = data?.ogStats;
  const ogMembers = data?.ogMembers ?? [];
  const growth = data?.growth ?? [];
  const signups = data?.recentSignups ?? [];

  return (
    <AdminPage
      title="Dashboard"
      subtitle="Live overview of platform health · pulled from the database"
      actions={
        <button
          onClick={() => refetch()}
          className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-[12px] font-extrabold text-foreground shadow-[2px_2px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:shadow-[3px_3px_0_0_#0F0F0F] sm:h-10 sm:px-3.5 sm:text-[13px]"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} /> Refresh
        </button>
      }
    >
      {error && (
        <div className="mb-4 rounded-lg border-[1.5px] border-[#0F0F0F] bg-[#FEE2E2] px-4 py-3 text-[13px] font-bold text-[#B91C1C] shadow-[3px_3px_0_0_#0F0F0F]">
          Couldn't load live stats: {(error as Error).message}
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={<Users className="h-4 w-4" />} label="Total Users" value={s?.totalUsers ?? (isLoading ? "…" : 0)} delta={s ? `+${s.newUsersToday} today` : undefined} />
        <StatCard icon={<TrendingUp className="h-4 w-4" />} label="New This Week" value={s?.newUsersWeek ?? (isLoading ? "…" : 0)} delta={s ? `+${s.newUsersToday} in last 24h` : undefined} />
        <StatCard icon={<Home className="h-4 w-4" />} label="Communities" value={s?.communities ?? (isLoading ? "…" : 0)} delta={s ? `+${s.communitiesWeek} this week` : undefined} />
        <StatCard icon={<Briefcase className="h-4 w-4" />} label="Jobs Posted" value={s?.jobs ?? (isLoading ? "…" : 0)} delta={s ? `+${s.jobsToday} today` : undefined} />
        <StatCard icon={<FolderKanban className="h-4 w-4" />} label="Projects" value={s?.projects ?? (isLoading ? "…" : 0)} delta={s ? `+${s.projectsWeek} this week` : undefined} />
        <StatCard icon={<Sparkles className="h-4 w-4" />} label="Prompts" value={s?.prompts ?? (isLoading ? "…" : 0)} />
        <StatCard icon={<CreditCard className="h-4 w-4" />} label="Active Subscriptions" value={s?.activeSubscriptions ?? (isLoading ? "…" : 0)} accent="gold" />
        <StatCard
          icon={<AlertTriangle className="h-4 w-4" />}
          label="Open Bug Reports"
          value={s?.pendingReports ?? (isLoading ? "…" : 0)}
          delta={s && s.pendingReports > 0 ? "Needs review" : "All clear"}
          deltaTone={s && s.pendingReports > 0 ? "warn" : "up"}
          accent={s && s.pendingReports > 0 ? "warn" : "success"}
          cta={<Link to="/admin/reports" className="text-[12px] font-bold text-coral hover:underline">Review →</Link>}
        />
      </div>

      <div className="mt-6">
        <AdminCard className="overflow-hidden p-0">
          <div className="grid gap-0 lg:grid-cols-[320px_1fr]">
            <div className="border-b-[1.5px] border-[#0F0F0F] bg-surface p-5 lg:border-b-0 lg:border-r-[1.5px]">
              <div className="inline-flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 py-1 text-[11px] font-extrabold uppercase tracking-[0.1em] text-foreground shadow-[2px_2px_0_0_#0F0F0F]">
                <Award className="h-3.5 w-3.5 text-coral" /> OG badges
              </div>
              <div className="mt-5 font-display text-5xl font-extrabold leading-none text-foreground">
                {ogStats ? ogStats.remaining : isLoading ? "…" : 100}
              </div>
              <div className="mt-2 text-[12px] font-extrabold uppercase tracking-[0.12em] text-muted-foreground">
                spots remaining
              </div>
              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3 shadow-[2px_2px_0_0_#0F0F0F]">
                  <div className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-muted-foreground">Claimed</div>
                  <div className="mt-1 text-2xl font-extrabold text-foreground">{ogStats?.taken ?? (isLoading ? "…" : 0)}</div>
                </div>
                <div className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3 shadow-[2px_2px_0_0_#0F0F0F]">
                  <div className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-muted-foreground">Next</div>
                  <div className="mt-1 text-2xl font-extrabold text-coral">#{ogStats?.nextNumber ?? (isLoading ? "…" : 1)}</div>
                </div>
              </div>
            </div>
            <div className="p-5">
              <div className="mb-3 flex items-center justify-between gap-3">
                <div>
                  <div className="font-display text-[15px] font-extrabold text-foreground">Founders Wall · claimed badges</div>
                  <div className="text-xs text-muted-foreground">Same live rows used by the early access wall</div>
                </div>
                <Link to="/founders-wall" className="text-[12px] font-bold text-coral hover:underline">Open page →</Link>
              </div>
              <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
                {isLoading && <div className="rounded-lg border border-[#0F0F0F]/10 bg-card p-4 text-sm text-muted-foreground">Loading OG members…</div>}
                {!isLoading && ogMembers.length === 0 && <div className="rounded-lg border border-[#0F0F0F]/10 bg-card p-4 text-sm text-muted-foreground">No OG badges claimed yet.</div>}
                {ogMembers.map((m) => (
                  <div key={m.id} className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3 shadow-[2px_2px_0_0_#0F0F0F]">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="truncate text-sm font-extrabold text-foreground">{m.full_name}</div>
                        <div className="mt-0.5 truncate text-[11px] font-semibold text-muted-foreground">
                          {[m.city, m.state].filter(Boolean).join(", ") || "Location pending"}
                        </div>
                      </div>
                      <div className="inline-flex shrink-0 items-center gap-1 rounded-full bg-gold px-2 py-1 text-[11px] font-extrabold text-[#0F0F0F]">
                        <Crown className="h-3 w-3" /> #{m.og_number ?? "—"}
                      </div>
                    </div>
                    <div className="mt-3 flex items-center justify-between gap-2 text-[10px] font-extrabold uppercase tracking-[0.1em] text-muted-foreground">
                      <span>{m.og_status}</span>
                      <span>{m.show_on_wall ? "On wall" : "Hidden"}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </AdminCard>
      </div>

      {/* Growth chart */}
      <div className="mt-6">
        <AdminCard className="p-5">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <div className="font-display text-[15px] font-extrabold text-foreground">Signups · Last 30 Days</div>
              <div className="text-xs text-muted-foreground">Daily new profiles created</div>
            </div>
            <div className="flex gap-3 text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-coral" /> New users</span>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer>
              <LineChart data={growth}>
                <CartesianGrid stroke="#0F0F0F" strokeOpacity={0.08} vertical={false} />
                <XAxis dataKey="day" stroke="#0F0F0F" opacity={0.6} fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#0F0F0F" opacity={0.6} fontSize={10} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ background: "#FFF8EE", border: "1.5px solid #0F0F0F", borderRadius: 8, color: "#0F0F0F", boxShadow: "3px 3px 0 0 #0F0F0F", fontWeight: 700 }}
                  labelStyle={{ color: "#0F0F0F", fontWeight: 800 }}
                />
                <Line type="monotone" dataKey="users" stroke="#E8623A" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </AdminCard>
      </div>

      {/* Recent signups */}
      <div className="mt-6">
        <div className="mb-3 flex items-center justify-between">
          <div className="font-display text-[15px] font-extrabold text-foreground">Recent Signups</div>
          <Link to="/admin/users" className="text-[12px] font-bold text-coral hover:underline">View all users →</Link>
        </div>
        <AdminCard className="overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr>
                  <th className="border-b-[1.5px] border-[#0F0F0F] bg-surface px-4 py-3 text-left text-[10.5px] font-extrabold uppercase tracking-[0.09em] text-foreground">User</th>
                  <th className="border-b-[1.5px] border-[#0F0F0F] bg-surface px-4 py-3 text-left text-[10.5px] font-extrabold uppercase tracking-[0.09em] text-foreground">Role</th>
                  <th className="border-b-[1.5px] border-[#0F0F0F] bg-surface px-4 py-3 text-left text-[10.5px] font-extrabold uppercase tracking-[0.09em] text-foreground">Joined</th>
                </tr>
              </thead>
              <tbody>
                {isLoading && (
                  <tr><td colSpan={3} className="bg-card px-4 py-8 text-center text-sm text-muted-foreground">Loading live data…</td></tr>
                )}
                {!isLoading && signups.length === 0 && (
                  <tr><td colSpan={3} className="bg-card px-4 py-8 text-center text-sm text-muted-foreground">No signups yet.</td></tr>
                )}
                {signups.map((u) => (
                  <tr key={u.id} className="group">
                    <td className="border-t border-[#0F0F0F]/10 bg-card px-4 py-3 transition group-hover:bg-surface/60">
                      <div className="flex items-center gap-3">
                        <img
                          src={u.avatar_url ?? `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(u.name)}`}
                          className="h-8 w-8 rounded-full border-[1.5px] border-[#0F0F0F] bg-surface"
                          alt=""
                        />
                        <div>
                          <div className="font-bold text-foreground">{u.name}</div>
                          {u.username && <div className="text-[11px] text-muted-foreground">@{u.username}</div>}
                        </div>
                      </div>
                    </td>
                    <td className="border-t border-[#0F0F0F]/10 bg-card px-4 py-3 transition group-hover:bg-surface/60"><RolePill role={u.role} /></td>
                    <td className="border-t border-[#0F0F0F]/10 bg-card px-4 py-3 text-[12px] font-semibold text-muted-foreground transition group-hover:bg-surface/60">
                      {new Date(u.created_at).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </AdminCard>
      </div>

      <div className="mt-6">
        <AdminCard className="p-4">
          <div className="flex items-center gap-2 text-[13px] text-muted-foreground">
            <Shield className="h-4 w-4 text-coral" />
            <span className="font-bold text-foreground">Live data.</span>
            Numbers auto-refresh every 60s. Moderation & reports queues will light up here as data flows in.
          </div>
        </AdminCard>
      </div>
    </AdminPage>
  );
}
