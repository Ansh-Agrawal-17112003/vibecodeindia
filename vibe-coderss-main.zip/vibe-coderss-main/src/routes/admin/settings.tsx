import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState } from "react";
import { AdminPage, AdminCard, Input, Select, Textarea, Toggle, BtnCoral, Pill } from "@/components/admin/AdminUI";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/admin/settings")({
  head: () => ({ meta: [{ title: "Platform Settings · VibeCode Admin" }] }),
  component: SettingsPage,
});

const TABS = ["General", "Auth", "Email", "Payment", "Maintenance"] as const;
type Tab = typeof TABS[number];

function SettingsPage() {
  const { isSuperAdmin, loading } = useAuth();
  const [tab, setTab] = useState<Tab>("General");

  // form state
  const [emailSignup, setEmailSignup] = useState(true);
  const [google, setGoogle] = useState(true);
  const [github, setGithub] = useState(false);
  const [emailVerify, setEmailVerify] = useState(true);
  const [maintenance, setMaintenance] = useState(false);

  if (loading) return null;
  if (!isSuperAdmin) return <Navigate to="/admin" replace />;

  const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="flex flex-col gap-2 border-b border-[#0F0F0F]/15 py-4 last:border-b-0 md:flex-row md:items-center md:justify-between">
      <div className="text-[13px] font-semibold text-foreground">{label}</div>
      <div className="md:w-[320px]">{children}</div>
    </div>
  );

  return (
    <AdminPage title="Platform Settings" subtitle={<>⚠️ <Pill tone="gold">Super Admin</Pill> access only</> as any}>
      <div className="mb-4 flex flex-wrap items-center gap-1 border-b border-[#0F0F0F]/15">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2.5 text-[13px] font-bold ${tab === t ? "border-b-2 border-coral text-foreground" : "text-muted-foreground hover:text-foreground"}`}>{t}</button>
        ))}
      </div>

      <AdminCard className="p-6">
        {tab === "General" && (
          <div>
            <Row label="Platform Name"><Input defaultValue="VibeCode" className="w-full" /></Row>
            <Row label="Tagline"><Input defaultValue="India's Largest AI Builders Community" className="w-full" /></Row>
            <Row label="Support Email"><Input defaultValue="support@vibecode.app" className="w-full" /></Row>
            <Row label="Max Upload Size"><Select defaultValue="10" className="w-full"><option value="5">5 MB</option><option value="10">10 MB</option><option value="25">25 MB</option></Select></Row>
            <Row label="Default User Role"><Select defaultValue="user" className="w-full"><option value="user">user</option><option value="admin">admin</option></Select></Row>
          </div>
        )}
        {tab === "Auth" && (
          <div>
            <Row label="Email Signup"><Toggle checked={emailSignup} onChange={setEmailSignup} /></Row>
            <Row label="Google OAuth"><Toggle checked={google} onChange={setGoogle} /></Row>
            <Row label="GitHub OAuth"><Toggle checked={github} onChange={setGithub} /></Row>
            <Row label="Email Verification Required"><Toggle checked={emailVerify} onChange={setEmailVerify} /></Row>
            <Row label="Min Password Length"><Input type="number" defaultValue={8} className="w-full" /></Row>
          </div>
        )}
        {tab === "Email" && (
          <div>
            <Row label="From Name"><Input defaultValue="VibeCode" className="w-full" /></Row>
            <Row label="From Email"><Input defaultValue="hello@vibecode.app" className="w-full" /></Row>
            <Row label="Reply-To"><Input defaultValue="support@vibecode.app" className="w-full" /></Row>
            <Row label="Welcome Email Template"><Textarea rows={4} defaultValue="Welcome to VibeCode 👋 — the fastest way to build with AI." /></Row>
          </div>
        )}
        {tab === "Payment" && (
          <div>
            <Row label="UPI ID"><div className="flex gap-2"><Input defaultValue="vibecode@upi" className="w-full" /><button className="rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[12px] font-bold text-foreground hover:bg-surface">Copy</button></div></Row>
            <Row label="Pro Plan (₹499) Link"><Input placeholder="https://rzp.io/i/..." className="w-full" /></Row>
            <Row label="Biz Plan (₹2999) Link"><Input placeholder="https://rzp.io/i/..." className="w-full" /></Row>
            <Row label="Payment QR"><div className="grid h-24 w-24 place-items-center rounded-md border border-dashed border-[#0F0F0F]/15 bg-card text-[11px] text-muted-foreground">Upload QR</div></Row>
          </div>
        )}
        {tab === "Maintenance" && (
          <div>
            <Row label="Maintenance Mode"><Toggle checked={maintenance} onChange={setMaintenance} /></Row>
            <Row label="Maintenance Message"><Textarea rows={3} defaultValue="We're doing some quick upgrades. Back in 30 min." /></Row>
            <div className="mt-4">
              <button className="inline-flex h-10 items-center gap-2 rounded-md border border-[#EF4444]/50 bg-[#EF4444]/15 px-4 text-[13px] font-bold text-[#F87171] hover:bg-[#EF4444]/25">⚠️ Enable Maintenance Mode</button>
            </div>
          </div>
        )}
        <div className="mt-6 flex justify-end border-t border-[#0F0F0F]/15 pt-4">
          <BtnCoral>Save Settings</BtnCoral>
        </div>
      </AdminCard>
    </AdminPage>
  );
}
