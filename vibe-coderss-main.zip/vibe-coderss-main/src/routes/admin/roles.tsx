import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, RefreshCw, Loader2 } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AdminPage, AdminCard, Input, RolePill, EmptyState } from "@/components/admin/AdminUI";
import { useAuth } from "@/hooks/useAuth";
import { listAdminUsers, grantAdminRole, revokeAdminRole } from "@/lib/admin-stats.functions";

export const Route = createFileRoute("/admin/roles")({
  head: () => ({ meta: [{ title: "Role Management · VibeCode Admin" }] }),
  component: Page,
});

type Row = {
  id: string; email: string; name: string; avatar_url: string | null;
  role: "super_admin" | "admin" | "user"; followers: number; created_at: string;
};

function Page() {
  const { isSuperAdmin, loading } = useAuth();
  const [q, setQ] = useState("");
  const [confirmGrant, setConfirmGrant] = useState<Row | null>(null);
  const [confirmRevoke, setConfirmRevoke] = useState<Row | null>(null);
  const [banner, setBanner] = useState<{ tone: "ok" | "err"; text: string } | null>(null);

  const fetchUsers = useServerFn(listAdminUsers);
  const grantFn = useServerFn(grantAdminRole);
  const revokeFn = useServerFn(revokeAdminRole);
  const qc = useQueryClient();

  const { data, isLoading, isFetching, refetch, error } = useQuery({
    queryKey: ["admin", "roles-users"],
    queryFn: () => fetchUsers({ data: { limit: 200 } }),
    refetchInterval: 60_000,
    staleTime: 30_000,
    enabled: !loading && !!isSuperAdmin,
  });

  const rows = (data?.rows ?? []) as Row[];
  const supers = useMemo(() => rows.filter((u) => u.role === "super_admin"), [rows]);
  const admins = useMemo(() => rows.filter((u) => u.role === "admin"), [rows]);
  const matches = useMemo(() => {
    if (q.length < 2) return [];
    const t = q.toLowerCase();
    return rows.filter((u) => u.role === "user" && (u.name.toLowerCase().includes(t) || u.email.toLowerCase().includes(t))).slice(0, 8);
  }, [rows, q]);

  const grant = useMutation({
    mutationFn: (u: Row) => grantFn({ data: { userId: u.id } }),
    onSuccess: (_r, u) => { setBanner({ tone: "ok", text: `${u.name} is now an Admin.` }); setConfirmGrant(null); qc.invalidateQueries({ queryKey: ["admin"] }); },
    onError: (e: any) => setBanner({ tone: "err", text: e?.message ?? "Failed to grant admin" }),
  });
  const revoke = useMutation({
    mutationFn: (u: Row) => revokeFn({ data: { userId: u.id } }),
    onSuccess: (_r, u) => { setBanner({ tone: "ok", text: `Removed admin role from ${u.name}.` }); setConfirmRevoke(null); qc.invalidateQueries({ queryKey: ["admin"] }); },
    onError: (e: any) => setBanner({ tone: "err", text: e?.message ?? "Failed to revoke admin" }),
  });

  if (loading) return null;
  if (!isSuperAdmin) return <Navigate to="/admin" replace />;

  const avatar = (u: Row) => u.avatar_url ?? `https://api.dicebear.com/7.x/notionists/svg?seed=${u.id}`;

  return (
    <AdminPage
      title="Role Management"
      subtitle={isLoading ? "Loading live roles…" : `${supers.length} super admin${supers.length === 1 ? "" : "s"} · ${admins.length} admin${admins.length === 1 ? "" : "s"} · live from database`}
      actions={
        <button onClick={() => refetch()} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[13px] font-bold text-foreground hover:bg-surface">
          <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} /> Refresh
        </button>
      }
    >
      {error && (
        <div className="mb-4 rounded-md border border-[#EF4444]/40 bg-[#EF4444]/10 px-3 py-2 text-[13px] font-bold text-[#B91C1C]">
          Couldn't load users: {(error as Error).message}
        </div>
      )}
      {banner && (
        <div className={`mb-4 rounded-md border px-3 py-2 text-[13px] font-bold ${banner.tone === "ok" ? "border-[#22C55E]/40 bg-[#DCFCE7] text-[#166534]" : "border-[#EF4444]/40 bg-[#FEE2E2] text-[#B91C1C]"}`}>
          {banner.text}
        </div>
      )}

      {/* Super Admins */}
      <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Super Admins (read-only)</div>
      <AdminCard className="mb-2 divide-y divide-[#0F0F0F]/10">
        {isLoading ? (
          <div className="p-4 text-[13px] text-muted-foreground">Loading…</div>
        ) : supers.length === 0 ? (
          <div className="p-4 text-[13px] text-muted-foreground">No super admins found.</div>
        ) : supers.map((u) => (
          <div key={u.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
            <div className="flex min-w-0 items-center gap-3">
              <img src={avatar(u)} className="h-9 w-9 shrink-0 rounded-full border border-[#0F0F0F]/15 bg-surface" alt="" />
              <div className="min-w-0">
                <div className="truncate font-semibold text-foreground">{u.name}</div>
                <div className="truncate text-[12px] text-muted-foreground">{u.email}</div>
              </div>
            </div>
            <div className="flex items-center gap-2"><RolePill role="super_admin" /><span className="text-[11px] text-muted-foreground">Cannot change</span></div>
          </div>
        ))}
      </AdminCard>
      <p className="mb-6 text-[11px] text-muted-foreground">Super Admin accounts can only be changed directly in the database.</p>

      {/* Admins */}
      <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Current Admins</div>
      <AdminCard className="mb-6 divide-y divide-[#0F0F0F]/10">
        {isLoading ? (
          <div className="p-4 text-[13px] text-muted-foreground">Loading…</div>
        ) : admins.length === 0 ? (
          <div className="p-4 text-[13px] text-muted-foreground">No admins assigned yet.</div>
        ) : admins.map((u) => (
          <div key={u.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
            <div className="flex min-w-0 items-center gap-3">
              <img src={avatar(u)} className="h-9 w-9 shrink-0 rounded-full border border-[#0F0F0F]/15 bg-surface" alt="" />
              <div className="min-w-0">
                <div className="truncate font-semibold text-foreground">{u.name}</div>
                <div className="truncate text-[12px] text-muted-foreground">{u.email}</div>
              </div>
            </div>
            <button
              onClick={() => setConfirmRevoke(u)}
              className="inline-flex h-9 items-center rounded-md border border-[#EF4444]/40 bg-[#FEE2E2] px-3 text-[12px] font-bold text-[#B91C1C] hover:bg-[#FEE2E2]/80"
            >
              Remove
            </button>
          </div>
        ))}
      </AdminCard>

      {/* Assign new admin */}
      <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Assign New Admin</div>
      <AdminCard className="mb-6 p-4">
        <div className="relative mb-3">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search user by name or email…" className="w-full pl-9" />
        </div>
        {matches.length > 0 && (
          <div className="space-y-2">
            {matches.map((u) => (
              <div key={u.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#0F0F0F]/15 bg-card p-3">
                <div className="flex min-w-0 items-center gap-3">
                  <img src={avatar(u)} className="h-9 w-9 shrink-0 rounded-full border border-[#0F0F0F]/15" alt="" />
                  <div className="min-w-0">
                    <div className="truncate font-semibold text-foreground">{u.name}</div>
                    <div className="truncate text-[11px] text-muted-foreground">{u.email} · {u.followers} followers · Joined {new Date(u.created_at).toLocaleDateString("en-IN")}</div>
                  </div>
                </div>
                <button onClick={() => setConfirmGrant(u)} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-coral px-3 text-[12px] font-bold text-white hover:brightness-95">⚡ Make Admin</button>
              </div>
            ))}
          </div>
        )}
        {q.length >= 2 && matches.length === 0 && !isLoading && (
          <p className="text-[12px] text-muted-foreground">No matching users.</p>
        )}
        {q.length < 2 && (
          <p className="text-[12px] text-muted-foreground">Type at least 2 characters to search live users.</p>
        )}
      </AdminCard>

      {!isLoading && rows.length === 0 && (
        <EmptyState title="No users yet" description="As soon as people sign up, they'll appear here." />
      )}

      {/* Confirm grant */}
      {confirmGrant && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4" onClick={() => setConfirmGrant(null)}>
          <AdminCard onClick={(e) => e.stopPropagation()} className="w-full max-w-md p-6">
            <div className="font-display text-lg font-extrabold text-foreground">Make {confirmGrant.name} an Admin?</div>
            <p className="mt-2 text-[13px] text-muted-foreground">Admins can moderate content, manage users, view analytics and manage communities. They cannot access Platform Settings or assign/remove other admin roles.</p>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setConfirmGrant(null)} className="inline-flex h-9 items-center rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[12px] font-bold text-foreground">Cancel</button>
              <button
                disabled={grant.isPending}
                onClick={() => grant.mutate(confirmGrant)}
                className="inline-flex h-9 items-center gap-1.5 rounded-md bg-coral px-3 text-[12px] font-bold text-white disabled:opacity-60"
              >
                {grant.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin" />} Confirm: Make Admin
              </button>
            </div>
          </AdminCard>
        </div>
      )}

      {/* Confirm revoke */}
      {confirmRevoke && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4" onClick={() => setConfirmRevoke(null)}>
          <AdminCard onClick={(e) => e.stopPropagation()} className="w-full max-w-md p-6">
            <div className="font-display text-lg font-extrabold text-foreground">Remove admin role from {confirmRevoke.name}?</div>
            <p className="mt-2 text-[13px] text-muted-foreground">They will lose access to the admin panel immediately.</p>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setConfirmRevoke(null)} className="inline-flex h-9 items-center rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[12px] font-bold text-foreground">Cancel</button>
              <button
                disabled={revoke.isPending}
                onClick={() => revoke.mutate(confirmRevoke)}
                className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#EF4444]/40 bg-[#FEE2E2] px-3 text-[12px] font-bold text-[#B91C1C] disabled:opacity-60"
              >
                {revoke.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin" />} Confirm: Remove
              </button>
            </div>
          </AdminCard>
        </div>
      )}
    </AdminPage>
  );
}
