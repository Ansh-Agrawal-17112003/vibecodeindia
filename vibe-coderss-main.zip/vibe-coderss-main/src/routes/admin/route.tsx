import { createFileRoute, Outlet, Link, useNavigate } from "@tanstack/react-router";
import { AdminRoute } from "@/components/auth/RouteGuards";
import { AdminSidebar, AdminMobileHeader } from "@/components/admin/AdminSidebar";
import { useAuth } from "@/hooks/useAuth";
import { Bell, ArrowLeft, Zap, Crown } from "lucide-react";
import { dashboardStats } from "@/components/admin/adminMockData";

export const Route = createFileRoute("/admin")({
  ssr: false,
  component: AdminLayout,
});

function AdminLayout() {
  const { profile, isSuperAdmin, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <AdminRoute>
      <div className="min-h-screen bg-background text-foreground">
        {/* Top bar — brand neo-brutalist */}
        <header className="sticky top-0 z-40 flex h-16 items-center justify-between gap-2 border-b-[1.5px] border-[#0F0F0F] bg-card px-3 md:px-6" style={{ boxShadow: "0 4px 0 -2px #0F0F0F" }}>
          <Link to="/admin" className="flex min-w-0 items-center gap-2">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-coral text-white shadow-[2px_2px_0_0_#0F0F0F] md:h-9 md:w-9">
              <Zap className="h-3.5 w-3.5 md:h-4 md:w-4" />
            </span>
            <span className="truncate font-display text-[13px] font-extrabold tracking-tight text-foreground md:text-[17px]">
              VibeCode<span className="text-coral">.</span>Admin
            </span>
            {isSuperAdmin && (
              <span className="pill-badge ml-1 hidden bg-gold text-[#0F0F0F] sm:inline-flex">
                <Crown className="h-3 w-3" /> Super
              </span>
            )}
          </Link>
          <div className="flex shrink-0 items-center gap-1.5 md:gap-2">
            <button className="relative grid h-9 w-9 place-items-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-surface text-foreground shadow-[2px_2px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:bg-gold hover:shadow-[3px_3px_0_0_#0F0F0F]">
              <Bell className="h-4 w-4" />
              {dashboardStats.pendingReports > 0 && (
                <span className="absolute -right-1.5 -top-1.5 grid h-[18px] min-w-[18px] place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-1 text-[10px] font-extrabold text-white">
                  {dashboardStats.pendingReports}
                </span>
              )}
            </button>
            <div className="hidden items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-surface px-2 py-1 shadow-[2px_2px_0_0_#0F0F0F] md:flex">
              <img
                src={`https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(profile?.display_name ?? "admin")}`}
                alt=""
                className="h-6 w-6 rounded-full border border-[#0F0F0F]/30 bg-card"
              />
              <span className="text-[12px] font-extrabold text-foreground">{profile?.display_name ?? "Admin"}</span>
            </div>
            <Link
              to="/"
              aria-label="Exit admin"
              className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-2.5 text-[12px] font-extrabold text-foreground shadow-[2px_2px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:bg-gold hover:shadow-[3px_3px_0_0_#0F0F0F] md:px-3"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Exit</span>
            </Link>
            <button
              onClick={async () => { await signOut(); navigate({ to: "/" }); }}
              className="hidden text-[12px] font-bold text-muted-foreground hover:text-coral md:inline"
            >
              Sign out
            </button>
          </div>
        </header>

        {/* Body: sidebar + content */}
        <div className="flex min-h-[calc(100vh-64px)]">
          <AdminSidebar badges={{ pendingReports: dashboardStats.pendingReports, modQueue: dashboardStats.modQueue }} />
          <div className="flex min-w-0 flex-1 flex-col">
            <AdminMobileHeader badges={{ pendingReports: dashboardStats.pendingReports, modQueue: dashboardStats.modQueue }} />
            <main
              className="flex-1 bg-background"
              style={{
                backgroundImage:
                  "radial-gradient(circle at 1px 1px, rgba(15,15,15,0.08) 1px, transparent 0)",
                backgroundSize: "22px 22px",
              }}
            >
              <Outlet />
            </main>
          </div>
        </div>
      </div>
    </AdminRoute>
  );
}
