import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { RefreshCw } from "lucide-react";
import { AdminPage, Pill, EmptyState } from "@/components/admin/AdminUI";
import { listAdminReports } from "@/lib/admin-stats.functions";

export const Route = createFileRoute("/admin/moderation")({
  head: () => ({ meta: [{ title: "Moderation · VibeCode Admin" }] }),
  component: ModerationPage,
});

function ModerationPage() {
  const fetchReports = useServerFn(listAdminReports);
  const { data, isLoading, isFetching, refetch } = useQuery({
    queryKey: ["admin", "moderation"],
    queryFn: () => fetchReports({ data: { status: "open" } }),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const counts = data?.counts ?? { open: 0, total: 0 };

  return (
    <AdminPage
      title="Moderation Queue"
      subtitle="Live queue of flagged content · auto-refresh every 60s"
      actions={
        <button onClick={() => refetch()} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[13px] font-bold text-foreground hover:bg-surface">
          <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} /> Refresh
        </button>
      }
    >
      <div className="mb-5 flex flex-wrap gap-2">
        <Pill tone="warn">Open: <span className="ml-1 font-extrabold text-[#FBBF24]">{counts.open}</span></Pill>
        <Pill>Total tracked: <span className="ml-1 font-extrabold text-foreground">{counts.total}</span></Pill>
      </div>

      {isLoading ? (
        <EmptyState title="Loading queue…" description="Fetching from the database." />
      ) : (
        <EmptyState
          icon="✅"
          title="Moderation queue is clear"
          description="Flagged posts, comments, and profiles from real users will appear here as reports come in. The queue auto-refreshes every 60 seconds."
        />
      )}
    </AdminPage>
  );
}
