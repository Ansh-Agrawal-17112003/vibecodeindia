import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, MoreVertical, RefreshCw } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { AdminPage, AdminCard, TableWrap, TH, TD, Input, Select, Pill, EmptyState } from "@/components/admin/AdminUI";
import { listAdminJobs } from "@/lib/admin-stats.functions";

export const Route = createFileRoute("/admin/jobs")({
  head: () => ({ meta: [{ title: "Jobs · VibeCode Admin" }] }),
  component: JobsPage,
});

function timeAgo(iso: string) {
  const mins = Math.floor((Date.now() - +new Date(iso)) / 60000);
  if (mins < 60) return `${mins}m ago`;
  const h = Math.floor(mins / 60); if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function JobsPage() {
  const [search, setSearch] = useState("");
  const [type, setType] = useState<"all" | string>("all");
  const [status, setStatus] = useState<"all" | string>("all");

  const fetchJobs = useServerFn(listAdminJobs);
  const { data, isLoading, isFetching, refetch, error } = useQuery({
    queryKey: ["admin", "jobs"],
    queryFn: () => fetchJobs(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const all = data?.rows ?? [];
  const rows = useMemo(() => all.filter((j) =>
    (!search || j.title.toLowerCase().includes(search.toLowerCase()) || j.company.toLowerCase().includes(search.toLowerCase())) &&
    (type === "all" || j.job_type === type) &&
    (status === "all" || j.status === status)
  ), [all, search, type, status]);

  const stats = {
    total: all.length,
    active: all.filter((j) => j.status === "active").length,
    closed: all.filter((j) => j.status === "closed").length,
  };

  return (
    <AdminPage
      title="Job Management"
      subtitle={isLoading ? "Loading live jobs…" : `${stats.total} real jobs · auto-refresh every 60s`}
      actions={
        <button onClick={() => refetch()} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[13px] font-bold text-foreground hover:bg-surface">
          <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} /> Refresh
        </button>
      }
    >
      {error && <div className="mb-4 rounded-md border border-[#EF4444]/40 bg-[#EF4444]/10 px-3 py-2 text-[13px] font-bold text-[#F87171]">Couldn't load: {(error as Error).message}</div>}

      <div className="mb-5 flex flex-wrap gap-2">
        <Pill>Total: <span className="ml-1 font-extrabold text-foreground">{stats.total}</span></Pill>
        <Pill tone="success">Active: <span className="ml-1 font-extrabold text-[#4ADE80]">{stats.active}</span></Pill>
        <Pill>Closed: <span className="ml-1 font-extrabold text-foreground">{stats.closed}</span></Pill>
      </div>

      <AdminCard className="mb-4 p-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[240px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search jobs…" className="w-full pl-9" />
          </div>
          <Select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="all">All statuses</option><option value="active">Active</option><option value="closed">Closed</option><option value="draft">Draft</option>
          </Select>
          <Select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="all">All types</option><option value="full-time">Full-time</option><option value="part-time">Part-time</option><option value="contract">Contract</option><option value="internship">Internship</option>
          </Select>
        </div>
      </AdminCard>

      {isLoading ? (
        <EmptyState title="Loading jobs…" description="Fetching from the database." />
      ) : rows.length === 0 ? (
        <EmptyState title="No jobs posted yet" description="Real job postings will appear here as employers submit them." />
      ) : (
        <TableWrap>
          <thead>
            <tr><TH>Job</TH><TH>Type</TH><TH>Location</TH><TH>Salary</TH><TH>Posted</TH><TH>Apps</TH><TH>Status</TH><TH className="text-right">Actions</TH></tr>
          </thead>
          <tbody>
            {rows.map((j) => (
              <tr key={j.id} className="hover:bg-surface">
                <TD>
                  <div className="font-semibold text-foreground">{j.title}</div>
                  <div className="text-[11px] text-muted-foreground">{j.company}</div>
                </TD>
                <TD className="capitalize text-foreground/80">{j.job_type}</TD>
                <TD className="text-foreground/80">{j.location}</TD>
                <TD className="text-foreground/80">{j.salary}</TD>
                <TD className="text-[12px] text-muted-foreground">{timeAgo(j.posted_at)}</TD>
                <TD className="font-semibold text-foreground">{j.applicants}</TD>
                <TD><Pill tone={j.status === "active" ? "success" : "warn"}>{j.status}</Pill></TD>
                <TD className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger className="rounded-md border border-[#0F0F0F]/15 p-1.5 text-muted-foreground hover:bg-surface hover:text-foreground"><MoreVertical className="h-4 w-4" /></DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-44 border-[#0F0F0F]/15 bg-card text-foreground">
                      <DropdownMenuItem>👁 View Job</DropdownMenuItem>
                      <DropdownMenuItem className="text-[#F87171]">🗑 Remove</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TD>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
    </AdminPage>
  );
}
