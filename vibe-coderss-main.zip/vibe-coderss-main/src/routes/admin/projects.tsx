import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, RefreshCw, ExternalLink, Github, Star, ArrowUp } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { AdminPage, AdminCard, TableWrap, TH, TD, Input, Select, Pill, EmptyState } from "@/components/admin/AdminUI";
import { listAdminProjects } from "@/lib/admin-stats.functions";

export const Route = createFileRoute("/admin/projects")({
  head: () => ({ meta: [{ title: "Projects · VibeCode Admin" }] }),
  component: ProjectsPage,
});

function timeAgo(iso: string) {
  const mins = Math.floor((Date.now() - +new Date(iso)) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const h = Math.floor(mins / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function ProjectsPage() {
  const [search, setSearch] = useState("");
  const [industry, setIndustry] = useState<"all" | string>("all");
  const [sort, setSort] = useState<"recent" | "upvotes">("recent");

  const fetchProjects = useServerFn(listAdminProjects);
  const { data, isLoading, isFetching, refetch, error } = useQuery({
    queryKey: ["admin", "projects"],
    queryFn: () => fetchProjects(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const all = data?.rows ?? [];
  const industries = useMemo(() => Array.from(new Set(all.map((p) => p.industry).filter((i) => i && i !== "—"))), [all]);

  const rows = useMemo(() => {
    let r = all.filter((p) =>
      (!search ||
        p.title.toLowerCase().includes(search.toLowerCase()) ||
        p.builder_name.toLowerCase().includes(search.toLowerCase())) &&
      (industry === "all" || p.industry === industry)
    );
    if (sort === "upvotes") r = [...r].sort((a, b) => b.upvote_count - a.upvote_count);
    return r;
  }, [all, search, industry, sort]);

  const stats = {
    total: all.length,
    featured: all.filter((p) => p.featured).length,
    week: all.filter((p) => Date.now() - +new Date(p.created_at) < 7 * 86_400_000).length,
  };

  return (
    <AdminPage
      title="Projects Built by Users"
      subtitle={isLoading ? "Loading live projects…" : `${stats.total} real projects · auto-refresh every 60s`}
      actions={
        <button onClick={() => refetch()} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[13px] font-bold text-foreground hover:bg-surface">
          <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} /> Refresh
        </button>
      }
    >
      {error && (
        <div className="mb-4 rounded-md border border-[#EF4444]/40 bg-[#EF4444]/10 px-3 py-2 text-[13px] font-bold text-[#F87171]">
          Couldn't load: {(error as Error).message}
        </div>
      )}

      <div className="mb-5 flex flex-wrap gap-2">
        <Pill>Total: <span className="ml-1 font-extrabold text-foreground">{stats.total}</span></Pill>
        <Pill tone="success">This week: <span className="ml-1 font-extrabold text-[#4ADE80]">{stats.week}</span></Pill>
        <Pill tone="warn">Featured: <span className="ml-1 font-extrabold text-foreground">{stats.featured}</span></Pill>
      </div>

      <AdminCard className="mb-4 p-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[240px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search projects or builders…" className="w-full pl-9" />
          </div>
          <Select value={industry} onChange={(e) => setIndustry(e.target.value)}>
            <option value="all">All industries</option>
            {industries.map((i) => <option key={i} value={i}>{i}</option>)}
          </Select>
          <Select value={sort} onChange={(e) => setSort(e.target.value as "recent" | "upvotes")}>
            <option value="recent">Most recent</option>
            <option value="upvotes">Most upvoted</option>
          </Select>
        </div>
      </AdminCard>

      {isLoading ? (
        <EmptyState title="Loading projects…" description="Fetching from the database." />
      ) : rows.length === 0 ? (
        <EmptyState title="No user projects yet" description="Projects shipped by real users will appear here." />
      ) : (
        <TableWrap>
          <thead>
            <tr>
              <TH>Project</TH>
              <TH>Builder</TH>
              <TH>Industry</TH>
              <TH>Tools</TH>
              <TH>Upvotes</TH>
              <TH>Shipped</TH>
              <TH className="text-right">Links</TH>
            </tr>
          </thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id} className="hover:bg-surface">
                <TD>
                  <div className="flex items-center gap-3">
                    {p.cover_image_url ? (
                      <img src={p.cover_image_url} alt="" className="h-10 w-14 rounded-md border border-[#0F0F0F]/15 object-cover" />
                    ) : (
                      <div className="grid h-10 w-14 place-items-center rounded-md border border-dashed border-[#0F0F0F]/20 bg-surface text-[10px] font-bold text-muted-foreground">No img</div>
                    )}
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 truncate font-semibold text-foreground">
                        {p.title}
                        {p.featured && <Star className="h-3 w-3 text-gold" />}
                      </div>
                      <div className="flex flex-wrap gap-1 pt-0.5">
                        {(p.tags ?? []).slice(0, 3).map((t: string) => (
                          <span key={t} className="rounded border border-[#0F0F0F]/10 bg-surface px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">#{t}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                </TD>
                <TD>
                  <div className="flex items-center gap-2">
                    {p.builder_avatar ? (
                      <img src={p.builder_avatar} alt="" className="h-6 w-6 rounded-full border border-[#0F0F0F]/15" />
                    ) : (
                      <div className="h-6 w-6 rounded-full bg-surface" />
                    )}
                    <div>
                      <div className="text-[13px] font-semibold text-foreground">{p.builder_name}</div>
                      {p.builder_username && <div className="text-[10.5px] text-muted-foreground">@{p.builder_username}</div>}
                    </div>
                  </div>
                </TD>
                <TD className="text-foreground/80">{p.industry}</TD>
                <TD>
                  <div className="flex flex-wrap gap-1">
                    {(p.tools_used ?? []).slice(0, 3).map((t: string) => (
                      <span key={t} className="rounded border border-[#0F0F0F]/10 bg-surface px-1.5 py-0.5 text-[10px] font-semibold text-foreground/80">{t}</span>
                    ))}
                    {(p.tools_used ?? []).length > 3 && <span className="text-[10px] text-muted-foreground">+{p.tools_used.length - 3}</span>}
                  </div>
                </TD>
                <TD>
                  <span className="inline-flex items-center gap-1 font-bold text-foreground">
                    <ArrowUp className="h-3 w-3 text-coral" /> {p.upvote_count}
                  </span>
                </TD>
                <TD className="text-[12px] text-muted-foreground">{timeAgo(p.created_at)}</TD>
                <TD className="text-right">
                  <div className="inline-flex items-center gap-1.5">
                    {p.live_demo_url && (
                      <a href={p.live_demo_url} target="_blank" rel="noreferrer" title="Live demo" className="rounded-md border border-[#0F0F0F]/15 p-1.5 text-muted-foreground hover:bg-surface hover:text-foreground">
                        <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    )}
                    {p.github_url && (
                      <a href={p.github_url} target="_blank" rel="noreferrer" title="GitHub" className="rounded-md border border-[#0F0F0F]/15 p-1.5 text-muted-foreground hover:bg-surface hover:text-foreground">
                        <Github className="h-3.5 w-3.5" />
                      </a>
                    )}
                  </div>
                </TD>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
    </AdminPage>
  );
}
