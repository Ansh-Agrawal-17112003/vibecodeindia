import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { AdminPage, AdminCard, StatCard, Pill } from "@/components/admin/AdminUI";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { RefreshCw, Users, Home, Briefcase, FolderKanban } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { getAdminAnalytics } from "@/lib/admin-stats.functions";

export const Route = createFileRoute("/admin/analytics")({
  head: () => ({ meta: [{ title: "Analytics · VibeCode Admin" }] }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const { isSuperAdmin } = useAuth();
  const [metric, setMetric] = useState<"users" | "communities" | "jobs" | "projects">("users");
  const fetchAnalytics = useServerFn(getAdminAnalytics);
  const { data, isLoading, isFetching, refetch, error } = useQuery({
    queryKey: ["admin", "analytics"],
    queryFn: () => fetchAnalytics(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const growth = data?.growth ?? [];
  const totals = data?.totalsLast30 ?? { users: 0, communities: 0, jobs: 0, projects: 0 };
  const topCommunities = data?.topCommunities ?? [];
  const maxMembers = Math.max(1, ...topCommunities.map((c) => c.members));

  return (
    <AdminPage
      title="Platform Analytics"
      subtitle={isLoading ? "Loading live analytics…" : "Live database growth · auto-refresh every 60s"}
      actions={
        <button onClick={() => refetch()} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[13px] font-bold text-foreground hover:bg-surface">
          <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} /> Refresh
        </button>
      }
    >
      {error && <div className="mb-4 rounded-md border border-[#EF4444]/40 bg-[#EF4444]/10 px-3 py-2 text-[13px] font-bold text-[#F87171]">Couldn't load: {(error as Error).message}</div>}

      <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Growth · Last 30 Days</div>
      <div className="mb-6 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={<Users className="h-4 w-4" />} label="Total Users" value={totals.users} />
        <StatCard icon={<Home className="h-4 w-4" />} label="New Communities" value={totals.communities} />
        <StatCard icon={<Briefcase className="h-4 w-4" />} label="New Jobs" value={totals.jobs} />
        <StatCard icon={<FolderKanban className="h-4 w-4" />} label="New Projects" value={totals.projects} />
      </div>

      <AdminCard className="mb-6 p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="font-display text-[15px] font-extrabold text-foreground">Daily {metric}</div>
          <div className="flex gap-1">
            {(["users", "communities", "jobs", "projects"] as const).map((m) => (
              <button key={m} onClick={() => setMetric(m)} className={`rounded-md px-3 py-1.5 text-[12px] font-bold capitalize ${metric === m ? "bg-coral text-foreground" : "border-[1.5px] border-[#0F0F0F] bg-card text-foreground hover:bg-surface"}`}>{m}</button>
            ))}
          </div>
        </div>
        <div className="h-72 w-full">
          <ResponsiveContainer>
            <LineChart data={growth}>
              <CartesianGrid stroke="#0F0F0F" strokeOpacity={0.08} vertical={false} />
              <XAxis dataKey="day" stroke="#0F0F0F" opacity={0.6} fontSize={10} tickLine={false} axisLine={false} />
              <YAxis stroke="#0F0F0F" opacity={0.6} fontSize={10} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip contentStyle={{ background: "#FFF8EE", border: "1.5px solid #0F0F0F", borderRadius: 8, color: "#0F0F0F", boxShadow: "3px 3px 0 0 #0F0F0F", fontWeight: 700 }} />
              <Line type="monotone" dataKey={metric} stroke="#E8623A" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </AdminCard>

      <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Top Communities</div>
      <AdminCard className="mb-6 p-5">
        {topCommunities.length === 0 ? (
          <div className="py-8 text-center text-sm text-muted-foreground">No communities yet.</div>
        ) : (
          <div className="space-y-3">
            {topCommunities.map((c, i) => (
              <div key={c.name}>
                <div className="mb-1 flex items-center justify-between text-[13px]">
                  <span className="font-semibold text-foreground">{i + 1}. {c.name}</span>
                  <span className="font-bold text-foreground">{c.members.toLocaleString("en-IN")}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-surface border-[1.5px] border-[#0F0F0F]">
                  <div className="h-full rounded-full bg-coral" style={{ width: `${(c.members / maxMembers) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </AdminCard>

      {isSuperAdmin && (
        <>
          <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Revenue <Pill tone="gold">Super Admin</Pill></div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <StatCard label="MRR" value="₹0" delta="No paid plans active" deltaTone="warn" />
            <StatCard label="Pending Verifications" value={0} delta="Manual UPI review" deltaTone="warn" />
            <StatCard label="This Month" value="₹0" delta="Revenue MTD" />
          </div>
        </>
      )}
    </AdminPage>
  );
}
