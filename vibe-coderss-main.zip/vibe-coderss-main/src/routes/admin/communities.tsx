import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, MoreVertical, RefreshCw } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { AdminPage, AdminCard, TableWrap, TH, TD, Input, Select, Pill, EmptyState } from "@/components/admin/AdminUI";
import { listAdminCommunities } from "@/lib/admin-stats.functions";

export const Route = createFileRoute("/admin/communities")({
  head: () => ({ meta: [{ title: "Communities · VibeCode Admin" }] }),
  component: CommunitiesPage,
});

function CommunitiesPage() {
  const [search, setSearch] = useState("");
  const [privacy, setPrivacy] = useState<"all" | "public" | "private">("all");
  const [status, setStatus] = useState<"all" | "pending" | "approved" | "rejected">("all");

  const fetchCommunities = useServerFn(listAdminCommunities);
  const { data, isLoading, isFetching, refetch, error } = useQuery({
    queryKey: ["admin", "communities"],
    queryFn: () => fetchCommunities(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const all = data?.rows ?? [];
  const rows = useMemo(() => all.filter((c) =>
    (!search || c.name.toLowerCase().includes(search.toLowerCase())) &&
    (privacy === "all" || c.privacy === privacy) &&
    (status === "all" || c.status === status)
  ), [all, search, privacy, status]);

  const stats = {
    total: all.length,
    approved: all.filter((c) => c.status === "approved").length,
    pending: all.filter((c) => c.status === "pending").length,
    paid: all.filter((c) => c.pricing_type && c.pricing_type !== "free").length,
  };

  return (
    <AdminPage
      title="Community Management"
      subtitle={isLoading ? "Loading live communities…" : `${stats.total} real communities · auto-refresh every 60s`}
      actions={
        <button onClick={() => refetch()} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[13px] font-bold text-foreground hover:bg-surface">
          <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} /> Refresh
        </button>
      }
    >
      {error && <div className="mb-4 rounded-md border border-[#EF4444]/40 bg-[#EF4444]/10 px-3 py-2 text-[13px] font-bold text-[#F87171]">Couldn't load: {(error as Error).message}</div>}

      <div className="mb-5 flex flex-wrap gap-2">
        <Pill>Total: <span className="ml-1 font-extrabold text-foreground">{stats.total}</span></Pill>
        <Pill tone="success">Approved: <span className="ml-1 font-extrabold text-[#4ADE80]">{stats.approved}</span></Pill>
        <Pill tone="warn">Pending: <span className="ml-1 font-extrabold text-[#FBBF24]">{stats.pending}</span></Pill>
        <Pill tone="coral">Paid: <span className="ml-1 font-extrabold text-coral">{stats.paid}</span></Pill>
      </div>

      <AdminCard className="mb-4 p-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[240px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search communities…" className="w-full pl-9" />
          </div>
          <Select value={privacy} onChange={(e) => setPrivacy(e.target.value as any)}>
            <option value="all">All types</option><option value="public">Public</option><option value="private">Private</option>
          </Select>
          <Select value={status} onChange={(e) => setStatus(e.target.value as any)}>
            <option value="all">All statuses</option><option value="approved">Approved</option><option value="pending">Pending</option><option value="rejected">Rejected</option>
          </Select>
        </div>
      </AdminCard>

      {isLoading ? (
        <EmptyState title="Loading communities…" description="Fetching from the database." />
      ) : rows.length === 0 ? (
        <EmptyState title="No communities to show" description="Real communities will appear here as members create them." />
      ) : (
        <TableWrap>
          <thead>
            <tr><TH>Community</TH><TH>Members</TH><TH>Type</TH><TH>Pricing</TH><TH>Status</TH><TH>Created</TH><TH className="text-right">Actions</TH></tr>
          </thead>
          <tbody>
            {rows.map((c) => (
              <tr key={c.id} className="hover:bg-surface">
                <TD>
                  <div className="flex items-center gap-3">
                    {c.icon_url
                      ? <img src={c.icon_url} className="h-10 w-10 rounded-lg border border-white/10 object-cover" alt="" />
                      : <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-to-br from-coral to-[#F5A623] text-sm font-extrabold text-white">{c.name[0]}</div>}
                    <div>
                      <div className="flex items-center gap-2 font-semibold text-foreground">{c.name}{c.is_official && <Pill tone="info">✓ Official</Pill>}</div>
                      <div className="text-[11px] text-muted-foreground">/{c.slug} · by {c.created_by_name}</div>
                    </div>
                  </div>
                </TD>
                <TD className="font-semibold text-foreground">{c.member_count.toLocaleString("en-IN")}</TD>
                <TD className="capitalize text-foreground/80">{c.privacy}</TD>
                <TD>{c.pricing_type && c.pricing_type !== "free" ? <Pill tone="coral">{c.pricing_type}</Pill> : <Pill tone="success">FREE</Pill>}</TD>
                <TD><Pill tone={c.status === "approved" ? "success" : c.status === "pending" ? "warn" : "danger"}>{c.status}</Pill></TD>
                <TD className="text-[12px] text-muted-foreground">{new Date(c.created_at).toLocaleDateString("en-IN")}</TD>
                <TD className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger className="rounded-md border border-[#0F0F0F]/15 p-1.5 text-muted-foreground hover:bg-surface hover:text-foreground"><MoreVertical className="h-4 w-4" /></DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 border-[#0F0F0F]/15 bg-card text-foreground">
                      <DropdownMenuItem>👁 View Community</DropdownMenuItem>
                      <DropdownMenuItem>✓ Verify</DropdownMenuItem>
                      <DropdownMenuItem className="text-[#F87171]">⏸ Suspend</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TD>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
    </AdminPage>
  );
}
