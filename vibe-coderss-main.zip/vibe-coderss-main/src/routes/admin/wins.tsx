import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Check, Star, Trash2, ExternalLink } from "lucide-react";
import {
  fetchAllMomentsAdmin,
  updateMoment,
  deleteMoment,
  KIND_EMOJI,
  KIND_LABEL,
  type RealValueMoment,
} from "@/lib/rvm-api";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/wins")({
  head: () => ({ meta: [{ title: "Real Wins · Admin" }] }),
  component: AdminWinsPage,
});

function AdminWinsPage() {
  const [rows, setRows] = useState<RealValueMoment[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "pending" | "verified" | "featured">("pending");

  async function reload() {
    setLoading(true);
    setRows(await fetchAllMomentsAdmin());
    setLoading(false);
  }
  useEffect(() => {
    reload();
  }, []);

  const filtered = rows.filter((r) => {
    if (filter === "pending") return !r.verified;
    if (filter === "verified") return r.verified;
    if (filter === "featured") return r.featured;
    return true;
  });

  async function toggle(id: string, patch: Partial<RealValueMoment>) {
    try {
      await updateMoment(id, patch as any);
      await reload();
    } catch (e: any) {
      toast.error(e?.message ?? "Failed");
    }
  }

  async function remove(id: string) {
    if (!confirm("Delete this moment?")) return;
    await deleteMoment(id);
    await reload();
  }

  const counts = {
    pending: rows.filter((r) => !r.verified).length,
    verified: rows.filter((r) => r.verified).length,
    featured: rows.filter((r) => r.featured).length,
  };

  return (
    <div className="p-4 md:p-8">
      <div className="mb-4 flex items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-extrabold sm:text-3xl">Real Wins</h1>
          <p className="text-sm text-muted-foreground">
            The one metric that matters — verify & celebrate every real outcome.
          </p>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {(["pending", "verified", "featured", "all"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full border-[1.5px] border-foreground px-3 py-1 text-xs font-extrabold uppercase tracking-wider ${
              filter === f ? "bg-coral text-white shadow-[2px_2px_0_0_#0F0F0F]" : "bg-white"
            }`}
          >
            {f} {f !== "all" && <span className="ml-1 opacity-70">({(counts as any)[f]})</span>}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="py-20 text-center text-sm text-muted-foreground">Loading…</div>
      ) : (
        <div className="space-y-2">
          {filtered.length === 0 && (
            <div className="rounded-lg border-[1.5px] border-dashed border-foreground/30 p-10 text-center text-sm text-muted-foreground">
              Nothing here.
            </div>
          )}
          {filtered.map((m) => (
            <div
              key={m.id}
              className="flex flex-col gap-3 rounded-xl border-[1.5px] border-foreground bg-card p-4 sm:flex-row sm:items-start"
              style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  <span>
                    {KIND_EMOJI[m.kind]} {KIND_LABEL[m.kind]}
                  </span>
                  <span>· {new Date(m.created_at).toLocaleDateString()}</span>
                  <span>· source: {m.source}</span>
                  {m.verified && <span className="text-green-600">· ✓ verified</span>}
                  {m.featured && <span className="text-coral">· ⭐ featured</span>}
                </div>
                <div className="mt-1 font-display text-base font-extrabold">{m.title}</div>
                {m.description && (
                  <p className="mt-1 text-sm text-foreground/80">{m.description}</p>
                )}
                <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                  <span>
                    by{" "}
                    <b>
                      {m.profile?.display_name ?? m.profile?.username ?? m.user_id.slice(0, 8)}
                    </b>
                  </span>
                  {m.amount_inr && <span>₹{m.amount_inr.toLocaleString()}</span>}
                  {m.hours_saved && <span>{m.hours_saved}h saved</span>}
                  {m.evidence_url && (
                    <a
                      href={m.evidence_url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 font-bold text-coral hover:underline"
                    >
                      Evidence <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              </div>
              <div className="flex shrink-0 flex-wrap gap-2">
                <button
                  onClick={() => toggle(m.id, { verified: !m.verified })}
                  className={`inline-flex h-9 items-center gap-1 rounded-md border-[1.5px] border-foreground px-3 text-xs font-extrabold ${
                    m.verified ? "bg-green-500 text-white" : "bg-white"
                  }`}
                >
                  <Check className="h-3.5 w-3.5" /> {m.verified ? "Verified" : "Verify"}
                </button>
                <button
                  onClick={() => toggle(m.id, { featured: !m.featured })}
                  className={`inline-flex h-9 items-center gap-1 rounded-md border-[1.5px] border-foreground px-3 text-xs font-extrabold ${
                    m.featured ? "bg-coral text-white" : "bg-white"
                  }`}
                >
                  <Star className="h-3.5 w-3.5" /> {m.featured ? "Featured" : "Feature"}
                </button>
                <button
                  onClick={() => remove(m.id)}
                  className="inline-flex h-9 items-center gap-1 rounded-md border-[1.5px] border-foreground bg-white px-3 text-xs font-extrabold text-red-600"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
