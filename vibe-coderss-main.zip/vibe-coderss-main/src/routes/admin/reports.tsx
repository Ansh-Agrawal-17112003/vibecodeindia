import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AdminPage, AdminCard, Pill, EmptyState } from "@/components/admin/AdminUI";
import { RefreshCw } from "lucide-react";
import { listAdminReports, updateReportStatus } from "@/lib/admin-stats.functions";

export const Route = createFileRoute("/admin/reports")({
  head: () => ({ meta: [{ title: "Reports · VibeCode Admin" }] }),
  component: ReportsPage,
});

function ReportsPage() {
  const [tab, setTab] = useState<"open" | "all" | "resolved">("open");
  const fetchReports = useServerFn(listAdminReports);
  const updateStatus = useServerFn(updateReportStatus);
  const qc = useQueryClient();

  const { data, isLoading, isFetching, refetch, error } = useQuery({
    queryKey: ["admin", "reports", tab],
    queryFn: () => fetchReports({ data: { status: tab === "all" ? "all" : tab === "open" ? "open" : "resolved" } }),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const counts = data?.counts ?? { open: 0, in_progress: 0, resolved: 0, closed: 0, total: 0 };
  const rows = data?.rows ?? [];

  const resolve = async (id: string, status: "resolved" | "closed" | "in_progress") => {
    await updateStatus({ data: { id, status } });
    qc.invalidateQueries({ queryKey: ["admin", "reports"] });
  };

  return (
    <AdminPage
      title="Reports & Bug Reports"
      subtitle="Live from database · auto-refresh every 60s"
      actions={
        <button onClick={() => refetch()} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[13px] font-bold text-foreground hover:bg-surface">
          <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} /> Refresh
        </button>
      }
    >
      {error && <div className="mb-4 rounded-md border border-[#EF4444]/40 bg-[#EF4444]/10 px-3 py-2 text-[13px] font-bold text-[#F87171]">Couldn't load: {(error as Error).message}</div>}

      <div className="mb-5 flex flex-wrap gap-2">
        <Pill tone="warn">Open: <span className="ml-1 font-extrabold text-[#FBBF24]">{counts.open}</span></Pill>
        <Pill>In progress: <span className="ml-1 font-extrabold text-foreground">{counts.in_progress}</span></Pill>
        <Pill tone="success">Resolved: <span className="ml-1 font-extrabold text-[#4ADE80]">{counts.resolved}</span></Pill>
        <Pill>Total: <span className="ml-1 font-extrabold text-foreground">{counts.total}</span></Pill>
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-1 border-b border-[#0F0F0F]/15">
        {(["open", "all", "resolved"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2.5 text-[13px] font-bold capitalize ${tab === t ? "border-b-2 border-coral text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            {t}
          </button>
        ))}
      </div>

      {isLoading ? (
        <EmptyState title="Loading reports…" description="Fetching from the database." />
      ) : rows.length === 0 ? (
        <EmptyState icon="✅" title="No reports to review" description="Bug reports from users will appear here in real time." />
      ) : (
        <div className="space-y-3">
          {rows.map((r) => (
            <AdminCard key={r.id} className="p-5">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-[#0F0F0F]/15 pb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[12px] font-bold text-foreground">#{r.id.slice(0, 8)}</span>
                  <Pill tone={r.status === "open" ? "warn" : r.status === "resolved" ? "success" : "info"}>{r.status.replace("_", " ")}</Pill>
                </div>
                <span className="text-[12px] text-muted-foreground">{new Date(r.created_at).toLocaleString("en-IN")}</span>
              </div>
              <div className="mb-2 font-semibold text-foreground">{r.title}</div>
              <p className="mb-3 text-[13px] text-foreground/80">{r.description}</p>
              {r.page_url && <div className="mb-3 text-[12px] text-muted-foreground">📍 {r.page_url}</div>}
              <div className="text-[12px] text-muted-foreground">Reported by <span className="font-semibold text-foreground">{r.reporter_name}</span></div>
              {r.status !== "resolved" && r.status !== "closed" && (
                <div className="mt-4 flex flex-wrap gap-2 border-t border-[#0F0F0F]/15 pt-4">
                  <button onClick={() => resolve(r.id, "in_progress")} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#F59E0B]/40 bg-[#F59E0B]/10 px-3 text-[12px] font-bold text-[#FBBF24] hover:bg-[#F59E0B]/20">🔧 In Progress</button>
                  <button onClick={() => resolve(r.id, "resolved")} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#22C55E]/40 bg-[#22C55E]/10 px-3 text-[12px] font-bold text-[#4ADE80] hover:bg-[#22C55E]/20">✅ Resolve</button>
                  <button onClick={() => resolve(r.id, "closed")} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[12px] font-bold text-foreground hover:bg-surface">❌ Close</button>
                </div>
              )}
            </AdminCard>
          ))}
        </div>
      )}
    </AdminPage>
  );
}
