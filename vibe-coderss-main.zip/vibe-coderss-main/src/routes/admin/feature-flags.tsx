import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState } from "react";
import { AdminPage, AdminCard, Toggle, BtnGhost, Pill } from "@/components/admin/AdminUI";
import { featureFlags as seed } from "@/components/admin/adminMockData";
import { useAuth } from "@/hooks/useAuth";
import { Plus } from "lucide-react";

export const Route = createFileRoute("/admin/feature-flags")({
  head: () => ({ meta: [{ title: "Feature Flags · VibeCode Admin" }] }),
  component: Page,
});

function Page() {
  const { isSuperAdmin, loading } = useAuth();
  const [flags, setFlags] = useState(seed);
  const [confirm, setConfirm] = useState<{ key: string; next: boolean } | null>(null);

  if (loading) return null;
  if (!isSuperAdmin) return <Navigate to="/admin" replace />;

  const commit = () => {
    if (!confirm) return;
    setFlags((prev) => prev.map((f) => f.key === confirm.key ? { ...f, enabled: confirm.next, changedAgo: "just now", changedBy: "you" } : f));
    setConfirm(null);
  };

  return (
    <AdminPage
      title="Feature Flags"
      subtitle="Toggle features on/off without code deploys"
      actions={<BtnGhost><Plus className="h-3.5 w-3.5" /> Add New Flag</BtnGhost>}
    >
      <AdminCard>
        <ul className="divide-y divide-[#1E1E1E]">
          {flags.map((f) => (
            <li key={f.key} className="flex items-center justify-between gap-4 p-5">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{f.enabled ? "🟢" : "🔴"}</span>
                  <span className="font-display text-[14px] font-extrabold text-foreground">{f.label}</span>
                  <Pill tone={f.enabled ? "success" : "muted"}>{f.enabled ? "ON" : "OFF"}</Pill>
                </div>
                <div className="mt-1 text-[13px] text-muted-foreground">{f.description}</div>
                <div className="mt-1 text-[11px] text-muted-foreground">Last changed: {f.changedAgo} by {f.changedBy}</div>
              </div>
              <Toggle checked={f.enabled} onChange={(next) => setConfirm({ key: f.key, next })} />
            </li>
          ))}
        </ul>
      </AdminCard>

      {confirm && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4" onClick={() => setConfirm(null)}>
          <AdminCard onClick={(e) => e.stopPropagation()} className="w-full max-w-md p-6">
            <div className="font-display text-lg font-extrabold text-foreground">Are you sure?</div>
            <p className="mt-2 text-[13px] text-muted-foreground">This affects all users immediately. Toggling <span className="font-bold text-foreground">{flags.find((f) => f.key === confirm.key)?.label}</span> {confirm.next ? "ON" : "OFF"}.</p>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setConfirm(null)} className="inline-flex h-9 items-center rounded-md border border-[#0F0F0F]/15 bg-card px-3 text-[12px] font-bold text-foreground">Cancel</button>
              <button onClick={commit} className="inline-flex h-9 items-center rounded-md bg-coral px-3 text-[12px] font-bold text-white">Confirm</button>
            </div>
          </AdminCard>
        </div>
      )}
    </AdminPage>
  );
}
