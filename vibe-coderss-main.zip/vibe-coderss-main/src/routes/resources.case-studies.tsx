import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/resources/case-studies")({
  head: () => ({
    meta: [
      { title: "Case Studies · VibeCode" },
      { name: "description", content: "Real stories from the community — the projects, the DMs, the offer letters. No embellishment." },
      { property: "og:title", content: "Case Studies · VibeCode" },
      { property: "og:description", content: "Real stories from the community — the projects, the DMs, the offer letters. No embellishment." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/resources/case-studies" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/resources/case-studies" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Case Studies"
      breadcrumb={[{"label":"Resources","to":"/"}]}
      title="How builders got hired."
      intro="Real stories from the community — the projects, the DMs, the offer letters. No embellishment."
      toc={[{"id":"kinds","label":"What you will find"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="kinds" title="What you will find"><NotionFeatureGrid items={[{"title":"Zero to offer in 30 days","description":"The exact posts that landed the interview."},{"title":"Freelance to full-time","description":"How gigs became salaries."},{"title":"First AI job","description":"Bootcamp grads breaking into ML roles."},{"title":"Studio spotlights","description":"Agencies that scaled through VibeCode inbound."}]} /></NotionSection>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Can I submit my story?" a="Yes — every hired builder gets an invite to write theirs. Reply to the welcome email." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
