import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useState, useMemo } from "react";
import { Shell } from "@/components/site/Shell";
import { TemplateCard } from "@/components/cards/TemplateCard";
import { AutocompleteInput } from "@/components/site/AutocompleteInput";
import { StatsStrip } from "@/components/site/StatsStrip";
import { templates as mockTemplates, TEMPLATE_CATEGORIES, TEMPLATE_FRAMEWORKS } from "@/lib/mock-data";
import { useLiveTable, mapTemplate } from "@/lib/entity-live";

export const Route = createFileRoute("/templates")({
  head: () => ({
    meta: [
      { title: 'Templates Library · VibeCode' },
      { name: "description", content: "Ready-to-fork templates for Lovable, Cursor, n8n, Make and Bolt — built by India's vibe coders." },
      { property: "og:title", content: 'Templates Library · VibeCode' },
      { property: "og:description", content: "Ready-to-fork templates for Lovable, Cursor, n8n, Make and Bolt — built by India's vibe coders." },
      { property: "og:url", content: 'https://joinvibecode.xyz/templates' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Templates Library · VibeCode' },
      { name: "twitter:description", content: "Ready-to-fork templates for Lovable, Cursor, n8n, Make and Bolt — built by India's vibe coders." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/templates' }],
  }),
  component: TemplatesPage,
});

function TemplatesPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [fw, setFw] = useState("All");
  const dbRows = useLiveTable("templates", mapTemplate);
  const templates = useMemo(() => {
    const seen = new Set(dbRows.map((t) => t.id));
    return [...dbRows, ...mockTemplates.filter((t) => !seen.has(t.id))];
  }, [dbRows]);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    return templates.filter((t) =>
      (cat === "All" || t.category === cat) &&
      (fw === "All" || t.framework === fw) &&
      (!term || t.title.toLowerCase().includes(term) || t.description.toLowerCase().includes(term) || t.stack.some((s) => s.toLowerCase().includes(term)))
    );
  }, [q, cat, fw, templates]);

  return (
    <Shell>
      <div className="container-page py-5 sm:py-8">
        <div className="mb-6 text-center sm:text-left">
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground sm:text-xs">Library</div>
          <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight sm:text-3xl md:text-4xl">Templates Library</h1>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">{filtered.length} starter templates. Fork and ship in minutes.</p>
        </div>
        <div className="hidden sm:block">
          <StatsStrip items={[
            { label: "Templates", value: templates.length },
            { label: "Categories", value: TEMPLATE_CATEGORIES.length },
            { label: "Frameworks", value: TEMPLATE_FRAMEWORKS.length },
            { label: "Forks", value: 21400, suffix: "+" },
          ]} />
        </div>

        <div className="card-flat mb-5 flex items-center gap-3 p-2 pl-4">
          <Search className="h-4 w-4 text-muted-foreground" />
          <AutocompleteInput
            value={q}
            onChange={setQ}
            placeholder="Search templates..."
            typewriter={["Next.js SaaS starter...", "AI chatbot template...", "Landing page for startups...", "Dashboard with charts...", "E-commerce with Stripe..."]}
            suggestions={templates.flatMap((t) => [t.title, t.category, t.framework, ...t.stack])}
          />
        </div>
        <div className="hidden md:block">
          <div className="mb-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Category</div>
          <div className="mb-4 flex flex-wrap gap-2">
            {(["All", ...TEMPLATE_CATEGORIES] as string[]).map((c) => (
              <button key={c} onClick={() => setCat(c)} className={`rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1 text-xs font-bold transition ${cat === c ? "bg-coral text-white" : "bg-card text-foreground"}`} style={cat === c ? { boxShadow: "2px 2px 0 0 #0F0F0F" } : undefined}>{c}</button>
            ))}
          </div>
          <div className="mb-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Framework</div>
          <div className="mb-6 flex flex-wrap gap-2">
            {(["All", ...TEMPLATE_FRAMEWORKS] as string[]).map((f) => (
              <button key={f} onClick={() => setFw(f)} className={`rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1 text-xs font-bold transition ${fw === f ? "bg-gold text-[#0F0F0F]" : "bg-card text-foreground"}`} style={fw === f ? { boxShadow: "2px 2px 0 0 #0F0F0F" } : undefined}>{f}</button>
            ))}
          </div>
        </div>

        {filtered.length ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{filtered.map((t) => <TemplateCard key={t.id} t={t} />)}</div>
        ) : <div className="card-editorial p-12 text-center text-sm text-muted-foreground">No templates match.</div>}
      </div>
    </Shell>
  );
}
