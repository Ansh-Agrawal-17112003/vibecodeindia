import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Crown,
  Sparkles,
  MapPin,
  BadgeCheck,
  Linkedin,
  Twitter,
  Lock,
  ArrowRight,
  Award,
  Calendar,
} from "lucide-react";

export const Route = createFileRoute("/founders-wall")({
  head: () => ({
    meta: [
      { title: 'The Founders Wall · VibeCode OG Class of 2026' },
      { name: "description", content: "The public wall of VibeCode's OG founding members — the first 10,000 AI builders in India." },
      { property: "og:title", content: 'The Founders Wall · VibeCode OG Class of 2026' },
      { property: "og:description", content: "The public wall of VibeCode's OG founding members — the first 10,000 AI builders in India." },
      { property: "og:url", content: 'https://joinvibecode.xyz/founders-wall' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'The Founders Wall · VibeCode OG Class of 2026' },
      { name: "twitter:description", content: "The public wall of VibeCode's OG founding members — the first 10,000 AI builders in India." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/founders-wall' }],
  }),
  component: FoundersWallPage,
});

/* ============================================================
   Tokens — mirrors the early-access palette
   ============================================================ */
const C = {
  cream: "#FAF6F1",
  creamDeep: "#F3ECDF",
  white: "#FFFFFF",
  ink: "#0F0F0F",
  inkSoft: "#161616",
  border: "#E8E0D6",
  text: "#0F0F0F",
  muted: "#6B6357",
  coral: "#E8623A",
  coralSoft: "#FFF1EA",
  gold: "#F5A623",
  goldDeep: "#B7791F",
  goldSoft: "#FFF4D6",
};

const TOTAL_SPOTS = 100;

const TOOLS: Record<string, { l: string; c: string }> = {
  lovable: { l: "Lovable", c: "#8b5cf6" },
  cursor: { l: "Cursor", c: "#0ea5e9" },
  n8n: { l: "n8n", c: "#ef4444" },
  claude: { l: "Claude", c: "#E8623A" },
  make: { l: "Make", c: "#a855f7" },
  gpt4: { l: "GPT-4o", c: "#10a37f" },
  gemini: { l: "Gemini", c: "#4285f4" },
  midjourney: { l: "Midjourney", c: "#ec4899" },
  replit: { l: "Replit", c: "#f26207" },
  bolt: { l: "Bolt", c: "#facc15" },
  other: { l: "Other", c: "#E8623A" },
};

type WallMember = {
  og_number: number;
  full_name: string;
  city: string | null;
  state: string | null;
  wall_tagline: string | null;
  primary_tool: string | null;
  linkedin_url: string | null;
  twitter_url: string | null;
};

const avatarUrl = (seed: string) =>
  `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed || "og")}`;

/* ============================================================
   Page
   ============================================================ */
function FoundersWallPage() {
  const [wall, setWall] = useState<WallMember[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchWall = async () => {
    try {
      const { data } = await supabase
        .from("og_wall_public" as any)
        .select(
          "og_number, full_name, city, state, wall_tagline, primary_tool, linkedin_url, twitter_url",
        )
        .order("og_number", { ascending: true });
      if (data) setWall(data as any);
    } catch {
      /* silent — page still renders empty slots */
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWall();
    const id = setInterval(fetchWall, 20000);
    return () => clearInterval(id);
  }, []);

  // Realtime on og_members was removed to prevent leaking PII (email, IP,
  // user_agent) to anonymous subscribers via WAL broadcast. The 20s poll
  // above keeps the wall live for all visitors.


  const claimedByNumber = useMemo(() => {
    const map = new Map<number, WallMember>();
    for (const m of wall) map.set(m.og_number, m);
    return map;
  }, [wall]);

  const taken = wall.length;
  const remaining = Math.max(0, TOTAL_SPOTS - taken);
  const pct = Math.min(100, Math.round((taken / TOTAL_SPOTS) * 100));

  const slots = useMemo(
    () => Array.from({ length: TOTAL_SPOTS }, (_, i) => i + 1),
    [],
  );

  return (
    <div style={{ background: C.cream, color: C.text, minHeight: "100vh" }}>
      {/* =============== HERO (dark premium) =============== */}
      <section
        className="relative overflow-hidden"
        style={{
          background:
            `radial-gradient(1200px 500px at 50% -10%, rgba(245,166,35,0.22), transparent 60%),` +
            `radial-gradient(800px 400px at 90% 110%, rgba(232,98,58,0.18), transparent 55%),` +
            `linear-gradient(180deg, #0B0B0B 0%, #141311 60%, #191612 100%)`,
        }}
      >
        {/* Subtle diagonal gold shimmer */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-[0.06]"
          style={{
            backgroundImage:
              "repeating-linear-gradient(115deg, transparent 0 22px, rgba(245,166,35,0.9) 22px 23px)",
          }}
        />

        {/* Faint back link */}
        <div className="relative mx-auto max-w-[1200px] px-5 pt-6 sm:pt-8">
          <Link
            to="/early-access"
            className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-bold uppercase tracking-[0.16em] transition hover:-translate-y-0.5"
            style={{
              borderColor: "rgba(245,166,35,0.35)",
              color: C.goldSoft,
              background: "rgba(255,255,255,0.02)",
            }}
          >
            <ArrowRight className="h-3 w-3 rotate-180" />
            Back to Early Access
          </Link>
        </div>

        <div className="relative mx-auto max-w-[900px] px-5 pb-16 pt-10 text-center sm:pb-24 sm:pt-14">
          {/* Ornament */}
          <div className="mb-6 flex items-center justify-center gap-3">
            <span
              className="h-[1px] w-10"
              style={{
                background:
                  "linear-gradient(90deg, transparent, rgba(245,166,35,0.7))",
              }}
            />
            <span
              className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-extrabold uppercase tracking-[0.22em]"
              style={{
                borderColor: "rgba(245,166,35,0.5)",
                color: C.gold,
                background: "rgba(245,166,35,0.06)",
                textShadow: "0 0 24px rgba(245,166,35,0.5)",
              }}
            >
              <Crown className="h-3 w-3" />
              OG Class of 2026
            </span>
            <span
              className="h-[1px] w-10"
              style={{
                background:
                  "linear-gradient(90deg, rgba(245,166,35,0.7), transparent)",
              }}
            />
          </div>

          <h1
            className="fw-shine font-display font-extrabold leading-[0.98] tracking-[-0.02em]"
            style={{
              fontFamily:
                '"Bricolage Grotesque", system-ui, -apple-system, sans-serif',
              fontSize: "clamp(38px, 8.5vw, 92px)",
              backgroundImage:
                "linear-gradient(92deg, #FFF3D6 0%, #F5A623 30%, #FFE9A8 55%, #B7791F 78%, #FFF3D6 100%)",
              backgroundSize: "220% 100%",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
              WebkitTextFillColor: "transparent",
            }}
          >
            The Founders Wall
          </h1>

          <p
            className="mx-auto mt-6 max-w-[640px] text-[15px] leading-[1.75] sm:text-[17px]"
            style={{ color: "rgba(255,244,214,0.78)" }}
          >
            One hundred Indian AI builders. Each with a permanent badge, a permanent
            spot, and a permanent line in the story of{" "}
            <span style={{ color: C.gold, fontWeight: 700 }}>VibeCode</span>. The
            wall goes live on{" "}
            <span style={{ color: C.gold, fontWeight: 700 }}>August 4, 2026</span>
            {" "}— but the names below are already written in.
          </p>

          {/* Stat row */}
          <div className="mx-auto mt-10 grid max-w-[720px] grid-cols-3 overflow-hidden rounded-2xl border sm:mt-12"
            style={{
              borderColor: "rgba(245,166,35,0.28)",
              background:
                "linear-gradient(180deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01))",
              backdropFilter: "blur(6px)",
            }}
          >
            <Stat label="Claimed" value={loading ? "…" : String(taken).padStart(2, "0")} accent />
            <Stat label="Reserved" value={String(remaining).padStart(2, "0")} divider />
            <Stat label="Total" value="100" />
          </div>

          {/* Progress rail */}
          <div className="mx-auto mt-6 h-[6px] max-w-[720px] overflow-hidden rounded-full"
            style={{ background: "rgba(255,244,214,0.08)" }}
          >
            <div
              className="fw-progress h-full"
              style={{
                width: `${pct}%`,
                background:
                  "linear-gradient(90deg, #B7791F 0%, #F5A623 45%, #FFE9A8 75%, #F5A623 100%)",
                boxShadow: "0 0 16px rgba(245,166,35,0.55)",
              }}
            />
          </div>
          <div className="mt-2 text-[11px] font-bold uppercase tracking-[0.18em]"
            style={{ color: "rgba(255,244,214,0.55)" }}
          >
            <Calendar className="mr-1 inline-block h-3 w-3 -translate-y-[1px]" />
            Wall unlocks · Aug 4, 2026
          </div>
        </div>
      </section>

      {/* =============== WALL GRID =============== */}
      <section className="relative">
        {/* Cream ornament header */}
        <div className="mx-auto max-w-[1240px] px-5 pt-14 sm:pt-20">
          <div className="flex flex-col items-center text-center">
            <span
              className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-extrabold uppercase tracking-[0.16em]"
              style={{
                background: C.goldSoft,
                color: C.goldDeep,
                border: `1px solid ${C.gold}55`,
              }}
            >
              <Award className="h-3 w-3" />
              The Hundred
            </span>
            <h2
              className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
              style={{
                fontFamily:
                  '"Bricolage Grotesque", system-ui, -apple-system, sans-serif',
                fontSize: "clamp(24px, 4.6vw, 44px)",
                color: C.ink,
              }}
            >
              Every OG. Every seat. Every number — for life.
            </h2>
            <p
              className="mt-4 max-w-[560px] text-[14px] leading-[1.7] sm:text-[15px]"
              style={{ color: C.muted }}
            >
              Empty slots stay gilded until they're claimed. Once a name lands on
              the wall, it never leaves.
            </p>
          </div>
        </div>

        <div className="mx-auto max-w-[1240px] px-4 pb-24 pt-10 sm:px-5 sm:pt-14">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4 xl:grid-cols-5">
            {slots.map((n) => {
              const m = claimedByNumber.get(n);
              return m ? (
                <FilledCard key={n} m={m} />
              ) : (
                <EmptyCard key={n} n={n} />
              );
            })}
          </div>

          {/* Bottom CTA */}
          <div className="mt-16 flex flex-col items-center justify-center gap-4 text-center sm:mt-20">
            <div
              className="inline-flex items-center gap-2 rounded-full px-4 py-1 text-[11px] font-extrabold uppercase tracking-[0.2em]"
              style={{
                background: "#0F0F0F",
                color: C.gold,
                border: `1px solid ${C.ink}`,
                boxShadow: `2px 2px 0 0 ${C.gold}`,
              }}
            >
              {remaining} spots remaining
            </div>
            <h3
              className="font-display font-extrabold tracking-[-0.02em]"
              style={{
                fontFamily:
                  '"Bricolage Grotesque", system-ui, sans-serif',
                fontSize: "clamp(22px, 4vw, 34px)",
                color: C.ink,
              }}
            >
              Reserve your name on the wall.
            </h3>
            <Link
              to="/early-access"
              className="mt-2 inline-flex items-center gap-2 rounded-full px-6 py-3 text-[14px] font-extrabold uppercase tracking-[0.12em] transition-transform active:scale-95"
              style={{
                background: C.ink,
                color: C.white,
                border: `1.5px solid ${C.ink}`,
                boxShadow: `3px 3px 0 0 ${C.gold}`,
              }}
            >
              <Crown className="h-4 w-4" style={{ color: C.gold }} />
              Claim your OG spot
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Local styles for shine + shimmer */}
      <style>{`
        @keyframes fw-shine-move {
          0%   { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
        .fw-shine { animation: fw-shine-move 7s linear infinite; }

        @keyframes fw-progress-glow {
          0%,100% { filter: brightness(1); }
          50%     { filter: brightness(1.15); }
        }
        .fw-progress { animation: fw-progress-glow 2.6s ease-in-out infinite; }

        @keyframes fw-halo-spin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        .fw-halo {
          position: absolute;
          inset: -3px;
          border-radius: 9999px;
          background: conic-gradient(from 0deg, #F5A623, #FFE9A8, #B7791F, #F5A623);
          animation: fw-halo-spin 5.5s linear infinite;
          filter: blur(0.4px);
          z-index: 0;
        }

        @keyframes fw-empty-shimmer {
          0%   { background-position: -140% 0; }
          100% { background-position: 240% 0; }
        }
        .fw-empty-shimmer {
          position: absolute; inset: 0;
          background-image: linear-gradient(115deg, transparent 30%, rgba(245,166,35,0.18) 50%, transparent 70%);
          background-size: 220% 100%;
          animation: fw-empty-shimmer 4.5s ease-in-out infinite;
          pointer-events: none;
        }

        /* Golden shining OG badge */
        @keyframes fw-badge-shine {
          0%   { background-position: -160% 0; }
          100% { background-position: 260% 0; }
        }
        @keyframes fw-badge-pulse {
          0%,100% { box-shadow: 1px 1px 0 0 #0F0F0F, 0 0 0 0 rgba(245,166,35,0.55); }
          50%     { box-shadow: 1px 1px 0 0 #0F0F0F, 0 0 14px 2px rgba(245,166,35,0.65); }
        }
        @keyframes fw-badge-sweep {
          0%   { transform: translateX(-120%); }
          60%  { transform: translateX(220%); }
          100% { transform: translateX(220%); }
        }
        .fw-og-badge {
          position: relative;
          overflow: hidden;
          isolation: isolate;
          background-image: linear-gradient(100deg,
            #B7791F 0%, #F5A623 25%, #FFF3D6 45%, #FFE9A8 55%, #F5A623 75%, #B7791F 100%) !important;
          background-size: 220% 100% !important;
          animation: fw-badge-shine 3s linear infinite, fw-badge-pulse 2.8s ease-in-out infinite;
          color: #1a1408 !important;
        }
        .fw-og-badge::after {
          content: "";
          position: absolute; inset: 0;
          background: linear-gradient(115deg, transparent 40%, rgba(255,255,255,0.85) 50%, transparent 60%);
          transform: translateX(-120%);
          animation: fw-badge-sweep 2.6s ease-in-out infinite;
          pointer-events: none;
        }

        /* Card grid shine sweep */
        @keyframes fw-card-sweep {
          0%   { transform: translateX(-130%) skewX(-18deg); opacity: 0; }
          10%  { opacity: 1; }
          90%  { opacity: 1; }
          100% { transform: translateX(230%) skewX(-18deg); opacity: 0; }
        }
        @keyframes fw-card-idle {
          0%,10%  { transform: translateX(-130%) skewX(-18deg); opacity: 0; }
          50%     { opacity: 0.7; }
          90%,100%{ transform: translateX(230%) skewX(-18deg); opacity: 0; }
        }
        .fw-card-shine {
          position: absolute; inset: 0;
          pointer-events: none;
          overflow: hidden;
          border-radius: inherit;
          z-index: 3;
        }
        .fw-card-shine::before {
          content: "";
          position: absolute;
          top: 0; bottom: 0; left: 0;
          width: 45%;
          background: linear-gradient(90deg,
            transparent 0%,
            rgba(255,244,214,0.35) 40%,
            rgba(245,166,35,0.55) 50%,
            rgba(255,244,214,0.35) 60%,
            transparent 100%);
          mix-blend-mode: screen;
          transform: translateX(-130%) skewX(-18deg);
          animation: fw-card-idle 6s ease-in-out infinite;
        }
        .fw-card-lift:hover .fw-card-shine::before {
          animation: fw-card-sweep 1s ease-out;
        }

        .fw-card-lift { transition: transform 260ms cubic-bezier(0.22,1,0.36,1), box-shadow 260ms; }
        .fw-card-lift:hover {
          transform: translateY(-3px);
          box-shadow: 4px 5px 0 0 #0F0F0F, 0 10px 28px -10px rgba(245,166,35,0.55) !important;
        }
      `}</style>
    </div>
  );
}

/* ============================================================
   Stat cell (hero)
   ============================================================ */
function Stat({
  label,
  value,
  accent,
  divider,
}: {
  label: string;
  value: string;
  accent?: boolean;
  divider?: boolean;
}) {
  return (
    <div
      className="flex flex-col items-center justify-center py-5"
      style={{
        borderLeft: divider ? "1px solid rgba(245,166,35,0.18)" : undefined,
        borderRight: divider ? "1px solid rgba(245,166,35,0.18)" : undefined,
      }}
    >
      <div
        className="font-display text-3xl font-extrabold sm:text-4xl"
        style={{
          fontFamily: '"Bricolage Grotesque", system-ui, sans-serif',
          color: accent ? C.gold : "rgba(255,244,214,0.92)",
          textShadow: accent ? "0 0 24px rgba(245,166,35,0.35)" : undefined,
        }}
      >
        {value}
      </div>
      <div
        className="mt-1 text-[10px] font-extrabold uppercase tracking-[0.22em]"
        style={{ color: "rgba(255,244,214,0.55)" }}
      >
        {label}
      </div>
    </div>
  );
}

/* ============================================================
   Filled OG card
   ============================================================ */
function FilledCard({ m }: { m: WallMember }) {
  const tool = m.primary_tool ? TOOLS[m.primary_tool] : undefined;
  const location = [m.city, m.state].filter(Boolean).join(", ");
  return (
    <div
      className="fw-card-lift group relative flex flex-col overflow-hidden rounded-[16px] p-4 sm:p-5"
      style={{
        background: `linear-gradient(180deg, ${C.white} 0%, ${C.goldSoft} 100%)`,
        border: `1.5px solid ${C.ink}`,
        boxShadow: `3px 3px 0 0 ${C.ink}`,
      }}
    >
      {/* Gold gradient inner frame */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-[1px] rounded-[15px]"
        style={{
          background:
            "linear-gradient(180deg, rgba(245,166,35,0.35), rgba(245,166,35,0) 40%)",
        }}
      />
      {/* Sparkle */}
      <Sparkles
        className="absolute right-2.5 top-2.5 h-3.5 w-3.5 z-[3]"
        style={{ color: C.gold, filter: "drop-shadow(0 0 6px rgba(245,166,35,0.6))" }}
      />


      {/* Top row: OG number + tool */}
      <div className="relative z-[2] flex items-center justify-between gap-2">
        <span
          className="fw-og-badge inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-[0.14em]"
          style={{
            border: `1px solid ${C.ink}`,
            boxShadow: `1px 1px 0 0 ${C.ink}`,
            textShadow: "0 1px 0 rgba(255,255,255,0.45)",
          }}
        >
          <Crown className="h-2.5 w-2.5" />
          OG #{String(m.og_number).padStart(2, "0")}
        </span>
        {tool && (
          <span
            className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold"
            style={{
              background: C.white,
              color: C.ink,
              border: `1px solid ${C.border}`,
            }}
          >
            <span
              className="h-1.5 w-1.5 rounded-full"
              style={{ background: tool.c, boxShadow: `0 0 6px ${tool.c}` }}
            />
            {tool.l}
          </span>
        )}
      </div>

      {/* Avatar w/ gold halo */}
      <div className="relative z-[2] mt-4 h-14 w-14 sm:h-16 sm:w-16">
        <span className="fw-halo" aria-hidden />
        <img
          src={avatarUrl(m.full_name)}
          alt=""
          loading="lazy"
          className="relative h-14 w-14 rounded-full sm:h-16 sm:w-16"
          style={{
            background: C.white,
            border: `2px solid ${C.ink}`,
            boxShadow: `0 0 0 2px ${C.white}`,
          }}
        />
        <BadgeCheck
          className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full"
          style={{
            color: C.white,
            fill: C.goldDeep,
            background: C.white,
            borderRadius: "9999px",
          }}
        />
      </div>

      {/* Name */}
      <div className="relative z-[2] mt-3 font-display text-[15px] font-extrabold leading-tight text-[color:var(--ink)]"
        style={{ color: C.ink }}
      >
        <span className="line-clamp-1">{m.full_name}</span>
      </div>
      {location && (
        <div
          className="relative z-[2] mt-0.5 flex items-center gap-1 text-[11px] font-semibold"
          style={{ color: C.muted }}
        >
          <MapPin className="h-2.5 w-2.5" style={{ color: C.coral }} />
          <span className="line-clamp-1">{location}</span>
        </div>
      )}

      {m.wall_tagline && (
        <p
          className="relative z-[2] mt-2 text-[12px] italic leading-[1.5] line-clamp-2"
          style={{ color: C.muted }}
        >
          “{m.wall_tagline}”
        </p>
      )}

      {/* Social */}
      {(m.linkedin_url || m.twitter_url) && (
        <div className="relative z-[2] mt-3 flex items-center gap-1.5">
          {m.linkedin_url && (
            <a
              href={m.linkedin_url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex h-6 w-6 items-center justify-center rounded-full transition hover:-translate-y-0.5"
              style={{
                background: C.white,
                border: `1px solid ${C.border}`,
                color: "#0A66C2",
              }}
              aria-label="LinkedIn"
            >
              <Linkedin className="h-3 w-3" />
            </a>
          )}
          {m.twitter_url && (
            <a
              href={m.twitter_url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex h-6 w-6 items-center justify-center rounded-full transition hover:-translate-y-0.5"
              style={{
                background: C.white,
                border: `1px solid ${C.border}`,
                color: C.ink,
              }}
              aria-label="Twitter / X"
            >
              <Twitter className="h-3 w-3" />
            </a>
          )}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   Empty (reserved) card
   ============================================================ */
function EmptyCard({ n }: { n: number }) {
  return (
    <div
      className="relative flex flex-col items-center justify-center overflow-hidden rounded-[16px] p-5"
      style={{
        minHeight: 190,
        background:
          `linear-gradient(180deg, ${C.white} 0%, ${C.creamDeep} 100%)`,
        border: `1.5px dashed ${C.gold}`,
      }}
    >
      <span className="fw-empty-shimmer" aria-hidden />

      <span
        className="relative inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-[0.16em]"
        style={{
          background: C.white,
          color: C.goldDeep,
          border: `1px solid ${C.gold}88`,
        }}
      >
        <Lock className="h-2.5 w-2.5" />
        Reserved
      </span>

      <div
        className="relative mt-4 font-display text-4xl font-extrabold leading-none sm:text-5xl"
        style={{
          fontFamily: '"Bricolage Grotesque", system-ui, sans-serif',
          backgroundImage:
            "linear-gradient(180deg, #F5A623 0%, #B7791F 100%)",
          WebkitBackgroundClip: "text",
          backgroundClip: "text",
          color: "transparent",
          WebkitTextFillColor: "transparent",
          letterSpacing: "-0.02em",
        }}
      >
        #{String(n).padStart(2, "0")}
      </div>

      <div
        className="relative mt-3 text-[10px] font-bold uppercase tracking-[0.18em]"
        style={{ color: C.goldDeep }}
      >
        Awaiting Builder
      </div>
    </div>
  );
}
