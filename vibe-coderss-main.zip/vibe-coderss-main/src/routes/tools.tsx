import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useState, useMemo } from "react";
import { Shell } from "@/components/site/Shell";
import { ToolCard } from "@/components/cards/ToolCard";
import { AutocompleteInput } from "@/components/site/AutocompleteInput";
import { StatsStrip } from "@/components/site/StatsStrip";
import { tools as mockTools, TOOL_CATEGORIES } from "@/lib/mock-data";
import { useLiveTable, mapTool } from "@/lib/entity-live";

export const Route = createFileRoute("/tools")({
  head: () => ({
    meta: [
      { title: 'AI Tools Directory · VibeCode' },
      { name: "description", content: 'Discover the AI tools Indian builders actually ship with — reviews, categories and real-world use cases.' },
      { property: "og:title", content: 'AI Tools Directory · VibeCode' },
      { property: "og:description", content: 'Discover the AI tools Indian builders actually ship with — reviews, categories and real-world use cases.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/tools' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'AI Tools Directory · VibeCode' },
      { name: "twitter:description", content: 'Discover the AI tools Indian builders actually ship with — reviews, categories and real-world use cases.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/tools' }],
  }),
  component: ToolsPage,
});

const PRICES = ["Free", "Freemium", "Paid"] as const;

function ToolsPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [prices, setPrices] = useState<string[]>([]);
  const dbRows = useLiveTable("ai_tools", mapTool);
  const tools = useMemo(() => {
    const seen = new Set(dbRows.map((t) => t.id));
    return [...dbRows, ...mockTools.filter((t) => !seen.has(t.id))];
  }, [dbRows]);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    return tools.filter((t) =>
      (cat === "All" || t.category === cat) &&
      (!prices.length || prices.includes(t.pricing)) &&
      (!term || t.name.toLowerCase().includes(term) || t.tagline.toLowerCase().includes(term) || t.category.toLowerCase().includes(term))
    );
  }, [q, cat, prices, tools]);

  return (
    <Shell>
      <div className="container-page py-5 sm:py-8">
        <div className="mb-6 text-center sm:text-left">
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground sm:text-xs">Library</div>
          <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight sm:text-3xl md:text-4xl">AI Tools Directory</h1>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">{filtered.length} of {tools.length} AI tools curated by Indian builders.</p>
        </div>
        <div className="hidden sm:block">
          <StatsStrip items={[
            { label: "AI Tools", value: tools.length },
            { label: "Categories", value: TOOL_CATEGORIES.length },
            { label: "Free Picks", value: tools.filter((t) => t.pricing === "Free").length },
            { label: "Monthly Visits", value: 92000, suffix: "+" },
          ]} />
        </div>
        <div className="card-flat mb-5 flex items-center gap-3 p-2 pl-4">
          <Search className="h-4 w-4 text-muted-foreground" />
          <AutocompleteInput
            value={q}
            onChange={setQ}
            placeholder="Search tools..."
            typewriter={["Image generator like Midjourney...", "Free AI writing tool...", "Video editor with AI...", "No-code app builder...", "Voice cloning tool..."]}
            suggestions={tools.flatMap((t) => [t.name, t.category])}
          />
        </div>
        <div className="mb-4 hidden flex-wrap gap-2 sm:flex">
          {(["All", ...TOOL_CATEGORIES] as string[]).map((c) => (
            <button key={c} onClick={() => setCat(c)} className={`rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1 text-xs font-bold transition ${cat === c ? "bg-coral text-white" : "bg-card text-foreground"}`} style={cat === c ? { boxShadow: "2px 2px 0 0 #0F0F0F" } : undefined}>{c}</button>
          ))}
        </div>
        <div className="mb-6 hidden flex-wrap gap-2 sm:flex">
          {PRICES.map((p) => {
            const on = prices.includes(p);
            return (
              <button key={p} onClick={() => setPrices((arr) => on ? arr.filter((x) => x !== p) : [...arr, p])} className={`rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1 text-xs font-bold transition ${on ? "bg-gold text-[#0F0F0F]" : "bg-card text-foreground"}`} style={on ? { boxShadow: "2px 2px 0 0 #0F0F0F" } : undefined}>{p}</button>
            );
          })}
        </div>

        {filtered.length ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">{filtered.map((t) => <ToolCard key={t.id} t={t} />)}</div>
        ) : <div className="card-editorial p-12 text-center text-sm text-muted-foreground">No tools match.</div>}
      </div>
    </Shell>
  );
}
