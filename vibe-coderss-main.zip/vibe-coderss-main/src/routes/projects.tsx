import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { ProjectCard } from "@/components/cards/ProjectCard";
import { projects } from "@/lib/mock-data";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: 'Trending Projects · VibeCode' },
      { name: "description", content: 'The best AI projects shipping out of India this week — with source, stack and builder profiles.' },
      { property: "og:title", content: 'Trending Projects · VibeCode' },
      { property: "og:description", content: 'The best AI projects shipping out of India this week — with source, stack and builder profiles.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/projects' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Trending Projects · VibeCode' },
      { name: "twitter:description", content: 'The best AI projects shipping out of India this week — with source, stack and builder profiles.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/projects' }],
  }),
  component: ProjectsPage,
});

const SORTS = ["Trending", "Newest", "Most upvoted"] as const;

function ProjectsPage() {
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<(typeof SORTS)[number]>("Trending");

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    let list = projects.slice();
    if (needle) {
      list = list.filter((p) => {
        const hay = `${p.title ?? ""} ${p.description ?? ""} ${(p.tools ?? []).join(" ")} ${p.industry ?? ""}`.toLowerCase();
        return hay.includes(needle);
      });
    }
    if (sort === "Most upvoted") {
      list.sort((a: any, b: any) => (b.upvotes ?? 0) - (a.upvotes ?? 0));
    } else if (sort === "Newest") {
      list.reverse();
    }
    return list;
  }, [q, sort]);

  return (
    <Shell>
      <section className="container-page py-8 sm:py-10">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight">Trending Projects</h1>
            <p className="mt-2 text-sm text-muted-foreground sm:text-base">
              Real projects shipped by AI builders. Upvote what inspires you.
            </p>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search projects…"
                className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card pl-9 pr-3 text-sm outline-none sm:w-72"
              />
            </div>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as (typeof SORTS)[number])}
              className="h-11 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm font-semibold outline-none"
            >
              {SORTS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="mt-6 card-editorial bg-gold/20 p-4 text-sm font-semibold text-foreground sm:text-base">
          🚧 This section is under construction right now. We'll let you know when it goes live.
        </div>

        <div className="mt-6 grid gap-4 sm:gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => <ProjectCard key={p.id} p={p} />)}
        </div>

        {filtered.length === 0 && (
          <div className="mt-16 grid place-items-center text-center">
            <p className="text-sm text-muted-foreground">No projects match "{q}".</p>
          </div>
        )}
      </section>
    </Shell>
  );
}
