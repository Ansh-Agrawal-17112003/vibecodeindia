import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Check, Sparkles } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { UpgradeModal } from "@/components/site/UpgradeModal";
import { useAuth } from "@/hooks/useAuth";
import { useSubscription, usePlatformSettings } from "@/hooks/useSubscription";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: 'Pricing · VibeCode' },
      { name: "description", content: 'Free forever for builders. Simple, transparent pricing for Pro members and hiring companies.' },
      { property: "og:title", content: 'Pricing · VibeCode' },
      { property: "og:description", content: 'Free forever for builders. Simple, transparent pricing for Pro members and hiring companies.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/pricing' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Pricing · VibeCode' },
      { name: "twitter:description", content: 'Free forever for builders. Simple, transparent pricing for Pro members and hiring companies.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/pricing' }],
  }),
  component: PricingPage,
});

function PricingPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { plan, refresh } = useSubscription();
  const { settings } = usePlatformSettings();
  const [openPlan, setOpenPlan] = useState<"pro" | "business" | null>(null);

  const proPrice = Number(settings.pro_plan_price ?? "499");
  const bizPrice = Number(settings.business_plan_price ?? "2999");

  const requestUpgrade = (target: "pro" | "business") => {
    if (!user) {
      navigate({ to: "/auth" });
      return;
    }
    setOpenPlan(target);
  };

  const plans = [
    {
      key: "free" as const,
      name: "Builder",
      price: "₹0",
      per: "forever",
      desc: "Everything an AI builder needs to ship.",
      features: [
        "Full profile + portfolio",
        "Unlimited job applications",
        "Join all 450+ communities",
        "Browse prompts, tools & workflows",
      ],
      cta: "Current plan",
      action: null,
    },
    {
      key: "pro" as const,
      name: "Pro",
      price: `₹${proPrice}`,
      per: "per month",
      desc: "For freelancers winning more clients.",
      features: [
        "Everything in Builder",
        "Unlimited builder search & profile views",
        "Top of search results",
        "Verified badge & featured slots",
        "Advanced analytics",
        "Priority support",
      ],
      popular: true,
      cta: plan === "pro" ? "Active" : "Upgrade to Pro",
      action: () => requestUpgrade("pro"),
    },
    {
      key: "business" as const,
      name: "Business",
      price: `₹${bizPrice}`,
      per: "per month",
      desc: "For founders & agencies hiring at scale.",
      features: [
        "Everything in Pro",
        "Featured job posts",
        "Team seats (3)",
        "Saved candidate pools",
        "Dedicated hiring manager",
        "Priority moderation",
      ],
      cta: plan === "business" ? "Active" : "Upgrade to Business",
      action: () => requestUpgrade("business"),
    },
  ];

  return (
    <Shell>
      <section className="container-page py-12 md:py-16">
        <div className="mx-auto max-w-3xl text-center">
          <span className="pill-badge bg-gold text-[#0F0F0F]">
            <Sparkles className="h-3.5 w-3.5" /> Pricing
          </span>
          <h1 className="mt-4 font-display text-4xl font-extrabold uppercase tracking-tight md:text-6xl">
            Free for builders.<br />Pro for the serious.
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Builders ship free, forever. Hirers and freelancers upgrade to unlock unlimited search & featured listings.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {plans.map((p) => {
            const isCurrent = plan === p.key;
            return (
              <div
                key={p.key}
                className={`relative flex flex-col rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-7 shadow-[6px_6px_0_0_#0F0F0F] ${
                  p.popular ? "lg:-translate-y-3 lg:scale-[1.02]" : ""
                }`}
              >
                {p.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1 text-xs font-bold uppercase text-white">
                    Most Popular
                  </span>
                )}
                <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{p.name}</div>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="font-display text-5xl font-extrabold">{p.price}</span>
                  <span className="text-sm text-muted-foreground">/{p.per.replace("per ", "")}</span>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>

                <ul className="mt-6 flex-1 space-y-2.5">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-coral" /> {f}
                    </li>
                  ))}
                </ul>

                <button
                  disabled={!p.action || isCurrent}
                  onClick={() => p.action?.()}
                  className={`mt-7 w-full rounded-lg border-[1.5px] border-[#0F0F0F] px-4 py-3 text-sm font-bold uppercase transition disabled:cursor-not-allowed disabled:opacity-60 ${
                    p.popular
                      ? "bg-coral text-white hover:shadow-[4px_4px_0_0_#0F0F0F]"
                      : "bg-white hover:bg-cream hover:shadow-[4px_4px_0_0_#0F0F0F]"
                  }`}
                >
                  {isCurrent ? "Active plan" : p.cta}
                </button>
              </div>
            );
          })}
        </div>

        <div className="mx-auto mt-12 max-w-2xl rounded-xl border-[1.5px] border-dashed border-[#0F0F0F]/40 bg-cream p-5 text-center text-sm text-muted-foreground">
          Payments are confirmed manually within 24 hours. You can renew anytime from{" "}
          <Link to="/settings" className="font-bold text-coral underline">Settings → Billing</Link>.
        </div>
      </section>

      {openPlan && (
        <UpgradeModal
          open={!!openPlan}
          onOpenChange={(o) => !o && setOpenPlan(null)}
          plan={openPlan}
          onSubmitted={refresh}
        />
      )}
    </Shell>
  );
}
