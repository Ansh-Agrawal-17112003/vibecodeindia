import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { BadgeCheck, MapPin, MessageSquare, Share2, UserPlus, Star, Zap, Trophy, Flame, Calendar, TrendingUp, Github, Linkedin, Globe, Twitter, ArrowUpRight, Sparkles, Target, Award, CheckCircle2, Clock, Rocket } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { ProjectCard } from "@/components/cards/ProjectCard";
import { ServiceCard } from "@/components/cards/ServiceCard";
import { PromptCard } from "@/components/cards/PromptCard";
import { WorkflowCard } from "@/components/cards/WorkflowCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Counter } from "@/components/site/Counter";
import { builders, getBuilderByUsername, projects, services, prompts, workflows, communities } from "@/lib/mock-data";
import { sharePage } from "@/lib/share";
import { RealUserProfile } from "@/components/profile/RealUserProfile";

export const Route = createFileRoute("/u/$username")({
  loader: ({ params }) => {
    const b = getBuilderByUsername(params.username);
    if (!b) throw notFound();
    return { builder: b };
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.builder.name} · vibecoder` }] }),
  component: Profile,
  notFoundComponent: () => {
    const { username } = Route.useParams();
    return <RealUserProfile username={username} />;
  },
});

const ACCENT = ["#E8623A", "#F5A623", "#2DD4BF", "#7C3AED", "#0F0F0F"];

function Profile() {
  const { builder: b } = Route.useLoaderData();
  const idx = parseInt(b.id) || 1;
  const accent = ACCENT[idx % ACCENT.length];
  const builderProjects = projects.filter((p) => p.builderId === b.id);
  const builderServices = services.filter((s) => s.builderId === b.id);
  const builderPrompts = prompts.filter((p) => p.builderId === b.id);
  const builderWorkflows = workflows.filter((w) => w.builderId === b.id);
  const similar = builders.filter((x) => x.id !== b.id).slice(0, 4);

  // Follow state (localStorage) — with live follower count
  const followKey = `vc.follow.${b.id}`;
  const [following, setFollowing] = useState(false);
  const [liveFollowers, setLiveFollowers] = useState(b.followers);
  useEffect(() => {
    try {
      const isF = localStorage.getItem(followKey) === "1";
      setFollowing(isF);
      setLiveFollowers(b.followers + (isF ? 1 : 0));
    } catch { /* ignore */ }
  }, [followKey, b.followers]);
  const toggleFollow = () => {
    const next = !following;
    setFollowing(next);
    setLiveFollowers((n: number) => n + (next ? 1 : -1));
    try { next ? localStorage.setItem(followKey, "1") : localStorage.removeItem(followKey); } catch { /* ignore */ }
    toast.success(next ? `You're now following ${b.name}` : `Unfollowed ${b.name}`);
  };
  const onShare = () => sharePage(`${b.name} · vibecoder`, b.bio);

  const navigate = useNavigate();
  const requestToHire = () => {
    const draft = `Hi ${b.name.split(" ")[0]}, I'd like to hire you.\n\nProject: [brief description]\nTimeline: [when you need it]\nBudget: around ₹${b.hourlyRate.toLocaleString("en-IN")}/hr\n\nAre you available to discuss? Thanks!`;
    try {
      sessionStorage.setItem(`vc.hireDraft.${b.id}`, draft);
      sessionStorage.setItem(`vc.hireAutoSend.${b.id}`, "1");
    } catch { /* ignore */ }
    toast.success(`Opening chat with ${b.name}…`);
    navigate({ to: "/messages", search: { to: b.id } });
  };

  const activities = [
    { icon: Sparkles, label: `Shipped a new project`, time: "2 days ago", color: "#E8623A" },
    { icon: Trophy, label: `Reached top 1% builders in ${b.industry[0]}`, time: "1 week ago", color: "#F5A623" },
    { icon: Star, label: `Received a 5★ review from a client`, time: "2 weeks ago", color: "#2DD4BF" },
    { icon: UserPlus, label: `Gained 120+ new followers`, time: "3 weeks ago", color: "#7C3AED" },
    { icon: Zap, label: `Launched ${b.tools[0]} workflow template`, time: "1 month ago", color: "#0F0F0F" },
  ];

  const testimonials = Array.from({ length: 6 }).map((_, i) => ({
    name: ["Ravi K.", "Meera S.", "Arjun P.", "Divya R.", "Karan M.", "Neha J."][i],
    role: ["Founder, Zapstack", "PM, Razorpay", "CTO, Kite", "Design Lead", "Solo Dev", "Growth, Meesho"][i],
    text: [
      "Delivered ahead of schedule with pixel-perfect polish. Would hire again in a heartbeat.",
      "The prompts and workflows saved my team 30+ hours a week. Complete pro.",
      "Communication was crisp, output was 10/10. Rare combo.",
      "Understood our brand instantly and shipped something we couldn't have imagined.",
      "Genuinely the best builder I've worked with in the AI space in India.",
      "Ridiculously fast turnaround and the quality is enterprise-grade.",
    ][i],
    seed: `rev-${b.id}-${i}`,
  }));

  const achievements = [
    { icon: "🥇", label: "Top 1% Builder", meta: `In ${b.industry[0]}` },
    { icon: "🚀", label: `${b.projects}+ Shipped`, meta: "Live projects" },
    { icon: "🔥", label: "30-day Streak", meta: "Daily builder" },
    { icon: "✨", label: b.verified ? "Verified" : "Rising Star", meta: "vibecoder" },
    { icon: "💎", label: "Client Favorite", meta: `${b.rating}★ avg` },
    { icon: "🎯", label: `${b.followers > 1000 ? "1K+" : b.followers} Followers`, meta: "Community" },
  ];

  return (
    <Shell>
      {/* Banner */}
      <div className="relative h-28 w-full sm:h-40" style={{ background: accent }}>
        <div className="absolute inset-0 opacity-[0.08] [background-image:radial-gradient(#0F0F0F_1px,transparent_1px)] [background-size:14px_14px]" />
      </div>

      <div className="container-page">
        {/* Header — avatar sits inside the same card as name/title */}
        <div className="mt-6 sm:mt-8">
          <div className="card-editorial p-4 sm:p-6">
            <div className="grid grid-cols-1 items-start gap-4 sm:grid-cols-[auto_minmax(0,1fr)_auto]">
              <img
                src={b.avatar}
                alt={b.name}
                className="h-20 w-20 rounded-2xl border-[1.5px] border-[#0F0F0F] bg-cream object-cover sm:h-28 sm:w-28"
              />
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="truncate font-display text-xl font-black tracking-tight sm:text-3xl">{b.name}</h1>
                  {b.verified && <BadgeCheck className="h-5 w-5 shrink-0 text-coral" />}
                  <span className="pill-badge bg-foreground text-white">{b.type}</span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground sm:text-base">{b.title}</p>
                <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" /> {b.location}</span>
                  <span className="inline-flex items-center gap-1"><Star className="h-3 w-3 fill-golden text-golden" /> {b.rating} · {b.reviews} reviews</span>
                  {b.available && (
                    <span className="inline-flex items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-[#2DD4BF]/20 px-2 py-0.5 font-bold text-foreground">
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#0a9c8a]" /> Available
                    </span>
                  )}
                </div>
              </div>
              <div className="flex flex-wrap gap-2 sm:justify-end">
                <button onClick={() => toast.success(`Hire request sent to ${b.name}`)} className="btn-coral h-10 !px-4 text-sm">Hire Me</button>
                <Link to="/messages" search={{ to: b.id }} className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-4 py-2 text-sm font-bold hover:bg-cream">
                  <MessageSquare className="h-4 w-4" /> Message
                </Link>
                <button
                  onClick={toggleFollow}
                  className={`inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] px-4 py-2 text-sm font-bold hover:opacity-90 ${following ? "bg-foreground text-white" : "bg-card hover:bg-cream"}`}
                >
                  <UserPlus className="h-4 w-4" /> {following ? "Following" : "Follow"}
                </button>
                <button onClick={onShare} aria-label="Share profile" className="grid h-10 w-10 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-card hover:bg-cream">
                  <Share2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>


        {/* Stats strip — flat, borders only */}
        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-5">
          {[
            { l: "Projects", v: b.projects, icon: Zap },
            { l: "Services", v: builderServices.length || 4, icon: Target },
            { l: "Followers", v: liveFollowers, icon: UserPlus },
            { l: "Reviews", v: b.reviews, icon: Star },
            { l: "Rate /hr", v: b.hourlyRate, prefix: "₹", icon: TrendingUp },
          ].map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.l} className="card-flat p-3 sm:p-4">
                <Icon className="h-4 w-4 text-coral" />
                <div className="mt-1 font-display text-xl font-black tracking-tight sm:text-2xl">
                  <Counter to={s.v} prefix={s.prefix} />
                </div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground sm:text-[11px]">{s.l}</div>
              </div>
            );
          })}
        </div>

        {/* Main grid */}
        <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
          <div className="min-w-0">
            <Tabs defaultValue="about">
              <TabsList className="w-full">
                {["about", "portfolio", "services", "prompts", "workflows", "reviews"].map((t) => (
                  <TabsTrigger key={t} value={t} className="capitalize">{t}</TabsTrigger>
                ))}
              </TabsList>

              <TabsContent value="about" className="space-y-5 py-5">
                <SectionBox title="About Me">
                  <p className="text-sm leading-relaxed sm:text-base">{b.bio}</p>
                  <p className="mt-3 text-sm leading-relaxed text-foreground/85 sm:text-base">
                    I'm a <b>{b.title}</b> based in {b.location} with {b.projects}+ shipped projects across {b.industry.join(", ")}.
                    I work end-to-end — from problem framing and prototyping to production launch — using {b.tools.slice(0, 3).join(", ")} and modern AI stacks.
                    Most of my clients are founders, product teams, and operators who want senior-level output without the agency overhead.
                  </p>
                </SectionBox>

                <SectionBox title="What I Do">
                  <ul className="space-y-2 text-sm sm:text-base">
                    {[
                      `Design and build AI-native features for ${b.industry[0].toLowerCase()} products — agents, RAG pipelines, workflows.`,
                      `Ship production-grade interfaces in ${b.tools[0] ?? "React"} with a strong bias for craft and performance.`,
                      `Integrate LLMs (OpenAI, Anthropic, Gemini) into existing systems with proper evals and observability.`,
                      `Prototype fast, validate with real users, and iterate to a shippable v1 in weeks — not quarters.`,
                    ].map((t) => (
                      <li key={t} className="flex gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-coral" /> <span>{t}</span></li>
                    ))}
                  </ul>
                </SectionBox>

                <SectionBox title="How I Deliver">
                  <div className="grid gap-3 sm:grid-cols-2">
                    {[
                      { icon: Sparkles, title: "Discover", body: "Kickoff call to align on goals, users, and success metrics. You get a written scope in 48 hours." },
                      { icon: Target, title: "Design", body: "Low-fi flows, then hi-fi screens or a working prototype so you can feel the product before we build." },
                      { icon: Rocket, title: "Build", body: "Weekly demo-able increments. You always see progress — no black-box month-long silences." },
                      { icon: CheckCircle2, title: "Launch", body: "QA, docs, handover, and a 2-week post-launch window for polish, tweaks, and bug fixes." },
                    ].map((s) => {
                      const Icon = s.icon;
                      return (
                        <div key={s.title} className="rounded-lg border-[1.5px] border-[#0F0F0F] p-3">
                          <div className="flex items-center gap-2">
                            <span className="grid h-7 w-7 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-coral text-white"><Icon className="h-3.5 w-3.5" /></span>
                            <div className="font-bold">{s.title}</div>
                          </div>
                          <p className="mt-2 text-xs text-foreground/80 sm:text-sm">{s.body}</p>
                        </div>
                      );
                    })}
                  </div>
                </SectionBox>

                <SectionBox title="What You Get">
                  <ul className="space-y-2 text-sm sm:text-base">
                    {[
                      "Direct access to me — no account managers, no proxies.",
                      "Weekly async video updates + a shared board so you always know where we are.",
                      "Clean, well-commented code and a written handover doc at launch.",
                      "Response within 2 business hours during working days (IST).",
                      `${b.available ? "Available to start this week." : "Booking 2–3 weeks out — waitlist open."}`,
                    ].map((t) => (
                      <li key={t} className="flex gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-coral" /> <span>{t}</span></li>
                    ))}
                  </ul>
                </SectionBox>

                <SectionBox title="Working With Me">
                  <div className="grid gap-3 sm:grid-cols-3">
                    {[
                      { icon: Clock, k: "Response", v: "< 2 hours" },
                      { icon: Calendar, k: "Delivery", v: "3–7 days" },
                      { icon: Star, k: "Rating", v: `${b.rating} / 5` },
                    ].map((s) => {
                      const Icon = s.icon;
                      return (
                        <div key={s.k} className="rounded-lg border-[1.5px] border-[#0F0F0F] p-3 text-center">
                          <Icon className="mx-auto h-4 w-4 text-coral" />
                          <div className="mt-1 font-display text-lg font-black">{s.v}</div>
                          <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{s.k}</div>
                        </div>
                      );
                    })}
                  </div>
                </SectionBox>

                <SectionBox title="Skills">
                  <div className="flex flex-wrap gap-2">
                    {b.skills.map((s: string) => (
                      <span key={s} className="rounded-full border-[1.5px] border-[#0F0F0F] bg-cream px-3 py-1 text-xs font-bold">{s}</span>
                    ))}
                  </div>
                </SectionBox>

                <SectionBox title="Tech Stack">
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                    {b.tools.map((t: string, i: number) => (
                      <div
                        key={t}
                        className="rounded-lg border-[1.5px] border-[#0F0F0F] p-3 text-center"
                        style={{ background: `${ACCENT[i % ACCENT.length]}14` }}
                      >
                        <div className="text-lg">⚡</div>
                        <div className="mt-1 font-mono text-xs font-bold">{t}</div>
                      </div>
                    ))}
                  </div>
                </SectionBox>

                <SectionBox title="Connect">
                  <div className="flex flex-wrap gap-2">
                    {[
                      { icon: Github, label: "GitHub" },
                      { icon: Linkedin, label: "LinkedIn" },
                      { icon: Twitter, label: "X / Twitter" },
                      { icon: Globe, label: "Website" },
                    ].map((l) => {
                      const Icon = l.icon;
                      return (
                        <a
                          key={l.label}
                          href="#"
                          className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-3 py-1.5 text-xs font-bold hover:bg-cream"
                        >
                          <Icon className="h-3.5 w-3.5" /> {l.label}
                        </a>
                      );
                    })}
                  </div>
                </SectionBox>
              </TabsContent>

              <TabsContent value="portfolio" className="py-5">
                <div className="grid gap-4 sm:grid-cols-2">
                  {(builderProjects.length ? builderProjects : projects).slice(0, 6).map((p) => (
                    <ProjectCard key={p.id} p={p} />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="services" className="grid gap-4 py-5 sm:grid-cols-2">
                {(builderServices.length ? builderServices : services.slice(0, 4)).map((s) => <ServiceCard key={s.id} s={s} />)}
              </TabsContent>

              <TabsContent value="prompts" className="grid gap-4 py-5 sm:grid-cols-2">
                {(builderPrompts.length ? builderPrompts : prompts.slice(0, 4)).map((p) => <PromptCard key={p.id} p={p} />)}
              </TabsContent>

              <TabsContent value="workflows" className="grid gap-4 py-5 sm:grid-cols-2">
                {(builderWorkflows.length ? builderWorkflows : workflows.slice(0, 4)).map((w) => <WorkflowCard key={w.id} w={w} />)}
              </TabsContent>

              <TabsContent value="reviews" className="space-y-3 py-5">
                <WriteReview builderId={b.id} builderName={b.name} />
                <UserReviews builderId={b.id} />
                {testimonials.map((t, i) => (
                  <div key={i} className="card-flat p-4 sm:p-5">
                    <div className="flex items-center gap-3">
                      <img src={`https://api.dicebear.com/7.x/notionists/svg?seed=${t.seed}`} className="h-10 w-10 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]" alt="" />
                      <div className="min-w-0">
                        <div className="truncate text-sm font-bold">{t.name}</div>
                        <div className="truncate text-xs text-muted-foreground">{t.role} · ★★★★★</div>
                      </div>
                    </div>
                    <p className="mt-3 text-sm leading-relaxed">{t.text}</p>
                  </div>
                ))}
              </TabsContent>
            </Tabs>

            {/* Achievements */}
            <div className="mt-8">
              <SectionTitle icon={Award} title="Achievements & Badges" />
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                {achievements.map((a, i) => (
                  <div
                    key={a.label}
                    className="rounded-lg border-[1.5px] border-[#0F0F0F] p-4"
                    style={{ background: `${ACCENT[i % ACCENT.length]}12` }}
                  >
                    <div className="text-2xl">{a.icon}</div>
                    <div className="mt-2 text-sm font-black">{a.label}</div>
                    <div className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">{a.meta}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Activity timeline */}
            <div className="mt-8">
              <SectionTitle icon={Flame} title="Recent Activity" />
              <div className="card-editorial mt-4 p-4 sm:p-6">
                <ol className="relative space-y-4 border-l-[1.5px] border-[#0F0F0F] pl-5">
                  {activities.map((a, i) => {
                    const Icon = a.icon;
                    return (
                      <li key={i} className="relative">
                        <span
                          className="absolute -left-[27px] grid h-6 w-6 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] text-white"
                          style={{ background: a.color }}
                        >
                          <Icon className="h-3 w-3" />
                        </span>
                        <div className="text-sm font-bold">{a.label}</div>
                        <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{a.time}</div>
                      </li>
                    );
                  })}
                </ol>
              </div>
            </div>

            {/* Contribution grid — mobile only; desktop shows this in sidebar */}
            <div className="mt-8 lg:hidden">
              <SectionTitle icon={Calendar} title="Build Contributions · Last 12 weeks" />
              <div className="card-editorial mt-4 p-4">
                <ContributionGrid idx={idx} />
              </div>
            </div>
          </div>


          {/* Sidebar */}
          <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
            <LivePulse builderId={b.id} available={b.available} />

            <div className="card-editorial p-5">

              <div className={`flex items-center gap-2 text-sm font-bold ${b.available ? "text-foreground" : "text-muted-foreground"}`}>
                <span className={`h-2 w-2 rounded-full ${b.available ? "animate-pulse bg-[#0a9c8a]" : "bg-muted-foreground"}`} />
                {b.available ? "Available for work" : "Currently booked"}
              </div>
              <div className="mt-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Starts at</div>
              <div className="font-display text-2xl font-black">₹{b.hourlyRate.toLocaleString("en-IN")}<span className="text-sm text-muted-foreground">/hr</span></div>
              <button onClick={requestToHire} className="btn-coral mt-4 w-full">Request to Hire</button>
              <div className="mt-3 flex items-center justify-between border-t-[1.5px] border-dashed border-[#0F0F0F]/30 pt-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                <span>Response · &lt; 2h</span>
                <span>Delivery · 3-7d</span>
              </div>
            </div>

            <div className="card-editorial p-5">
              <h4 className="mb-3 text-xs font-black uppercase tracking-wider">Communities</h4>
              <div className="space-y-2">
                {communities.slice(0, 4).map((c) => (
                  <Link
                    key={c.id}
                    to="/communities/$slug"
                    params={{ slug: c.slug }}
                    className="flex items-center justify-between gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-cream px-3 py-2 text-sm font-bold hover:bg-coral hover:text-white"
                  >
                    <span className="flex min-w-0 items-center gap-2"><span className="text-base">{c.icon}</span><span className="truncate">{c.name}</span></span>
                    <ArrowUpRight className="h-3.5 w-3.5 shrink-0" />
                  </Link>
                ))}
              </div>
            </div>

            <div className="card-editorial p-5">
              <h4 className="mb-3 text-xs font-black uppercase tracking-wider">Industries</h4>
              <div className="flex flex-wrap gap-1.5">
                {b.industry.map((i: string) => (
                  <span key={i} className="rounded-full border-[1.5px] border-[#0F0F0F] bg-golden/30 px-2.5 py-1 text-[11px] font-bold">{i}</span>
                ))}
              </div>
            </div>

            <div className="card-editorial p-5">
              <h4 className="mb-3 text-xs font-black uppercase tracking-wider">Similar Builders</h4>
              <div className="space-y-3">
                {similar.map((s) => (
                  <Link
                    key={s.id}
                    to="/u/$username"
                    params={{ username: s.username }}
                    className="flex items-center gap-3 hover:opacity-80"
                  >
                    <img src={s.avatar} className="h-9 w-9 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]" alt="" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-bold">{s.name}</div>
                      <div className="truncate text-xs text-muted-foreground">{s.title}</div>
                    </div>
                    <ArrowUpRight className="h-3.5 w-3.5 shrink-0" />
                  </Link>
                ))}
              </div>
            </div>

            {/* Contribution grid — desktop sidebar placement */}
            <div className="hidden lg:block">
              <div className="card-editorial p-5">
                <div className="mb-3 flex items-center justify-between">
                  <h4 className="text-xs font-black uppercase tracking-wider">Build Contributions</h4>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">12 wks</span>
                </div>
                <ContributionGrid idx={idx} />
              </div>
            </div>
          </aside>

        </div>

        <div className="h-12" />
      </div>
    </Shell>
  );
}

function SectionBox({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="card-editorial p-4 sm:p-5">
      <h3 className="mb-3 text-xs font-black uppercase tracking-wider text-muted-foreground">{title}</h3>
      {children}
    </div>
  );
}

function SectionTitle({ icon: Icon, title }: { icon: any; title: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="grid h-8 w-8 place-items-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-coral text-white">
        <Icon className="h-4 w-4" />
      </span>
      <h2 className="font-display text-lg font-black tracking-tight sm:text-2xl">{title}</h2>
    </div>
  );
}

function ContributionGrid({ idx }: { idx: number }) {
  const levels = [0.08, 0.25, 0.45, 0.7, 1];
  return (
    <>
      <div className="grid grid-cols-[repeat(12,minmax(0,1fr))] gap-1">
        {Array.from({ length: 84 }).map((_, i) => {
          const seed = (i * 31 + idx * 7) % 5;
          const opacity = levels[seed];
          const isToday = i === 83;
          return (
            <div
              key={i}
              className={`aspect-square rounded-[3px] border border-foreground/20 ${isToday ? "ring-2 ring-coral" : ""}`}
              style={{ background: `rgba(232,98,58,${opacity})` }}
              title={`${seed * 2} contributions`}
            />
          );
        })}
      </div>
      <div className="mt-3 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
        <span>12w ago</span>
        <div className="flex items-center gap-1">
          Less
          {levels.map((o) => (
            <span key={o} className="h-2.5 w-2.5 rounded-[2px] border border-foreground/20" style={{ background: `rgba(232,98,58,${o})` }} />
          ))}
          More
        </div>
        <span>Today</span>
      </div>
    </>
  );
}

function LivePulse({ builderId, available }: { builderId: string; available: boolean }) {
  const seed = parseInt(builderId) || 1;
  const [views, setViews] = useState(() => 1200 + seed * 37);
  const [watching, setWatching] = useState(() => 3 + (seed % 7));
  const [lastPing, setLastPing] = useState(0);

  useEffect(() => {
    const t = setInterval(() => {
      setViews((v) => v + Math.floor(Math.random() * 3) + 1);
      setWatching((w) => Math.max(1, Math.min(24, w + (Math.random() > 0.5 ? 1 : -1))));
      setLastPing((p) => p + 1);
    }, 3500);
    return () => clearInterval(t);
  }, []);

  const pings = [
    { label: "New follower", who: "@arjun.builds", color: "#E8623A" },
    { label: "Portfolio viewed", who: "from Bengaluru", color: "#F5A623" },
    { label: "Message received", who: "@meera.codes", color: "#2DD4BF" },
    { label: "Profile shared", who: "on LinkedIn", color: "#7C3AED" },
  ];
  const ping = pings[lastPing % pings.length];

  return (
    <div className="card-editorial overflow-hidden p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#E8623A] opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-[#E8623A]" />
          </span>
          Live now
        </div>
        <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
          {available ? "Online" : "Away"}
        </span>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <div className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-cream p-2.5">
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Profile views</div>
          <div className="font-display text-lg font-black tabular-nums transition-all">{views.toLocaleString("en-IN")}</div>
        </div>
        <div className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-cream p-2.5">
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Watching now</div>
          <div className="flex items-baseline gap-1 font-display text-lg font-black tabular-nums">
            {watching}
            <span className="text-[10px] font-bold text-[#0a9c8a]">▲</span>
          </div>
        </div>
      </div>

      <div
        key={lastPing}
        className="mt-3 flex items-center gap-2 rounded-lg border-[1.5px] border-dashed border-[#0F0F0F]/30 p-2 text-xs animate-in fade-in slide-in-from-bottom-1"
      >
        <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: ping.color }} />
        <span className="min-w-0 flex-1 truncate">
          <b>{ping.label}</b> <span className="text-muted-foreground">· {ping.who}</span>
        </span>
        <span className="shrink-0 text-[10px] font-bold uppercase text-muted-foreground">now</span>
      </div>
    </div>
  );
}

type UserReview = { id: string; author: string; rating: number; text: string; at: number };

function reviewsKey(id: string) { return `vc.reviews.${id}`; }
function loadReviews(id: string): UserReview[] {
  try { return JSON.parse(localStorage.getItem(reviewsKey(id)) ?? "[]"); } catch { return []; }
}

function WriteReview({ builderId, builderName }: { builderId: string; builderName: string }) {
  const [rating, setRating] = useState(5);
  const [author, setAuthor] = useState("");
  const [text, setText] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (author.trim().length < 2) return toast.error("Add your name");
    if (text.trim().length < 5) return toast.error("Write at least 5 characters");
    const list = loadReviews(builderId);
    const next: UserReview = { id: `r-${Date.now()}`, author: author.trim(), rating, text: text.trim(), at: Date.now() };
    localStorage.setItem(reviewsKey(builderId), JSON.stringify([next, ...list]));
    setAuthor(""); setText(""); setRating(5);
    toast.success(`Review posted for ${builderName}`);
    window.dispatchEvent(new CustomEvent("vc:reviews-updated", { detail: builderId }));
  };
  return (
    <form onSubmit={submit} className="card-editorial space-y-3 p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <h4 className="text-xs font-black uppercase tracking-wider">Write a review</h4>
        <div className="flex items-center gap-1">
          {[1,2,3,4,5].map((n) => (
            <button key={n} type="button" onClick={() => setRating(n)} aria-label={`${n} stars`}>
              <Star className={`h-5 w-5 ${n <= rating ? "fill-golden text-golden" : "text-muted-foreground"}`} />
            </button>
          ))}
        </div>
      </div>
      <input value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Your name" className="h-10 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-surface px-3 text-sm outline-none focus:border-coral" />
      <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder={`Share how ${builderName} did…`} rows={3} className="w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-surface p-3 text-sm outline-none focus:border-coral" />
      <button type="submit" className="btn-coral h-10 w-full">Post review</button>
    </form>
  );
}

function UserReviews({ builderId }: { builderId: string }) {
  const [items, setItems] = useState<UserReview[]>([]);
  useEffect(() => {
    setItems(loadReviews(builderId));
    const h = (e: Event) => { if ((e as CustomEvent).detail === builderId) setItems(loadReviews(builderId)); };
    window.addEventListener("vc:reviews-updated", h);
    return () => window.removeEventListener("vc:reviews-updated", h);
  }, [builderId]);
  if (!items.length) return null;
  return (
    <>
      {items.map((r) => (
        <div key={r.id} className="card-flat p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <div className="text-sm font-bold">{r.author}</div>
            <div className="flex items-center gap-0.5">
              {Array.from({ length: r.rating }).map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-golden text-golden" />)}
            </div>
          </div>
          <p className="mt-2 text-sm leading-relaxed">{r.text}</p>
          <div className="mt-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{new Date(r.at).toLocaleDateString()}</div>
        </div>
      ))}
    </>
  );
}


