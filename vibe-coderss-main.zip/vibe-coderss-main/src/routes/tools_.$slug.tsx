import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowUp, ExternalLink, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { Shell } from "@/components/site/Shell";
import { ToolCard } from "@/components/cards/ToolCard";
import { getTool, tools } from "@/lib/mock-data";
import { getToolLogoSources } from "@/lib/tool-logo";

export const Route = createFileRoute("/tools_/$slug")({
  head: ({ params }) => ({ meta: [{ title: `${params.slug} · Tools · VibeCode` }] }),
  loader: ({ params }) => {
    const t = getTool(params.slug);
    if (!t) throw notFound();
    return { tool: t };
  },
  notFoundComponent: () => (
    <Shell><div className="container-page py-20 text-center"><h1 className="font-display text-3xl font-extrabold">Tool not found</h1><Link to="/tools" className="mt-4 inline-block text-coral underline">Back to tools</Link></div></Shell>
  ),
  component: ToolDetail,
});

function ToolDetail() {
  const { tool: t } = Route.useLoaderData();
  const related = tools.filter((x) => x.category === t.category && x.slug !== t.slug).slice(0, 3);
  const sources = getToolLogoSources(t);
  const [idx, setIdx] = useState(0);
  return (
    <Shell>
      <div className="container-page py-8">
        <Link to="/tools" className="inline-flex items-center gap-1 text-sm font-bold text-coral hover:underline"><ArrowLeft className="h-4 w-4" /> Back to tools</Link>
        <div className="card-editorial mt-4 p-8">
          <div className="flex flex-wrap items-start gap-6">
            <div className="grid h-24 w-24 shrink-0 place-items-center overflow-hidden rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}>
              {idx < sources.length ? (
                <img src={sources[idx]} alt={`${t.name} logo`} className="h-16 w-16 object-contain" onError={() => setIdx(idx + 1)} />
              ) : (
                <span className="font-display text-4xl font-extrabold" style={{ color: t.logoBg }}>{t.name[0]}</span>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="font-display text-4xl font-extrabold tracking-tight">{t.name}</h1>
              <p className="mt-2 text-base text-muted-foreground">{t.tagline}</p>
              <div className="mt-4 flex flex-wrap gap-2 text-xs">
                <span className="rounded-md bg-teal/25 px-2 py-1 font-bold text-[#0a6b5e]">{t.category}</span>
                <span className="rounded-md bg-gold/40 px-2 py-1 font-bold text-[#0F0F0F]">{t.pricing}</span>
                <span className="flex items-center gap-1 rounded-md bg-coral/15 px-2 py-1 font-bold text-coral"><ArrowUp className="h-3 w-3" /> {t.upvotes}</span>
              </div>
              <div className="mt-6 flex flex-wrap gap-3">
                <a href={t.url} target="_blank" rel="noopener noreferrer" className="btn-coral"><ExternalLink className="h-4 w-4" /> Visit site</a>
                <Link to="/submit" search={{ kind: "tool" }} className="btn-outline-dark">Suggest an update</Link>
              </div>
            </div>
          </div>
          <div className="mt-8 border-t-[1.5px] border-[#0F0F0F] pt-6">
            <h2 className="font-display text-xl font-extrabold">About {t.name}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{t.description}</p>
          </div>
        </div>
        {related.length > 0 && (
          <section className="mt-10">
            <h3 className="mb-4 font-display text-xl font-extrabold">Related {t.category} tools</h3>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{related.map((x) => <ToolCard key={x.id} t={x} />)}</div>
          </section>
        )}
      </div>
    </Shell>
  );
}
