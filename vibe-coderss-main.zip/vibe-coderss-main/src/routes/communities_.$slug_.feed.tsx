import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  ArrowLeft, ArrowUp, BadgeCheck, Bell, BellOff, Bookmark, Calendar, Check, ChevronDown, ChevronRight,
  Clock, Copy, Crown, Download, Eye, FileText, Flag, Globe, Hash, Info, Link as LinkIcon, LogOut,
  Mail, MapPin, Medal, MessageCircle, Mic, MoreHorizontal, Paperclip, Pin, Plus, Search, Send, Settings,
  Share2, Sparkles, Star, ThumbsUp, Trophy, Users, Video, X,
} from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { sharePage } from "@/lib/share";
import { allCommunities, builders, communities as seededCommunities } from "@/lib/mock-data";
import { JoinCommunityModal, isMember } from "@/components/site/JoinCommunityModal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  BasePost, PostType, ReactionKey, REACTION_META, reactionTotal,
  getPosts, getTopics, getResources, getEvents, getLeaderboard, getRules,
  loadSlugState, saveSlugState, communityId,
} from "@/lib/community-seed";
import { RealClassroomTab } from "@/components/community/RealClassroomTab";



export const Route = createFileRoute("/communities_/$slug_/feed")({
  loader: ({ params }) => {
    const c = seededCommunities.find((x) => x.slug === params.slug);
    return { slug: params.slug, community: c ?? null };
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.community?.name ?? "Community"} · VibeCoder` }] }),
  component: CommunityDetail,
  notFoundComponent: () => (
    <Shell>
      <div className="container-page py-20 text-center">
        <h1 className="font-display text-3xl font-extrabold">Community not found</h1>
        <Link to="/communities" className="mt-4 inline-block text-coral underline">Browse all communities</Link>
      </div>
    </Shell>
  ),
});

const ICON_BG = ["#E8623A", "#2DD4BF", "#F5A623", "#7C3AED", "#FF4D8D", "#E11D48"];

type TabId = "community" | "classroom" | "calendar" | "members" | "leaderboard" | "about";
const TABS: { id: TabId; label: string; icon: any }[] = [
  { id: "community", label: "Community", icon: Users },
  { id: "classroom", label: "Classroom", icon: FileText },
  { id: "calendar", label: "Calendar", icon: Calendar },
  { id: "members", label: "Members", icon: Users },
  { id: "leaderboard", label: "Leaderboard", icon: Trophy },
  { id: "about", label: "About", icon: Info },
];

const TYPE_META: Record<PostType, { label: string; color: string }> = {
  post: { label: "Post", color: "bg-[#F1E9DC] text-[#0F0F0F]" },
  prompt: { label: "Prompt", color: "bg-[#F3E8FF] text-[#7E22CE]" },
  workflow: { label: "Workflow", color: "bg-[#DBEAFE] text-[#1D4ED8]" },
  poll: { label: "Poll", color: "bg-[#FEF3C7] text-[#92400E]" },
  event: { label: "Event", color: "bg-[#DCFCE7] text-[#15803D]" },
  resource: { label: "Resource", color: "bg-[#FFE4E1] text-[#B91C1C]" },
  question: { label: "Question", color: "bg-[#E0E7FF] text-[#4338CA]" },
};

function CommunityDetail() {
  const { slug, community: seed } = Route.useLoaderData();
  const nav = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const c = seed ?? allCommunities().find((x) => x.slug === slug);
  if (!c) throw notFound();

  // Membership gate: real DB communities require an active member row.
  // Mock-only communities (not in DB) fall back to the localStorage isMember() check
  // that JoinCommunityModal maintains, so demo slugs still work.
  const [gateState, setGateState] = useState<"checking" | "ok" | "pending_payment">("checking");
  const [dbCommunityId, setDbCommunityId] = useState<string | null>(null);
  const [myRole, setMyRole] = useState<string | null>(null);
  const [isOwner, setIsOwner] = useState(false);
  useEffect(() => {
    let alive = true;
    if (authLoading) return;
    (async () => {
      // Local membership (mock or optimistic post-join) is always a valid pass,
      // even for anonymous visitors — they gave name+email in the join modal.
      if (isMember(slug)) { setGateState("ok"); }
      if (!user) {
        if (!isMember(slug)) nav({ to: "/communities/$slug", params: { slug }, replace: true });
        return;
      }
      const { data: comm } = await supabase
        .from("communities").select("id, created_by").eq("slug", slug).maybeSingle();
      if (!alive) return;
      if (!comm) {
        if (!isMember(slug)) nav({ to: "/communities/$slug", params: { slug }, replace: true });
        return;
      }
      setDbCommunityId(comm.id);
      setIsOwner(comm.created_by === user.id);
      const { data: m } = await supabase
        .from("community_members").select("status, role")
        .eq("community_id", comm.id).eq("profile_id", user.id).maybeSingle();
      if (!alive) return;
      if (m) setMyRole((m as any).role ?? null);
      if (!m && !isMember(slug)) { nav({ to: "/communities/$slug", params: { slug }, replace: true }); return; }
      if (m?.status === "pending_payment") setGateState("pending_payment");
      else setGateState("ok");
    })();
    return () => { alive = false; };
  }, [user, authLoading, slug, nav]);

  const canUpload = isOwner || ["owner", "admin", "moderator"].includes(myRole ?? "");

  const bg = ICON_BG[communityId(c.slug) % ICON_BG.length];
  const initialPosts = useMemo(() => getPosts(c.slug, c.name), [c.slug, c.name]);
  const topics = useMemo(() => getTopics(c.slug), [c.slug]);
  const resources = useMemo(() => getResources(c.slug, c.name), [c.slug, c.name]);
  const events = useMemo(() => getEvents(c.slug, c.name), [c.slug, c.name]);
  const leaderboard = useMemo(() => getLeaderboard(c.slug), [c.slug]);
  const rules = getRules();

  const [tab, setTab] = useState<TabId>("community");
  const [posts, setPosts] = useState<BasePost[]>(initialPosts);
  const [joinOpen, setJoinOpen] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQ, setSearchQ] = useState("");
  const [composerOpen, setComposerOpen] = useState(false);
  const [notif, setNotif] = useState(true);
  const [joined, setJoined] = useState(false);
  const [online, setOnline] = useState(Math.round(c.members / 10));
  const [typing, setTyping] = useState<string | null>(null);
  const [newPostsCount, setNewPostsCount] = useState(0);
  const [localState, setLocalState] = useState(() => loadSlugState(c.slug));
  const [topicFilter, setTopicFilter] = useState<string | null>(null);
  const [shareOpen, setShareOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<any | null>(null);
  const [eventRsvps, setEventRsvps] = useState<Record<string, boolean>>(() => {
    if (typeof window === "undefined") return {};
    try { return JSON.parse(localStorage.getItem(`vc:evt-rsvp:${c.slug}`) ?? "{}"); } catch { return {}; }
  });
  const feedTopRef = useRef<HTMLDivElement>(null);


  useEffect(() => setPosts(initialPosts), [initialPosts]);
  useEffect(() => {
    setJoined(isMember(c.slug));
    const onJoin = (e: Event) => { const d = (e as CustomEvent).detail as { slug: string }; if (d?.slug === c.slug) setJoined(true); };
    window.addEventListener("vc:joined", onJoin);
    if (typeof window !== "undefined" && new URLSearchParams(window.location.search).get("invite") === "1" && !isMember(c.slug)) setJoinOpen(true);
    return () => window.removeEventListener("vc:joined", onJoin);
  }, [c.slug]);

  // demo aliveness — auto refresh every 15s so the feed feels alive
  useEffect(() => {
    const onlineT = setInterval(() => setOnline((v) => Math.max(50, v + Math.floor(Math.random() * 17) - 8)), 15000);
    const newPostsT = setInterval(() => setNewPostsCount((n) => n + 1 + Math.floor(Math.random() * 2)), 15000);
    const reactT = setInterval(() => {
      setPosts((prev) => {
        if (!prev.length) return prev;
        const idx = Math.floor(Math.random() * Math.min(6, prev.length));
        const keys = Object.keys(REACTION_META) as ReactionKey[];
        const k = keys[Math.floor(Math.random() * keys.length)];
        const inc = 1 + Math.floor(Math.random() * 2);
        const copy = [...prev];
        copy[idx] = { ...copy[idx], reactions: { ...copy[idx].reactions, [k]: copy[idx].reactions[k] + inc } };
        return copy;
      });
    }, 15000);
    const typingT = setInterval(() => {
      const b = builders[Math.floor(Math.random() * builders.length)];
      setTyping(`${b.name} is posting something…`);
      setTimeout(() => setTyping(null), 4000);
    }, 30000);
    return () => { clearInterval(onlineT); clearInterval(newPostsT); clearInterval(reactT); clearInterval(typingT); };
  }, []);

  const persist = (next: typeof localState) => { setLocalState(next); saveSlugState(c.slug, next); };

  const setReaction = (postId: string, key: ReactionKey) => {
    const prev = localState.reactions[postId];
    setPosts((ps) => ps.map((p) => {
      if (p.id !== postId) return p;
      const r = { ...p.reactions };
      if (prev) r[prev] = Math.max(0, r[prev] - 1);
      if (prev !== key) r[key] = r[key] + 1;
      return { ...p, reactions: r };
    }));
    const nextReactions = { ...localState.reactions };
    if (prev === key) delete nextReactions[postId]; else nextReactions[postId] = key;
    persist({ ...localState, reactions: nextReactions });
  };

  const vote = (postId: string, optIdx: number) => {
    if (localState.votes[postId] !== undefined) return;
    setPosts((ps) => ps.map((p) => p.id === postId && p.pollOptions
      ? { ...p, pollOptions: p.pollOptions.map((o, i) => i === optIdx ? { ...o, votes: o.votes + 1 } : o) }
      : p));
    persist({ ...localState, votes: { ...localState.votes, [postId]: optIdx } });
    toast.success("Vote recorded");
  };

  const rsvp = (postId: string) => {
    const going = !localState.rsvps[postId];
    setPosts((ps) => ps.map((p) => p.id === postId ? { ...p, eventGoing: (p.eventGoing ?? 0) + (going ? 1 : -1) } : p));
    persist({ ...localState, rsvps: { ...localState.rsvps, [postId]: going } });
    toast.success(going ? "RSVP confirmed 🎉" : "RSVP removed");
  };

  const toggleSave = (postId: string) => {
    const saved = !localState.saved[postId];
    persist({ ...localState, saved: { ...localState.saved, [postId]: saved } });
    toast(saved ? "Saved" : "Removed");
  };

  const refreshFeed = () => {
    setPosts((p) => [...p].sort(() => Math.random() - 0.5));
    setNewPostsCount(0);
    feedTopRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const publishPost = (draft: { type: PostType; body: string; title?: string; tags?: string[]; pollOptions?: string[]; eventTitle?: string; eventWhen?: string; eventLocation?: string; resourceUrl?: string }) => {
    const newPost: BasePost = {
      id: `u-${Date.now()}`, type: draft.type, builderIdx: 0,
      title: draft.title || undefined, body: draft.body,
      tags: draft.tags?.length ? draft.tags : ["#new"],
      reactions: { like: 0, celebrate: 0, fire: 0, insightful: 0, support: 0 },
      views: 1, time: "just now", comments: [],
      pollOptions: draft.pollOptions?.filter(Boolean).map((t) => ({ text: t, votes: 0 })),
      pollEndsAt: draft.type === "poll" ? "in 3 days" : undefined,
      eventTitle: draft.eventTitle, eventWhen: draft.eventWhen, eventLocation: draft.eventLocation,
      eventLocationType: draft.eventLocation?.toLowerCase().includes("online") ? "online" : "in-person",
      eventGoing: draft.type === "event" ? 1 : undefined,
      resourceUrl: draft.resourceUrl, resourceCategory: draft.type === "resource" ? "Guide" : undefined,
    };
    setPosts((p) => [newPost, ...p]);
    setComposerOpen(false);
    setNewPostsCount(0);
    setTab("community");
    // Scroll to the new post next tick
    setTimeout(() => {
      feedTopRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 60);
    toast.success("Posted to the community ✨");
  };

  const pinned = posts.filter((p) => p.pinned);
  const activeFeed = topicFilter
    ? posts.filter((p) => !p.pinned && (
        (p.tags ?? []).some((t: string) => t.toLowerCase().replace(/^#/, "") === topicFilter.toLowerCase()) ||
        (p.body ?? "").toLowerCase().includes("#" + topicFilter.toLowerCase()) ||
        (p.title ?? "").toLowerCase().includes(topicFilter.toLowerCase())
      ))
    : posts.filter((p) => !p.pinned);
  const feed = activeFeed;

  const toggleEventRsvp = (eventId: string) => {
    setEventRsvps((prev) => {
      const next = { ...prev, [eventId]: !prev[eventId] };
      try { localStorage.setItem(`vc:evt-rsvp:${c.slug}`, JSON.stringify(next)); } catch {}
      toast.success(next[eventId] ? "RSVP confirmed 🎉" : "RSVP removed");
      return next;
    });
  };


  if (gateState === "checking") {
    return (
      <div className="grid min-h-screen place-items-center bg-[#FAF6F1] text-sm text-muted-foreground">
        Loading community…
      </div>
    );
  }

  if (gateState === "pending_payment") {
    return (
      <div className="grid min-h-screen place-items-center bg-[#FAF6F1] px-6">
        <div className="w-full max-w-md rounded-2xl border-[1.5px] border-foreground bg-white p-8 text-center shadow-[4px_4px_0_0_#0F0F0F]">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-xl border-[1.5px] border-foreground bg-[#F5A623] text-3xl">⏳</div>
          <h1 className="mt-4 font-display text-2xl font-extrabold">{c.name}</h1>
          <p className="mt-1 text-sm font-bold text-[#F59E0B]">Your membership is being verified</p>
          <p className="mt-4 text-sm text-muted-foreground">
            We received your payment details and are verifying your transaction.
            This usually takes less than 24 hours.
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            You'll receive a notification the moment your access is activated.
          </p>
          <div className="mt-6 flex flex-col gap-2">
            <Link
              to="/communities/$slug" params={{ slug }}
              className="grid h-11 place-items-center rounded-full border-[1.5px] border-foreground bg-coral text-sm font-bold text-white shadow-[3px_3px_0_0_#0F0F0F]"
            >← Back to Community Preview</Link>
            <a href="mailto:support@vibecoder.in" className="text-xs font-semibold text-muted-foreground hover:text-foreground">📞 Contact Support</a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <Shell chromeless>
      {/* Top bar */}
      <TopBar
        c={c} bg={bg} online={online}
        onBack={() => nav({ to: "/communities/$slug", params: { slug }, replace: true })}
        onMenu={() => setDrawerOpen(true)}
        onSearch={() => setSearchOpen(true)}
        onMore={() => setMoreOpen(true)}
        joined={joined}
        onJoin={() => setJoinOpen(true)}
        onShare={() => setShareOpen(true)}
        onInvite={() => setInviteOpen(true)}
      />

      {/* Filter bar */}
      <FilterBar tab={tab} setTab={setTab} />

      {/* Search overlay */}
      {searchOpen && (
        <SearchOverlay
          q={searchQ} onQ={setSearchQ} onClose={() => { setSearchOpen(false); setSearchQ(""); }}
          posts={posts} resources={resources} events={events} community={c.name}
        />
      )}

      {/* Body */}
      <div className="mx-auto w-full max-w-[1200px] lg:grid lg:min-h-0 lg:flex-1 lg:grid-cols-[220px_minmax(0,1fr)_280px] lg:gap-6 lg:overflow-hidden lg:px-4 lg:py-5">
        {/* Left sidebar desktop */}
        <aside className="hidden lg:block lg:h-full lg:overflow-y-auto lg:pr-1 no-scrollbar">
          <div className="space-y-4">
            <DrawerContent c={c} bg={bg} online={online} topics={topics} tab={tab} setTab={setTab}
              onInvite={() => setInviteOpen(true)} onLeave={() => toast("You'd leave the community here")}
              onTopicClick={(name: string) => { setTopicFilter(name); setTab("community"); feedTopRef.current?.scrollIntoView({ behavior: "smooth" }); }}
              onToolClick={(name: string) => { setSearchQ(name); setSearchOpen(true); }}
              embedded />
          </div>
        </aside>

        {/* Center */}
        <div className="min-w-0 lg:h-full lg:overflow-y-auto">
          {tab === "community" && (
            <CommunityTab
              c={c} online={online} typing={typing} newPostsCount={newPostsCount}
              onRefreshNew={refreshFeed}
              pinned={pinned} feed={feed}
              localState={localState}
              onReaction={setReaction} onVote={vote} onRsvp={rsvp} onSave={toggleSave}
              onOpenComposer={() => setComposerOpen(true)}
              feedTopRef={feedTopRef}
              topicFilter={topicFilter}
              onClearTopicFilter={() => setTopicFilter(null)}
            />
          )}
          {tab === "classroom" && (
            dbCommunityId
              ? <RealClassroomTab slug={slug} communityId={dbCommunityId} canUpload={canUpload} />
              : <ClassroomTab resources={resources} />
          )}
          {tab === "calendar" && <CalendarTab events={events} rsvps={eventRsvps} onOpenEvent={(e: any) => setSelectedEvent(e)} />}
          {tab === "members" && <MembersTab />}
          {tab === "leaderboard" && <LeaderboardTab rows={leaderboard} />}
          {tab === "about" && <AboutTab c={c} rules={rules} onInvite={() => setInviteOpen(true)} />}
        </div>

        {/* Right sidebar desktop */}
        <aside className="hidden lg:block lg:h-full lg:overflow-y-auto lg:pl-1 no-scrollbar">
          <div className="space-y-4">
            <RightSidebar c={c} bg={bg} events={events} leaderboard={leaderboard}
              onInvite={() => setInviteOpen(true)}
              onOpenEvent={(e: any) => setSelectedEvent(e)} />
          </div>
        </aside>
      </div>


      {/* Mobile drawer */}
      <Sheet open={drawerOpen} onOpenChange={setDrawerOpen}>
        <SheetContent side="left" className="w-[85%] max-w-xs overflow-y-auto p-0">
          <DrawerContent c={c} bg={bg} online={online} topics={topics} tab={tab} setTab={(t: TabId) => { setTab(t); setDrawerOpen(false); }}
            onInvite={() => { setDrawerOpen(false); setInviteOpen(true); }} onLeave={() => toast("You'd leave the community here")}
            onTopicClick={(name: string) => { setTopicFilter(name); setTab("community"); setDrawerOpen(false); }}
            onToolClick={(name: string) => { setDrawerOpen(false); setSearchQ(name); setSearchOpen(true); }} />
        </SheetContent>
      </Sheet>


      {/* More menu */}
      {moreOpen && (
        <div className="fixed inset-0 z-[90] bg-black/40" onClick={() => setMoreOpen(false)}>
          <div className="absolute inset-x-0 bottom-0 rounded-t-2xl border-t-[1.5px] border-[#0F0F0F] bg-white p-2 lg:inset-auto lg:right-4 lg:top-[60px] lg:w-64 lg:rounded-xl lg:border-[1.5px]" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }} onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto mb-2 h-1 w-10 rounded-full bg-black/20 lg:hidden" />
            {[
              { icon: Users, label: "Invite People", onClick: () => setInviteOpen(true) },
              { icon: Settings, label: "Community Settings", onClick: () => toast("Settings coming soon") },
              { icon: notif ? BellOff : Bell, label: notif ? "Mute notifications" : "Enable notifications", onClick: () => { setNotif((v) => !v); toast.success(notif ? "Muted" : "Notifications on"); } },
              { icon: Pin, label: "Pinned Posts", onClick: () => { setTab("community"); toast("Scrolled to pinned"); } },
              { icon: LogOut, label: "Leave Community", onClick: () => toast("Left community"), danger: true },
              { icon: Flag, label: "Report Community", onClick: () => toast.success("Reported — thanks"), danger: true },
            ].map((o) => {
              const Icon = o.icon;
              return (
                <button key={o.label} onClick={() => { setMoreOpen(false); o.onClick(); }} className={`flex w-full items-center gap-3 rounded-md px-3 py-3 text-left text-sm font-bold hover:bg-cream ${(o as any).danger ? "text-red-600" : ""}`}>
                  <Icon className="h-4 w-4" /> {o.label}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Composer bottom sheet */}
      {composerOpen && (
        <ComposerSheet communityName={c.name} onClose={() => setComposerOpen(false)} onPublish={publishPost} />
      )}

      {/* Invite modal (custom) */}
      {inviteOpen && (
        <CommunityInvite c={c} onClose={() => setInviteOpen(false)} />
      )}

      {shareOpen && <ShareModal name={c.name} description={c.description} onClose={() => setShareOpen(false)} />}
      {selectedEvent && (
        <EventDetailsModal
          event={selectedEvent}
          communityName={c.name}
          going={!!eventRsvps[selectedEvent.id]}
          onRsvp={() => toggleEventRsvp(selectedEvent.id)}
          onClose={() => setSelectedEvent(null)}
        />
      )}

      <JoinCommunityModal open={joinOpen} onClose={() => setJoinOpen(false)} communitySlug={c.slug} communityName={c.name} />


      {/* FAB for composer on mobile */}
      {tab === "community" && (
        <button onClick={() => setComposerOpen(true)} className="fixed bottom-5 right-4 z-40 grid h-14 w-14 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-coral text-white lg:hidden" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }} aria-label="Create post">
          <Plus className="h-6 w-6" />
        </button>
      )}
    </Shell>
  );
}

/* ============================== TOP BAR ============================== */
function TopBar({ c, bg, online, onBack, onMenu, onSearch, onMore, joined, onJoin, onShare, onInvite }: any) {
  return (
    <header className="sticky top-0 z-40 border-b-[1.5px] border-[#0F0F0F] bg-cream">
      <div className="mx-auto flex h-[52px] w-full max-w-[1200px] items-center gap-2 px-2 lg:h-16 lg:px-4">
        <button onClick={onBack} className="hidden h-9 items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 text-xs font-bold lg:inline-flex" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          <ArrowLeft className="h-3.5 w-3.5" /> Community Info
        </button>
        <button onClick={onBack} className="grid h-9 w-9 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-white lg:hidden" aria-label="Back" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          <ArrowLeft className="h-4 w-4" />
        </button>
        <button onClick={onMenu} className="grid h-9 w-9 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-white lg:hidden" aria-label="Menu" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          <ChevronRight className="h-4 w-4 rotate-180" />
        </button>

        <div className="hidden h-9 w-9 shrink-0 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] text-sm font-extrabold text-white lg:grid" style={{ background: bg, boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          {(c.icon && c.icon.length <= 2) ? c.icon : c.name.slice(0, 2).toUpperCase()}
        </div>

        <div className="min-w-0 flex-1 text-center lg:text-left">
          <div className="flex items-center justify-center gap-1 lg:justify-start">
            <h1 className="truncate font-display text-[15px] font-extrabold lg:text-lg">{c.name}</h1>
            <BadgeCheck className="h-3.5 w-3.5 shrink-0 text-coral lg:h-4 lg:w-4" />
          </div>
          <div className="hidden items-center gap-2 text-[11px] font-bold text-muted-foreground lg:flex">
            <Users className="h-3 w-3" /> {c.members.toLocaleString()}
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-success" /> {online.toLocaleString()} online
          </div>
        </div>

        <button onClick={onSearch} className="grid h-9 w-9 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }} aria-label="Search">
          <Search className="h-4 w-4" />
        </button>
        <button onClick={onInvite} className="flex h-9 items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-[#F5A623] px-2.5 text-xs font-extrabold text-[#0F0F0F] lg:px-3" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }} aria-label="Invite">
          <Users className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Invite</span>
        </button>
        {!joined ? (
          <button onClick={onJoin} className="hidden h-9 items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 text-xs font-extrabold text-white lg:inline-flex" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <Plus className="h-3.5 w-3.5" /> Join
          </button>
        ) : (
          <span className="hidden h-9 items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-success px-3 text-xs font-extrabold text-white lg:inline-flex" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <Check className="h-3.5 w-3.5" /> Joined
          </span>
        )}
        <button onClick={onShare} className="hidden h-9 w-9 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-white lg:grid" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }} aria-label="Share">
          <Share2 className="h-4 w-4" />
        </button>
        <button onClick={onMore} className="grid h-9 w-9 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }} aria-label="More">
          <MoreHorizontal className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}

/* ============================== FILTER BAR ============================== */
function FilterBar({ tab, setTab }: { tab: TabId; setTab: (t: TabId) => void }) {
  return (
    <div className="sticky top-[52px] z-30 hidden border-b-[1.5px] border-[#0F0F0F] bg-cream lg:top-16 lg:block">
      <div className="mx-auto w-full max-w-[1200px] px-2 lg:px-4">
        <nav className="scrollbar-none flex gap-2 overflow-x-auto py-2 lg:gap-1 lg:py-0">
          {TABS.map((t) => {
            const active = tab === t.id;
            return (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`shrink-0 whitespace-nowrap rounded-full border-[1.5px] px-3 py-1.5 text-xs font-extrabold transition
                  lg:rounded-none lg:border-0 lg:border-b-[3px] lg:px-4 lg:py-3 lg:text-sm
                  ${active
                    ? "border-[#0F0F0F] bg-coral text-white lg:border-coral lg:bg-transparent lg:text-coral"
                    : "border-[#0F0F0F]/40 bg-transparent text-foreground/70 lg:border-transparent lg:text-muted-foreground"}`}>
                {t.label}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}

/* ============================== DRAWER CONTENT ============================== */
function DrawerContent({ c, bg, online, topics, tab, setTab, onInvite, onLeave, embedded, onTopicClick, onToolClick }: any) {
  return (
    <div className={`${embedded ? "space-y-4" : "space-y-5 p-4"}`}>
      {!embedded && (
        <div className="flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl border-[1.5px] border-[#0F0F0F] font-extrabold text-white" style={{ background: bg }}>
            {(c.icon && c.icon.length <= 2) ? c.icon : c.name.slice(0, 2).toUpperCase()}
          </div>
          <div className="min-w-0">
            <div className="truncate font-display font-extrabold">{c.name}</div>
            <div className="text-[11px] font-bold text-muted-foreground">
              👥 {c.members.toLocaleString()} · 🟢 {online.toLocaleString()} online
            </div>
          </div>
        </div>
      )}

      <div className={embedded ? "card-editorial p-3" : ""}>
        <h4 className="mb-2 px-1 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Navigate</h4>
        <ul className="space-y-0.5 text-sm">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <li key={t.id}>
                <button onClick={() => setTab(t.id)} className={`flex w-full items-center gap-2 rounded-md px-2 py-2 text-left font-bold ${active ? "bg-coral/15 text-coral" : "text-foreground/80 hover:bg-cream"}`}>
                  <Icon className="h-4 w-4" /> {t.label}
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      <div className={embedded ? "card-editorial p-3" : ""}>
        <h4 className="mb-2 px-1 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Topics</h4>
        <ul className="space-y-0.5 text-sm">
          {topics.slice(0, 6).map((t: any) => (
            <li key={t.name}>
              <button
                onClick={() => onTopicClick?.(t.name)}
                className="flex w-full items-center justify-between rounded-md px-2 py-1.5 font-bold text-foreground/80 hover:bg-cream"
              >
                <span className="flex items-center gap-1.5"><Hash className="h-3.5 w-3.5 text-muted-foreground" /> {t.name}</span>
                <span className="text-[11px] font-bold text-muted-foreground">{t.count.toLocaleString?.() ?? t.count}</span>
              </button>
            </li>

          ))}
        </ul>
        <button className="mt-1 w-full rounded-md px-2 py-1.5 text-left text-[11px] font-bold text-coral hover:bg-cream">View all topics →</button>
      </div>

      <div className={embedded ? "card-editorial p-3" : ""}>
        <div className="mb-2 flex items-center justify-between px-1">
          <h4 className="text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Your Tools</h4>
          <button className="grid h-5 w-5 place-items-center rounded border border-[#0F0F0F]/30" aria-label="Add tool"><Plus className="h-3 w-3" /></button>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {["ChatGPT", "Claude", "n8n", "Lovable"].map((t) => (
            <button
              key={t}
              onClick={() => onToolClick?.(t)}
              className="rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2 py-1 text-[11px] font-bold transition hover:bg-coral hover:text-white"
            >{t}</button>
          ))}
        </div>

      </div>

      <div className="space-y-2">
        <button onClick={onInvite} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral py-2 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          <Users className="h-3.5 w-3.5" /> Invite People
        </button>
        <button onClick={onLeave} className="flex w-full items-center justify-center gap-2 rounded-md border-[1.5px] border-red-500/60 bg-white py-2 text-xs font-extrabold text-red-600">
          <LogOut className="h-3.5 w-3.5" /> Leave Community
        </button>
      </div>
    </div>
  );
}

/* ============================== COMMUNITY TAB ============================== */
function CommunityTab({ c, online, typing, newPostsCount, onRefreshNew, pinned, feed, localState, onReaction, onVote, onRsvp, onSave, onOpenComposer, feedTopRef, topicFilter, onClearTopicFilter }: any) {
  return (
    <div className="lg:space-y-4">
      <div ref={feedTopRef} />
      {topicFilter && (
        <div className="mx-3 mt-3 flex items-center justify-between gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-coral/10 px-3 py-2 text-xs font-bold lg:mx-0">
          <span className="flex items-center gap-1.5 text-coral"><Hash className="h-3.5 w-3.5" /> Filtering by <span className="font-extrabold">#{topicFilter}</span></span>
          <button onClick={onClearTopicFilter} className="flex items-center gap-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2 py-0.5 text-[11px] font-extrabold">
            <X className="h-3 w-3" /> Clear
          </button>
        </div>
      )}

      {/* Desktop composer */}
      <div className="hidden lg:block">
        <button onClick={onOpenComposer} className="flex w-full items-center gap-3 rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-4 text-left text-sm text-muted-foreground" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
          <div className="grid h-10 w-10 place-items-center rounded-full bg-cream font-extrabold">Y</div>
          Write something to the community…
        </button>
      </div>
      {/* Mobile composer bar */}
      <div className="lg:hidden">
        <button onClick={onOpenComposer} className="flex w-full items-center gap-2 border-b border-[#0F0F0F]/10 bg-white px-3 py-3 text-left text-sm text-muted-foreground">
          <div className="grid h-8 w-8 place-items-center rounded-full bg-cream font-bold">Y</div>
          Write something to the community…
        </button>
      </div>

      {newPostsCount > 0 && (
        <div className="sticky top-[100px] z-20 flex justify-center py-2 lg:top-[120px]">
          <button onClick={onRefreshNew} className="flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-4 py-1.5 text-xs font-extrabold text-white" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
            <ArrowUp className="h-3.5 w-3.5" /> {newPostsCount} new post{newPostsCount > 1 ? "s" : ""} — tap to refresh
          </button>
        </div>
      )}

      {typing && (
        <div className="px-3 py-1 text-[11px] italic text-muted-foreground lg:px-1">{typing}</div>
      )}

      <div className="space-y-1.5 lg:space-y-4">
        {pinned.map((p: BasePost) => (
          <PostCard key={p.id} post={p} localState={localState} onReaction={onReaction} onVote={onVote} onRsvp={onRsvp} onSave={onSave} />
        ))}
        {feed.map((p: BasePost) => (
          <PostCard key={p.id} post={p} localState={localState} onReaction={onReaction} onVote={onVote} onRsvp={onRsvp} onSave={onSave} />
        ))}
      </div>
    </div>
  );
}

/* ============================== POST CARD ============================== */
function PostCard({ post, localState, onReaction, onVote, onRsvp, onSave }: any) {
  const b = builders[post.builderIdx % builders.length];
  const [expanded, setExpanded] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [commentDraft, setCommentDraft] = useState("");
  const userReaction: ReactionKey | undefined = localState.reactions[post.id];
  const meta = TYPE_META[post.type as PostType];
  const pinCls = post.pinned ? "border-l-[3px] border-l-coral bg-[#FFF8F6]" : "";
  return (
    <article className={`bg-white lg:rounded-xl lg:border-[1.5px] lg:border-[#0F0F0F] ${pinCls}`} style={post.pinned ? {} : { boxShadow: "3px 3px 0 0 #0F0F0F" }}>
      <div className="p-3 lg:p-4">
        {post.pinned && (
          <div className="mb-2 inline-flex items-center gap-1 rounded-full bg-coral/15 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-coral">
            <Pin className="h-3 w-3" /> Pinned
          </div>
        )}
        <div className="flex items-center gap-2">
          <img src={b.avatar} alt="" className="h-10 w-10 shrink-0 rounded-full border-[1.5px] border-[#0F0F0F]" />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-sm font-extrabold">
              <span className="truncate">{b.name}</span>
              {b.verified && <BadgeCheck className="h-3.5 w-3.5 shrink-0 text-coral" />}
              <span className="rounded bg-[#F5A62333] px-1.5 py-0.5 text-[9px] font-extrabold uppercase text-[#92400E]">Pro</span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
              <span className="truncate">{b.title}</span> · <span>{post.time}</span>
              <span className={`rounded px-1.5 py-0.5 text-[9px] font-extrabold uppercase ${meta.color}`}>{meta.label}</span>
            </div>
          </div>
          <button className="grid h-8 w-8 place-items-center rounded-md hover:bg-cream" aria-label="More"><MoreHorizontal className="h-4 w-4" /></button>
        </div>

        {post.title && <h3 className="mt-2 font-display text-base font-extrabold leading-snug lg:text-lg">{post.title}</h3>}
        <p className={`mt-1 whitespace-pre-wrap text-sm leading-relaxed text-foreground/85 ${expanded ? "" : "line-clamp-5"}`}>{post.body}</p>
        {post.body.length > 240 && !expanded && (
          <button onClick={() => setExpanded(true)} className="mt-1 text-xs font-bold text-coral">Read more</button>
        )}

        {post.media && (
          <div className="mt-3 aspect-[16/9] w-full overflow-hidden rounded-lg border-[1.5px] border-[#0F0F0F]" style={{ background: `linear-gradient(135deg, ${post.media.a}, ${post.media.b})` }} />
        )}

        {post.type === "poll" && post.pollOptions && (
          <PollBlock post={post} userVote={localState.votes[post.id]} onVote={(i: number) => onVote(post.id, i)} />
        )}

        {post.type === "event" && (
          <EventBlock post={post} going={!!localState.rsvps[post.id]} onRsvp={() => onRsvp(post.id)} />
        )}

        {post.type === "resource" && post.resourceUrl && (
          <a href={post.resourceUrl} target="_blank" rel="noreferrer" className="mt-3 flex items-center justify-between gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-cream p-3 text-sm font-bold">
            <span className="flex min-w-0 items-center gap-2"><FileText className="h-4 w-4 shrink-0 text-coral" /><span className="truncate">{post.resourceUrl}</span></span>
            <span className="rounded bg-coral/15 px-2 py-0.5 text-[10px] font-extrabold uppercase text-coral">Open</span>
          </a>
        )}

        {post.tags?.length ? (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {post.tags.map((t: string) => <span key={t} className="rounded bg-cream px-1.5 py-0.5 text-[11px] font-bold text-foreground/70">{t}</span>)}
          </div>
        ) : null}
      </div>

      {/* Reaction totals */}
      <div className="flex items-center justify-between border-t border-[#0F0F0F]/10 px-3 py-2 text-[11px] font-bold text-muted-foreground lg:px-4">
        <div className="flex items-center gap-2">
          {(["like", "fire", "insightful"] as ReactionKey[]).map((k) => post.reactions[k] > 0 && (
            <span key={k} className="flex items-center gap-1">{REACTION_META[k].emoji} {post.reactions[k]}</span>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1"><MessageCircle className="h-3 w-3" /> {post.comments.length}</span>
          <span className="flex items-center gap-1"><Eye className="h-3 w-3" /> {post.views.toLocaleString()}</span>
        </div>
      </div>

      {/* Action row */}
      <div className="relative grid grid-cols-4 border-t border-[#0F0F0F]/10 text-xs font-extrabold">
        <button
          onClick={() => userReaction ? onReaction(post.id, userReaction) : onReaction(post.id, "like")}
          onContextMenu={(e) => { e.preventDefault(); setPickerOpen((v) => !v); }}
          onDoubleClick={() => setPickerOpen(true)}
          className={`flex items-center justify-center gap-1 py-2.5 hover:bg-cream ${userReaction ? "text-coral" : ""}`}
        >
          {userReaction ? REACTION_META[userReaction].emoji : "👍"} {userReaction ? REACTION_META[userReaction].label : "Like"}
        </button>
        <button onClick={() => setPickerOpen((v) => !v)} className="border-l border-[#0F0F0F]/10 py-2.5 text-[10px] font-bold text-muted-foreground hover:bg-cream">React ▾</button>
        <button onClick={() => setShowComments((v) => !v)} className="flex items-center justify-center gap-1 border-l border-[#0F0F0F]/10 py-2.5 hover:bg-cream">
          <MessageCircle className="h-3.5 w-3.5" /> Comment
        </button>
        <button onClick={() => onSave(post.id)} className={`flex items-center justify-center gap-1 border-l border-[#0F0F0F]/10 py-2.5 hover:bg-cream ${localState.saved[post.id] ? "text-coral" : ""}`}>
          <Bookmark className="h-3.5 w-3.5" /> Save
        </button>

        {pickerOpen && (
          <div className="absolute bottom-full left-1/2 z-10 mb-2 flex -translate-x-1/2 items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-2 py-1.5" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
            {(Object.keys(REACTION_META) as ReactionKey[]).map((k) => (
              <button key={k} onClick={() => { onReaction(post.id, k); setPickerOpen(false); }} className="grid h-8 w-8 place-items-center rounded-full text-lg transition hover:scale-125" title={REACTION_META[k].label}>
                {REACTION_META[k].emoji}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Comments */}
      {showComments && (
        <div className="border-t border-[#0F0F0F]/10 bg-cream/50 p-3 lg:p-4">
          <div className="mb-2 text-[11px] font-extrabold uppercase text-muted-foreground">Comments ({post.comments.length})</div>
          <ul className="space-y-3">
            {post.comments.map((c: any) => {
              const cb = builders[c.builderIdx % builders.length];
              return (
                <li key={c.id} className="flex gap-2">
                  <img src={cb.avatar} className="h-8 w-8 shrink-0 rounded-full border border-[#0F0F0F]/30" alt="" />
                  <div className="min-w-0 flex-1">
                    <div className="rounded-lg border border-[#0F0F0F]/15 bg-white p-2 text-sm">
                      <div className="text-[11px] font-extrabold">{cb.name}</div>
                      <div className="mt-0.5 text-[13px]">{c.body}</div>
                    </div>
                    <div className="mt-1 flex items-center gap-3 text-[11px] font-bold text-muted-foreground">
                      <button className="hover:text-coral">Like</button>
                      <button className="hover:text-coral">Reply</button>
                      <span>{c.time}</span>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
          <div className="mt-3 flex items-center gap-2">
            <input value={commentDraft} onChange={(e) => setCommentDraft(e.target.value)} placeholder="Add a comment…" className="min-w-0 flex-1 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-sm outline-none" />
            <button onClick={() => { if (commentDraft.trim()) { toast.success("Comment posted"); setCommentDraft(""); } }} className="grid h-9 w-9 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-coral text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }} aria-label="Send"><Send className="h-4 w-4" /></button>
          </div>
        </div>
      )}
    </article>
  );
}

function PollBlock({ post, userVote, onVote }: any) {
  const total = post.pollOptions.reduce((s: number, o: any) => s + o.votes, 0) || 1;
  const voted = userVote !== undefined;
  return (
    <div className="mt-3 space-y-2">
      {post.pollOptions.map((o: any, i: number) => {
        const pct = Math.round((o.votes / total) * 100);
        const isMine = userVote === i;
        return voted ? (
          <div key={i} className={`relative overflow-hidden rounded-md border-[1.5px] ${isMine ? "border-coral" : "border-[#0F0F0F]/40"} bg-white`}>
            <div className="absolute inset-y-0 left-0 bg-coral/20" style={{ width: `${pct}%` }} />
            <div className="relative flex items-center justify-between px-3 py-2 text-sm font-bold">
              <span className="flex items-center gap-1.5">{isMine && <Check className="h-3.5 w-3.5 text-coral" />} {o.text}</span>
              <span className="text-xs text-muted-foreground">{pct}% · {o.votes}</span>
            </div>
          </div>
        ) : (
          <button key={i} onClick={() => onVote(i)} className="flex w-full items-center justify-between rounded-md border-[1.5px] border-[#0F0F0F]/40 bg-white px-3 py-2 text-sm font-bold hover:border-coral hover:bg-coral/5">
            {o.text}
          </button>
        );
      })}
      <div className="text-[11px] font-bold text-muted-foreground">Total: {total} votes · Ends {post.pollEndsAt}</div>
    </div>
  );
}

function EventBlock({ post, going, onRsvp }: any) {
  return (
    <div className="mt-3 rounded-lg border-[1.5px] border-[#0F0F0F] bg-cream p-3">
      <div className="text-sm font-extrabold">📅 {post.eventTitle}</div>
      <div className="mt-1 flex items-center gap-2 text-xs font-bold text-muted-foreground">
        <Clock className="h-3 w-3" /> {post.eventWhen}
      </div>
      <div className="mt-1 flex items-center gap-2 text-xs font-bold text-muted-foreground">
        <MapPin className="h-3 w-3" /> {post.eventLocation}
      </div>
      <div className="mt-2 flex items-center justify-between">
        <div className="flex -space-x-2">
          {builders.slice(0, 4).map((b) => <img key={b.id} src={b.avatar} alt="" className="h-6 w-6 rounded-full border-2 border-white" />)}
          <span className="ml-3 self-center text-[11px] font-bold text-muted-foreground">+{post.eventGoing} going</span>
        </div>
        <button onClick={onRsvp} className={`rounded-md border-[1.5px] border-[#0F0F0F] px-3 py-1.5 text-xs font-extrabold ${going ? "bg-success text-white" : "bg-coral text-white"}`} style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          {going ? "✓ Going" : "RSVP — I'm Going"}
        </button>
      </div>
    </div>
  );
}

/* ============================== TABS ============================== */
function ClassroomTab({ resources }: any) {
  const nav = useNavigate();
  const [filter, setFilter] = useState<string>("All");
  const filters = ["All", "Guides", "Videos", "Templates", "Prompt Packs", "Workflows"];
  const filtered = filter === "All" ? resources : resources.filter((r: any) => r.category + "s" === filter || r.category === filter.replace(/s$/, ""));
  // First video is treated as a live stream for demo
  const liveId = resources.find((r: any) => r.kind === "Video")?.id ?? resources[0]?.id;
  // Route params: derive slug from URL (this tab is only rendered inside the community feed route)
  const slug = typeof window !== "undefined" ? window.location.pathname.split("/")[2] ?? "" : "";
  return (
    <section className="p-3 lg:p-0">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-display text-xl font-extrabold">Classroom</h2>
        <div className="flex gap-1.5">
          <button onClick={() => nav({ to: "/communities/$slug/watch/$id", params: { slug, id: resources[0].id } })} className="flex items-center gap-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2.5 py-1.5 text-xs font-extrabold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <span className="h-2 w-2 rounded-full bg-red-600 animate-pulse" /> Go Live
          </button>
          <button onClick={() => toast("Upload flow coming soon — lecturers can upload MP4 or start a live stream")} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1.5 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>+ Upload</button>
        </div>
      </div>
      <div className="mb-3 flex gap-1.5 overflow-x-auto">
        {filters.map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`shrink-0 rounded-full border-[1.5px] px-3 py-1 text-xs font-bold ${filter === f ? "border-[#0F0F0F] bg-coral text-white" : "border-[#0F0F0F]/40 bg-white"}`}>{f}</button>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {filtered.map((r: any) => {
          const b = builders[r.builderIdx % builders.length];
          const isLive = r.id === liveId;
          return (
            <Link
              key={r.id}
              to="/communities/$slug/watch/$id"
              params={{ slug, id: r.id }}
              className="group text-left rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-3 hover:bg-cream/40"
              style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
            >
              <div className="relative aspect-video overflow-hidden rounded-md border border-[#0F0F0F]/20" style={{ background: `linear-gradient(135deg, #E8623A, #F5A623)` }}>
                <div className="absolute inset-0 grid place-items-center opacity-90 group-hover:opacity-100">
                  <div className="grid h-12 w-12 place-items-center rounded-full bg-black/60 text-white">▶</div>
                </div>
                {isLive && (
                  <span className="absolute left-2 top-2 flex items-center gap-1 rounded-md bg-red-600 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-white">
                    <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" /> Live
                  </span>
                )}
                <span className="absolute bottom-2 right-2 rounded bg-black/70 px-1.5 py-0.5 text-[10px] font-bold text-white">12:34</span>
              </div>
              <div className="mt-2 flex items-start justify-between gap-2">
                <h3 className="text-sm font-extrabold leading-snug">{r.title}</h3>
                <span className="shrink-0 rounded bg-cream px-1.5 py-0.5 text-[10px] font-extrabold uppercase">{r.category}</span>
              </div>
              <div className="mt-2 flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
                <img src={b.avatar} className="h-5 w-5 rounded-full" alt="" /> {b.name} · {r.date}
              </div>
              <div className="mt-2 flex items-center justify-between text-[11px] font-bold">
                <span className="text-muted-foreground">👁 {r.downloads.toLocaleString()} · ⭐ {r.rating.toFixed(1)}</span>
                <span className="rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2 py-1 text-[11px] font-extrabold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>Watch →</span>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

function CalendarTab({ events, rsvps, onOpenEvent }: any) {
  const today = new Date();
  const monthName = today.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const eventByDay = new Map<number, any>();
  events.forEach((e: any) => { if (!eventByDay.has(e.day)) eventByDay.set(e.day, e); });
  return (
    <section className="p-3 lg:p-0">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-display text-xl font-extrabold">Calendar</h2>
        <button className="rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1.5 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>+ Schedule Event</button>
      </div>
      <div className="mb-4 rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-3" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
        <div className="mb-2 text-center text-sm font-extrabold">{monthName}</div>
        <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-muted-foreground">
          {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => <div key={i}>{d}</div>)}
        </div>
        <div className="mt-1 grid grid-cols-7 gap-1">
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const d = i + 1;
            const ev = eventByDay.get(d);
            const has = !!ev;
            const isToday = d === today.getDate();
            return (
              <button
                key={d}
                onClick={() => ev && onOpenEvent(ev)}
                disabled={!has}
                className={`relative grid aspect-square place-items-center rounded-md text-xs font-bold transition ${isToday ? "bg-coral text-white" : has ? "bg-coral/10 text-coral hover:bg-coral/25" : "text-foreground/60 cursor-default"}`}
              >
                {d}
                {has && !isToday && <span className="absolute bottom-0.5 h-1 w-1 rounded-full bg-coral" />}
              </button>
            );
          })}
        </div>
      </div>
      <div className="space-y-3">
        {events.map((e: any) => {
          const org = builders[e.organizerIdx % builders.length];
          const going = !!rsvps?.[e.id];
          return (
            <button
              key={e.id}
              onClick={() => onOpenEvent(e)}
              className="flex w-full gap-3 rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-3 text-left transition hover:-translate-y-0.5 hover:bg-cream"
              style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
            >
              <div className="grid h-14 w-14 shrink-0 place-content-center rounded-lg border-[1.5px] border-[#0F0F0F] bg-cream text-center">
                <div className="text-[9px] font-extrabold uppercase tracking-wider">{e.month}</div>
                <div className="text-lg font-extrabold leading-none">{e.day}</div>
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-sm font-extrabold">{e.title}</h3>
                <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] font-bold text-muted-foreground">
                  <span><MapPin className="inline h-3 w-3" /> {e.location}</span>
                  <span><Clock className="inline h-3 w-3" /> {e.when}</span>
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <div className="flex items-center gap-1 text-[11px] font-bold text-muted-foreground">
                    <img src={org.avatar} alt="" className="h-5 w-5 rounded-full border border-[#0F0F0F]/30" />
                    {org.name} · +{e.going + (going ? 1 : 0)} going
                  </div>
                  <span className={`rounded-md border-[1.5px] border-[#0F0F0F] px-2 py-1 text-[11px] font-extrabold text-white ${going ? "bg-success" : "bg-coral"}`} style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
                    {going ? "✓ Going" : "View →"}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}


function MembersTab() {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"All" | "Admins" | "Moderators" | "New">("All");
  const [sort, setSort] = useState<"Points" | "Newest" | "A-Z">("Points");
  const list = useMemo(() => {
    let l = [...builders];
    if (q) l = l.filter((b) => b.name.toLowerCase().includes(q.toLowerCase()));
    if (filter === "Admins") l = l.slice(0, 2);
    if (filter === "Moderators") l = l.slice(2, 5);
    if (sort === "A-Z") l.sort((a, b) => a.name.localeCompare(b.name));
    if (sort === "Newest") l.reverse();
    return l;
  }, [q, filter, sort]);
  return (
    <section className="p-3 lg:p-0">
      <h2 className="mb-3 font-display text-xl font-extrabold">Members</h2>
      <div className="mb-2 flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
        <Search className="h-4 w-4" />
        <input value={q} onChange={(e) => setQ(e.target.value)} className="min-w-0 flex-1 bg-transparent text-sm outline-none" placeholder="Search members…" />
      </div>
      <div className="mb-3 flex flex-wrap items-center gap-2 text-xs">
        {(["All", "Admins", "Moderators", "New"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`rounded-full border-[1.5px] px-3 py-1 font-bold ${filter === f ? "border-[#0F0F0F] bg-coral text-white" : "border-[#0F0F0F]/40 bg-white"}`}>{f}</button>
        ))}
        <div className="ml-auto flex items-center gap-1 text-[11px] font-bold text-muted-foreground">
          Sort:
          <select value={sort} onChange={(e) => setSort(e.target.value as any)} className="rounded border border-[#0F0F0F]/30 bg-white px-1.5 py-0.5 text-[11px] font-bold">
            <option>Points</option><option>Newest</option><option>A-Z</option>
          </select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
        {list.map((b) => (
          <div key={b.id} className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-3 text-center" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <Link to="/u/$username" params={{ username: b.username }} className="block">
              <img src={b.avatar} className="mx-auto h-14 w-14 rounded-full border-[1.5px] border-[#0F0F0F]" alt="" />
              <div className="mt-1.5 flex items-center justify-center gap-1 text-sm font-extrabold hover:text-coral">
                <span className="truncate">{b.name.split(" ")[0]}</span>
                {b.verified && <BadgeCheck className="h-3 w-3 text-coral" />}
              </div>
              <div className="truncate text-[10px] font-bold text-muted-foreground">{b.title}</div>
              <div className="mt-1 text-[11px] font-extrabold text-coral">🏆 {(b.followers * 3).toLocaleString()} pts</div>
            </Link>
            <button onClick={(e) => { e.preventDefault(); toast.success(`Following ${b.name.split(" ")[0]}`); }} className="mt-2 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-white py-1 text-[11px] font-extrabold" style={{ boxShadow: "1px 1px 0 0 #0F0F0F" }}>Follow</button>
          </div>
        ))}
      </div>
    </section>
  );
}

function LeaderboardTab({ rows }: any) {
  const [period, setPeriod] = useState<"Week" | "Month" | "All Time">("Week");
  const [, setTick] = useState(0);
  useEffect(() => { const t = setInterval(() => setTick((x) => x + 1), 30000); return () => clearInterval(t); }, []);
  return (
    <section className="p-3 lg:p-0">
      <h2 className="mb-3 font-display text-xl font-extrabold">Leaderboard</h2>
      <div className="mb-3 flex gap-1.5">
        {(["Week", "Month", "All Time"] as const).map((p) => (
          <button key={p} onClick={() => setPeriod(p)} className={`rounded-full border-[1.5px] px-3 py-1 text-xs font-bold ${period === p ? "border-[#0F0F0F] bg-coral text-white" : "border-[#0F0F0F]/40 bg-white"}`}>This {p}</button>
        ))}
      </div>
      <ul className="space-y-1.5">
        {rows.slice(0, 15).map((r: any) => {
          const podium = r.rank <= 3;
          const podiumBg = r.rank === 1 ? "bg-[#FFF7D6]" : r.rank === 2 ? "bg-[#F0F0F0]" : r.rank === 3 ? "bg-[#FFE4CC]" : "bg-white";
          const medal = r.rank === 1 ? <Crown className="h-4 w-4 text-[#F5A623]" /> : r.rank === 2 ? <Medal className="h-4 w-4 text-gray-500" /> : r.rank === 3 ? <Medal className="h-4 w-4 text-[#CD7F32]" /> : null;
          return (
            <li key={r.builder.id}>
              <Link
                to="/u/$username"
                params={{ username: r.builder.username }}
                className={`flex items-center gap-3 rounded-xl border-[1.5px] border-[#0F0F0F] ${podiumBg} p-2.5 hover:bg-cream/60`}
                style={{ boxShadow: podium ? "3px 3px 0 0 #0F0F0F" : "1px 1px 0 0 #0F0F0F" }}
              >
                <div className="w-6 text-center text-sm font-extrabold text-muted-foreground">#{r.rank}</div>
                {medal}
                <img src={r.builder.avatar} className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F]" alt="" />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-extrabold">{r.builder.name}</div>
                  <div className="text-[11px] font-bold text-muted-foreground">{r.level}</div>
                </div>
                <div className="text-sm font-extrabold text-coral">{r.points.toLocaleString()}</div>
              </Link>
            </li>
          );
        })}
      </ul>
      <div className="sticky bottom-2 mt-4 flex items-center justify-between rounded-xl border-[1.5px] border-coral bg-cream p-3 text-sm font-extrabold" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
        <span>Your rank: #47</span>
        <span className="text-coral">1,240 pts</span>
      </div>
    </section>
  );
}

function AboutTab({ c, rules, onInvite }: any) {
  const admins = builders.slice(0, 2);
  const mods = builders.slice(2, 5);
  return (
    <section className="p-3 lg:p-0">
      <div className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
        <div className="flex items-center gap-2">
          <h1 className="font-display text-2xl font-extrabold">{c.name}</h1>
          <BadgeCheck className="h-5 w-5 text-coral" />
        </div>
        <p className="mt-2 text-sm text-muted-foreground">{c.description}</p>
        <div className="mt-3 flex flex-wrap gap-3 text-xs font-bold">
          <span>👥 <b>{c.members.toLocaleString()}</b> members</span>
          <span>🟢 <b>{Math.round(c.members / 10).toLocaleString()}</b> online</span>
          <span>🌏 <b>50+</b> countries</span>
          <span>📅 Created Jan 2024</span>
        </div>
      </div>

      <div className="mt-4 rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
        <h3 className="mb-2 font-display text-lg font-extrabold">Community Rules</h3>
        <ol className="space-y-2 text-sm">
          {rules.map((r: string, i: number) => (
            <li key={i} className="flex gap-2"><span className="font-extrabold text-coral">{i + 1}.</span> {r}</li>
          ))}
        </ol>
      </div>

      <div className="mt-4 rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
        <h3 className="mb-2 font-display text-lg font-extrabold">Admins & Moderators</h3>
        <div className="flex flex-wrap gap-2">
          {admins.map((b) => (
            <div key={b.id} className="flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-white pl-1 pr-3 py-1">
              <img src={b.avatar} className="h-7 w-7 rounded-full" alt="" />
              <span className="text-xs font-extrabold">{b.name}</span>
              <span className="rounded bg-coral/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase text-coral">Admin</span>
            </div>
          ))}
          {mods.map((b) => (
            <div key={b.id} className="flex items-center gap-2 rounded-full border-[1.5px] border-[#0F0F0F] bg-white pl-1 pr-3 py-1">
              <img src={b.avatar} className="h-7 w-7 rounded-full" alt="" />
              <span className="text-xs font-extrabold">{b.name}</span>
              <span className="rounded bg-cream px-1.5 py-0.5 text-[9px] font-extrabold uppercase text-foreground/70">Mod</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 flex gap-2">
        <button onClick={onInvite} className="flex-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-2.5 text-sm font-extrabold text-white" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>Invite People</button>
        <button className="rounded-md border-[1.5px] border-red-500/60 bg-white px-3 py-2.5 text-sm font-extrabold text-red-600">Leave</button>
        <button className="rounded-md border-[1.5px] border-red-500/60 bg-white px-3 py-2.5 text-sm font-extrabold text-red-600">Report</button>
      </div>
    </section>
  );
}

/* ============================== RIGHT SIDEBAR ============================== */
function RightSidebar({ c, bg, events, leaderboard, onInvite, onOpenEvent }: any) {
  return (
    <>
      <div className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
        <div className="flex items-center gap-2">
          <div className="grid h-10 w-10 place-items-center rounded-md text-sm font-extrabold text-white" style={{ background: bg }}>
            {c.icon?.slice(0, 2).toUpperCase() ?? c.name.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <div className="font-display font-extrabold">About</div>
            <div className="text-[11px] font-bold text-muted-foreground">{c.members.toLocaleString()} members</div>
          </div>
        </div>
        <p className="mt-2 line-clamp-3 text-xs text-muted-foreground">{c.description}</p>
        <button onClick={onInvite} className="mt-3 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-coral py-2 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>Invite People</button>
      </div>

      <div className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
        <h4 className="mb-2 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Top Members</h4>
        <ul className="space-y-2">
          {leaderboard.slice(0, 5).map((r: any) => (
            <li key={r.builder.id}>
              <Link
                to="/u/$username"
                params={{ username: r.builder.username }}
                className="flex items-center gap-2 rounded-md p-1 -m-1 hover:bg-cream"
              >
                <span className="w-4 text-[11px] font-extrabold text-muted-foreground">#{r.rank}</span>
                <img src={r.builder.avatar} className="h-7 w-7 rounded-full border border-[#0F0F0F]/30" alt="" />
                <div className="min-w-0 flex-1 truncate text-xs font-extrabold hover:text-coral">{r.builder.name}</div>
                <div className="text-[11px] font-extrabold text-coral">{r.points.toLocaleString()}</div>
              </Link>
            </li>
          ))}
        </ul>
      </div>

      <div className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-white p-4" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
        <h4 className="mb-2 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Upcoming Events</h4>
        <ul className="space-y-2.5">
          {events.slice(0, 3).map((e: any) => (
            <li key={e.id}>
              <button
                onClick={() => onOpenEvent?.(e)}
                className="flex w-full items-center gap-2 rounded-md p-1 text-left transition hover:bg-cream"
              >
                <div className="grid h-10 w-10 shrink-0 place-content-center rounded border border-[#0F0F0F]/30 bg-cream text-center">
                  <div className="text-[8px] font-extrabold uppercase">{e.month}</div>
                  <div className="text-sm font-extrabold leading-none">{e.day}</div>
                </div>
                <div className="min-w-0 flex-1 text-xs">
                  <div className="truncate font-extrabold hover:text-coral">{e.title}</div>
                  <div className="truncate text-[10px] font-bold text-muted-foreground">{e.when}</div>
                </div>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
}


/* ============================== COMPOSER SHEET ============================== */
function ComposerSheet({ communityName, onClose, onPublish }: { communityName: string; onClose: () => void; onPublish: (d: any) => void }) {
  const [type, setType] = useState<PostType>("post");
  const [body, setBody] = useState("");
  const [title, setTitle] = useState("");
  const [pollOpts, setPollOpts] = useState<string[]>(["", ""]);
  const [eventWhen, setEventWhen] = useState("");
  const [eventLocation, setEventLocation] = useState("");
  const [resourceUrl, setResourceUrl] = useState("");

  const types: { id: PostType; label: string; icon: any }[] = [
    { id: "post", label: "Post", icon: MessageCircle },
    { id: "prompt", label: "Prompt", icon: Sparkles },
    { id: "workflow", label: "Workflow", icon: Settings },
    { id: "poll", label: "Poll", icon: ThumbsUp },
    { id: "event", label: "Event", icon: Calendar },
    { id: "resource", label: "Resource", icon: FileText },
    { id: "question", label: "Question", icon: Info },
  ];

  const submit = () => {
    if (!body.trim()) { toast.error("Add some content first"); return; }
    onPublish({
      type, body, title: title || undefined,
      pollOptions: type === "poll" ? pollOpts : undefined,
      eventTitle: type === "event" ? title : undefined, eventWhen, eventLocation,
      resourceUrl: type === "resource" ? resourceUrl : undefined,
    });
  };

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-black/50 lg:items-center lg:justify-center" onClick={onClose}>
      <div className="mt-auto max-h-[92vh] w-full overflow-y-auto rounded-t-2xl border-t-[1.5px] border-[#0F0F0F] bg-white lg:m-auto lg:max-w-xl lg:rounded-2xl lg:border-[1.5px]" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }} onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 flex items-center justify-between border-b-[1.5px] border-[#0F0F0F] bg-white px-4 py-3">
          <button onClick={onClose} className="text-sm font-bold text-muted-foreground">Cancel</button>
          <div className="font-display font-extrabold">Create Post</div>
          <button onClick={submit} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>Post →</button>
        </div>
        <div className="p-4">
          <div className="mb-3 text-xs font-bold text-muted-foreground">Posting to: <span className="font-extrabold text-foreground">{communityName}</span> · <Globe className="inline h-3 w-3" /> Community</div>

          <div className="mb-3 flex gap-1.5 overflow-x-auto pb-1">
            {types.map((t) => {
              const Icon = t.icon;
              const active = type === t.id;
              return (
                <button key={t.id} onClick={() => setType(t.id)} className={`inline-flex shrink-0 items-center gap-1 rounded-full border-[1.5px] px-2.5 py-1 text-xs font-bold ${active ? "border-[#0F0F0F] bg-coral text-white" : "border-[#0F0F0F]/40 bg-white"}`}>
                  <Icon className="h-3 w-3" /> {t.label}
                </button>
              );
            })}
          </div>

          {(type === "event" || type === "resource" || type === "poll") && (
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={type === "event" ? "Event title" : type === "resource" ? "Resource title" : "Poll question"} className="mb-2 h-11 w-full rounded-md border-[1.5px] border-[#0F0F0F] px-3 text-sm outline-none" />
          )}

          <textarea autoFocus value={body} onChange={(e) => setBody(e.target.value)} placeholder="Write your post…" className="min-h-[140px] w-full rounded-md border-[1.5px] border-[#0F0F0F] p-3 text-sm outline-none" />

          {type === "poll" && (
            <div className="mt-2 space-y-2">
              {pollOpts.map((o, i) => (
                <input key={i} value={o} onChange={(e) => { const c = [...pollOpts]; c[i] = e.target.value; setPollOpts(c); }} placeholder={`Option ${i + 1}`} className="h-10 w-full rounded-md border-[1.5px] border-[#0F0F0F] px-3 text-sm outline-none" />
              ))}
              {pollOpts.length < 6 && (
                <button onClick={() => setPollOpts([...pollOpts, ""])} className="text-xs font-extrabold text-coral">+ Add option</button>
              )}
            </div>
          )}
          {type === "event" && (
            <div className="mt-2 space-y-2">
              <input value={eventWhen} onChange={(e) => setEventWhen(e.target.value)} placeholder="Date & time (e.g. Sat Jul 12, 7pm IST)" className="h-10 w-full rounded-md border-[1.5px] border-[#0F0F0F] px-3 text-sm outline-none" />
              <input value={eventLocation} onChange={(e) => setEventLocation(e.target.value)} placeholder="Location (Online or venue)" className="h-10 w-full rounded-md border-[1.5px] border-[#0F0F0F] px-3 text-sm outline-none" />
            </div>
          )}
          {type === "resource" && (
            <input value={resourceUrl} onChange={(e) => setResourceUrl(e.target.value)} placeholder="Resource URL" className="mt-2 h-10 w-full rounded-md border-[1.5px] border-[#0F0F0F] px-3 text-sm outline-none" />
          )}

          <div className="mt-3 flex flex-wrap gap-2 text-xs">
            {[
              { icon: Paperclip, label: "Photo" }, { icon: LinkIcon, label: "Link" },
              { icon: FileText, label: "File" }, { icon: Hash, label: "Tag" },
            ].map(({ icon: Icon, label }) => (
              <button key={label} className="inline-flex items-center gap-1 rounded-md border-[1.5px] border-[#0F0F0F]/30 bg-white px-2.5 py-1 font-bold text-foreground/70">
                <Icon className="h-3.5 w-3.5" /> {label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================== INVITE MODAL ============================== */
function CommunityInvite({ c, onClose }: any) {
  const url = typeof window !== "undefined" ? `${window.location.origin}/communities/${c.slug}?invite=1` : "";
  const [emails, setEmails] = useState("");
  const [q, setQ] = useState("");
  const filtered = q ? builders.filter((b) => b.name.toLowerCase().includes(q.toLowerCase())).slice(0, 6) : builders.slice(0, 6);
  const copy = () => { navigator.clipboard?.writeText(url); toast.success("Invite link copied"); };
  return (
    <div className="fixed inset-0 z-[100] grid place-items-center overflow-y-auto bg-black/60 p-4" onClick={onClose}>
      <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-5" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white" aria-label="Close"><X className="h-4 w-4" /></button>
        <h3 className="font-display text-lg font-extrabold">Invite to {c.name}</h3>

        <div className="mt-3 text-xs font-extrabold uppercase text-muted-foreground">Invite link</div>
        <div className="mt-1 flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-cream p-2">
          <span className="min-w-0 flex-1 truncate px-2 text-xs font-mono">{url}</span>
          <button onClick={copy} className="shrink-0 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}><Copy className="mr-1 inline h-3 w-3" />Copy</button>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2">
          {[
            { label: "WhatsApp", bg: "#25D366", href: `https://wa.me/?text=${encodeURIComponent(`Join ${c.name} on VibeCoder — ${url}`)}` },
            { label: "LinkedIn", bg: "#0A66C2", href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}` },
            { label: "Twitter", bg: "#0F0F0F", href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(`Join ${c.name} on VibeCoder`)}&url=${encodeURIComponent(url)}` },
          ].map((o) => (
            <a key={o.label} href={o.href} target="_blank" rel="noreferrer" className="rounded-md border-[1.5px] border-[#0F0F0F] py-2 text-center text-xs font-extrabold text-white" style={{ background: o.bg, boxShadow: "2px 2px 0 0 #0F0F0F" }}>{o.label}</a>
          ))}
        </div>

        <div className="mt-4 text-xs font-extrabold uppercase text-muted-foreground">Invite by email</div>
        <textarea value={emails} onChange={(e) => setEmails(e.target.value)} placeholder="email@example.com, another@email.com…" className="mt-1 min-h-[70px] w-full rounded-md border-[1.5px] border-[#0F0F0F] p-2 text-sm outline-none" />
        <button onClick={() => { if (!emails.trim()) return; toast.success(`Invites sent to ${emails.split(",").length} people`); setEmails(""); }} className="mt-2 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-coral py-2 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>Send Invites</button>

        <div className="mt-4 text-xs font-extrabold uppercase text-muted-foreground">Invite VibeCoder builders</div>
        <div className="mt-1 flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-white p-1.5">
          <Search className="ml-1 h-4 w-4" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search builders…" className="min-w-0 flex-1 bg-transparent text-sm outline-none" />
        </div>
        <ul className="mt-2 max-h-56 space-y-1 overflow-y-auto">
          {filtered.map((b) => (
            <li key={b.id} className="flex items-center gap-2 rounded-md border border-[#0F0F0F]/15 bg-white p-2">
              <img src={b.avatar} className="h-8 w-8 rounded-full border border-[#0F0F0F]/30" alt="" />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-extrabold">{b.name}</div>
                <div className="truncate text-[11px] font-bold text-muted-foreground">{b.title}</div>
              </div>
              <button onClick={() => toast.success(`Invited ${b.name}`)} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-2.5 py-1 text-xs font-extrabold" style={{ boxShadow: "1px 1px 0 0 #0F0F0F" }}>Invite</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

/* ============================== SEARCH OVERLAY ============================== */
function SearchOverlay({ q, onQ, onClose, posts, resources, events, community }: any) {
  const [scope, setScope] = useState<"Posts" | "Members" | "Resources" | "Events">("Posts");
  const filter = <T,>(arr: T[], key: (t: T) => string) => q ? arr.filter((x) => key(x).toLowerCase().includes(q.toLowerCase())) : arr.slice(0, 8);
  return (
    <div className="fixed inset-0 z-[95] flex flex-col bg-cream">
      <div className="flex items-center gap-2 border-b-[1.5px] border-[#0F0F0F] px-2 py-2">
        <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }} aria-label="Back"><ArrowLeft className="h-4 w-4" /></button>
        <div className="flex min-w-0 flex-1 items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
          <Search className="h-4 w-4" />
          <input autoFocus value={q} onChange={(e) => onQ(e.target.value)} placeholder={`Search in ${community}…`} className="min-w-0 flex-1 bg-transparent text-sm outline-none" />
        </div>
      </div>
      <div className="flex gap-1.5 overflow-x-auto border-b border-[#0F0F0F]/10 px-2 py-2">
        {(["Posts", "Members", "Resources", "Events"] as const).map((s) => (
          <button key={s} onClick={() => setScope(s)} className={`shrink-0 rounded-full border-[1.5px] px-3 py-1 text-xs font-bold ${scope === s ? "border-[#0F0F0F] bg-coral text-white" : "border-[#0F0F0F]/40 bg-white"}`}>{s}</button>
        ))}
      </div>
      <div className="flex-1 space-y-2 overflow-y-auto p-3">
        {scope === "Posts" && filter(posts, (p: any) => (p.title || "") + p.body).map((p: any) => (
          <div key={p.id} className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-white p-3 text-sm">
            <div className="font-extrabold">{p.title || p.body.slice(0, 60)}</div>
            <div className="mt-1 line-clamp-2 text-xs text-muted-foreground">{p.body}</div>
          </div>
        ))}
        {scope === "Members" && filter(builders, (b: any) => b.name + b.title).map((b: any) => (
          <div key={b.id} className="flex items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white p-2">
            <img src={b.avatar} className="h-9 w-9 rounded-full" alt="" />
            <div className="min-w-0 flex-1"><div className="truncate text-sm font-extrabold">{b.name}</div><div className="truncate text-[11px] font-bold text-muted-foreground">{b.title}</div></div>
          </div>
        ))}
        {scope === "Resources" && filter(resources, (r: any) => r.title).map((r: any) => (
          <div key={r.id} className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-white p-3 text-sm font-bold">{r.title}</div>
        ))}
        {scope === "Events" && filter(events, (e: any) => e.title + e.location).map((e: any) => (
          <div key={e.id} className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-white p-3 text-sm font-bold">{e.title} · <span className="font-normal text-muted-foreground">{e.when}</span></div>
        ))}
      </div>
    </div>
  );
}

/* ============================== SHARE MODAL ============================== */
function ShareModal({ name, description, onClose }: { name: string; description?: string; onClose: () => void }) {
  const url = typeof window !== "undefined" ? window.location.href : "";
  const text = `${name}${description ? ` — ${description}` : ""}`;
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(url); setCopied(true); toast.success("Link copied"); setTimeout(() => setCopied(false), 1500); }
    catch { toast.error("Couldn't copy the link"); }
  };
  const nativeShare = async () => {
    try {
      if ((navigator as any).share) { await (navigator as any).share({ title: name, text, url }); onClose(); }
      else copy();
    } catch {}
  };
  const targets = [
    { label: "WhatsApp", bg: "#25D366", href: `https://wa.me/?text=${encodeURIComponent(`${text} — ${url}`)}` },
    { label: "Twitter", bg: "#0F0F0F", href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}` },
    { label: "LinkedIn", bg: "#0A66C2", href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}` },
    { label: "Telegram", bg: "#229ED9", href: `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}` },
    { label: "Facebook", bg: "#1877F2", href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}` },
    { label: "Email", bg: "#6B7280", href: `mailto:?subject=${encodeURIComponent(name)}&body=${encodeURIComponent(`${text}\n\n${url}`)}` },
  ];
  return (
    <div className="fixed inset-0 z-[110] flex items-end justify-center overflow-y-auto bg-black/60 p-0 lg:items-center lg:p-4" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-t-2xl border-t-[1.5px] border-[#0F0F0F] bg-white p-5 lg:rounded-2xl lg:border-[1.5px]"
        style={{ boxShadow: "6px 6px 0 0 #0F0F0F", paddingBottom: "calc(1.25rem + env(safe-area-inset-bottom))" }}
      >
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-black/20 lg:hidden" />
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Share</div>
            <div className="font-display text-lg font-extrabold leading-tight">{name}</div>
          </div>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F]" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-4 flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-cream p-2">
          <span className="min-w-0 flex-1 truncate px-1 text-[11px] font-mono">{url}</span>
          <button onClick={copy} className="shrink-0 rounded-md border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1 text-xs font-extrabold text-white" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            {copied ? <Check className="inline h-3 w-3" /> : <Copy className="inline h-3 w-3" />} {copied ? "Copied" : "Copy"}
          </button>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2">
          {targets.map((o) => (
            <a
              key={o.label}
              href={o.href}
              target="_blank"
              rel="noreferrer"
              className="rounded-md border-[1.5px] border-[#0F0F0F] py-2 text-center text-[11px] font-extrabold text-white"
              style={{ background: o.bg, boxShadow: "2px 2px 0 0 #0F0F0F" }}
            >
              {o.label}
            </a>
          ))}
        </div>
        {typeof navigator !== "undefined" && (navigator as any).share && (
          <button onClick={nativeShare} className="mt-3 grid h-10 w-full place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-white text-xs font-extrabold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
            <span className="inline-flex items-center gap-1.5"><Share2 className="h-3.5 w-3.5" /> More options…</span>
          </button>
        )}
      </div>
    </div>
  );
}

/* ============================== EVENT DETAILS MODAL ============================== */
function EventDetailsModal({ event, communityName, going, onRsvp, onClose }: {
  event: any; communityName: string; going: boolean; onRsvp: () => void; onClose: () => void;
}) {
  const org = builders[event.organizerIdx % builders.length];
  const attendees = builders.slice(0, Math.min(8, builders.length));
  const isOnline = (event.location ?? "").toLowerCase().includes("online");
  const addToCal = () => {
    const start = new Date(); start.setDate(event.day || start.getDate()); start.setHours(19, 0, 0, 0);
    const end = new Date(start.getTime() + 60 * 60 * 1000);
    const fmtDate = (d: Date) => d.toISOString().replace(/[-:]|\.\d{3}/g, "");
    const href = `https://www.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(event.title)}&dates=${fmtDate(start)}/${fmtDate(end)}&details=${encodeURIComponent(`Hosted in ${communityName}. ${event.when}`)}&location=${encodeURIComponent(event.location ?? "")}`;
    window.open(href, "_blank", "noopener");
  };
  return (
    <div className="fixed inset-0 z-[110] flex items-end justify-center overflow-y-auto bg-black/60 p-0 lg:items-center lg:p-4" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-2xl border-t-[1.5px] border-[#0F0F0F] bg-white lg:rounded-2xl lg:border-[1.5px]"
        style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b-[1.5px] border-[#0F0F0F] bg-white px-4 py-3">
          <div className="text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Community Event</div>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-[#0F0F0F]" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5">
          <div className="flex items-start gap-3">
            <div className="grid h-16 w-16 shrink-0 place-content-center rounded-xl border-[1.5px] border-[#0F0F0F] bg-cream text-center" style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}>
              <div className="text-[10px] font-extrabold uppercase tracking-wider">{event.month}</div>
              <div className="text-2xl font-extrabold leading-none">{event.day}</div>
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-xl font-extrabold leading-tight">{event.title}</h2>
              <div className="mt-1 text-[11px] font-bold text-muted-foreground">in {communityName}</div>
              <span className={`mt-2 inline-flex items-center gap-1 rounded-full border-[1.5px] border-[#0F0F0F] px-2 py-0.5 text-[10px] font-extrabold ${isOnline ? "bg-[#DBEAFE] text-[#1D4ED8]" : "bg-[#FEF3C7] text-[#92400E]"}`}>
                {isOnline ? "🌐 Online" : "📍 In-person"}
              </span>
            </div>
          </div>

          <div className="mt-4 grid gap-2 rounded-xl border-[1.5px] border-[#0F0F0F] bg-cream p-3 text-sm">
            <div className="flex items-center gap-2 font-bold"><Clock className="h-4 w-4 text-coral" /> {event.when}</div>
            <div className="flex items-center gap-2 font-bold"><MapPin className="h-4 w-4 text-coral" /> {event.location}</div>
            <div className="flex items-center gap-2 font-bold"><Users className="h-4 w-4 text-coral" /> {event.going + (going ? 1 : 0)} going</div>
          </div>

          <div className="mt-4">
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">About this event</div>
            <p className="mt-1.5 text-sm leading-relaxed text-foreground/85">
              {event.description ?? `Join ${org.name} and the ${communityName} community for "${event.title}". We'll ship together, share what's working, and answer your questions live. Bring your build, your questions, and your energy.`}
            </p>
          </div>

          <div className="mt-4 flex items-center gap-2 rounded-lg border-[1.5px] border-[#0F0F0F]/25 bg-white p-2">
            <img src={org.avatar} alt="" className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F]" />
            <div className="min-w-0 flex-1">
              <div className="text-[10px] font-bold uppercase text-muted-foreground">Hosted by</div>
              <div className="truncate text-sm font-extrabold">{org.name}</div>
            </div>
          </div>

          <div className="mt-4">
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground">Who's going</div>
            <div className="mt-2 flex items-center gap-2">
              <div className="flex -space-x-2">
                {attendees.map((b) => (
                  <img key={b.id} src={b.avatar} alt="" className="h-8 w-8 rounded-full border-[1.5px] border-white" />
                ))}
              </div>
              <span className="text-[11px] font-bold text-muted-foreground">+{event.going + (going ? 1 : 0) - attendees.length > 0 ? event.going + (going ? 1 : 0) - attendees.length : 0} others</span>
            </div>
          </div>

          <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row">
            <button
              onClick={addToCal}
              className="grid h-11 flex-1 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-white text-xs font-extrabold"
              style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
            >
              <span className="inline-flex items-center gap-1.5"><Calendar className="h-4 w-4" /> Add to Calendar</span>
            </button>
            <button
              onClick={onRsvp}
              className={`grid h-11 flex-1 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] text-sm font-extrabold text-white ${going ? "bg-success" : "bg-coral"}`}
              style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
            >
              {going ? "✓ You're going" : "RSVP — I'm Going"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
