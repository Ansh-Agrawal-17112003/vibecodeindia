import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/community/social")({
  head: () => ({
    meta: [
      { title: "Discord · X · GitHub · VibeCode" },
      { name: "description", content: "The Vibe Feed is where you ship. These are where you talk trash, share memes, and pair on late-night bugs." },
      { property: "og:title", content: "Discord · X · GitHub · VibeCode" },
      { property: "og:description", content: "The Vibe Feed is where you ship. These are where you talk trash, share memes, and pair on late-night bugs." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/community/social" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/community/social" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Discord · X · GitHub"
      breadcrumb={[{"label":"Community","to":"/"}]}
      title="Hang out with builders."
      intro="The Vibe Feed is where you ship. These are where you talk trash, share memes, and pair on late-night bugs."
      toc={[{"id":"where","label":"Find us"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="where" title="Find us"><NotionFeatureGrid items={[{"title":"Discord","description":"18k+ builders. Channels for every stack and city."},{"title":"X (Twitter)","description":"Daily wins, threads, and beef. Follow @joinvibecode."},{"title":"GitHub","description":"Open-source SDKs, prompt library, and community repos."},{"title":"YouTube","description":"Weekly demo nights and interviews with founders."}]} /></NotionSection>
      <NotionCallout emoji="💬" tone="cream">Community rules are simple: no spam, no scams, no crypto shilling. Everything else goes.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="How do I get the Discord invite?" a="Sign in and check the sidebar — the invite is one click away." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
