import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/resources/newsletter")({
  head: () => ({
    meta: [
      { title: "Newsletter · VibeCode" },
      { name: "description", content: "One email a week. The best builds, prompts, workflows, and jobs from the Indian AI community — hand-picked, never generated." },
      { property: "og:title", content: "Newsletter · VibeCode" },
      { property: "og:description", content: "One email a week. The best builds, prompts, workflows, and jobs from the Indian AI community — hand-picked, never generated." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/resources/newsletter" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/resources/newsletter" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Newsletter"
      breadcrumb={[{"label":"Resources","to":"/"}]}
      title="Weekly signal. Zero noise."
      intro="One email a week. The best builds, prompts, workflows, and jobs from the Indian AI community — hand-picked, never generated."
      toc={[{"id":"inside","label":"Inside every issue"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="inside" title="Inside every issue"><NotionList items={["5 builds you should study this week","3 prompts with real production usage","2 open roles from vetted teams","1 essay from a builder in the trenches"]} /></NotionSection>
      <NotionCallout emoji="📬" tone="coral">Sent every Sunday at 8:30 IST. Unsubscribe in one click, no dark patterns.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="How do I subscribe?" a="Create a free account — the newsletter is on by default and toggleable in settings." />
          <NotionToggle q="Do you sell my email?" a="Never. We do not run ads and we do not share the list." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
