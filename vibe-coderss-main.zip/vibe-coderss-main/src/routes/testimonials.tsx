import { createFileRoute, Link } from "@tanstack/react-router";
import { Quote, Star, Search, ArrowRight } from "lucide-react";
import { useMemo, useState } from "react";
import { Shell } from "@/components/site/Shell";
import { SectionHeader, CoralWord } from "@/components/site/SectionHeader";
import { AutocompleteInput } from "@/components/site/AutocompleteInput";

export const Route = createFileRoute("/testimonials")({
  head: () => ({
    meta: [
      { title: 'Testimonials · VibeCode — Loved by 120,000+ AI Builders' },
      { name: "description", content: 'Real stories from Indian AI builders, freelancers and founders shipping on VibeCode.' },
      { property: "og:title", content: 'Testimonials · VibeCode — Loved by 120,000+ AI Builders' },
      { property: "og:description", content: 'Real stories from Indian AI builders, freelancers and founders shipping on VibeCode.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/testimonials' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Testimonials · VibeCode — Loved by 120,000+ AI Builders' },
      { name: "twitter:description", content: 'Real stories from Indian AI builders, freelancers and founders shipping on VibeCode.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/testimonials' }],
  }),
  component: TestimonialsPage,
});

const FIRST = ["Aarav","Vivaan","Aditya","Krishna","Rudra","Arjun","Ishaan","Reyansh","Kabir","Rohan","Yash","Karan","Dev","Sahil","Manav","Aryan","Veer","Tanish","Atharv","Om","Priya","Ananya","Diya","Aanya","Saanvi","Myra","Aadhya","Anika","Kiara","Riya","Sara","Ishita","Neha","Pooja","Tara","Mira","Aisha","Zara","Nisha","Meera","Ritu","Sneha","Kavya","Trisha","Rhea","Aditi","Naina","Esha","Avni","Tanya"];
const LAST = ["Mehta","Sharma","Iyer","Reddy","Singh","Kapoor","Joshi","Khan","Nair","Patel","Gupta","Verma","Bose","Das","Ghosh","Chopra","Malhotra","Bhat","Pillai","Rao","Menon","Sinha","Yadav","Saxena","Tiwari"];
const ROLES = ["AI Engineer","Founder","Indie Hacker","Workflow Architect","Prompt Engineer","Agency Lead","Product Designer","Full-stack Builder","Automation Consultant","Solo Dev","Startup CTO","Growth Engineer","RAG Specialist","No-Code Pro","DevRel","ML Researcher","AI PM","Cursor Power User","Lovable Builder","n8n Freelancer"];
const CITIES = ["Bangalore","Mumbai","Delhi","Pune","Hyderabad","Chennai","Gurgaon","Noida","Kolkata","Ahmedabad","Jaipur","Remote"];
const QUOTES = [
  "VibeCode helped me land 3 clients in my first month. The talent pool is unreal.",
  "Found my technical co-founder on VibeCode. We've raised our pre-seed already.",
  "The community is genuinely supportive — no recruiter spam, just builders helping builders.",
  "I switched from Upwork to VibeCode and tripled my rate. Clients here value AI expertise.",
  "Best decision I made this year. The prompts library alone is worth a year of Pro.",
  "Hired our entire 6-person AI team from VibeCode in under 4 weeks. Insane quality.",
  "Shipped my first SaaS with help from the Lovable community here. ₹40K MRR in month 2.",
  "The n8n workflows shared by other builders save me hours every week.",
  "I'm a college student and got my first AI internship through VibeCode. Life-changer.",
  "Coming from a non-tech background, VibeCode made AI building approachable for me.",
  "The Insider hubs inside communities are 10× more useful than Slack or Discord.",
  "Stopped doom-scrolling Twitter. VibeCode is where my real builder friends are now.",
  "Posted a project on Friday, had 4 enterprise leads in DMs by Monday.",
  "Found a senior AI engineer for our startup in 3 days. Recruiting was usually 3 months.",
  "The Cursor power user community is gold. Picked up tricks I'd never have found on YouTube.",
  "I run an agency. We staff 80% of new gigs from VibeCode now. Faster than any platform.",
  "VibeCode's prompt library kicked my output 4×. I cancelled three other tool subscriptions.",
  "Joined for fun, landed a ₹35L role at an AI-first startup six weeks later.",
  "The Made-in-India AI community is something special. Genuine builders, zero LinkedIn fluff.",
  "Honestly the only community where every member actually ships product. Refreshing.",
  "Cracked my first product launch from the launch playbook shared in Pro community.",
  "Got featured on the home page. Two YCombinator partners DM'd me the same day.",
  "I moved my freelance pipeline entirely off Fiverr. Clients here actually pay on time.",
  "Built and sold a side project worth ₹6L thanks to feedback from this community.",
  "The hiring stack here is brutal-fast. Posted a JD, hired in 9 days, zero recruiter fees.",
  "Vibe coders here are 5 years ahead of the average tech twitter crowd.",
  "Replaced my Slack, Discord, and Notion habit with VibeCode. Sounds dramatic, true story.",
  "The workflow library single-handedly automated 12 hours/week off my agency ops.",
  "I'm a designer — I found 3 amazing devs to ship my product ideas. Magic.",
  "We hired 4 vibe coders for our ed-tech startup. Output is wild compared to traditional devs.",
  "VibeCode is the only place where 'I built this in a weekend' is true 90% of the time.",
  "Pro plan paid for itself in 2 days through one inbound client.",
  "Got my first paid prompt engineering gig from a hiring DM here. Total game changer.",
  "Indian AI talent finally has a real home. Long overdue. Thank you, VibeCode team.",
  "Even as a beginner I feel welcomed. People actually answer questions thoughtfully.",
  "The events calendar surfaces real, in-person meetups in my city. Already met 20+ builders IRL.",
];
const TOPICS = ["All","Builders","Founders","Hirers","Freelancers","Students","Agencies"];

function avatar(seed: string) {
  return `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed)}`;
}

type T = { id: number; name: string; role: string; city: string; quote: string; topic: string; rating: number; avatar: string; verified: boolean };

const TESTIMONIALS: T[] = Array.from({ length: 132 }).map((_, i) => {
  const first = FIRST[(i * 7) % FIRST.length];
  const last = LAST[(i * 11) % LAST.length];
  const name = `${first} ${last}`;
  const role = ROLES[i % ROLES.length];
  const topic =
    role.includes("Founder") || role.includes("CTO") ? "Founders" :
    role.includes("Agency") ? "Agencies" :
    role.includes("Freelancer") || role.includes("Solo") ? "Freelancers" :
    role.includes("PM") || role.includes("DevRel") ? "Hirers" :
    i % 11 === 0 ? "Students" : "Builders";
  return {
    id: i + 1, name, role, city: CITIES[i % CITIES.length],
    quote: QUOTES[i % QUOTES.length],
    topic, rating: 4 + ((i * 3) % 2) + (i % 3 === 0 ? 1 : 0) > 5 ? 5 : 5,
    avatar: avatar(`${first}-${last}-${i}`),
    verified: i % 4 === 0,
  };
});

function TestimonialsPage() {
  const [q, setQ] = useState("");
  const [topic, setTopic] = useState("All");
  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return TESTIMONIALS.filter((x) =>
      (topic === "All" || x.topic === topic) &&
      (!t || x.name.toLowerCase().includes(t) || x.role.toLowerCase().includes(t) || x.quote.toLowerCase().includes(t) || x.city.toLowerCase().includes(t))
    );
  }, [q, topic]);

  return (
    <Shell>
      <section className="container-page py-12">
        <SectionHeader
          label="TESTIMONIALS"
          title={<>Loved by <CoralWord>120,000+ AI builders.</CoralWord></>}
          subtitle="Real stories from founders, freelancers, agencies and students shipping with VibeCode every single day."
        />

        {/* Search + filter */}
        <div className="mx-auto mt-8 max-w-3xl">
          <div className="card-flat flex items-center gap-3 p-2 pl-4">
            <Search className="h-4 w-4 text-muted-foreground" />
            <AutocompleteInput
              value={q}
              onChange={setQ}
              placeholder="Search testimonials by name, role, city or keyword..."
              className="h-10 flex-1 bg-transparent text-sm outline-none"
              suggestions={TESTIMONIALS.flatMap((t) => [t.name, t.role, t.city, t.topic])}
            />
          </div>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {TOPICS.map((c) => (
              <button
                key={c}
                onClick={() => setTopic(c)}
                className={`rounded-full border-[1.5px] border-[#0F0F0F] px-3 py-1 text-xs font-bold transition ${topic === c ? "bg-coral text-white" : "bg-card text-foreground hover:bg-coral hover:text-white"}`}
                style={topic === c ? { boxShadow: "2px 2px 0 0 #0F0F0F" } : undefined}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Counter strip */}
        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {[
            { n: "120K+", l: "AI Builders" },
            { n: "4.9 / 5", l: "Average Rating" },
            { n: "98%", l: "Would Recommend" },
          ].map((s) => (
            <div key={s.l} className="card-editorial p-5 text-center">
              <div className="font-display text-3xl font-extrabold">{s.n}</div>
              <div className="mt-1 text-xs font-bold uppercase tracking-wider text-muted-foreground">{s.l}</div>
            </div>
          ))}
        </div>

        {/* Grid */}
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((t) => (
            <article key={t.id} className="card-editorial flex h-full flex-col p-5">
              <Quote className="h-5 w-5 text-coral" />
              <p className="mt-3 flex-1 text-sm leading-relaxed">"{t.quote}"</p>
              <div className="mt-4 flex items-center gap-3 border-t-[1.5px] border-[#0F0F0F] pt-3">
                <img src={t.avatar} alt={t.name} className="h-10 w-10 rounded-full border-[1.5px] border-[#0F0F0F] bg-card" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <div className="truncate text-sm font-bold">{t.name}</div>
                    {t.verified && <span className="grid h-3.5 w-3.5 place-items-center rounded-full bg-coral text-[8px] font-bold text-white">✓</span>}
                  </div>
                  <div className="truncate text-xs text-muted-foreground">{t.role} · {t.city}</div>
                </div>
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, k) => <Star key={k} className="h-3 w-3 fill-gold text-gold" />)}
                </div>
              </div>
            </article>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="card-editorial mt-10 p-12 text-center text-sm text-muted-foreground">
            No testimonials match your search.
          </div>
        )}

        {/* CTA */}
        <div className="mt-16 card-editorial flex flex-col items-center gap-4 p-10 text-center">
          <span className="pill-badge bg-gold text-[#0F0F0F]">JOIN THE COMMUNITY</span>
          <h2 className="font-display text-3xl font-extrabold md:text-4xl">
            Add your story to the <CoralWord>VibeCode wall.</CoralWord>
          </h2>
          <p className="max-w-xl text-sm text-muted-foreground">
            Loved building with VibeCode? Share what shipped — we feature the best stories on the home page.
          </p>
          <div className="mt-2 flex flex-wrap gap-3">
            <Link to="/submit" className="btn-coral">Share your story <ArrowRight className="h-4 w-4" /></Link>
            <Link to="/signup" className="btn-outline-dark">Create your profile</Link>
          </div>
        </div>
      </section>
    </Shell>
  );
}
