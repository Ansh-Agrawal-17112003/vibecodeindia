import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/solutions/community-leaders")({
  head: () => ({
    meta: [
      { title: "For Community Leaders · VibeCode" },
      { name: "description", content: "Everything you need to run a real classroom — lectures, chat, XP, streaks, and monetization — without stitching 6 tools together." },
      { property: "og:title", content: "For Community Leaders · VibeCode" },
      { property: "og:description", content: "Everything you need to run a real classroom — lectures, chat, XP, streaks, and monetization — without stitching 6 tools together." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/solutions/community-leaders" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/solutions/community-leaders" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="For Community Leaders"
      breadcrumb={[{"label":"Solutions","to":"/"}]}
      title="Run cohorts on autopilot."
      intro="Everything you need to run a real classroom — lectures, chat, XP, streaks, and monetization — without stitching 6 tools together."
      toc={[{"id":"stack","label":"Your entire stack in one place"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="stack" title="Your entire stack in one place"><NotionFeatureGrid items={[{"title":"Live + recorded lectures","description":"Upload once, stream forever. Auto-captioned."},{"title":"Real classroom chat","description":"Threads, reactions, and pinned answers."},{"title":"XP and streaks","description":"Retention baked in — members come back daily."},{"title":"Payments and gating","description":"Sell access, drip content, and refund with one click."}]} /></NotionSection>
      <NotionCallout emoji="🎓" tone="gold">Community-as-a-Service: we run the ops, you focus on teaching. Ask about our done-for-you rollout.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Can I migrate from Discord/WhatsApp?" a="Yes. We help you import members, pin content, and run a launch week." />
          <NotionToggle q="What is the revenue split?" a="You keep 90%. We take 10% platform fee, capped for large cohorts." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
