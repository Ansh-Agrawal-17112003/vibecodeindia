import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  ArrowLeft, Share2, Users, Circle, Calendar as CalIcon, MapPin, Check, Lock,
  MessageCircle, Sparkles, GitBranch, Video, Trophy, CalendarDays, Copy, X, Loader2, Star,
} from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { allCommunities, builders, communities as seededCommunities } from "@/lib/mock-data";
import { getPosts, getTopics, communityId } from "@/lib/community-seed";
import { sharePage } from "@/lib/share";
import { upiIntent, upiQrUrl, PAYEE_UPI_ID } from "@/lib/payee";
import { getMemberships } from "@/components/site/JoinCommunityModal";

const ICON_BG = ["#E8623A", "#2DD4BF", "#F5A623", "#7C3AED", "#FF4D8D", "#E11D48"];

type PricingType = "free" | "paid_monthly" | "paid_onetime";
type CommunityRow = {
  id: string;
  slug: string;
  name: string;
  icon: string | null;
  description: string | null;
  banner_url: string | null;
  member_count: number;
  is_official: boolean;
  pricing_type: PricingType;
  price_inr: number;
  trial_days: number;
};

type Search = { join?: "1"; redirect?: string };

export const Route = createFileRoute("/communities_/$slug")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    join: s.join === "1" ? "1" : undefined,
  }),
  loader: ({ params }) => {
    const seed = seededCommunities.find((x) => x.slug === params.slug);
    return { slug: params.slug, seed: seed ?? null };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.seed?.name ?? "Community"} · VibeCoder` },
      { name: "description", content: loaderData?.seed?.description ?? "Join a VibeCoder builder community." },
    ],
  }),
  component: CommunityPreview,
  notFoundComponent: () => (
    <Shell>
      <div className="container-page py-20 text-center">
        <h1 className="font-display text-3xl font-extrabold">Community not found</h1>
        <Link to="/communities" className="mt-4 inline-block text-coral underline">Browse all communities</Link>
      </div>
    </Shell>
  ),
});

function CommunityPreview() {
  const { slug, seed } = Route.useLoaderData();
  const search = Route.useSearch();
  const nav = useNavigate();
  const { user } = useAuth();

  const [dbRow, setDbRow] = useState<CommunityRow | null>(null);
  const [dbLoading, setDbLoading] = useState(true);
  const [membership, setMembership] = useState<{ status: string } | null>(null);
  const [joining, setJoining] = useState(false);
  const [paySheetOpen, setPaySheetOpen] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [pendingFlow, setPendingFlow] = useState<"free" | "paid" | null>(null);

  // Fallback to seed / mock lookup so UI never blanks while DB resolves.
  const fallback = seed ?? allCommunities().find((x) => x.slug === slug);
  if (!fallback && !dbLoading && !dbRow) throw notFound();

  const c = useMemo(() => ({
    id: dbRow?.id ?? `mock-${slug}`,
    slug,
    name: dbRow?.name ?? fallback?.name ?? slug,
    icon: dbRow?.icon ?? fallback?.icon ?? "🚀",
    description: dbRow?.description ?? fallback?.description ?? "",
    banner_url: dbRow?.banner_url ?? null,
    members: dbRow?.member_count ?? fallback?.members ?? 0,
    isOfficial: dbRow?.is_official ?? fallback?.isOfficial ?? false,
    pricing_type: (dbRow?.pricing_type ?? "free") as PricingType,
    price_inr: dbRow?.price_inr ?? 0,
    trial_days: dbRow?.trial_days ?? 0,
  }), [dbRow, fallback, slug]);

  const online = Math.max(24, Math.round(c.members * 0.12));
  const bg = ICON_BG[communityId(slug) % ICON_BG.length];
  const isPaid = c.pricing_type !== "free" && c.price_inr > 0;
  const priceLabel = isPaid ? `₹${c.price_inr}${c.pricing_type === "paid_monthly" ? "/month" : " one-time"}` : "FREE";

  // Load DB row + membership
  useEffect(() => {
    let alive = true;
    (async () => {
      const { data } = await supabase
        .from("communities")
        .select("id, slug, name, icon, description, banner_url, member_count, is_official, pricing_type, price_inr, trial_days")
        .eq("slug", slug)
        .maybeSingle();
      if (!alive) return;
      setDbRow((data as CommunityRow | null) ?? null);
      setDbLoading(false);
      if (data && user) {
        const { data: m } = await supabase
          .from("community_members").select("status")
          .eq("community_id", data.id).eq("profile_id", user.id).maybeSingle();
        if (alive) setMembership(m ?? null);
      }
      // Mock-only community fallback: check local membership too
      if (!data && alive && getMemberships().some((m) => m.slug === slug)) {
        setMembership({ status: "active" });
      }
    })();
    return () => { alive = false; };
  }, [slug, user]);

  // Auto-run join after returning from /auth?redirect=…&join=1
  useEffect(() => {
    if (search.join === "1" && user && dbRow && !membership && !joining) {
      if (isPaid) setPaySheetOpen(true);
      else handleFreeJoin();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search.join, user, dbRow, membership]);

  async function handleFreeJoin() {
    setJoining(true);
    // Real DB community + signed-in user: create active member row.
    if (dbRow && user) {
      const { error } = await supabase.from("community_members").insert({
        community_id: dbRow.id, profile_id: user.id, status: "active",
      });
      if (error && !error.message.includes("duplicate")) {
        // Non-fatal — we still let them into the community optimistically via local membership.
        console.warn("community_members insert failed:", error.message);
      } else {
        try { await supabase.rpc("award_xp", { _action_type: "COMMUNITY_JOIN", _xp: 50 }); } catch {}
      }
    }
    // Always persist local membership so the /feed gate lets us in immediately,
    // whether the community is DB-backed, mock-only, or the DB insert was blocked.
    try {
      const list = getMemberships().filter((m) => m.slug !== slug);
      list.push({
        slug, name: c.name,
        username: (user?.email?.split("@")[0]) ?? "guest",
        email: user?.email ?? "",
        joinedAt: new Date().toISOString(),
      });
      localStorage.setItem("vc:memberships", JSON.stringify(list));
    } catch {}
    setJoining(false);
    toast.success(`Welcome to ${c.name}! 🎉`);
    nav({ to: "/communities/$slug/feed", params: { slug } });
  }

  function handleJoinClick() {
    if (membership) {
      if (membership.status === "pending_payment") { toast.info("Your payment is being verified"); return; }
      nav({ to: "/communities/$slug/feed", params: { slug } });
      return;
    }
    // Paid communities require sign-in (so we can attach the payment to a profile).
    if (isPaid && !user) {
      nav({ to: "/auth", search: { redirect: `/communities/${slug}?join=1` } as any });
      return;
    }
    // Collect name + email first (once per user/community)
    const key = `vc:details:${slug}`;
    const saved = typeof window !== "undefined" ? localStorage.getItem(key) : null;
    if (!saved) {
      setPendingFlow(isPaid ? "paid" : "free");
      setDetailsOpen(true);
      return;
    }
    if (isPaid) setPaySheetOpen(true);
    else handleFreeJoin();
  }

  function afterDetailsSubmit() {
    setDetailsOpen(false);
    if (pendingFlow === "paid") setPaySheetOpen(true);
    else handleFreeJoin();
    setPendingFlow(null);
  }

  const primaryLabel = membership
    ? membership.status === "pending_payment" ? "Verification pending" : "View Community →"
    : isPaid ? `Join for ₹${c.price_inr}${c.pricing_type === "paid_monthly" ? "/mo" : ""} →`
             : joining ? "Joining…" : "Join Free →";

  // Blurred teaser posts
  const teaserPosts = useMemo(() => getPosts(slug, c.name).slice(0, 3), [slug, c.name]);

  return (
    <Shell mobileChromeless hideFooter>
      {/* Mobile top bar */}
      <header className="sticky top-0 z-40 flex h-[52px] items-center gap-2 border-b-[1.5px] border-foreground bg-cream px-3 lg:hidden">
        <button
          onClick={() => nav({ to: "/communities", replace: true })}
          className="grid h-9 w-9 place-items-center rounded-md border-[1.5px] border-foreground bg-white shadow-[2px_2px_0_0_#0F0F0F]"
          aria-label="Back"
        ><ArrowLeft className="h-4 w-4" /></button>
        <h1 className="min-w-0 flex-1 truncate text-center font-display text-sm font-extrabold">{c.name}</h1>
        <button
          onClick={() => sharePage(c.name, `/communities/${slug}`)}
          className="grid h-9 w-9 place-items-center rounded-md border-[1.5px] border-foreground bg-white shadow-[2px_2px_0_0_#0F0F0F]"
          aria-label="Share"
        ><Share2 className="h-4 w-4" /></button>
      </header>

      {/* Desktop breadcrumb */}
      <div className="hidden border-b-[1.5px] border-foreground bg-cream lg:block">
        <div className="container-page flex h-14 items-center gap-2 text-xs font-semibold">
          <Link to="/communities" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Communities
          </Link>
          <span className="text-muted-foreground">/</span>
          <span className="text-foreground">{c.name}</span>
          <button
            onClick={() => sharePage(c.name, `/communities/${slug}`)}
            className="ml-auto inline-flex h-9 items-center gap-1.5 rounded-md border-[1.5px] border-foreground bg-white px-3 shadow-[2px_2px_0_0_#0F0F0F]"
          ><Share2 className="h-3.5 w-3.5" /> Share</button>
        </div>
      </div>

      <div className="pb-24 lg:pb-16">
        <div className="container-page grid gap-6 lg:grid-cols-[1fr_360px] lg:py-6">
          {/* LEFT column */}
          <div className="min-w-0">
            {/* Banner */}
            <div className="relative -mx-3 h-[140px] overflow-hidden border-b-[1.5px] border-foreground lg:mx-0 lg:h-[240px] lg:rounded-2xl lg:border-[1.5px] lg:shadow-[4px_4px_0_0_#0F0F0F]"
              style={{ background: c.banner_url ? `url(${c.banner_url}) center/cover` : `linear-gradient(135deg, ${bg}, #FFE4D6)` }}>
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
              <div className="absolute bottom-3 left-3 right-3 flex items-end gap-2.5 lg:bottom-4 lg:left-4 lg:right-4 lg:gap-3">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-lg border-[1.5px] border-foreground text-lg text-white shadow-[2px_2px_0_0_#0F0F0F] lg:h-16 lg:w-16 lg:rounded-xl lg:text-2xl lg:shadow-[3px_3px_0_0_#0F0F0F]" style={{ background: bg }}>{c.icon}</div>
                <div className="min-w-0">
                  <h1 className="font-display text-base font-extrabold leading-tight text-white drop-shadow-md lg:text-2xl">{c.name}</h1>
                  {c.isOfficial && <span className="mt-1 inline-flex items-center gap-1 rounded-full border-[1.5px] border-white bg-coral px-1.5 py-0.5 text-[9px] font-bold uppercase text-white lg:px-2 lg:text-[10px]"><Check className="h-2.5 w-2.5 lg:h-3 lg:w-3" /> Official</span>}
                </div>
              </div>
            </div>

            {/* Stats row */}
            <div className="mt-3 grid grid-cols-4 divide-x-[1.5px] divide-foreground rounded-xl border-[1.5px] border-foreground bg-white shadow-[3px_3px_0_0_#0F0F0F] lg:mt-4 lg:rounded-2xl lg:shadow-[4px_4px_0_0_#0F0F0F]">
              <Stat icon={<Users className="h-3.5 w-3.5 lg:h-4 lg:w-4" />} label="Members" value={fmt(c.members)} />
              <Stat icon={<Circle className="h-3.5 w-3.5 fill-[#22C55E] text-[#22C55E] lg:h-4 lg:w-4" />} label="Online" value={fmt(online)} />
              <Stat icon={<CalIcon className="h-3.5 w-3.5 lg:h-4 lg:w-4" />} label="Founded" value="Jan '24" />
              <Stat icon={<MapPin className="h-3.5 w-3.5 lg:h-4 lg:w-4" />} label="Location" value="India" />
            </div>

            {/* Mobile Join CTA (sticky right card renders on desktop) */}
            <div className="mt-5 lg:hidden">
              <JoinCTACard c={c} priceLabel={priceLabel} isPaid={isPaid} membership={membership} joining={joining} onJoin={handleJoinClick} onTrial={() => setPaySheetOpen(true)} />
            </div>

            {/* About */}
            <section className="mt-5 lg:mt-6">
              <h2 className="font-display text-base font-extrabold lg:text-xl">About This Community</h2>
              <p className="mt-2 whitespace-pre-line text-[13px] leading-[1.65] text-foreground/90 lg:mt-3 lg:text-[15px] lg:leading-[1.7]">
                {c.description || `${c.name} is a home for India's most active AI builders. We ship together, share prompts and workflows, run weekly live builds, and celebrate every launch. Whether you're just starting or scaling your first product, you'll find your people here.`}
              </p>
            </section>

            {/* What's Inside */}
            <section className="mt-6 lg:mt-8">
              <h2 className="font-display text-base font-extrabold lg:text-xl">What's Inside</h2>
              <div className="mt-3 grid gap-2.5 sm:grid-cols-2 lg:mt-4 lg:gap-3">
                {INSIDE.map((f) => (
                  <div key={f.title} className="flex gap-2.5 rounded-lg border-[1.5px] border-foreground bg-white p-2.5 shadow-[2px_2px_0_0_#0F0F0F] lg:gap-3 lg:rounded-xl lg:p-3 lg:shadow-[3px_3px_0_0_#0F0F0F]">
                    <div className="grid h-8 w-8 shrink-0 place-items-center rounded-md border-[1.5px] border-foreground text-white lg:h-10 lg:w-10 lg:rounded-lg" style={{ background: f.color }}>{f.icon}</div>
                    <div className="min-w-0">
                      <div className="text-[13px] font-bold leading-tight lg:text-sm">{f.title}</div>
                      <div className="mt-0.5 text-[11px] leading-snug text-muted-foreground lg:text-xs">{f.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Topics */}
            <section className="mt-6 lg:mt-8">
              <h2 className="font-display text-base font-extrabold lg:text-xl">Topics Discussed</h2>
              <div className="mt-3 flex flex-wrap gap-1.5 lg:gap-2">
                {getTopics(slug).map((t) => (
                  <span key={t.name} className="rounded-full border-[1.5px] border-foreground bg-white px-2.5 py-0.5 text-[11px] font-bold lg:px-3 lg:py-1 lg:text-xs">#{t.name}</span>
                ))}
              </div>
            </section>

            {/* Top members */}
            <section className="mt-6 lg:mt-8">
              <div className="flex items-baseline justify-between">
                <h2 className="font-display text-base font-extrabold lg:text-xl">Top Members</h2>
                <span className="text-[11px] font-semibold text-muted-foreground lg:text-xs">See all →</span>
              </div>
              <div className="mt-3 flex items-center gap-3">
                <div className="flex -space-x-2">
                  {builders.slice(0, 6).map((b, i) => (
                    <Link key={i} to="/u/$username" params={{ username: b.username }}>
                      <img src={b.avatar} alt={b.name} className="h-8 w-8 rounded-full border-[1.5px] border-foreground lg:h-10 lg:w-10" />
                    </Link>
                  ))}
                </div>
                <p className="min-w-0 text-[11px] leading-snug text-muted-foreground lg:text-xs">
                  <Link to="/u/$username" params={{ username: builders[0].username }} className="font-bold text-foreground hover:text-coral">{builders[0].name}</Link>,{" "}
                  <Link to="/u/$username" params={{ username: builders[1].username }} className="font-bold text-foreground hover:text-coral">{builders[1].name}</Link>{" "}
                  and <strong className="text-foreground">{fmt(c.members - 2)}</strong> others are members
                </p>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 lg:mt-4 lg:gap-3">
                {builders.slice(0, 3).map((b, i) => (
                  <Link key={i} to="/u/$username" params={{ username: b.username }} className="flex flex-col items-center rounded-lg border-[1.5px] border-foreground bg-white p-2 text-center shadow-[2px_2px_0_0_#0F0F0F] hover:bg-cream lg:rounded-xl lg:p-3">
                    <img src={b.avatar} alt="" className="h-10 w-10 rounded-full border-[1.5px] border-foreground lg:h-12 lg:w-12" />
                    <div className="mt-2 w-full truncate text-[11px] font-bold leading-tight lg:text-xs">{b.name.split(" ")[0]}</div>
                    <div className="mt-1.5 inline-flex items-center gap-1 rounded-full border border-foreground/40 bg-[#FEF3C7] px-1.5 py-0.5 text-[9px] font-bold leading-none">
                      <Star className="h-2.5 w-2.5 fill-current" /> Legend
                    </div>
                  </Link>
                ))}
              </div>
            </section>

            {/* Blurred posts teaser */}
            <section className="mt-6 lg:mt-8">
              <h2 className="font-display text-base font-extrabold lg:text-xl">Recent Community Posts</h2>
              <div className="relative mt-4">
                <div className="space-y-3" style={{ filter: "blur(4px)", pointerEvents: "none", userSelect: "none" }} aria-hidden>
                  {teaserPosts.map((p) => (
                    <div key={p.id} className="rounded-xl border-[1.5px] border-foreground bg-white p-4 shadow-[3px_3px_0_0_#0F0F0F]">
                      <div className="flex items-center gap-2">
                        <img src={builders[p.builderIdx % builders.length].avatar} alt="" className="h-8 w-8 rounded-full border border-foreground" />
                        <div className="text-xs font-bold">{builders[p.builderIdx % builders.length].name}</div>
                      </div>
                      {p.title && <div className="mt-2 text-sm font-bold">{p.title}</div>}
                      <p className="mt-1 line-clamp-3 text-sm text-foreground/80">{p.body}</p>
                    </div>
                  ))}
                </div>
                <div className="absolute inset-0 grid place-items-center rounded-xl bg-gradient-to-b from-white/40 via-cream/70 to-cream">
                  <div className="rounded-2xl border-[1.5px] border-foreground bg-white p-5 text-center shadow-[4px_4px_0_0_#0F0F0F]">
                    <Lock className="mx-auto h-6 w-6" />
                    <div className="mt-2 text-sm font-bold">Join to see all community posts</div>
                    <button onClick={handleJoinClick} className="mt-3 grid h-10 w-full place-items-center rounded-full border-[1.5px] border-foreground bg-coral px-5 text-xs font-bold text-white shadow-[3px_3px_0_0_#0F0F0F]">
                      {membership ? "View Community →" : "Join Now →"}
                    </button>
                  </div>
                </div>
              </div>
            </section>
          </div>

          {/* RIGHT — sticky join card (desktop) */}
          <aside className="hidden lg:block">
            <div className="sticky top-6">
              <JoinCTACard c={c} priceLabel={priceLabel} isPaid={isPaid} membership={membership} joining={joining} onJoin={handleJoinClick} onTrial={() => setPaySheetOpen(true)} />
            </div>
          </aside>
        </div>
      </div>

      {/* Sticky bottom join bar — mobile */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t-[1.5px] border-foreground bg-white p-3 lg:hidden" style={{ paddingBottom: "calc(0.75rem + env(safe-area-inset-bottom))" }}>
        {isPaid ? (
          <div className="flex items-center gap-3">
            <div className="min-w-0 flex-1">
              <div className="text-[10px] uppercase text-muted-foreground">Membership</div>
              <div className="font-display text-base font-extrabold">₹{c.price_inr}<span className="text-xs font-semibold text-muted-foreground">{c.pricing_type === "paid_monthly" ? "/month" : ""}</span></div>
            </div>
            <button onClick={handleJoinClick} disabled={joining} className="grid h-11 shrink-0 place-items-center rounded-full border-[1.5px] border-foreground bg-coral px-5 text-xs font-bold text-white shadow-[3px_3px_0_0_#0F0F0F] disabled:opacity-60">{primaryLabel}</button>
          </div>
        ) : (
          <button onClick={handleJoinClick} disabled={joining} className="grid h-11 w-full place-items-center rounded-full border-[1.5px] border-foreground bg-coral text-sm font-bold text-white shadow-[3px_3px_0_0_#0F0F0F] disabled:opacity-60">{joining ? <Loader2 className="h-4 w-4 animate-spin" /> : `${primaryLabel}${!membership ? " — It's Free Forever" : ""}`}</button>
        )}
      </div>

      {paySheetOpen && (
        <PaymentSheet
          communityId={dbRow?.id ?? null}
          communityName={c.name}
          amount={c.price_inr}
          pricing={c.pricing_type}
          onClose={() => setPaySheetOpen(false)}
          onSubmitted={() => {
            setMembership({ status: "pending_payment" });
            setPaySheetOpen(false);
          }}
        />
      )}

      {detailsOpen && (
        <DetailsModal
          slug={slug}
          communityName={c.name}
          isPaid={pendingFlow === "paid"}
          onClose={() => { setDetailsOpen(false); setPendingFlow(null); }}
          onSubmit={afterDetailsSubmit}
        />
      )}
    </Shell>
  );
}

/* ---------------- helpers ---------------- */

function fmt(n: number) {
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
}

const INSIDE = [
  { icon: <MessageCircle className="h-5 w-5" />, color: "#E8623A", title: "Discussions & Posts", desc: "Share builds, ask questions, help others" },
  { icon: <Sparkles className="h-5 w-5" />, color: "#7C3AED", title: "Prompt Library", desc: "Curated prompts shared by top builders" },
  { icon: <GitBranch className="h-5 w-5" />, color: "#2DD4BF", title: "Workflow Templates", desc: "Ready-to-use n8n, Make and Zapier flows" },
  { icon: <Video className="h-5 w-5" />, color: "#F5A623", title: "Live Sessions", desc: "Weekly live builds with top builders" },
  { icon: <CalendarDays className="h-5 w-5" />, color: "#0EA5E9", title: "Events & Workshops", desc: "Exclusive events for members" },
  { icon: <Trophy className="h-5 w-5" />, color: "#F59E0B", title: "Leaderboard & Rewards", desc: "Earn VibeCoins and get recognized" },
];

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="p-2 text-center lg:p-3">
      <div className="mx-auto flex h-5 items-center justify-center text-muted-foreground lg:h-6">{icon}</div>
      <div className="mt-1 font-display text-sm font-extrabold leading-tight lg:text-base">{value}</div>
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground lg:text-[10px]">{label}</div>
    </div>
  );
}

const BENEFITS = [
  "Access all community discussions",
  "Join live build sessions",
  "Prompt & workflow library",
  "Get featured on leaderboard",
  "Earn VibeCoins & XP",
];

function JoinCTACard({ c, priceLabel, isPaid, membership, joining, onJoin, onTrial }: any) {
  return (
    <div className="rounded-2xl border-2 border-coral bg-white p-5 shadow-[4px_4px_0_0_#0F0F0F]">
      <div className="text-xs font-bold uppercase text-muted-foreground">{isPaid ? "💎 Premium Membership" : "🔓 Free To Join"}</div>
      <div className="mt-1 font-display text-2xl font-extrabold">{priceLabel}</div>
      <ul className="mt-4 space-y-2 text-sm">
        {BENEFITS.map((b) => (
          <li key={b} className="flex items-start gap-2">
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-[#22C55E]" /> <span>{b}</span>
          </li>
        ))}
      </ul>
      <button
        onClick={onJoin}
        disabled={joining || membership?.status === "pending_payment"}
        className="mt-5 grid h-12 w-full place-items-center rounded-[10px] border-[1.5px] border-foreground bg-coral text-sm font-bold text-white shadow-[3px_3px_0_0_#0F0F0F] disabled:opacity-60"
      >
        {joining ? <Loader2 className="h-4 w-4 animate-spin" />
          : membership ? (membership.status === "pending_payment" ? "Verification pending" : "View Community →")
          : isPaid ? `Join for ${priceLabel} →`
          : "Join Free →"}
      </button>
      {isPaid && !membership && (
        <>
          <button onClick={onTrial} className="mt-2 grid h-10 w-full place-items-center rounded-[10px] border-[1.5px] border-coral bg-transparent text-xs font-bold text-coral">
            Try Free for 7 Days
          </button>
          <p className="mt-1 text-center text-[11px] text-muted-foreground">Cancel anytime · No questions asked</p>
        </>
      )}
      <p className="mt-3 text-center text-[11px] text-muted-foreground">2,340 builders joined this month</p>
    </div>
  );
}

/* ---------------- Payment Sheet ---------------- */

function PaymentSheet({ communityId, communityName, amount, pricing, onClose, onSubmitted }: {
  communityId: string | null; communityName: string; amount: number; pricing: PricingType;
  onClose: () => void; onSubmitted: () => void;
}) {
  const [utr, setUtr] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const { user } = useAuth();

  const qr = upiQrUrl({ amount, note: `${communityName} membership`, ref: `COMM-${communityId?.slice(0, 8) ?? "x"}` });
  const intent = upiIntent({ amount, note: `${communityName} membership`, ref: `COMM-${communityId?.slice(0, 8) ?? "x"}` });

  async function submit() {
    if (!user || !communityId) return;
    if (utr.trim().length < 6) { toast.error("Please enter a valid UTR / transaction ID"); return; }
    setSubmitting(true);
    let screenshotUrl: string | null = null;
    if (file) {
      const path = `${user.id}/${Date.now()}-${file.name}`.replace(/[^\w./-]/g, "_");
      const up = await supabase.storage.from("payment-screenshots").upload(path, file);
      if (!up.error) screenshotUrl = path;
    }
    const { error } = await supabase.from("community_payment_requests").insert({
      community_id: communityId, profile_id: user.id, amount_inr: amount,
      transaction_reference: utr.trim(), screenshot_url: screenshotUrl,
    });
    if (error) { toast.error(error.message); setSubmitting(false); return; }
    // Create pending member row so we can gate `/feed` with a pending screen.
    await supabase.from("community_members").insert({
      community_id: communityId, profile_id: user.id, status: "pending_payment",
    }).then(({ error: e }) => { if (e && !e.message.includes("duplicate")) console.error(e); });
    setDone(true);
    setSubmitting(false);
    onSubmitted();
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/60 lg:items-center" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="w-full max-w-md rounded-t-2xl border-t-[1.5px] border-foreground bg-white p-5 shadow-[4px_-4px_0_0_#0F0F0F] lg:rounded-2xl lg:border-[1.5px] lg:shadow-[6px_6px_0_0_#0F0F0F]">
        <div className="flex items-center justify-between">
          <div className="font-display text-lg font-extrabold">Complete Your Membership</div>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-foreground"><X className="h-4 w-4" /></button>
        </div>

        {done ? (
          <div className="mt-4 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full border-[1.5px] border-foreground bg-[#22C55E] text-2xl text-white">✓</div>
            <p className="mt-3 text-sm font-bold">Payment submitted!</p>
            <p className="mt-1 text-xs text-muted-foreground">We'll verify within 24 hours and notify you as soon as your access is activated.</p>
            <button onClick={onClose} className="mt-4 grid h-11 w-full place-items-center rounded-full border-[1.5px] border-foreground bg-coral text-sm font-bold text-white shadow-[3px_3px_0_0_#0F0F0F]">Got it</button>
          </div>
        ) : (
          <>
            <div className="mt-3 rounded-lg border-[1.5px] border-foreground bg-cream p-3 text-sm">
              <div className="font-bold">{communityName}</div>
              <div className="text-xs text-muted-foreground">₹{amount} {pricing === "paid_monthly" ? "/ month" : "one-time"} · Cancel anytime</div>
            </div>

            <div className="mt-4">
              <div className="text-xs font-bold uppercase text-muted-foreground">Pay via UPI</div>
              <div className="mt-2 flex items-center gap-2 rounded-lg border-[1.5px] border-foreground bg-white p-2">
                <code className="flex-1 truncate text-xs">{PAYEE_UPI_ID}</code>
                <button onClick={() => { navigator.clipboard.writeText(PAYEE_UPI_ID); toast.success("UPI ID copied"); }} className="inline-flex items-center gap-1 rounded-md border-[1.5px] border-foreground bg-white px-2 py-1 text-[11px] font-bold"><Copy className="h-3 w-3" /> Copy</button>
              </div>
              <div className="mt-3 flex justify-center">
                <img src={qr} alt="Scan to pay" className="h-40 w-40 rounded-lg border-[1.5px] border-foreground" />
              </div>
              <a href={intent} className="mt-2 grid h-9 w-full place-items-center rounded-md border-[1.5px] border-foreground bg-white text-xs font-bold">Open UPI App</a>
            </div>

            <div className="mt-4 space-y-2">
              <label className="text-xs font-bold uppercase text-muted-foreground">Transaction ID / UTR</label>
              <input value={utr} onChange={(e) => setUtr(e.target.value)} placeholder="Enter your UTR number" className="h-11 w-full rounded-lg border-[1.5px] border-foreground bg-white px-3 text-sm outline-none" />
              <label className="mt-2 grid h-10 w-full cursor-pointer place-items-center rounded-lg border-[1.5px] border-dashed border-foreground text-xs font-bold text-muted-foreground">
                {file ? file.name : "📎 Upload Screenshot (optional)"}
                <input type="file" accept="image/*" hidden onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
              </label>
            </div>

            <button onClick={submit} disabled={submitting || !user || !communityId} className="mt-4 grid h-12 w-full place-items-center rounded-full border-[1.5px] border-foreground bg-coral text-sm font-bold text-white shadow-[3px_3px_0_0_#0F0F0F] disabled:opacity-60">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Submit for Verification"}
            </button>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">Access granted within 24 hours after payment verification. You'll be notified once approved.</p>
          </>
        )}
      </div>
    </div>
  );
}

/* ---------------- Details Modal (name + email gate) ---------------- */

function DetailsModal({ slug, communityName, isPaid, onClose, onSubmit }: {
  slug: string; communityName: string; isPaid: boolean;
  onClose: () => void; onSubmit: () => void;
}) {
  const { user } = useAuth();
  const [name, setName] = useState(() => (user?.user_metadata?.display_name as string) ?? "");
  const [email, setEmail] = useState(() => user?.email ?? "");
  const [saving, setSaving] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const trimmedName = name.trim().slice(0, 80);
    const trimmedEmail = email.trim().slice(0, 200);
    if (trimmedName.length < 2) { toast.error("Please enter your name"); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) { toast.error("Please enter a valid email"); return; }
    setSaving(true);
    try {
      localStorage.setItem(`vc:details:${slug}`, JSON.stringify({ name: trimmedName, email: trimmedEmail, at: Date.now() }));
      if (user) {
        await supabase.from("profiles").update({ display_name: trimmedName }).eq("id", user.id);
      }
    } catch {}
    setSaving(false);
    onSubmit();
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/60 lg:items-center" onClick={onClose}>
      <form
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-t-2xl border-t-[1.5px] border-foreground bg-white p-5 shadow-[4px_-4px_0_0_#0F0F0F] lg:rounded-2xl lg:border-[1.5px] lg:shadow-[6px_6px_0_0_#0F0F0F]"
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Join Community</div>
            <div className="font-display text-lg font-extrabold leading-tight">{communityName}</div>
          </div>
          <button type="button" onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-foreground" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        <p className="mt-3 text-xs text-muted-foreground">
          Tell us a bit about you so members can recognize you inside the community.
        </p>

        <label className="mt-4 block">
          <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Your Name</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={80}
            placeholder="e.g. Aditi Sharma"
            className="mt-1 h-11 w-full rounded-lg border-[1.5px] border-foreground bg-white px-3 text-sm outline-none focus:shadow-[3px_3px_0_0_#0F0F0F]"
            autoFocus
          />
        </label>

        <label className="mt-3 block">
          <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Email Address</span>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            maxLength={200}
            placeholder="you@example.com"
            className="mt-1 h-11 w-full rounded-lg border-[1.5px] border-foreground bg-white px-3 text-sm outline-none focus:shadow-[3px_3px_0_0_#0F0F0F]"
          />
        </label>

        <button
          type="submit"
          disabled={saving}
          className="mt-5 grid h-12 w-full place-items-center rounded-full border-[1.5px] border-foreground bg-coral text-sm font-bold text-white shadow-[3px_3px_0_0_#0F0F0F] disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : (isPaid ? "Continue to Payment →" : "Join Community →")}
        </button>
        <p className="mt-2 text-center text-[11px] text-muted-foreground">
          {isPaid ? "You'll be taken to the secure UPI payment page next." : "You'll get instant access to the community feed."}
        </p>
      </form>
    </div>
  );
}

