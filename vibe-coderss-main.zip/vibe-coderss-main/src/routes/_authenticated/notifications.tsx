import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import {
  Bell,
  MessageSquare,
  Heart,
  UserPlus,
  Sparkles,
  CheckCheck,
  Trash2,
  Settings2,
  Zap,
  Rocket,
  Trophy,
  Star,
  ArrowLeft,
  Search,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Shell, PageHeader } from "@/components/site/Shell";
import { useNotifications } from "@/hooks/useNotifications";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({ meta: [{ title: "Notifications · VibeCoder" }] }),
  component: NotificationsPage,
  errorComponent: ({ error, reset }) => (
    <Shell>
      <div className="container-page py-16 text-center">
        <div className="mx-auto max-w-md rounded-md border-[1.5px] border-[#0F0F0F] bg-card p-6 shadow-[4px_4px_0_0_#0F0F0F]">
          <Bell className="mx-auto h-8 w-8 text-coral" />
          <h1 className="mt-3 font-display text-2xl font-extrabold">Couldn't load notifications</h1>
          <p className="mt-1 text-sm text-muted-foreground">{error?.message ?? "Something went sideways."}</p>
          <button onClick={reset} className="btn-coral mt-4 h-10">Try again</button>
        </div>
      </div>
    </Shell>
  ),
  notFoundComponent: () => (
    <Shell>
      <div className="container-page py-20 text-center text-muted-foreground">Notifications not found.</div>
    </Shell>
  ),
});

const TYPE_META: Record<string, { icon: typeof Bell; color: string; bg: string; label: string }> = {
  message: { icon: MessageSquare, color: "text-coral", bg: "bg-coral/10", label: "Messages" },
  follow: { icon: UserPlus, color: "text-blue-600", bg: "bg-blue-500/10", label: "Follows" },
  upvote: { icon: Heart, color: "text-rose-600", bg: "bg-rose-500/10", label: "Upvotes" },
  system: { icon: Sparkles, color: "text-gold", bg: "bg-amber-400/15", label: "System" },
};

const FILTERS = ["all", "unread", "message", "follow", "upvote", "system"] as const;
type Filter = (typeof FILTERS)[number];

const SAMPLE_HINTS = [
  { icon: Rocket, title: "Ship a project", body: "Publish your first build on Explore to start getting upvotes.", to: "/submit" },
  { icon: MessageSquare, title: "Say hi", body: "Open a builder's profile and hit Message to start chatting.", to: "/explore" },
  { icon: UserPlus, title: "Follow builders", body: "Follow creators to get notified when they ship.", to: "/leaderboard" },
  { icon: Trophy, title: "Join a community", body: "Communities push events and drops straight to your inbox.", to: "/communities" },
];

function fmtRelative(iso: string) {
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  if (s < 604800) return `${Math.floor(s / 86400)}d ago`;
  return new Date(iso).toLocaleDateString();
}

function groupByDay(items: ReturnType<typeof useNotifications>["items"]) {
  const groups: Record<string, typeof items> = {};
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const yest = today - 86400000;
  for (const n of items) {
    const t = new Date(n.created_at).getTime();
    const key = t >= today ? "Today" : t >= yest ? "Yesterday" : t >= today - 7 * 86400000 ? "This week" : "Earlier";
    (groups[key] ||= []).push(n);
  }
  return groups;
}

function NotificationsPage() {
  const { items, unread, loading, markAllRead, markOneRead } = useNotifications();
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const router = useRouter();

  const visible = useMemo(() => {
    let list = items;
    if (filter === "unread") list = list.filter((n) => !n.read_at);
    else if (filter !== "all") list = list.filter((n) => n.type === filter);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (n) => n.title.toLowerCase().includes(q) || (n.body ?? "").toLowerCase().includes(q),
      );
    }
    return list;
  }, [items, filter, query]);

  const grouped = useMemo(() => groupByDay(visible), [visible]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { message: 0, follow: 0, upvote: 0, system: 0 };
    items.forEach((n) => { if (c[n.type] !== undefined) c[n.type]++; });
    return c;
  }, [items]);

  return (
    <Shell mobileChromeless>
      {/* ===================== MOBILE (chromeless) ===================== */}
      <div className="lg:hidden fixed inset-0 flex flex-col bg-[#FAF6F1]">
        {/* Top bar */}
        <div className="sticky top-0 z-20 flex items-center gap-2 border-b-[1.5px] border-foreground bg-[#FAF6F1] px-3 py-2.5">
          <button
            onClick={() => (window.history.length > 1 ? router.history.back() : router.navigate({ to: "/" }))}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border-[1.5px] border-foreground bg-white active:scale-95"
            aria-label="Back"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="flex min-w-0 flex-1 items-center gap-2 rounded-full border-[1.5px] border-foreground bg-white px-3 py-1.5">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search notifications"
              className="min-w-0 flex-1 bg-transparent text-[13px] outline-none"
            />
          </div>
          {unread > 0 && (
            <button
              onClick={markAllRead}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full border-[1.5px] border-foreground bg-coral text-white active:scale-95"
              aria-label="Mark all read"
            >
              <CheckCheck className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Filter pills */}
        <div className="flex gap-1.5 overflow-x-auto border-b border-foreground/10 bg-[#FAF6F1] px-3 py-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {FILTERS.map((f) => {
            const active = filter === f;
            const n = f === "all" ? items.length : f === "unread" ? unread : counts[f] ?? 0;
            return (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`inline-flex shrink-0 items-center gap-1 rounded-full border-[1.5px] px-2.5 py-1 text-[11px] font-semibold capitalize ${
                  active
                    ? "border-foreground bg-coral text-white"
                    : "border-foreground/60 bg-white text-foreground"
                }`}
              >
                {f}
                <span className={`rounded-full px-1.5 text-[9px] ${active ? "bg-white/20" : "bg-foreground/10"}`}>{n}</span>
              </button>
            );
          })}
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="space-y-2 p-3">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-16 animate-pulse rounded-lg bg-white/70" />
              ))}
            </div>
          ) : visible.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center px-6 text-center">
              <div className="grid h-14 w-14 place-items-center rounded-full border-[1.5px] border-foreground bg-coral text-white">
                <Bell className="h-6 w-6" />
              </div>
              <h3 className="mt-3 font-display text-lg font-black">You're all caught up</h3>
              <p className="mt-1 text-xs text-muted-foreground">
                No {filter === "all" ? "" : filter + " "}notifications right now.
              </p>
            </div>
          ) : (
            <div>
              {Object.entries(grouped).map(([day, rows]) => (
                <div key={day}>
                  <div className="sticky top-0 z-10 flex items-center justify-between border-b border-foreground/10 bg-[#F0EAE0]/95 px-3 py-1.5 backdrop-blur">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{day}</span>
                    <span className="text-[10px] text-muted-foreground">{rows.length}</span>
                  </div>
                  {rows.map((n) => {
                    const meta = TYPE_META[n.type] ?? TYPE_META.system;
                    const Icon = meta.icon;
                    const inner = (
                      <div
                        className={`flex items-start gap-2.5 border-b border-foreground/10 px-3 py-2.5 active:bg-foreground/5 ${
                          !n.read_at ? "bg-white" : "bg-transparent"
                        }`}
                      >
                        <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full border-[1.5px] border-foreground ${meta.bg} ${meta.color}`}>
                          <Icon className="h-4 w-4" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <p className="truncate text-[13px] font-semibold text-foreground">{n.title}</p>
                            <span className="shrink-0 text-[10px] text-muted-foreground">{fmtRelative(n.created_at)}</span>
                          </div>
                          {n.body && <p className="mt-0.5 line-clamp-2 text-[11.5px] leading-snug text-muted-foreground">{n.body}</p>}
                        </div>
                        {!n.read_at && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-coral" />}
                      </div>
                    );
                    return n.link ? (
                      <Link key={n.id} to={n.link} onClick={() => markOneRead(n.id)} className="block">{inner}</Link>
                    ) : (
                      <button key={n.id} onClick={() => markOneRead(n.id)} className="block w-full text-left">{inner}</button>
                    );
                  })}
                </div>
              ))}
              <div className="h-8" />
            </div>
          )}
        </div>
      </div>

      {/* ===================== DESKTOP ===================== */}
      <div className="hidden lg:block">
      <div className="hidden sm:block">
        <PageHeader
          breadcrumb="INBOX"
          title="Notifications"
          subtitle="Every mention, message, upvote and drop — all in one place."
        />
      </div>

      <div className="container-page grid gap-4 py-4 sm:gap-6 sm:py-8 md:grid-cols-[1fr_320px]">
        {/* MAIN */}
        <div>
          {/* Toolbar */}
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3 sm:mb-4">
            {/* Desktop filter chips */}
            <div className="hidden flex-wrap gap-2 sm:flex">
              {FILTERS.map((f) => {
                const active = filter === f;
                const n = f === "all" ? items.length : f === "unread" ? unread : counts[f] ?? 0;
                return (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`inline-flex items-center gap-1.5 rounded-full border-[1.5px] px-3 py-1.5 text-xs font-semibold capitalize transition ${
                      active
                        ? "border-[#0F0F0F] bg-coral text-white shadow-[2px_2px_0_0_#0F0F0F]"
                        : "border-[#0F0F0F]/70 bg-card text-[#0F0F0F] hover:-translate-y-0.5"
                    }`}
                  >
                    {f}
                    <span className={`rounded-full px-1.5 text-[10px] ${active ? "bg-white/20" : "bg-[#0F0F0F]/10"}`}>{n}</span>
                  </button>
                );
              })}
            </div>
            <div className="flex w-full justify-center gap-2 sm:w-auto sm:justify-end">
              {unread > 0 && (
                <button
                  onClick={markAllRead}
                  className="inline-flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 py-2 text-xs font-semibold shadow-[2px_2px_0_0_#0F0F0F] hover:-translate-y-0.5"
                >
                  <CheckCheck className="h-3.5 w-3.5" /> Mark all read
                </button>
              )}
              <Link
                to="/settings"
                className="inline-flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-card px-3 py-2 text-xs font-semibold shadow-[2px_2px_0_0_#0F0F0F] hover:-translate-y-0.5"
              >
                <Settings2 className="h-3.5 w-3.5" /> Settings
              </Link>
            </div>
          </div>

          {/* List */}
          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-20 animate-pulse rounded-md border-[1.5px] border-[#0F0F0F]/20 bg-card" />
              ))}
            </div>
          ) : visible.length === 0 ? (
            <div className="rounded-md border-[1.5px] border-[#0F0F0F] bg-card p-10 text-center shadow-[4px_4px_0_0_#0F0F0F]">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-full border-[1.5px] border-[#0F0F0F] bg-coral text-white shadow-[3px_3px_0_0_#0F0F0F]">
                <Bell className="h-6 w-6" />
              </div>
              <h3 className="mt-4 font-display text-2xl font-bold">You're all caught up</h3>
              <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
                No {filter === "all" ? "" : filter + " "}notifications right now. Here's how to spark some activity:
              </p>
              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                {SAMPLE_HINTS.map((h) => (
                  <Link
                    key={h.title}
                    to={h.to}
                    className="group flex items-start gap-3 rounded-md border-[1.5px] border-[#0F0F0F] bg-surface p-3 text-left shadow-[2px_2px_0_0_#0F0F0F] transition hover:-translate-y-0.5 hover:bg-coral/5"
                  >
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] bg-cream text-coral">
                      <h.icon className="h-4 w-4" />
                    </span>
                    <div>
                      <div className="text-sm font-semibold">{h.title}</div>
                      <div className="text-xs text-muted-foreground">{h.body}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {Object.entries(grouped).map(([day, rows]) => (
                <div key={day}>
                  <div className="mb-2 flex items-center gap-2">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{day}</span>
                    <span className="h-px flex-1 bg-[#0F0F0F]/10" />
                    <span className="text-[11px] text-muted-foreground">{rows.length}</span>
                  </div>
                  <div className="overflow-hidden rounded-md border-[1.5px] border-[#0F0F0F] bg-card shadow-[3px_3px_0_0_#0F0F0F]">
                    {rows.map((n, i) => {
                      const meta = TYPE_META[n.type] ?? TYPE_META.system;
                      const Icon = meta.icon;
                      const inner = (
                        <div
                          className={`flex items-start gap-2.5 border-b border-[#0F0F0F]/10 p-3 transition last:border-b-0 hover:bg-cream/70 sm:gap-3 sm:p-4 ${
                            !n.read_at ? "bg-cream/40" : ""
                          }`}
                        >
                          <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-md border-[1.5px] border-[#0F0F0F] sm:h-10 sm:w-10 ${meta.bg} ${meta.color}`}>
                            <Icon className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                          </span>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                              <p className="text-[13px] font-semibold text-[#0F0F0F] sm:text-sm">{n.title}</p>
                              <span className="shrink-0 text-[10px] text-muted-foreground sm:text-[11px]">{fmtRelative(n.created_at)}</span>
                            </div>
                            {n.body && <p className="mt-0.5 line-clamp-2 text-[11px] text-muted-foreground sm:text-xs">{n.body}</p>}
                            <div className="mt-1.5 flex items-center gap-2 sm:mt-2 sm:gap-3">
                              <span className={`inline-flex items-center gap-1 rounded-full border border-[#0F0F0F]/20 px-1.5 py-0.5 text-[9px] font-semibold uppercase sm:px-2 sm:text-[10px] ${meta.color}`}>
                                {meta.label}
                              </span>
                              {!n.read_at && (
                                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-coral">
                                  <span className="h-1.5 w-1.5 rounded-full bg-coral" /> New
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                      return n.link ? (
                        <Link key={n.id} to={n.link} onClick={() => markOneRead(n.id)} className="block">{inner}</Link>
                      ) : (
                        <button key={n.id} onClick={() => markOneRead(n.id)} className="block w-full text-left">{inner}</button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* SIDEBAR */}
        <aside className="space-y-4">
          <div className="rounded-md border-[1.5px] border-[#0F0F0F] bg-card p-5 shadow-[4px_4px_0_0_#0F0F0F]">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-coral" />
              <h3 className="font-display text-sm font-bold uppercase tracking-wide">Activity summary</h3>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {(["message", "follow", "upvote", "system"] as const).map((t) => {
                const meta = TYPE_META[t];
                return (
                  <div key={t} className="rounded-md border-[1.5px] border-[#0F0F0F]/70 bg-surface p-3">
                    <div className={`flex items-center gap-1.5 text-[10px] font-bold uppercase ${meta.color}`}>
                      <meta.icon className="h-3 w-3" /> {meta.label}
                    </div>
                    <div className="mt-1 text-2xl font-extrabold">{counts[t] ?? 0}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rounded-md border-[1.5px] border-[#0F0F0F] bg-cream p-5 shadow-[4px_4px_0_0_#0F0F0F]">
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-gold" />
              <h3 className="font-display text-sm font-bold uppercase tracking-wide">Pro tip</h3>
            </div>
            <p className="mt-2 text-sm text-[#0F0F0F]">
              Turn on browser notifications from Settings to catch messages, hire requests and upvotes in real-time —
              even when the tab is closed.
            </p>
            <Link
              to="/settings"
              className="mt-3 inline-flex items-center gap-2 rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-xs font-semibold shadow-[2px_2px_0_0_#0F0F0F] hover:-translate-y-0.5"
            >
              <Settings2 className="h-3.5 w-3.5" /> Notification settings
            </Link>
          </div>

          <div className="rounded-md border-[1.5px] border-[#0F0F0F] bg-card p-5 shadow-[4px_4px_0_0_#0F0F0F]">
            <div className="flex items-center gap-2">
              <Trash2 className="h-4 w-4 text-muted-foreground" />
              <h3 className="font-display text-sm font-bold uppercase tracking-wide">Keep it tidy</h3>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Notifications older than 90 days auto-archive. Click any row to jump to the source.
            </p>
          </div>
        </aside>
      </div>
      </div>
    </Shell>
  );
}
