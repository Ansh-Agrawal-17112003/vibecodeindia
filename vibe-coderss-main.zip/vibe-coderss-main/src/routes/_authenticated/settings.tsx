import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/site/Shell";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useSubscription } from "@/hooks/useSubscription";
import { UpgradeModal } from "@/components/site/UpgradeModal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { ProfileEditor } from "@/components/profile/ProfileEditor";
import { useServerFn } from "@tanstack/react-start";
import { exportMyData, deleteMyAccount } from "@/lib/dpdp.functions";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings · VibeCode" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <Shell>
      <div className="container-page py-8">
        <h1 className="text-3xl font-semibold tracking-tight">Settings</h1>
        <Tabs defaultValue="profile" className="mt-6">
          <TabsList className="border-b border-border bg-transparent">
            {["profile", "account", "availability", "notifications", "privacy", "billing", "danger"].map((t) => (
              <TabsTrigger key={t} value={t} className="capitalize">{t === "danger" ? "Danger Zone" : t}</TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="profile" className="space-y-6 py-6 max-w-2xl">
            <ProfileEditor />
          </TabsContent>
          <TabsContent value="account" className="space-y-6 py-6 max-w-2xl">
            <Field label="Username" defaultValue="priya" />
            <Field label="Email" type="email" defaultValue="priya@vibecode.in" />
            <Field label="Current password" type="password" />
            <Field label="New password" type="password" />
            <div className="flex justify-end"><Save /></div>
          </TabsContent>
          <TabsContent value="availability" className="space-y-4 py-6 max-w-2xl">
            <Toggle label="Available for work" defaultChecked />
            <Toggle label="Open to full-time roles" />
            <Toggle label="Open to freelance gigs" defaultChecked />
            <Field label="Hourly rate (₹)" type="number" defaultValue="6000" />
          </TabsContent>
          <TabsContent value="notifications" className="space-y-4 py-6 max-w-2xl">
            {["New followers", "Project upvotes", "Service orders", "Messages", "Community mentions", "Weekly digest"].map((n) => <Toggle key={n} label={n} defaultChecked />)}
          </TabsContent>
          <TabsContent value="privacy" className="space-y-4 py-6 max-w-2xl">
            <Toggle label="Show me in public search results" defaultChecked />
            <Toggle label="Allow messages from non-followers" defaultChecked />
            <Toggle label="Show my location publicly" />
          </TabsContent>
          <TabsContent value="billing" className="space-y-6 py-6 max-w-3xl">
            <BillingPanel />
          </TabsContent>
          <TabsContent value="danger" className="py-6 max-w-2xl">
            <DpdpPanel />
          </TabsContent>
        </Tabs>
      </div>
    </Shell>
  );
}

function Field({ label, ...rest }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</label>
      <input {...rest} className="h-10 w-full rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary" />
    </div>
  );
}
function FieldArea({ label, ...rest }: { label: string } & React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</label>
      <textarea rows={3} {...rest} className="w-full resize-none rounded-md border border-border bg-surface p-3 text-sm outline-none focus:border-primary" />
    </div>
  );
}
function Toggle({ label, defaultChecked }: { label: string; defaultChecked?: boolean }) {
  return (
    <label className="flex cursor-pointer items-center justify-between rounded-md border border-border bg-surface p-3">
      <span className="text-sm">{label}</span>
      <input type="checkbox" defaultChecked={defaultChecked} className="h-4 w-4 accent-primary" />
    </label>
  );
}
function Save() {
  return <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary-hover">Save changes</button>;
}

interface SubReqRow {
  id: string;
  requested_plan: string;
  amount: number;
  status: string;
  submitted_at: string;
  rejection_reason: string | null;
}

function BillingPanel() {
  const { user } = useAuth();
  const { subscription, plan, refresh } = useSubscription();
  const [openPlan, setOpenPlan] = useState<"pro" | "business" | null>(null);
  const [history, setHistory] = useState<SubReqRow[]>([]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("subscription_requests")
      .select("id,requested_plan,amount,status,submitted_at,rejection_reason")
      .eq("profile_id", user.id)
      .order("submitted_at", { ascending: false })
      .then(({ data }) => setHistory((data as SubReqRow[]) ?? []));
  }, [user, subscription]);

  const expires = subscription?.current_period_end
    ? new Date(subscription.current_period_end).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
    : null;

  const planBadge =
    plan === "pro" ? "bg-coral text-white" : plan === "business" ? "bg-gold text-[#0F0F0F]" : "bg-cream text-[#0F0F0F]";

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-6 shadow-[4px_4px_0_0_#0F0F0F]">
        <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Current plan</div>
        <div className="mt-2 flex items-center gap-3">
          <span className={`rounded-md border-[1.5px] border-[#0F0F0F] px-2.5 py-1 text-sm font-bold uppercase ${planBadge}`}>{plan}</span>
          {subscription?.status === "expired" && <span className="text-sm text-error">Expired — reverted to Free</span>}
        </div>
        {expires && plan !== "free" && (
          <p className="mt-2 text-sm text-muted-foreground">{subscription?.status === "expired" ? "Expired on" : "Renews on"}: {expires}</p>
        )}
        <div className="mt-4 flex flex-wrap gap-2">
          {plan === "free" && (
            <>
              <button onClick={() => setOpenPlan("pro")} className="btn-coral">Upgrade to Pro</button>
              <button onClick={() => setOpenPlan("business")} className="rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-4 py-2 text-sm font-bold hover:bg-cream">Upgrade to Business</button>
            </>
          )}
          {plan !== "free" && (
            <button onClick={() => setOpenPlan(plan as "pro" | "business")} className="btn-coral">Renew plan</button>
          )}
        </div>
      </div>

      <div className="rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-6 shadow-[4px_4px_0_0_#0F0F0F]">
        <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Payment history</div>
        {history.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">No payment requests yet.</p>
        ) : (
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-[1.5px] border-[#0F0F0F] text-left text-xs uppercase">
                  <th className="py-2">Date</th>
                  <th>Plan</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {history.map((h) => (
                  <tr key={h.id} className="border-b border-[#0F0F0F]/10">
                    <td className="py-2">{new Date(h.submitted_at).toLocaleDateString("en-IN")}</td>
                    <td className="capitalize">{h.requested_plan}</td>
                    <td>₹{h.amount.toLocaleString("en-IN")}</td>
                    <td>
                      <span className={`rounded-md px-2 py-0.5 text-xs font-bold uppercase ${
                        h.status === "verified" ? "bg-success/15 text-success" :
                        h.status === "rejected" ? "bg-error/15 text-error" :
                        "bg-gold/20 text-[#7a5a00]"
                      }`}>{h.status}</span>
                      {h.rejection_reason && <div className="mt-1 text-xs text-muted-foreground">{h.rejection_reason}</div>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {openPlan && (
        <UpgradeModal
          open={!!openPlan}
          onOpenChange={(o) => !o && setOpenPlan(null)}
          plan={openPlan}
          onSubmitted={refresh}
        />
      )}
    </div>
  );
}

function DpdpPanel() {
  const exportFn = useServerFn(exportMyData);
  const deleteFn = useServerFn(deleteMyAccount);
  const navigate = useNavigate();
  const [busy, setBusy] = useState<"export" | "delete" | null>(null);
  const [confirm, setConfirm] = useState("");

  async function handleExport() {
    setBusy("export");
    try {
      const res = await exportFn({});
      const blob = new Blob([res.json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `vibecode-my-data-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Your data export has downloaded.");
    } catch (e: any) {
      toast.error(e?.message ?? "Export failed");
    } finally {
      setBusy(null);
    }
  }

  async function handleDelete() {
    if (confirm !== "DELETE") {
      toast.error('Type DELETE to confirm.');
      return;
    }
    setBusy("delete");
    try {
      await deleteFn({ data: { confirm: "DELETE" } });
      await supabase.auth.signOut();
      toast.success("Your account has been deleted.");
      navigate({ to: "/" });
    } catch (e: any) {
      toast.error(e?.message ?? "Delete failed");
      setBusy(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-6 shadow-[4px_4px_0_0_#0F0F0F]">
        <h3 className="text-lg font-bold">Export my data</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Download a JSON copy of everything we hold about you — profile, posts, messages, jobs, subscriptions, and more.
          Provided under your DPDP Act §11 Right to Access.
        </p>
        <button
          onClick={handleExport}
          disabled={busy !== null}
          className="mt-4 rounded-md border-[1.5px] border-[#0F0F0F] bg-cream px-4 py-2 text-sm font-bold hover:bg-cream/80 disabled:opacity-50"
        >
          {busy === "export" ? "Preparing…" : "Download my data"}
        </button>
      </div>

      <div className="rounded-2xl border-[1.5px] border-error/40 bg-error/5 p-6">
        <h3 className="text-lg font-bold text-error">Delete my account</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Permanently erases your account and all associated data — profile, projects, services, messages, subscriptions.
          This cannot be undone. Provided under your DPDP Act §12 Right to Erasure.
        </p>
        <label className="mt-4 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
          Type <span className="text-error">DELETE</span> to confirm
        </label>
        <input
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          className="mt-1.5 h-10 w-full rounded-md border border-error/40 bg-white px-3 text-sm outline-none focus:border-error"
          placeholder="DELETE"
        />
        <button
          onClick={handleDelete}
          disabled={busy !== null || confirm !== "DELETE"}
          className="mt-4 rounded-md border border-error/40 bg-error/10 px-4 py-2 text-sm font-bold text-error hover:bg-error/20 disabled:opacity-50"
        >
          {busy === "delete" ? "Deleting…" : "Delete my account permanently"}
        </button>
      </div>
    </div>
  );
}
