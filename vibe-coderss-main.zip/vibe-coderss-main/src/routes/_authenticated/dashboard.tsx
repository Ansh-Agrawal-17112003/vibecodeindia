import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { LayoutGrid, Plus, Briefcase, FileCode, Users, ExternalLink, FileText, Flame, Trophy, Coins, Zap } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { LevelBadge } from "@/components/site/LevelBadge";
import { useAuth } from "@/hooks/useAuth";
import { useXpProfile } from "@/hooks/useXpProfile";
import { levelFor, nextLevel, progressToNext, QUICK_XP_ACTIONS } from "@/lib/xp";
import { supabase } from "@/integrations/supabase/client";
import { ProfileBoostCard } from "@/components/features/ProfileBoost";
import { MissionCard } from "@/components/site/MissionCard";



export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard · VibeCode" }] }),
  component: DashboardPage,
});

type Profile = { id: string; display_name: string | null; username: string | null; roles: string[]; follower_count: number; onboarded_at: string | null };

function DashboardPage() {
  const { user } = useAuth();
  const { profile: xp } = useXpProfile();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);

  const [projectCount, setProjectCount] = useState(0);
  const [appsCount, setAppsCount] = useState(0);
  const [postedJobs, setPostedJobs] = useState<any[]>([]);
  const [incomingApps, setIncomingApps] = useState<any[]>([]);
  const [myApps, setMyApps] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: p } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
      if (!p?.onboarded_at) { navigate({ to: "/onboarding" }); return; }
      setProfile(p as Profile);

      const [{ count: pc }, { count: ac }, { data: pj }, { data: ma }] = await Promise.all([
        supabase.from("projects").select("id", { count: "exact", head: true }).eq("builder_id", user.id),
        supabase.from("job_applications").select("id", { count: "exact", head: true }).eq("applicant_id", user.id),
        supabase.from("jobs").select("id,title,status,created_at").eq("posted_by", user.id).order("created_at", { ascending: false }),
        supabase.from("job_applications").select("id,status,applied_at,job:jobs(id,title)").eq("applicant_id", user.id).order("applied_at", { ascending: false }).limit(10),
      ]);
      setProjectCount(pc ?? 0);
      setAppsCount(ac ?? 0);
      setPostedJobs(pj ?? []);
      setMyApps(ma ?? []);

      if (pj && pj.length) {
        const { data: ia } = await (supabase.from("job_applications") as any).select("id,status,applied_at,cover_note,resume_url,application_priority,applicant:profiles!applicant_id(id,display_name,username,subscription_plan,is_og_member,og_number,is_verified),job:jobs!job_id(id,title)").in("job_id", pj.map((x) => x.id)).order("application_priority", { ascending: false }).order("applied_at", { ascending: false });
        setIncomingApps(ia ?? []);
      }
    })();
  }, [user, navigate]);

  if (!profile) return <Shell><div className="container-page py-20 text-center text-muted-foreground">Loading…</div></Shell>;

  const isBuilder = profile.roles.includes("builder");
  const isHirer = profile.roles.includes("hirer");

  return (
    <Shell>
      <div className="container-page py-6 sm:py-8">
        <div className="grid grid-cols-1 items-start gap-4 sm:grid-cols-[minmax(0,1fr)_auto]">
          <div className="min-w-0">
            <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Dashboard</div>
            <h1 className="mt-1 truncate font-display text-2xl font-extrabold sm:text-3xl">Welcome back, {profile.display_name}</h1>
            <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
              <span className="truncate">@{profile.username ?? user?.email?.split("@")[0]}</span>
              {xp && <LevelBadge xp={xp.total_xp} size="xs" />}
              <span className="truncate">· {profile.roles.join(" · ") || "no role yet"}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 sm:justify-end">
            {isBuilder && <Link to="/submit-project" className="btn-coral h-10"><Plus className="h-4 w-4" /> New project</Link>}
            {isHirer && <Link to="/submit-job" className="inline-flex h-10 items-center gap-1.5 rounded-md border-[1.5px] border-[#0F0F0F] bg-gold px-4 text-sm font-bold" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}><Plus className="h-4 w-4" /> Post job</Link>}
          </div>
        </div>

        {xp && (
          <div className="mt-6 grid gap-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)]">
            <ProgressCard xp={xp.total_xp} />
            <StreakCard streak={xp.login_streak} longest={xp.longest_streak} />
            <VibeCoinCard balance={xp.vibecoin_balance} />
          </div>
        )}

        <MissionCard />





        {isHirer && (
          <section className="mt-10">
            <h2 className="font-display text-xl font-extrabold">Your posted jobs</h2>
            <div className="mt-3 space-y-2">
              {postedJobs.length === 0 && <Empty msg="No jobs yet. Post your first to start hiring." cta={<Link to="/submit-job" className="btn-coral h-9 text-xs">Post a job</Link>} />}
              {postedJobs.map((j) => (
                <Link key={j.id} to="/jobs/$id" params={{ id: j.id }} className="card-editorial flex items-center justify-between p-4 hover:-translate-y-0.5">
                  <div>
                    <div className="font-bold">{j.title}</div>
                    <div className="text-xs text-muted-foreground">{new Date(j.created_at).toLocaleDateString()} · {j.status}</div>
                  </div>
                  <ExternalLink className="h-4 w-4" />
                </Link>
              ))}
            </div>

            <h2 className="mt-8 font-display text-xl font-extrabold">Applications received</h2>
            <div className="mt-3 space-y-2">
              {incomingApps.length === 0 && <Empty msg="No applications yet." />}
              {incomingApps.map((a) => (
                <div key={a.id} className="card-editorial p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-bold">{a.applicant?.display_name ?? "Applicant"}</div>
                      <div className="text-xs text-muted-foreground">for <Link to="/jobs/$id" params={{ id: a.job.id }} className="font-bold hover:underline">{a.job.title}</Link> · {new Date(a.applied_at).toLocaleDateString()}</div>
                    </div>
                    <span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-2.5 py-0.5 text-xs font-bold">{a.status}</span>
                  </div>
                  {a.cover_note && <p className="mt-2 text-sm text-foreground/85">{a.cover_note}</p>}
                </div>
              ))}
            </div>
          </section>
        )}

        {isBuilder && (
          <section className="mt-10">
            <h2 className="font-display text-xl font-extrabold">Your applications</h2>
            <div className="mt-3 space-y-2">
              {myApps.length === 0 && <Empty msg="No applications yet. Find a job and apply!" cta={<Link to="/jobs" className="btn-coral h-9 text-xs">Browse jobs</Link>} />}
              {myApps.map((a: any) => (
                <Link key={a.id} to="/jobs/$id" params={{ id: a.job.id }} className="card-editorial flex items-center justify-between p-4">
                  <div>
                    <div className="font-bold">{a.job?.title ?? "Job"}</div>
                    <div className="text-xs text-muted-foreground">Applied {new Date(a.applied_at).toLocaleDateString()}</div>
                  </div>
                  <span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-card px-2.5 py-0.5 text-xs font-bold">{a.status}</span>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Pro / OG features — additive; nothing above is changed */}
        <section className="mt-10">
          <div className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">Pro features</div>
          <div className="mt-3 grid gap-4 md:grid-cols-3">
            <ProfileBoostCard />
            <Link to="/analytics" className="card-editorial hover-lift block p-4">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">📊 Profile analytics</div>
              <div className="mt-2 font-display text-lg font-extrabold">See who viewed you</div>
              <div className="mt-1 text-xs text-muted-foreground">Views, search appearances & top posts.</div>
            </Link>
            <Link to="/rewards" className="card-editorial hover-lift block p-4">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">🪙 VibeCoins</div>
              <div className="mt-2 font-display text-lg font-extrabold tabular-nums">{(xp?.vibecoin_balance ?? 0).toLocaleString()}</div>
              <div className="mt-1 text-xs text-muted-foreground">Redeem for community access & perks.</div>
            </Link>
          </div>
          <div className="mt-4">
            <Link to="/wins" className="card-editorial hover-lift block p-4">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">🏆 Real Wins</div>
              <div className="mt-2 font-display text-lg font-extrabold">Share what VibeCode got you</div>
              <div className="mt-1 text-xs text-muted-foreground">Hires, gigs, collabs, cashouts — every real outcome celebrated.</div>
            </Link>
          </div>
        </section>
      </div>
    </Shell>
  );
}


function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="card-editorial p-4">
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">{icon} {label}</div>
      <div className="mt-2 font-display text-3xl font-extrabold">{value}</div>
    </div>
  );
}

function Empty({ msg, cta }: { msg: string; cta?: React.ReactNode }) {
  return (
    <div className="card-editorial flex flex-col items-center gap-3 p-8 text-center">
      <LayoutGrid className="h-6 w-6 text-muted-foreground" />
      <p className="text-sm text-muted-foreground">{msg}</p>
      {cta}
    </div>
  );
}

function ProgressCard({ xp }: { xp: number }) {
  const lvl = levelFor(xp);
  const next = nextLevel(xp);
  const { pct, needed } = progressToNext(xp);
  return (
    <div className="card-editorial p-5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
          <Zap className="h-4 w-4" /> Your progress
        </div>
        <LevelBadge xp={xp} size="sm" />
      </div>
      <div className="mt-3 flex items-baseline gap-2">
        <div className="font-display text-3xl font-extrabold tabular-nums">{xp.toLocaleString()}</div>
        <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">XP</div>
      </div>
      <div className="mt-3 h-3 w-full overflow-hidden rounded-full border-[1.5px] border-[#0F0F0F] bg-white">
        <div
          className="h-full transition-[width] duration-500"
          style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${lvl.color}, ${next?.color ?? lvl.color})` }}
        />
      </div>
      <div className="mt-2 text-xs font-bold text-muted-foreground">
        {next ? `${needed.toLocaleString()} more XP to reach ${next.emoji} ${next.name}` : "Top level reached — you're a Vibe Master 👑"}
      </div>
      <div className="mt-4">
        <div className="text-[11px] font-extrabold uppercase tracking-wider text-muted-foreground">Quickest ways to earn XP</div>
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          {QUICK_XP_ACTIONS.map((a) => (
            <Link key={a.label} to={a.to} className="flex items-center justify-between rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 text-xs font-bold transition hover:-translate-y-0.5" style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}>
              <span className="truncate">{a.label}</span>
              <span className="shrink-0 text-coral">+{a.xp} XP</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function StreakCard({ streak, longest }: { streak: number; longest: number }) {
  const week = Array.from({ length: 7 }, (_, i) => i < Math.min(streak, 7));
  return (
    <div className="card-editorial p-5">
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        <Flame className="h-4 w-4 text-coral" /> Login streak
      </div>
      <div className="mt-3 flex items-baseline gap-2">
        <div className="font-display text-3xl font-extrabold tabular-nums">{streak}</div>
        <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">days 🔥</div>
      </div>
      <div className="mt-3 flex gap-1.5">
        {week.map((on, i) => (
          <div key={i} className={`h-6 w-6 rounded border-[1.5px] border-[#0F0F0F] ${on ? "bg-coral" : "bg-white"}`} />
        ))}
      </div>
      <div className="mt-3 text-xs font-bold text-muted-foreground">
        {streak >= 30 ? "🏅 Month Builder unlocked" : `${Math.max(0, 30 - streak)} more days for the Month Builder badge`}
      </div>
      <div className="mt-1 text-[11px] text-muted-foreground">Longest streak: {longest} days</div>
    </div>
  );
}

function VibeCoinCard({ balance }: { balance: number }) {
  return (
    <div className="card-editorial p-5">
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        <Coins className="h-4 w-4 text-gold" /> VibeCoins
      </div>
      <div className="mt-3 flex items-baseline gap-2">
        <div className="font-display text-3xl font-extrabold tabular-nums">{balance.toLocaleString()}</div>
        <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">🪙</div>
      </div>
      <div className="mt-3 text-xs text-muted-foreground">Earn coins by shipping projects, joining challenges & inviting builders.</div>
      <Link to="/rewards" className="btn-coral mt-4 h-9 w-full text-xs">
        <Trophy className="h-3.5 w-3.5" /> Open rewards
      </Link>
    </div>
  );
}

