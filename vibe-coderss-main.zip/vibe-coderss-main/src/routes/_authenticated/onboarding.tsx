import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Shell } from "@/components/site/Shell";
import { CheckCircle2, AlertCircle, Sparkles, Loader2 } from "lucide-react";
import { generateProfileContent } from "@/lib/ai-profile.functions";

export const Route = createFileRoute("/_authenticated/onboarding")({
  head: () => ({ meta: [{ title: "Complete your profile · VibeCode" }] }),
  component: Onboarding,
});

type Role = "builder" | "hirer";

const USERNAME_RE = /^[a-z0-9_]{3,24}$/;

function Onboarding() {
  const { user, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [roles, setRoles] = useState<Role[]>([]);
  const [busy, setBusy] = useState(false);
  const [aiBusy, setAiBusy] = useState(false);
  const [aiDone, setAiDone] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [usernameStatus, setUsernameStatus] = useState<"idle" | "checking" | "ok" | "taken" | "invalid">("idle");

  // shared / builder fields
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [skills, setSkills] = useState("");
  const [tools, setTools] = useState("");
  const [bio, setBio] = useState("");
  const [website, setWebsite] = useState("");
  const [github, setGithub] = useState("");
  const [linkedin, setLinkedin] = useState("");
  const [twitter, setTwitter] = useState("");

  // hirer fields
  const [hirerName, setHirerName] = useState("");
  const [isCompany, setIsCompany] = useState(false);
  const [companyName, setCompanyName] = useState("");
  const [companyWebsite, setCompanyWebsite] = useState("");
  const [confirmTrue, setConfirmTrue] = useState(false);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem("vc_signup_prefill");
      if (raw) {
        const p = JSON.parse(raw);
        if (p?.display_name) setDisplayName((cur) => cur || p.display_name);
        if (p?.display_name) setHirerName((cur) => cur || p.display_name);
        sessionStorage.removeItem("vc_signup_prefill");
      }
    } catch {}
    if (!user) return;
    supabase.from("profiles").select("onboarded_at, display_name, username, bio, location").eq("id", user.id).maybeSingle().then(({ data }) => {
      if (data?.onboarded_at && data.username && data.bio && data.location) navigate({ to: "/vibe" });
      if (data?.display_name) setDisplayName((cur) => cur || data.display_name!);
      if (data?.username) setUsername((cur) => cur || data.username!);
      if (data?.bio) setBio((cur) => cur || data.bio!);
      if (data?.location) setLocation((cur) => cur || data.location!);
    });
  }, [user, navigate]);

  // Live username availability check
  useEffect(() => {
    if (!username) { setUsernameStatus("idle"); return; }
    if (!USERNAME_RE.test(username)) { setUsernameStatus("invalid"); return; }
    setUsernameStatus("checking");
    const t = setTimeout(async () => {
      const { data } = await supabase.from("profiles").select("id").eq("username", username).maybeSingle();
      if (!data || data.id === user?.id) setUsernameStatus("ok");
      else setUsernameStatus("taken");
    }, 350);
    return () => clearTimeout(t);
  }, [username, user?.id]);

  function toggleRole(r: Role) {
    setRoles((prev) => (prev.length === 1 && prev[0] === r ? prev : [r]));
  }

  const isBuilder = roles.includes("builder");
  const isHirer = roles.includes("hirer");

  function validate(): boolean {
    const e: Record<string, string> = {};
    if (!displayName.trim() || displayName.trim().length < 2) e.displayName = "Full name is required (2+ chars).";
    if (!username || !USERNAME_RE.test(username)) e.username = "Username must be 3–24 chars (a–z, 0–9, _).";
    if (usernameStatus === "taken") e.username = "Username is already taken.";
    if (!bio.trim() || bio.trim().length < 30) e.bio = "Add a bio (at least 30 characters).";
    if (!location.trim()) e.location = "Location is required.";
    if (isBuilder) {
      if (!title.trim()) e.title = "Add your role / title.";
      if (!skills.trim() || skills.split(",").filter((s) => s.trim()).length < 2) e.skills = "Add at least 2 skills.";
    }
    if (isHirer && isCompany) {
      if (!companyName.trim()) e.companyName = "Company name is required.";
    }
    if (!confirmTrue) e.confirm = "Please confirm the details you entered are accurate.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  const completion = useMemo(() => {
    let score = 0;
    const total = isBuilder ? 8 : 6;
    if (displayName.trim().length >= 2) score++;
    if (USERNAME_RE.test(username) && usernameStatus !== "taken") score++;
    if (bio.trim().length >= 30) score++;
    if (location.trim()) score++;
    if (roles.length) score++;
    if (confirmTrue) score++;
    if (isBuilder) {
      if (title.trim()) score++;
      if (skills.split(",").filter((s) => s.trim()).length >= 2) score++;
    }
    return Math.round((score / total) * 100);
  }, [displayName, username, usernameStatus, bio, location, roles, confirmTrue, isBuilder, title, skills]);

  async function finish() {
    if (!user) return;
    if (!validate()) {
      toast.error("Please fix the highlighted fields.");
      return;
    }
    setBusy(true);
    try {
      const finalDisplayName = (displayName || hirerName || user.email!.split("@")[0]).trim();
      const { error: pErr } = await supabase
        .from("profiles")
        .update({
          display_name: finalDisplayName,
          username: username.trim(),
          bio: bio.trim(),
          location: location.trim(),
          website_url: website.trim() || null,
          github_url: github.trim() || null,
          linkedin_url: linkedin.trim() || null,
          x_url: twitter.trim() || null,
          onboarded_at: new Date().toISOString(),
        })
        .eq("id", user.id);
      if (pErr) throw pErr;

      await supabase.from("user_roles").delete().eq("user_id", user.id).in("role", ["builder", "hirer"]);
      const roleRows = roles.map((r) => ({ user_id: user.id, role: r }));
      if (roleRows.length) await supabase.from("user_roles").upsert(roleRows, { onConflict: "user_id,role" });

      if (isBuilder) {
        await supabase.from("builder_details").upsert({
          profile_id: user.id,
          title: title.trim(),
          skills: skills.split(",").map((s) => s.trim()).filter(Boolean),
          ai_tools: tools.split(",").map((s) => s.trim()).filter(Boolean),
        });
      }
      if (isHirer && isCompany && companyName) {
        await supabase.from("companies").insert({
          owner_profile_id: user.id,
          name: companyName.trim(),
          website: companyWebsite.trim() || null,
        });
      }

      // Mark the profile-incomplete notification as read so it stops nagging.
      await supabase.from("notifications").update({ read_at: new Date().toISOString() })
        .eq("user_id", user.id).eq("type", "profile_incomplete").is("read_at", null);

      toast.success("Profile complete — welcome to the feed!");
      await refreshProfile();
      navigate({ to: "/vibe" });
    } catch (e: any) {
      toast.error(e?.message ?? "Failed to save");
    } finally {
      setBusy(false);
    }
  }

  async function runAiAutofill() {
    if (!displayName.trim()) { toast.error("Add your name first — the AI needs something to write about."); return; }
    setAiBusy(true);
    try {
      const result = await generateProfileContent({
        data: {
          displayName: displayName.trim(),
          title: title.trim() || undefined,
          bio: bio.trim() || undefined,
          location: location.trim() || undefined,
          role: isBuilder ? "builder" : isHirer ? "hirer" : undefined,
          skills: skills.split(",").map((s) => s.trim()).filter(Boolean),
          tools: tools.split(",").map((s) => s.trim()).filter(Boolean),
        },
      });
      // Fill missing basics from the AI output so the profile has a real bio too.
      if (!bio.trim() && result?.about_long) {
        const short = result.about_long.split(/\n\n|\. /)[0].slice(0, 240);
        setBio(short.length < 30 ? result.about_long.slice(0, 240) : short);
      }
      if (!title.trim() && result?.headline) setTitle(result.headline);
      setAiDone(true);
      toast.success("AI profile drafted. Review, tweak, then publish.");
    } catch (e: any) {
      toast.error(e?.message ?? "AI autofill failed. You can still fill it manually.");
    } finally {
      setAiBusy(false);
    }
  }

  const usernameHint = () => {
    if (!username) return null;
    if (usernameStatus === "invalid") return <span className="text-xs text-red-600">3–24 chars, lowercase, numbers or _</span>;
    if (usernameStatus === "checking") return <span className="text-xs text-muted-foreground">Checking…</span>;
    if (usernameStatus === "ok") return <span className="text-xs text-emerald-600">@{username} is available</span>;
    if (usernameStatus === "taken") return <span className="text-xs text-red-600">@{username} is taken</span>;
    return null;
  };

  const inputCls = (k: string) =>
    `h-11 w-full rounded-lg border-[1.5px] px-3 text-sm ${errors[k] ? "border-red-500 bg-red-50" : "border-[#0F0F0F] bg-card"}`;

  return (
    <Shell hideFooter mobileChromeless>
      <div className="container-page max-w-2xl py-6 sm:py-10">
        {/* Progress */}
        <div className="mb-4 flex items-center justify-between text-xs font-bold">
          <span className="text-muted-foreground">Step {step + 1} of 2</span>
          <span>{completion}% complete</span>
        </div>
        <div className="mb-6 h-2 w-full overflow-hidden rounded-full bg-border">
          <div className="h-full bg-coral transition-all" style={{ width: `${completion}%` }} />
        </div>

        <div className="rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-4 sm:p-6" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}>
          {step === 0 && (
            <>
              <h2 className="font-display text-xl font-extrabold sm:text-2xl">How will you use VibeCode?</h2>
              <p className="mt-1 text-sm text-muted-foreground">This is a required step — your profile only goes live once complete.</p>
              <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {([
                  { id: "builder", title: "I'm a Builder", desc: "Showcase work, get hired, offer services." },
                  { id: "hirer", title: "I'm Hiring", desc: "Post jobs, discover AI builders." },
                ] as { id: Role; title: string; desc: string }[]).map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => toggleRole(opt.id)}
                    className={`rounded-xl border-[1.5px] border-[#0F0F0F] p-4 text-left transition ${roles.includes(opt.id) ? "bg-coral text-white" : "bg-card hover:-translate-y-0.5"}`}
                    style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
                  >
                    <div className="font-bold">{opt.title}</div>
                    <div className="mt-1 text-xs opacity-80">{opt.desc}</div>
                  </button>
                ))}
              </div>
              <button disabled={!roles.length} onClick={() => setStep(1)} className="btn-coral mt-6 h-11 w-full disabled:opacity-50">Continue →</button>
            </>
          )}

          {step === 1 && (
            <>
              <h2 className="font-display text-xl font-extrabold sm:text-2xl">Complete your profile</h2>
              <p className="mt-1 text-sm text-muted-foreground">All fields are required. Your profile becomes public after this.</p>

              <div className="mt-4 space-y-3">
                <div>
                  <label className="text-xs font-bold">Full name *</label>
                  <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Jane Sharma" className={inputCls("displayName")} />
                  {errors.displayName && <p className="mt-1 text-xs text-red-600">{errors.displayName}</p>}
                </div>

                <div>
                  <label className="text-xs font-bold">Username *</label>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">@</span>
                    <input value={username} onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))} placeholder="janesharma" className={inputCls("username")} />
                  </div>
                  <div className="mt-1">{errors.username ? <p className="text-xs text-red-600">{errors.username}</p> : usernameHint()}</div>
                </div>

                <div>
                  <label className="text-xs font-bold">Location *</label>
                  <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Bangalore, India" className={inputCls("location")} />
                  {errors.location && <p className="mt-1 text-xs text-red-600">{errors.location}</p>}
                </div>

                <div>
                  <label className="text-xs font-bold">Short bio * <span className="font-normal text-muted-foreground">({bio.trim().length}/30 min)</span></label>
                  <textarea value={bio} onChange={(e) => setBio(e.target.value)} placeholder="What you do, who you help, what makes you different." rows={3} className={`w-full rounded-lg border-[1.5px] p-3 text-sm ${errors.bio ? "border-red-500 bg-red-50" : "border-[#0F0F0F] bg-card"}`} />
                  {errors.bio && <p className="mt-1 text-xs text-red-600">{errors.bio}</p>}
                </div>

                {isBuilder && (
                  <>
                    <div>
                      <label className="text-xs font-bold">Role / Title *</label>
                      <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="AI Automation Builder" className={inputCls("title")} />
                      {errors.title && <p className="mt-1 text-xs text-red-600">{errors.title}</p>}
                    </div>
                    <div>
                      <label className="text-xs font-bold">Skills * <span className="font-normal text-muted-foreground">(comma-separated, min 2)</span></label>
                      <input value={skills} onChange={(e) => setSkills(e.target.value)} placeholder="React, LangChain, RAG, n8n" className={inputCls("skills")} />
                      {errors.skills && <p className="mt-1 text-xs text-red-600">{errors.skills}</p>}
                    </div>
                    <div>
                      <label className="text-xs font-bold">AI tools you use</label>
                      <input value={tools} onChange={(e) => setTools(e.target.value)} placeholder="Claude, Cursor, Lovable, OpenAI" className={inputCls("tools")} />
                    </div>
                  </>
                )}

                {isHirer && (
                  <>
                    <label className="flex items-center gap-2 text-sm">
                      <input type="checkbox" checked={isCompany} onChange={(e) => setIsCompany(e.target.checked)} /> I'm hiring on behalf of a company
                    </label>
                    {isCompany && (
                      <>
                        <div>
                          <label className="text-xs font-bold">Company name *</label>
                          <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} placeholder="Acme Inc." className={inputCls("companyName")} />
                          {errors.companyName && <p className="mt-1 text-xs text-red-600">{errors.companyName}</p>}
                        </div>
                        <div>
                          <label className="text-xs font-bold">Company website</label>
                          <input value={companyWebsite} onChange={(e) => setCompanyWebsite(e.target.value)} placeholder="https://acme.com" className={inputCls("companyWebsite")} />
                        </div>
                      </>
                    )}
                  </>
                )}

                <details className="rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3">
                  <summary className="cursor-pointer text-sm font-bold">Social links <span className="font-normal text-muted-foreground">(optional but recommended)</span></summary>
                  <div className="mt-3 space-y-2">
                    <input value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="Personal website (https://…)" className="h-10 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
                    <input value={linkedin} onChange={(e) => setLinkedin(e.target.value)} placeholder="LinkedIn URL" className="h-10 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
                    <input value={github} onChange={(e) => setGithub(e.target.value)} placeholder="GitHub URL" className="h-10 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
                    <input value={twitter} onChange={(e) => setTwitter(e.target.value)} placeholder="X / Twitter URL" className="h-10 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
                  </div>
                </details>

                {/* AI Autofill */}
                <div className="rounded-xl border-[1.5px] border-[#0F0F0F] bg-gradient-to-br from-coral/10 via-gold/10 to-transparent p-3">
                  <div className="flex items-start gap-2">
                    <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-coral text-white">
                      <Sparkles className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-black">Let AI write a detailed profile for you</div>
                      <p className="mt-0.5 text-xs text-muted-foreground">We'll expand what you've written into a proper multi-section profile — About, What I Do, Expertise, Why Work With Me, FAQ, and more. You can still edit anything after.</p>
                      <button
                        type="button"
                        disabled={aiBusy}
                        onClick={runAiAutofill}
                        className="mt-2 inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-3 py-1.5 text-xs font-black text-white disabled:opacity-60"
                        style={{ boxShadow: "2px 2px 0 0 #0F0F0F" }}
                      >
                        {aiBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                        {aiBusy ? "Drafting…" : aiDone ? "Regenerate ✨" : "Autofill with AI"}
                      </button>
                      {aiDone && <span className="ml-2 inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700"><CheckCircle2 className="h-3 w-3" /> Draft saved to your profile</span>}
                    </div>
                  </div>
                </div>

                <label className={`flex items-start gap-2 rounded-lg border-[1.5px] p-3 text-sm ${errors.confirm ? "border-red-500 bg-red-50" : "border-[#0F0F0F] bg-card"}`}>

                  <input type="checkbox" checked={confirmTrue} onChange={(e) => setConfirmTrue(e.target.checked)} className="mt-1" />
                  <span>
                    I confirm the information above is accurate. I understand that impersonation or fake profiles may be removed.
                  </span>
                </label>
                {errors.confirm && <p className="text-xs text-red-600">{errors.confirm}</p>}
              </div>

              <div className="mt-6 flex gap-2">
                <button onClick={() => setStep(0)} className="h-11 flex-1 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card text-sm font-bold">← Back</button>
                <button disabled={busy} onClick={finish} className="btn-coral h-11 flex-[2]">
                  {busy ? "Saving…" : "Publish profile →"}
                </button>
              </div>

              {Object.keys(errors).length > 0 && (
                <div className="mt-3 flex items-center gap-2 rounded-lg border-[1.5px] border-red-500 bg-red-50 p-2 text-xs text-red-700">
                  <AlertCircle className="h-4 w-4" /> Please fix {Object.keys(errors).length} field(s) above.
                </div>
              )}
              {completion === 100 && Object.keys(errors).length === 0 && (
                <div className="mt-3 flex items-center gap-2 rounded-lg border-[1.5px] border-emerald-500 bg-emerald-50 p-2 text-xs text-emerald-700">
                  <CheckCircle2 className="h-4 w-4" /> Looks great! Hit Publish to go live.
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </Shell>
  );
}
