import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Shell } from "@/components/site/Shell";

export const Route = createFileRoute("/_authenticated/submit-job")({
  head: () => ({ meta: [{ title: "Post a Job · VibeCode" }] }),
  component: PostJobPage,
});

function PostJobPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({
    title: "", description: "", location: "Remote",
    job_type: "full-time", remote_type: "remote",
    salary_min: "", salary_max: "",
    requirements: "", tools_required: "",
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    // ensure hirer role
    await supabase.from("user_roles").upsert({ user_id: user.id, role: "hirer" }, { onConflict: "user_id,role" });

    const { data, error } = await supabase.from("jobs").insert({
      posted_by: user.id,
      title: f.title,
      description: f.description,
      location: f.location,
      job_type: f.job_type as any,
      remote_type: f.remote_type as any,
      salary_min: f.salary_min ? Number(f.salary_min) : null,
      salary_max: f.salary_max ? Number(f.salary_max) : null,
      requirements: f.requirements.split("\n").map((s) => s.trim()).filter(Boolean),
      tools_required: f.tools_required.split(",").map((s) => s.trim()).filter(Boolean),
    }).select("id").single();
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Job posted!");
    navigate({ to: "/jobs/$id", params: { id: data!.id } });
  }

  return (
    <Shell>
      <div className="container-page max-w-2xl py-10">
        <Link to="/dashboard" className="text-xs font-bold text-muted-foreground">← Dashboard</Link>
        <h1 className="mt-2 font-display text-3xl font-extrabold">Post a job</h1>
        <form onSubmit={submit} className="mt-6 space-y-3 rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-6" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}>
          <input required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="Job title" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          <textarea required rows={6} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} placeholder="Description" className="w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3 text-sm" />
          <div className="grid grid-cols-2 gap-3">
            <select value={f.job_type} onChange={(e) => setF({ ...f, job_type: e.target.value })} className="h-11 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm">
              <option value="full-time">Full-time</option><option value="part-time">Part-time</option><option value="freelance">Freelance</option><option value="internship">Internship</option>
            </select>
            <select value={f.remote_type} onChange={(e) => setF({ ...f, remote_type: e.target.value })} className="h-11 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm">
              <option value="remote">Remote</option><option value="hybrid">Hybrid</option><option value="onsite">On-site</option>
            </select>
          </div>
          <input value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} placeholder="Location" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          <div className="grid grid-cols-2 gap-3">
            <input type="number" value={f.salary_min} onChange={(e) => setF({ ...f, salary_min: e.target.value })} placeholder="Min salary (₹/yr)" className="h-11 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
            <input type="number" value={f.salary_max} onChange={(e) => setF({ ...f, salary_max: e.target.value })} placeholder="Max salary (₹/yr)" className="h-11 rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          </div>
          <textarea rows={4} value={f.requirements} onChange={(e) => setF({ ...f, requirements: e.target.value })} placeholder="Requirements (one per line)" className="w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3 text-sm" />
          <input value={f.tools_required} onChange={(e) => setF({ ...f, tools_required: e.target.value })} placeholder="Tools (comma-separated)" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          <button disabled={busy} className="btn-coral h-11 w-full">{busy ? "Posting…" : "Publish job →"}</button>
        </form>
      </div>
    </Shell>
  );
}
