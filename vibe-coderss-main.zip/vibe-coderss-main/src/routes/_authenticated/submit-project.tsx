import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Shell } from "@/components/site/Shell";

export const Route = createFileRoute("/_authenticated/submit-project")({
  head: () => ({ meta: [{ title: "Add Project · VibeCode" }] }),
  component: AddProjectPage,
});

function AddProjectPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({ title: "", problem: "", solution: "", tools: "", live: "", github: "", tags: "", industry: "" });
  const [file, setFile] = useState<File | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    try {
      await supabase.from("user_roles").upsert({ user_id: user.id, role: "builder" }, { onConflict: "user_id,role" });
      let coverUrl: string | null = null;
      if (file) {
        if (file.size > 5 * 1024 * 1024) throw new Error("Cover image must be < 5MB");
        const path = `${user.id}/${Date.now()}-${file.name.replace(/[^a-z0-9.\-_]/gi, "_")}`;
        const { error: upErr } = await supabase.storage.from("project-covers").upload(path, file);
        if (upErr) throw upErr;
        const { data } = supabase.storage.from("project-covers").getPublicUrl(path);
        coverUrl = data.publicUrl;
      }
      const { error } = await supabase.from("projects").insert({
        builder_id: user.id,
        title: f.title,
        problem_solved: f.problem,
        solution: f.solution,
        tools_used: f.tools.split(",").map((s) => s.trim()).filter(Boolean),
        live_demo_url: f.live || null,
        github_url: f.github || null,
        tags: f.tags.split(",").map((s) => s.trim()).filter(Boolean),
        industry: f.industry || null,
        cover_image_url: coverUrl,
      });
      if (error) throw error;
      toast.success("Project added!");
      navigate({ to: "/dashboard" });
    } catch (e: any) {
      toast.error(e?.message ?? "Failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Shell>
      <div className="container-page max-w-2xl py-10">
        <Link to="/dashboard" className="text-xs font-bold text-muted-foreground">← Dashboard</Link>
        <h1 className="mt-2 font-display text-3xl font-extrabold">Add a project</h1>
        <form onSubmit={submit} className="mt-6 space-y-3 rounded-2xl border-[1.5px] border-[#0F0F0F] bg-card p-6" style={{ boxShadow: "4px 4px 0 0 #0F0F0F" }}>
          <input required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="Project title" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="text-sm" />
          <textarea rows={3} value={f.problem} onChange={(e) => setF({ ...f, problem: e.target.value })} placeholder="Problem you solved" className="w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3 text-sm" />
          <textarea rows={4} value={f.solution} onChange={(e) => setF({ ...f, solution: e.target.value })} placeholder="How you built it" className="w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card p-3 text-sm" />
          <input value={f.tools} onChange={(e) => setF({ ...f, tools: e.target.value })} placeholder="Tools (comma-separated)" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          <input value={f.industry} onChange={(e) => setF({ ...f, industry: e.target.value })} placeholder="Industry" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          <input value={f.tags} onChange={(e) => setF({ ...f, tags: e.target.value })} placeholder="Tags (comma-separated)" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          <input value={f.live} onChange={(e) => setF({ ...f, live: e.target.value })} placeholder="Live demo URL" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          <input value={f.github} onChange={(e) => setF({ ...f, github: e.target.value })} placeholder="GitHub URL" className="h-11 w-full rounded-lg border-[1.5px] border-[#0F0F0F] bg-card px-3 text-sm" />
          <button disabled={busy} className="btn-coral h-11 w-full">{busy ? "Saving…" : "Publish project →"}</button>
        </form>
      </div>
    </Shell>
  );
}
