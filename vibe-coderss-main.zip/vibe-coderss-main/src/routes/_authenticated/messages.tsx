import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Loader2, Lock, MessageSquare, MessageSquarePlus, Search, X, Plus, Send, Image as ImageIcon, Video, Mic, Paperclip, Pencil, Trash2, MoreVertical, Check } from "lucide-react";
import { toast } from "sonner";
import { Shell } from "@/components/site/Shell";
import {
  AttachmentPreview,
  uploadAttachment,
} from "@/components/site/MessagingExtras";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";


export const Route = createFileRoute("/_authenticated/messages")({
  validateSearch: (search: Record<string, unknown>) => ({
    to: typeof search.to === "string" ? search.to : undefined,
    c: typeof search.c === "string" ? search.c : undefined,
  }),
  head: () => ({ meta: [{ title: "Messages · VibeCoder" }] }),
  component: MessagesPage,
});

type Profile = Pick<Database["public"]["Tables"]["profiles"]["Row"], "id" | "display_name" | "avatar_url" | "username">;
type ConversationRow = Database["public"]["Tables"]["conversations"]["Row"];
type MessageRow = Database["public"]["Tables"]["messages"]["Row"];

type Conversation = ConversationRow & {
  other: Profile | null;
  unread: number;
};

type MockConversation = {
  id: string;
  mock: true;
  name: string;
  username: string;
  avatar: string;
  last: string;
  when: string;
  unread: number;
  online: boolean;
};

type MockMessage = { id: string; mine: boolean; body: string; time: string };

const MOCK_CONVERSATIONS: MockConversation[] = [];


const avatarFor = (profile?: Profile | null, seed?: string) =>
  profile?.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed ?? profile?.id ?? "builder")}`;

const nameFor = (profile?: Profile | null) => profile?.display_name || profile?.username || "Builder";

function MessagesPage() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const search = Route.useSearch();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(search.c ?? null);
  const [messages, setMessages] = useState<MessageRow[]>([]);
  const [loadingConversations, setLoadingConversations] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [composerOpen, setComposerOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [mockThreads, setMockThreads] = useState<Record<string, MockMessage[]>>({});

  useEffect(() => {
    if (search.c) setActiveId(search.c);
  }, [search.c]);

  const loadConversations = async () => {
    if (!user) return;
    setLoadingConversations(true);

    const { data: rows, error } = await supabase
      .from("conversations")
      .select("*")
      .or(`user_a.eq.${user.id},user_b.eq.${user.id}`)
      .order("last_message_at", { ascending: false, nullsFirst: false });

    if (error) {
      toast.error("Could not load conversations");
      setLoadingConversations(false);
      return;
    }

    const conversationsRows = rows ?? [];
    const otherIds = Array.from(new Set(conversationsRows.map((row) => (row.user_a === user.id ? row.user_b : row.user_a))));
    const { data: profiles } = otherIds.length
      ? await supabase.from("profiles").select("id, display_name, avatar_url, username").in("id", otherIds)
      : { data: [] as Profile[] };
    const profileMap = new Map((profiles ?? []).map((profile) => [profile.id, profile]));

    const unreadMap = new Map<string, number>();
    const { data: unreadRows } = await supabase
      .from("messages")
      .select("conversation_id")
      .eq("recipient_id", user.id)
      .is("read_at", null);
    for (const row of unreadRows ?? []) {
      unreadMap.set(row.conversation_id, (unreadMap.get(row.conversation_id) ?? 0) + 1);
    }

    const next = conversationsRows.map((row) => {
      const otherId = row.user_a === user.id ? row.user_b : row.user_a;
      return { ...row, other: profileMap.get(otherId) ?? null, unread: unreadMap.get(row.id) ?? 0 };
    });

    setConversations(next);
    setLoadingConversations(false);
  };

  useEffect(() => {
    if (!authLoading && user) void loadConversations();
  }, [authLoading, user?.id]);

  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel(`messages-inbox:${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "messages", filter: `recipient_id=eq.${user.id}` }, () => {
        void loadConversations();
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "messages", filter: `sender_id=eq.${user.id}` }, () => {
        void loadConversations();
      })
      .subscribe((status) => {
        if (status === "CHANNEL_ERROR") console.warn("[messages] inbox realtime channel error");
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  useEffect(() => {
    if (!user || !search.to) return;

    let cancelled = false;
    (async () => {
      const { data: conversationId, error } = await supabase.rpc("get_or_create_conversation", { _other: search.to });
      if (cancelled) return;
      if (error || !conversationId) {
        toast.error(error?.message || "Could not open message thread");
        return;
      }
      setActiveId(conversationId);
      await loadConversations();
      navigate({ to: "/messages", search: { c: conversationId }, replace: true });
    })();

    return () => {
      cancelled = true;
    };
  }, [search.to, user?.id]);

  useEffect(() => {
    if (!activeId || !user || activeId.startsWith("mock:")) {
      if (!activeId?.startsWith("mock:")) setMessages([]);
      return;
    }

    let cancelled = false;
    const loadMessages = async () => {
      setLoadingMessages(true);
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("conversation_id", activeId)
        .order("created_at", { ascending: true });

      if (cancelled) return;
      if (error) {
        toast.error("Could not load messages");
        setLoadingMessages(false);
        return;
      }
      setMessages(data ?? []);
      setLoadingMessages(false);

      await supabase.from("messages").update({ read_at: new Date().toISOString() }).eq("conversation_id", activeId).eq("recipient_id", user.id).is("read_at", null);
      setConversations((prev) => prev.map((conversation) => (conversation.id === activeId ? { ...conversation, unread: 0 } : conversation)));
    };

    void loadMessages();
    const channel = supabase
      .channel(`messages:${activeId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "messages", filter: `conversation_id=eq.${activeId}` },
        () => {
          void loadMessages();
          void loadConversations();
        },
      )
      .subscribe((status) => {
        if (status === "CHANNEL_ERROR") console.warn("[messages] realtime channel error");
      });

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [activeId, user?.id]);

  const activeConversation = useMemo(
    () => conversations.find((conversation) => conversation.id === activeId) ?? null,
    [activeId, conversations],
  );
  const activeMock = useMemo(
    () => (activeId?.startsWith("mock:") ? MOCK_CONVERSATIONS.find((m) => m.id === activeId) ?? null : null),
    [activeId],
  );

  if (authLoading || !user) {
    return (
      <Shell mobileChromeless>
        <div className="grid min-h-screen place-items-center">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Opening messages…
          </div>
        </div>
      </Shell>
    );
  }

  const mobileChatOpen = !!activeId;

  // Combined + filtered list
  const q = query.trim().toLowerCase();
  const realItems = conversations.map((c) => ({
    id: c.id,
    kind: "real" as const,
    name: nameFor(c.other),
    username: c.other?.username ?? "",
    avatar: avatarFor(c.other, c.id),
    last: c.last_message || "Say hello and start building together.",
    when: c.last_message_at ? shortWhen(c.last_message_at) : "",
    unread: c.unread,
    online: false,
  }));
  const mockItems = MOCK_CONVERSATIONS.map((m) => ({ ...m, kind: "mock" as const }));
  const all = [...realItems, ...mockItems];
  const filtered = q ? all.filter((x) => x.name.toLowerCase().includes(q) || x.username.toLowerCase().includes(q) || x.last.toLowerCase().includes(q)) : all;

  return (
    <Shell mobileChromeless>
      {/* MOBILE: full-screen chromeless */}
      <div className="lg:hidden">
        {mobileChatOpen ? (
          activeMock ? (
            <MockChatWindow
              conv={activeMock}
              messages={mockThreads[activeMock.id] ?? seedMockThread(activeMock)}
              onBack={() => { setActiveId(null); navigate({ to: "/messages", search: {}, replace: true }); }}
              onSend={(text) => setMockThreads((prev) => {
                const cur = prev[activeMock.id] ?? seedMockThread(activeMock);
                return { ...prev, [activeMock.id]: [...cur, { id: crypto.randomUUID(), mine: true, body: text, time: "now" }] };
              })}
            />
          ) : (
            <ChatWindow
              key={activeId ?? "empty"}
              userId={user.id}
              conversation={activeConversation}
              messages={messages}
              loading={loadingMessages}
              onBack={() => { setActiveId(null); navigate({ to: "/messages", search: {}, replace: true }); }}
              onSent={() => { void loadConversations(); }}
              fullscreen
            />
          )
        ) : (
          <MobileInbox
            items={filtered}
            query={query}
            setQuery={setQuery}
            loading={loadingConversations}
            onBack={() => navigate({ to: "/" })}
            onNew={() => setComposerOpen(true)}
            onSelect={(id) => {
              setActiveId(id);
              if (!id.startsWith("mock:")) navigate({ to: "/messages", search: { c: id }, replace: true });
            }}
          />
        )}
      </div>

      {/* DESKTOP: original two-pane */}
      <div className="hidden lg:block">
        <div className="container-page py-6">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <h1 className="font-display text-2xl font-extrabold sm:text-3xl">Messages</h1>
              <p className="text-sm text-muted-foreground">Direct messages with builders — end-to-end encrypted</p>
            </div>
            <button
              onClick={() => setComposerOpen(true)}
              className="inline-flex h-10 items-center gap-2 rounded-md border-[1.5px] border-foreground bg-coral px-3 text-sm font-bold text-white shadow-[2px_2px_0_0_#0F0F0F]"
            >
              <MessageSquarePlus className="h-4 w-4" /> New
            </button>
          </div>

          <div className="grid gap-4 md:grid-cols-[330px_1fr]">
            <DesktopConversationList
              items={filtered}
              activeId={activeId}
              loading={loadingConversations}
              query={query}
              setQuery={setQuery}
              onSelect={(id) => {
                setActiveId(id);
                if (!id.startsWith("mock:")) navigate({ to: "/messages", search: { c: id }, replace: true });
              }}
            />

            {activeMock ? (
              <MockChatWindow
                conv={activeMock}
                messages={mockThreads[activeMock.id] ?? seedMockThread(activeMock)}
                onBack={() => setActiveId(null)}
                onSend={(text) => setMockThreads((prev) => {
                  const cur = prev[activeMock.id] ?? seedMockThread(activeMock);
                  return { ...prev, [activeMock.id]: [...cur, { id: crypto.randomUUID(), mine: true, body: text, time: "now" }] };
                })}
              />
            ) : (
              <ChatWindow
                key={activeId ?? "empty"}
                userId={user.id}
                conversation={activeConversation}
                messages={messages}
                loading={loadingMessages}
                onBack={() => { setActiveId(null); navigate({ to: "/messages", search: {}, replace: true }); }}
                onSent={() => { void loadConversations(); }}
              />
            )}
          </div>
        </div>
      </div>

      {composerOpen && (
        <NewMessageDialog
          currentUserId={user.id}
          onClose={() => setComposerOpen(false)}
          onOpen={(conversationId) => {
            setActiveId(conversationId);
            navigate({ to: "/messages", search: { c: conversationId }, replace: true });
            void loadConversations();
          }}
        />
      )}
    </Shell>
  );
}

function shortWhen(iso: string) {
  const d = new Date(iso).getTime();
  const diff = Math.max(0, Date.now() - d);
  const m = Math.floor(diff / 60000);
  if (m < 1) return "now";
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  const days = Math.floor(h / 24);
  return `${days}d`;
}

function seedMockThread(conv: MockConversation): MockMessage[] {
  return [
    { id: "m1", mine: false, body: `Hey! I'm ${conv.name.split(" ")[0]} 👋`, time: conv.when },
    { id: "m2", mine: false, body: conv.last, time: conv.when },
  ];
}

type InboxItem = {
  id: string;
  kind: "real" | "mock";
  name: string;
  username: string;
  avatar: string;
  last: string;
  when: string;
  unread: number;
  online: boolean;
};

function MobileInbox({
  items, query, setQuery, loading, onBack, onNew, onSelect,
}: {
  items: InboxItem[];
  query: string;
  setQuery: (v: string) => void;
  loading: boolean;
  onBack: () => void;
  onNew: () => void;
  onSelect: (id: string) => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#FAF6F1]">
      {/* Top bar: back + search */}
      <div className="sticky top-0 z-10 flex items-center gap-2 border-b-[1.5px] border-foreground bg-white px-3 py-2.5">
        <button onClick={onBack} className="grid h-9 w-9 shrink-0 place-items-center rounded-full hover:bg-[#F5EFE5]" aria-label="Back">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search messages"
            className="h-9 w-full rounded-full border-[1.5px] border-foreground bg-[#FAF6F1] pl-9 pr-9 text-[13px] outline-none focus:border-coral"
          />
          {query && (
            <button onClick={() => setQuery("")} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-1 hover:bg-[#F5EFE5]" aria-label="Clear">
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
        <button onClick={onNew} className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-coral text-white" aria-label="New message">
          <MessageSquarePlus className="h-4 w-4" />
        </button>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto pb-6">
        {loading && items.length === 0 && (
          <div className="grid h-40 place-items-center text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Loading inbox…</span>
          </div>
        )}
        {items.length === 0 && !loading && (
          <div className="grid h-64 place-items-center px-6 text-center">
            <div>
              <MessageSquare className="mx-auto h-8 w-8 text-coral" />
              <p className="mt-3 font-display text-lg font-extrabold">No matches</p>
              <p className="mt-1 text-sm text-muted-foreground">Try a different search.</p>
            </div>
          </div>
        )}
        {items.map((c) => (
          <button
            key={c.id}
            onClick={() => onSelect(c.id)}
            className="flex w-full items-start gap-3 border-b border-black/5 bg-white px-3 py-3 text-left active:bg-[#F5EFE5]"
          >
            <div className="relative shrink-0">
              <img src={c.avatar} alt="" className="h-12 w-12 rounded-full border-[1.5px] border-foreground object-cover" />
              {c.online && <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white bg-emerald-500" />}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-[14px] font-extrabold">{c.name}</span>
                <span className="shrink-0 text-[11px] text-muted-foreground">{c.when}</span>
              </div>
              <div className="mt-0.5 flex items-center justify-between gap-2">
                <span className={`truncate text-[12.5px] ${c.unread > 0 ? "font-bold text-foreground" : "text-muted-foreground"}`}>{c.last}</span>
                {c.unread > 0 && (
                  <span className="ml-2 grid h-5 min-w-5 shrink-0 place-items-center rounded-full bg-coral px-1.5 text-[10px] font-black text-white">{c.unread}</span>
                )}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function DesktopConversationList({
  items, activeId, loading, query, setQuery, onSelect,
}: {
  items: InboxItem[];
  activeId: string | null;
  loading: boolean;
  query: string;
  setQuery: (v: string) => void;
  onSelect: (id: string) => void;
}) {
  return (
    <aside className="rounded-xl border-[1.5px] border-foreground bg-card overflow-hidden">
      <div className="border-b-[1.5px] border-foreground bg-white px-3 py-2.5">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search messages"
            className="h-9 w-full rounded-full border-[1.5px] border-foreground bg-[#FAF6F1] pl-9 pr-3 text-sm outline-none focus:border-coral"
          />
        </div>
      </div>
      <div className="max-h-[calc(100vh-230px)] min-h-[420px] overflow-y-auto">
        {loading && items.length === 0 && (
          <div className="grid h-44 place-items-center text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Loading inbox…</span>
          </div>
        )}
        {items.map((c) => {
          const active = c.id === activeId;
          return (
            <button
              key={c.id}
              onClick={() => onSelect(c.id)}
              className={`flex w-full items-start gap-3 border-b border-border px-3 py-3 text-left transition ${active ? "bg-[#FFE9DC]" : "hover:bg-white"}`}
            >
              <img src={c.avatar} alt="" className="h-11 w-11 shrink-0 rounded-full border-[1.5px] border-foreground object-cover" />
              <span className="min-w-0 flex-1">
                <span className="flex items-center justify-between gap-2">
                  <span className="truncate text-sm font-extrabold">{c.name}</span>
                  <span className="text-[11px] text-muted-foreground">{c.when}</span>
                </span>
                <span className="mt-1 flex items-center justify-between gap-2">
                  <span className="line-clamp-1 block text-xs text-muted-foreground">{c.last}</span>
                  {c.unread > 0 && <span className="rounded-full bg-coral px-2 py-0.5 text-[10px] font-black text-white">{c.unread}</span>}
                </span>
              </span>
            </button>
          );
        })}
      </div>
    </aside>
  );
}

/* ----- Composer (shared) ----- */

function Composer({
  onSend, onFile, disabled, placeholder,
}: {
  onSend: (text: string) => void;
  onFile?: (file: File) => void;
  disabled?: boolean;
  placeholder?: string;
}) {
  const [draft, setDraft] = useState("");
  const [attachOpen, setAttachOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const [accept, setAccept] = useState<string>("*/*");
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setAttachOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const submit = () => {
    const text = draft.trim();
    if (!text) return;
    onSend(text);
    setDraft("");
  };

  const pick = (a: string) => {
    setAccept(a);
    setAttachOpen(false);
    requestAnimationFrame(() => fileRef.current?.click());
  };

  return (
    <div ref={rootRef} className="relative border-t-[1.5px] border-foreground bg-white px-3 py-2.5 md:px-4 md:py-3">
      {attachOpen && (
        <div className="absolute bottom-14 left-3 z-20 w-52 overflow-hidden rounded-xl border-[1.5px] border-foreground bg-white shadow-[3px_3px_0_0_#0F0F0F] md:left-4">
          <AttachOption icon={<ImageIcon className="h-4 w-4" />} label="Photo" onClick={() => pick("image/*")} />
          <AttachOption icon={<Video className="h-4 w-4" />} label="Video" onClick={() => pick("video/*")} />
          <AttachOption icon={<Mic className="h-4 w-4" />} label="Voice note" onClick={() => pick("audio/*")} />
          <AttachOption icon={<Paperclip className="h-4 w-4" />} label="File" onClick={() => pick("*/*")} />
        </div>
      )}
      <input
        ref={fileRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f && onFile) onFile(f); e.currentTarget.value = ""; }}
      />
      <div className="flex items-end gap-2">
        <button
          onClick={() => setAttachOpen((v) => !v)}
          className="grid h-11 w-11 shrink-0 place-items-center rounded-full border-[1.5px] border-foreground bg-white text-foreground hover:bg-[#F5EFE5]"
          aria-label="Add attachment"
          type="button"
        >
          <Plus className="h-5 w-5" />
        </button>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); }
          }}
          placeholder={placeholder ?? "Write a message"}
          rows={1}
          className="max-h-32 min-h-11 flex-1 resize-none rounded-3xl border-[1.5px] border-foreground bg-[#FAF6F1] px-4 py-2.5 text-[14px] outline-none focus:border-coral"
        />
        <button
          onClick={submit}
          disabled={disabled || !draft.trim()}
          className="grid h-11 w-11 shrink-0 place-items-center rounded-full border-[1.5px] border-foreground bg-coral text-white disabled:opacity-50"
          aria-label="Send message"
          type="button"
        >
          <Send className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}

function AttachOption({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-2.5 border-b border-black/5 px-3 py-2.5 text-left text-sm font-bold last:border-b-0 hover:bg-[#F5EFE5]">
      <span className="grid h-8 w-8 place-items-center rounded-full bg-[#F5EFE5]">{icon}</span>
      {label}
    </button>
  );
}

/* ----- Chat windows ----- */

function ChatWindow({
  userId, conversation, messages, loading, onBack, onSent, fullscreen,
}: {
  userId: string;
  conversation: Conversation | null;
  messages: MessageRow[];
  loading: boolean;
  onBack: () => void;
  onSent: () => void;
  fullscreen?: boolean;
}) {
  const [sending, setSending] = useState(false);
  const [attachment, setAttachment] = useState<{ url: string; name: string; type: string } | null>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length, conversation?.id]);

  const doSend = async (body: string) => {
    if (!conversation || sending) return;
    if (!body && !attachment) return;
    const recipientId = conversation.user_a === userId ? conversation.user_b : conversation.user_a;
    setSending(true);
    const { error } = await supabase.from("messages").insert({
      conversation_id: conversation.id,
      sender_id: userId,
      recipient_id: recipientId,
      body: body || null,
      attachment_url: attachment?.url ?? null,
      attachment_name: attachment?.name ?? null,
      attachment_type: attachment?.type ?? null,
    });
    setSending(false);
    if (error) { toast.error(error.message); return; }
    setAttachment(null);
    onSent();
  };

  const doFile = async (file: File) => {
    try {
      setSending(true);
      const uploaded = await uploadAttachment(userId, file, file.name, file.type || "application/octet-stream");
      setAttachment(uploaded);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    } finally { setSending(false); }
  };

  const wrapperCls = fullscreen
    ? "fixed inset-0 z-50 flex flex-col bg-[#FAF6F1]"
    : "flex overflow-hidden rounded-xl border-[1.5px] border-foreground bg-card min-h-[calc(100vh-230px)] flex-col";

  if (!conversation) {
    return (
      <section className={wrapperCls}>
        <div className="grid h-full flex-1 place-items-center p-6 text-center">
          <div>
            <MessageSquare className="mx-auto h-10 w-10 text-coral" />
            <p className="mt-3 font-display text-xl font-extrabold">Select a conversation</p>
            <p className="mt-1 text-sm text-muted-foreground">Your chat will open here instantly.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className={wrapperCls}>
      <header className="flex items-center gap-3 border-b-[1.5px] border-foreground bg-white px-3 py-2.5">
        <button onClick={onBack} className="grid h-9 w-9 shrink-0 place-items-center rounded-full hover:bg-[#F5EFE5]" aria-label="Back">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <img src={avatarFor(conversation.other, conversation.id)} alt="" className="h-9 w-9 rounded-full border-[1.5px] border-foreground object-cover" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-[14px] font-extrabold">{nameFor(conversation.other)}</p>
          <p className="flex items-center gap-1 text-[11px] text-muted-foreground"><Lock className="h-3 w-3" /> End-to-end encrypted</p>
        </div>
      </header>

      <div ref={listRef} className="flex-1 space-y-2 overflow-y-auto px-3 py-3">
        {loading && (
          <div className="grid h-full place-items-center text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Loading messages…</span>
          </div>
        )}
        {!loading && messages.length === 0 && (
          <div className="grid h-full place-items-center text-center">
            <div>
              <Lock className="mx-auto h-6 w-6 text-coral" />
              <p className="mt-2 font-display text-base font-extrabold">Start the conversation</p>
              <p className="mt-1 text-xs text-muted-foreground">Messages are end-to-end encrypted.</p>
            </div>
          </div>
        )}
        {messages.map((message) => {
          const mine = message.sender_id === userId;
          return (
            <MessageBubble key={message.id} message={message} mine={mine} />
          );
        })}
      </div>

      {attachment && (
        <div className="mx-3 mb-1 flex items-center justify-between rounded-md border-[1.5px] border-foreground bg-white px-3 py-2 text-xs font-bold">
          <span className="truncate">Attached: {attachment.name}</span>
          <button onClick={() => setAttachment(null)} className="text-coral">Remove</button>
        </div>
      )}
      <Composer onSend={(t) => void doSend(t)} onFile={(f) => void doFile(f)} disabled={sending} />
      
    </section>
  );
}

function MockChatWindow({
  conv, messages, onBack, onSend,
}: {
  conv: MockConversation;
  messages: MockMessage[];
  onBack: () => void;
  onSend: (text: string) => void;
}) {
  const listRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = listRef.current; if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length]);

  return (
    <section className="fixed inset-0 z-50 flex flex-col bg-[#FAF6F1] lg:static lg:z-auto lg:rounded-xl lg:border-[1.5px] lg:border-foreground lg:min-h-[calc(100vh-230px)]">
      <header className="flex items-center gap-3 border-b-[1.5px] border-foreground bg-white px-3 py-2.5">
        <button onClick={onBack} className="grid h-9 w-9 shrink-0 place-items-center rounded-full hover:bg-[#F5EFE5]" aria-label="Back">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="relative">
          <img src={conv.avatar} alt="" className="h-9 w-9 rounded-full border-[1.5px] border-foreground object-cover" />
          {conv.online && <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-white bg-emerald-500" />}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[14px] font-extrabold">{conv.name}</p>
          <p className="flex items-center gap-1 text-[11px] text-muted-foreground"><Lock className="h-3 w-3" /> End-to-end encrypted</p>
        </div>
      </header>

      <div ref={listRef} className="flex-1 space-y-2 overflow-y-auto px-3 py-3">
        <div className="mx-auto flex max-w-xs items-center justify-center gap-1.5 rounded-full bg-white px-3 py-1 text-[11px] font-bold text-muted-foreground shadow-[2px_2px_0_0_#0F0F0F]">
          <Lock className="h-3 w-3" /> Messages are end-to-end encrypted
        </div>
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.mine ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[78%] rounded-2xl border-[1.5px] border-foreground px-3 py-2 shadow-[2px_2px_0_0_#0F0F0F] ${m.mine ? "bg-coral text-white" : "bg-white"}`}>
              <p className="whitespace-pre-wrap text-[14px] leading-snug">{m.body}</p>
              <p className={`mt-1 text-[10px] ${m.mine ? "text-white/80" : "text-muted-foreground"}`}>{m.time}</p>
            </div>
          </div>
        ))}
      </div>

      <Composer
        onSend={onSend}
        onFile={(f) => toast.success(`Attached ${f.name}`)}
        placeholder={`Message ${conv.name.split(" ")[0]}`}
      />
    </section>
  );
}

function NewMessageDialog({
  currentUserId,
  onClose,
  onOpen,
}: {
  currentUserId: string;
  onClose: () => void;
  onOpen: (conversationId: string) => void;
}) {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(false);
  const [openingId, setOpeningId] = useState<string | null>(null);

  useEffect(() => {
    const term = q.trim();
    const timer = window.setTimeout(async () => {
      if (!term) { setResults([]); return; }
      setLoading(true);
      const safeTerm = term.replaceAll(",", " ");
      const { data, error } = await supabase
        .from("profiles")
        .select("id, display_name, avatar_url, username")
        .or(`display_name.ilike.%${safeTerm}%,username.ilike.%${safeTerm}%`)
        .neq("id", currentUserId)
        .limit(12);
      if (error) toast.error("Could not search builders");
      setResults(data ?? []);
      setLoading(false);
    }, 250);
    return () => window.clearTimeout(timer);
  }, [q, currentUserId]);

  const open = async (profile: Profile) => {
    setOpeningId(profile.id);
    const { data, error } = await supabase.rpc("get_or_create_conversation", { _other: profile.id });
    setOpeningId(null);
    if (error || !data) { toast.error(error?.message || "Could not start conversation"); return; }
    onOpen(data);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] grid place-items-center bg-black/60 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-xl border-[1.5px] border-foreground bg-card p-5 shadow-[6px_6px_0_0_#0F0F0F]" onClick={(event) => event.stopPropagation()}>
        <h3 className="font-display text-lg font-extrabold">New message</h3>
        <input
          autoFocus
          value={q}
          onChange={(event) => setQ(event.target.value)}
          placeholder="Search builders by name or @username…"
          className="mt-3 h-10 w-full rounded-md border-[1.5px] border-foreground bg-white px-3 text-sm outline-none focus:border-coral"
        />
        <div className="mt-3 max-h-72 overflow-y-auto">
          {loading && <p className="text-xs text-muted-foreground">Searching…</p>}
          {!loading && results.length === 0 && q && <p className="text-xs text-muted-foreground">No builders found.</p>}
          {results.map((profile) => (
            <button
              key={profile.id}
              onClick={() => void open(profile)}
              className="flex w-full items-center gap-3 rounded-md border-[1.5px] border-transparent p-2 text-left hover:border-foreground hover:bg-white"
            >
              <img src={avatarFor(profile)} alt="" className="h-9 w-9 rounded-full border-[1.5px] border-foreground object-cover" />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-bold">{nameFor(profile)}</span>
                {profile.username && <span className="block truncate text-xs text-muted-foreground">@{profile.username}</span>}
              </span>
              {openingId === profile.id && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
            </button>
          ))}
        </div>
        <div className="mt-4 flex justify-end">
          <button onClick={onClose} className="rounded-md border-[1.5px] border-foreground bg-white px-3 py-2 text-xs font-bold">Cancel</button>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ message, mine }: { message: MessageRow; mine: boolean }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(message.body ?? "");
  const [saving, setSaving] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => setDraft(message.body ?? ""), [message.body]);
  useEffect(() => {
    if (!menuOpen) return;
    const onDoc = (e: MouseEvent) => { if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [menuOpen]);

  const withinEditWindow = Date.now() - new Date(message.created_at).getTime() < 15 * 60 * 1000;

  const saveEdit = async () => {
    if (!draft.trim()) { toast.error("Message can't be empty"); return; }
    setSaving(true);
    const { error } = await supabase.from("messages").update({ body: draft.trim() }).eq("id", message.id);
    setSaving(false);
    if (error) { toast.error(error.message || "Couldn't edit (15 min window)"); return; }
    setEditing(false);
    toast.success("Message updated");
  };

  const doDelete = async () => {
    const { error } = await supabase.from("messages").delete().eq("id", message.id);
    if (error) { toast.error(error.message || "Couldn't delete"); return; }
    setConfirmDel(false);
    toast.success("Message deleted");
  };

  return (
    <div className={`group/msg flex items-end gap-1 ${mine ? "justify-end" : "justify-start"}`}>
      {mine && !editing && (
        <div ref={menuRef} className="relative opacity-0 transition group-hover/msg:opacity-100">
          <button
            type="button"
            onClick={() => setMenuOpen((o) => !o)}
            aria-label="Message options"
            className="grid h-7 w-7 place-items-center rounded-full text-muted-foreground hover:bg-surface hover:text-foreground"
          >
            <MoreVertical className="h-3.5 w-3.5" />
          </button>
          {menuOpen && (
            <div className="absolute bottom-8 right-0 z-20 w-36 overflow-hidden rounded-xl border-[1.5px] border-foreground bg-white text-sm shadow-[3px_3px_0_0_#0F0F0F]">
              {withinEditWindow && message.body && (
                <button
                  onClick={() => { setMenuOpen(false); setEditing(true); }}
                  className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs font-bold hover:bg-surface"
                >
                  <Pencil className="h-3.5 w-3.5" /> Edit
                </button>
              )}
              <button
                onClick={() => { setMenuOpen(false); setConfirmDel(true); }}
                className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs font-bold text-error hover:bg-error/10"
              >
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </button>
            </div>
          )}
        </div>
      )}
      <div className={`max-w-[78%] rounded-2xl border-[1.5px] border-foreground px-3 py-2 shadow-[2px_2px_0_0_#0F0F0F] ${mine ? "bg-coral text-white" : "bg-white"}`}>
        {editing ? (
          <div>
            <textarea
              autoFocus
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              rows={2}
              className="w-full resize-none rounded-md border border-white/40 bg-white/10 px-2 py-1 text-[13px] text-white placeholder:text-white/60 focus:outline-none"
            />
            <div className="mt-1.5 flex items-center justify-end gap-1.5">
              <button onClick={() => { setEditing(false); setDraft(message.body ?? ""); }} className="rounded-full bg-white/20 px-2 py-0.5 text-[10px] font-bold text-white">Cancel</button>
              <button onClick={saveEdit} disabled={saving} className="inline-flex items-center gap-1 rounded-full bg-white px-2.5 py-0.5 text-[10px] font-bold text-coral disabled:opacity-60">
                {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />} Save
              </button>
            </div>
          </div>
        ) : confirmDel ? (
          <div>
            <p className="text-[13px] font-semibold">Delete this message?</p>
            <div className="mt-1.5 flex items-center justify-end gap-1.5">
              <button onClick={() => setConfirmDel(false)} className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${mine ? "bg-white/20 text-white" : "border border-foreground/20 bg-white"}`}>Cancel</button>
              <button onClick={doDelete} className="rounded-full bg-white px-2.5 py-0.5 text-[10px] font-bold text-error">Delete</button>
            </div>
          </div>
        ) : (
          <>
            {message.body && <p className="whitespace-pre-wrap text-[14px] leading-snug">{message.body}</p>}
            <AttachmentPreview url={message.attachment_url ?? ""} type={message.attachment_type} name={message.attachment_name} />
            <p className={`mt-1 flex items-center gap-1 text-[10px] ${mine ? "text-white/80" : "text-muted-foreground"}`}>
              {new Date(message.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              {message.edited_at && <span>· edited</span>}
            </p>
          </>
        )}
      </div>
    </div>
  );
}
