import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Coins, Rocket, Star, Sparkles, Wallet, Check, Loader2 } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { useAuth } from "@/hooks/useAuth";
import { useXpProfile, awardCoins } from "@/hooks/useXpProfile";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/rewards")({
  head: () => ({ meta: [{ title: "Rewards · VibeCode" }] }),
  component: RewardsPage,
});

const COIN_TO_INR = 10; // 500 coins = ₹50

type Redemption = { id: string; amount_coins: number; amount_inr: number; upi_id: string; status: string; requested_at: string; paid_at: string | null };
type ProjectLite = { id: string; title: string; featured_until: string | null };

function RewardsPage() {
  const { user } = useAuth();
  const { profile: xp, refresh } = useXpProfile();
  const [redemptions, setRedemptions] = useState<Redemption[]>([]);
  const [projects, setProjects] = useState<ProjectLite[]>([]);
  const [openModal, setOpenModal] = useState<null | "withdraw" | "boost" | "feature" | "templates">(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [{ data: r }, { data: p }] = await Promise.all([
        supabase.from("vibecoin_redemptions").select("id,amount_coins,amount_inr,upi_id,status,requested_at,paid_at").eq("profile_id", user.id).order("requested_at", { ascending: false }),
        supabase.from("projects").select("id,title,featured_until").eq("builder_id", user.id).order("created_at", { ascending: false }),
      ]);
      setRedemptions((r as any) ?? []);
      setProjects((p as any) ?? []);
    })();
  }, [user, xp?.vibecoin_balance]);

  const balance = xp?.vibecoin_balance ?? 0;

  return (
    <Shell>
      <div className="container-page py-6 sm:py-10">
        <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Rewards</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold sm:text-4xl">Spend your VibeCoins</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">Earn coins by shipping projects, joining daily challenges and referring builders. Cash out to UPI or spend inside the platform.</p>

        <div className="mt-6 card-editorial flex flex-col items-start justify-between gap-3 p-6 sm:flex-row sm:items-center">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Your balance</div>
            <div className="mt-1 flex items-baseline gap-2">
              <div className="font-display text-4xl font-extrabold tabular-nums">{balance.toLocaleString()}</div>
              <div className="text-lg font-extrabold">🪙</div>
              <div className="ml-2 text-sm text-muted-foreground">≈ ₹{Math.floor(balance / COIN_TO_INR).toLocaleString()}</div>
            </div>
          </div>
          <div className="text-xs text-muted-foreground">Rate: <span className="font-bold text-foreground">500 coins = ₹50</span> · Min withdrawal 500 coins</div>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <RewardCard
            icon={<Wallet className="h-5 w-5" />}
            title="Withdraw to UPI"
            cost="500+ coins"
            desc="Direct UPI transfer processed within 48h."
            action={() => setOpenModal("withdraw")}
            disabled={balance < 500}
          />
          <RewardCard
            icon={<Rocket className="h-5 w-5" />}
            title="Boost my profile"
            cost="200 coins"
            desc="Appear at top of Explore for 7 days."
            action={() => setOpenModal("boost")}
            disabled={balance < 200}
          />
          <RewardCard
            icon={<Star className="h-5 w-5" />}
            title="Feature my project"
            cost="300 coins"
            desc="Land in Trending for 48 hours."
            action={() => setOpenModal("feature")}
            disabled={balance < 300 || projects.length === 0}
          />
          <RewardCard
            icon={<Sparkles className="h-5 w-5" />}
            title="Premium templates"
            cost="150 coins"
            desc="Unlock premium prompt & workflow packs."
            action={() => setOpenModal("templates")}
            disabled={balance < 150}
          />
        </div>

        <h2 className="mt-10 font-display text-xl font-extrabold">Your withdrawal history</h2>
        <div className="mt-3 space-y-2">
          {redemptions.length === 0 && (
            <div className="card-editorial p-6 text-center text-sm text-muted-foreground">No withdrawal requests yet.</div>
          )}
          {redemptions.map((r) => (
            <div key={r.id} className="card-editorial flex flex-wrap items-center justify-between gap-3 p-4">
              <div className="min-w-0">
                <div className="font-bold">₹{r.amount_inr.toLocaleString()} <span className="text-xs text-muted-foreground">({r.amount_coins} coins)</span></div>
                <div className="truncate text-xs text-muted-foreground">to {r.upi_id} · requested {new Date(r.requested_at).toLocaleDateString()}</div>
              </div>
              <StatusChip status={r.status} />
            </div>
          ))}
        </div>

        <p className="mt-8 text-xs text-muted-foreground"><Link to="/leaderboard" className="font-bold hover:underline">See leaderboard →</Link></p>
      </div>

      {openModal === "withdraw" && <WithdrawModal balance={balance} onClose={() => { setOpenModal(null); refresh(); }} />}
      {openModal === "boost" && <ConfirmModal
        title="Boost your profile"
        desc="Spend 200 coins to appear at the top of Explore for 7 days."
        cost={200}
        balance={balance}
        onConfirm={async () => {
          if (!user) return;
          await awardCoins("spent", 200, "Profile boost 7 days");
          const until = new Date(); until.setDate(until.getDate() + 7);
          await supabase.from("profiles").update({ boosted_until: until.toISOString() }).eq("id", user.id);
          toast.success("Profile boosted for 7 days 🚀");
        }}
        onClose={() => { setOpenModal(null); refresh(); }}
      />}
      {openModal === "feature" && <FeatureProjectModal
        balance={balance}
        projects={projects}
        onClose={() => { setOpenModal(null); refresh(); }}
      />}
      {openModal === "templates" && <ConfirmModal
        title="Unlock premium templates"
        desc="Spend 150 coins for lifetime access to premium prompt & workflow packs."
        cost={150}
        balance={balance}
        onConfirm={async () => {
          await awardCoins("spent", 150, "Premium templates unlock");
          toast.success("Premium templates unlocked ✨");
        }}
        onClose={() => { setOpenModal(null); refresh(); }}
      />}
    </Shell>
  );
}

function StatusChip({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "bg-white text-foreground",
    approved: "bg-gold text-foreground",
    paid: "bg-emerald-100 text-emerald-800",
    rejected: "bg-rose-100 text-rose-800",
  };
  return <span className={`rounded-full border-[1.5px] border-[#0F0F0F] px-2.5 py-0.5 text-xs font-extrabold ${map[status] ?? "bg-white"}`}>{status}</span>;
}

function RewardCard({ icon, title, cost, desc, action, disabled }: { icon: React.ReactNode; title: string; cost: string; desc: string; action: () => void; disabled?: boolean }) {
  return (
    <div className="card-editorial flex flex-col p-5">
      <div className="flex items-center gap-2 text-coral">{icon}<span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{cost}</span></div>
      <div className="mt-2 font-display text-lg font-extrabold">{title}</div>
      <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
      <button
        onClick={action}
        disabled={disabled}
        className="btn-coral mt-4 h-9 text-xs disabled:cursor-not-allowed disabled:opacity-50"
      >
        {disabled ? "Not enough coins" : "Redeem"}
      </button>
    </div>
  );
}

function ModalShell({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-t-2xl border-[1.5px] border-[#0F0F0F] bg-cream p-5 sm:rounded-2xl" style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <div className="font-display text-lg font-extrabold">{title}</div>
          <button onClick={onClose} className="text-sm font-bold text-muted-foreground hover:text-foreground">Close</button>
        </div>
        <div className="mt-4">{children}</div>
      </div>
    </div>
  );
}

function WithdrawModal({ balance, onClose }: { balance: number; onClose: () => void }) {
  const { user } = useAuth();
  const [amount, setAmount] = useState(500);
  const [upi, setUpi] = useState("");
  const [loading, setLoading] = useState(false);
  const inr = Math.floor(amount / COIN_TO_INR);
  const canSubmit = amount >= 500 && amount <= balance && /^[\w.-]+@[\w.-]+$/.test(upi);

  const submit = async () => {
    if (!user || !canSubmit) return;
    setLoading(true);
    try {
      await awardCoins("redeemed", amount, `UPI withdrawal to ${upi}`);
      const { error } = await supabase.from("vibecoin_redemptions").insert({
        profile_id: user.id, amount_coins: amount, amount_inr: inr, upi_id: upi,
      });
      if (error) throw error;
      toast.success("Withdrawal request submitted. We'll pay within 48h.");
      onClose();
    } catch (e: any) {
      toast.error(e.message ?? "Failed to submit");
    } finally { setLoading(false); }
  };

  return (
    <ModalShell title="Withdraw to UPI" onClose={onClose}>
      <label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">Coins to withdraw</label>
      <input
        type="number" min={500} max={balance} step={100} value={amount}
        onChange={(e) => setAmount(Math.min(balance, Math.max(500, parseInt(e.target.value || "500"))))}
        className="mt-1 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 font-bold"
      />
      <div className="mt-1 text-xs text-muted-foreground">You'll receive <span className="font-bold text-foreground">₹{inr.toLocaleString()}</span> · Balance {balance.toLocaleString()} 🪙</div>

      <label className="mt-4 block text-xs font-extrabold uppercase tracking-wider text-muted-foreground">Your UPI ID</label>
      <input
        placeholder="you@upi"
        value={upi}
        onChange={(e) => setUpi(e.target.value.trim())}
        className="mt-1 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 font-bold"
      />

      <button onClick={submit} disabled={!canSubmit || loading} className="btn-coral mt-5 h-10 w-full text-sm disabled:opacity-50">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
        Request withdrawal
      </button>
      <p className="mt-2 text-[11px] text-muted-foreground">Processed manually by our team within 48h. You'll get a notification when it's paid.</p>
    </ModalShell>
  );
}

function ConfirmModal({ title, desc, cost, balance, onConfirm, onClose }: { title: string; desc: string; cost: number; balance: number; onConfirm: () => Promise<void>; onClose: () => void }) {
  const [loading, setLoading] = useState(false);
  const submit = async () => {
    setLoading(true);
    try { await onConfirm(); onClose(); } catch (e: any) { toast.error(e.message ?? "Failed"); }
    finally { setLoading(false); }
  };
  return (
    <ModalShell title={title} onClose={onClose}>
      <p className="text-sm text-muted-foreground">{desc}</p>
      <div className="mt-3 rounded-md border-[1.5px] border-[#0F0F0F] bg-white p-3 text-sm font-bold">
        Cost: <span className="text-coral">{cost} 🪙</span> · New balance: {(balance - cost).toLocaleString()} 🪙
      </div>
      <button onClick={submit} disabled={loading} className="btn-coral mt-4 h-10 w-full text-sm">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Coins className="h-4 w-4" />} Confirm & spend
      </button>
    </ModalShell>
  );
}

function FeatureProjectModal({ balance, projects, onClose }: { balance: number; projects: ProjectLite[]; onClose: () => void }) {
  const [pid, setPid] = useState(projects[0]?.id ?? "");
  const [loading, setLoading] = useState(false);
  const submit = async () => {
    if (!pid) return;
    setLoading(true);
    try {
      await awardCoins("spent", 300, "Feature project 48h", pid);
      const until = new Date(); until.setHours(until.getHours() + 48);
      await supabase.from("projects").update({ featured_until: until.toISOString() }).eq("id", pid);
      toast.success("Project featured for 48 hours ⭐");
      onClose();
    } catch (e: any) { toast.error(e.message ?? "Failed"); }
    finally { setLoading(false); }
  };
  return (
    <ModalShell title="Feature a project" onClose={onClose}>
      <label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">Choose a project</label>
      <select value={pid} onChange={(e) => setPid(e.target.value)} className="mt-1 w-full rounded-md border-[1.5px] border-[#0F0F0F] bg-white px-3 py-2 font-bold">
        {projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
      </select>
      <div className="mt-3 rounded-md border-[1.5px] border-[#0F0F0F] bg-white p-3 text-sm font-bold">
        Cost: <span className="text-coral">300 🪙</span> · New balance: {(balance - 300).toLocaleString()} 🪙
      </div>
      <button onClick={submit} disabled={loading || !pid} className="btn-coral mt-4 h-10 w-full text-sm">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Star className="h-4 w-4" />} Feature for 48h
      </button>
    </ModalShell>
  );
}
