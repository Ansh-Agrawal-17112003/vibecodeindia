import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Eye, TrendingUp, Search as SearchIcon, Users, Lock, Flame, MessageCircle,
  Heart, Repeat2, Briefcase, Building2, MapPin, Award, Clock, Sparkles,
} from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer,
  XAxis, YAxis, Tooltip, CartesianGrid,
} from "recharts";
import { Shell } from "@/components/site/Shell";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { useXpProfile } from "@/hooks/useXpProfile";
import { useCompanyPlan } from "@/hooks/useCompanyPlan";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchOverview, fetchViewers, fetchContent, fetchHiring,
  type OverviewAnalytics, type ViewerBreakdown, type ContentAnalytics, type HiringAnalytics,
} from "@/lib/analytics-api";

export const Route = createFileRoute("/_authenticated/analytics")({
  head: () => ({ meta: [{ title: "Profile Analytics · VibeCode" }] }),
  component: AnalyticsPage,
});

const CORAL = "#FF5A3C";
const GOLD = "#F5B301";
const NAVY = "#0F0F0F";
const PALETTE = [CORAL, GOLD, "#4C6EF5", "#12B886", "#845EF7", "#F783AC", "#20C997", "#FF922B"];

const DAYS_OPTIONS = [7, 30, 90] as const;
const DAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function AnalyticsPage() {
  const { user } = useAuth();
  const { profile: xp } = useXpProfile();
  const { company, isHiringUltra } = useCompanyPlan();

  const [plan, setPlan] = useState<string>("free");
  const isPro = plan === "pro" || plan === "og_pro";
  const isOG = plan === "og_pro";

  const [days, setDays] = useState<number>(30);
  const [overview, setOverview] = useState<OverviewAnalytics | null>(null);
  const [viewers, setViewers] = useState<ViewerBreakdown | null>(null);
  const [content, setContent] = useState<ContentAnalytics | null>(null);
  const [hiring, setHiring] = useState<HiringAnalytics | null>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await (supabase.from("profiles") as any)
        .select("subscription_plan")
        .eq("id", user.id)
        .maybeSingle();
      setPlan((data?.subscription_plan as string) ?? "free");
    })();
  }, [user?.id]);

  useEffect(() => {
    if (!user) return;
    void fetchOverview(user.id, days).then(setOverview);
    if (isPro) {
      void fetchViewers(user.id, days).then(setViewers);
      void fetchContent(user.id, days).then(setContent);
    }
    if (isHiringUltra && company) {
      void fetchHiring(company.id, days).then(setHiring);
    }
  }, [user?.id, days, isPro, isHiringUltra, company?.id]);

  return (
    <Shell>
      <div className="container-page py-6 sm:py-8">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Analytics</div>
            <h1 className="mt-1 font-display text-2xl font-extrabold sm:text-3xl">Profile analytics</h1>
            <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
              <TierPill plan={plan} isHiringUltra={isHiringUltra} />
              <span>· Last {days} days</span>
            </div>
          </div>
          <div className="flex gap-1 rounded-md border-[1.5px] border-[#0F0F0F] bg-white p-1 shadow-[2px_2px_0_0_#0F0F0F]">
            {DAYS_OPTIONS.map((d) => (
              <button
                key={d}
                onClick={() => setDays(d)}
                className={`rounded px-3 py-1 text-xs font-bold transition ${
                  days === d ? "bg-coral text-white" : "text-foreground/70 hover:bg-muted"
                }`}
              >
                {d}d
              </button>
            ))}
          </div>
        </div>

        {/* Existing top stat row — untouched shape */}
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat icon={<Eye className="h-4 w-4" />} label="Profile views" value={overview?.total_views_all_time ?? 0} sub="All time" />
          <Stat
            icon={<TrendingUp className="h-4 w-4" />}
            label={`Views (${days}d)`}
            value={overview?.views_window ?? 0}
            sub={overview?.views_growth_pct != null ? `${overview.views_growth_pct > 0 ? "+" : ""}${overview.views_growth_pct}% vs prev` : "Last window"}
          />
          <Stat icon={<SearchIcon className="h-4 w-4" />} label="Search appearances" value={overview?.search_appearances ?? 0} sub={`Last ${days}d`} locked={!isPro} />
          <Stat icon={<Users className="h-4 w-4" />} label="Followers" value={overview?.followers ?? 0} sub={`+${overview?.new_followers ?? 0} new`} />
        </div>

        {/* Free-tier extra basic row */}
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat icon={<MessageCircle className="h-4 w-4" />} label="Comments received" value={overview?.comments_received ?? 0} sub={`Last ${days}d`} />
          <Stat icon={<Heart className="h-4 w-4" />} label="Likes received" value={overview?.likes_received ?? 0} sub={`Last ${days}d`} />
          <Stat icon={<Sparkles className="h-4 w-4" />} label="Posts published" value={overview?.posts ?? 0} sub={`Last ${days}d`} />
          <Stat icon={<TrendingUp className="h-4 w-4" />} label="Engagement rate" value={overview?.engagement_rate ?? 0} sub="Likes+comments / views" suffix="%" />
        </div>

        {/* Tabs */}
        <div className="mt-8">
          <Tabs defaultValue="overview">
            <TabsList className="flex w-full flex-wrap justify-start gap-1 rounded-lg border-[1.5px] border-[#0F0F0F] bg-white p-1 shadow-[2px_2px_0_0_#0F0F0F]">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="audience">Audience</TabsTrigger>
              <TabsTrigger value="content">Content</TabsTrigger>
              <TabsTrigger value="discovery">Discovery</TabsTrigger>
              <TabsTrigger value="growth">Growth</TabsTrigger>
              {isHiringUltra && <TabsTrigger value="hiring">Hiring · Ultra</TabsTrigger>}
            </TabsList>

            <TabsContent value="overview" className="mt-5">
              <OverviewTab data={overview} days={days} />
            </TabsContent>
            <TabsContent value="audience" className="mt-5">
              <LockedIf locked={!isPro} title="Unlock audience insights">
                <AudienceTab data={viewers} />
              </LockedIf>
            </TabsContent>
            <TabsContent value="content" className="mt-5">
              <LockedIf locked={!isPro} title="Unlock content analytics">
                <ContentTab data={content} />
              </LockedIf>
            </TabsContent>
            <TabsContent value="discovery" className="mt-5">
              <LockedIf locked={!isPro} title="Unlock discovery metrics">
                <DiscoveryTab overview={overview} />
              </LockedIf>
            </TabsContent>
            <TabsContent value="growth" className="mt-5">
              <LockedIf locked={!isPro} title="Unlock growth analytics">
                <GrowthTab xp={xp} overview={overview} />
              </LockedIf>
            </TabsContent>
            {isHiringUltra && (
              <TabsContent value="hiring" className="mt-5">
                <HiringTab data={hiring} />
              </TabsContent>
            )}
          </Tabs>
        </div>

        {!isPro && (
          <div className="card-editorial mt-6 border-2 border-coral p-6 text-center">
            <div className="text-2xl">📊</div>
            <h3 className="mt-2 font-display text-lg font-extrabold">Unlock full analytics</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Audience insights, content performance, best time to post, discovery ranking & more.
            </p>
            <Link to="/pricing" className="btn-coral mt-4 inline-flex h-10 items-center px-6 text-sm">
              Upgrade to Pro →
            </Link>
          </div>
        )}

        {isPro && !isHiringUltra && company && (
          <div className="card-editorial mt-6 border-2 border-gold p-6 text-center">
            <div className="text-2xl">🏢</div>
            <h3 className="mt-2 font-display text-lg font-extrabold">Hiring Ultra for {company.name}</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Unlock the hiring funnel, applicant intelligence & employer-brand analytics.
              <span className="ml-1 font-bold text-foreground">₹2,999/month</span>
            </p>
            <Link to="/pricing" className="btn-coral mt-4 inline-flex h-10 items-center px-6 text-sm">
              Upgrade company plan →
            </Link>
          </div>
        )}
      </div>
    </Shell>
  );
}

/* ---------------- Tabs ---------------- */

function OverviewTab({ data, days }: { data: OverviewAnalytics | null; days: number }) {
  const trend = (data?.daily_trend ?? []).map((r) => ({ day: r.day.slice(5), views: r.views }));
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="Profile views trend" className="lg:col-span-2">
        <div className="h-64">
          <ResponsiveContainer>
            <LineChart data={trend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e6e6e6" />
              <XAxis dataKey="day" stroke="#666" fontSize={11} />
              <YAxis stroke="#666" fontSize={11} allowDecimals={false} />
              <Tooltip contentStyle={{ border: "1.5px solid #0F0F0F", borderRadius: 8 }} />
              <Line type="monotone" dataKey="views" stroke={CORAL} strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Engagement summary">
        <MiniRow label="Views" value={data?.views_window ?? 0} sub={`Last ${days}d`} />
        <MiniRow label="Likes" value={data?.likes_received ?? 0} />
        <MiniRow label="Comments" value={data?.comments_received ?? 0} />
        <MiniRow label="New followers" value={data?.new_followers ?? 0} />
        <MiniRow label="Engagement rate" value={`${data?.engagement_rate ?? 0}%`} />
      </Card>
    </div>
  );
}

function AudienceTab({ data }: { data: ViewerBreakdown | null }) {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card title="Viewers by title/role">
        <BarList items={data?.by_title ?? []} color={CORAL} />
      </Card>
      <Card title="Viewers by location">
        <BarList items={data?.by_location ?? []} color={GOLD} />
      </Card>
      <Card title="Top viewers" className="lg:col-span-2">
        <div className="divide-y">
          {(data?.top_viewers ?? []).length === 0 && <EmptyLine text="No named viewers yet." />}
          {(data?.top_viewers ?? []).map((v) => (
            <Link
              key={v.id}
              to="/u/$username"
              params={{ username: v.username ?? v.id }}
              className="flex items-center justify-between py-2.5 hover:bg-muted/30"
            >
              <div className="flex items-center gap-3 min-w-0">
                {v.avatar_url ? (
                  <img src={v.avatar_url} alt="" className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F] object-cover" />
                ) : (
                  <div className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F] bg-muted" />
                )}
                <div className="min-w-0">
                  <div className="truncate font-bold text-sm">{v.display_name ?? "Someone"}</div>
                  <div className="truncate text-xs text-muted-foreground">{v.title ?? "Builder"} · @{v.username ?? "—"}</div>
                </div>
              </div>
              <span className="shrink-0 rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-2.5 py-0.5 text-xs font-bold">
                {v.view_count} view{v.view_count > 1 ? "s" : ""}
              </span>
            </Link>
          ))}
        </div>
      </Card>
      <Card title="Repeat viewers">
        <div className="flex items-baseline gap-2">
          <div className="font-display text-4xl font-extrabold tabular-nums">{data?.repeat_viewers ?? 0}</div>
          <div className="text-xs font-bold text-muted-foreground">people viewed you more than once</div>
        </div>
      </Card>
    </div>
  );
}

function ContentTab({ data }: { data: ContentAnalytics | null }) {
  const reactionMix = data
    ? Object.entries(data.reaction_mix).map(([k, v]) => ({ name: k, value: v as number }))
    : [];
  const mediaVsText = data
    ? [
        { name: "Media", value: data.media_vs_text.media, count: data.media_vs_text.media_count },
        { name: "Text", value: data.media_vs_text.text, count: data.media_vs_text.text_count },
      ]
    : [];

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card title="Reaction mix">
        <div className="h-56">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={reactionMix} dataKey="value" nameKey="name" innerRadius={40} outerRadius={80} paddingAngle={2}>
                {reactionMix.map((_, i) => (
                  <Cell key={i} fill={PALETTE[i % PALETTE.length]} stroke={NAVY} strokeWidth={1.5} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Media vs Text engagement">
        <div className="h-56">
          <ResponsiveContainer>
            <BarChart data={mediaVsText}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e6e6e6" />
              <XAxis dataKey="name" fontSize={11} stroke="#666" />
              <YAxis fontSize={11} stroke="#666" />
              <Tooltip />
              <Bar dataKey="value" fill={CORAL} stroke={NAVY} strokeWidth={1.5} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card title="Best time to post" className="lg:col-span-2">
        <Heatmap heatmap={data?.best_time_heatmap ?? []} />
      </Card>

      <Card title="Post performance" className="lg:col-span-2">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                <th className="py-2 pr-3">Post</th>
                <th className="py-2 pr-3">Likes</th>
                <th className="py-2 pr-3">Comments</th>
                <th className="py-2 pr-3">Reposts</th>
                <th className="py-2 pr-3">Score</th>
                <th className="py-2 pr-3">Posted</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {(data?.posts ?? []).length === 0 && (
                <tr><td colSpan={6} className="py-6 text-center text-muted-foreground">No posts yet in this window.</td></tr>
              )}
              {(data?.posts ?? []).slice(0, 10).map((p) => (
                <tr key={p.id}>
                  <td className="py-2 pr-3 max-w-xs truncate">{p.excerpt || `(${p.kind})`}</td>
                  <td className="py-2 pr-3 tabular-nums">{p.like_count}</td>
                  <td className="py-2 pr-3 tabular-nums">{p.comment_count}</td>
                  <td className="py-2 pr-3 tabular-nums">{p.repost_count}</td>
                  <td className="py-2 pr-3 tabular-nums font-bold">{Math.round(p.score)}</td>
                  <td className="py-2 pr-3 text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function DiscoveryTab({ overview }: { overview: OverviewAnalytics | null }) {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="Search appearances">
        <div className="flex items-baseline gap-2">
          <div className="font-display text-4xl font-extrabold tabular-nums">{overview?.search_appearances ?? 0}</div>
          <div className="text-xs font-bold text-muted-foreground">times you appeared</div>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">Boost your profile or complete your bio to appear more often.</p>
      </Card>
      <Card title="Followers vs following">
        <MiniRow label="Followers" value={overview?.followers ?? 0} />
        <MiniRow label="Following" value={overview?.following ?? 0} />
        <MiniRow
          label="Ratio"
          value={
            overview && overview.following > 0
              ? (overview.followers / overview.following).toFixed(2)
              : "—"
          }
        />
      </Card>
      <Card title="Profile completeness">
        <CompletenessRing overview={overview} />
      </Card>
    </div>
  );
}

function GrowthTab({ xp, overview }: { xp: any; overview: OverviewAnalytics | null }) {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="XP & level">
        <MiniRow label="Total XP" value={(xp?.total_xp ?? 0).toLocaleString()} />
        <MiniRow label="Level" value={xp?.current_level ?? "Newcomer"} />
        <MiniRow label="Streak" value={`${xp?.login_streak ?? 0} days 🔥`} />
      </Card>
      <Card title="VibeCoin balance">
        <div className="flex items-baseline gap-2">
          <div className="font-display text-4xl font-extrabold tabular-nums">{(xp?.vibecoin_balance ?? 0).toLocaleString()}</div>
          <div className="text-xs font-bold text-muted-foreground">🪙</div>
        </div>
        <Link to="/rewards" className="btn-coral mt-3 h-9 w-full text-xs">Open rewards</Link>
      </Card>
      <Card title="Follower growth">
        <div className="flex items-baseline gap-2">
          <div className="font-display text-4xl font-extrabold tabular-nums">+{overview?.new_followers ?? 0}</div>
          <div className="text-xs font-bold text-muted-foreground">this window</div>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          Total {overview?.followers ?? 0} followers overall.
        </p>
      </Card>
    </div>
  );
}

function HiringTab({ data }: { data: HiringAnalytics | null }) {
  const funnel = data ? Object.entries(data.by_status).map(([k, v]) => ({ name: k, value: v })) : [];
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="Active jobs" >
        <div className="flex items-baseline gap-2">
          <div className="font-display text-4xl font-extrabold tabular-nums">{data?.jobs_active ?? 0}</div>
          <div className="text-xs font-bold text-muted-foreground">/ {data?.jobs_closed ?? 0} closed</div>
        </div>
      </Card>
      <Card title="Applications">
        <MiniRow label="Total" value={data?.applications_total ?? 0} />
        <MiniRow label="Pro applicants" value={data?.applications_pro ?? 0} />
        <MiniRow label="Free applicants" value={data?.applications_free ?? 0} />
      </Card>
      <Card title="Response speed">
        <MiniRow label="Avg hours to 1st apply" value={data ? data.avg_hours_to_first_app.toFixed(1) : "—"} />
        <MiniRow label="Avg applicant XP" value={data ? Math.round(data.avg_applicant_xp).toLocaleString() : "—"} />
      </Card>

      <Card title="Application funnel" className="lg:col-span-2">
        <div className="h-56">
          <ResponsiveContainer>
            <BarChart data={funnel} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e6e6e6" />
              <XAxis type="number" fontSize={11} stroke="#666" />
              <YAxis type="category" dataKey="name" fontSize={11} stroke="#666" width={100} />
              <Tooltip />
              <Bar dataKey="value" fill={GOLD} stroke={NAVY} strokeWidth={1.5} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Applicant seniority">
        <BarList items={data?.by_seniority ?? []} color="#4C6EF5" />
      </Card>

      <Card title="Top skills across applicants" className="lg:col-span-2">
        <div className="flex flex-wrap gap-2">
          {(data?.top_skills ?? []).length === 0 && <EmptyLine text="No skills data yet." />}
          {(data?.top_skills ?? []).map((s) => (
            <span
              key={s.label}
              className="rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-3 py-1 text-xs font-bold shadow-[1px_1px_0_0_#0F0F0F]"
              style={{ fontSize: 11 + Math.min(6, s.n / 2) }}
            >
              {s.label} · {s.n}
            </span>
          ))}
        </div>
      </Card>
      <Card title="Applicant locations">
        <BarList items={data?.by_location ?? []} color="#12B886" />
      </Card>

      <Card title="Job-post performance" className="lg:col-span-3">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                <th className="py-2 pr-3">Job</th>
                <th className="py-2 pr-3">Status</th>
                <th className="py-2 pr-3">Applications</th>
                <th className="py-2 pr-3">Saves</th>
                <th className="py-2 pr-3">Posted</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {(data?.jobs ?? []).length === 0 && (
                <tr><td colSpan={5} className="py-6 text-center text-muted-foreground">No jobs posted yet.</td></tr>
              )}
              {(data?.jobs ?? []).map((j) => (
                <tr key={j.id}>
                  <td className="py-2 pr-3">
                    <Link to="/jobs/$id" params={{ id: j.id }} className="font-bold hover:underline">{j.title}</Link>
                  </td>
                  <td className="py-2 pr-3"><span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-2 py-0.5 text-xs font-bold">{j.status}</span></td>
                  <td className="py-2 pr-3 tabular-nums">{j.applications}</td>
                  <td className="py-2 pr-3 tabular-nums">{j.saves}</td>
                  <td className="py-2 pr-3 text-xs text-muted-foreground">{new Date(j.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ---------------- Primitives ---------------- */

function TierPill({ plan, isHiringUltra }: { plan: string; isHiringUltra: boolean }) {
  if (isHiringUltra)
    return <span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-gold px-2.5 py-0.5 text-xs font-extrabold shadow-[1px_1px_0_0_#0F0F0F]">🏢 Ultra Hiring</span>;
  if (plan === "og_pro")
    return <span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-coral px-2.5 py-0.5 text-xs font-extrabold text-white shadow-[1px_1px_0_0_#0F0F0F]">✨ OG Pro</span>;
  if (plan === "pro")
    return <span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-2.5 py-0.5 text-xs font-extrabold shadow-[1px_1px_0_0_#0F0F0F]">Pro</span>;
  return <span className="rounded-full border-[1.5px] border-[#0F0F0F] bg-white px-2.5 py-0.5 text-xs font-extrabold shadow-[1px_1px_0_0_#0F0F0F]">Free</span>;
}

function Card({ title, children, className = "" }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`card-editorial p-5 ${className}`}>
      <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">{title}</h3>
      {children}
    </div>
  );
}

function Stat({
  icon, label, value, sub, locked = false, suffix = "",
}: { icon: React.ReactNode; label: string; value: number | string; sub: string; locked?: boolean; suffix?: string }) {
  return (
    <div className="card-editorial relative overflow-hidden p-4">
      {locked && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/80 backdrop-blur-[2px]">
          <Lock className="h-5 w-5 text-muted-foreground" />
        </div>
      )}
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        {icon} {label}
      </div>
      <div className="mt-2 font-display text-3xl font-extrabold tabular-nums">
        {typeof value === "number" ? value.toLocaleString("en-IN") : value}{suffix}
      </div>
      <div className="mt-1 text-[11px] text-muted-foreground">{sub}</div>
    </div>
  );
}

function MiniRow({ label, value, sub }: { label: string; value: number | string; sub?: string }) {
  return (
    <div className="flex items-baseline justify-between border-b border-dashed border-[#e6e6e6] py-2 last:border-0">
      <div>
        <div className="text-xs font-bold text-foreground/80">{label}</div>
        {sub && <div className="text-[10px] text-muted-foreground">{sub}</div>}
      </div>
      <div className="font-display text-lg font-extrabold tabular-nums">
        {typeof value === "number" ? value.toLocaleString("en-IN") : value}
      </div>
    </div>
  );
}

function BarList({ items, color }: { items: { label: string; n: number }[]; color: string }) {
  const max = Math.max(1, ...items.map((i) => i.n));
  if (items.length === 0) return <EmptyLine text="No data yet." />;
  return (
    <div className="space-y-2">
      {items.map((i) => (
        <div key={i.label}>
          <div className="mb-0.5 flex justify-between text-xs">
            <span className="truncate font-bold text-foreground/80">{i.label}</span>
            <span className="tabular-nums text-muted-foreground">{i.n}</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full border border-[#0F0F0F] bg-white">
            <div style={{ width: `${(i.n / max) * 100}%`, background: color }} className="h-full" />
          </div>
        </div>
      ))}
    </div>
  );
}

function Heatmap({ heatmap }: { heatmap: { dow: number; hour: number; posts: number; engagement: number }[] }) {
  const map: Record<string, number> = {};
  let max = 0;
  for (const cell of heatmap) {
    const v = cell.engagement || cell.posts;
    map[`${cell.dow}-${cell.hour}`] = v;
    if (v > max) max = v;
  }
  return (
    <div className="overflow-x-auto">
      <div className="min-w-[560px]">
        <div className="grid" style={{ gridTemplateColumns: "40px repeat(24, minmax(0,1fr))" }}>
          <div />
          {Array.from({ length: 24 }).map((_, h) => (
            <div key={h} className="text-center text-[9px] text-muted-foreground">{h}</div>
          ))}
          {DAY_LABELS.map((d, dow) => (
            <>
              <div key={`l-${dow}`} className="pr-1 text-right text-[10px] font-bold text-muted-foreground">{d}</div>
              {Array.from({ length: 24 }).map((_, h) => {
                const v = map[`${dow}-${h}`] ?? 0;
                const alpha = max > 0 ? v / max : 0;
                return (
                  <div
                    key={`${dow}-${h}`}
                    className="m-[1px] h-4 rounded-sm border border-[#e6e6e6]"
                    style={{ background: `rgba(255,90,60,${0.08 + alpha * 0.9})` }}
                    title={`${d} ${h}:00 — ${v} eng`}
                  />
                );
              })}
            </>
          ))}
        </div>
        <div className="mt-2 text-[10px] text-muted-foreground">Darker = higher engagement in that hour.</div>
      </div>
    </div>
  );
}

function CompletenessRing({ overview }: { overview: OverviewAnalytics | null }) {
  const score = useMemo(() => {
    let s = 20;
    if ((overview?.followers ?? 0) > 5) s += 20;
    if ((overview?.posts ?? 0) > 3) s += 20;
    if ((overview?.total_views_all_time ?? 0) > 10) s += 20;
    if ((overview?.engagement_rate ?? 0) > 5) s += 20;
    return Math.min(100, s);
  }, [overview]);
  return (
    <div className="flex items-center gap-4">
      <div className="relative h-20 w-20">
        <svg viewBox="0 0 36 36" className="h-full w-full">
          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none" stroke="#eee" strokeWidth="3" />
          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none" stroke={CORAL} strokeWidth="3" strokeDasharray={`${score}, 100`} strokeLinecap="round" />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center font-display text-xl font-extrabold">{score}%</div>
      </div>
      <div className="text-xs text-muted-foreground">
        {score < 60 ? "Complete your profile & post more to increase discovery." : "Great — your profile is discoverable."}
      </div>
    </div>
  );
}

function LockedIf({ locked, title, children }: { locked: boolean; title: string; children: React.ReactNode }) {
  if (!locked) return <>{children}</>;
  return (
    <div className="relative">
      <div className="pointer-events-none blur-sm select-none">{children}</div>
      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 rounded-lg bg-white/70 p-8 text-center backdrop-blur-sm">
        <Lock className="h-6 w-6 text-coral" />
        <div className="font-display text-lg font-extrabold">{title}</div>
        <p className="max-w-sm text-sm text-muted-foreground">Available on Pro & OG Pro plans.</p>
        <Link to="/pricing" className="btn-coral mt-2 h-9 px-5 text-xs">Upgrade to Pro</Link>
      </div>
    </div>
  );
}

function EmptyLine({ text }: { text: string }) {
  return <div className="py-6 text-center text-xs text-muted-foreground">{text}</div>;
}
