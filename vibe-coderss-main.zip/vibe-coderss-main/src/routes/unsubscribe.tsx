import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/unsubscribe")({
  component: UnsubscribePage,
});

type State =
  | { kind: "loading" }
  | { kind: "ready" }
  | { kind: "already" }
  | { kind: "invalid" }
  | { kind: "submitting" }
  | { kind: "done" }
  | { kind: "error"; message: string };

function UnsubscribePage() {
  const [state, setState] = useState<State>({ kind: "loading" });
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const t = new URLSearchParams(window.location.search).get("token");
    if (!t) return setState({ kind: "invalid" });
    setToken(t);
    fetch(`/email/unsubscribe?token=${encodeURIComponent(t)}`)
      .then(async (r) => {
        const data = await r.json().catch(() => ({}));
        if (r.ok && data.valid) return setState({ kind: "ready" });
        if (data.reason === "already_unsubscribed") return setState({ kind: "already" });
        setState({ kind: "invalid" });
      })
      .catch(() => setState({ kind: "invalid" }));
  }, []);

  const confirm = async () => {
    if (!token) return;
    setState({ kind: "submitting" });
    try {
      const r = await fetch("/email/unsubscribe", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ token }),
      });
      const data = await r.json().catch(() => ({}));
      if (r.ok && data.success) return setState({ kind: "done" });
      if (data.reason === "already_unsubscribed") return setState({ kind: "already" });
      setState({ kind: "error", message: data.error || "Something went wrong" });
    } catch (e: any) {
      setState({ kind: "error", message: e?.message || "Network error" });
    }
  };

  return (
    <main className="grid min-h-screen place-items-center bg-cream p-6">
      <div
        className="w-full max-w-md rounded-[16px] border-[1.5px] border-[#0F0F0F] bg-white p-7 text-center"
        style={{ boxShadow: "6px 6px 0 0 #0F0F0F" }}
      >
        <div className="mb-1 text-[11px] font-extrabold uppercase tracking-[0.14em] text-[#7a7266]">
          VibeCoder · Email preferences
        </div>
        {state.kind === "loading" && <p className="mt-4 text-sm text-[#4a4238]">Checking your link…</p>}

        {state.kind === "ready" && (
          <>
            <h1 className="mt-2 font-display text-2xl font-extrabold text-[#0F0F0F]">Unsubscribe?</h1>
            <p className="mt-2 text-sm text-[#4a4238]">
              You'll stop receiving all VibeCoder emails at this address. You can rejoin anytime.
            </p>
            <button
              onClick={confirm}
              className="mt-5 h-12 w-full rounded-[10px] border-[1.5px] border-[#0F0F0F] bg-[#E8623A] text-sm font-extrabold text-white"
              style={{ boxShadow: "3px 3px 0 0 #0F0F0F" }}
            >
              Confirm unsubscribe
            </button>
          </>
        )}

        {state.kind === "submitting" && <p className="mt-4 text-sm text-[#4a4238]">Unsubscribing…</p>}

        {state.kind === "done" && (
          <>
            <h1 className="mt-2 font-display text-2xl font-extrabold text-[#0F0F0F]">You're unsubscribed</h1>
            <p className="mt-2 text-sm text-[#4a4238]">We won't email you again. Sorry to see you go.</p>
          </>
        )}

        {state.kind === "already" && (
          <>
            <h1 className="mt-2 font-display text-2xl font-extrabold text-[#0F0F0F]">Already unsubscribed</h1>
            <p className="mt-2 text-sm text-[#4a4238]">This email is already off our list.</p>
          </>
        )}

        {state.kind === "invalid" && (
          <>
            <h1 className="mt-2 font-display text-2xl font-extrabold text-[#0F0F0F]">Link expired</h1>
            <p className="mt-2 text-sm text-[#4a4238]">This unsubscribe link is invalid or expired.</p>
          </>
        )}

        {state.kind === "error" && (
          <>
            <h1 className="mt-2 font-display text-2xl font-extrabold text-[#0F0F0F]">Something went wrong</h1>
            <p className="mt-2 text-sm text-[#4a4238]">{state.message}</p>
          </>
        )}
      </div>
    </main>
  );
}
