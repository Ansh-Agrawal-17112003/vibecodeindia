import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/learn/certifications")({
  head: () => ({
    meta: [
      { title: "Certifications · VibeCode" },
      { name: "description", content: "Verifiable, portfolio-linked certifications that hirers actually respect — because they are earned by shipping, not by watching." },
      { property: "og:title", content: "Certifications · VibeCode" },
      { property: "og:description", content: "Verifiable, portfolio-linked certifications that hirers actually respect — because they are earned by shipping, not by watching." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/learn/certifications" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/learn/certifications" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Certifications"
      breadcrumb={[{"label":"Learn","to":"/"}]}
      title="Prove your craft."
      intro="Verifiable, portfolio-linked certifications that hirers actually respect — because they are earned by shipping, not by watching."
      toc={[{"id":"tracks","label":"Available certifications"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="tracks" title="Available certifications"><NotionFeatureGrid items={[{"title":"Prompt Engineer","description":"Ship 5 production prompts with eval scores."},{"title":"RAG Engineer","description":"Build and defend a retrieval system end-to-end."},{"title":"Agent Builder","description":"Ship a multi-step agent with tool use."},{"title":"AI Product Engineer","description":"Take an LLM feature from spec to shipped."}]} /></NotionSection>
      <NotionCallout emoji="🏅" tone="cream">Certifications are free to attempt. Only shipped work counts — no multiple choice, no fluff.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="How do hirers verify?" a="Every certificate links back to the artifact you shipped. Public, permanent, tamper-proof." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
