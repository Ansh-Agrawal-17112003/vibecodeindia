import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/enterprise/community-as-a-service")({
  head: () => ({
    meta: [
      { title: "Community-as-a-Service · VibeCode" },
      { name: "description", content: "Launch a branded builder community without hiring a community team. We handle ops, moderation, content, and events." },
      { property: "og:title", content: "Community-as-a-Service · VibeCode" },
      { property: "og:description", content: "Launch a branded builder community without hiring a community team. We handle ops, moderation, content, and events." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/enterprise/community-as-a-service" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/enterprise/community-as-a-service" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Community-as-a-Service"
      breadcrumb={[{"label":"Enterprise","to":"/"}]}
      title="We run the cohort. You ship."
      intro="Launch a branded builder community without hiring a community team. We handle ops, moderation, content, and events."
      toc={[{"id":"stack","label":"What we run for you"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="stack" title="What we run for you"><NotionFeatureGrid items={[{"title":"Ops & moderation","description":"24/7 human moderation, spam filtering, escalation SLAs."},{"title":"Content calendar","description":"Weekly threads, AMAs, and challenges — planned and posted."},{"title":"Events","description":"Monthly IRL meetups in the cities that matter to you."},{"title":"Analytics","description":"Monthly report on engagement, sentiment, and top voices."}]} /></NotionSection>
      <NotionCallout emoji="🤝" tone="gold">Typical rollout: 6 weeks from kickoff to public launch. Retainer-based, no long-term lock-in.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Do we own the community?" a="Yes. All data, all members, all IP — yours. We are staff-augmentation, not a landlord." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
