import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/pricing_/team")({
  head: () => ({
    meta: [
      { title: "Team Plans · VibeCode" },
      { name: "description", content: "Multi-seat plans for startups hiring, agencies sourcing, and community leaders running cohorts." },
      { property: "og:title", content: "Team Plans · VibeCode" },
      { property: "og:description", content: "Multi-seat plans for startups hiring, agencies sourcing, and community leaders running cohorts." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/pricing/team" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/pricing/team" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Team Plans"
      breadcrumb={[{"label":"Pricing","to":"/pricing"}]}
      title="For crews and agencies."
      intro="Multi-seat plans for startups hiring, agencies sourcing, and community leaders running cohorts."
      toc={[{"id":"plans","label":"Team pricing"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="plans" title="Team pricing"><NotionFeatureGrid items={[{"title":"Business — ₹2,999/month","description":"3 seats, featured job posts, saved candidate pools, priority moderation."},{"title":"Studio — ₹7,499/month","description":"10 seats, branded studio page, sponsored builds, dedicated CSM."}]} /></NotionSection>
      <NotionCallout emoji="👥" tone="cream">Add or remove seats anytime. Prorated billing, no minimum term.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Can I switch from Pro to Business?" a="Yes — upgrade in one click, remaining Pro credit is prorated." />
          <NotionToggle q="Do you offer annual billing?" a="Yes — 2 months free on annual plans." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
