import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import {
  Sparkles,
  Flame,
  Trophy,
  Users,
  Rocket,
  Award,
  Briefcase,
  MessageCircle,
  Check,
  ArrowRight,
  Star,
  Crown,
  Heart,
  Lock,
  Building2,
  GraduationCap,
  Calendar,
  Twitter,
  Linkedin,
  Send,
  Copy as CopyIcon,
  Quote,
  ChevronRight,
  Share2,
  ShieldCheck,
  AlertTriangle,
  ExternalLink,
  BadgeCheck,
  MapPin,
} from "lucide-react";
import { LandingDock } from "@/components/site/LandingDock";
import { KineticText } from "@/components/ui/kinetic-text";
import { WordRotate } from "@/registry/magicui/word-rotate";
import Text3DFlip from "@/registry/magicui/text-3d-flip";
import { Terminal, TypingAnimation, AnimatedSpan } from "@/registry/magicui/terminal";
import { Highlighter } from "@/registry/magicui/highlighter";
import { GlareHover } from "@/registry/magicui/glare-hover";

import { AnimatedCounter, Reveal, HighlightText, BentoMotion } from "@/components/early-access/effects";
import { CountdownTicker } from "@/components/early-access/CountdownTicker";
import {
  StickyClaimBar,
  OGNumberSimulator,
  AvailabilityHeatmap,
  KineticManifesto,
  LiveJoinsStrip,
  CelebrationOverlay,
} from "@/components/early-access/Wave1";
import {
  FounderVideoCard,
  TestimonialMasonry,
} from "@/components/early-access/Wave2";
import {
  PerksComparisonTable,
  ScrollJourneyTimeline,
  SpinWheelPerkReveal,
  BuilderPersonalityQuiz,
} from "@/components/early-access/Wave3";

const LAUNCH_DATE = "2026-08-04T00:00:00+05:30";



export const Route = createFileRoute("/early-access")({
  head: () => ({
    meta: [
      { title: 'OG Founding Members · VibeCode Early Access' },
      { name: "description", content: 'Claim your permanent OG number, land on the Founders Wall, and unlock ₹6,000+ of Pro perks at launch.' },
      { property: "og:title", content: 'OG Founding Members · VibeCode Early Access' },
      { property: "og:description", content: 'Claim your permanent OG number, land on the Founders Wall, and unlock ₹6,000+ of Pro perks at launch.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/early-access' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'OG Founding Members · VibeCode Early Access' },
      { name: "twitter:description", content: 'Claim your permanent OG number, land on the Founders Wall, and unlock ₹6,000+ of Pro perks at launch.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/early-access' }],
  }),
  component: EarlyAccessPage,
});

/* ============================================================
   Brand tokens — mirror the landing page
   ============================================================ */
const C = {
  cream: "#FAF6F1",
  creamDeep: "#F3ECDF",
  white: "#FFFFFF",
  dark: "#0F0F0F",
  darkSoft: "#161616",
  border: "#E8E0D6",
  text: "#0F0F0F",
  muted: "#666666",
  coral: "#E8623A",
  coralSoft: "#FFF1EA",
  gold: "#F5A623",
  green: "#22C55E",
};

const TOTAL_SPOTS = 100;

const BUILDER_TYPES = [
  { v: "freelancer", e: "🚀", l: "Indie Builder" },
  { v: "employee", e: "👨‍💼", l: "Employee" },
  { v: "student", e: "🎓", l: "Student" },
  { v: "agency", e: "🏢", l: "Agency" },
  { v: "founder", e: "💡", l: "Founder" },
  { v: "other", e: "🤷", l: "Other" },
];

const TOOLS = [
  { v: "lovable", l: "Lovable", c: "#8b5cf6" },
  { v: "cursor", l: "Cursor", c: "#0ea5e9" },
  { v: "n8n", l: "n8n", c: "#ef4444" },
  { v: "claude", l: "Claude", c: "#E8623A" },
  { v: "make", l: "Make", c: "#a855f7" },
  { v: "gpt4", l: "GPT-4o", c: "#10a37f" },
  { v: "gemini", l: "Gemini", c: "#4285f4" },
  { v: "midjourney", l: "Midjourney", c: "#ec4899" },
  { v: "replit", l: "Replit", c: "#f26207" },
  { v: "bolt", l: "Bolt", c: "#facc15" },
  { v: "other", l: "Other", c: "#E8623A" },
];

const REFERRAL_SOURCES = ["LinkedIn", "Twitter / X", "WhatsApp", "A friend", "Google", "YouTube", "Other"];

const INDIAN_STATES = [
  "Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat",
  "Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh",
  "Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab",
  "Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh",
  "Uttarakhand","West Bengal","Delhi","Chandigarh","Puducherry","Jammu & Kashmir","Ladakh",
];

const MARQUEE_ITEMS = [
  "🔥 100 Permanent OG Badges",
  "100 Community Spots",
  "Free Pro for 1 Full Year",
  "Worth ₹5,988 · Yours Free",
  "Your Name on the Founders Wall",
  "500 VibeCoins on Launch",
  "First Access to Every Feature",
  "🇮🇳 Made for Indian Builders",
  "August 4, 2026 · Launch Day",
  "joinvibecode.xyz",
];

const PERSONAS = [
  {
    icon: Rocket,
    tint: "#FFF1EA",
    title: "Indie Builders",
    body: "You're shipping micro-SaaS with Lovable, automating with n8n, or launching Chrome extensions on weekends. You want a home where builders find you.",
  },
  {
    icon: Building2,
    tint: "#FFE9E6",
    title: "Founders & Operators",
    body: "You're building the next AI-native company from India. You want to hire vibe coders — not resume-driven engineers who've never shipped.",
  },
  {
    icon: Briefcase,
    tint: "#F5F0E8",
    title: "AI Freelancers",
    body: "You bill in USD for Claude prompts, n8n workflows, and Cursor builds. You want clients that respect your craft and pay on time.",
  },
  {
    icon: GraduationCap,
    tint: "#FFF6E6",
    title: "Students & Beginners",
    body: "You're 19, you've built 3 side projects, and you're tired of 'submit a resume' hiring. You want a stage where the work speaks first.",
  },
];

const PLATFORM_INTRO = [
  {
    icon: Sparkles,
    title: "What VibeCode is",
    body: "India's first platform built specifically for AI builders. A living profile of what you actually ship — projects, prompts, workflows, tools. Not a resume. Not a LinkedIn clone. A discovery layer for the new economy of Indian AI talent.",
  },
  {
    icon: Heart,
    title: "Why we're building it",
    body: "Because LinkedIn doesn't know what n8n is. Because Upwork is a race to the bottom. Because the best Indian AI builders shouldn't have to build careers on 40 scattered Discord servers. We're the home vibe coders deserve.",
  },
  {
    icon: Users,
    title: "Who it's for",
    body: "50,000+ builders shipping in Lovable, Claude, Cursor, n8n, Make, GPT-4o, Gemini, Midjourney. Founders hiring AI talent. Freelancers ready to raise their rates. Students turning weekend builds into paid work.",
  },
];

const PERKS = [
  {
    label: "BENEFIT 01",
    icon: "🔥",
    tint: "#0F0F0F",
    title: "Permanent OG Badge",
    body: "A badge on your VibeCode profile that marks you as Builder #X of 100. Reserved forever. Never earnable after August 4, 2026. This is the only way to get it.",
    dark: true,
    span: 3,
  },
  {
    label: "BENEFIT 02",
    icon: "💎",
    tint: "#FFF1EA",
    title: "Free Pro — 1 Full Year",
    body: "₹5,988 of Pro membership, on the house. Top of search. Verified badge. Priority job apps. Profile analytics.",
    span: 2,
  },
  {
    label: "BENEFIT 03",
    icon: "🏆",
    tint: "#FFE9E6",
    title: "Founders Wall",
    body: "Your name, your city, your tagline — on the permanent public Founders Wall. Linked forever in VibeCode history.",
    span: 2,
  },
  {
    label: "BENEFIT 04",
    icon: "🪙",
    tint: "#FFF6E6",
    title: "500 VibeCoins",
    body: "Credited on launch day. Cash out to UPI. Boost your profile. Unlock premium features. Our gift for believing early.",
    span: 1,
  },
  {
    label: "BENEFIT 05",
    icon: "⚡",
    tint: "#F5F0E8",
    title: "First Access",
    body: "Every new feature — live sessions, AI feedback, collab boards — you see it first. Before the public. Before anyone.",
    span: 3,
  },
  {
    label: "BENEFIT 06",
    icon: "🎯",
    tint: "#E8623A",
    title: "OG WhatsApp Group",
    body: "Private group with the other 96 OGs and the founders. Direct DM to the team. Shape the roadmap. Ship together.",
    coral: true,
    span: 2,
  },
];

const TIMELINE = [
  { d: "Today", i: "📅", t: "Claim your OG spot", b: "Fill the 90-second form. Your badge is reserved the moment you hit submit." },
  { d: "Jul 15", i: "📬", t: "Onboarding email", b: "We send you a private founder update, plus first look at the platform." },
  { d: "Jul 28", i: "🎥", t: "OG-only preview", b: "Private Zoom with the founding team. Ask anything. Shape the launch." },
  { d: "Aug 04", i: "🚀", t: "Official launch", b: "VibeCode goes live to India. Your OG badge, Pro, and 500 coins auto-activate." },
  { d: "Aug 05+", i: "🏆", t: "Founders Wall live", b: "Your name goes up on the public wall. First 100 forever. Screenshots become memories." },
];

const FAQ = [
  {
    q: "Is the OG spot really free?",
    a: "Yes. Zero rupees. No credit card. No trial. You claim your builder number, and it's yours. The Free Pro year, the Founders Wall spot, the 500 coins — all included. We make money from Pro subscribers post-launch, not from you.",
  },
  {
    q: "What happens after August 4?",
    a: "The OG program closes forever. No new OG badges will ever be issued. Anyone joining after launch becomes a regular Builder. The 100 OGs stay marked on their profiles permanently — a small, permanent tribe.",
  },
  {
    q: "What if I claim a spot but don't use my Pro?",
    a: "It's still yours. Pro activates on August 4 automatically and runs for 12 months from that date. Even if you never log in, the badge and Founders Wall entry are permanent.",
  },
  {
    q: "Do I have to be based in India?",
    a: "You should identify with India's AI builder ecosystem — most OGs will be based in India, but Indian builders living abroad are just as welcome. The community's soul is Indian; the passport is not the gate.",
  },
  {
    q: "Can I stay anonymous on the wall?",
    a: "Yes. During signup you can toggle 'Show me on the wall' off. Your badge and benefits remain — only your name won't appear publicly. You can flip it on later from your profile.",
  },
  {
    q: "Why only 100?",
    a: "Because scarcity forces intention. 100 is small enough that every OG matters. It's the founding tribe — the people who believed before there was anything to see. That's not a marketing number. That's a promise.",
  },
];

type WallMember = {
  og_number: number;
  full_name: string;
  city: string | null;
  state: string | null;
  wall_tagline: string | null;
  primary_tool: string | null;
  linkedin_url: string | null;
  twitter_url: string | null;
};

const avatarUrl = (seed: string) =>
  `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed || "og")}`;

/* ============================================================
   Page
   ============================================================ */
function EarlyAccessPage() {
  const [remaining, setRemaining] = useState<number>(TOTAL_SPOTS);
  const [taken, setTaken] = useState<number>(0);
  const [nextNumber, setNextNumber] = useState<number>(4);
  const [wall, setWall] = useState<WallMember[]>([]);
  const [step, setStep] = useState<1 | 2 | 3 | "terms" | "success" | "waitlist">(1);
  const [submitting, setSubmitting] = useState(false);
  const [ogNumber, setOgNumber] = useState<number | null>(null);
  const [alreadyAt, setAlreadyAt] = useState<number | null>(null);
  const [joinToast, setJoinToast] = useState<WallMember | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [wallExpanded, setWallExpanded] = useState(false);
  const [celebrateOpen, setCelebrateOpen] = useState(false);
  const { session } = useAuth();
  const verifiedEmail = session?.user?.email ?? null;

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    username: "",
    city: "",
    state: "",
    builderType: "",
    primaryTool: "",
    otherTools: [] as string[],
    whatBuilding: "",
    wallTagline: "",
    linkedinUrl: "",
    twitterUrl: "",
    githubUrl: "",
    referralSource: "",
    showOnWall: true,
    agreed: false,
  });

  const [waitEmail, setWaitEmail] = useState("");
  const [waitName, setWaitName] = useState("");
  const [waitDone, setWaitDone] = useState(false);

  // Prefill from verified Google session (email is locked from editing)
  useEffect(() => {
    if (!session?.user) return;
    const meta: any = session.user.user_metadata || {};
    const gEmail = session.user.email || "";
    const gName = meta.full_name || meta.name || "";
    setForm((f) => ({
      ...f,
      email: gEmail || f.email,
      fullName: f.fullName || gName,
    }));
    // After Google verification, take the builder straight to the next steps:
    // scroll to the registration form and show a welcome toast once per session.
    if (typeof window !== "undefined") {
      const key = "vc_ea_post_oauth_shown";
      if (!sessionStorage.getItem(key)) {
        sessionStorage.setItem(key, "1");
        toast.success(`Email verified — let's claim your OG spot, ${(gName || "builder").split(" ")[0]}!`);
        setTimeout(() => {
          document.getElementById("og-form")?.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 250);
      }
    }
  }, [session?.user?.id]);

  const fetchAll = async () => {
    try {
      const [{ data: spots }, { data: members }] = await Promise.all([
        supabase.from("og_spots_remaining" as any).select("remaining, taken, next_number").single(),
        supabase
          .from("og_wall_public" as any)
          .select("og_number, full_name, city, state, wall_tagline, primary_tool, linkedin_url, twitter_url")
          .order("og_number", { ascending: true }),
      ]);
      if (spots) {
        const dbTaken = Number((spots as any).taken ?? 0);
        const dbRemaining = Number((spots as any).remaining ?? Math.max(0, TOTAL_SPOTS - dbTaken));
        const dbNextNumber = Number((spots as any).next_number ?? Math.min(TOTAL_SPOTS, dbTaken + 1));
        setTaken(dbTaken);
        setRemaining(Math.max(0, dbRemaining));
        setNextNumber(Math.min(TOTAL_SPOTS, Math.max(1, dbNextNumber)));
      }
      if (members) setWall(members as any);
    } catch {
      // Keep the enrollment flow uninterrupted; realtime/polling will retry.
    }
  };

  useEffect(() => {
    fetchAll();
    const id = setInterval(fetchAll, 15000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const syncStats = (stats: any) => {
      if (!stats) return;
      const dbTaken = Number(stats.taken ?? 0);
      const dbRemaining = Number(stats.remaining ?? Math.max(0, TOTAL_SPOTS - dbTaken));
      const dbNextNumber = Number(stats.next_number ?? Math.min(TOTAL_SPOTS, dbTaken + 1));
      setTaken(dbTaken);
      setRemaining(Math.max(0, dbRemaining));
      setNextNumber(Math.min(TOTAL_SPOTS, Math.max(1, dbNextNumber)));
    };

    // Realtime on og_members removed — it broadcast full rows (including
    // email/IP) to any anon subscriber. Live counter still updates via the
    // og_claim_stats channel below, which contains no PII.
    const channel = supabase
      .channel("og-members-live")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "og_claim_stats" } as any,
        (payload) => {
          syncStats(payload.new as any);
          fetchAll();
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const pct = Math.min(100, Math.round((taken / TOTAL_SPOTS) * 100));

  const scrollToForm = () => document.getElementById("og-form")?.scrollIntoView({ behavior: "smooth" });

  const validateStep1 = () => {
    if (form.fullName.trim().length < 2) return "Please enter your full name";
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email.trim())) return "Enter a valid email";
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(form.username.trim())) return "Username: 3–20 chars, letters/numbers/underscore";
    if (form.city.trim().length < 2) return "Please enter your city";
    return null;
  };
  const validateStep2 = () => {
    if (!form.builderType) return "Pick what kind of builder you are";
    if (!form.primaryTool) return "Pick your primary AI tool";
    if (form.whatBuilding.trim().length < 5) return "Tell us what you're building";
    if (form.wallTagline.trim().length < 5) return "Add a short tagline for the wall";
    return null;
  };
  const validateStep3 = () => {
    if (!form.referralSource) return "Let us know how you heard about us";
    return null;
  };

  const goNext = (from: 1 | 2 | 3) => {
    if (!verifiedEmail) return toast.error("Please verify your email with Google first");
    const err = from === 1 ? validateStep1() : from === 2 ? validateStep2() : validateStep3();
    if (err) return toast.error(err);
    if (from === 1) setStep(2);
    else if (from === 2) setStep(3);
    else setStep("terms");
  };

  const submit = async () => {
    setSubmitting(true);
    try {
      // Device-level guard: never block a returning builder with an error popup.
      const deviceClaim = typeof window !== "undefined" ? localStorage.getItem("vc_og_claimed") : null;
      if (deviceClaim) {
        try {
          const parsed = JSON.parse(deviceClaim) as { og_number?: number; email?: string };
          if (parsed?.og_number) {
            setAlreadyAt(parsed.og_number);
            setOgNumber(parsed.og_number);
            await fetchAll();
            setStep("success");
            return;
          }
        } catch {}
      }

      const { data: spots } = await supabase.from("og_spots_remaining" as any).select("remaining, taken, next_number").single();
      if (spots && (spots as any).remaining <= 0) {
        setStep("waitlist");
        return;
      }
      const emailNorm = form.email.trim().toLowerCase();
      const { data: claimData, error } = await (supabase as any).rpc("claim_og_spot", {
        payload: {
          full_name: form.fullName.trim(),
          email: emailNorm,
          username: form.username.trim().toLowerCase(),
          city: form.city.trim(),
          state: form.state || null,
          builder_type: form.builderType,
          primary_tool: form.primaryTool,
          other_tools: form.otherTools,
          what_building: form.whatBuilding.trim(),
          wall_tagline: form.wallTagline.trim(),
          linkedin_url: form.linkedinUrl.trim() || null,
          twitter_url: form.twitterUrl.trim() || null,
          github_url: form.githubUrl.trim() || null,
          referral_source: form.referralSource,
          show_on_wall: form.showOnWall,
        },
      });
      if (error) throw error;
      const row = Array.isArray(claimData) ? claimData[0] : claimData;
      const claimedNumber = Number(row?.og_number);
      if (!Number.isFinite(claimedNumber) || claimedNumber <= 0) throw new Error("Claim pending");
      const wasAlready = !!row?.already_claimed;
      if (wasAlready) setAlreadyAt(claimedNumber);
      setOgNumber(claimedNumber);
      const statsTaken = Number(row?.taken);
      const statsRemaining = Number(row?.remaining);
      const statsNextNumber = Number(row?.next_number);
      setTaken(Number.isFinite(statsTaken) ? statsTaken : claimedNumber);
      setRemaining(Number.isFinite(statsRemaining) ? Math.max(0, statsRemaining) : Math.max(0, TOTAL_SPOTS - claimedNumber));
      setNextNumber(Number.isFinite(statsNextNumber) ? Math.min(TOTAL_SPOTS, Math.max(1, statsNextNumber)) : Math.min(TOTAL_SPOTS, claimedNumber + 1));
      try {
        localStorage.setItem("vc_og_claimed", JSON.stringify({ og_number: claimedNumber, email: emailNorm }));
      } catch {}
      await fetchAll();
      setStep("success");
      if (!wasAlready) setCelebrateOpen(true);
    } catch (e: any) {
      if (e?.message?.toLowerCase().includes("og spots are full")) {
        setStep("waitlist");
      } else {
        await fetchAll();
        setStep("terms");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const joinWaitlist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(waitEmail.trim())) return toast.error("Valid email please");
    const { error } = await supabase
      .from("og_waitlist" as any)
      .insert({ email: waitEmail.trim().toLowerCase(), name: waitName.trim() || null });
    if (error && !error.message.toLowerCase().includes("duplicate")) return toast.error(error.message);
    setWaitDone(true);
    toast.success("You're on the waitlist!");
  };

  return (
    <div style={{ background: C.cream, color: C.text, minHeight: "100vh" }} className="font-sans ea-page">
      <style>{`
        @keyframes ea-gradient-pan { 0% { background-position: 0% 50%; } 100% { background-position: 200% 50%; } }
        @keyframes ea-badge-in { 0% { opacity: 0; transform: scale(.7) translateY(6px); } 100% { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes ea-bar-rise { 0% { transform: scaleY(0); opacity: 0; } 100% { transform: scaleY(1); opacity: 0.85; } }
        @keyframes ea-bar-wave { 0%, 100% { transform: scaleY(1); } 50% { transform: scaleY(1.18); } }
        @keyframes ea-progress-fill { 0% { transform: scaleX(0); } 100% { transform: scaleX(1); } }
        @keyframes ea-empty-pulse {
          0%, 100% { border-color: rgba(15,15,15,0.22); background: #F5F0E8; }
          50% { border-color: rgba(232,98,58,0.55); background: #FFF1EA; }
        }
        .ea-empty-slot { animation: ea-empty-pulse 3.6s ease-in-out infinite; }
        @keyframes ea-dash-flow { to { stroke-dashoffset: -200; } }
        .ea-flow-dash { animation: ea-dash-flow 2.4s linear infinite; }
        @keyframes ea-svg-draw { to { stroke-dashoffset: 0; } }
        @media (min-width: 1280px) { .ea-page { zoom: 1.1; } }
        @media (min-width: 1600px) { .ea-page { zoom: 1.18; } }

      `}</style>

      {/* ============ Standalone slim topbar ============ */}
      <header
        className="sticky top-0 z-50 border-b bg-[#FAF6F1]/85 backdrop-blur-lg"
        style={{ borderColor: C.border }}
      >
        <div className="mx-auto flex h-14 max-w-[1200px] items-center justify-between px-5 md:px-8">
          <div className="flex items-center gap-2">
            <span
              className="grid h-8 w-8 place-items-center rounded-[8px] border-[1.5px]"
              style={{ background: C.coral, borderColor: C.dark, color: "#fff", boxShadow: `2px 2px 0 0 ${C.dark}` }}
            >
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M8 8 L3 12 L8 16" />
                <path d="M16 8 L21 12 L16 16" />
                <path d="M14 5 L10 19" />
              </svg>
            </span>
            <span className="font-display text-[18px] font-extrabold tracking-[-0.02em]">VibeCode</span>
          </div>
          <div className="flex items-center gap-2 md:gap-3">
            <span className="hidden text-[12px] font-semibold text-[#666] md:inline">joinvibecode.xyz/early-access</span>
            <ShareMenu C={C} remaining={remaining} />
            <a
              href="#og-form"
              onClick={(e) => {
                e.preventDefault();
                scrollToForm();
              }}
              className="btn-coral h-9 px-4 text-[12px]"
              style={{ height: 36 }}
            >
              Claim spot
            </a>
          </div>
        </div>
      </header>

      {/* ============ 1. HERO ============ */}
      <Section
        bg={`radial-gradient(700px circle at 15% 10%, rgba(232,98,58,0.10), transparent 60%), radial-gradient(600px circle at 85% 90%, rgba(245,166,35,0.08), transparent 60%), ${C.cream}`}
      >
        <div className="relative mx-auto max-w-[960px] text-center">
          <div
            className="group relative mx-auto inline-flex items-center justify-center gap-2 rounded-full bg-white/70 px-3 py-1 text-[9.5px] font-bold uppercase tracking-[0.14em] backdrop-blur-md transition-shadow duration-500 ease-out md:px-4 md:py-1.5 md:text-[11px]"
            style={{
              color: C.text,
              boxShadow:
                "inset 0 -6px 12px rgba(232,98,58,0.10), 0 6px 22px -10px rgba(232,98,58,0.35)",
            }}
          >
            <span
              aria-hidden
              className="pointer-events-none absolute inset-0 rounded-[inherit] p-[1.5px] [background-size:300%_100%] [animation:ea-gradient-pan_5s_linear_infinite]"
              style={{
                backgroundImage:
                  "linear-gradient(110deg,#E8623A_0%,#F5A623_35%,#0F0F0F_50%,#F5A623_65%,#E8623A_100%)",
                WebkitMask:
                  "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
                WebkitMaskComposite: "xor",
                mask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
                maskComposite: "exclude",
              }}
            />
            <Sparkles className="h-3 w-3" style={{ color: C.coral }} />
            <span
              className="bg-clip-text text-transparent [background-size:200%_100%] [animation:ea-gradient-pan_4s_linear_infinite]"
              style={{
                backgroundImage:
                  "linear-gradient(110deg,#0F0F0F 0%,#E8623A 40%,#F5A623 55%,#0F0F0F 100%)",
              }}
            >
              100 OG Badges
            </span>
            <span aria-hidden className="h-3 w-px shrink-0 bg-[#0F0F0F]/25" />
            <span style={{ color: C.coral }} className="tabular-nums">{remaining} Available</span>
            <span aria-hidden className="h-3 w-px shrink-0 bg-[#0F0F0F]/25" />
            <span style={{ color: C.text }}>Aug 4 Launch</span>
          </div>

          <h1
            className="mx-auto mt-4 font-display font-extrabold leading-[1] tracking-[-0.03em] uppercase md:mt-7"
            style={{ fontSize: "clamp(38px, 8vw, 88px)" }}
          >
            YOU'RE ONE OF{" "}
            <span className="whitespace-nowrap">
              INDIA'S FIRST{" "}
              <span
                className="relative inline-block"
                style={{ color: C.coral }}
              >
                100
                <svg
                  aria-hidden
                  viewBox="0 0 120 12"
                  className="absolute -bottom-2 left-0 h-2 w-full"
                  preserveAspectRatio="none"
                >
                  <path
                    d="M2 8 Q30 2 60 6 T118 5"
                    stroke={C.coral}
                    strokeWidth="2.5"
                    fill="none"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
            </span>
            <br />
            <WordRotate
              words={["AI BUILDERS.", "VIBE CODERS.", "AI FOUNDERS.", "PROMPT ENGINEERS.", "AUTOMATORS.", "SHIPPERS."]}
              className="uppercase bg-clip-text text-transparent [background-image:linear-gradient(110deg,#E8623A_0%,#F5A623_35%,#E8623A_60%,#FF8A5B_100%)] [background-size:200%_100%] [animation:ea-gradient-pan_4s_linear_infinite] drop-shadow-[0_2px_0_rgba(15,15,15,0.06)]"
            />

          </h1>


          <p
            className="mx-auto mt-4 max-w-[620px] text-[14px] leading-[1.6] md:mt-6 md:text-[19px] md:leading-[1.65]"
            style={{ color: C.muted }}
          >
            VibeCode launches <b style={{ color: C.text }}>August 4, 2026</b>. The first{" "}
            <b style={{ color: C.text }}>100 people</b> who claim an OG spot get{" "}
            <b style={{ color: C.coral }}>Free Pro for 1 year</b> — worth ₹5,988.
          </p>

          {/* Counter widget — cream card, brutal shadow */}
          <div className="mx-auto mt-6 max-w-[560px] md:mt-10">
            <GlareHover
              className="rounded-[18px] p-5 md:rounded-[22px] md:p-8"
              duration={1400}
              glareColor="rgba(255,255,255,0.7)"
              style={{
                background:
                  "radial-gradient(120% 100% at 0% 0%, rgba(232,98,58,0.20), transparent 60%), radial-gradient(120% 100% at 100% 100%, rgba(245,166,35,0.16), transparent 60%), linear-gradient(180deg, #FFF6EE 0%, #FDE7D6 100%)",
                border: `1.5px solid ${C.dark}`,
                boxShadow: `4px 4px 0 0 ${C.dark}, inset 0 1px 0 rgba(255,255,255,0.7), inset 0 0 60px rgba(232,98,58,0.08)`,
                color: C.text,
              }}
            >
              {/* Top row: LIVE label + status */}
              <div className="mb-4 flex items-center justify-between text-[10px] font-bold uppercase tracking-[0.22em] md:text-[11px]" style={{ color: "#8a5a3f" }}>
                <span className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#E8623A] opacity-70" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-[#E8623A]" />
                  </span>
                  Live · OG Counter
                </span>
                <span className="tabular-nums" style={{ color: C.text }}>#{String(nextNumber).padStart(3, "0")} / 100</span>
              </div>

              {/* Massive clock-style remaining number */}
              <div className="text-center">
                <div
                  className="font-mono font-black leading-[0.9] tabular-nums"
                  style={{
                    fontSize: "clamp(88px, 26vw, 180px)",
                    fontFeatureSettings: "'tnum','ss01'",
                    letterSpacing: "-0.04em",
                    background:
                      "linear-gradient(180deg, #FF8A52 0%, #E8623A 50%, #B03A18 100%)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                    filter: "drop-shadow(0 4px 18px rgba(232,98,58,0.30)) drop-shadow(0 1px 0 rgba(15,15,15,0.08))",
                  }}
                >
                  <AnimatedCounter value={remaining} />
                </div>
                <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.28em] md:text-[11px]" style={{ color: "#8a5a3f" }}>
                  Spots remaining
                </div>
              </div>

              {/* Progress bar */}
              <div className="mt-6">
                <div
                  className="h-1.5 w-full overflow-hidden rounded-full"
                  style={{ background: "rgba(15,15,15,0.08)", border: "1px solid rgba(15,15,15,0.10)" }}
                >
                  <div
                    className="h-full transition-[width] duration-700 ease-out"
                    style={{
                      width: `${pct}%`,
                      background: `linear-gradient(90deg, ${C.coral} 0%, ${C.gold} 100%)`,
                      boxShadow: `0 0 10px rgba(232,98,58,0.55)`,
                    }}
                  />
                </div>
              </div>

              {/* Bottom stats row */}
              <div className="mt-5 grid grid-cols-2 gap-3">
                <div
                  className="rounded-[12px] px-3 py-2.5"
                  style={{ background: "rgba(255,255,255,0.65)", border: "1px solid rgba(15,15,15,0.12)", backdropFilter: "blur(6px)" }}
                >
                  <div
                    className="font-mono font-extrabold tabular-nums leading-none"
                    style={{ color: C.coral, fontSize: "clamp(24px, 6vw, 34px)", letterSpacing: "-0.02em" }}
                  >
                    <AnimatedCounter value={taken} />
                  </div>
                  <div className="mt-1.5 text-[9.5px] font-bold uppercase tracking-[0.18em] md:text-[10px]" style={{ color: "#8a5a3f" }}>
                    Builders joined
                  </div>
                </div>
                <div
                  className="rounded-[12px] px-3 py-2.5"
                  style={{ background: "rgba(255,255,255,0.65)", border: "1px solid rgba(15,15,15,0.12)", backdropFilter: "blur(6px)" }}
                >
                  <div
                    className="font-mono font-extrabold tabular-nums leading-none"
                    style={{ color: C.text, fontSize: "clamp(24px, 6vw, 34px)", letterSpacing: "-0.02em" }}
                  >
                    {pct}<span style={{ color: "#8a5a3f" }}>%</span>
                  </div>
                  <div className="mt-1.5 text-[9.5px] font-bold uppercase tracking-[0.18em] md:text-[10px]" style={{ color: "#8a5a3f" }}>
                    Claimed
                  </div>
                </div>
              </div>
            </GlareHover>
          </div>

          {/* Countdown ticker — window closes at launch */}
          <div className="mt-6 flex flex-col items-center gap-3 md:mt-8">
            <div className="text-[10px] font-bold uppercase tracking-[0.22em] md:text-[11px]" style={{ color: C.muted }}>
              Early access window closes in
            </div>
            <CountdownTicker target={LAUNCH_DATE} />
            <div className="text-[11px] md:text-[12px]" style={{ color: C.muted }}>
              Ends <b style={{ color: C.text }}>Aug 4, 2026</b> · when spots fill, they fill early
            </div>
          </div>


          <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row md:mt-10">
            <button className="btn-coral h-12 px-6 text-[14px] md:h-14 md:px-8 md:text-[15px]" onClick={scrollToForm} disabled={remaining <= 0}>
              <Flame className="h-4 w-4" />
              {remaining <= 0 ? "Join the Waitlist" : "Claim Your OG Spot — It's Free"}
              <ArrowRight className="h-4 w-4" />
            </button>
            <a href="#what-you-get" className="btn-outline-dark h-12 px-5 text-[13px] md:h-14 md:px-6 md:text-[14px]">
              What's inside <ChevronRight className="h-4 w-4" />
            </a>
          </div>

          <div className="mt-5 text-[12px] font-semibold text-[#7a7a7a]">
            No credit card · Free forever for OGs · OG Pro lasts 1 full year
          </div>

          {/* Trust — founder avatars */}
          <div className="mt-9 flex flex-col items-center justify-center gap-3 px-4 sm:flex-row sm:gap-3">
            <div className="flex shrink-0">
              {["Riya", "Arjun", "Priya", "Rohan", "Meera"].map((s, i) => (
                <img
                  key={s}
                  src={avatarUrl(s)}
                  alt=""
                  className="h-8 w-8 rounded-full sm:h-9 sm:w-9"
                  style={{
                    background: C.creamDeep,
                    border: `1.5px solid ${C.dark}`,
                    marginLeft: i === 0 ? 0 : -12,
                    zIndex: 5 - i,
                  }}
                />
              ))}
            </div>
            <div className="min-w-0 text-center text-[13px] sm:text-left">
              <div className="font-bold" style={{ color: C.text }}>
                Founders already inside
              </div>
              <div className="text-[12px]" style={{ color: C.muted }}>
                Building for India's builders since day zero.
              </div>
            </div>
          </div>

        </div>
      </Section>

      {/* ============ 2. MARQUEE ============ */}
      <div
        className="w-full overflow-hidden border-y"
        style={{
          background: `linear-gradient(180deg, ${C.cream} 0%, ${C.creamDeep} 100%)`,
          borderColor: C.border,
        }}
      >
        <div className="group flex whitespace-nowrap py-4">
          <div
            className="animate-marquee flex shrink-0 items-center gap-10 pr-10 group-hover:[animation-play-state:paused]"
            style={{ animationDuration: "45s" }}
          >
            {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((t, i) => (
              <span key={i} className="flex items-center gap-10 text-sm font-medium" style={{ color: "#5a5044" }}>
                <span>{t}</span>
                <span style={{ color: C.coral }}>◆</span>
              </span>
            ))}
          </div>
        </div>
      </div>


      {/* ============ 3. WHAT VIBECODE IS ============ */}
      <Section bg={C.white}>
        <div className="mx-auto max-w-[820px] text-center">
          <Pill soft>
            <Sparkles className="h-3 w-3" />
            First, a quick intro
          </Pill>
          <h2
            className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
            style={{ fontSize: "clamp(26px, 5.5vw, 60px)" }}
          >
            Before you claim your spot, meet the <Highlighter action="underline" color="#E8623A" strokeWidth={2.5} padding={1} animationDuration={900}>platform</Highlighter> you're joining.
          </h2>
          <p className="mx-auto mt-5 max-w-[620px] text-[16px] leading-[1.7]" style={{ color: C.muted }}>
            VibeCode isn't a landing page waiting to become a product. It's a working platform, launching to India on August 4. Here's what you're becoming part of.
          </p>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {PLATFORM_INTRO.map((p, i) => {
            const tints = [
              { bg: "linear-gradient(160deg, #FFF3EA 0%, #FFE1CE 100%)", glow: "rgba(232,98,58,0.22)" },
              { bg: "linear-gradient(160deg, #FFF7E4 0%, #FFE8B8 100%)", glow: "rgba(245,166,35,0.22)" },
              { bg: "linear-gradient(160deg, #FEEFEA 0%, #FFD8CB 100%)", glow: "rgba(232,98,58,0.20)" },
            ];
            const t = tints[i % 3];
            return (
              <BentoMotion key={p.title} index={i} className="h-full">
                <GlareHover className="h-full rounded-[16px]" duration={900} glareColor="rgba(255,255,255,0.55)" angle={18} width={45}>
                  <div
                    className="group relative flex h-full flex-col overflow-hidden rounded-[16px] p-6"
                    style={{
                      background: t.bg,
                      border: `1.5px solid ${C.dark}`,
                      boxShadow: `3px 3px 0 0 ${C.dark}`,
                      transition: "transform 220ms cubic-bezier(0.22,1,0.36,1), box-shadow 220ms cubic-bezier(0.22,1,0.36,1)",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "translate(-2px,-3px)";
                      e.currentTarget.style.boxShadow = `5px 6px 0 0 ${C.dark}`;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "translate(0,0)";
                      e.currentTarget.style.boxShadow = `3px 3px 0 0 ${C.dark}`;
                    }}
                  >
                    {/* decorative dotted grid corner */}
                    <span
                      aria-hidden
                      className="pointer-events-none absolute -right-6 -top-6 h-28 w-28 opacity-40"
                      style={{
                        backgroundImage: `radial-gradient(${C.dark} 1px, transparent 1.2px)`,
                        backgroundSize: "10px 10px",
                        maskImage: "radial-gradient(closest-side, black 40%, transparent 75%)",
                      }}
                    />
                    {/* soft radial glow */}
                    <span
                      aria-hidden
                      className="pointer-events-none absolute inset-0"
                      style={{ background: `radial-gradient(400px circle at 20% -10%, ${t.glow}, transparent 60%)` }}
                    />

                    <div className="relative flex items-start justify-between">
                      <span
                        className="grid h-12 w-12 place-items-center rounded-[12px] border-[1.5px] text-white"
                        style={{
                          background: `linear-gradient(135deg, ${C.coral} 0%, #F5A623 100%)`,
                          borderColor: C.dark,
                          boxShadow: `2px 2px 0 0 ${C.dark}`,
                        }}
                      >
                        <p.icon className="h-5 w-5" />
                      </span>
                      <span
                        className="font-mono text-[11px] font-black tracking-[0.14em]"
                        style={{ color: C.dark, opacity: 0.55 }}
                      >
                        0{i + 1} / 03
                      </span>
                    </div>

                    <div className="relative mt-5 flex-1">
                      <h3 className="font-display text-[22px] font-extrabold leading-[1.15] tracking-[-0.01em]">
                        {p.title}
                      </h3>
                      <span
                        aria-hidden
                        className="mt-2 block h-[3px] w-10 origin-left rounded-full transition-transform duration-300 group-hover:w-20"
                        style={{ background: `linear-gradient(90deg, ${C.coral}, #F5A623)` }}
                      />
                      <p className="mt-3 text-[14.5px] leading-[1.65]" style={{ color: "#4a3f34" }}>
                        {p.body}
                      </p>
                    </div>

                    {/* footer stripe */}
                    <div
                      className="relative mt-5 flex items-center justify-between border-t pt-3 font-mono text-[10px] font-bold uppercase tracking-[0.16em]"
                      style={{ borderColor: "rgba(15,15,15,0.14)", color: C.dark }}
                    >
                      <span className="inline-flex items-center gap-1.5">
                        <span className="h-1.5 w-1.5 rounded-full" style={{ background: C.coral }} />
                        vibecode · intro
                      </span>
                      <span style={{ color: C.coral }}>→</span>
                    </div>
                  </div>
                </GlareHover>
              </BentoMotion>
            );
          })}
        </div>

        {/* Terminal — how claiming an OG spot actually feels */}
        <div className="mt-16">
          <div className="mx-auto mb-6 max-w-[680px] text-center">
            <div
              className="mx-auto mb-3 inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.18em]"
              style={{ background: C.dark, color: "#fff", borderColor: C.dark }}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#28c840" }} />
              live · og_claim.sh
            </div>
            <h3
              className="font-display font-extrabold leading-[1.1] tracking-[-0.02em]"
              style={{ fontSize: "clamp(24px, 3.6vw, 34px)" }}
            >
              <Highlighter action="underline" color="#E8623A" strokeWidth={2} padding={1} animationDuration={900}>90 seconds</Highlighter>. One script. <span style={{ color: C.coral }}><Highlighter action="highlight" color="rgba(232,98,58,0.22)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>You're an OG.</Highlighter></span>
            </h3>
          </div>
          <Terminal title="~/vibecode/og-claim">
            <TypingAnimation>&gt; vibecode og:claim --launch aug-4-2026</TypingAnimation>
            <AnimatedSpan className="text-emerald-400">✔ Verifying early access window · open</AnimatedSpan>
            <AnimatedSpan className="text-emerald-400">{`✔ Locking OG number · reserving Builder #${nextNumber}`}</AnimatedSpan>
            <AnimatedSpan className="text-emerald-400">✔ Minting permanent OG badge · non-transferable</AnimatedSpan>
            <AnimatedSpan className="text-emerald-400">✔ Granting Pro access · 12 months · ₹5,988 waived</AnimatedSpan>
            <AnimatedSpan className="text-emerald-400">✔ Publishing to Founders Wall · visible on Aug 4</AnimatedSpan>
            <AnimatedSpan className="text-emerald-400">✔ Joining private WhatsApp · India's AI builders</AnimatedSpan>
            <AnimatedSpan className="text-[#E8623A]">
              <span>ℹ Perks unlocked (3):</span>
              <span className="pl-3">— Free Pro · 1 year</span>
              <span className="pl-3">— OG-only community + private drops</span>
              <span className="pl-3">— Founders Wall spot · forever</span>
            </AnimatedSpan>
            <TypingAnimation className="text-white/60">
              Welcome to the first 100. Ship something legendary.
            </TypingAnimation>
            <AnimatedSpan className="text-white/40">$ _</AnimatedSpan>
          </Terminal>
        </div>
      </Section>

      <Section bg={C.cream}>
        <div className="mx-auto max-w-[820px] text-center">
          <Pill soft>
            <Users className="h-3 w-3" />
            Who this is for
          </Pill>
          <h2
            className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
            style={{ fontSize: "clamp(26px, 5.5vw, 60px)" }}
          >
            The <Highlighter action="highlight" color="rgba(245,166,35,0.32)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>100 people</Highlighter> we built this for.
          </h2>
          <p className="mx-auto mt-5 max-w-[620px] text-[16px] leading-[1.7]" style={{ color: C.muted }}>
            Every OG is someone building the AI economy from India. If any of these sound like you — this spot has your name on it.
          </p>
        </div>

        {/* Premium asymmetric bento */}
        <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-6 md:auto-rows-[minmax(220px,auto)]">
          {PERSONAS.map((p, i) => {
            // Asymmetric spans: 0 → 4wide/2row (hero), 1 → 2wide, 2 → 2wide, 3 → 4wide
            const span =
              i === 0
                ? "md:col-span-4 md:row-span-2"
                : i === 1
                  ? "md:col-span-2"
                  : i === 2
                    ? "md:col-span-2"
                    : "md:col-span-6 lg:col-span-4 md:col-start-3";
            const isHero = i === 0;
            const isDark = i === 3;
            return (
              <BentoMotion key={p.title} index={i} className={`${span} h-full`}>
                <div
                  className="group relative flex h-full flex-col overflow-hidden rounded-[16px] p-6 md:p-7 transition-shadow duration-300 hover:shadow-[6px_6px_0_0_#0F0F0F]"
                  style={{
                    background: isDark ? C.dark : isHero ? C.white : p.tint,
                    color: isDark ? "#fff" : C.text,
                    border: `1.5px solid ${C.dark}`,
                    boxShadow: `3px 3px 0 0 ${C.dark}`,
                  }}
                >
                  {/* diagonal sheen */}
                  <div
                    aria-hidden
                    className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent opacity-0 transition-all duration-[900ms] group-hover:translate-x-full group-hover:opacity-100"
                  />
                  {/* dotted grid for hero */}
                  {isHero && (
                    <div
                      aria-hidden
                      className="pointer-events-none absolute inset-0 opacity-[0.35]"
                      style={{
                        backgroundImage: `radial-gradient(${C.border} 1px, transparent 1px)`,
                        backgroundSize: "18px 18px",
                        maskImage: "linear-gradient(to bottom right, black, transparent 70%)",
                      }}
                    />
                  )}
                  {/* radial glow for dark */}
                  {isDark && (
                    <div
                      aria-hidden
                      className="pointer-events-none absolute inset-0"
                      style={{
                        background:
                          "radial-gradient(400px circle at 80% 20%, rgba(232,98,58,0.22), transparent 60%)",
                      }}
                    />
                  )}

                  <div className="relative z-10 flex items-center justify-between">
                    <span
                      className="grid h-12 w-12 place-items-center rounded-[10px] border-[1.5px] transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-110"
                      style={{
                        background: isDark ? C.darkSoft : C.white,
                        borderColor: isDark ? "#2a2a2a" : C.dark,
                        color: isDark ? C.coral : C.dark,
                        boxShadow: isDark ? "none" : `1.5px 1.5px 0 0 ${C.dark}`,
                      }}
                    >
                      <p.icon className="h-5 w-5" />
                    </span>
                    <span
                      className="rounded-full px-2.5 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.14em]"
                      style={{
                        background: isDark ? "rgba(232,98,58,0.14)" : "rgba(15,15,15,0.06)",
                        color: isDark ? C.coral : "#8a8a8a",
                        border: isDark ? `1px solid ${C.coral}55` : `1px solid ${C.border}`,
                      }}
                    >
                      0{i + 1} / 04
                    </span>
                  </div>

                  <h3
                    className={`relative z-10 mt-5 font-display font-extrabold leading-tight ${
                      isHero ? "text-[28px] md:text-[34px]" : "text-[20px] md:text-[22px]"
                    }`}
                    style={{ color: isDark ? "#ffffff" : C.text }}
                  >
                    {p.title}
                  </h3>
                  <p
                    className={`relative z-10 mt-2 leading-[1.65] ${
                      isHero ? "text-[15px] md:text-[16px]" : "text-[13.5px]"
                    }`}
                    style={{ color: isDark ? "rgba(255,255,255,0.88)" : C.muted }}
                  >
                    {p.body}
                  </p>

                  {/* interactive footer per persona */}
                  {isHero && <PersonaHeroCodeReel />}
                  {isHero && <PersonaHeroFooter />}
                  {i === 1 && <PersonaFoundersFooter />}
                  {i === 2 && <PersonaFreelancerFooter />}
                  {isDark && <PersonaStudentsFooter />}
                </div>
              </BentoMotion>
            );
          })}
        </div>

      </Section>

      {/* ============ 5. WHAT YOU'RE GETTING — BENTO ============ */}
      <Section bg={C.white} id="what-you-get">
        <div className="mx-auto max-w-[820px] text-center">
          <Pill>
            <Trophy className="h-3 w-3" />
            The OG box
          </Pill>
          <h2
            className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
            style={{ fontSize: "clamp(26px, 5.5vw, 60px)" }}
          >
            Everything in your <Highlighter action="underline" color="#E8623A" strokeWidth={2.5} padding={1} animationDuration={900}>OG badge</Highlighter>.
          </h2>
          <p className="mx-auto mt-5 max-w-[600px] text-[16px] leading-[1.7]" style={{ color: C.muted }}>
            Permanent. Rare. Exclusively yours. Six things you can never buy after August 4.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-3 lg:grid-cols-5">
          {PERKS.map((p, i) => (
            <BentoMotion
              key={p.label}
              index={i}
              className={
                (p.span === 3 ? "lg:col-span-3 " : p.span === 2 ? "lg:col-span-2 md:col-span-2 " : "lg:col-span-1 ") +
                "h-full"
              }
            >
              <BentoPerk p={p} nextNumber={nextNumber} />
            </BentoMotion>
          ))}

        </div>
      </Section>


      {/* ============ 5.5 PERKS COMPARISON (Wave 3) ============ */}
      <PerksComparisonTable />

      {/* ============ 6. WHY WE'RE DOING THIS — dark contrast ============ */}
      <Section bg={C.dark} dark>
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{ background: `radial-gradient(600px circle at 50% 0%, rgba(232,98,58,0.14), transparent 60%)` }}
        />
        <div className="relative mx-auto max-w-[900px] text-center">
          <Pill dark>
            <Heart className="h-3 w-3" />
            The reason we're doing this
          </Pill>
          <h2
            className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em] text-white"
            style={{ fontSize: "clamp(26px, 5.5vw, 64px)" }}
          >
            The first 100 believers get <Highlighter action="highlight" color="rgba(232,98,58,0.38)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>more than a badge</Highlighter>.
          </h2>
          <p className="mx-auto mt-6 max-w-[720px] text-[16px] leading-[1.8] md:text-[18px]">
            <HighlightText
              text="Every category-defining Indian company started with a small tribe of people who showed up before it was obvious. Zerodha had its first 100 traders. Zomato had its first 100 restaurants. VibeCode has you."
              from="rgba(255,255,255,0.35)"
              to="#ffffff"
              accent={["Zerodha", "Zomato", "VibeCode", "you"]}
              accentColor={C.coral}
            />
          </p>

          <p className="mx-auto mt-4 max-w-[720px] text-[16px] leading-[1.8] text-white/80 md:text-[18px]">
            The 100 OGs won't just <em className="not-italic" style={{ color: C.coral }}>get benefits</em>. You'll shape what VibeCode becomes — the features we build, the tone of the community, the founding culture. This is our thank-you for showing up first.
          </p>

          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {[
              { n: String(remaining), l: "OG spots left" },
              { n: "0", l: "Rupees to claim" },
              { n: "1 year", l: "Free Pro included" },
            ].map((s) => (
              <div
                key={s.l}
                className="rounded-[14px] p-6"
                style={{
                  background: C.darkSoft,
                  border: `1px solid #232323`,
                  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.03)",
                }}
              >
                <div className="font-display text-[44px] font-extrabold leading-none" style={{ color: C.coral }}>
                  {s.n}
                </div>
                <div className="mt-2 text-[12px] font-bold uppercase tracking-[0.14em] text-white/60">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ============ 6.5 AVAILABILITY HEATMAP (Wave 1) ============ */}
      <AvailabilityHeatmap taken={taken} total={TOTAL_SPOTS} nextNumber={nextNumber} />

      {/* ============ 7. HOW IT WORKS / TIMELINE ============ */}
      <Section bg={C.cream}>
        <div className="mx-auto max-w-[820px] text-center">
          <Pill soft>
            <Calendar className="h-3 w-3" />
            How it works
          </Pill>
          <h2
            className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
            style={{ fontSize: "clamp(26px, 5.5vw, 60px)" }}
          >
            From today to <Highlighter action="underline" color="#E8623A" strokeWidth={2.5} padding={1} animationDuration={900}>launch day</Highlighter>.
          </h2>
          <p className="mx-auto mt-5 max-w-[560px] text-[16px] leading-[1.7]" style={{ color: C.muted }}>
            Five milestones. Ninety seconds of work from you. The rest happens on autopilot.
          </p>
        </div>

        {/* Premium timeline bento — asymmetric with connector spine */}
        <div className="relative mt-14 grid grid-cols-1 gap-5 md:grid-cols-6 md:auto-rows-[minmax(180px,auto)]">
          {/* animated dashed spine (desktop) */}
          <div
            aria-hidden
            className="pointer-events-none absolute left-0 right-0 top-[92px] hidden md:block"
            style={{
              height: 2,
              background: `repeating-linear-gradient(to right, ${C.dark} 0 8px, transparent 8px 16px)`,
              opacity: 0.35,
            }}
          />
          {TIMELINE.map((t, i) => {
            // Asymmetric spans: 2-2-2, 3-3 for step 4+5
            const span =
              i < 3 ? "md:col-span-2" : i === 3 ? "md:col-span-4" : "md:col-span-2";
            const isLaunch = i === 3;
            const isFinal = i === 4;
            const isCurrent = i === 0;
            return (
              <BentoMotion key={t.d} index={i} className={`${span} h-full`}>
                <div
                  className="group relative flex h-full flex-col overflow-hidden rounded-[16px] p-5 md:p-6 transition-shadow duration-300 hover:shadow-[6px_6px_0_0_#0F0F0F]"
                  style={{
                    background: isLaunch ? C.dark : isFinal ? C.coral : C.white,
                    color: isLaunch || isFinal ? "#fff" : C.text,
                    border: `1.5px solid ${C.dark}`,
                    boxShadow: `3px 3px 0 0 ${C.dark}`,
                  }}
                >
                  {/* diagonal sheen */}
                  <div
                    aria-hidden
                    className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent opacity-0 transition-all duration-[900ms] group-hover:translate-x-full group-hover:opacity-100"
                  />
                  {isLaunch && (
                    <div
                      aria-hidden
                      className="pointer-events-none absolute inset-0"
                      style={{
                        background:
                          "radial-gradient(500px circle at 80% 30%, rgba(232,98,58,0.28), transparent 60%)",
                      }}
                    />
                  )}

                  <div className="relative z-10 flex items-start justify-between">
                    <div
                      className="grid h-11 w-11 place-items-center rounded-full border-[1.5px] font-mono text-[13px] font-extrabold"
                      style={{
                        background: isLaunch || isFinal ? "#fff" : C.coral,
                        borderColor: isLaunch || isFinal ? C.dark : C.dark,
                        color: isLaunch ? C.dark : isFinal ? C.coral : "#fff",
                        boxShadow: `1.5px 1.5px 0 0 ${isLaunch || isFinal ? "rgba(0,0,0,0.35)" : C.dark}`,
                      }}
                    >
                      {String(i + 1).padStart(2, "0")}
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span
                        className="font-mono text-[10px] font-bold uppercase tracking-[0.16em]"
                        style={{
                          color: isLaunch ? "rgba(255,255,255,0.55)" : isFinal ? "rgba(255,255,255,0.75)" : "#8a8a8a",
                        }}
                      >
                        Step {i + 1} of 5
                      </span>
                      {isCurrent && (
                        <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.14em]" style={{ color: C.coral }}>
                          <span className="relative flex h-1.5 w-1.5">
                            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#E8623A] opacity-70" />
                            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#E8623A]" />
                          </span>
                          You are here
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="relative z-10 mt-4 flex items-center gap-3">
                    <span
                      className="rounded-md px-2.5 py-1 font-mono text-[11px] font-extrabold uppercase tracking-[0.14em]"
                      style={{
                        background: isLaunch
                          ? "rgba(232,98,58,0.18)"
                          : isFinal
                            ? "rgba(255,255,255,0.18)"
                            : "rgba(232,98,58,0.10)",
                        color: isLaunch ? C.coral : isFinal ? "#fff" : C.coral,
                        border: `1px solid ${isFinal ? "rgba(255,255,255,0.35)" : C.coral + "55"}`,
                      }}
                    >
                      {t.d}
                    </span>
                    <span
                      className={`text-[26px] transition-transform duration-300 group-hover:scale-125 group-hover:-rotate-6 ${
                        isLaunch ? "drop-shadow-[0_0_18px_rgba(232,98,58,0.6)]" : ""
                      }`}
                    >
                      {t.i}
                    </span>
                  </div>

                  <h3
                    className={`relative z-10 mt-3 font-display font-extrabold leading-tight ${
                      isLaunch ? "text-[24px] md:text-[28px]" : "text-[17px] md:text-[18px]"
                    }`}
                    style={{ color: isLaunch || isFinal ? "#fff" : C.text }}
                  >
                    {t.t}
                  </h3>
                  <p
                    className="relative z-10 mt-2 text-[13px] leading-[1.6]"
                    style={{
                      color: isLaunch
                        ? "rgba(255,255,255,0.75)"
                        : isFinal
                          ? "rgba(255,255,255,0.9)"
                          : C.muted,
                    }}
                  >
                    {t.b}
                  </p>

                  {/* pictorial widget per step */}
                  <TimelineWidget step={i} isLaunch={isLaunch} isFinal={isFinal} />

                  {/* progress bar footer */}
                  <div className="relative z-10 mt-auto pt-5">
                    <div
                      className="h-1.5 w-full overflow-hidden rounded-full"
                      style={{
                        background: isLaunch || isFinal ? "rgba(255,255,255,0.15)" : C.creamDeep,
                        border: `1px solid ${isLaunch || isFinal ? "rgba(255,255,255,0.2)" : C.border}`,
                      }}
                    >
                      <div
                        className="h-full"
                        style={{
                          width: `${(i + 1) * 20}%`,
                          background: isLaunch || isFinal
                            ? "#fff"
                            : `linear-gradient(90deg, ${C.coral}, ${C.gold})`,
                          animation: `ea-progress-fill 900ms ${i * 100 + 200}ms both cubic-bezier(.22,1,.36,1)`,
                          transformOrigin: "left",
                        }}
                      />
                    </div>
                    {isLaunch && (
                      <div className="mt-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.14em] text-white/80">
                        <Flame className="h-3.5 w-3.5" style={{ color: C.coral }} />
                        Auto-activates on this date
                      </div>
                    )}
                  </div>
                </div>
              </BentoMotion>
            );
          })}
        </div>

      </Section>

      {/* ============ 7.5 KINETIC MANIFESTO (Wave 1) ============ */}
      <KineticManifesto />

      {/* ============ 7.75 FOUNDER VIDEO (Wave 2) ============ */}
      <FounderVideoCard />

      {/* ============ 7.8 SCROLL JOURNEY TIMELINE (Wave 3) ============ */}
      <ScrollJourneyTimeline />


      {/* ============ 8. MEET THE FOUNDERS ============ */}
      <Section bg={C.white}>
        <div className="mx-auto max-w-[820px] text-center">
          <Pill soft>
            <Crown className="h-3 w-3" />
            Meet the founders
          </Pill>
          <h2
            className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
            style={{ fontSize: "clamp(26px, 5.5vw, 60px)" }}
          >
            The <Highlighter action="highlight" color="rgba(245,166,35,0.32)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>three humans</Highlighter> building this platform.
          </h2>
          <p className="mx-auto mt-5 max-w-[560px] text-[16px] leading-[1.7]" style={{ color: C.muted }}>
            OG #1, #2, and #3 are reserved for the founding team. Every other spot goes to you.
          </p>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {(() => {
            const founders = wall
              .filter((m) => m.og_number <= 3)
              .concat(
                Array.from({ length: Math.max(0, 3 - wall.filter((m) => m.og_number <= 3).length) }).map(
                  (_, i) =>
                    ({
                      og_number: i + 1,
                      full_name: ["The Founder", "The Co-Founder", "Head of Growth"][i],
                      city: "Bangalore",
                      state: "Karnataka",
                      wall_tagline: [
                        "Building the home Indian AI builders deserve.",
                        "Shipping the platform we wish existed in 2019.",
                        "Getting VibeCode into every builder's hands.",
                      ][i],
                      primary_tool: "lovable",
                      linkedin_url: null,
                      twitter_url: null,
                    }) as WallMember,
                ),
              )
              .slice(0, 3);
            return founders.map((m) => <FounderCard key={m.og_number} m={m} />);
          })()}
        </div>
      </Section>

      {/* ============ 8.5 OG NUMBER SIMULATOR (Wave 1) ============ */}
      <OGNumberSimulator nextNumber={nextNumber} onClaim={scrollToForm} />

      {/* ============ 8.75 BUILDER PERSONALITY QUIZ (Wave 3) ============ */}
      <BuilderPersonalityQuiz />

      {/* ============ 9. FORM ============ */}
      <Section bg={C.cream} id="og-form">
        {step === "terms" ? (
          <TermsStep
            nextNumber={nextNumber}
            submitting={submitting}
            onBack={() => setStep(3)}
            onAccept={() => void submit()}
          />
        ) : step === "success" ? (
          <SuccessBlock
            ogNumber={ogNumber!}
            form={form}
            remaining={remaining}
            alreadyAt={alreadyAt}
          />
        ) : step === "waitlist" || remaining <= 0 ? (
          <WaitlistBlock
            waitEmail={waitEmail}
            setWaitEmail={setWaitEmail}
            waitName={waitName}
            setWaitName={setWaitName}
            waitDone={waitDone}
            onSubmit={joinWaitlist}
          />
        ) : (
          <div className="mx-auto max-w-[640px]">
            <div className="text-center">
              <Pill>
                <Lock className="h-3 w-3" />
                Reserve your builder number
              </Pill>
              <h2
                className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
                style={{ fontSize: "clamp(26px, 5.5vw, 56px)" }}
              >
                Claim <Highlighter action="underline" color="#E8623A" strokeWidth={2.5} padding={1} animationDuration={900}>Builder</Highlighter>
              </h2>
              <div
                className="mt-3 font-display font-extrabold leading-none"
                style={{ color: C.coral, fontSize: "clamp(64px, 10vw, 96px)", fontFeatureSettings: "'tnum'" }}
              >
                #{nextNumber}
              </div>
              <div className="mt-3 text-[13px] font-bold uppercase tracking-[0.12em] text-[#7a7a7a]">
                {remaining} of {TOTAL_SPOTS} spots remaining
              </div>
            </div>

            <StepIndicator step={step as number} />

            <div
              className="mt-8 rounded-[16px] p-6 md:p-8"
              style={{
                background: C.white,
                border: `1.5px solid ${C.dark}`,
                boxShadow: `4px 4px 0 0 ${C.dark}`,
              }}
            >
              {step === 1 && <Step1 form={form} setForm={setForm} onNext={() => goNext(1)} verifiedEmail={verifiedEmail} />}
              {step === 2 && (
                <Step2
                  form={form}
                  setForm={setForm}
                  nextNumber={nextNumber}
                  onBack={() => setStep(1)}
                  onNext={() => goNext(2)}
                />
              )}
              {step === 3 && (
                <Step3
                  form={form}
                  setForm={setForm}
                  nextNumber={nextNumber}
                  submitting={submitting}
                  onBack={() => setStep(2)}
                  onSubmit={() => goNext(3)}
                />
              )}
            </div>
          </div>
        )}
      </Section>

      {/* ============ 10. FOUNDERS WALL ============ */}
      <Section bg={C.white}>
        <div className="mx-auto max-w-[820px] text-center">
          <Pill soft>
            <Award className="h-3 w-3" />
            The Founders Wall
          </Pill>
          <h2
            className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
            style={{ fontSize: "clamp(26px, 5.5vw, 60px)" }}
          >
            Every OG. Their name, <Highlighter action="underline" color="#E8623A" strokeWidth={2.5} padding={1} animationDuration={900}>here, forever</Highlighter>.
          </h2>
          <p className="mx-auto mt-5 max-w-[560px] text-[16px] leading-[1.7]" style={{ color: C.muted }}>
            Wall updates the moment you claim. Empty slots go dashed until they fill.
          </p>
          <div
            className="mx-auto mt-5 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-[12px] font-bold uppercase tracking-[0.14em]"
            style={{ background: C.coralSoft, color: C.coral, border: `1px solid ${C.coral}33` }}
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#E8623A] opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[#E8623A]" />
            </span>
            {taken} of 100 seats filled
          </div>

          <div className="mt-5">
            <Link
              to="/founders-wall"
              className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-[12px] font-extrabold uppercase tracking-[0.14em] transition-transform active:scale-95"
              style={{
                background: C.dark,
                color: "#fff",
                border: `1.5px solid ${C.dark}`,
                boxShadow: `2px 2px 0 0 ${C.gold}`,
              }}
            >
              <Crown className="h-3.5 w-3.5" style={{ color: C.gold }} />
              See the full Founders Wall
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>

        </div>

        <div className="mt-10">
          <LiveJoinsStrip members={wall} />
        </div>



        {(() => {
          const realCards = wall;
          const emptyCount = Math.max(0, TOTAL_SPOTS - wall.length);
          const allEmpties = Array.from({ length: emptyCount }).slice(0, 24);
          const MOBILE_LIMIT = 4;
          const mobileReal = realCards.slice(0, MOBILE_LIMIT);
          const mobileEmpties = allEmpties.slice(0, Math.max(0, MOBILE_LIMIT - mobileReal.length));
          const hiddenOnMobile = (realCards.length + allEmpties.length) - (mobileReal.length + mobileEmpties.length);
          return (
            <>
              <div className="mt-12 grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                {/* Mobile: limited set (hidden on sm+) */}
                {!wallExpanded && (
                  <div className="contents sm:hidden">
                    {mobileReal.map((m, i) => (
                      <BentoMotion key={`m-${m.og_number}`} index={i}>
                        <WallCard m={m} />
                      </BentoMotion>
                    ))}
                    {mobileEmpties.map((_, i) => (
                      <BentoMotion key={`m-empty-${i}`} index={mobileReal.length + i}>
                        <div
                          className="flex h-full flex-col items-center justify-center rounded-[14px] p-6 ea-empty-slot"
                          style={{ background: C.cream, border: `1.5px dashed ${C.border}`, minHeight: 160 }}
                        >
                          <div className="text-[28px] font-extrabold text-[#c9c0af]">?</div>
                          <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.14em] text-[#a89f8d]">Open spot</div>
                        </div>
                      </BentoMotion>
                    ))}
                  </div>
                )}
                {/* Desktop always + mobile when expanded */}
                <div className={`contents ${wallExpanded ? "" : "hidden sm:contents"}`}>
                  {realCards.map((m, i) => (
                    <BentoMotion key={m.og_number} index={i}>
                      <WallCard m={m} />
                    </BentoMotion>
                  ))}
                  {allEmpties.map((_, i) => (
                    <BentoMotion key={`empty-${i}`} index={realCards.length + i}>
                      <div
                        className="flex h-full flex-col items-center justify-center rounded-[14px] p-6 ea-empty-slot"
                        style={{ background: C.cream, border: `1.5px dashed ${C.border}`, minHeight: 160, animationDelay: `${(i % 8) * 120}ms` }}
                      >
                        <div className="text-[28px] font-extrabold text-[#c9c0af]">?</div>
                        <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.14em] text-[#a89f8d]">Open spot</div>
                      </div>
                    </BentoMotion>
                  ))}
                </div>

              </div>

              {/* Mobile: link to full Founders Wall page */}
              {hiddenOnMobile > 0 && (
                <div className="mt-6 flex justify-center sm:hidden">
                  <Link
                    to="/founders-wall"
                    className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-[13px] font-extrabold uppercase tracking-[0.12em] transition-transform active:scale-95"
                    style={{
                      background: C.dark,
                      color: "#fff",
                      border: `1.5px solid ${C.dark}`,
                      boxShadow: `2px 2px 0 0 ${C.coral}`,
                    }}
                  >
                    {`More — click to expand (${hiddenOnMobile})`}
                    <span className="inline-block">→</span>
                  </Link>
                </div>
              )}
            </>
          );
        })()}
      </Section>

      {/* ============ 10.5 TESTIMONIAL MASONRY (Wave 2) ============ */}
      <TestimonialMasonry />

      {/* ============ 11. FAQ ============ */}
      <Section bg={C.cream}>
        <div className="mx-auto max-w-[760px]">
          <div className="text-center">
            <Pill soft>
              <MessageCircle className="h-3 w-3" />
              Answered
            </Pill>
            <h2
              className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
              style={{ fontSize: "clamp(26px, 5.5vw, 56px)" }}
            >
              Everything you were about to <Highlighter action="highlight" color="rgba(245,166,35,0.32)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>ask</Highlighter>.
            </h2>
          </div>

          <div className="mt-10 space-y-3">
            {FAQ.map((f, i) => (
              <div
                key={f.q}
                className="overflow-hidden rounded-[14px]"
                style={{
                  background: C.white,
                  border: `1.5px solid ${C.dark}`,
                  boxShadow: `2px 2px 0 0 ${C.dark}`,
                }}
              >
                <button
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                >
                  <span className="font-display text-[16px] font-extrabold md:text-[18px]">{f.q}</span>
                  <span
                    className="grid h-7 w-7 shrink-0 place-items-center rounded-full border-[1.5px] text-[14px] font-extrabold transition-transform"
                    style={{
                      background: openFaq === i ? C.coral : C.cream,
                      borderColor: C.dark,
                      color: openFaq === i ? "#fff" : C.dark,
                      transform: openFaq === i ? "rotate(45deg)" : "none",
                    }}
                  >
                    +
                  </span>
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-5 text-[14.5px] leading-[1.7]" style={{ color: C.muted }}>
                    {f.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ============ 12. FINAL CTA ============ */}
      <Section bg={C.dark} dark>
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{ background: `radial-gradient(700px circle at 50% 100%, rgba(232,98,58,0.18), transparent 60%)` }}
        />
        <div className="relative mx-auto max-w-[820px] text-center">
          <Pill dark>
            <Flame className="h-3 w-3" />
            One last thing
          </Pill>
          <h2
            className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em] text-white"
            style={{ fontSize: "clamp(28px, 6.5vw, 72px)" }}
          >
            The clock is <Highlighter action="underline" color="#F5A623" strokeWidth={2.5} padding={1} animationDuration={900}>running</Highlighter>.
          </h2>
          <p className="mx-auto mt-6 max-w-[560px] text-[16px] leading-[1.75] text-white/80 md:text-[18px]">
            Every hour, another builder claims their OG number. There are <Highlighter action="highlight" color="rgba(232,98,58,0.32)" strokeWidth={1.5} padding={3} iterations={2} animationDuration={900}><b style={{ color: C.coral }}>only {remaining} spots left</b></Highlighter>. When they're gone, they're gone. Forever.
          </p>
          <div className="mt-8 flex justify-center">
            <CountdownTicker target={LAUNCH_DATE} variant="dark" />
          </div>

          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <button className="btn-coral h-14 px-8 text-[15px]" onClick={scrollToForm} disabled={remaining <= 0}>
              <Flame className="h-4 w-4" />
              {remaining <= 0 ? "Join the Waitlist" : `Claim Builder #${nextNumber} Now`}
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
          <div className="mt-5 text-[12px] font-semibold text-white/60">
            Takes 90 seconds · Locks in permanently · Never charged
          </div>
        </div>

        {/* ============ Signature — Vibecoder 3D flip wordmark ============ */}
        <div className="relative mt-24 flex flex-col items-center">
          <div
            className="mb-5 inline-flex items-center gap-2 rounded-full border-[1.5px] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.22em]"
            style={{ background: "rgba(255,255,255,0.06)", borderColor: "rgba(245,240,232,0.25)", color: "rgba(245,240,232,0.75)" }}
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: C.coral, boxShadow: `0 0 10px ${C.coral}` }} />
            Made in India · For builders
          </div>

          <Text3DFlip
            className="text-center font-display font-black leading-[0.9] tracking-[-0.04em]"
            textClassName="text-white"
            flipTextClassName=""
            rotateDirection="top"
            staggerDuration={0.05}
            staggerFrom="center"
            transition={{ type: "spring", damping: 22, stiffness: 150 }}
            accentWords={["coder"]}
            accentColor={C.coral}
          >
            {"vibe coder"}
          </Text3DFlip>

          <div
            aria-hidden
            className="mt-4 h-[2px] w-40"
            style={{ background: `linear-gradient(90deg, transparent, ${C.coral} 50%, transparent)` }}
          />
          <div className="mt-3 font-mono text-[10px] font-semibold uppercase tracking-[0.28em] text-white/40">
            joinvibecode.xyz — v1.0 · aug 4, 2026
          </div>
        </div>
      </Section>

      {/* ============ Dock ============ */}
      <LandingDock />

      {/* ============ Kinetic wordmark — below dock ============ */}
      <section
        className="relative overflow-hidden py-20 md:py-28"
        style={{ background: C.dark }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(700px circle at 50% 60%, rgba(232,98,58,0.14), transparent 65%)",
          }}
        />
        <div className="relative flex items-center justify-center">
          <KineticText
            text="vibecoder"
            splitAt={4}
            className="text-[22vw] tracking-[-0.06em] md:text-[16rem]"
          />
        </div>
        <div
          className="relative mx-auto mt-6 text-center font-mono text-[11px] uppercase tracking-[0.3em]"
          style={{ color: "#5a5a5a" }}
        >
          Built in India · For builders, by builders
        </div>
      </section>


      {/* ============ Sticky claim bar (Wave 1) ============ */}
      <StickyClaimBar remaining={remaining} nextNumber={nextNumber} onClaim={scrollToForm} />

      {/* ============ Celebration overlay (Wave 1) ============ */}
      <CelebrationOverlay
        open={celebrateOpen}
        ogNumber={ogNumber}
        name={form.fullName}
        onClose={() => setCelebrateOpen(false)}
      />


      <style>{`
        @keyframes ea-slide-in {
          from { opacity: 0; transform: translateX(-24px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes ea-badge-in {
          0%   { opacity: 0; transform: scale(.55) rotate(-6deg); }
          60%  { transform: scale(1.08) rotate(3deg); }
          100% { opacity: 1; transform: scale(1) rotate(0deg); }
        }
        @keyframes ea-confetti-fall {
          to { transform: translate(var(--tx), var(--ty)) rotate(720deg); opacity: 0; }
        }
        @keyframes ea-gradient-pan {
          0%   { background-position: 0% 50%; }
          100% { background-position: 200% 50%; }
        }

        .ea-confetti-piece {
          position: absolute;
          top: -10px;
          width: 10px;
          height: 14px;
          animation: ea-confetti-fall 2.4s cubic-bezier(.19,.86,.5,1) forwards;
        }
      `}</style>
    </div>
  );
}

/* ============================================================
   Section shell
   ============================================================ */
function ShareMenu({ C, remaining }: { C: any; remaining: number }) {
  const [open, setOpen] = useState(false);
  const url = typeof window !== "undefined" ? window.location.href : "https://joinvibecode.xyz/early-access";
  const text = `Only ${remaining} OG spots left on VibeCode — India's AI builder community. Free Pro for 1 year for the first 100 builders. Launching Aug 4, 2026.`;
  const enc = encodeURIComponent;
  const links = [
    { label: "WhatsApp", href: `https://wa.me/?text=${enc(text + " " + url)}` },
    { label: "Twitter / X", href: `https://twitter.com/intent/tweet?text=${enc(text)}&url=${enc(url)}` },
    { label: "LinkedIn", href: `https://www.linkedin.com/sharing/share-offsite/?url=${enc(url)}` },
    { label: "Telegram", href: `https://t.me/share/url?url=${enc(url)}&text=${enc(text)}` },
  ];

  const nativeShare = async () => {
    if (typeof navigator !== "undefined" && (navigator as any).share) {
      try {
        await (navigator as any).share({ title: "VibeCode — Early Access", text, url });
        return true;
      } catch {}
    }
    return false;
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Link copied!");
    } catch {
      toast.error("Couldn't copy link");
    }
    setOpen(false);
  };

  const onClick = async () => {
    const shared = await nativeShare();
    if (!shared) setOpen((v) => !v);
  };

  return (
    <div className="relative">
      <button
        onClick={onClick}
        className="inline-flex h-9 items-center gap-1.5 rounded-[8px] border-[1.5px] bg-white px-3 text-[12px] font-bold"
        style={{ borderColor: C.dark, color: C.text, boxShadow: `2px 2px 0 0 ${C.dark}` }}
        aria-label="Share this page"
      >
        <Share2 className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Share</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div
            className="absolute right-0 top-[calc(100%+8px)] z-50 w-48 overflow-hidden rounded-[10px] border-[1.5px] bg-white"
            style={{ borderColor: C.dark, boxShadow: `4px 4px 0 0 ${C.dark}` }}
          >
            {links.map((l) => (
              <a
                key={l.label}
                href={l.href}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setOpen(false)}
                className="block px-3 py-2 text-[13px] font-semibold hover:bg-[#FAF6F1]"
                style={{ color: C.text }}
              >
                {l.label}
              </a>
            ))}
            <button
              onClick={copy}
              className="flex w-full items-center gap-2 border-t px-3 py-2 text-left text-[13px] font-semibold hover:bg-[#FAF6F1]"
              style={{ color: C.text, borderColor: C.border }}
            >
              <CopyIcon className="h-3.5 w-3.5" /> Copy link
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function Section({
  children,
  bg,
  id,
  dark = false,
}: {
  children: React.ReactNode;
  bg: string;
  id?: string;
  dark?: boolean;
}) {
  return (
    <section
      id={id}
      className={`relative w-full overflow-hidden py-10 md:py-24 ${dark ? "text-white" : ""}`}
      style={{ background: bg }}
    >
      <div className="relative mx-auto w-full max-w-[1200px] px-4 md:px-8">{children}</div>
    </section>
  );
}

/* ============================================================
   Pill
   ============================================================ */
function Pill({
  children,
  soft = false,
  dark = false,
}: {
  children: React.ReactNode;
  soft?: boolean;
  dark?: boolean;
}) {
  const styles: React.CSSProperties = dark
    ? {
        background: "rgba(232,98,58,0.14)",
        color: C.coral,
        border: `1px solid ${C.coral}55`,
      }
    : soft
      ? {
          background: C.coralSoft,
          color: C.coral,
          border: `1px solid ${C.coral}33`,
        }
      : {
          background: C.coral,
          color: "#fff",
          boxShadow: "0 6px 20px -6px rgba(232,98,58,0.6)",
        };
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[9.5px] font-bold uppercase tracking-[0.12em] md:px-3.5 md:py-1.5 md:text-[11px] md:tracking-[0.14em]"
      style={styles}
    >
      {children}
    </span>
  );
}

/* ============================================================
   Persona bento footers — pictorial data widgets
   ============================================================ */
/* Timeline step pictorial widget */
function TimelineWidget({ step, isLaunch, isFinal }: { step: number; isLaunch: boolean; isFinal: boolean }) {
  const onDark = isLaunch || isFinal;
  const chip = onDark ? "rgba(255,255,255,0.08)" : "#FAF6F1";
  const chipBorder = onDark ? "rgba(255,255,255,0.18)" : "#0F0F0F";
  const chipText = onDark ? "#fff" : "#0F0F0F";
  const softText = onDark ? "rgba(255,255,255,0.6)" : "#8a8a8a";

  // Step 0 — Claim form preview
  if (step === 0) {
    return (
      <div className="relative z-10 mt-4 rounded-[10px] border-[1.5px] p-2.5" style={{ background: chip, borderColor: chipBorder }}>
        <div className="mb-1.5 text-[9px] font-bold uppercase tracking-[0.16em]" style={{ color: softText }}>Claim form · 90s</div>
        <div className="flex items-center gap-1.5 rounded-md bg-white/95 px-2 py-1.5" style={{ border: "1px solid #0F0F0F" }}>
          <span className="font-mono text-[11px] font-extrabold text-black">Ananya S.</span>
          <span className="ml-auto h-3 w-[1.5px] animate-blink-cursor bg-[#E8623A]" />
        </div>
        <div className="mt-1.5 flex items-center gap-1.5 text-[10px] font-bold" style={{ color: softText }}>
          <span className="grid h-3.5 w-3.5 place-items-center rounded-sm bg-[#E8623A] text-[9px] text-white">✓</span>
          Reserved OG #04
        </div>
      </div>
    );
  }

  // Step 1 — Email envelope
  if (step === 1) {
    return (
      <div className="relative z-10 mt-4 rounded-[10px] border-[1.5px] px-3 py-2.5" style={{ background: chip, borderColor: chipBorder }}>
        <div className="flex items-center gap-2">
          <div className="grid h-8 w-10 shrink-0 place-items-center rounded-md border-[1.5px] font-mono text-[11px] font-extrabold" style={{ background: "#fff", borderColor: "#0F0F0F", color: "#0F0F0F", boxShadow: "1.5px 1.5px 0 0 #0F0F0F" }}>
            ✉
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate font-mono text-[11px] font-extrabold" style={{ color: chipText }}>from: founders@vibecode</div>
            <div className="truncate text-[10px]" style={{ color: softText }}>Your first OG update →</div>
          </div>
          <span className="rounded-full px-1.5 py-0.5 text-[9px] font-extrabold" style={{ background: "#E8623A", color: "#fff" }}>NEW</span>
        </div>
      </div>
    );
  }

  // Step 2 — Zoom avatars grid
  if (step === 2) {
    const cells = ["A", "R", "V", "K", "M", "S"];
    return (
      <div className="relative z-10 mt-4 rounded-[10px] border-[1.5px] p-2" style={{ background: chip, borderColor: chipBorder }}>
        <div className="grid grid-cols-6 gap-1">
          {cells.map((c, k) => (
            <div
              key={k}
              className="grid aspect-square place-items-center rounded-[4px] font-mono text-[10px] font-extrabold"
              style={{
                background: k === 0 ? "#E8623A" : ["#FFF1EA", "#FFE9E6", "#FFF6E6", "#F5F0E8", "#FAF6F1", "#FFF1EA"][k],
                color: k === 0 ? "#fff" : "#0F0F0F",
                border: "1px solid #0F0F0F",
                animation: `ea-badge-in 400ms ${k * 60}ms both`,
              }}
            >
              {c}
            </div>
          ))}
        </div>
        <div className="mt-1.5 flex items-center gap-1 text-[9px] font-bold uppercase tracking-[0.14em]" style={{ color: softText }}>
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#E8623A]" />
          Live · 6 OGs on call
        </div>
      </div>
    );
  }

  // Step 3 — Launch rocket trajectory
  if (step === 3) {
    return (
      <div className="relative z-10 mt-4 overflow-hidden rounded-[10px] border-[1.5px] p-2.5" style={{ background: chip, borderColor: chipBorder }}>
        <svg viewBox="0 0 220 44" className="h-11 w-full">
          <path id={`ea-rocket-path-${step}`} d="M4 40 Q 60 38, 100 26 T 210 4" fill="none" stroke="#E8623A" strokeWidth="2" strokeLinecap="round" strokeDasharray="4 4" className="ea-flow-dash" />
          <circle cx="4" cy="40" r="2.5" fill="#fff" stroke="#E8623A" strokeWidth="1.5" />
          <g fontSize="14">
            <text>🚀
              <animateMotion dur="2.6s" repeatCount="indefinite" rotate="auto" path="M4 40 Q 60 38, 100 26 T 210 4" />
            </text>
          </g>
        </svg>
        <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-[0.14em]">
          <span style={{ color: softText }}>T-0 · Aug 04</span>
          <span style={{ color: "#E8623A" }}>Pro · Coins · Badge</span>
        </div>
      </div>
    );
  }

  // Step 4 — Wall of names ticker
  const names = ["Ananya · Blr", "Rohan · Del", "Vikram · Mum", "Kavya · Pune"];
  return (
    <div className="relative z-10 mt-4 space-y-1 rounded-[10px] border-[1.5px] p-2" style={{ background: chip, borderColor: chipBorder }}>
      <div className="text-[9px] font-bold uppercase tracking-[0.16em] text-white/70">Founders Wall · live</div>
      {names.map((n, k) => (
        <div
          key={n}
          className="flex items-center gap-2 rounded-[6px] px-2 py-1 font-mono text-[10.5px] font-extrabold text-white"
          style={{ background: "rgba(255,255,255,0.12)", animation: `ea-badge-in 500ms ${k * 120}ms both` }}
        >
          <span className="rounded-sm px-1 text-[9px]" style={{ background: "#fff", color: "#E8623A" }}>0{k + 1}</span>
          {n}
        </div>
      ))}
    </div>
  );
}

function PersonaHeroCodeReel() {
  const snippets = useMemo(
    () => [
      {
        file: "invoice-gpt/app.ts",
        lang: "ts",
        lines: [
          { t: "import", c: "kw" },
          { t: " { ai } ", c: "tx" },
          { t: "from", c: "kw" },
          { t: " 'lovable/ai'\n", c: "str" },
          { t: "export async function ", c: "kw" },
          { t: "generate", c: "fn" },
          { t: "(prompt: ", c: "tx" },
          { t: "string", c: "ty" },
          { t: ") {\n  ", c: "tx" },
          { t: "const", c: "kw" },
          { t: " invoice = ", c: "tx" },
          { t: "await", c: "kw" },
          { t: " ai.", c: "tx" },
          { t: "run", c: "fn" },
          { t: "({\n    model: ", c: "tx" },
          { t: "'gpt-4o'", c: "str" },
          { t: ",\n    schema: ", c: "tx" },
          { t: "Invoice", c: "ty" },
          { t: ",\n    prompt,\n  })\n  ", c: "tx" },
          { t: "return", c: "kw" },
          { t: " invoice\n}\n", c: "tx" },
          { t: "// → ₹42K MRR in 6 weeks", c: "cm" },
        ],
      },
      {
        file: "leadflow.n8n.json",
        lang: "json",
        lines: [
          { t: "{\n  ", c: "tx" },
          { t: '"trigger"', c: "ky" },
          { t: ": ", c: "tx" },
          { t: '"webhook"', c: "str" },
          { t: ",\n  ", c: "tx" },
          { t: '"nodes"', c: "ky" },
          { t: ": [\n    { ", c: "tx" },
          { t: '"type"', c: "ky" },
          { t: ": ", c: "tx" },
          { t: '"gpt.classify"', c: "str" },
          { t: " },\n    { ", c: "tx" },
          { t: '"type"', c: "ky" },
          { t: ": ", c: "tx" },
          { t: '"slack.notify"', c: "str" },
          { t: " },\n    { ", c: "tx" },
          { t: '"type"', c: "ky" },
          { t: ": ", c: "tx" },
          { t: '"hubspot.upsert"', c: "str" },
          { t: " }\n  ],\n  ", c: "tx" },
          { t: '"ship"', c: "ky" },
          { t: ": ", c: "tx" },
          { t: "true", c: "kw" },
          { t: "\n}\n", c: "tx" },
          { t: "// 312 buyers · $18/mo", c: "cm" },
        ],
      },
      {
        file: "promptstash.chrome.tsx",
        lang: "tsx",
        lines: [
          { t: "export default function ", c: "kw" },
          { t: "Popup", c: "fn" },
          { t: "() {\n  ", c: "tx" },
          { t: "const", c: "kw" },
          { t: " [q, setQ] = ", c: "tx" },
          { t: "useState", c: "fn" },
          { t: "(", c: "tx" },
          { t: "''", c: "str" },
          { t: ")\n  ", c: "tx" },
          { t: "return", c: "kw" },
          { t: " (\n    <", c: "tx" },
          { t: "Command", c: "ty" },
          { t: " onSearch={setQ}>\n      <", c: "tx" },
          { t: "PromptList", c: "ty" },
          { t: " query={q} />\n    </", c: "tx" },
          { t: "Command", c: "ty" },
          { t: ">\n  )\n}\n", c: "tx" },
          { t: "// 8.2K weekly active users", c: "cm" },
        ],
      },
    ],
    [],
  );

  const [idx, setIdx] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const snippet = snippets[idx];
  const fullText = useMemo(() => snippet.lines.map((l) => l.t).join(""), [snippet]);

  useEffect(() => {
    setCharCount(0);
    let i = 0;
    const iv = window.setInterval(() => {
      i += 2;
      if (i >= fullText.length) {
        window.clearInterval(iv);
        setCharCount(fullText.length);
        window.setTimeout(() => setIdx((n) => (n + 1) % snippets.length), 2600);
      } else {
        setCharCount(i);
      }
    }, 22);
    return () => window.clearInterval(iv);
  }, [idx, fullText, snippets.length]);

  const colorFor = (c: string) => {
    switch (c) {
      case "kw": return "#ff7ab6"; // keyword pink
      case "fn": return "#f5a623"; // function amber
      case "ty": return "#7ee7c7"; // type mint
      case "str": return "#ffd479"; // string
      case "ky": return "#7cc4ff"; // json key
      case "cm": return "#6b7a70"; // comment
      default: return "#e6e6e6";
    }
  };

  // Slice tokens so typing reveals progressively
  let remaining = charCount;
  const rendered: Array<{ t: string; c: string }> = [];
  for (const tok of snippet.lines) {
    if (remaining <= 0) break;
    if (tok.t.length <= remaining) {
      rendered.push(tok);
      remaining -= tok.t.length;
    } else {
      rendered.push({ t: tok.t.slice(0, remaining), c: tok.c });
      remaining = 0;
    }
  }
  const lineCount = fullText.slice(0, charCount).split("\n").length;

  return (
    <div
      className="relative z-10 mt-6 overflow-hidden rounded-[14px] border-[1.5px]"
      style={{
        background: "#0B0B0C",
        borderColor: "#0F0F0F",
        boxShadow: "4px 4px 0 0 #0F0F0F",
      }}
    >
      {/* chrome */}
      <div
        className="flex items-center gap-2 border-b px-3.5 py-2"
        style={{ borderColor: "#1c1c1e", background: "#111112" }}
      >
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: "#ff5f57" }} />
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: "#febc2e" }} />
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: "#28c840" }} />
        <span className="ml-2 font-mono text-[10.5px] tracking-tight text-white/55">
          {snippet.file}
        </span>
        <span
          className="ml-auto rounded-full px-2 py-0.5 font-mono text-[9.5px] font-bold uppercase tracking-[0.14em]"
          style={{ background: "rgba(232,98,58,0.16)", color: "#E8623A" }}
        >
          {snippet.lang}
        </span>
      </div>

      {/* code body with gutter */}
      <div className="relative flex px-3.5 py-3">
        <div
          className="select-none pr-3 text-right font-mono text-[11px] leading-[1.55]"
          style={{ color: "#3d3d40", minWidth: "1.6rem" }}
        >
          {Array.from({ length: Math.max(lineCount, 10) }).map((_, k) => (
            <div key={k}>{String(k + 1).padStart(2, "0")}</div>
          ))}
        </div>
        <pre
          className="flex-1 whitespace-pre-wrap break-words font-mono text-[11.5px] leading-[1.55]"
          style={{ color: "#e6e6e6", margin: 0 }}
        >
          {rendered.map((tok, k) => (
            <span key={k} style={{ color: colorFor(tok.c) }}>
              {tok.t}
            </span>
          ))}
          {charCount < fullText.length && (
            <span
              className="ml-0.5 inline-block h-[0.95em] w-[6px] -mb-[2px] align-[-2px]"
              style={{
                background: "#E8623A",
                animation: "ea-cursor-blink 1s steps(2) infinite",
              }}
            />
          )}
        </pre>
        {/* soft top glow */}
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-8"
          style={{ background: "linear-gradient(180deg, rgba(232,98,58,0.10), transparent)" }}
        />
      </div>
      <style>{`@keyframes ea-cursor-blink { 50% { opacity: 0; } }`}</style>
    </div>
  );
}

function PersonaHeroFooter() {
  const tools = ["Lovable", "Cursor", "n8n", "Claude", "Make", "GPT-4o", "Replit", "Bolt"];
  const ships = [
    { emoji: "🚀", name: "InvoiceGPT", tag: "Micro-SaaS", mrr: "₹42K MRR" },
    { emoji: "🧩", name: "PromptStash", tag: "Chrome ext", mrr: "8.2K users" },
    { emoji: "⚙️", name: "LeadFlow.n8n", tag: "Workflow", mrr: "312 buyers" },
  ];
  return (
    <div className="relative z-10 mt-auto grid gap-5 pt-6 md:grid-cols-2">
      {/* Left — tool chips */}
      <div>
        <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.18em]" style={{ color: "#a09680" }}>
          Tools you ship with
        </div>
        <div className="flex flex-wrap gap-1.5">
          {tools.map((t, k) => (
            <span
              key={t}
              className="rounded-full border-[1.5px] px-3 py-1 text-[11.5px] font-semibold transition-transform hover:-translate-y-0.5"
              style={{
                background: "#FAF6F1",
                borderColor: "#0F0F0F",
                color: "#0F0F0F",
                boxShadow: `1.5px 1.5px 0 0 #0F0F0F`,
                animation: `ea-badge-in 500ms ${k * 60}ms both`,
              }}
            >
              {t}
            </span>
          ))}
        </div>
      </div>
      {/* Right — live shipping feed */}
      <div>
        <div className="mb-2 flex items-center justify-between text-[10px] font-bold uppercase tracking-[0.18em]" style={{ color: "#a09680" }}>
          <span>Live shipping now</span>
          <span className="flex items-center gap-1" style={{ color: "#E8623A" }}>
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#E8623A] opacity-70" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#E8623A]" />
            </span>
            LIVE
          </span>
        </div>
        <div className="space-y-1.5">
          {ships.map((s, k) => (
            <div
              key={s.name}
              className="flex items-center gap-2 rounded-[10px] border-[1.5px] bg-white px-2.5 py-2"
              style={{
                borderColor: "#0F0F0F",
                boxShadow: `1.5px 1.5px 0 0 #0F0F0F`,
                animation: `ea-badge-in 600ms ${k * 130 + 200}ms both`,
              }}
            >
              <span className="grid h-7 w-7 place-items-center rounded-md bg-[#FFF1EA] text-[14px]">{s.emoji}</span>
              <div className="min-w-0 flex-1">
                <div className="truncate font-mono text-[11.5px] font-extrabold">{s.name}</div>
                <div className="truncate text-[10px] font-semibold" style={{ color: "#8a8a8a" }}>{s.tag}</div>
              </div>
              <span
                className="rounded-full px-2 py-0.5 font-mono text-[10px] font-bold"
                style={{ background: "#0F0F0F", color: "#F5A623" }}
              >
                {s.mrr}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PersonaFoundersFooter() {
  const bars = [35, 55, 42, 78, 62, 88, 72];
  const avatars = ["A", "P", "S", "R", "M"];
  return (
    <div className="relative z-10 mt-auto space-y-4 pt-6">
      <div>
        <div className="flex items-end gap-1.5">
          {bars.map((h, k) => (
            <div
              key={k}
              className="w-3 rounded-t-[3px] ea-bar"
              style={{
                height: `${h * 0.55}px`,
                background: k === 5 ? "#E8623A" : "#0F0F0F",
                opacity: 0.85,
                transformOrigin: "bottom",
                animation: `ea-bar-rise 700ms ${k * 60}ms both, ea-bar-wave 2.6s ${900 + k * 120}ms ease-in-out infinite`,
              }}
            />
          ))}
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] font-semibold" style={{ color: "#8a8a8a" }}>
          <span>Hiring velocity</span>
          <span style={{ color: "#E8623A" }}>▲ 3.2×</span>
        </div>
      </div>
      {/* applicant stack */}
      <div className="flex items-center gap-3 rounded-[10px] border-[1.5px] bg-white px-2.5 py-2" style={{ borderColor: "#0F0F0F", boxShadow: `1.5px 1.5px 0 0 #0F0F0F` }}>
        <div className="flex -space-x-2">
          {avatars.map((a, k) => (
            <span
              key={k}
              className="grid h-7 w-7 place-items-center rounded-full border-[1.5px] font-mono text-[11px] font-extrabold"
              style={{
                background: ["#FFF1EA", "#FFE9E6", "#FFF6E6", "#F5F0E8", "#E8623A"][k],
                color: k === 4 ? "#fff" : "#0F0F0F",
                borderColor: "#0F0F0F",
                animation: `ea-badge-in 500ms ${k * 90}ms both`,
              }}
            >
              {a}
            </span>
          ))}
        </div>
        <div className="min-w-0 flex-1">
          <div className="font-mono text-[11px] font-extrabold">12 shippers/day</div>
          <div className="text-[10px]" style={{ color: "#8a8a8a" }}>Real builds. No resumes.</div>
        </div>
      </div>
    </div>
  );
}

function PersonaFreelancerFooter() {
  // Sparkline: rising rate curve
  const pts = [
    [4, 46], [22, 42], [40, 34], [58, 28], [76, 20], [94, 14], [112, 10],
  ] as const;
  const path = pts.map((p, i) => (i === 0 ? `M${p[0]} ${p[1]}` : `L${p[0]} ${p[1]}`)).join(" ");
  const area = `${path} L112 56 L4 56 Z`;
  return (
    <div className="relative z-10 mt-auto space-y-3 pt-6">
      <div className="flex items-end justify-between">
        <div>
          <div className="text-[10px] font-bold uppercase tracking-[0.16em]" style={{ color: "#a09680" }}>Avg hourly</div>
          <div className="font-display text-[26px] font-extrabold leading-none">
            $180<span className="text-[14px]" style={{ color: "#8a8a8a" }}>/hr</span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-[10px] font-bold uppercase tracking-[0.16em]" style={{ color: "#a09680" }}>From</div>
          <div className="font-mono text-[13px] font-extrabold line-through" style={{ color: "#8a8a8a" }}>$25/hr</div>
        </div>
      </div>
      <div className="rounded-[10px] border-[1.5px] bg-white p-2" style={{ borderColor: "#0F0F0F", boxShadow: `1.5px 1.5px 0 0 #0F0F0F` }}>
        <svg viewBox="0 0 116 60" className="h-14 w-full">
          <defs>
            <linearGradient id="sparkFill" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#E8623A" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#E8623A" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={area} fill="url(#sparkFill)" />
          <path d={path} fill="none" stroke="#E8623A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ strokeDasharray: 300, strokeDashoffset: 300, animation: "ea-progress-fill 1200ms 300ms cubic-bezier(.22,1,.36,1) forwards" }} />
          {pts.map((p, i) => (
            <circle key={i} cx={p[0]} cy={p[1]} r={i === pts.length - 1 ? 3 : 1.6} fill={i === pts.length - 1 ? "#E8623A" : "#0F0F0F"} style={{ opacity: 0, animation: `ea-badge-in 300ms ${600 + i * 90}ms both` }} />
          ))}
        </svg>
      </div>
      <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-[0.14em]" style={{ color: "#8a8a8a" }}>
        <span>USD · Global clients</span>
        <span style={{ color: "#E8623A" }}>▲ 7.2×</span>
      </div>
    </div>
  );
}

function PersonaStudentsFooter() {
  const stats = [
    { n: "3", l: "Side projects" },
    { n: "19", l: "Avg age" },
    { n: "0", l: "Resumes needed" },
  ];
  const projects = [
    { emoji: "🧠", name: "StudyGPT", meta: "AI notes · 1.2K DAU" },
    { emoji: "🎧", name: "LofiBrain", meta: "Chrome ext · 4.8★" },
    { emoji: "📸", name: "ClipCut", meta: "n8n workflow · v2" },
  ];
  return (
    <div className="relative z-10 mt-auto space-y-3 pt-6">
      {/* mini project cards */}
      <div className="grid gap-2 md:grid-cols-3">
        {projects.map((p, k) => (
          <div
            key={p.name}
            className="rounded-[10px] px-2.5 py-2"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: "1px solid #2a2a2a",
              animation: `ea-badge-in 500ms ${k * 120}ms both`,
            }}
          >
            <div className="flex items-center gap-2">
              <span className="grid h-6 w-6 place-items-center rounded-md bg-[#E8623A]/15 text-[13px]">{p.emoji}</span>
              <span className="truncate font-mono text-[11.5px] font-extrabold text-white">{p.name}</span>
            </div>
            <div className="mt-1 truncate text-[10px] font-semibold text-white/55">{p.meta}</div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-3 gap-3">
        {stats.map((s) => (
          <div
            key={s.l}
            className="rounded-[10px] px-3 py-2.5"
            style={{ background: "rgba(255,255,255,0.05)", border: "1px solid #232323" }}
          >
            <div className="font-display text-[22px] font-extrabold leading-none" style={{ color: "#E8623A" }}>
              {s.n}
            </div>
            <div className="mt-1 text-[10px] font-bold uppercase tracking-[0.12em] text-white/60">
              {s.l}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   Bento perk card
   ============================================================ */
function BentoPerk({ p, nextNumber }: { p: (typeof PERKS)[number]; nextNumber: number }) {
  const isDark = !!p.dark;
  const isCoral = !!p.coral;
  const bg = isDark ? C.dark : isCoral ? C.coral : p.tint;
  const fg = isDark || isCoral ? "#ffffff" : C.text;
  const muted = isDark ? "rgba(255,255,255,0.88)" : isCoral ? "rgba(255,255,255,0.95)" : C.muted;

  return (
    <div
      className="group relative flex h-full flex-col overflow-hidden rounded-[14px] p-4 md:rounded-[16px] md:p-7 transition-shadow duration-300 hover:shadow-[6px_6px_0_0_#0F0F0F]"
      style={{
        background: bg,
        color: fg,
        border: `1.5px solid ${C.dark}`,
        boxShadow: `3px 3px 0 0 ${C.dark}`,
      }}
    >
      {/* subtle sheen on hover */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 transition-all duration-700 group-hover:translate-x-full group-hover:opacity-100"
      />

      <div className="mb-3 flex items-center justify-between md:mb-4">
        <span
          className="text-[10px] font-bold uppercase tracking-[0.16em]"
          style={{ color: isDark || isCoral ? "rgba(255,255,255,0.65)" : "#a09680" }}
        >
          {p.label}
        </span>
        {isDark && (
          <span
            className="rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em]"
            style={{ background: "rgba(245,166,35,0.15)", color: C.gold, border: `1px solid ${C.gold}55` }}
          >
            <Star className="mr-1 inline h-3 w-3 fill-current" />
            Forever
          </span>
        )}
      </div>

      <div className="mb-2 flex items-start gap-3 md:mb-3">
        <div
          className="grid h-10 w-10 shrink-0 place-items-center rounded-[10px] border-[1.5px] text-[20px] transition-transform group-hover:scale-110 md:h-12 md:w-12 md:text-[24px]"
          style={{
            background: isDark ? C.darkSoft : isCoral ? "rgba(255,255,255,0.2)" : C.white,
            borderColor: isDark || isCoral ? "rgba(255,255,255,0.2)" : C.dark,
            boxShadow: isDark || isCoral ? "none" : `1.5px 1.5px 0 0 ${C.dark}`,
          }}
        >
          {p.icon}
        </div>
        {isDark && (
          <div
            className="ml-auto flex flex-col items-end rounded-[12px] px-3 py-2 font-mono text-[11px]"
            style={{ background: "rgba(255,255,255,0.05)", color: C.coral }}
          >
            <span className="opacity-60">You'll be</span>
            <span className="font-extrabold" style={{ fontSize: 18, color: "#fff" }}>
              OG #{nextNumber}
            </span>
          </div>
        )}
      </div>

      <h3 className="font-display text-[17px] font-extrabold leading-tight md:text-[24px]" style={{ color: fg }}>{p.title}</h3>
      <p className="mt-1.5 text-[13px] leading-[1.6] md:mt-2 md:text-[14px] md:leading-[1.65]" style={{ color: muted }}>
        {p.body}
      </p>

      {p.label === "BENEFIT 06" && (
        <div className="mt-4 space-y-2">
          {["Just shipped 🚀", "Who wants to collab?", "OG #23 here 🔥"].map((t, i) => (
            <div
              key={t}
              className="rounded-[10px] px-3 py-2 text-[12px] font-medium"
              style={{
                background: "rgba(255,255,255,0.14)",
                color: "#fff",
                border: "1px solid rgba(255,255,255,0.2)",
                animation: `ea-badge-in 500ms ${i * 200}ms both`,
              }}
            >
              {t}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   Step indicator
   ============================================================ */
function StepIndicator({ step }: { step: number }) {
  return (
    <div className="mt-8 flex items-center justify-center gap-2">
      {[1, 2, 3].map((n, i) => (
        <div key={n} className="flex items-center gap-2">
          <div className="flex flex-col items-center">
            <div
              className="grid h-9 w-9 place-items-center rounded-full border-[1.5px] font-mono text-[13px] font-extrabold transition-all"
              style={
                step === n
                  ? {
                      background: C.coral,
                      color: "#fff",
                      borderColor: C.dark,
                      boxShadow: `2px 2px 0 0 ${C.dark}`,
                    }
                  : step > n
                    ? {
                        background: C.dark,
                        color: "#fff",
                        borderColor: C.dark,
                        boxShadow: `2px 2px 0 0 ${C.coral}`,
                      }
                    : {
                        background: C.white,
                        color: "#c9c0af",
                        borderColor: C.border,
                      }
              }
            >
              {step > n ? "✓" : n}
            </div>
            <div
              className="mt-1.5 text-[10px] font-bold uppercase tracking-[0.12em]"
              style={{ color: step >= n ? C.text : "#a89f8d" }}
            >
              {["You", "Builder", "Done"][i]}
            </div>
          </div>
          {n < 3 && (
            <div className="mb-4 h-0.5 w-10" style={{ background: step > n ? C.coral : C.border }} />
          )}
        </div>
      ))}
    </div>
  );
}

/* ============================================================
   Form field
   ============================================================ */
function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <label className="mb-2 block text-[11px] font-bold uppercase tracking-[0.12em] text-[#7a7a7a]">
        {label}
      </label>
      {children}
      {hint && <div className="mt-1.5 text-[12px] text-[#a89f8d]">{hint}</div>}
    </div>
  );
}

const inputCls =
  "w-full rounded-[10px] px-3.5 py-3 text-[15px] outline-none transition-all placeholder:text-[#c9c0af] focus:-translate-y-0.5";
const inputStyle: React.CSSProperties = {
  background: C.cream,
  border: `1.5px solid ${C.dark}`,
  color: C.text,
  boxShadow: "none",
};
const inputFocus =
  "focus:shadow-[3px_3px_0_0_#0F0F0F] focus:bg-white";

/* ============================================================
   Step 1 — Personal
   ============================================================ */
function Step1({ form, setForm, onNext, verifiedEmail }: any) {
  const [oauthLoading, setOauthLoading] = useState(false);
  const signInWithGoogle = async () => {
    try {
      setOauthLoading(true);
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo: `${window.location.origin}/auth-callback?next=/early-access` },
      });
      if (error) toast.error(error.message || "Google sign-in failed");
    } catch (e: any) {
      toast.error(e?.message || "Google sign-in failed");
    } finally {
      setOauthLoading(false);
    }
  };

  if (!verifiedEmail) {
    return (
      <>
        <div className="mb-5 text-[11px] font-bold uppercase tracking-[0.16em] text-[#a89f8d]">
          Step 1 of 3 · Verify your email
        </div>
        <div
          className="rounded-[14px] border-[1.5px] p-5 md:p-6"
          style={{ background: "#FFF6EE", borderColor: "#0F0F0F", boxShadow: "4px 4px 0 0 #0F0F0F" }}
        >
          <div className="mb-2 inline-flex items-center gap-2 rounded-full border-[1.5px] px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider"
               style={{ background: "#fff", borderColor: "#0F0F0F", color: "#0F0F0F" }}>
            <ShieldCheck className="h-3.5 w-3.5" /> Email verification required
          </div>
          <h3 className="font-display text-[22px] font-extrabold leading-tight text-[#0F0F0F]">
            Continue with Google to claim your OG spot
          </h3>
          <p className="mt-2 text-[13px] text-[#5b5347]">
            To keep the Founders Wall real, every builder must verify their email through Google before registering. Takes 3 seconds — no password needed.
          </p>
          <button
            type="button"
            onClick={signInWithGoogle}
            disabled={oauthLoading}
            className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-[10px] border-[1.5px] bg-white text-[14px] font-bold text-[#0F0F0F] transition hover:-translate-y-0.5 disabled:opacity-60"
            style={{ borderColor: "#0F0F0F", boxShadow: "3px 3px 0 0 #0F0F0F" }}
          >
            <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
              <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.9 32.1 29.4 35 24 35c-6.1 0-11-4.9-11-11s4.9-11 11-11c2.8 0 5.4 1.1 7.4 2.8l5.7-5.7C33.6 6.5 29.1 4.5 24 4.5 13.2 4.5 4.5 13.2 4.5 24S13.2 43.5 24 43.5 43.5 34.8 43.5 24c0-1.2-.1-2.4-.4-3.5z"/>
              <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.6 16 18.9 13 24 13c2.8 0 5.4 1.1 7.4 2.8l5.7-5.7C33.6 6.5 29.1 4.5 24 4.5 16.3 4.5 9.6 8.9 6.3 14.7z"/>
              <path fill="#4CAF50" d="M24 43.5c5 0 9.5-1.9 12.9-5l-6-4.9c-2 1.5-4.5 2.4-6.9 2.4-5.3 0-9.8-2.9-11.3-7L6.2 33.8C9.4 39.5 16.1 43.5 24 43.5z"/>
              <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.4 4.2-4.4 5.6l6 4.9c-.4.4 6.6-4.8 6.6-14.5 0-1.2-.1-2.4-.4-3.5z"/>
            </svg>
            {oauthLoading ? "Redirecting to Google…" : "Continue with Google"}
          </button>
          <p className="mt-3 text-[11px] text-[#8a8172]">
            We only use your Google account to verify your email. We won't post anything.
          </p>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="mb-5 text-[11px] font-bold uppercase tracking-[0.16em] text-[#a89f8d]">
        Step 1 of 3 · Who are you?
      </div>
      <div className="mb-4 flex items-center gap-2 rounded-[10px] border-[1.5px] px-3 py-2 text-[12px] font-bold"
           style={{ background: "#EAF7EE", borderColor: "#0F0F0F", color: "#0F0F0F" }}>
        <BadgeCheck className="h-4 w-4 text-[#0f7a3a]" />
        Email verified via Google · {verifiedEmail}
      </div>
      <Field label="Full Name">
        <input
          className={`${inputCls} ${inputFocus}`}
          style={inputStyle}
          value={form.fullName}
          onChange={(e) => setForm({ ...form, fullName: e.target.value })}
          placeholder="Rohit Sharma"
        />
      </Field>
      <Field label="Email" hint="Verified with Google — locked">
        <input
          className={`${inputCls}`}
          style={{ ...inputStyle, background: "#F5F0E8", cursor: "not-allowed" }}
          type="email"
          value={verifiedEmail}
          readOnly
          disabled
        />
      </Field>

      <Field label="Username" hint="3–20 chars · letters, numbers, underscore">
        <div className="relative">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono text-[15px] text-[#7a7a7a]">
            @
          </span>
          <input
            className={`${inputCls} ${inputFocus} pl-8`}
            style={inputStyle}
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value.replace(/[^a-zA-Z0-9_]/g, "") })}
            placeholder="rohitsharma"
          />
        </div>
      </Field>
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="City">
          <input
            className={`${inputCls} ${inputFocus}`}
            style={inputStyle}
            value={form.city}
            onChange={(e) => setForm({ ...form, city: e.target.value })}
            placeholder="Bangalore"
          />
        </Field>
        <Field label="State">
          <select
            className={`${inputCls} ${inputFocus}`}
            style={inputStyle}
            value={form.state}
            onChange={(e) => setForm({ ...form, state: e.target.value })}
          >
            <option value="">Select</option>
            {INDIAN_STATES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </Field>
      </div>

      <button className="btn-coral mt-4 h-13 w-full text-[14px]" style={{ height: 52 }} onClick={onNext}>
        Next: Builder Profile <ArrowRight className="h-4 w-4" />
      </button>
    </>
  );
}

/* ============================================================
   Step 2 — Builder profile + live preview
   ============================================================ */
function Step2({ form, setForm, nextNumber, onBack, onNext }: any) {
  return (
    <>
      <div className="mb-5 text-[11px] font-bold uppercase tracking-[0.16em] text-[#a89f8d]">
        Step 2 of 3 · Your builder profile
      </div>

      <Field label="I am a...">
        <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
          {BUILDER_TYPES.map((b) => {
            const on = form.builderType === b.v;
            return (
              <button
                key={b.v}
                type="button"
                onClick={() => setForm({ ...form, builderType: b.v })}
                className="rounded-full px-3 py-2.5 text-[13px] font-bold transition-all"
                style={{
                  background: on ? C.coral : C.white,
                  color: on ? "#fff" : C.text,
                  border: `1.5px solid ${C.dark}`,
                  boxShadow: on ? `2px 2px 0 0 ${C.dark}` : "none",
                  transform: on ? "translate(-1px,-1px)" : "none",
                }}
              >
                {b.e} {b.l}
              </button>
            );
          })}
        </div>
      </Field>

      <Field label="My primary AI tool">
        <div className="flex flex-wrap gap-2">
          {TOOLS.map((t) => {
            const on = form.primaryTool === t.v;
            return (
              <button
                key={t.v}
                type="button"
                onClick={() => setForm({ ...form, primaryTool: t.v })}
                className="rounded-full px-3.5 py-2 text-[13px] font-bold transition-all"
                style={{
                  background: on ? t.c : C.white,
                  color: on ? "#fff" : C.text,
                  border: `1.5px solid ${C.dark}`,
                  boxShadow: on ? `2px 2px 0 0 ${C.dark}` : "none",
                  transform: on ? "translate(-1px,-1px)" : "none",
                }}
              >
                {t.l}
              </button>
            );
          })}
        </div>
      </Field>

      <Field label="What are you building?" hint={`${form.whatBuilding.length}/150 — What problem are you solving?`}>
        <textarea
          className={`${inputCls} ${inputFocus}`}
          style={inputStyle}
          rows={3}
          maxLength={150}
          value={form.whatBuilding}
          onChange={(e) => setForm({ ...form, whatBuilding: e.target.value })}
          placeholder="A SaaS for Indian SMBs using n8n and Claude..."
        />
      </Field>

      <Field label="Your Founders Wall tagline" hint={`${form.wallTagline.length}/60`}>
        <input
          className={`${inputCls} ${inputFocus}`}
          style={inputStyle}
          maxLength={60}
          value={form.wallTagline}
          onChange={(e) => setForm({ ...form, wallTagline: e.target.value })}
          placeholder="Building AI automation for India's SMBs"
        />
      </Field>

      {/* Live preview */}
      <div
        className="mt-4 rounded-[12px] p-4"
        style={{ background: C.cream, border: `1.5px dashed ${C.dark}` }}
      >
        <div className="mb-3 text-[10px] font-bold uppercase tracking-[0.16em] text-[#a89f8d]">
          Live preview — how you'll appear on the wall
        </div>
        <div
          className="rounded-[10px] p-4"
          style={{ background: C.white, border: `1.5px solid ${C.dark}`, boxShadow: `2px 2px 0 0 ${C.dark}` }}
        >
          <div className="flex items-center gap-3">
            <img
              src={avatarUrl(form.fullName || "you")}
              alt=""
              className="h-10 w-10 rounded-full"
              style={{ background: C.cream, border: `1.5px solid ${C.dark}` }}
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span
                  className="rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.12em]"
                  style={{ background: C.coralSoft, color: C.coral, border: `1px solid ${C.coral}44` }}
                >
                  🔥 OG #{nextNumber}
                </span>
                <span className="truncate text-[14px] font-extrabold">
                  {form.fullName || "Your Name"}
                </span>
              </div>
              <div className="mt-1 truncate text-[12px] italic text-[#7a7a7a]">
                {form.wallTagline ? `"${form.wallTagline}"` : "Your tagline will appear here…"}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 flex gap-3">
        <button className="btn-outline-dark h-13 flex-1 text-[13px]" style={{ height: 52 }} onClick={onBack}>
          ← Back
        </button>
        <button className="btn-coral h-13 flex-[2] text-[14px]" style={{ height: 52 }} onClick={onNext}>
          Next: Final step <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </>
  );
}

/* ============================================================
   Step 3 — Links + submit
   ============================================================ */
function Step3({ form, setForm, nextNumber, submitting, onBack, onSubmit }: any) {
  return (
    <>
      <div className="mb-5 text-[11px] font-bold uppercase tracking-[0.16em] text-[#a89f8d]">
        Step 3 of 3 · Lock it in
      </div>

      <Field label="LinkedIn (optional)">
        <input
          className={`${inputCls} ${inputFocus}`}
          style={inputStyle}
          value={form.linkedinUrl}
          onChange={(e) => setForm({ ...form, linkedinUrl: e.target.value })}
          placeholder="linkedin.com/in/you"
        />
      </Field>
      <Field label="Twitter / X (optional)">
        <input
          className={`${inputCls} ${inputFocus}`}
          style={inputStyle}
          value={form.twitterUrl}
          onChange={(e) => setForm({ ...form, twitterUrl: e.target.value })}
          placeholder="twitter.com/you"
        />
      </Field>
      <Field label="GitHub (optional)">
        <input
          className={`${inputCls} ${inputFocus}`}
          style={inputStyle}
          value={form.githubUrl}
          onChange={(e) => setForm({ ...form, githubUrl: e.target.value })}
          placeholder="github.com/you"
        />
      </Field>

      <Field label="How did you find us?">
        <div className="flex flex-wrap gap-2">
          {REFERRAL_SOURCES.map((s) => {
            const on = form.referralSource === s;
            return (
              <button
                key={s}
                type="button"
                onClick={() => setForm({ ...form, referralSource: s })}
                className="rounded-full px-3.5 py-2 text-[13px] font-bold transition-all"
                style={{
                  background: on ? C.coral : C.white,
                  color: on ? "#fff" : C.text,
                  border: `1.5px solid ${C.dark}`,
                  boxShadow: on ? `2px 2px 0 0 ${C.dark}` : "none",
                  transform: on ? "translate(-1px,-1px)" : "none",
                }}
              >
                {s}
              </button>
            );
          })}
        </div>
      </Field>

      <div
        className="mb-4 flex items-center justify-between gap-3 rounded-[12px] p-4"
        style={{ background: C.cream, border: `1.5px solid ${C.dark}` }}
      >
        <div className="min-w-0">
          <div className="text-[14px] font-extrabold">Show me on the Founders Wall</div>
          <div className="mt-1 text-[12px] text-[#7a7a7a]">
            Your name and tagline appear on the public wall.
          </div>
        </div>
        <button
          type="button"
          onClick={() => setForm({ ...form, showOnWall: !form.showOnWall })}
          className="relative h-8 w-14 shrink-0 rounded-full border-[1.5px] transition-colors"
          style={{
            background: form.showOnWall ? C.coral : C.white,
            borderColor: C.dark,
            boxShadow: `2px 2px 0 0 ${C.dark}`,
          }}
        >
          <span
            className="absolute top-0.5 grid h-6 w-6 place-items-center rounded-full transition-transform"
            style={{
              background: "#fff",
              border: `1.5px solid ${C.dark}`,
              transform: form.showOnWall ? "translateX(26px)" : "translateX(2px)",
            }}
          >
            {form.showOnWall && <Check className="h-3 w-3" style={{ color: C.coral }} />}
          </span>
        </button>
      </div>


      <div className="flex flex-col gap-3 sm:flex-row">
        <button
          className="btn-outline-dark h-13 sm:flex-1"
          style={{ height: 52 }}
          onClick={onBack}
          disabled={submitting}
        >
          ← Back
        </button>
        <button
          className="btn-coral h-14 text-[14px] sm:flex-[2]"
          style={{ height: 56 }}
          onClick={onSubmit}
          disabled={submitting}
        >
          {submitting ? (
            <>
              <span
                className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white"
                aria-hidden
              />
              Locking in your spot...
            </>
          ) : (
            <>
              <Flame className="h-4 w-4" /> Lock in OG Badge #{nextNumber}
            </>
          )}
        </button>
      </div>
      <div className="mt-3 text-center text-[11px] font-semibold uppercase tracking-[0.12em] text-[#a89f8d]">
        Permanent · Free · Reserved instantly
      </div>
    </>
  );
}

/* ============================================================
   Terms & Conditions consent step (before final submit)
   ============================================================ */
function TermsStep({
  nextNumber,
  submitting,
  onBack,
  onAccept,
}: {
  nextNumber: number;
  submitting: boolean;
  onBack: () => void;
  onAccept: () => void;
}) {
  const [checked, setChecked] = useState(false);
  return (
    <div className="mx-auto max-w-[640px]">
      <div className="text-center">
        <div
          className="mx-auto inline-flex items-center gap-2 rounded-full border-[1.5px] px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.16em]"
          style={{ borderColor: "#0F0F0F", background: "#FFF3EE", color: "#E8623A" }}
        >
          <ShieldCheck className="h-3 w-3" />
          One last step
        </div>
        <h2
          className="mt-5 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
          style={{ fontSize: "clamp(28px, 4.8vw, 44px)" }}
        >
          Accept the Terms to lock <Highlighter action="highlight" color="rgba(232,98,58,0.22)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}><span style={{ color: "#E8623A" }}>OG #{nextNumber}</span></Highlighter>
        </h2>
        <p className="mx-auto mt-3 max-w-[520px] text-[14.5px] leading-[1.65] text-[#5c5c5c]">
          VibeCode is a marketplace connecting builders, hirers, and communities. Please read and agree before we finalize your OG spot.
        </p>
      </div>

      <div
        className="mt-6 rounded-[16px] p-6 md:p-7"
        style={{ background: "#FFFFFF", border: "1.5px solid #0F0F0F", boxShadow: "4px 4px 0 0 #0F0F0F" }}
      >
        <div
          className="flex items-start gap-3 rounded-xl border-[1.5px] p-3.5 text-[13.5px] leading-[1.6]"
          style={{ borderColor: "#E8623A", background: "#FFF3EE", color: "#0F0F0F" }}
        >
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" style={{ color: "#E8623A" }} />
          <div>
            <b>VibeCode is a marketplace.</b> We connect people — but <b>we are not a party</b> to your deals and{" "}
            <b>cannot guarantee</b> that every user is genuine or scam-free. Always vet the counterparty, start
            small, and never share credentials or transfer large sums before you've verified them.
          </div>
        </div>

        <ul className="mt-4 space-y-2 text-[13.5px] leading-[1.6] text-[#0F0F0F]/80">
          <li className="flex gap-2"><span style={{ color: "#E8623A" }}>•</span> You're responsible for your own vetting, payments, and communications.</li>
          <li className="flex gap-2"><span style={{ color: "#E8623A" }}>•</span> You own the content you upload; you must have the rights to it.</li>
          <li className="flex gap-2"><span style={{ color: "#E8623A" }}>•</span> We use essential cookies to keep you signed in and analytics cookies to improve the product.</li>
          <li className="flex gap-2"><span style={{ color: "#E8623A" }}>•</span> Fraud or abuse can be reported at <a href="mailto:trust@joinvibecode.xyz" className="underline" style={{ color: "#E8623A" }}>trust@joinvibecode.xyz</a>.</li>
        </ul>

        <label
          className="mt-5 flex cursor-pointer items-start gap-3 rounded-xl border p-3.5"
          style={{ borderColor: "rgba(15,15,15,0.15)", background: "#FAF7F0" }}
        >
          <input
            type="checkbox"
            className="mt-1 h-4 w-4 shrink-0 accent-[#E8623A]"
            checked={checked}
            onChange={(e) => setChecked(e.target.checked)}
          />
          <span className="text-[13.5px] leading-[1.55] text-[#0F0F0F]">
            I have read and agree to VibeCode's{" "}
            <a
              href="/terms"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 font-semibold underline"
              style={{ color: "#E8623A" }}
            >
              Terms & Conditions <ExternalLink className="h-3 w-3" />
            </a>{" "}
            and{" "}
            <a
              href="/privacy-policy"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 font-semibold underline"
              style={{ color: "#E8623A" }}
            >
              Privacy Policy <ExternalLink className="h-3 w-3" />
            </a>
            . I understand VibeCode does not guarantee outcomes and I will vet the users I transact with.
          </span>
        </label>
      </div>

      <div className="mt-5 flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
        <button
          type="button"
          onClick={onBack}
          disabled={submitting}
          className="inline-flex items-center justify-center gap-1.5 rounded-full border-[1.5px] px-5 py-2.5 text-[13px] font-extrabold uppercase tracking-[0.1em] transition-transform active:scale-95 disabled:opacity-60"
          style={{ borderColor: "#0F0F0F", background: "#FFFFFF", color: "#0F0F0F" }}
        >
          Back
        </button>
        <button
          type="button"
          onClick={onAccept}
          disabled={!checked || submitting}
          className="inline-flex items-center justify-center gap-2 rounded-full border-[1.5px] px-6 py-3 text-[13px] font-extrabold uppercase tracking-[0.1em] text-white transition-transform active:scale-95 disabled:cursor-not-allowed disabled:opacity-50"
          style={{
            borderColor: "#0F0F0F",
            background: checked ? "#E8623A" : "#c9c0af",
            boxShadow: checked ? "3px 3px 0 0 #0F0F0F" : "none",
          }}
        >
          <ShieldCheck className="h-3.5 w-3.5" />
          {submitting ? "Locking your OG spot…" : `Accept & lock OG #${nextNumber}`}
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   Success block
   ============================================================ */
function ThankYouMickey({ name, ogNumber }: { name: string; ogNumber: number }) {
  return (
    <div
      className="mx-auto mt-8 max-w-[480px] overflow-hidden rounded-[20px] text-left"
      style={{
        background: "linear-gradient(180deg, #FFF7F1 0%, #FFFFFF 100%)",
        border: "1.5px solid #0F0F0F",
        boxShadow: "6px 6px 0 0 #0F0F0F",
        animation: "ea-badge-in 700ms cubic-bezier(.34,1.56,.64,1) 200ms both",
      }}
    >
      <style>{`
        @keyframes tym-wave {
          0%, 60%, 100% { transform: rotate(-8deg); }
          15% { transform: rotate(22deg); }
          30% { transform: rotate(-14deg); }
          45% { transform: rotate(22deg); }
        }
        @keyframes tym-bob {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }
        @keyframes tym-blink {
          0%, 92%, 100% { transform: scaleY(1); }
          95% { transform: scaleY(0.1); }
        }
        @keyframes tym-heart {
          0% { transform: translateY(0) scale(0.6); opacity: 0; }
          20% { opacity: 1; }
          100% { transform: translateY(-38px) scale(1); opacity: 0; }
        }
        .tym-wrap { animation: tym-bob 2.6s ease-in-out infinite; transform-origin: 50% 100%; }
        .tym-arm { transform-origin: 42px 78px; animation: tym-wave 2.4s ease-in-out infinite; }
        .tym-eye { transform-origin: center; animation: tym-blink 4s ease-in-out infinite; }
        .tym-heart { animation: tym-heart 2.8s ease-in-out infinite; }
        .tym-heart.d1 { animation-delay: 0.4s; }
        .tym-heart.d2 { animation-delay: 1.2s; }
        .tym-heart.d3 { animation-delay: 2s; }
      `}</style>

      <div className="flex flex-col items-center gap-4 px-6 py-6 sm:flex-row sm:items-center sm:gap-5 sm:px-7">
        {/* Waving mouse mascot */}
        <div className="relative shrink-0" style={{ width: 118, height: 128 }}>
          {/* Floating hearts */}
          <svg width="118" height="128" viewBox="0 0 118 128" style={{ position: "absolute", inset: 0, pointerEvents: "none" }} aria-hidden>
            <g fill="#E8623A">
              <path className="tym-heart d1" d="M20 96 l-3.5 -3.5 a2.4 2.4 0 1 1 3.5 -3.2 a2.4 2.4 0 1 1 3.5 3.2 z" />
              <path className="tym-heart d2" d="M96 92 l-3.5 -3.5 a2.4 2.4 0 1 1 3.5 -3.2 a2.4 2.4 0 1 1 3.5 3.2 z" />
              <path className="tym-heart d3" d="M58 84 l-3.5 -3.5 a2.4 2.4 0 1 1 3.5 -3.2 a2.4 2.4 0 1 1 3.5 3.2 z" />
            </g>
          </svg>

          <svg
            className="tym-wrap"
            width="118"
            height="128"
            viewBox="0 0 118 128"
            aria-label="A cheerful mouse waving hello"
          >
            {/* Ears */}
            <circle cx="26" cy="30" r="18" fill="#0F0F0F" />
            <circle cx="92" cy="30" r="18" fill="#0F0F0F" />
            {/* Head */}
            <circle cx="59" cy="60" r="30" fill="#0F0F0F" />
            {/* Face */}
            <ellipse cx="59" cy="72" rx="20" ry="17" fill="#F5D6B8" />
            {/* Muzzle */}
            <ellipse cx="59" cy="78" rx="10" ry="7" fill="#FFE8D2" />
            {/* Nose */}
            <ellipse cx="59" cy="72" rx="4.2" ry="3.2" fill="#0F0F0F" />
            {/* Nose highlight */}
            <ellipse cx="57.5" cy="70.8" rx="1.2" ry="0.9" fill="#fff" />
            {/* Eyes */}
            <g fill="#fff">
              <ellipse className="tym-eye" cx="50" cy="58" rx="4.2" ry="6" />
              <ellipse className="tym-eye" cx="68" cy="58" rx="4.2" ry="6" />
            </g>
            <g fill="#0F0F0F">
              <ellipse cx="51" cy="60" rx="1.8" ry="2.4" />
              <ellipse cx="69" cy="60" rx="1.8" ry="2.4" />
            </g>
            {/* Smile */}
            <path d="M52 82 Q59 88 66 82" stroke="#0F0F0F" strokeWidth="2" fill="none" strokeLinecap="round" />
            {/* Body */}
            <path d="M40 88 Q59 100 78 88 L78 112 Q59 120 40 112 Z" fill="#E8623A" stroke="#0F0F0F" strokeWidth="1.5" />
            {/* Buttons */}
            <circle cx="54" cy="104" r="2.2" fill="#fff" stroke="#0F0F0F" strokeWidth="1" />
            <circle cx="64" cy="104" r="2.2" fill="#fff" stroke="#0F0F0F" strokeWidth="1" />
            {/* Static arm */}
            <path d="M78 92 Q92 100 88 114" stroke="#0F0F0F" strokeWidth="6" fill="none" strokeLinecap="round" />
            <circle cx="90" cy="116" r="6" fill="#FFF" stroke="#0F0F0F" strokeWidth="1.5" />
            {/* Waving arm */}
            <g className="tym-arm">
              <path d="M42 92 Q30 78 34 62" stroke="#0F0F0F" strokeWidth="6" fill="none" strokeLinecap="round" />
              <circle cx="34" cy="58" r="7" fill="#FFF" stroke="#0F0F0F" strokeWidth="1.5" />
            </g>
          </svg>
        </div>

        {/* Message */}
        <div className="flex-1 text-center sm:text-left">
          <div className="inline-flex items-center gap-1.5 rounded-full border border-[#0F0F0F]/15 bg-white px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.16em] text-[#E8623A]">
            💌 A note from the founders
          </div>
          <h3 className="mt-2 font-display text-[20px] font-extrabold leading-tight sm:text-[22px]">
            Thank you, {name} — truly.
          </h3>
          <p className="mt-1.5 text-[13.5px] leading-[1.65] text-[#0F0F0F]/75">
            You're OG <b style={{ color: "#E8623A" }}>#{ogNumber}</b> out of 100. Betting on a tiny startup this
            early is a big deal — it means the world to us. We'll build VibeCode with the same care you just showed
            us. Ship loud, be kind, and let's make Indian AI builders unmissable. 🧡
          </p>
          <p className="mt-2 text-[12px] font-bold uppercase tracking-[0.14em] text-[#0F0F0F]/60">
            — Team VibeCode
          </p>
        </div>
      </div>
    </div>
  );
}

function SuccessBlock({ ogNumber, form, remaining, alreadyAt }: any) {
  const url = "https://joinvibecode.xyz/early-access";
  const shareText = encodeURIComponent(
    `Just locked in Builder #${ogNumber} on VibeCode 🔥\n\nIndia's AI builder community launches August 4.\nI'm one of 100 OG members — Free Pro for a year.\n\nOnly ${remaining} spots left → ${url}\n\n#VibeCode #AIBuilder #BuildingInPublic`,
  );
  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Link copied");
    } catch {
      toast.error("Couldn't copy");
    }
  };
  const first = form.fullName.trim().split(" ")[0] || "Builder";
  const toolLabel = TOOLS.find((t) => t.v === form.primaryTool)?.l || "—";

  return (
    <div className="mx-auto max-w-[620px] text-center">
      {/* Confetti */}
      <div className="pointer-events-none relative h-0">
        {Array.from({ length: 40 }).map((_, i) => {
          const angle = (Math.random() - 0.5) * 360;
          const dist = 160 + Math.random() * 260;
          const rad = (angle * Math.PI) / 180;
          return (
            <span
              key={i}
              className="ea-confetti-piece"
              style={
                {
                  left: `${50 + (Math.random() - 0.5) * 30}%`,
                  background: [C.coral, C.gold, C.dark, C.white][i % 4],
                  borderRadius: i % 3 === 0 ? "50%" : "2px",
                  boxShadow: i % 4 === 3 ? `0 0 0 1.5px ${C.dark}` : "none",
                  ["--tx" as any]: `${Math.cos(rad) * dist}px`,
                  ["--ty" as any]: `${Math.sin(rad) * dist + 60}px`,
                  animationDelay: `${Math.random() * 0.2}s`,
                } as React.CSSProperties
              }
            />
          );
        })}
      </div>

      <div
        className="mx-auto grid h-24 w-24 place-items-center rounded-full text-[42px]"
        style={{
          background: C.coral,
          color: "#fff",
          border: `2px solid ${C.dark}`,
          boxShadow: `4px 4px 0 0 ${C.dark}`,
          animation: "ea-badge-in 700ms cubic-bezier(.34,1.56,.64,1)",
        }}
      >
        🔥
      </div>

      <h2
        className="mt-6 font-display font-extrabold leading-[1.05] tracking-[-0.02em]"
        style={{ fontSize: "clamp(26px, 6vw, 56px)" }}
      >
        You're in, <Highlighter action="highlight" color="rgba(232,98,58,0.22)" strokeWidth={1.5} padding={4} iterations={2} animationDuration={800}>{first}</Highlighter>.
      </h2>
      <p className="mx-auto mt-3 max-w-[440px] text-[16px]" style={{ color: C.muted }}>
        {alreadyAt
          ? "You were already registered — welcome back."
          : "Welcome to the founding 100. Your builder number is reserved forever."}
      </p>

      {/* Thank-you note from the founders, with a waving mouse */}
      <ThankYouMickey name={first} ogNumber={ogNumber} />

      {/* Private WhatsApp group — OG-only access before launch */}
      <a
        href="https://chat.whatsapp.com/KqbbXDLoh2SFRUNakySOBj"
        target="_blank"
        rel="noreferrer"
        className="group mx-auto mt-6 flex max-w-[480px] items-center justify-between gap-4 rounded-[16px] px-5 py-4 text-left transition-transform duration-150 hover:-translate-y-0.5 active:translate-y-0"
        style={{
          background: "#25D366",
          color: "#fff",
          border: "1.5px solid #0F0F0F",
          boxShadow: "5px 5px 0 0 #0F0F0F",
        }}
      >
        <div className="flex items-center gap-3">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white"
            style={{ border: "1.5px solid #0F0F0F" }}
            aria-hidden
          >
            <svg viewBox="0 0 32 32" width="22" height="22" fill="#25D366">
              <path d="M16 3C9 3 3.4 8.6 3.4 15.6c0 2.5.7 4.9 2 7L3 29l6.6-2.3c2 .9 4.2 1.4 6.4 1.4h.1c7 0 12.6-5.6 12.6-12.6C28.7 8.6 23 3 16 3zm7.3 17.8c-.3.8-1.7 1.6-2.3 1.7-.6.1-1.4.1-2.2-.1-.5-.2-1.2-.4-2-.7-3.6-1.5-5.9-5.1-6.1-5.4-.2-.3-1.4-1.9-1.4-3.6 0-1.7.9-2.6 1.3-2.9.3-.3.7-.4 1-.4h.7c.2 0 .5-.1.8.6.3.7 1 2.4 1.1 2.6.1.2.1.4 0 .6-.1.2-.2.4-.3.5l-.5.5c-.2.2-.3.4-.1.7.2.3.9 1.4 1.9 2.3 1.3 1.1 2.4 1.5 2.7 1.6.3.1.5.1.7-.1.2-.2.8-.9 1-1.2.2-.3.4-.3.7-.2.3.1 1.9.9 2.2 1 .3.1.5.2.6.4.1.2.1.9-.2 1.7z"/>
            </svg>
          </span>
          <div>
            <div className="text-[11px] font-bold uppercase tracking-[0.16em] opacity-90">OG-only · private group</div>
            <div className="font-display text-[17px] font-extrabold leading-tight">Join the WhatsApp group</div>
            <div className="mt-0.5 text-[12.5px] opacity-90">Get inside access before we go live on Aug 4</div>
          </div>
        </div>
        <ArrowRight className="h-5 w-5 shrink-0 transition-transform duration-150 group-hover:translate-x-1" />
      </a>


      {/* OG membership card */}
      <div
        className="mx-auto mt-8 max-w-[440px] rounded-[18px] p-6 text-left"
        style={{
          background: C.white,
          border: `1.5px solid ${C.dark}`,
          boxShadow: `6px 6px 0 0 ${C.coral}`,
        }}
      >
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className="grid h-7 w-7 place-items-center rounded-[6px] border-[1.5px]"
              style={{ background: C.coral, borderColor: C.dark, color: "#fff", boxShadow: `1.5px 1.5px 0 0 ${C.dark}` }}
            >
              <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M8 8 L3 12 L8 16" />
                <path d="M16 8 L21 12 L16 16" />
                <path d="M14 5 L10 19" />
              </svg>
            </span>
            <span className="font-display text-[15px] font-extrabold">VibeCode</span>
          </div>
          <span
            className="rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em]"
            style={{ background: C.coralSoft, color: C.coral, border: `1px solid ${C.coral}55` }}
          >
            🔥 OG Member
          </span>
        </div>
        <div className="flex items-center gap-3">
          <img
            src={avatarUrl(form.fullName || String(ogNumber))}
            alt=""
            className="h-16 w-16 rounded-full"
            style={{ background: C.cream, border: `1.5px solid ${C.dark}` }}
          />
          <div>
            <div className="font-display text-[20px] font-extrabold">{form.fullName || "Founding Builder"}</div>
            <div className="text-[13px] font-bold" style={{ color: C.coral }}>
              @{form.username || "you"}
            </div>
            <div className="text-[12px] text-[#7a7a7a]">
              {[form.city, form.state].filter(Boolean).join(", ") || "India"}
            </div>
          </div>
        </div>
        {form.wallTagline && (
          <p className="mt-4 text-[14px] italic leading-[1.55]" style={{ color: C.text }}>
            "{form.wallTagline}"
          </p>
        )}
        <div className="my-4 h-px" style={{ background: C.border }} />
        <div className="grid grid-cols-3 gap-3">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#a89f8d]">Builder</div>
            <div className="mt-1 font-display text-[16px] font-extrabold">#{ogNumber}</div>
          </div>
          <div>
            <div className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#a89f8d]">Primary Tool</div>
            <div className="mt-1 text-[14px] font-extrabold">{toolLabel}</div>
          </div>
          <div>
            <div className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#a89f8d]">Status</div>
            <div className="mt-1 text-[13px] font-extrabold" style={{ color: C.green }}>
              ✓ Confirmed
            </div>
          </div>
        </div>
        <div className="mt-4 text-right text-[10px] font-bold uppercase tracking-[0.14em] text-[#c9c0af]">
          August 4, 2026 · VibeCode OG
        </div>
      </div>
      <div className="mt-3 text-[12px] italic text-[#7a7a7a]">Screenshot this card and share it 📸</div>

      {/* Share */}
      <div className="mt-8">
        <div className="mb-3 text-[13px] font-bold">Your OG spot is live. Tell someone.</div>
        <div className="flex flex-wrap justify-center gap-2">
          {[
            {
              icon: Linkedin,
              label: "LinkedIn",
              href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
            },
            { icon: Twitter, label: "Twitter", href: `https://twitter.com/intent/tweet?text=${shareText}` },
            { icon: Send, label: "WhatsApp", href: `https://wa.me/?text=${shareText}` },
          ].map((s) => (
            <a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noreferrer"
              className="btn-outline-dark h-11 px-4 text-[13px]"
              style={{ height: 44 }}
            >
              <s.icon className="h-4 w-4" />
              {s.label}
            </a>
          ))}
          <button className="btn-outline-dark h-11 px-4 text-[13px]" style={{ height: 44 }} onClick={copyLink}>
            <CopyIcon className="h-4 w-4" />
            Copy link
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   Waitlist
   ============================================================ */
function WaitlistBlock({ waitEmail, setWaitEmail, waitName, setWaitName, waitDone, onSubmit }: any) {
  if (waitDone) {
    return (
      <div className="mx-auto max-w-[520px] text-center">
        <div
          className="mx-auto grid h-20 w-20 place-items-center rounded-full text-[36px]"
          style={{
            background: C.gold,
            border: `2px solid ${C.dark}`,
            boxShadow: `4px 4px 0 0 ${C.dark}`,
          }}
        >
          📮
        </div>
        <h2 className="mt-6 font-display text-[36px] font-extrabold">You're on the waitlist.</h2>
        <p className="mt-3 text-[15px]" style={{ color: C.muted }}>
          All 100 OG spots are gone — but if one opens up, you're first in line.
        </p>
      </div>
    );
  }
  return (
    <div className="mx-auto max-w-[520px]">
      <div className="text-center">
        <Pill soft>
          <Users className="h-3 w-3" />
          OG spots are full
        </Pill>
        <h2 className="mt-5 font-display text-[36px] font-extrabold">Join the waitlist</h2>
        <p className="mt-3 text-[15px]" style={{ color: C.muted }}>
          If a spot opens up, we email you first.
        </p>
      </div>
      <form
        onSubmit={onSubmit}
        className="mt-8 rounded-[16px] p-6"
        style={{
          background: C.white,
          border: `1.5px solid ${C.dark}`,
          boxShadow: `4px 4px 0 0 ${C.dark}`,
        }}
      >
        <Field label="Full Name">
          <input
            className={`${inputCls} ${inputFocus}`}
            style={inputStyle}
            value={waitName}
            onChange={(e) => setWaitName(e.target.value)}
            placeholder="Rohit Sharma"
          />
        </Field>
        <Field label="Email">
          <input
            className={`${inputCls} ${inputFocus}`}
            style={inputStyle}
            type="email"
            value={waitEmail}
            onChange={(e) => setWaitEmail(e.target.value)}
            placeholder="rohit@builder.dev"
          />
        </Field>
        <button className="btn-coral mt-2 h-13 w-full text-[14px]" style={{ height: 52 }} type="submit">
          Join the waitlist <ArrowRight className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}

/* ============================================================
   Founder card
   ============================================================ */
function FounderCard({ m }: { m: WallMember }) {
  return (
    <div
      className="hover-lift relative flex flex-col rounded-[16px] p-6"
      style={{
        background: C.white,
        border: `1.5px solid ${C.dark}`,
        boxShadow: `3px 3px 0 0 ${C.gold}`,
      }}
    >
      <div className="mb-4 flex items-center justify-between">
        <span
          className="rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em]"
          style={{
            background: "rgba(245,166,35,0.15)",
            color: "#a17615",
            border: `1px solid ${C.gold}66`,
          }}
        >
          <Crown className="mr-1 inline h-3 w-3" />
          Founder · OG #{m.og_number}
        </span>
      </div>
      <img
        src={avatarUrl(m.full_name)}
        alt=""
        className="h-16 w-16 rounded-full"
        style={{ background: C.cream, border: `2px solid ${C.gold}` }}
      />
      <div className="mt-4 font-display text-[18px] font-extrabold">{m.full_name}</div>
      <div className="text-[12px] font-bold text-[#a17615]">
        {[m.city, m.state].filter(Boolean).join(", ") || "India"}
      </div>
      {m.wall_tagline && (
        <p className="mt-3 flex-1 text-[13.5px] italic leading-[1.6]" style={{ color: C.muted }}>
          <Quote className="mr-1 inline h-3 w-3" style={{ color: C.gold }} />
          {m.wall_tagline}
        </p>
      )}
    </div>
  );
}

/* ============================================================
   Wall card
   ============================================================ */
function WallCard({ m }: { m: WallMember }) {
  const tool = TOOLS.find((t) => t.v === m.primary_tool);
  const toolColor = tool?.c ?? C.coral;
  const location = [m.city, m.state].filter(Boolean).join(", ");
  return (
    <div
      className="og-wall-card hover-lift relative flex flex-col rounded-[14px] p-5"
      style={{
        border: `1.5px solid ${C.dark}`,
        boxShadow: `2px 2px 0 0 ${C.dark}`,
      }}
    >
      {/* corner sparkle accent */}
      <Sparkles
        className="og-sparkle absolute right-2 top-2 h-3 w-3"
        style={{ color: C.gold, zIndex: 3 }}
      />

      <div className="relative z-[3] mb-3 flex items-center justify-between gap-2">
        <span
          className="og-badge-shine inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-[0.14em]"
          style={{
            border: `1px solid ${C.dark}`,
            boxShadow: `1px 1px 0 0 ${C.dark}`,
          }}
        >
          <Crown className="h-2.5 w-2.5" />
          OG #{String(m.og_number).padStart(2, "0")}
        </span>
        {tool && (
          <span
            className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold"
            style={{
              background: C.cream,
              color: C.text,
              border: `1px solid ${C.border}`,
            }}
          >
            <span
              className="h-1.5 w-1.5 rounded-full"
              style={{ background: toolColor, boxShadow: `0 0 6px ${toolColor}` }}
            />
            {tool.l}
          </span>
        )}
      </div>

      {/* Avatar with animated halo */}
      <div className="relative z-[3] mb-3 h-14 w-14">
        <span
          className="og-wall-halo"
          style={{ inset: -6 }}
          aria-hidden
        />
        <img
          src={avatarUrl(m.full_name)}
          alt=""
          className="relative h-14 w-14 rounded-full"
          style={{
            background: C.cream,
            border: `2px solid ${C.dark}`,
            boxShadow: `0 0 0 2px ${C.white}, 0 0 0 3.5px ${toolColor}`,
          }}
        />
        <BadgeCheck
          className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full"
          style={{
            color: C.white,
            fill: C.gold,
            background: C.white,
            borderRadius: "9999px",
          }}
        />
      </div>

      <div className="relative z-[3] flex items-center gap-1.5 font-display text-[15px] font-extrabold leading-tight">
        <span className="truncate">{m.full_name}</span>
      </div>
      {location && (
        <div className="relative z-[3] mt-0.5 flex items-center gap-1 text-[11px] font-semibold" style={{ color: C.muted }}>
          <MapPin className="h-2.5 w-2.5" style={{ color: C.coral }} />
          <span className="truncate">{location}</span>
        </div>
      )}

      {m.wall_tagline && (
        <p
          className="relative z-[3] mt-2 text-[12px] italic leading-[1.5]"
          style={{ color: C.muted }}
        >
          <Quote className="mr-1 inline h-2.5 w-2.5" style={{ color: C.gold }} />
          {m.wall_tagline}
        </p>
      )}

      <div className="relative z-[3] mt-auto flex items-center justify-between pt-3">
        <span
          className="text-[9px] font-black uppercase tracking-[0.18em]"
          style={{ color: C.gold }}
        >
          Founding Builder
        </span>
        <div className="flex gap-1.5">
          {m.linkedin_url && (
            <a
              href={m.linkedin_url}
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn"
              className="grid h-7 w-7 place-items-center rounded-[6px] border-[1.5px] text-[#7a7a7a] transition-all hover:-translate-y-0.5 hover:text-[#E8623A]"
              style={{ borderColor: C.border, background: C.cream }}
            >
              <Linkedin className="h-3.5 w-3.5" />
            </a>
          )}
          {m.twitter_url && (
            <a
              href={m.twitter_url}
              target="_blank"
              rel="noreferrer"
              aria-label="Twitter"
              className="grid h-7 w-7 place-items-center rounded-[6px] border-[1.5px] text-[#7a7a7a] transition-all hover:-translate-y-0.5 hover:text-[#E8623A]"
              style={{ borderColor: C.border, background: C.cream }}
            >
              <Twitter className="h-3.5 w-3.5" />
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

