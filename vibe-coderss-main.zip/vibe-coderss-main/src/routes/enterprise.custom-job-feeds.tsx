import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/enterprise/custom-job-feeds")({
  head: () => ({
    meta: [
      { title: "Custom Job Feeds · VibeCode" },
      { name: "description", content: "Instead of posting one job, get a continuous feed of qualified builders matched to your open roles — weekly." },
      { property: "og:title", content: "Custom Job Feeds · VibeCode" },
      { property: "og:description", content: "Instead of posting one job, get a continuous feed of qualified builders matched to your open roles — weekly." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/enterprise/custom-job-feeds" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/enterprise/custom-job-feeds" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Custom Job Feeds"
      breadcrumb={[{"label":"Enterprise","to":"/"}]}
      title="Curated pipelines by role."
      intro="Instead of posting one job, get a continuous feed of qualified builders matched to your open roles — weekly."
      toc={[{"id":"how","label":"How the feed works"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="how" title="How the feed works"><NotionList items={["You define the role signature — stack, seniority, city, availability","Our matching model surfaces 10-20 new candidates weekly","You mark thumbs up/down — the model tunes to your taste","Shortlisted builders get a warm intro from us on your behalf"]} /></NotionSection>
      <NotionCallout emoji="📥" tone="cream">Built for teams hiring 3+ AI engineers per quarter. Ask about our multi-role pricing.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="How is this different from LinkedIn Recruiter?" a="We index shipped work, not stated skills. Every candidate has a verifiable portfolio." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
