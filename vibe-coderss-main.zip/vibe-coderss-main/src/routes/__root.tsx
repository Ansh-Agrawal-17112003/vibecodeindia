import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
  redirect,
} from "@tanstack/react-router";
import { createIsomorphicFn } from "@tanstack/react-start";
import { useEffect, useState, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { Toaster } from "@/components/ui/sonner";
import { AuthProvider } from "@/hooks/useAuth";
import { TermsConsentModal } from "@/components/legal/TermsConsentModal";
import { RevealObserver } from "@/components/motion/PageMotion";

import { EarlyAccessModal } from "@/components/site/EarlyAccessModal";
import { OgFounderWelcomeModal } from "@/components/site/OgFounderWelcomeModal";
import { ThanksgivingModal } from "@/components/site/ThanksgivingModal";
import { RoleChoiceModal } from "@/components/site/RoleChoiceModal";
import { Preloader } from "@/components/site/Preloader";
import { PublicRouteGuard } from "@/components/auth/PublicRouteGuard";

import { isPathAllowedInMaintenance, shouldGateHost } from "@/lib/maintenance";

const getRequestHostname = createIsomorphicFn()
  .server(() => {
    try {
      // Dynamic require keeps this server-only module out of the client bundle.
      const { getRequestHost } = require("@tanstack/react-start/server") as {
        getRequestHost: (opts?: { xForwardedHost?: boolean }) => string;
      };
      return getRequestHost({ xForwardedHost: true }) ?? "";
    } catch {
      return "";
    }
  })
  .client(() => (typeof window !== "undefined" ? window.location.hostname : ""));


function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90">
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">This page didn't load</h1>
        <p className="mt-2 text-sm text-muted-foreground">Something went wrong on our end.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }} className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Try again</button>
          <a href="/" className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground">Go home</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  beforeLoad: ({ location }) => {
    // Maintenance / early-access-only mode:
    // On gated hosts (live domains), any non-allowed path is redirected to
    // /early-access at load time — no client-side flash, no blank spinner.
    const host = getRequestHostname();
    if (!host) return;
    if (!shouldGateHost(host)) return;
    if (isPathAllowedInMaintenance(location.pathname)) return;
    throw redirect({ to: "/early-access", replace: true });
  },
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "VibeCode — India's Largest AI Builder Community" },
      { name: "description", content: "The home feed for India's AI builders. Ship in public, share prompts, workflows and projects, and get discovered by 120,000+ vibe coders." },
      { property: "og:title", content: "VibeCode — India's Largest AI Builder Community" },
      { property: "og:description", content: "The home feed for India's AI builders. Ship in public, share prompts, workflows and projects, and get discovered by 120,000+ vibe coders." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "VibeCode — India's Largest AI Builder Community" },
      { name: "twitter:description", content: "The home feed for India's AI builders. Ship in public, share prompts, workflows and projects, and get discovered by 120,000+ vibe coders." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/da6537bd-821e-471d-b5e7-8b74a267c62e/id-preview-1129da65--f48ce3b8-96de-426c-a0e7-9141f9297d2e.lovable.app-1783163054451.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/da6537bd-821e-471d-b5e7-8b74a267c62e/id-preview-1129da65--f48ce3b8-96de-426c-a0e7-9141f9297d2e.lovable.app-1783163054451.png" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,600;12..96,700;12..96,800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" },
      { rel: "stylesheet", href: appCss },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "VibeCode",
          url: "https://joinvibecode.xyz",
          logo: "https://joinvibecode.xyz/vibecode-logo.svg",
          description: "India's largest community for AI builders, vibe coders, and no-code makers.",
          sameAs: ["https://joinvibecode.xyz"],
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "VibeCode",
          url: "https://joinvibecode.xyz",
          potentialAction: {
            "@type": "SearchAction",
            target: "https://joinvibecode.xyz/search?q={search_term_string}",
            "query-input": "required name=search_term_string",
          },
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});


function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function HydratedToaster() {
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  if (!hydrated) return null;
  return <Toaster position="top-center" richColors />;
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isStandalone = pathname === "/early-access";
  // Pre-launch: suppress the post-signup "welcome / choose role" modals on
  // early-access + founders-wall + onboarding flows. These are launch-day
  // (Aug 4, 2026) modals meant for users signing in through the landing page
  // after the platform officially opens — not for OG founders claiming spots.
  const LAUNCH_TS = new Date("2026-08-04T00:00:00+05:30").getTime();
  const preLaunch = Date.now() < LAUNCH_TS;
  const suppressWelcomeModals =
    preLaunch ||
    pathname === "/founders-wall" ||
    pathname === "/early-access" ||
    pathname.startsWith("/onboarding");
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Preloader />
        {!isStandalone && <PublicRouteGuard />}
        
        <RevealObserver />
        {!isStandalone && <EarlyAccessModal />}
        {!isStandalone && <OgFounderWelcomeModal />}
        {!suppressWelcomeModals && <ThanksgivingModal />}
        {!suppressWelcomeModals && <RoleChoiceModal />}
        <Outlet />
        {!isStandalone && <TermsConsentModal />}
        <HydratedToaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

