import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/pricing_/enterprise")({
  head: () => ({
    meta: [
      { title: "Enterprise · VibeCode" },
      { name: "description", content: "For teams hiring at scale, running branded communities, or embedding VibeCode into their workflow." },
      { property: "og:title", content: "Enterprise · VibeCode" },
      { property: "og:description", content: "For teams hiring at scale, running branded communities, or embedding VibeCode into their workflow." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/pricing/enterprise" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/pricing/enterprise" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Enterprise"
      breadcrumb={[{"label":"Pricing","to":"/pricing"}]}
      title="Custom rollouts."
      intro="For teams hiring at scale, running branded communities, or embedding VibeCode into their workflow."
      toc={[{"id":"includes","label":"What is included"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="includes" title="What is included"><NotionFeatureGrid items={[{"title":"Dedicated CSM","description":"A named partner from day one, not a shared inbox."},{"title":"SLA + priority support","description":"4-hour response, uptime guarantee, quarterly reviews."},{"title":"SSO + audit logs","description":"SAML, SCIM, and exportable audit trails."},{"title":"Custom integrations","description":"ATS sync, HRIS sync, internal tools — we build it."}]} /></NotionSection>
      <NotionCallout emoji="🏢" tone="gold">Enterprise pricing is scoped to your seats, roles, and integration needs. Talk to sales for a quote.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Do you offer on-prem?" a="No. Enterprise runs on our cloud with region pinning for data residency." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
