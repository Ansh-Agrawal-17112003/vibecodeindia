import { createFileRoute } from "@tanstack/react-router";
import { NotionPageShell, NotionSection, NotionFeatureGrid, NotionList, NotionCallout, NotionQuote, NotionToggle } from "@/components/site/NotionPageShell";

export const Route = createFileRoute("/pricing_/individual")({
  head: () => ({
    meta: [
      { title: "Individual Plans · VibeCode" },
      { name: "description", content: "Ship for free forever. Upgrade to Pro when you start freelancing and need more visibility." },
      { property: "og:title", content: "Individual Plans · VibeCode" },
      { property: "og:description", content: "Ship for free forever. Upgrade to Pro when you start freelancing and need more visibility." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://joinvibecode.xyz/pricing/individual" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://joinvibecode.xyz/pricing/individual" }],
  }),
  component: Page,
});

function Page() {
  return (
    <NotionPageShell
      eyebrow="Individual Plans"
      breadcrumb={[{"label":"Pricing","to":"/pricing"}]}
      title="For solo builders."
      intro="Ship for free forever. Upgrade to Pro when you start freelancing and need more visibility."
      toc={[{"id":"plans","label":"Two plans, no tricks"}]}
      cta={{ label: "Get started free", to: "/auth", sub: "Join 120,000+ AI builders shipping in public." }}
    >
      <NotionSection id="plans" title="Two plans, no tricks"><NotionFeatureGrid items={[{"title":"Builder — ₹0 forever","description":"Full profile, unlimited posts, unlimited applications, all communities."},{"title":"Pro — ₹499/month","description":"Top of search, verified badge, featured slots, advanced analytics."}]} /></NotionSection>
      <NotionCallout emoji="💳" tone="coral">Pro is billed monthly, cancel anytime. UPI, cards, and net-banking supported.</NotionCallout>

      <NotionSection id="faq" title="FAQ">
        <div>
          <NotionToggle q="Do I need Pro to get hired?" a="No. Most builders get hired on the free plan. Pro is for freelancers who want to be top of search." />
          <NotionToggle q="Is there a student discount?" a="Yes — 50% off Pro with a verified .edu or college ID." />
        </div>
      </NotionSection>
    </NotionPageShell>
  );
}
