import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus, Search } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Shell } from "@/components/site/Shell";
import { CommunityCard } from "@/components/cards/CommunityCard";
import { AutocompleteInput } from "@/components/site/AutocompleteInput";
import { StatsStrip } from "@/components/site/StatsStrip";
import { allCommunities } from "@/lib/mock-data";
import type { Community } from "@/lib/mock-data";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/communities")({
  head: () => ({
    meta: [
      { title: 'Communities · VibeCode' },
      { name: "description", content: '450+ communities for AI tools, roles and cities — join builders shipping with the same stack as you.' },
      { property: "og:title", content: 'Communities · VibeCode' },
      { property: "og:description", content: '450+ communities for AI tools, roles and cities — join builders shipping with the same stack as you.' },
      { property: "og:url", content: 'https://joinvibecode.xyz/communities' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Communities · VibeCode' },
      { name: "twitter:description", content: '450+ communities for AI tools, roles and cities — join builders shipping with the same stack as you.' },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/communities' }],
  }),
  component: CommunitiesPage,
});

const CATEGORIES = ["All", "AI Agents", "Automation", "No-Code", "Open Source", "Industry"];
const SORTS = ["Most Members", "Newest", "Trending"] as const;
type Sort = (typeof SORTS)[number];

function categoryOf(c: { name: string; slug: string; description: string }) {
  const s = (c.name + " " + c.slug + " " + c.description).toLowerCase();
  if (/(agent|gpt|claude|llm|openai)/.test(s)) return "AI Agents";
  if (/(n8n|automat|workflow|make)/.test(s)) return "Automation";
  if (/(lovable|cursor|bolt|no.?code)/.test(s)) return "No-Code";
  if (/(open.?source|llama|mistral)/.test(s)) return "Open Source";
  return "Industry";
}

function CommunitiesPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [priceFilter, setPriceFilter] = useState<"All" | "Free" | "Paid">("All");
  const [sort, setSort] = useState<Sort>("Most Members");
  const [dbRows, setDbRows] = useState<Community[]>([]);

  const loadCommunities = () => {
    supabase
      .from("communities")
      .select("id, slug, name, icon, description, member_count, posts_this_week, hue, is_official, status, pricing_type, price_inr, is_demo")
      .eq("status", "approved")
      .order("is_official", { ascending: false })
      .order("member_count", { ascending: false })
      .then(({ data }) => {
        if (!data) return;
        setDbRows(data.map((r: any) => ({
          id: `db-${r.id}`,
          slug: r.slug,
          name: r.name,
          icon: r.icon ?? "🚀",
          description: r.description ?? "",
          members: r.member_count ?? 0,
          postsThisWeek: r.posts_this_week ?? 0,
          hue: r.hue ?? 200,
          isOfficial: r.is_official ?? false,
          is_demo: r.is_demo ?? false,
          pricing_type: r.pricing_type ?? "free",
          price_inr: r.price_inr ?? 0,
        }) as any));
      });
  };

  useEffect(() => {
    loadCommunities();
    const channel = supabase
      .channel(`communities:list:${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "communities" }, () => loadCommunities())
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "communities" }, () => loadCommunities())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const merged = useMemo(() => {
    const bySlug = new Map<string, Community>();
    // DB first so real rows win over mock on slug collision
    for (const c of dbRows) bySlug.set(c.slug, c);
    for (const c of allCommunities()) if (!bySlug.has(c.slug)) bySlug.set(c.slug, { ...c, is_demo: true } as any);
    return Array.from(bySlug.values());
  }, [dbRows]);

  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    let arr = merged;
    if (t) arr = arr.filter((c) => c.name.toLowerCase().includes(t) || c.description.toLowerCase().includes(t));
    if (cat !== "All") arr = arr.filter((c) => categoryOf(c) === cat);
    if (priceFilter !== "All") {
      arr = arr.filter((c: any) => {
        const paid = (c.pricing_type ?? "free") !== "free" && (c.price_inr ?? 0) > 0;
        return priceFilter === "Paid" ? paid : !paid;
      });
    }
    arr = [...arr];
    if (sort === "Most Members") arr.sort((a, b) => (Number(b.isOfficial) - Number(a.isOfficial)) || (b.members - a.members));
    else if (sort === "Newest") arr.sort((a, b) => String(b.id).localeCompare(String(a.id)));
    else arr.sort((a, b) => b.postsThisWeek - a.postsThisWeek);
    return arr;
  }, [q, cat, sort, merged, priceFilter]);

  return (
    <Shell>
      <div className="container-page py-5 sm:py-8">
        <div className="mb-4 flex flex-col gap-3 text-center sm:mb-6 sm:flex-row sm:items-start sm:justify-between sm:gap-4 sm:text-left">
          <div className="min-w-0 w-full">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground sm:text-xs">Network</div>
            <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight sm:text-3xl md:text-4xl">Communities</h1>
            <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
              Join builders sharing knowledge, projects and opportunities · {list.length} communities
            </p>
          </div>
          <Link
            to="/submit"
            className="hidden sm:inline-flex h-10 shrink-0 items-center gap-2 self-start rounded-full border-[1.5px] border-foreground bg-coral px-4 text-xs font-bold text-white shadow-[3px_3px_0_0_#0F0F0F] hover:-translate-y-0.5 hover:shadow-[5px_5px_0_0_#0F0F0F] sm:h-11 sm:px-5 sm:text-sm"
          >
            <Plus className="h-4 w-4" /> Create Community
          </Link>
        </div>

        <div className="hidden sm:block">
          <StatsStrip items={[
            { label: "Communities", value: 110 },
            { label: "Total Members", value: 847, suffix: "K+" },
            { label: "Posts / Week", value: 12.4, suffix: "K" },
            { label: "Categories", value: 18 },
          ]} />
        </div>



        <div className="card-flat mb-4 flex items-center gap-2 p-2">
          <Search className="ml-2 h-4 w-4 text-muted-foreground" />
          <AutocompleteInput
            value={q}
            onChange={setQ}
            placeholder="Search communities..."
            typewriter={["Indie hackers of India...", "AI builders Bengaluru...", "No-code founders...", "n8n automation crew...", "Prompt engineers guild..."]}
            className="h-10 w-full bg-transparent text-sm outline-none"
            suggestions={allCommunities().flatMap((c) => [c.name, c.description])}
          />
        </div>

        <div className="mb-6 hidden flex-col gap-3 sm:flex lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`rounded-full border-[1.5px] border-foreground px-3.5 py-1.5 text-xs font-bold transition ${
                  cat === c ? "bg-foreground text-background" : "bg-card text-foreground hover:bg-surface"
                }`}
              >
                {c}
              </button>
            ))}
            {(["All", "Free", "Paid"] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPriceFilter(p)}
                className={`rounded-full border-[1.5px] border-foreground px-3.5 py-1.5 text-xs font-bold transition ${
                  priceFilter === p ? "bg-coral text-white" : "bg-card text-foreground hover:bg-surface"
                }`}
              >{p}</button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-muted-foreground">Sort:</span>
            {SORTS.map((s) => (
              <button
                key={s}
                onClick={() => setSort(s)}
                className={`rounded-full px-3 py-1 text-xs font-bold ${
                  sort === s ? "text-coral underline underline-offset-4" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>


        {list.length === 0 ? (
          <div className="card-editorial p-10 text-center">
            <p className="text-sm text-muted-foreground">No communities match your filters.</p>
          </div>
        ) : (
          <div className="grid gap-4 sm:gap-5 md:grid-cols-2 lg:grid-cols-3">
            {list.map((c) => (
              <CommunityCard key={c.id} c={c} />
            ))}
          </div>
        )}
      </div>
    </Shell>
  );
}
