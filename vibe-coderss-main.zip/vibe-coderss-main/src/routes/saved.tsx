import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bookmark, Loader2 } from "lucide-react";
import { Shell } from "@/components/site/Shell";
import { listBookmarks, timeAgo } from "@/lib/feed-api";
import { useAuth } from "@/hooks/useAuth";
import { useSavedItems, type SavedKind } from "@/lib/saved-items";
import { allPrompts, allWorkflows, allTemplates, allProjects } from "@/lib/mock-data";
import { PromptCard } from "@/components/cards/PromptCard";
import { WorkflowCard } from "@/components/cards/WorkflowCard";
import { TemplateCard } from "@/components/cards/TemplateCard";
import { ProjectCard } from "@/components/cards/ProjectCard";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/saved")({
  head: () => ({
    meta: [
      { title: 'Saved · VibeCode' },
      { name: "description", content: "Everything you've bookmarked on VibeCode — builders, projects, prompts, tools and workflows." },
      { property: "og:title", content: 'Saved · VibeCode' },
      { property: "og:description", content: "Everything you've bookmarked on VibeCode — builders, projects, prompts, tools and workflows." },
      { property: "og:url", content: 'https://joinvibecode.xyz/saved' },
      { property: "og:type", content: 'website' },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: 'Saved · VibeCode' },
      { name: "twitter:description", content: "Everything you've bookmarked on VibeCode — builders, projects, prompts, tools and workflows." },
    ],
    links: [{ rel: "canonical", href: 'https://joinvibecode.xyz/saved' }],
  }),
  component: SavedPage,
});

type Tab = "posts" | "prompt" | "workflow" | "template" | "project";

function SavedPage() {
  const { user, loading } = useAuth();
  const [tab, setTab] = useState<Tab>("posts");
  const { items } = useSavedItems();

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["saved", user?.id],
    queryFn: () => listBookmarks(100),
    enabled: !!user,
  });

  const saved = useMemo(() => {
    const byKind = (k: SavedKind) => items.filter((i) => i.kind === k).map((i) => i.id);
    const pIds = new Set(byKind("prompt"));
    const wIds = new Set(byKind("workflow"));
    const tIds = new Set(byKind("template"));
    const prIds = new Set(byKind("project"));
    return {
      prompts: allPrompts().filter((x) => pIds.has(x.id)),
      workflows: allWorkflows().filter((x) => wIds.has(x.id)),
      templates: allTemplates().filter((x) => tIds.has(x.slug)),
      projects: allProjects().filter((x) => prIds.has(x.id)),
    };
  }, [items]);

  const counts: Record<Tab, number> = {
    posts: posts.length,
    prompt: saved.prompts.length,
    workflow: saved.workflows.length,
    template: saved.templates.length,
    project: saved.projects.length,
  };

  const tabs: { key: Tab; label: string }[] = [
    { key: "posts", label: "Posts" },
    { key: "prompt", label: "Prompts" },
    { key: "workflow", label: "Workflows" },
    { key: "template", label: "Templates" },
    { key: "project", label: "Projects" },
  ];

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-6">
        <div className="mb-4 flex items-center gap-2">
          <Bookmark className="h-5 w-5 text-coral" />
          <h1 className="font-display text-xl font-black">Saved</h1>
        </div>

        <div className="mb-5 flex flex-wrap gap-2 border-b-[1.5px] border-[#0F0F0F]/10 pb-3">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "rounded-full border-[1.5px] px-3 py-1.5 text-xs font-bold transition",
                tab === t.key
                  ? "border-[#0F0F0F] bg-[#0F0F0F] text-white shadow-[2px_2px_0_0_#0F0F0F]"
                  : "border-[#0F0F0F]/25 bg-white text-foreground hover:border-coral hover:text-coral",
              )}
            >
              {t.label} <span className="ml-1 opacity-70">({counts[t.key]})</span>
            </button>
          ))}
        </div>

        {tab === "posts" && (
          loading || isLoading ? (
            <div className="grid place-items-center py-16 text-sm text-muted-foreground">
              <Loader2 className="mb-2 h-5 w-5 animate-spin" /> Loading…
            </div>
          ) : !user ? (
            <EmptyState>
              <Link to="/auth" className="font-bold text-coral hover:underline">Sign in</Link> to see your saved posts.
            </EmptyState>
          ) : posts.length === 0 ? (
            <EmptyState>
              <div className="text-sm font-bold">Nothing saved yet.</div>
              <p className="mt-1 text-xs text-muted-foreground">Tap the bookmark icon on any post to save it for later.</p>
            </EmptyState>
          ) : (
            <div className="mx-auto max-w-2xl space-y-3">
              {posts.map((p) => (
                <article key={p.id} className="rounded-2xl border-[1.5px] border-[#0F0F0F] bg-white p-4 shadow-[3px_3px_0_0_#0F0F0F]">
                  <div className="flex items-center gap-3">
                    <img
                      src={p.author?.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${p.author?.username ?? p.author_id}`}
                      alt=""
                      className="h-9 w-9 rounded-full border-[1.5px] border-[#0F0F0F]"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-display text-sm font-bold">{p.author?.display_name || p.author?.username || "Anonymous"}</div>
                      <div className="truncate text-xs text-muted-foreground">{timeAgo(p.created_at)}</div>
                    </div>
                  </div>
                  {p.body && <div className="mt-2 whitespace-pre-wrap text-sm leading-relaxed">{p.body}</div>}
                  {p.image_urls?.[0] && (
                    <img src={p.image_urls[0]} alt="" className="mt-2 max-h-72 w-full rounded-lg border border-[#0F0F0F]/20 object-cover" />
                  )}
                  <div className="mt-3 flex items-center justify-between text-[11px] text-muted-foreground">
                    <span>{p.like_count} likes · {p.comment_count} comments</span>
                    <Link to="/vibe" hash={`post-${p.id}`} className="font-bold text-coral hover:underline">Open →</Link>
                  </div>
                </article>
              ))}
            </div>
          )
        )}

        {tab === "prompt" && (
          saved.prompts.length === 0 ? (
            <EmptyKind kind="prompts" to="/prompts" />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {saved.prompts.map((p) => <PromptCard key={p.id} p={p} />)}
            </div>
          )
        )}

        {tab === "workflow" && (
          saved.workflows.length === 0 ? (
            <EmptyKind kind="workflows" to="/workflows" />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {saved.workflows.map((w) => <WorkflowCard key={w.id} w={w} />)}
            </div>
          )
        )}

        {tab === "template" && (
          saved.templates.length === 0 ? (
            <EmptyKind kind="templates" to="/templates" />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {saved.templates.map((t) => <TemplateCard key={t.slug} t={t} />)}
            </div>
          )
        )}

        {tab === "project" && (
          saved.projects.length === 0 ? (
            <EmptyKind kind="projects" to="/projects" />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {saved.projects.map((p) => <ProjectCard key={p.id} p={p} />)}
            </div>
          )
        )}
      </div>
    </Shell>
  );
}

function EmptyState({ children }: { children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-2xl rounded-xl border-[1.5px] border-dashed border-[#0F0F0F]/25 bg-white p-6 text-center text-sm">
      {children}
    </div>
  );
}

function EmptyKind({ kind, to }: { kind: string; to: string }) {
  return (
    <EmptyState>
      <div className="text-sm font-bold">No saved {kind} yet.</div>
      <p className="mt-1 text-xs text-muted-foreground">Tap the bookmark on any {kind.slice(0, -1)} card to save it here.</p>
      <Link to={to} className="mt-3 inline-block font-bold text-coral hover:underline">Browse {kind} →</Link>
    </EmptyState>
  );
}
