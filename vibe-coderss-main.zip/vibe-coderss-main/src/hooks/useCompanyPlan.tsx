import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export type CompanyRow = {
  id: string;
  name: string;
  logo_url: string | null;
  plan: string;
  plan_expires_at: string | null;
};

export function useCompanyPlan() {
  const { user } = useAuth();
  const [company, setCompany] = useState<CompanyRow | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setCompany(null);
      setLoading(false);
      return;
    }
    (async () => {
      const { data } = await (supabase.from("companies") as any)
        .select("id, name, logo_url, plan, plan_expires_at")
        .eq("owner_profile_id", user.id)
        .order("created_at", { ascending: true })
        .limit(1)
        .maybeSingle();
      setCompany((data as CompanyRow) ?? null);
      setLoading(false);
    })();
  }, [user?.id]);

  const isHiringUltra =
    !!company &&
    company.plan === "hiring_pro" &&
    (!company.plan_expires_at || new Date(company.plan_expires_at) > new Date());

  return { company, isHiringUltra, loading };
}
