import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export type Plan = "free" | "pro" | "business";

export interface Subscription {
  id: string;
  profile_id: string;
  plan: Plan;
  status: "active" | "expired" | "cancelled";
  current_period_start: string;
  current_period_end: string | null;
}

export type PlatformSettings = Record<string, string>;

export function usePlatformSettings() {
  const [settings, setSettings] = useState<PlatformSettings>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    supabase
      .rpc("get_public_platform_settings")
      .then(({ data }) => {
        if (!alive) return;
        const out: PlatformSettings = {};
        (data ?? []).forEach((r: { key: string; value: string | null }) => {
          out[r.key] = r.value ?? "";
        });
        setSettings(out);
        setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, []);

  return { settings, loading };
}

export function useSubscription() {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!user) {
      setSubscription(null);
      setLoading(false);
      return;
    }
    const { data } = await supabase
      .from("subscriptions")
      .select("*")
      .eq("profile_id", user.id)
      .maybeSingle();
    // Expired?
    if (data && data.current_period_end && new Date(data.current_period_end) < new Date()) {
      setSubscription({ ...data, plan: "free", status: "expired" } as Subscription);
    } else {
      setSubscription((data as Subscription | null) ?? { id: "", profile_id: user.id, plan: "free", status: "active", current_period_start: new Date().toISOString(), current_period_end: null });
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { subscription, loading, refresh, plan: subscription?.plan ?? "free" };
}

export function useSearchLimit() {
  const { user } = useAuth();
  const { settings } = usePlatformSettings();
  const { plan } = useSubscription();
  const [used, setUsed] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const limit = Number(settings.free_search_limit ?? "3");
  const unlimited = plan === "pro" || plan === "business";

  const refresh = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    const month = new Date().toISOString().slice(0, 7);
    const { data } = await supabase
      .from("search_usage")
      .select("search_count")
      .eq("profile_id", user.id)
      .eq("month_year", month)
      .maybeSingle();
    setUsed(data?.search_count ?? 0);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const consume = useCallback(async (): Promise<{ ok: boolean; used: number; limit: number; unlimited: boolean }> => {
    if (unlimited) return { ok: true, used, limit, unlimited: true };
    if (!user) return { ok: false, used, limit, unlimited: false };
    if (used >= limit) return { ok: false, used, limit, unlimited: false };
    const { data, error } = await supabase.rpc("increment_search_usage");
    if (error) return { ok: false, used, limit, unlimited: false };
    const newCount = (data as number) ?? used + 1;
    setUsed(newCount);
    return { ok: newCount <= limit, used: newCount, limit, unlimited: false };
  }, [unlimited, user, used, limit]);

  return { used, limit, unlimited, remaining: Math.max(0, limit - used), loading, consume, refresh };
}
