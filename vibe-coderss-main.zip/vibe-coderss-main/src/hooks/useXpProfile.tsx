import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";

export type XpProfile = {
  total_xp: number;
  current_level: string;
  vibecoin_balance: number;
  login_streak: number;
  longest_streak: number;
  last_login_date: string | null;
  streak_badges: string[];
};

// Cross-component event bus so every mounted useXpProfile instance refreshes
// the moment XP or coins are awarded, without waiting for realtime latency.
const XP_EVENT = "vc:xp-updated";
function emitXpUpdated() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent(XP_EVENT));
  }
}

export function useXpProfile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<XpProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!user) { setProfile(null); setLoading(false); return; }
    const { data } = await supabase
      .from("profiles")
      .select("total_xp,current_level,vibecoin_balance,login_streak,longest_streak,last_login_date,streak_badges")
      .eq("id", user.id)
      .maybeSingle();
    setProfile(data as XpProfile | null);
    setLoading(false);
  }, [user]);

  useEffect(() => { refresh(); }, [refresh]);

  // Instant in-app refresh: any awardXp / awardCoins call anywhere in the app
  // dispatches this event, so all XP displays update immediately.
  useEffect(() => {
    if (!user) return;
    const onEvent = () => refresh();
    window.addEventListener(XP_EVENT, onEvent);
    return () => window.removeEventListener(XP_EVENT, onEvent);
  }, [user, refresh]);

  // Realtime: refresh whenever this user's profile row changes in the DB
  // (covers XP awarded from server-side triggers or other devices/tabs).
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel(`profile-xp:${user.id}:${Math.random().toString(36).slice(2, 8)}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "profiles", filter: `id=eq.${user.id}` },
        () => refresh(),
      )
      .subscribe();
    return () => {
      try { supabase.removeChannel(channel); } catch { /* noop */ }
    };
  }, [user, refresh]);

  return { profile, loading, refresh };
}

/** Award XP for a user action. Non-blocking; swallows errors. */
export async function awardXp(actionType: string, xp: number, ref?: { id?: string; type?: string }) {
  try {
    await supabase.rpc("award_xp", {
      _action_type: actionType,
      _xp: xp,
      _reference_id: ref?.id ?? undefined,
      _reference_type: ref?.type ?? undefined,
    });
    emitXpUpdated();
  } catch (e) {
    console.warn("awardXp failed", e);
  }
}

export async function awardCoins(type: "earned" | "spent" | "redeemed", amount: number, reason: string, referenceId?: string) {
  const { data, error } = await supabase.rpc("award_vibecoins", {
    _type: type,
    _amount: amount,
    _reason: reason,
    _reference_id: referenceId ?? undefined,
  });

  if (error) throw error;
  emitXpUpdated();
  return data as number;
}
