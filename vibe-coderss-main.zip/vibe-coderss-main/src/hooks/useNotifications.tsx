import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";


export interface NotificationRow {
  id: string;
  user_id: string;
  actor_id: string | null;
  type: string;
  title: string;
  body: string | null;
  link: string | null;
  read_at: string | null;
  created_at: string;
}

export function useNotifications() {
  const { user } = useAuth();
  const [items, setItems] = useState<NotificationRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) {
      setItems([]);
      setLoading(false);
      return;
    }
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100);
    setItems((data as NotificationRow[]) ?? []);
    setLoading(false);
  }, [user]);


  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!user) return;
    let channel: ReturnType<typeof supabase.channel> | null = null;
    try {
      channel = supabase
        .channel(`notif-${user.id}`)
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
          (payload) => {
            const row = payload.new as NotificationRow;
            setItems((prev) => {
              const withoutMock = prev.filter((n) => !n.id.startsWith("mock-"));
              return withoutMock.some((n) => n.id === row.id) ? withoutMock : [row, ...withoutMock];
            });
            toast(row.title, { description: row.body ?? undefined });
          },
        )
        .subscribe((status) => {
          if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
            console.warn("[notifications] realtime status:", status);
          }
        });
    } catch (e) {
      console.warn("[notifications] realtime subscribe failed", e);
    }
    return () => {
      if (channel) supabase.removeChannel(channel);
    };
  }, [user]);


  const unread = items.filter((n) => !n.read_at).length;

  const markAllRead = useCallback(async () => {
    const nowIso = new Date().toISOString();
    if (user) {
      await supabase
        .from("notifications")
        .update({ read_at: nowIso })
        .is("read_at", null);
    }
    setItems((prev) => prev.map((n) => ({ ...n, read_at: n.read_at ?? nowIso })));
  }, [user]);

  const markOneRead = useCallback(async (id: string) => {
    const nowIso = new Date().toISOString();
    if (!id.startsWith("mock-")) {
      await supabase.from("notifications").update({ read_at: nowIso }).eq("id", id);
    }
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read_at: nowIso } : n)));
  }, []);

  return { items, unread, loading, markAllRead, markOneRead, refresh: load };
}

export function useUnreadMessages() {
  const { user } = useAuth();
  const [count, setCount] = useState(0);

  const load = useCallback(async () => {
    if (!user) return setCount(0);
    const { count: c } = await supabase
      .from("messages")
      .select("id", { count: "exact", head: true })
      .eq("recipient_id", user.id)
      .is("read_at", null);
    setCount(c ?? 0);
  }, [user]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!user) return;
    let ch: ReturnType<typeof supabase.channel> | null = null;
    try {
      ch = supabase
        .channel(`msg-unread-${user.id}`)
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "messages", filter: `recipient_id=eq.${user.id}` },
          () => load(),
        )
        .subscribe((status) => {
          if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
            console.warn("[messages] realtime status:", status);
          }
        });
    } catch (e) {
      console.warn("[messages] realtime subscribe failed", e);
    }
    return () => {
      if (ch) supabase.removeChannel(ch);
    };
  }, [user, load]);


  return { count, refresh: load };
}
