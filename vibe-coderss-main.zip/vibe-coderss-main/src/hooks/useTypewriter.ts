import { useEffect, useState } from "react";

export function useTypewriter(
  words: string[],
  { type = 60, pause = 1600, erase = 30 }: { type?: number; pause?: number; erase?: number } = {},
) {
  const [text, setText] = useState("");
  const [i, setI] = useState(0);
  const [del, setDel] = useState(false);
  useEffect(() => {
    if (!words.length) return;
    const word = words[i % words.length];
    if (!del && text === word) {
      const t = setTimeout(() => setDel(true), pause);
      return () => clearTimeout(t);
    }
    if (del && text === "") {
      setDel(false);
      setI((n) => (n + 1) % words.length);
      return;
    }
    const t = setTimeout(
      () => setText(del ? word.slice(0, text.length - 1) : word.slice(0, text.length + 1)),
      del ? erase : type,
    );
    return () => clearTimeout(t);
  }, [text, del, i, words, type, pause, erase]);
  return text;
}
