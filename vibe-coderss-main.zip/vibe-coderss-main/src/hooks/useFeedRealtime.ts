import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Subscribes to realtime changes on posts/likes/comments and invokes `onChange`
 * whenever anything relevant happens. Handles proper cleanup.
 *
 * Uses a unique channel name per hook instance to avoid the Supabase
 * "cannot add postgres_changes callbacks after subscribe()" error that
 * occurs when the same channel name is reused (e.g. React StrictMode
 * double-mount or multiple components using the hook).
 */
export function useFeedRealtime(onChange: () => void) {
  const cbRef = useRef(onChange);
  cbRef.current = onChange;

  useEffect(() => {
    if (typeof window === "undefined") return;
    const name = `feed:${Math.random().toString(36).slice(2)}`;
    let cancelled = false;
    let channel: ReturnType<typeof supabase.channel> | null = null;

    try {
      channel = supabase
        .channel(name)
        .on("postgres_changes", { event: "*", schema: "public", table: "posts" }, () => cbRef.current())
        .on("postgres_changes", { event: "*", schema: "public", table: "post_reactions" }, () => cbRef.current())
        .on("postgres_changes", { event: "*", schema: "public", table: "post_comments" }, () => cbRef.current())
        .subscribe();
    } catch (err) {
      console.warn("[useFeedRealtime] subscribe failed", err);
    }

    return () => {
      cancelled = true;
      if (channel) {
        try {
          supabase.removeChannel(channel);
        } catch {
          /* noop */
        }
      }
    };
  }, []);
}

export function useCommentsRealtime(postId: string, onChange: () => void) {
  const cbRef = useRef(onChange);
  cbRef.current = onChange;

  useEffect(() => {
    if (!postId) return;
    if (typeof window === "undefined") return;
    const name = `comments:${postId}:${Math.random().toString(36).slice(2)}`;
    let channel: ReturnType<typeof supabase.channel> | null = null;

    try {
      channel = supabase
        .channel(name)
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "post_comments", filter: `post_id=eq.${postId}` },
          () => cbRef.current(),
        )
        .subscribe();
    } catch (err) {
      console.warn("[useCommentsRealtime] subscribe failed", err);
    }

    return () => {
      if (channel) {
        try {
          supabase.removeChannel(channel);
        } catch {
          /* noop */
        }
      }
    };
  }, [postId]);
}
