import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type ProfileRole = "super_admin" | "admin" | "user";

export type AuthProfile = {
  id: string;
  display_name: string | null;
  username: string | null;
  avatar_url: string | null;
  role: ProfileRole;
  is_banned: boolean;
  is_suspended: boolean;
  suspended_until: string | null;
  ban_reason: string | null;
};

type AuthCtx = {
  session: Session | null;
  user: User | null;
  profile: AuthProfile | null;
  loading: boolean;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  isBanned: boolean;
  isSuspended: boolean;
  refreshProfile: () => Promise<void>;
  signOut: () => Promise<void>;
};

const Ctx = createContext<AuthCtx>({
  session: null,
  user: null,
  profile: null,
  loading: true,
  isAdmin: false,
  isSuperAdmin: false,
  isBanned: false,
  isSuspended: false,
  refreshProfile: async () => {},
  signOut: async () => {},
});

async function fetchProfile(userId: string): Promise<AuthProfile | null> {
  // Base profile (display + avatar)
  const profileRes: any = await (supabase.from("profiles") as any)
    .select("id, display_name, username, avatar_url")
    .eq("id", userId)
    .maybeSingle();
  const p = profileRes?.data;

  // Real role source: public.user_roles (many-to-many)
  const rolesRes: any = await (supabase.from("user_roles") as any)
    .select("role")
    .eq("user_id", userId);
  const roles: string[] = Array.isArray(rolesRes?.data)
    ? rolesRes.data.map((r: any) => r.role).filter(Boolean)
    : [];

  let role: ProfileRole = "user";
  if (roles.includes("super_admin")) role = "super_admin";
  else if (roles.includes("admin")) role = "admin";

  return {
    id: userId,
    display_name: p?.display_name ?? null,
    username: p?.username ?? null,
    avatar_url: p?.avatar_url ?? null,
    role,
    // Ban/suspension columns don't exist on profiles yet — default safely.
    is_banned: false,
    is_suspended: false,
    suspended_until: null,
    ban_reason: null,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<AuthProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshProfile = async () => {
    if (!session?.user) { setProfile(null); return; }
    setProfile(await fetchProfile(session.user.id));
  };

  useEffect(() => {
    // IMPORTANT: never `await` Supabase calls inside onAuthStateChange —
    // it deadlocks the auth event queue and breaks token refresh, sign-out,
    // and subsequent auth-scoped requests (messages, notifications, etc.).
    const { data: sub } = supabase.auth.onAuthStateChange((evt, s) => {
      setSession(s);
      setLoading(false);
      if (s?.user) {
        const uid = s.user.id;
        // Fire-and-forget: defer to microtask so we don't block the auth callback.
        setTimeout(() => {
          fetchProfile(uid).then((p) => setProfile(p)).catch(() => {});
          if (evt === "SIGNED_IN" || evt === "INITIAL_SESSION") {
            supabase.rpc("check_daily_login").then(() => {}, () => {});
            // Launch-day conversion: flip early-access OG signups into
            // real users the first time they log in on/after Aug 4, 2026.
            supabase.rpc("convert_early_access_if_ready" as never).then(() => {}, () => {});
          }
        }, 0);
      } else {
        setProfile(null);
      }
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
      if (data.session?.user) {
        const uid = data.session.user.id;
        fetchProfile(uid).then((p) => setProfile(p)).catch(() => {});
        supabase.rpc("check_daily_login").then(() => {}, () => {});
        supabase.rpc("convert_early_access_if_ready" as never).then(() => {}, () => {});
      }
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const role = profile?.role ?? "user";
  const isSuperAdmin = role === "super_admin";
  const isAdmin = role === "admin" || isSuperAdmin;
  const isBanned = !!profile?.is_banned;
  const isSuspended = !!profile?.is_suspended && !!profile?.suspended_until && new Date(profile.suspended_until) > new Date();

  return (
    <Ctx.Provider
      value={{
        session,
        user: session?.user ?? null,
        profile,
        loading,
        isAdmin,
        isSuperAdmin,
        isBanned,
        isSuspended,
        refreshProfile,
        signOut: async () => {
          try { await supabase.auth.signOut(); } catch (e) { console.warn("signOut error", e); }
          // Proactively clear local state so UI updates immediately even if
          // the auth listener is slow or the network call failed.
          setSession(null);
          setProfile(null);
          if (typeof window !== "undefined") {
            try {
              Object.keys(window.localStorage)
                .filter((k) => k.startsWith("sb-") && k.endsWith("-auth-token"))
                .forEach((k) => window.localStorage.removeItem(k));
            } catch {}
          }
        },
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export const useAuth = () => useContext(Ctx);
