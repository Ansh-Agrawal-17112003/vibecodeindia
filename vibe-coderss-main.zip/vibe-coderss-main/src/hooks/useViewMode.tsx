import { useEffect, useState } from "react";

export type ViewMode = "user" | "admin";
const KEY = "vc_view_mode";
const EVT = "vc:view-mode-change";

export function getViewMode(): ViewMode {
  if (typeof window === "undefined") return "user";
  return (localStorage.getItem(KEY) as ViewMode) || "user";
}

export function setViewMode(mode: ViewMode) {
  localStorage.setItem(KEY, mode);
  window.dispatchEvent(new CustomEvent(EVT));
}

export function useViewMode(): [ViewMode, (m: ViewMode) => void] {
  const [mode, setMode] = useState<ViewMode>("user");
  useEffect(() => {
    setMode(getViewMode());
    const h = () => setMode(getViewMode());
    window.addEventListener(EVT, h);
    window.addEventListener("storage", h);
    return () => {
      window.removeEventListener(EVT, h);
      window.removeEventListener("storage", h);
    };
  }, []);
  return [mode, setViewMode];
}
