import { useEffect, useState } from "react";

// Milliseconds until midnight IST (UTC+5:30)
function msUntilMidnightIST() {
  const now = new Date();
  // Current time in IST
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const ist = new Date(utc + 5.5 * 3600000);
  const next = new Date(ist);
  next.setHours(24, 0, 0, 0);
  return next.getTime() - ist.getTime();
}

function fmt(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = String(Math.floor(total / 3600)).padStart(2, "0");
  const m = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

export function useCountdownToMidnightIST() {
  const [label, setLabel] = useState("--:--:--");
  useEffect(() => {
    setLabel(fmt(msUntilMidnightIST()));
    const id = setInterval(() => setLabel(fmt(msUntilMidnightIST())), 1000);
    return () => clearInterval(id);
  }, []);
  return label;
}
