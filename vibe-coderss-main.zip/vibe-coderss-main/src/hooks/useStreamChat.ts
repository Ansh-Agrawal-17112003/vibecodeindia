import { useEffect, useState, useRef } from "react";
import { StreamChat, type User } from "stream-chat";
import { getStreamCredentials } from "@/lib/stream.functions";
import { useAuth } from "@/hooks/useAuth";

// One shared client per browser tab. Stream requires a singleton per user.
let sharedClient: StreamChat | null = null;
let sharedUserId: string | null = null;

export function useStreamChat() {
  const { user } = useAuth();
  const [client, setClient] = useState<StreamChat | null>(sharedClient);
  const [error, setError] = useState<string | null>(null);
  const connectingRef = useRef(false);

  useEffect(() => {
    if (!user) {
      setClient(null);
      return;
    }
    if (sharedClient && sharedUserId === user.id) {
      setClient(sharedClient);
      return;
    }
    if (connectingRef.current) return;
    connectingRef.current = true;

    let cancelled = false;

    (async () => {
      try {
        const creds = await getStreamCredentials();
        if (cancelled) return;
        // Disconnect any previous user
        if (sharedClient && sharedUserId && sharedUserId !== creds.userId) {
          await sharedClient.disconnectUser();
          sharedClient = null;
          sharedUserId = null;
        }
        const c = sharedClient ?? StreamChat.getInstance(creds.apiKey);
        if (!sharedClient) {
          const streamUser: User = {
            id: creds.userId,
            name: creds.name,
            image: creds.image,
          };
          await c.connectUser(streamUser, creds.userToken);
          sharedClient = c;
          sharedUserId = creds.userId;
        }
        if (!cancelled) setClient(c);
      } catch (e) {
        console.error("Stream Chat connect failed", e);
        if (!cancelled) setError(e instanceof Error ? e.message : "Chat unavailable");
      } finally {
        connectingRef.current = false;
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  return { client, error };
}
