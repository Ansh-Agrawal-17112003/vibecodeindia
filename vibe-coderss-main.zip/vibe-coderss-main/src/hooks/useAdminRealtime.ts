import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Subscribes to postgres changes on the tables the admin panel depends on
 * and invalidates any React Query keys prefixed with ["admin", ...] so all
 * admin views (dashboard, users, OG list, etc.) refresh in real time.
 *
 * Falls back gracefully if realtime isn't enabled for a table — the polling
 * refetchInterval on each admin useQuery still keeps data fresh.
 */
export function useAdminRealtime() {
  const qc = useQueryClient();

  useEffect(() => {
    const tables = [
      "og_members",
      "profiles",
      "user_roles",
      "communities",
      "jobs",
      "projects",
      "prompts",
      "bug_reports",
      "subscriptions",
    ];

    const invalidate = () => {
      qc.invalidateQueries({ queryKey: ["admin"] });
    };

    const channel = supabase.channel(`admin-realtime:${Math.random().toString(36).slice(2)}`);
    for (const table of tables) {
      channel.on(
        "postgres_changes",
        { event: "*", schema: "public", table } as any,
        invalidate,
      );
    }
    channel.subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);
}
