# Mega-Nav Pages — Notion-Style Build Plan

Build dedicated routes for every mega-nav item that currently deep-links to a `/landing#hash`, plus the Pricing sub-pages. Reuse `Shell`, `SectionHeader`, and the existing product-page look. All pages will share one new `NotionPageShell` layout so the visual language stays consistent.

## Design language (Notion-style)
- Cream `bg-surface` page, generous whitespace, thin `1.5px` black borders on cards
- Serif-ish display headings (existing `font-display`), muted body
- Callout blocks (emoji + tinted background), toggle FAQs, 2-col feature grids
- Simple TOC sidebar on desktop, sticky right-rail CTA
- No heavy animations — clean, editorial

Shared component: `src/components/site/NotionPageShell.tsx`
- Props: `eyebrow`, `title`, `intro`, `toc[]`, `children`, `cta`
- Renders breadcrumb, hero, sticky TOC, content column, footer CTA

Reusable primitives (same file):
- `NotionCallout`, `NotionToggle`, `NotionFeatureGrid`, `NotionQuote`, `NotionCTA`

## Routes to create

### Solutions (5)
- `/solutions/indie-builders`
- `/solutions/ai-engineers`
- `/solutions/startups-hiring`
- `/solutions/community-leaders`
- `/solutions/agencies`

### Resources (4 — blog & testimonials already exist)
- `/resources/tutorials`
- `/resources/newsletter`
- `/resources/events`
- `/resources/case-studies` (index that curates testimonials)

### Developers (5)
- `/developers/api`
- `/developers/sdks`
- `/developers/webhooks`
- `/developers/integrations`
- `/developers/changelog`

### Enterprise (4)
- `/enterprise/talent-sourcing`
- `/enterprise/community-as-a-service`
- `/enterprise/employer-branding`
- `/enterprise/custom-job-feeds`

### Learn (3 — classroom & prompts already exist)
- `/learn/bootcamp`
- `/learn/videos`
- `/learn/certifications`

### Community (1 — leaderboard/founders/testimonials/wins already exist)
- `/community/social`

### Pricing (4)
- `/pricing/individual`
- `/pricing/team`
- `/pricing/enterprise`
- `/pricing/compare`

**Total: 26 new route files + 1 shared shell component.**

## Per-page content shape
Each page ships with:
1. `head()` meta (unique title, description, og:title/description, canonical)
2. Hero (eyebrow pill, H1, sub, primary CTA)
3. 3–6 feature blocks or list sections relevant to the topic
4. Notion-style callout or pull-quote
5. FAQ toggle (2–4 Qs)
6. Footer CTA linking to `/auth` or `/pricing`

Copy will be tailored per page (indie vs enterprise vs api docs etc.), not templated boilerplate.

## Mega-nav wiring
Update `src/components/landing/megaNavConfig.ts`:
- Replace `to: "/landing", hash: "..."` entries with the new route paths above
- Keep icons/labels/descriptions unchanged
- Leave existing working links (`/jobs`, `/communities`, `/blog`, `/tools`, `/prompts`, `/leaderboard`, `/founders-wall`, `/testimonials`, `/wins`, `/pricing`) as-is
- Pricing sub-items point to the 4 new pricing sub-routes

## Out of scope
- No backend/database changes
- No changes to existing pages (blog, jobs, communities, pricing root, etc.)
- No new hero videos or generated images — use text + iconography
- No dark-mode retheming

## Execution order
1. Create `NotionPageShell` + primitives
2. Create all 26 route files in parallel (grouped by section)
3. Update `megaNavConfig.ts` links
4. Typecheck via build

Estimated changes: ~28 new files, 1 edit.
