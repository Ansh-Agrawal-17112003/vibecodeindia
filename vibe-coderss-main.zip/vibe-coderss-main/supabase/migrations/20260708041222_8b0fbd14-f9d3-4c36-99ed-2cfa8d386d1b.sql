
-- Schedule mirror drain every 30s
-- Uses pg_net to POST to the app's server route with the shared cron secret.

-- Unschedule any prior version safely
DO $$
DECLARE j record;
BEGIN
  FOR j IN SELECT jobid FROM cron.job WHERE jobname IN ('mirror-drain-30s','mirror-drain-30s-b') LOOP
    PERFORM cron.unschedule(j.jobid);
  END LOOP;
END $$;

-- Run every 30s by scheduling two jobs 30s apart (pg_cron minimum is 1min via cron syntax)
SELECT cron.schedule(
  'mirror-drain-30s',
  '* * * * *',
  $$
  SELECT net.http_post(
    url := 'https://project--f48ce3b8-96de-426c-a0e7-9141f9297d2e-dev.lovable.app/api/public/mirror-drain',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'x-mirror-secret', current_setting('app.mirror_cron_secret', true)
    ),
    body := '{}'::jsonb,
    timeout_milliseconds := 25000
  );
  $$
);

SELECT cron.schedule(
  'mirror-drain-30s-b',
  '* * * * *',
  $$
  SELECT pg_sleep(30);
  SELECT net.http_post(
    url := 'https://project--f48ce3b8-96de-426c-a0e7-9141f9297d2e-dev.lovable.app/api/public/mirror-drain',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'x-mirror-secret', current_setting('app.mirror_cron_secret', true)
    ),
    body := '{}'::jsonb,
    timeout_milliseconds := 25000
  );
  $$
);
