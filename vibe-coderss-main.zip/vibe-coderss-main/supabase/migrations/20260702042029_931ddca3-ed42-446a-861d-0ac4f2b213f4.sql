
-- 1. Extend profiles
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS total_xp integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS current_level text NOT NULL DEFAULT 'Vibe Starter',
  ADD COLUMN IF NOT EXISTS vibecoin_balance integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS login_streak integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS longest_streak integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_login_date date,
  ADD COLUMN IF NOT EXISTS streak_badges text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS boosted_until timestamptz;

-- 2. Projects: featured_until
ALTER TABLE public.projects
  ADD COLUMN IF NOT EXISTS featured_until timestamptz;

-- 3. builder_levels (public catalog)
CREATE TABLE IF NOT EXISTS public.builder_levels (
  id serial PRIMARY KEY,
  name text NOT NULL UNIQUE,
  min_xp integer NOT NULL,
  max_xp integer,
  badge_emoji text NOT NULL,
  badge_color text NOT NULL,
  sort_order integer NOT NULL
);
GRANT SELECT ON public.builder_levels TO anon, authenticated;
GRANT ALL ON public.builder_levels TO service_role;
ALTER TABLE public.builder_levels ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Levels are public" ON public.builder_levels;
CREATE POLICY "Levels are public" ON public.builder_levels FOR SELECT USING (true);

INSERT INTO public.builder_levels (name, min_xp, max_xp, badge_emoji, badge_color, sort_order) VALUES
  ('Vibe Starter', 0, 499, '🌱', '#9CA3AF', 1),
  ('Vibe Builder', 500, 1999, '⚡', '#3B82F6', 2),
  ('Vibe Maker', 2000, 4999, '🔥', '#F97316', 3),
  ('Vibe Pro', 5000, 14999, '🚀', '#8B5CF6', 4),
  ('Vibe Legend', 15000, 49999, '💎', '#EAB308', 5),
  ('Vibe Master', 50000, NULL, '👑', '#E8623A', 6)
ON CONFLICT (name) DO NOTHING;

-- 4. xp_transactions
CREATE TABLE IF NOT EXISTS public.xp_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  action_type text NOT NULL,
  xp_earned integer NOT NULL,
  reference_id uuid,
  reference_type text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS xp_tx_profile_idx ON public.xp_transactions(profile_id, created_at DESC);
GRANT SELECT, INSERT ON public.xp_transactions TO authenticated;
GRANT ALL ON public.xp_transactions TO service_role;
ALTER TABLE public.xp_transactions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users view own xp" ON public.xp_transactions;
CREATE POLICY "Users view own xp" ON public.xp_transactions FOR SELECT USING (auth.uid() = profile_id);
DROP POLICY IF EXISTS "Users insert own xp" ON public.xp_transactions;
CREATE POLICY "Users insert own xp" ON public.xp_transactions FOR INSERT WITH CHECK (auth.uid() = profile_id);

-- 5. vibecoin_transactions
CREATE TABLE IF NOT EXISTS public.vibecoin_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('earned','spent','redeemed')),
  amount integer NOT NULL,
  reason text NOT NULL,
  reference_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS vc_tx_profile_idx ON public.vibecoin_transactions(profile_id, created_at DESC);
GRANT SELECT, INSERT ON public.vibecoin_transactions TO authenticated;
GRANT ALL ON public.vibecoin_transactions TO service_role;
ALTER TABLE public.vibecoin_transactions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users view own coins" ON public.vibecoin_transactions;
CREATE POLICY "Users view own coins" ON public.vibecoin_transactions FOR SELECT USING (auth.uid() = profile_id);
DROP POLICY IF EXISTS "Users insert own coins" ON public.vibecoin_transactions;
CREATE POLICY "Users insert own coins" ON public.vibecoin_transactions FOR INSERT WITH CHECK (auth.uid() = profile_id);

-- 6. vibecoin_redemptions
CREATE TABLE IF NOT EXISTS public.vibecoin_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount_coins integer NOT NULL CHECK (amount_coins >= 500),
  amount_inr integer NOT NULL,
  upi_id text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','paid','rejected')),
  admin_note text,
  requested_at timestamptz NOT NULL DEFAULT now(),
  paid_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.vibecoin_redemptions TO authenticated;
GRANT ALL ON public.vibecoin_redemptions TO service_role;
ALTER TABLE public.vibecoin_redemptions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users view own redemptions" ON public.vibecoin_redemptions;
CREATE POLICY "Users view own redemptions" ON public.vibecoin_redemptions
  FOR SELECT USING (auth.uid() = profile_id OR public.has_role(auth.uid(), 'admin'));
DROP POLICY IF EXISTS "Users create own redemptions" ON public.vibecoin_redemptions;
CREATE POLICY "Users create own redemptions" ON public.vibecoin_redemptions
  FOR INSERT WITH CHECK (auth.uid() = profile_id);
DROP POLICY IF EXISTS "Admins update redemptions" ON public.vibecoin_redemptions;
CREATE POLICY "Admins update redemptions" ON public.vibecoin_redemptions
  FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_redemptions_updated
  BEFORE UPDATE ON public.vibecoin_redemptions
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 7. award_xp helper (SECURITY DEFINER so any signed-in user can call it for themselves)
CREATE OR REPLACE FUNCTION public.award_xp(
  _action_type text,
  _xp integer,
  _reference_id uuid DEFAULT NULL,
  _reference_type text DEFAULT NULL
) RETURNS TABLE(new_total_xp integer, new_level text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _total integer;
  _level text;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _xp <= 0 THEN RAISE EXCEPTION 'XP must be positive'; END IF;

  INSERT INTO public.xp_transactions(profile_id, action_type, xp_earned, reference_id, reference_type)
  VALUES (_uid, _action_type, _xp, _reference_id, _reference_type);

  UPDATE public.profiles
    SET total_xp = total_xp + _xp
    WHERE id = _uid
    RETURNING total_xp INTO _total;

  SELECT name INTO _level FROM public.builder_levels
    WHERE min_xp <= _total AND (max_xp IS NULL OR max_xp >= _total)
    ORDER BY sort_order DESC LIMIT 1;

  UPDATE public.profiles SET current_level = _level WHERE id = _uid;

  RETURN QUERY SELECT _total, _level;
END $$;

-- 8. award_vibecoins helper
CREATE OR REPLACE FUNCTION public.award_vibecoins(
  _type text,
  _amount integer,
  _reason text,
  _reference_id uuid DEFAULT NULL
) RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _new_balance integer;
  _signed integer;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _type NOT IN ('earned','spent','redeemed') THEN RAISE EXCEPTION 'Invalid type'; END IF;
  IF _amount <= 0 THEN RAISE EXCEPTION 'Amount must be positive'; END IF;

  _signed := CASE WHEN _type = 'earned' THEN _amount ELSE -_amount END;

  UPDATE public.profiles
    SET vibecoin_balance = vibecoin_balance + _signed
    WHERE id = _uid
    RETURNING vibecoin_balance INTO _new_balance;

  IF _new_balance < 0 THEN
    RAISE EXCEPTION 'Insufficient VibeCoin balance';
  END IF;

  INSERT INTO public.vibecoin_transactions(profile_id, type, amount, reason, reference_id)
  VALUES (_uid, _type, _amount, _reason, _reference_id);

  RETURN _new_balance;
END $$;

-- 9. check_daily_login: increment streak + award XP
CREATE OR REPLACE FUNCTION public.check_daily_login()
RETURNS TABLE(streak integer, xp_awarded integer, milestone text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _today date := (now() AT TIME ZONE 'Asia/Kolkata')::date;
  _last date;
  _streak integer;
  _longest integer;
  _badges text[];
  _milestone text := NULL;
  _bonus integer := 0;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;

  SELECT last_login_date, login_streak, longest_streak, streak_badges
    INTO _last, _streak, _longest, _badges
    FROM public.profiles WHERE id = _uid;

  IF _last = _today THEN
    RETURN QUERY SELECT _streak, 0, NULL::text; RETURN;
  ELSIF _last = _today - 1 THEN
    _streak := COALESCE(_streak, 0) + 1;
  ELSE
    _streak := 1;
  END IF;

  _longest := GREATEST(COALESCE(_longest, 0), _streak);

  IF _streak = 7 AND NOT ('Week Warrior' = ANY(_badges)) THEN
    _badges := _badges || 'Week Warrior'; _milestone := 'Week Warrior'; _bonus := 100;
  ELSIF _streak = 30 AND NOT ('Month Builder' = ANY(_badges)) THEN
    _badges := _badges || 'Month Builder'; _milestone := 'Month Builder'; _bonus := 500;
  ELSIF _streak = 100 AND NOT ('Centurion' = ANY(_badges)) THEN
    _badges := _badges || 'Centurion'; _milestone := 'Centurion'; _bonus := 1000;
  END IF;

  UPDATE public.profiles
    SET last_login_date = _today,
        login_streak = _streak,
        longest_streak = _longest,
        streak_badges = _badges,
        total_xp = total_xp + 25 + _bonus
    WHERE id = _uid;

  INSERT INTO public.xp_transactions(profile_id, action_type, xp_earned)
  VALUES (_uid, 'DAILY_LOGIN', 25);

  IF _bonus > 0 THEN
    INSERT INTO public.xp_transactions(profile_id, action_type, xp_earned)
    VALUES (_uid, 'STREAK_MILESTONE_' || _streak, _bonus);
  END IF;

  RETURN QUERY SELECT _streak, 25 + _bonus, _milestone;
END $$;

REVOKE EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.check_daily_login() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.check_daily_login() TO authenticated;
