REVOKE EXECUTE ON FUNCTION public.bump_post_reaction_counts() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.notify_on_post_reaction() FROM PUBLIC, anon, authenticated;