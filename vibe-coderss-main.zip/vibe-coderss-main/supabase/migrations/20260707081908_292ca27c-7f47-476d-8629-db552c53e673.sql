
-- Reorder BEFORE INSERT triggers so sanitize runs first, then number assignment.
DROP TRIGGER IF EXISTS trg_sanitize_og_member_insert ON public.og_members;
DROP TRIGGER IF EXISTS auto_assign_og_number ON public.og_members;

CREATE TRIGGER a_sanitize_og_member_insert
  BEFORE INSERT ON public.og_members
  FOR EACH ROW EXECUTE FUNCTION public.sanitize_og_member_insert();

CREATE TRIGGER b_assign_og_number
  BEFORE INSERT ON public.og_members
  FOR EACH ROW EXECUTE FUNCTION public.assign_og_number();

-- Raise cap in assign_og_number to allow up to 100 total OG numbers.
CREATE OR REPLACE FUNCTION public.assign_og_number()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  next_number integer;
BEGIN
  IF NEW.og_number IS NOT NULL THEN
    RETURN NEW;
  END IF;
  SELECT COALESCE(MAX(og_number), 3) + 1 INTO next_number FROM public.og_members;
  IF next_number > 100 THEN
    RAISE EXCEPTION 'OG spots are full';
  END IF;
  NEW.og_number := next_number;
  RETURN NEW;
END;
$$;

-- Backfill missing og_numbers in signup order.
WITH ranked AS (
  SELECT id, row_number() OVER (ORDER BY signed_up_at) + 3 AS new_num
  FROM public.og_members
  WHERE og_number IS NULL
)
UPDATE public.og_members m
SET og_number = ranked.new_num
FROM ranked
WHERE m.id = ranked.id;

-- Update spots view to reflect 100-spot capacity.
CREATE OR REPLACE VIEW public.og_spots_remaining AS
SELECT (100 - count(*))::integer AS remaining,
       count(*)::integer AS taken
FROM public.og_members;
