
-- Build ai_content JSONB dynamically from og_members columns for members 4-18 that lack it
UPDATE public.og_members m
SET ai_content = jsonb_build_object(
  'headline', COALESCE(NULLIF(m.wall_tagline, ''), 'OG Founding Member #' || m.og_number),
  'about_long',
    COALESCE(m.full_name, m.username, 'This builder') ||
    ' is one of the OG founding members of VibeCode (OG #' || m.og_number || ') — an early India-based AI builder from ' ||
    COALESCE(NULLIF(TRIM(BOTH ', ' FROM COALESCE(m.city, '') || ', ' || COALESCE(m.state, '')), ''), 'India') ||
    ' shipping real products in the AI-native era. Focus area: ' ||
    COALESCE(NULLIF(m.wall_tagline, ''), 'building useful AI-powered products') ||
    '. As part of the founding cohort, they helped shape VibeCode before launch and are here to build alongside India''s next generation of AI builders.',
  'what_i_do', jsonb_build_array(
    'Ship AI-native products end-to-end — from idea to live',
    'Use modern AI tools (LLMs, agents, no-code) as leverage',
    'Prototype fast, iterate with real users',
    'Share learnings openly with the VibeCode builder community'
  ),
  'expertise', jsonb_build_array(
    'AI Product Building', 'Prompt Engineering', 'Rapid Prototyping',
    'Vibe Coding', 'Automation & Workflows', 'Modern Web Stacks'
  ),
  'approach', jsonb_build_array(
    'Ship the smallest useful thing first, then iterate with real users',
    'Use AI as leverage — not as a crutch',
    'Prefer clarity over cleverness in both code and product',
    'Build in public and learn from the community'
  ),
  'why_work_with_me', jsonb_build_array(
    'OG founding member of VibeCode — deeply plugged into India''s AI builder scene',
    'Based in ' || COALESCE(m.city, 'India') || ' — understands local context and Indian market nuances',
    'Ships fast without sacrificing craft',
    'Comfortable with modern AI stacks (LLMs, agents, automations, no-code)'
  ),
  'achievements', jsonb_build_array(
    'VibeCode OG Founding Member #' || m.og_number,
    'Early adopter of AI-native building tools',
    'Active contributor to India''s builder community'
  ),
  'values', jsonb_build_array(
    'Craft over shortcuts',
    'Ship fast, learn faster',
    'Community first',
    'Honest work, honest wins'
  ),
  'faq', jsonb_build_array(
    jsonb_build_object(
      'q', 'What can I hire ' || COALESCE(split_part(m.full_name, ' ', 1), m.username, 'them') || ' for?',
      'a', 'End-to-end AI product building — from idea to shipped MVP, plus automations and no-code workflows.'
    ),
    jsonb_build_object(
      'q', 'Are you available for freelance / collabs?',
      'a', 'Yes — VibeCode launches on Aug 4. Reach out via the platform after launch for services, collabs, or founding-team opportunities.'
    ),
    jsonb_build_object(
      'q', 'Why VibeCode?',
      'a', 'Because India''s next wave of builders deserves a home — a platform built by builders, for builders, in the AI-native era.'
    )
  )
)
WHERE m.og_number BETWEEN 4 AND 18
  AND (m.ai_content IS NULL OR m.ai_content = '{}'::jsonb);

-- Sync ai_content from og_members into any existing profiles rows (by username match)
UPDATE public.profiles p
SET ai_content = o.ai_content
FROM public.og_members o
WHERE p.username IS NOT NULL
  AND p.username = o.username
  AND o.ai_content IS NOT NULL
  AND (p.ai_content IS NULL OR p.ai_content = '{}'::jsonb);
