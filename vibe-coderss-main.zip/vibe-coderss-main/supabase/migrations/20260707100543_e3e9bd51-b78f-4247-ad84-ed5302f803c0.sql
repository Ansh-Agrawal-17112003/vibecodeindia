DROP POLICY IF EXISTS og_public_insert ON public.og_members;

CREATE POLICY og_public_insert ON public.og_members
FOR INSERT TO anon, authenticated
WITH CHECK (
  email IS NOT NULL
  AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
  AND COALESCE(og_status, 'pending') = 'pending'
  AND COALESCE(free_pro_granted, false) = false
  AND free_pro_until IS NULL
  AND activated_at IS NULL
  AND (
    (auth.uid() IS NULL AND profile_id IS NULL)
    OR (auth.uid() IS NOT NULL AND (profile_id IS NULL OR profile_id = auth.uid()))
  )
);