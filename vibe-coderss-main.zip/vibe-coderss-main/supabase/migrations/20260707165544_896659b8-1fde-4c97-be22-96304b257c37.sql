
-- 1. Remove the duplicate Rishita Jaiswal (rishi18) — she already exists as OG #2
DELETE FROM public.og_members WHERE username = 'rishi18' AND og_number = 9;

-- 2. Shift everyone above the deleted slot down by 1 (10→9, 11→10, ..., 18→17)
UPDATE public.og_members SET og_number = og_number - 1 WHERE og_number > 9;

-- 3. Regenerate ai_content for the renumbered members so the text reflects new OG numbers
UPDATE public.og_members m
SET ai_content = jsonb_build_object(
  'headline', COALESCE(NULLIF(m.wall_tagline, ''), 'OG Founding Member #' || m.og_number),
  'about_long',
    COALESCE(m.full_name, m.username, 'This builder') ||
    ' is one of the OG founding members of VibeCode (OG #' || m.og_number || ') — an early India-based AI builder from ' ||
    COALESCE(NULLIF(TRIM(BOTH ', ' FROM COALESCE(m.city, '') || ', ' || COALESCE(m.state, '')), ''), 'India') ||
    ' shipping real products in the AI-native era. Focus area: ' ||
    COALESCE(NULLIF(m.wall_tagline, ''), 'building useful AI-powered products') ||
    '. As part of the founding cohort, they helped shape VibeCode before launch and are here to build alongside India''s next generation of AI builders.',
  'what_i_do', jsonb_build_array(
    'Ship AI-native products end-to-end — from idea to live',
    'Use modern AI tools (LLMs, agents, no-code) as leverage',
    'Prototype fast, iterate with real users',
    'Share learnings openly with the VibeCode builder community'
  ),
  'expertise', jsonb_build_array('AI Product Building','Prompt Engineering','Rapid Prototyping','Vibe Coding','Automation & Workflows','Modern Web Stacks'),
  'approach', jsonb_build_array(
    'Ship the smallest useful thing first, then iterate with real users',
    'Use AI as leverage — not as a crutch',
    'Prefer clarity over cleverness in both code and product',
    'Build in public and learn from the community'
  ),
  'why_work_with_me', jsonb_build_array(
    'OG founding member of VibeCode — deeply plugged into India''s AI builder scene',
    'Based in ' || COALESCE(m.city, 'India') || ' — understands local context and Indian market nuances',
    'Ships fast without sacrificing craft',
    'Comfortable with modern AI stacks (LLMs, agents, automations, no-code)'
  ),
  'achievements', jsonb_build_array(
    'VibeCode OG Founding Member #' || m.og_number,
    'Early adopter of AI-native building tools',
    'Active contributor to India''s builder community'
  ),
  'values', jsonb_build_array('Craft over shortcuts','Ship fast, learn faster','Community first','Honest work, honest wins'),
  'faq', jsonb_build_array(
    jsonb_build_object(
      'q', 'What can I hire ' || COALESCE(split_part(m.full_name, ' ', 1), m.username, 'them') || ' for?',
      'a', 'End-to-end AI product building — from idea to shipped MVP, plus automations and no-code workflows.'
    ),
    jsonb_build_object(
      'q', 'Are you available for freelance / collabs?',
      'a', 'Yes — VibeCode launches on Aug 4. Reach out via the platform after launch for services, collabs, or founding-team opportunities.'
    ),
    jsonb_build_object(
      'q', 'Why VibeCode?',
      'a', 'Because India''s next wave of builders deserves a home — a platform built by builders, for builders, in the AI-native era.'
    )
  )
)
WHERE m.og_number BETWEEN 9 AND 17;

-- 4. Push refreshed ai_content into any matching profiles rows
UPDATE public.profiles p
SET ai_content = o.ai_content
FROM public.og_members o
WHERE p.username IS NOT NULL
  AND p.username = o.username
  AND o.ai_content IS NOT NULL;
