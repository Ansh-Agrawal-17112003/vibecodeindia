-- Allow users to self-assign roles on their profile (e.g., hirer/company during onboarding).
-- Remove admin-only guard on profiles.roles column.
DROP TRIGGER IF EXISTS guard_profiles_roles_column ON public.profiles;
DROP TRIGGER IF EXISTS trg_guard_profiles_roles_column ON public.profiles;
DROP FUNCTION IF EXISTS public.guard_profiles_roles_column() CASCADE;