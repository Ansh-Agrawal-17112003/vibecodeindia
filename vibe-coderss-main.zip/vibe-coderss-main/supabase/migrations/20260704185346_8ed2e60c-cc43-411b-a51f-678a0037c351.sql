
-- Restore intentional user-callable reward RPCs (fix over-correction from prior turn)
GRANT EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) TO authenticated;

-- Secure invite-based join for private communities
CREATE OR REPLACE FUNCTION public.join_community_by_invite(_community_id uuid, _token text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _community record;
  _invite record;
  _member_id uuid;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _token IS NULL OR length(_token) = 0 THEN RAISE EXCEPTION 'Invite token required'; END IF;

  SELECT id, status, COALESCE(pricing_type,'free') AS pricing_type, COALESCE(privacy,'public') AS privacy
    INTO _community
  FROM public.communities WHERE id = _community_id;
  IF NOT FOUND OR _community.status <> 'approved' THEN
    RAISE EXCEPTION 'Community not available';
  END IF;
  IF _community.pricing_type <> 'free' THEN
    RAISE EXCEPTION 'Paid community requires payment flow';
  END IF;

  SELECT id, community_id, uses, max_uses, expires_at
    INTO _invite
  FROM public.community_invites
  WHERE token = _token AND community_id = _community_id
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Invalid invite'; END IF;
  IF _invite.expires_at IS NOT NULL AND _invite.expires_at <= now() THEN
    RAISE EXCEPTION 'Invite expired';
  END IF;
  IF _invite.max_uses IS NOT NULL AND _invite.uses >= _invite.max_uses THEN
    RAISE EXCEPTION 'Invite exhausted';
  END IF;

  INSERT INTO public.community_members(community_id, profile_id, status, role, banned)
  VALUES (_community_id, _uid, 'active', 'member', false)
  ON CONFLICT (community_id, profile_id) DO UPDATE
    SET status = 'active', banned = false
  RETURNING id INTO _member_id;

  UPDATE public.community_invites SET uses = uses + 1 WHERE id = _invite.id;

  RETURN _member_id;
END $$;

REVOKE EXECUTE ON FUNCTION public.join_community_by_invite(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.join_community_by_invite(uuid, text) TO authenticated;

-- Tighten INSERT policy: drop the "any invite exists" branch
DROP POLICY IF EXISTS "Users can join a community themselves" ON public.community_members;

CREATE POLICY "Users can join a community themselves"
  ON public.community_members
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = profile_id
    AND role = 'member'
    AND banned = false
    AND EXISTS (
      SELECT 1 FROM public.communities c
      WHERE c.id = community_members.community_id
        AND c.status = 'approved'
        AND (
          -- Free + public: instant join
          (COALESCE(c.pricing_type,'free') = 'free'
            AND COALESCE(c.privacy,'public') = 'public'
            AND community_members.status = 'active')
          -- Paid: pending_payment row until verified
          OR (COALESCE(c.pricing_type,'free') <> 'free'
            AND community_members.status = 'pending_payment')
          -- Creator can always self-add
          OR c.created_by = auth.uid()
        )
    )
  );
