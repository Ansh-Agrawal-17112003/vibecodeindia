
-- ================================================================
-- MIRROR OUTBOX: capture all writes to external Supabase
-- ================================================================

CREATE TABLE IF NOT EXISTS public.mirror_outbox (
  id bigserial PRIMARY KEY,
  table_name text NOT NULL,
  op char(1) NOT NULL CHECK (op IN ('I','U','D')),
  row_pk text NOT NULL,
  payload jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz,
  attempts int NOT NULL DEFAULT 0,
  last_error text
);

CREATE INDEX IF NOT EXISTS mirror_outbox_pending_idx
  ON public.mirror_outbox (id) WHERE sent_at IS NULL;

GRANT ALL ON public.mirror_outbox TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.mirror_outbox_id_seq TO service_role;

ALTER TABLE public.mirror_outbox ENABLE ROW LEVEL SECURITY;
-- Service-role only; no policies for anon/authenticated.

-- ================================================================
-- Trigger function: capture every change into the outbox
-- ================================================================
CREATE OR REPLACE FUNCTION public.mirror_capture()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_pk text;
  v_payload jsonb;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_payload := to_jsonb(OLD);
  ELSE
    v_payload := to_jsonb(NEW);
  END IF;

  -- Prefer 'id', fall back to composite key encoded in JSON
  v_pk := COALESCE(v_payload->>'id', v_payload::text);

  INSERT INTO public.mirror_outbox (table_name, op, row_pk, payload)
  VALUES (
    TG_TABLE_NAME,
    CASE TG_OP WHEN 'INSERT' THEN 'I' WHEN 'UPDATE' THEN 'U' ELSE 'D' END,
    v_pk,
    v_payload
  );

  RETURN COALESCE(NEW, OLD);
EXCEPTION WHEN OTHERS THEN
  -- Never break the original write because of mirror failure
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- ================================================================
-- Attach trigger to all mirrored tables
-- ================================================================
DO $$
DECLARE
  t text;
  mirrored_tables text[] := ARRAY[
    'ai_tools','bug_reports','builder_details','builder_levels',
    'communities','community_channels','community_invites','community_members',
    'community_payment_requests','companies','conversations','early_access_signups',
    'follows','founder_emails','job_applications','jobs','messages','notifications',
    'og_claim_stats','og_members','og_waitlist','platform_settings',
    'post_bookmarks','post_comments','post_likes','post_reactions','post_reports','posts',
    'profiles','projects','prompts','reviews','saved_jobs','services',
    'subscription_requests','subscriptions','templates','upvotes','user_roles',
    'vibecoin_redemptions','vibecoin_transactions','workflows','xp_transactions'
  ];
BEGIN
  FOREACH t IN ARRAY mirrored_tables LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS mirror_capture_trg ON public.%I', t);
    EXECUTE format(
      'CREATE TRIGGER mirror_capture_trg AFTER INSERT OR UPDATE OR DELETE ON public.%I
       FOR EACH ROW EXECUTE FUNCTION public.mirror_capture()', t
    );
  END LOOP;
END $$;

-- ================================================================
-- One-shot backfill: enqueue all existing rows for initial sync
-- ================================================================
CREATE OR REPLACE FUNCTION public.mirror_backfill_all()
RETURNS int
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  t text;
  n int;
  total int := 0;
  mirrored_tables text[] := ARRAY[
    'builder_levels','platform_settings','ai_tools','companies',
    'profiles','user_roles','builder_details','communities',
    'community_channels','community_members','community_invites','community_payment_requests',
    'conversations','messages','follows',
    'projects','prompts','workflows','templates','services','reviews',
    'jobs','job_applications','saved_jobs',
    'posts','post_comments','post_likes','post_bookmarks','post_reactions','post_reports',
    'notifications','upvotes',
    'xp_transactions','vibecoin_transactions','vibecoin_redemptions',
    'subscriptions','subscription_requests',
    'og_members','og_waitlist','og_claim_stats',
    'early_access_signups','founder_emails','bug_reports'
  ];
BEGIN
  FOREACH t IN ARRAY mirrored_tables LOOP
    EXECUTE format(
      'INSERT INTO public.mirror_outbox (table_name, op, row_pk, payload)
       SELECT %L, ''U'', COALESCE((to_jsonb(x)->>''id''), row_number() OVER ()::text), to_jsonb(x)
       FROM public.%I x',
      t, t
    );
    GET DIAGNOSTICS n = ROW_COUNT;
    total := total + n;
  END LOOP;
  RETURN total;
END;
$$;
