
CREATE POLICY "msg attach upload own"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'message-attachments' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "msg attach read authenticated"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'message-attachments');

CREATE POLICY "msg attach delete own"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'message-attachments' AND (storage.foldername(name))[1] = auth.uid()::text);
