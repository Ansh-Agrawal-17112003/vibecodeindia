
-- Restore Data API grants on og_members so anon can read the public wall
-- and submit signups, while keeping PII columns (email, IP, UA, referral)
-- hidden from anonymous readers. RLS still enforces row-level access.

GRANT ALL ON public.og_members TO service_role;

-- Authenticated users: full access; RLS narrows rows to own/admin.
GRANT SELECT, INSERT, UPDATE, DELETE ON public.og_members TO authenticated;

-- Anon: column-scoped SELECT for wall rendering (RLS restricts to show_on_wall=true).
GRANT SELECT (
  og_number, full_name, city, state, wall_tagline,
  primary_tool, linkedin_url, twitter_url, builder_type,
  username, signed_up_at, show_on_wall
) ON public.og_members TO anon;

-- Anon: column-scoped INSERT so the public signup form can create pending rows.
-- The sanitize_og_member_insert trigger and og_public_insert RLS policy still
-- strip and validate server-controlled fields.
GRANT INSERT (
  full_name, email, username, city, state, builder_type,
  primary_tool, other_tools, what_building, wall_tagline,
  linkedin_url, twitter_url, github_url, referral_source,
  show_on_wall, og_status, free_pro_granted, free_pro_until,
  profile_id
) ON public.og_members TO anon;

-- Existence check by email during signup ("already an OG?") needs to read
-- og_number by email for the current visitor. The og_public_insert flow
-- is anon, so allow email lookup by granting SELECT on email + og_number
-- to anon as well. RLS still limits row visibility to show_on_wall=true,
-- so this only reveals whether a walled OG exists with that email.
GRANT SELECT (email) ON public.og_members TO anon;
