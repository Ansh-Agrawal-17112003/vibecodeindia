
-- Pricing columns on communities
ALTER TABLE public.communities
  ADD COLUMN IF NOT EXISTS pricing_type text NOT NULL DEFAULT 'free',
  ADD COLUMN IF NOT EXISTS price_inr integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS trial_days integer NOT NULL DEFAULT 0;

ALTER TABLE public.communities
  DROP CONSTRAINT IF EXISTS communities_pricing_type_check;
ALTER TABLE public.communities
  ADD CONSTRAINT communities_pricing_type_check
  CHECK (pricing_type IN ('free','paid_monthly','paid_onetime'));

-- Membership status columns
ALTER TABLE public.community_members
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS paid_until timestamptz;

ALTER TABLE public.community_members
  DROP CONSTRAINT IF EXISTS community_members_status_check;
ALTER TABLE public.community_members
  ADD CONSTRAINT community_members_status_check
  CHECK (status IN ('active','pending_payment','suspended'));

-- Allow members to insert with pending_payment status too (existing insert policy already checks profile_id)
-- No change needed; policy already scoped to auth.uid() = profile_id.

-- Payment requests table
CREATE TABLE IF NOT EXISTS public.community_payment_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id uuid NOT NULL REFERENCES public.communities(id) ON DELETE CASCADE,
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount_inr integer NOT NULL,
  transaction_reference text NOT NULL,
  screenshot_url text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','verified','rejected')),
  reject_reason text,
  submitted_at timestamptz NOT NULL DEFAULT now(),
  verified_at timestamptz,
  verified_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.community_payment_requests TO authenticated;
GRANT ALL ON public.community_payment_requests TO service_role;

ALTER TABLE public.community_payment_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users read own payment requests" ON public.community_payment_requests;
CREATE POLICY "Users read own payment requests"
  ON public.community_payment_requests FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users insert own payment requests" ON public.community_payment_requests;
CREATE POLICY "Users insert own payment requests"
  ON public.community_payment_requests FOR INSERT
  TO authenticated
  WITH CHECK (profile_id = auth.uid() AND status = 'pending');

DROP POLICY IF EXISTS "Admins update payment requests" ON public.community_payment_requests;
CREATE POLICY "Admins update payment requests"
  ON public.community_payment_requests FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS trg_touch_payment_requests ON public.community_payment_requests;
CREATE TRIGGER trg_touch_payment_requests
  BEFORE UPDATE ON public.community_payment_requests
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE INDEX IF NOT EXISTS idx_payreq_status ON public.community_payment_requests(status, submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_payreq_profile ON public.community_payment_requests(profile_id);

-- Seed pricing onto the existing 12+ official communities.
UPDATE public.communities SET pricing_type = 'paid_monthly', price_inr = 299 WHERE slug = 'n8n';
UPDATE public.communities SET pricing_type = 'paid_monthly', price_inr = 499 WHERE slug = 'no-code';
UPDATE public.communities SET pricing_type = 'paid_monthly', price_inr = 199 WHERE slug = 'healthcare-ai';
UPDATE public.communities SET pricing_type = 'paid_monthly', price_inr = 399 WHERE slug = 'fintech-ai';
UPDATE public.communities SET pricing_type = 'paid_monthly', price_inr = 149 WHERE slug = 'indie-founders';
UPDATE public.communities SET pricing_type = 'paid_monthly', price_inr = 99  WHERE slug = 'cursor';
UPDATE public.communities SET pricing_type = 'paid_monthly', price_inr = 249 WHERE slug = 'make';
UPDATE public.communities SET pricing_type = 'free', price_inr = 0 WHERE slug IN ('ai-builders-india','lovable','claude','openai','student-builders','open-source-ai');
