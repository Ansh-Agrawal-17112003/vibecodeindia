
-- 1) Add reaction_counts column to posts
ALTER TABLE public.posts
  ADD COLUMN IF NOT EXISTS reaction_counts jsonb NOT NULL
  DEFAULT '{"like":0,"fire":0,"celebrate":0,"insightful":0}'::jsonb;

-- 2) Create post_reactions table
CREATE TABLE IF NOT EXISTS public.post_reactions (
  post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reaction_type text NOT NULL DEFAULT 'like',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (post_id, user_id),
  CONSTRAINT post_reactions_type_check CHECK (reaction_type IN ('like','fire','celebrate','insightful'))
);

CREATE INDEX IF NOT EXISTS post_reactions_user_idx ON public.post_reactions(user_id);
CREATE INDEX IF NOT EXISTS post_reactions_post_idx ON public.post_reactions(post_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.post_reactions TO authenticated;
GRANT SELECT ON public.post_reactions TO anon;
GRANT ALL ON public.post_reactions TO service_role;

ALTER TABLE public.post_reactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "reactions_public_read" ON public.post_reactions;
CREATE POLICY "reactions_public_read" ON public.post_reactions
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "reactions_self_insert" ON public.post_reactions;
CREATE POLICY "reactions_self_insert" ON public.post_reactions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "reactions_self_update" ON public.post_reactions;
CREATE POLICY "reactions_self_update" ON public.post_reactions
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "reactions_self_delete" ON public.post_reactions;
CREATE POLICY "reactions_self_delete" ON public.post_reactions
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- 3) Trigger to maintain reaction_counts + posts.like_count (total reactions)
CREATE OR REPLACE FUNCTION public.bump_post_reaction_counts()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _t text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    _t := NEW.reaction_type;
    UPDATE public.posts
      SET reaction_counts = jsonb_set(
            COALESCE(reaction_counts, '{"like":0,"fire":0,"celebrate":0,"insightful":0}'::jsonb),
            ARRAY[_t],
            to_jsonb(COALESCE((reaction_counts->>_t)::int, 0) + 1)
          ),
          like_count = like_count + 1
      WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    _t := OLD.reaction_type;
    UPDATE public.posts
      SET reaction_counts = jsonb_set(
            COALESCE(reaction_counts, '{"like":0,"fire":0,"celebrate":0,"insightful":0}'::jsonb),
            ARRAY[_t],
            to_jsonb(GREATEST(COALESCE((reaction_counts->>_t)::int, 0) - 1, 0))
          ),
          like_count = GREATEST(like_count - 1, 0)
      WHERE id = OLD.post_id;
  ELSIF TG_OP = 'UPDATE' AND NEW.reaction_type <> OLD.reaction_type THEN
    UPDATE public.posts
      SET reaction_counts = jsonb_set(
            jsonb_set(
              COALESCE(reaction_counts, '{"like":0,"fire":0,"celebrate":0,"insightful":0}'::jsonb),
              ARRAY[OLD.reaction_type],
              to_jsonb(GREATEST(COALESCE((reaction_counts->>OLD.reaction_type)::int, 0) - 1, 0))
            ),
            ARRAY[NEW.reaction_type],
            to_jsonb(COALESCE((reaction_counts->>NEW.reaction_type)::int, 0) + 1)
          )
      WHERE id = NEW.post_id;
  END IF;
  RETURN NULL;
END $$;

DROP TRIGGER IF EXISTS post_reactions_counts_trg ON public.post_reactions;
CREATE TRIGGER post_reactions_counts_trg
AFTER INSERT OR UPDATE OR DELETE ON public.post_reactions
FOR EACH ROW EXECUTE FUNCTION public.bump_post_reaction_counts();

-- 4) Stop the old post_likes trigger from double-counting (post_reactions is now the source of truth)
DROP TRIGGER IF EXISTS bump_post_like_count_trg ON public.post_likes;
DROP TRIGGER IF EXISTS post_likes_count_trg ON public.post_likes;
DROP TRIGGER IF EXISTS notify_on_post_like_trg ON public.post_likes;

-- 5) Backfill: copy existing post_likes into post_reactions (as 'like'), reset counts, then recompute
INSERT INTO public.post_reactions (post_id, user_id, reaction_type, created_at)
SELECT pl.post_id, pl.user_id, 'like', pl.created_at
FROM public.post_likes pl
ON CONFLICT (post_id, user_id) DO NOTHING;

-- Reset all counts to zero, then recompute from post_reactions
UPDATE public.posts
  SET reaction_counts = '{"like":0,"fire":0,"celebrate":0,"insightful":0}'::jsonb,
      like_count = 0;

WITH agg AS (
  SELECT post_id,
         COUNT(*) FILTER (WHERE reaction_type = 'like')       AS n_like,
         COUNT(*) FILTER (WHERE reaction_type = 'fire')       AS n_fire,
         COUNT(*) FILTER (WHERE reaction_type = 'celebrate')  AS n_celebrate,
         COUNT(*) FILTER (WHERE reaction_type = 'insightful') AS n_insightful,
         COUNT(*) AS n_total
  FROM public.post_reactions
  GROUP BY post_id
)
UPDATE public.posts p
   SET reaction_counts = jsonb_build_object(
         'like', a.n_like,
         'fire', a.n_fire,
         'celebrate', a.n_celebrate,
         'insightful', a.n_insightful),
       like_count = a.n_total
  FROM agg a
 WHERE p.id = a.post_id;

-- 6) Notification on reaction (like the previous notify_on_post_like trigger)
CREATE OR REPLACE FUNCTION public.notify_on_post_reaction()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE _author uuid; _actor text; _snippet text; _label text;
BEGIN
  SELECT author_id, LEFT(COALESCE(body,''),120) INTO _author, _snippet FROM public.posts WHERE id = NEW.post_id;
  _actor := public._notif_name(NEW.user_id);
  _label := CASE NEW.reaction_type
    WHEN 'fire' THEN 'reacted 🔥 to your post'
    WHEN 'celebrate' THEN 'celebrated 🎉 your post'
    WHEN 'insightful' THEN 'found your post insightful 💡'
    ELSE 'liked your post'
  END;
  PERFORM public._notif_push(_author, NEW.user_id, 'like',
    _actor || ' ' || _label, _snippet, '/vibe?p=' || NEW.post_id);
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS post_reactions_notify_trg ON public.post_reactions;
CREATE TRIGGER post_reactions_notify_trg
AFTER INSERT ON public.post_reactions
FOR EACH ROW EXECUTE FUNCTION public.notify_on_post_reaction();
