ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.communities ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS profiles_is_demo_idx ON public.profiles(is_demo);
CREATE INDEX IF NOT EXISTS communities_is_demo_idx ON public.communities(is_demo);
CREATE INDEX IF NOT EXISTS projects_is_demo_idx ON public.projects(is_demo);