
-- 1. Link og_members to profiles via matching email (auth.users)
UPDATE public.og_members om
SET profile_id = u.id
FROM auth.users u
WHERE om.profile_id IS NULL
  AND u.email IS NOT NULL
  AND lower(u.email) = lower(om.email);

-- 2. Grant OG Founder perks to all linked og_members not yet granted
DO $$
DECLARE
  r RECORD;
  _end TIMESTAMPTZ := now() + INTERVAL '1 year';
BEGIN
  FOR r IN
    SELECT om.profile_id
    FROM public.og_members om
    JOIN public.profiles p ON p.id = om.profile_id
    WHERE COALESCE(p.is_og_founder, false) = false
  LOOP
    INSERT INTO public.subscriptions (profile_id, plan, status, current_period_start, current_period_end)
    VALUES (r.profile_id, 'pro', 'active', now(), _end)
    ON CONFLICT (profile_id) DO UPDATE
      SET plan = 'pro',
          status = 'active',
          current_period_start = LEAST(public.subscriptions.current_period_start, now()),
          current_period_end = GREATEST(COALESCE(public.subscriptions.current_period_end, now()), _end),
          updated_at = now();

    UPDATE public.profiles
      SET is_og_founder = true,
          og_founder_since = now(),
          og_founder_until = _end,
          vibecoin_balance = vibecoin_balance + 500,
          updated_at = now()
      WHERE id = r.profile_id;

    INSERT INTO public.vibecoin_transactions (profile_id, type, amount, reason)
    VALUES (r.profile_id, 'earned', 500, 'OG Founder Welcome Bonus');
  END LOOP;
END $$;

-- 3. Backfill display_name / bio / location on linked profiles from og_member data
UPDATE public.profiles p
SET
  display_name = COALESCE(NULLIF(p.display_name, ''), om.full_name),
  bio = COALESCE(
    NULLIF(p.bio, ''),
    NULLIF(om.wall_tagline, ''),
    NULLIF(om.what_building, ''),
    'OG Founder on VibeCode — building in public with India''s AI builder community.'
  ),
  location = COALESCE(
    NULLIF(p.location, ''),
    CASE
      WHEN NULLIF(om.city, '') IS NOT NULL AND NULLIF(om.state, '') IS NOT NULL THEN om.city || ', ' || om.state
      ELSE COALESCE(NULLIF(om.city, ''), NULLIF(om.state, ''))
    END
  ),
  username = COALESCE(p.username, om.username),
  linkedin_url = COALESCE(p.linkedin_url, om.linkedin_url),
  x_url = COALESCE(p.x_url, om.twitter_url),
  github_url = COALESCE(p.github_url, om.github_url),
  updated_at = now()
FROM public.og_members om
WHERE om.profile_id = p.id;

-- 4. Copy pre-generated ai_content from og_member to linked profile when missing
UPDATE public.profiles p
SET ai_content = om.ai_content,
    updated_at = now()
FROM public.og_members om
WHERE om.profile_id = p.id
  AND p.ai_content IS NULL
  AND om.ai_content IS NOT NULL;
