
-- Founder email allowlist
CREATE TABLE IF NOT EXISTS public.founder_emails (
  email TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.founder_emails TO authenticated;
GRANT ALL ON public.founder_emails TO service_role;
ALTER TABLE public.founder_emails ENABLE ROW LEVEL SECURITY;
-- No policies granted intentionally: table is only read by SECURITY DEFINER trigger.

INSERT INTO public.founder_emails (email) VALUES ('jaiambeypropertydealers@gmail.com')
ON CONFLICT (email) DO NOTHING;

-- Trigger function
CREATE OR REPLACE FUNCTION public.grant_founder_super_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email_confirmed_at IS NOT NULL
     AND EXISTS (SELECT 1 FROM public.founder_emails WHERE email = lower(NEW.email)) THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'super_admin'::public.app_role)
    ON CONFLICT (user_id, role) DO NOTHING;
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin'::public.app_role)
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

-- Lock down: only auth triggers should call it
REVOKE ALL ON FUNCTION public.grant_founder_super_admin() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS on_auth_user_created_grant_founder ON auth.users;
CREATE TRIGGER on_auth_user_created_grant_founder
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.grant_founder_super_admin();

DROP TRIGGER IF EXISTS on_auth_user_confirmed_grant_founder ON auth.users;
CREATE TRIGGER on_auth_user_confirmed_grant_founder
AFTER UPDATE OF email_confirmed_at ON auth.users
FOR EACH ROW
WHEN (OLD.email_confirmed_at IS NULL AND NEW.email_confirmed_at IS NOT NULL)
EXECUTE FUNCTION public.grant_founder_super_admin();

-- Backfill for existing founder accounts
INSERT INTO public.user_roles (user_id, role)
SELECT au.id, 'super_admin'::public.app_role
FROM auth.users au
JOIN public.founder_emails fe ON fe.email = lower(au.email)
WHERE au.email_confirmed_at IS NOT NULL
ON CONFLICT (user_id, role) DO NOTHING;

INSERT INTO public.user_roles (user_id, role)
SELECT au.id, 'admin'::public.app_role
FROM auth.users au
JOIN public.founder_emails fe ON fe.email = lower(au.email)
WHERE au.email_confirmed_at IS NOT NULL
ON CONFLICT (user_id, role) DO NOTHING;
