
-- Public-read buckets: anyone can SELECT
CREATE POLICY "Public read media"
ON storage.objects FOR SELECT
USING (bucket_id IN ('avatars','banners','project-covers','portfolio-images'));

-- Authenticated users can manage their own files (path layout: <bucket>/<auth_uid>/<filename>)
CREATE POLICY "Users upload own media"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id IN ('avatars','banners','project-covers','portfolio-images','resumes')
  AND (storage.foldername(name))[1] = auth.uid()::text
);
CREATE POLICY "Users update own media"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id IN ('avatars','banners','project-covers','portfolio-images','resumes')
  AND (storage.foldername(name))[1] = auth.uid()::text
);
CREATE POLICY "Users delete own media"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id IN ('avatars','banners','project-covers','portfolio-images','resumes')
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Resumes: applicant can read their own, job poster can read applicants' resumes for their jobs
CREATE POLICY "Applicant reads own resume"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'resumes'
  AND (storage.foldername(name))[1] = auth.uid()::text
);
CREATE POLICY "Hirer reads applicant resumes"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'resumes'
  AND EXISTS (
    SELECT 1 FROM public.job_applications a
    JOIN public.jobs j ON j.id = a.job_id
    WHERE j.posted_by = auth.uid()
      AND a.resume_url = storage.objects.name
  )
);
