
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_og_founder BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS og_founder_since TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS og_founder_until TIMESTAMPTZ;

CREATE OR REPLACE FUNCTION public.claim_og_founder_access()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _email text;
  _now timestamptz := now();
  _launch timestamptz := '2026-08-04 00:00:00+05:30'::timestamptz;
  _eligible boolean := false;
  _already boolean := false;
  _period_end timestamptz;
BEGIN
  IF _uid IS NULL THEN
    RETURN jsonb_build_object('granted', false, 'reason', 'not_authenticated');
  END IF;

  SELECT lower(email) INTO _email FROM auth.users WHERE id = _uid;
  IF _email IS NULL THEN
    RETURN jsonb_build_object('granted', false, 'reason', 'no_email');
  END IF;

  SELECT EXISTS(SELECT 1 FROM public.early_access_signups WHERE lower(email) = _email) INTO _eligible;
  IF NOT _eligible THEN
    RETURN jsonb_build_object('granted', false, 'reason', 'not_eligible');
  END IF;

  IF _now < _launch THEN
    RETURN jsonb_build_object('granted', false, 'reason', 'not_yet', 'launch_at', _launch, 'eligible', true);
  END IF;

  SELECT is_og_founder INTO _already FROM public.profiles WHERE id = _uid;
  IF _already THEN
    RETURN jsonb_build_object(
      'granted', true,
      'already_claimed', true,
      'period_end', (SELECT og_founder_until FROM public.profiles WHERE id = _uid)
    );
  END IF;

  _period_end := _now + INTERVAL '1 year';

  INSERT INTO public.subscriptions (profile_id, plan, status, current_period_start, current_period_end)
  VALUES (_uid, 'pro', 'active', _now, _period_end)
  ON CONFLICT (profile_id) DO UPDATE
    SET plan = 'pro',
        status = 'active',
        current_period_start = LEAST(public.subscriptions.current_period_start, _now),
        current_period_end = GREATEST(COALESCE(public.subscriptions.current_period_end, _now), _period_end),
        updated_at = _now;

  UPDATE public.profiles
    SET is_og_founder = true,
        og_founder_since = _now,
        og_founder_until = _period_end,
        vibecoin_balance = vibecoin_balance + 500,
        updated_at = _now
    WHERE id = _uid;

  INSERT INTO public.vibecoin_transactions (profile_id, type, amount, reason)
  VALUES (_uid, 'earned', 500, 'OG Founder Welcome Bonus');

  RETURN jsonb_build_object(
    'granted', true,
    'already_claimed', false,
    'period_end', _period_end,
    'vibecoins_awarded', 500
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.claim_og_founder_access() TO authenticated;
