GRANT ALL ON public.mirror_outbox TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.mirror_outbox_id_seq TO service_role;