
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.increment_search_usage()
RETURNS integer LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE
  _uid UUID := auth.uid();
  _month TEXT := to_char(now(), 'YYYY-MM');
  _count INTEGER;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  INSERT INTO public.search_usage (profile_id, month_year, search_count)
  VALUES (_uid, _month, 1)
  ON CONFLICT (profile_id, month_year) DO UPDATE
    SET search_count = public.search_usage.search_count + 1,
        updated_at = now()
  RETURNING search_count INTO _count;
  RETURN _count;
END $$;

CREATE OR REPLACE FUNCTION public.get_or_create_conversation(_other uuid)
RETURNS uuid LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE
  _me UUID := auth.uid();
  _a UUID; _b UUID; _id UUID;
BEGIN
  IF _me IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _me = _other THEN RAISE EXCEPTION 'Cannot message self'; END IF;
  IF _me < _other THEN _a := _me; _b := _other; ELSE _a := _other; _b := _me; END IF;
  SELECT id INTO _id FROM public.conversations WHERE user_a = _a AND user_b = _b;
  IF _id IS NULL THEN
    INSERT INTO public.conversations(user_a, user_b) VALUES (_a, _b) RETURNING id INTO _id;
  END IF;
  RETURN _id;
END $$;
