
CREATE OR REPLACE FUNCTION public.sanitize_og_member_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  -- Server-controlled fields: strip whatever client sent
  NEW.og_number := NULL;              -- assign_og_number trigger sets this
  NEW.free_pro_granted := false;
  NEW.free_pro_until := NULL;
  NEW.activated_at := NULL;
  NEW.og_status := COALESCE(NEW.og_status, 'pending');
  NEW.ip_address := NULL;             -- do not accept client-supplied IPs
  NEW.user_agent := NULL;             -- do not accept client-supplied UA
  -- Only allow linking profile_id to the signed-in user (or NULL for anon signup)
  IF auth.uid() IS NOT NULL THEN
    NEW.profile_id := auth.uid();
  ELSE
    NEW.profile_id := NULL;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_sanitize_og_member_insert ON public.og_members;
CREATE TRIGGER trg_sanitize_og_member_insert
  BEFORE INSERT ON public.og_members
  FOR EACH ROW EXECUTE FUNCTION public.sanitize_og_member_insert();
