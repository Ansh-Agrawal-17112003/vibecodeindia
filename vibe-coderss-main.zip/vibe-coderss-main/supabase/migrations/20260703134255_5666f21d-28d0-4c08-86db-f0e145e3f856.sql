
CREATE OR REPLACE FUNCTION public.is_community_member(_community_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.community_members
    WHERE community_id = _community_id AND profile_id = _user_id
  );
$$;

GRANT EXECUTE ON FUNCTION public.is_community_member(uuid, uuid) TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "Anyone can view community members" ON public.community_members;

CREATE POLICY "Members can view same-community memberships"
  ON public.community_members
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = profile_id
    OR public.is_community_member(community_id, auth.uid())
    OR public.has_role(auth.uid(), 'admin'::app_role)
  );
