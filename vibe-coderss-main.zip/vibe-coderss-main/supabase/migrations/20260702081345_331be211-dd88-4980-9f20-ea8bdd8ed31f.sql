
-- Fix 1: vibecoin_redemptions -> authenticated
DROP POLICY IF EXISTS "Users view own redemptions" ON public.vibecoin_redemptions;
DROP POLICY IF EXISTS "Users create own redemptions" ON public.vibecoin_redemptions;
DROP POLICY IF EXISTS "Admins update redemptions" ON public.vibecoin_redemptions;
CREATE POLICY "Users view own redemptions" ON public.vibecoin_redemptions
  FOR SELECT TO authenticated USING (auth.uid() = profile_id);
CREATE POLICY "Users create own redemptions" ON public.vibecoin_redemptions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = profile_id);
CREATE POLICY "Admins update redemptions" ON public.vibecoin_redemptions
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

-- Fix 2: vibecoin_transactions & xp_transactions -> authenticated
DROP POLICY IF EXISTS "Users view own coins" ON public.vibecoin_transactions;
DROP POLICY IF EXISTS "Users insert own coins" ON public.vibecoin_transactions;
CREATE POLICY "Users view own coins" ON public.vibecoin_transactions
  FOR SELECT TO authenticated USING (auth.uid() = profile_id);
CREATE POLICY "Users insert own coins" ON public.vibecoin_transactions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = profile_id);

DROP POLICY IF EXISTS "Users view own xp" ON public.xp_transactions;
DROP POLICY IF EXISTS "Users insert own xp" ON public.xp_transactions;
CREATE POLICY "Users view own xp" ON public.xp_transactions
  FOR SELECT TO authenticated USING (auth.uid() = profile_id);
CREATE POLICY "Users insert own xp" ON public.xp_transactions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = profile_id);

-- Fix 3: community_invites SELECT/DELETE for creator or community creator
CREATE POLICY "Creators can view own invites"
  ON public.community_invites FOR SELECT TO authenticated
  USING (
    auth.uid() = created_by
    OR EXISTS (
      SELECT 1 FROM public.communities c
      WHERE c.id = community_invites.community_id AND c.created_by = auth.uid()
    )
  );

CREATE POLICY "Creators can delete own invites"
  ON public.community_invites FOR DELETE TO authenticated
  USING (
    auth.uid() = created_by
    OR EXISTS (
      SELECT 1 FROM public.communities c
      WHERE c.id = community_invites.community_id AND c.created_by = auth.uid()
    )
  );

-- Fix 4: early_access_signups length guards
ALTER TABLE public.early_access_signups
  ADD CONSTRAINT early_access_email_len CHECK (char_length(email) BETWEEN 5 AND 255),
  ADD CONSTRAINT early_access_source_len CHECK (source IS NULL OR char_length(source) <= 64);

-- Fix 5: SECURITY DEFINER function EXECUTE lockdown
REVOKE EXECUTE ON FUNCTION public.activate_subscription_on_verify() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.after_message_insert() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.bump_community_member_count() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.bump_follow_counts() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.bump_project_upvotes() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

REVOKE EXECUTE ON FUNCTION public.check_daily_login() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.get_community_invite(text) FROM PUBLIC, anon;

GRANT EXECUTE ON FUNCTION public.check_daily_login() TO authenticated;
GRANT EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_community_invite(text) TO authenticated;
