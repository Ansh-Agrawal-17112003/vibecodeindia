-- Revoke the broad anon read we added earlier
DROP POLICY IF EXISTS "Public can view wall-visible OG members" ON public.og_members;
REVOKE SELECT ON public.og_members FROM anon;

-- Safe, minimal public projection for the Founders Wall
CREATE OR REPLACE VIEW public.og_wall_public
WITH (security_invoker = on) AS
SELECT
  og_number,
  full_name,
  city,
  state,
  wall_tagline,
  primary_tool,
  linkedin_url,
  twitter_url
FROM public.og_members
WHERE show_on_wall = true;

GRANT SELECT ON public.og_wall_public TO anon, authenticated;

-- The view uses security_invoker, so it needs a matching SELECT policy
-- on the base table for anon — scoped to opted-in wall rows only.
CREATE POLICY "Anon can read wall-visible OG members via view"
  ON public.og_members
  FOR SELECT
  TO anon
  USING (show_on_wall = true);