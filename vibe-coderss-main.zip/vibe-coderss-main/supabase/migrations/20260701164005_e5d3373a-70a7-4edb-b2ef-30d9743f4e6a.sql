
-- Messaging enhancements: attachments + reply-to
ALTER TABLE public.messages
  ADD COLUMN IF NOT EXISTS reply_to_id UUID REFERENCES public.messages(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS attachment_url TEXT,
  ADD COLUMN IF NOT EXISTS attachment_type TEXT,
  ADD COLUMN IF NOT EXISTS attachment_name TEXT;

-- Allow empty body when there's an attachment
ALTER TABLE public.messages ALTER COLUMN body DROP NOT NULL;

-- Bug reports table
CREATE TABLE IF NOT EXISTS public.bug_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  page_url TEXT,
  user_agent TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.bug_reports TO authenticated;
GRANT INSERT ON public.bug_reports TO anon;
GRANT ALL ON public.bug_reports TO service_role;
ALTER TABLE public.bug_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can file a bug" ON public.bug_reports FOR INSERT WITH CHECK (true);
CREATE POLICY "Reporter can view own" ON public.bug_reports FOR SELECT USING (auth.uid() = reporter_id OR public.has_role(auth.uid(), 'admin'));

-- Reviews: allow reviewing any profile (already supported by schema); ensure policies exist.
-- Refresh insert policy so authenticated users can review any profile they don't own
DROP POLICY IF EXISTS "Users can create reviews" ON public.reviews;
CREATE POLICY "Users can create reviews" ON public.reviews
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = reviewer_id
    AND (reviewed_profile_id IS NULL OR reviewed_profile_id <> auth.uid())
  );

-- Prevent duplicate profile reviews from same reviewer
CREATE UNIQUE INDEX IF NOT EXISTS reviews_reviewer_profile_unique
  ON public.reviews (reviewer_id, reviewed_profile_id)
  WHERE reviewed_profile_id IS NOT NULL;
