
CREATE OR REPLACE FUNCTION public.claim_og_spot(payload jsonb)
RETURNS TABLE(og_number integer, already_claimed boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _email text := lower(trim(coalesce(payload->>'email','')));
  _username text := lower(trim(coalesce(payload->>'username','')));
  _existing integer;
  _new_number integer;
BEGIN
  IF _email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' THEN
    RAISE EXCEPTION 'Invalid email';
  END IF;

  -- Already claimed by email?
  SELECT om.og_number INTO _existing FROM public.og_members om WHERE om.email = _email LIMIT 1;
  IF _existing IS NOT NULL THEN
    RETURN QUERY SELECT _existing, true;
    RETURN;
  END IF;

  -- Already claimed by username?
  IF _username <> '' THEN
    SELECT om.og_number INTO _existing FROM public.og_members om WHERE om.username = _username LIMIT 1;
    IF _existing IS NOT NULL THEN
      RETURN QUERY SELECT _existing, true;
      RETURN;
    END IF;
  END IF;

  INSERT INTO public.og_members (
    profile_id, full_name, email, username, city, state,
    builder_type, primary_tool, other_tools, what_building,
    wall_tagline, linkedin_url, twitter_url, github_url,
    referral_source, show_on_wall, og_status
  ) VALUES (
    _uid,
    trim(coalesce(payload->>'full_name','')),
    _email,
    nullif(_username,''),
    trim(coalesce(payload->>'city','')),
    nullif(trim(coalesce(payload->>'state','')),''),
    nullif(trim(coalesce(payload->>'builder_type','')),''),
    nullif(trim(coalesce(payload->>'primary_tool','')),''),
    CASE WHEN payload ? 'other_tools'
      THEN ARRAY(SELECT jsonb_array_elements_text(payload->'other_tools'))
      ELSE ARRAY[]::text[] END,
    trim(coalesce(payload->>'what_building','')),
    trim(coalesce(payload->>'wall_tagline','')),
    nullif(trim(coalesce(payload->>'linkedin_url','')),''),
    nullif(trim(coalesce(payload->>'twitter_url','')),''),
    nullif(trim(coalesce(payload->>'github_url','')),''),
    nullif(trim(coalesce(payload->>'referral_source','')),''),
    coalesce((payload->>'show_on_wall')::boolean, true),
    'pending'
  )
  RETURNING public.og_members.og_number INTO _new_number;

  RETURN QUERY SELECT _new_number, false;
END;
$$;

GRANT EXECUTE ON FUNCTION public.claim_og_spot(jsonb) TO anon, authenticated;
