
-- Pin search_path on touch_updated_at
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

-- Lock down trigger-only function
REVOKE EXECUTE ON FUNCTION public.activate_subscription_on_verify() FROM PUBLIC, anon, authenticated;

-- Convert increment_search_usage to SECURITY INVOKER (RLS policy already allows users to manage own usage)
CREATE OR REPLACE FUNCTION public.increment_search_usage()
RETURNS INTEGER LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE
  _uid UUID := auth.uid();
  _month TEXT := to_char(now(), 'YYYY-MM');
  _count INTEGER;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  INSERT INTO public.search_usage (profile_id, month_year, search_count)
  VALUES (_uid, _month, 1)
  ON CONFLICT (profile_id, month_year) DO UPDATE
    SET search_count = public.search_usage.search_count + 1,
        updated_at = now()
  RETURNING search_count INTO _count;
  RETURN _count;
END $$;
REVOKE EXECUTE ON FUNCTION public.increment_search_usage() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.increment_search_usage() TO authenticated;
