
DROP POLICY IF EXISTS "Anyone can file a bug" ON public.bug_reports;
CREATE POLICY "Users file bug reports" ON public.bug_reports
  FOR INSERT
  WITH CHECK (
    (auth.uid() IS NULL AND reporter_id IS NULL)
    OR (auth.uid() IS NOT NULL AND reporter_id = auth.uid())
  );
