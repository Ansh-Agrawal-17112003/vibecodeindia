
-- ============================================================================
-- LinkedIn-style realtime notifications: follow, like, comment, reply,
-- repost, mention, upvote. Message notifications already exist.
-- ============================================================================

-- Helper: resolve a display name safely
CREATE OR REPLACE FUNCTION public._notif_name(_uid uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT COALESCE(display_name, username, 'Someone') FROM public.profiles WHERE id = _uid
$$;

-- Helper: insert a notification (skips if actor == recipient)
CREATE OR REPLACE FUNCTION public._notif_push(
  _user_id uuid, _actor_id uuid, _type text, _title text, _body text, _link text
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF _user_id IS NULL OR _user_id = _actor_id THEN RETURN; END IF;
  INSERT INTO public.notifications(user_id, actor_id, type, title, body, link)
  VALUES (_user_id, _actor_id, _type, _title, LEFT(COALESCE(_body,''), 240), _link);
END $$;

-- ---------------- FOLLOW ----------------
CREATE OR REPLACE FUNCTION public.notify_on_follow()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _actor text;
BEGIN
  _actor := public._notif_name(NEW.follower_id);
  PERFORM public._notif_push(
    NEW.following_id, NEW.follower_id, 'follow',
    _actor || ' started following you', NULL,
    '/u/' || COALESCE((SELECT username FROM public.profiles WHERE id=NEW.follower_id), NEW.follower_id::text)
  );
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_notify_on_follow ON public.follows;
CREATE TRIGGER trg_notify_on_follow AFTER INSERT ON public.follows
FOR EACH ROW EXECUTE FUNCTION public.notify_on_follow();

-- ---------------- POST LIKE ----------------
CREATE OR REPLACE FUNCTION public.notify_on_post_like()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _author uuid; _actor text; _snippet text;
BEGIN
  SELECT author_id, LEFT(COALESCE(body,''),120) INTO _author, _snippet FROM public.posts WHERE id = NEW.post_id;
  _actor := public._notif_name(NEW.user_id);
  PERFORM public._notif_push(_author, NEW.user_id, 'like',
    _actor || ' liked your post', _snippet, '/vibe?p=' || NEW.post_id);
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_notify_on_post_like ON public.post_likes;
CREATE TRIGGER trg_notify_on_post_like AFTER INSERT ON public.post_likes
FOR EACH ROW EXECUTE FUNCTION public.notify_on_post_like();

-- ---------------- POST COMMENT / REPLY / MENTION ----------------
CREATE OR REPLACE FUNCTION public.notify_on_post_comment()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _post_author uuid;
  _parent_author uuid;
  _actor text;
  _handles text[];
  _h text;
  _mentioned uuid;
  _notified uuid[] := ARRAY[]::uuid[];
BEGIN
  _actor := public._notif_name(NEW.author_id);
  SELECT author_id INTO _post_author FROM public.posts WHERE id = NEW.post_id;

  IF NEW.parent_comment_id IS NOT NULL THEN
    SELECT author_id INTO _parent_author FROM public.post_comments WHERE id = NEW.parent_comment_id;
    IF _parent_author IS NOT NULL AND _parent_author <> NEW.author_id THEN
      PERFORM public._notif_push(_parent_author, NEW.author_id, 'reply',
        _actor || ' replied to your comment', NEW.body, '/vibe?p=' || NEW.post_id);
      _notified := _notified || _parent_author;
    END IF;
  END IF;

  IF _post_author IS NOT NULL AND _post_author <> NEW.author_id AND NOT (_post_author = ANY(_notified)) THEN
    PERFORM public._notif_push(_post_author, NEW.author_id, 'comment',
      _actor || ' commented on your post', NEW.body, '/vibe?p=' || NEW.post_id);
    _notified := _notified || _post_author;
  END IF;

  -- @mentions
  SELECT ARRAY(SELECT DISTINCT lower(m[1]) FROM regexp_matches(COALESCE(NEW.body,''), '@([A-Za-z0-9_]{2,32})', 'g') AS m)
    INTO _handles;
  IF _handles IS NOT NULL THEN
    FOREACH _h IN ARRAY _handles LOOP
      SELECT id INTO _mentioned FROM public.profiles WHERE lower(username) = _h LIMIT 1;
      IF _mentioned IS NOT NULL AND NOT (_mentioned = ANY(_notified)) AND _mentioned <> NEW.author_id THEN
        PERFORM public._notif_push(_mentioned, NEW.author_id, 'mention',
          _actor || ' mentioned you in a comment', NEW.body, '/vibe?p=' || NEW.post_id);
        _notified := _notified || _mentioned;
      END IF;
    END LOOP;
  END IF;

  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_notify_on_post_comment ON public.post_comments;
CREATE TRIGGER trg_notify_on_post_comment AFTER INSERT ON public.post_comments
FOR EACH ROW EXECUTE FUNCTION public.notify_on_post_comment();

-- ---------------- REPOST / POST MENTION ----------------
CREATE OR REPLACE FUNCTION public.notify_on_post_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _orig_author uuid;
  _actor text;
  _handles text[];
  _h text;
  _mentioned uuid;
  _notified uuid[] := ARRAY[]::uuid[];
BEGIN
  _actor := public._notif_name(NEW.author_id);

  IF NEW.repost_of IS NOT NULL THEN
    SELECT author_id INTO _orig_author FROM public.posts WHERE id = NEW.repost_of;
    IF _orig_author IS NOT NULL AND _orig_author <> NEW.author_id THEN
      PERFORM public._notif_push(_orig_author, NEW.author_id, 'repost',
        _actor || ' reposted your post', NEW.body, '/vibe?p=' || NEW.repost_of);
      _notified := _notified || _orig_author;
    END IF;
  END IF;

  SELECT ARRAY(SELECT DISTINCT lower(m[1]) FROM regexp_matches(COALESCE(NEW.body,''), '@([A-Za-z0-9_]{2,32})', 'g') AS m)
    INTO _handles;
  IF _handles IS NOT NULL THEN
    FOREACH _h IN ARRAY _handles LOOP
      SELECT id INTO _mentioned FROM public.profiles WHERE lower(username) = _h LIMIT 1;
      IF _mentioned IS NOT NULL AND NOT (_mentioned = ANY(_notified)) AND _mentioned <> NEW.author_id THEN
        PERFORM public._notif_push(_mentioned, NEW.author_id, 'mention',
          _actor || ' mentioned you in a post', NEW.body, '/vibe?p=' || NEW.id);
        _notified := _notified || _mentioned;
      END IF;
    END LOOP;
  END IF;

  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_notify_on_post_insert ON public.posts;
CREATE TRIGGER trg_notify_on_post_insert AFTER INSERT ON public.posts
FOR EACH ROW EXECUTE FUNCTION public.notify_on_post_insert();

-- ---------------- UPVOTES (projects & other targets) ----------------
CREATE OR REPLACE FUNCTION public.notify_on_upvote()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _owner uuid; _title text; _actor text; _link text;
BEGIN
  _actor := public._notif_name(NEW.profile_id);
  IF NEW.target_type = 'project' THEN
    SELECT builder_id, title INTO _owner, _title FROM public.projects WHERE id = NEW.target_id;
    _link := '/projects/' || NEW.target_id;
  ELSIF NEW.target_type = 'prompt' THEN
    SELECT author_id, title INTO _owner, _title FROM public.prompts WHERE id = NEW.target_id;
    _link := '/prompts';
  ELSIF NEW.target_type = 'workflow' THEN
    SELECT author_id, title INTO _owner, _title FROM public.workflows WHERE id = NEW.target_id;
    _link := '/workflows';
  ELSIF NEW.target_type = 'template' THEN
    SELECT author_id, title INTO _owner, _title FROM public.templates WHERE id = NEW.target_id;
    _link := '/templates';
  ELSIF NEW.target_type = 'tool' THEN
    SELECT submitted_by, name INTO _owner, _title FROM public.ai_tools WHERE id = NEW.target_id;
    _link := '/tools';
  ELSIF NEW.target_type = 'service' THEN
    SELECT builder_id, title INTO _owner, _title FROM public.services WHERE id = NEW.target_id;
    _link := '/services';
  ELSE
    RETURN NEW;
  END IF;

  PERFORM public._notif_push(_owner, NEW.profile_id, 'upvote',
    _actor || ' upvoted your ' || NEW.target_type,
    _title, _link);
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_notify_on_upvote ON public.upvotes;
CREATE TRIGGER trg_notify_on_upvote AFTER INSERT ON public.upvotes
FOR EACH ROW EXECUTE FUNCTION public.notify_on_upvote();

-- ---------------- Ensure notifications realtime ----------------
ALTER TABLE public.notifications REPLICA IDENTITY FULL;
