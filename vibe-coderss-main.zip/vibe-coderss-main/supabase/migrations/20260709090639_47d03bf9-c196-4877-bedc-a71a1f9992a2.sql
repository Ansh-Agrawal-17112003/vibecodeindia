
-- 1) Add plan fields to companies
ALTER TABLE public.companies
  ADD COLUMN IF NOT EXISTS plan text NOT NULL DEFAULT 'free',
  ADD COLUMN IF NOT EXISTS plan_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS plan_expires_at timestamptz;

-- Only admin or the owner can change plan fields (guard)
CREATE OR REPLACE FUNCTION public.guard_companies_plan()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'UPDATE' AND (
    NEW.plan IS DISTINCT FROM OLD.plan
    OR NEW.plan_started_at IS DISTINCT FROM OLD.plan_started_at
    OR NEW.plan_expires_at IS DISTINCT FROM OLD.plan_expires_at
  ) THEN
    RAISE EXCEPTION 'Only admins can change company plan fields';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS guard_companies_plan_trg ON public.companies;
CREATE TRIGGER guard_companies_plan_trg
BEFORE UPDATE ON public.companies
FOR EACH ROW EXECUTE FUNCTION public.guard_companies_plan();


-- 2) Overview analytics (own profile only)
CREATE OR REPLACE FUNCTION public.get_profile_analytics(p_user uuid, p_days integer DEFAULT 30)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_since timestamptz := now() - (p_days || ' days')::interval;
  v_prev_since timestamptz := now() - ((p_days * 2) || ' days')::interval;
  v_result jsonb;
  v_views int;
  v_prev_views int;
  v_total_views int;
  v_followers int;
  v_following int;
  v_posts int;
  v_likes int;
  v_comments int;
  v_search_apps int;
  v_engagement_rate numeric;
  v_trend jsonb;
  v_new_followers int;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF auth.uid() <> p_user AND NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  SELECT COUNT(*) INTO v_views
    FROM public.profile_views
    WHERE viewed_profile_id = p_user AND viewed_at >= v_since;

  SELECT COUNT(*) INTO v_prev_views
    FROM public.profile_views
    WHERE viewed_profile_id = p_user
      AND viewed_at >= v_prev_since AND viewed_at < v_since;

  SELECT COALESCE(total_profile_views,0), COALESCE(follower_count,0), COALESCE(following_count,0)
    INTO v_total_views, v_followers, v_following
    FROM public.profiles WHERE id = p_user;

  SELECT COUNT(*), COALESCE(SUM(like_count),0), COALESCE(SUM(comment_count),0)
    INTO v_posts, v_likes, v_comments
    FROM public.posts
    WHERE author_id = p_user AND created_at >= v_since;

  SELECT COUNT(*) INTO v_search_apps
    FROM public.search_appearances
    WHERE profile_id = p_user AND appeared_at >= v_since;

  SELECT COUNT(*) INTO v_new_followers
    FROM public.follows
    WHERE following_id = p_user AND created_at >= v_since;

  v_engagement_rate := CASE WHEN v_views > 0
    THEN ROUND(((v_likes + v_comments)::numeric / v_views) * 100, 2)
    ELSE 0 END;

  -- Daily trend
  SELECT jsonb_agg(row_to_json(t) ORDER BY t.day)
    INTO v_trend
    FROM (
      SELECT date_trunc('day', viewed_at)::date AS day, COUNT(*)::int AS views
      FROM public.profile_views
      WHERE viewed_profile_id = p_user AND viewed_at >= v_since
      GROUP BY 1
    ) t;

  v_result := jsonb_build_object(
    'views_window', v_views,
    'views_prev_window', v_prev_views,
    'views_growth_pct', CASE WHEN v_prev_views > 0
      THEN ROUND(((v_views - v_prev_views)::numeric / v_prev_views) * 100, 1)
      ELSE NULL END,
    'total_views_all_time', v_total_views,
    'followers', v_followers,
    'following', v_following,
    'new_followers', v_new_followers,
    'posts', v_posts,
    'likes_received', v_likes,
    'comments_received', v_comments,
    'search_appearances', v_search_apps,
    'engagement_rate', v_engagement_rate,
    'daily_trend', COALESCE(v_trend, '[]'::jsonb)
  );
  RETURN v_result;
END $$;


-- 3) Viewer breakdown
CREATE OR REPLACE FUNCTION public.get_viewer_breakdown(p_user uuid, p_days integer DEFAULT 30)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_since timestamptz := now() - (p_days || ' days')::interval;
  v_by_title jsonb;
  v_by_company jsonb;
  v_by_location jsonb;
  v_top_viewers jsonb;
  v_repeat int;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF auth.uid() <> p_user AND NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_by_title
    FROM (
      SELECT COALESCE(NULLIF(p.title,''),'Builder') AS label, COUNT(*)::int AS n
      FROM public.profile_views v
      JOIN public.profiles p ON p.id = v.viewer_id
      WHERE v.viewed_profile_id = p_user AND v.viewed_at >= v_since AND v.viewer_id IS NOT NULL
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_by_company
    FROM (
      SELECT COALESCE(NULLIF(p.company,''),'Independent') AS label, COUNT(*)::int AS n
      FROM public.profile_views v
      JOIN public.profiles p ON p.id = v.viewer_id
      WHERE v.viewed_profile_id = p_user AND v.viewed_at >= v_since AND v.viewer_id IS NOT NULL
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_by_location
    FROM (
      SELECT COALESCE(NULLIF(p.location,''), NULLIF(p.city,''),'Unknown') AS label, COUNT(*)::int AS n
      FROM public.profile_views v
      JOIN public.profiles p ON p.id = v.viewer_id
      WHERE v.viewed_profile_id = p_user AND v.viewed_at >= v_since AND v.viewer_id IS NOT NULL
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_top_viewers
    FROM (
      SELECT p.id, p.display_name, p.username, p.avatar_url, p.title,
             COUNT(*)::int AS view_count,
             MAX(v.viewed_at) AS last_view
      FROM public.profile_views v
      JOIN public.profiles p ON p.id = v.viewer_id
      WHERE v.viewed_profile_id = p_user AND v.viewed_at >= v_since AND v.viewer_id IS NOT NULL
      GROUP BY p.id, p.display_name, p.username, p.avatar_url, p.title
      ORDER BY view_count DESC, last_view DESC LIMIT 20
    ) t;

  SELECT COUNT(*) INTO v_repeat FROM (
    SELECT viewer_id FROM public.profile_views
    WHERE viewed_profile_id = p_user AND viewed_at >= v_since AND viewer_id IS NOT NULL
    GROUP BY viewer_id HAVING COUNT(*) > 1
  ) r;

  RETURN jsonb_build_object(
    'by_title', COALESCE(v_by_title,'[]'::jsonb),
    'by_company', COALESCE(v_by_company,'[]'::jsonb),
    'by_location', COALESCE(v_by_location,'[]'::jsonb),
    'top_viewers', COALESCE(v_top_viewers,'[]'::jsonb),
    'repeat_viewers', v_repeat
  );
END $$;


-- 4) Content analytics
CREATE OR REPLACE FUNCTION public.get_content_analytics(p_user uuid, p_days integer DEFAULT 30)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_since timestamptz := now() - (p_days || ' days')::interval;
  v_posts jsonb;
  v_heatmap jsonb;
  v_media_vs_text jsonb;
  v_reaction_mix jsonb;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF auth.uid() <> p_user AND NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  SELECT jsonb_agg(row_to_json(t) ORDER BY t.created_at DESC)
    INTO v_posts
    FROM (
      SELECT p.id, LEFT(COALESCE(p.body,''),200) AS excerpt, p.kind,
             p.like_count, p.comment_count, p.repost_count, p.reaction_counts,
             p.created_at,
             COALESCE((SELECT total_score FROM public.post_feed_scores s WHERE s.post_id = p.id),0) AS score,
             (p.image_urls IS NOT NULL AND array_length(p.image_urls,1) > 0) AS has_media
      FROM public.posts p
      WHERE p.author_id = p_user AND p.created_at >= v_since
      LIMIT 100
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_heatmap
    FROM (
      SELECT EXTRACT(dow FROM created_at)::int AS dow,
             EXTRACT(hour FROM created_at)::int AS hour,
             COUNT(*)::int AS posts,
             COALESCE(SUM(like_count + comment_count),0)::int AS engagement
      FROM public.posts
      WHERE author_id = p_user AND created_at >= v_since
      GROUP BY 1,2
    ) t;

  SELECT jsonb_build_object(
    'media', COALESCE(SUM(CASE WHEN array_length(image_urls,1) > 0 THEN like_count + comment_count ELSE 0 END),0),
    'text',  COALESCE(SUM(CASE WHEN COALESCE(array_length(image_urls,1),0) = 0 THEN like_count + comment_count ELSE 0 END),0),
    'media_count', COALESCE(SUM(CASE WHEN array_length(image_urls,1) > 0 THEN 1 ELSE 0 END),0),
    'text_count',  COALESCE(SUM(CASE WHEN COALESCE(array_length(image_urls,1),0) = 0 THEN 1 ELSE 0 END),0)
  ) INTO v_media_vs_text
  FROM public.posts WHERE author_id = p_user AND created_at >= v_since;

  SELECT jsonb_build_object(
    'like',       COALESCE(SUM((reaction_counts->>'like')::int),0),
    'fire',       COALESCE(SUM((reaction_counts->>'fire')::int),0),
    'celebrate',  COALESCE(SUM((reaction_counts->>'celebrate')::int),0),
    'insightful', COALESCE(SUM((reaction_counts->>'insightful')::int),0)
  ) INTO v_reaction_mix
  FROM public.posts WHERE author_id = p_user AND created_at >= v_since;

  RETURN jsonb_build_object(
    'posts', COALESCE(v_posts,'[]'::jsonb),
    'best_time_heatmap', COALESCE(v_heatmap,'[]'::jsonb),
    'media_vs_text', v_media_vs_text,
    'reaction_mix', v_reaction_mix
  );
END $$;


-- 5) Hiring analytics for company owner
CREATE OR REPLACE FUNCTION public.get_hiring_analytics(p_company uuid, p_days integer DEFAULT 30)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_since timestamptz := now() - (p_days || ' days')::interval;
  v_owner uuid;
  v_result jsonb;
  v_jobs_active int; v_jobs_closed int;
  v_apps_total int;
  v_pro_apps int; v_free_apps int;
  v_by_status jsonb;
  v_by_seniority jsonb;
  v_top_skills jsonb;
  v_by_location jsonb;
  v_avg_xp numeric;
  v_avg_time_to_first interval;
  v_jobs_perf jsonb;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT owner_profile_id INTO v_owner FROM public.companies WHERE id = p_company;
  IF v_owner IS NULL THEN RAISE EXCEPTION 'Company not found'; END IF;
  IF v_owner <> auth.uid() AND NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  SELECT
    COUNT(*) FILTER (WHERE status = 'open'),
    COUNT(*) FILTER (WHERE status <> 'open')
    INTO v_jobs_active, v_jobs_closed
    FROM public.jobs WHERE posted_by = v_owner;

  SELECT COUNT(*),
         COUNT(*) FILTER (WHERE COALESCE(pr.subscription_plan,'free') IN ('pro','og_pro')),
         COUNT(*) FILTER (WHERE COALESCE(pr.subscription_plan,'free') = 'free')
    INTO v_apps_total, v_pro_apps, v_free_apps
  FROM public.job_applications a
  JOIN public.jobs j ON j.id = a.job_id
  LEFT JOIN public.profiles pr ON pr.id = a.applicant_id
  WHERE j.posted_by = v_owner AND a.applied_at >= v_since;

  SELECT jsonb_object_agg(status, n)
    INTO v_by_status
    FROM (
      SELECT a.status, COUNT(*)::int AS n
      FROM public.job_applications a
      JOIN public.jobs j ON j.id = a.job_id
      WHERE j.posted_by = v_owner AND a.applied_at >= v_since
      GROUP BY a.status
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_by_seniority
    FROM (
      SELECT COALESCE(NULLIF(pr.experience_level,''),'Unknown') AS label, COUNT(*)::int AS n
      FROM public.job_applications a
      JOIN public.jobs j ON j.id = a.job_id
      JOIN public.profiles pr ON pr.id = a.applicant_id
      WHERE j.posted_by = v_owner AND a.applied_at >= v_since
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_by_location
    FROM (
      SELECT COALESCE(NULLIF(pr.location,''), NULLIF(pr.city,''),'Unknown') AS label, COUNT(*)::int AS n
      FROM public.job_applications a
      JOIN public.jobs j ON j.id = a.job_id
      JOIN public.profiles pr ON pr.id = a.applicant_id
      WHERE j.posted_by = v_owner AND a.applied_at >= v_since
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_top_skills
    FROM (
      SELECT skill AS label, COUNT(*)::int AS n
      FROM public.job_applications a
      JOIN public.jobs j ON j.id = a.job_id
      JOIN public.profiles pr ON pr.id = a.applicant_id
      LEFT JOIN LATERAL unnest(COALESCE(pr.skills, ARRAY[]::text[])) AS skill ON TRUE
      WHERE j.posted_by = v_owner AND a.applied_at >= v_since AND skill IS NOT NULL
      GROUP BY 1 ORDER BY 2 DESC LIMIT 20
    ) t;

  SELECT AVG(pr.total_xp)::numeric
    INTO v_avg_xp
    FROM public.job_applications a
    JOIN public.jobs j ON j.id = a.job_id
    JOIN public.profiles pr ON pr.id = a.applicant_id
    WHERE j.posted_by = v_owner AND a.applied_at >= v_since;

  SELECT AVG(first_app - j.created_at)
    INTO v_avg_time_to_first
    FROM public.jobs j
    LEFT JOIN LATERAL (
      SELECT MIN(a.applied_at) AS first_app
      FROM public.job_applications a WHERE a.job_id = j.id
    ) fa ON TRUE
    WHERE j.posted_by = v_owner AND j.created_at >= v_since AND first_app IS NOT NULL;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_jobs_perf
    FROM (
      SELECT j.id, j.title, j.status, j.created_at,
        (SELECT COUNT(*)::int FROM public.job_applications a WHERE a.job_id = j.id) AS applications,
        (SELECT COUNT(*)::int FROM public.saved_jobs s WHERE s.job_id = j.id) AS saves
      FROM public.jobs j
      WHERE j.posted_by = v_owner
      ORDER BY j.created_at DESC LIMIT 20
    ) t;

  v_result := jsonb_build_object(
    'jobs_active', v_jobs_active,
    'jobs_closed', v_jobs_closed,
    'applications_total', v_apps_total,
    'applications_pro', v_pro_apps,
    'applications_free', v_free_apps,
    'by_status', COALESCE(v_by_status, '{}'::jsonb),
    'by_seniority', COALESCE(v_by_seniority,'[]'::jsonb),
    'by_location', COALESCE(v_by_location,'[]'::jsonb),
    'top_skills', COALESCE(v_top_skills,'[]'::jsonb),
    'avg_applicant_xp', COALESCE(v_avg_xp, 0),
    'avg_hours_to_first_app', COALESCE(EXTRACT(EPOCH FROM v_avg_time_to_first) / 3600.0, 0),
    'jobs', COALESCE(v_jobs_perf,'[]'::jsonb)
  );
  RETURN v_result;
END $$;


-- Grants
GRANT EXECUTE ON FUNCTION public.get_profile_analytics(uuid, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_viewer_breakdown(uuid, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_content_analytics(uuid, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_hiring_analytics(uuid, integer) TO authenticated;
