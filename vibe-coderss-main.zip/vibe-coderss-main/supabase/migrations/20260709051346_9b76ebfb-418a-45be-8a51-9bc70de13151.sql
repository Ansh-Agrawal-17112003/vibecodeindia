-- 1) Grants so anon + authenticated can actually read the wall.
GRANT SELECT ON public.og_members       TO anon, authenticated;
GRANT SELECT ON public.og_wall_public   TO anon, authenticated;
GRANT SELECT ON public.og_spots_remaining TO anon, authenticated;
GRANT SELECT ON public.og_claim_stats   TO anon, authenticated;

-- 2) Fill the lowest empty slot so "next builder number" matches the wall's visible count.
CREATE OR REPLACE FUNCTION public.claim_og_spot(payload jsonb)
 RETURNS TABLE(og_number integer, already_claimed boolean, remaining integer, taken integer, next_number integer)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  _uid uuid := auth.uid();
  _email text := lower(trim(coalesce(payload->>'email','')));
  _username text := lower(regexp_replace(trim(coalesce(payload->>'username','')), '[^a-zA-Z0-9_]', '', 'g'));
  _full_name text := nullif(trim(coalesce(payload->>'full_name','')), '');
  _city text := nullif(trim(coalesce(payload->>'city','')), '');
  _existing integer;
  _new_number integer;
  _taken integer;
  _remaining integer;
  _next_number integer;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtextextended('public.claim_og_spot', 0));

  IF _email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' THEN
    RAISE EXCEPTION 'Invalid email';
  END IF;

  IF _username <> '' AND _username !~ '^[a-zA-Z0-9_]{3,20}$' THEN
    RAISE EXCEPTION 'Invalid username';
  END IF;

  IF _full_name IS NULL OR length(_full_name) < 2 THEN
    RAISE EXCEPTION 'Invalid name';
  END IF;

  IF _city IS NULL OR length(_city) < 2 THEN
    RAISE EXCEPTION 'Invalid city';
  END IF;

  SELECT om.og_number
  INTO _existing
  FROM public.og_members om
  WHERE lower(om.email) = _email
  ORDER BY om.og_number NULLS LAST, om.signed_up_at
  LIMIT 1;

  IF _existing IS NULL AND _username <> '' THEN
    SELECT om.og_number
    INTO _existing
    FROM public.og_members om
    WHERE lower(om.username) = _username
    ORDER BY om.og_number NULLS LAST, om.signed_up_at
    LIMIT 1;
  END IF;

  IF _existing IS NOT NULL THEN
    SELECT s.remaining, s.taken, s.next_number
    INTO _remaining, _taken, _next_number
    FROM public.og_spots_remaining s
    LIMIT 1;

    RETURN QUERY SELECT _existing, true, COALESCE(_remaining, 0), COALESCE(_taken, 0), COALESCE(_next_number, LEAST(100, _existing + 1));
    RETURN;
  END IF;

  -- Fill the lowest empty slot in [4, 100] first (fills gaps left by hidden/removed OGs).
  SELECT gs.n
  INTO _new_number
  FROM generate_series(4, 100) AS gs(n)
  WHERE NOT EXISTS (
    SELECT 1 FROM public.og_members om WHERE om.og_number = gs.n
  )
  ORDER BY gs.n
  LIMIT 1;

  SELECT COUNT(*)::integer INTO _taken
  FROM public.og_members om
  WHERE om.og_number IS NOT NULL;

  IF _new_number IS NULL OR _taken >= 100 THEN
    RAISE EXCEPTION 'OG spots are full';
  END IF;

  INSERT INTO public.og_members (
    profile_id, full_name, email, username, city, state,
    builder_type, primary_tool, other_tools, what_building, wall_tagline,
    linkedin_url, twitter_url, github_url, referral_source,
    show_on_wall, og_status, og_number
  ) VALUES (
    _uid, _full_name, _email, nullif(_username,''), _city,
    nullif(trim(coalesce(payload->>'state','')),''),
    nullif(trim(coalesce(payload->>'builder_type','')),''),
    nullif(trim(coalesce(payload->>'primary_tool','')),''),
    CASE WHEN jsonb_typeof(payload->'other_tools') = 'array'
      THEN ARRAY(SELECT left(value, 80) FROM jsonb_array_elements_text(payload->'other_tools') AS value LIMIT 20)
      ELSE ARRAY[]::text[]
    END,
    nullif(trim(coalesce(payload->>'what_building','')),''),
    nullif(trim(coalesce(payload->>'wall_tagline','')),''),
    nullif(trim(coalesce(payload->>'linkedin_url','')),''),
    nullif(trim(coalesce(payload->>'twitter_url','')),''),
    nullif(trim(coalesce(payload->>'github_url','')),''),
    nullif(trim(coalesce(payload->>'referral_source','')),''),
    coalesce((payload->>'show_on_wall')::boolean, true),
    'pending',
    _new_number
  )
  RETURNING public.og_members.og_number INTO _new_number;

  SELECT s.taken, s.remaining, s.next_number
  INTO _taken, _remaining, _next_number
  FROM public.og_spots_remaining s
  LIMIT 1;

  RETURN QUERY SELECT
    _new_number,
    false,
    COALESCE(_remaining, GREATEST(0, 100 - COALESCE(_taken, 0))),
    COALESCE(_taken, 0),
    COALESCE(_next_number, LEAST(100, _new_number + 1));
EXCEPTION
  WHEN unique_violation THEN
    SELECT om.og_number
    INTO _existing
    FROM public.og_members om
    WHERE lower(om.email) = _email OR (_username <> '' AND lower(om.username) = _username)
    ORDER BY om.og_number NULLS LAST, om.signed_up_at
    LIMIT 1;

    IF _existing IS NOT NULL THEN
      SELECT s.remaining, s.taken, s.next_number
      INTO _remaining, _taken, _next_number
      FROM public.og_spots_remaining s
      LIMIT 1;

      RETURN QUERY SELECT _existing, true, COALESCE(_remaining, 0), COALESCE(_taken, 0), COALESCE(_next_number, LEAST(100, _existing + 1));
      RETURN;
    END IF;
    RAISE;
END;
$function$;