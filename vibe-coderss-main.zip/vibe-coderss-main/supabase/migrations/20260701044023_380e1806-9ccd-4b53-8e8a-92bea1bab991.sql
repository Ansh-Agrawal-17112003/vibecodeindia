DROP POLICY IF EXISTS "Anyone reads settings" ON public.platform_settings;
CREATE POLICY "Authenticated read settings" ON public.platform_settings FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.platform_settings FROM anon;