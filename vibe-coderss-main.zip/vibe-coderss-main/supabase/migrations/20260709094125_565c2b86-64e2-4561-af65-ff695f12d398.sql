
-- RPC to convert an early-access OG member into a real activated user
-- once they sign in on or after the official launch date.
CREATE OR REPLACE FUNCTION public.convert_early_access_if_ready()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_email text;
  v_launch timestamptz := '2026-08-04 00:00:00+05:30';
  v_updated int := 0;
BEGIN
  IF v_uid IS NULL THEN
    RETURN jsonb_build_object('converted', false, 'reason', 'no_session');
  END IF;
  IF now() < v_launch THEN
    RETURN jsonb_build_object('converted', false, 'reason', 'pre_launch');
  END IF;

  SELECT email INTO v_email FROM auth.users WHERE id = v_uid;
  IF v_email IS NULL THEN
    RETURN jsonb_build_object('converted', false, 'reason', 'no_email');
  END IF;

  UPDATE public.og_members
     SET og_status = 'activated',
         activated_at = COALESCE(activated_at, now()),
         profile_id = COALESCE(profile_id, v_uid)
   WHERE (profile_id = v_uid OR lower(email) = lower(v_email))
     AND og_status <> 'activated';
  GET DIAGNOSTICS v_updated = ROW_COUNT;

  RETURN jsonb_build_object('converted', v_updated > 0, 'count', v_updated);
END;
$$;

REVOKE ALL ON FUNCTION public.convert_early_access_if_ready() FROM public;
GRANT EXECUTE ON FUNCTION public.convert_early_access_if_ready() TO authenticated;
