
-- 1) Bookmarks (save posts)
CREATE TABLE IF NOT EXISTS public.post_bookmarks (
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, post_id)
);
GRANT SELECT, INSERT, DELETE ON public.post_bookmarks TO authenticated;
GRANT ALL ON public.post_bookmarks TO service_role;
ALTER TABLE public.post_bookmarks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own bookmarks read"   ON public.post_bookmarks FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own bookmarks insert" ON public.post_bookmarks FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own bookmarks delete" ON public.post_bookmarks FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- 2) Reports (spam/abuse). Anyone signed in can create; only admins can view/manage.
CREATE TABLE IF NOT EXISTS public.post_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  reporter_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reason text NOT NULL,
  details text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.post_reports TO authenticated;
GRANT ALL ON public.post_reports TO service_role;
ALTER TABLE public.post_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reporter can insert" ON public.post_reports FOR INSERT TO authenticated WITH CHECK (auth.uid() = reporter_id);
CREATE POLICY "reporter reads own"  ON public.post_reports FOR SELECT TO authenticated USING (auth.uid() = reporter_id);
CREATE POLICY "admins read all"     ON public.post_reports FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admins update"       ON public.post_reports FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role));
CREATE UNIQUE INDEX IF NOT EXISTS post_reports_unique_per_reporter ON public.post_reports(post_id, reporter_id);

-- 3) Realtime for bookmarks so save state syncs across tabs
ALTER PUBLICATION supabase_realtime ADD TABLE public.post_bookmarks;

-- 4) Posts edit tracking (safe if columns exist)
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS edited_at timestamptz;
