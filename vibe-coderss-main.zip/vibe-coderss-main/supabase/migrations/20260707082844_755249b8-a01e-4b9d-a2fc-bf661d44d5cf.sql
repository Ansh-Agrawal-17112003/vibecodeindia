ALTER VIEW public.og_spots_remaining SET (security_invoker = on);
GRANT SELECT ON public.og_spots_remaining TO anon, authenticated;