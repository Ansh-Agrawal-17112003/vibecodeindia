
CREATE OR REPLACE FUNCTION public.get_viewer_breakdown(p_user uuid, p_days integer DEFAULT 30)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_since timestamptz := now() - (p_days || ' days')::interval;
  v_by_title jsonb;
  v_by_location jsonb;
  v_top_viewers jsonb;
  v_repeat int;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF auth.uid() <> p_user AND NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_by_title
    FROM (
      SELECT COALESCE(NULLIF(bd.title,''),'Builder') AS label, COUNT(*)::int AS n
      FROM public.profile_views v
      JOIN public.profiles p ON p.id = v.viewer_id
      LEFT JOIN public.builder_details bd ON bd.profile_id = p.id
      WHERE v.viewed_profile_id = p_user AND v.viewed_at >= v_since AND v.viewer_id IS NOT NULL
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_by_location
    FROM (
      SELECT COALESCE(NULLIF(p.location,''),'Unknown') AS label, COUNT(*)::int AS n
      FROM public.profile_views v
      JOIN public.profiles p ON p.id = v.viewer_id
      WHERE v.viewed_profile_id = p_user AND v.viewed_at >= v_since AND v.viewer_id IS NOT NULL
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_top_viewers
    FROM (
      SELECT p.id, p.display_name, p.username, p.avatar_url, bd.title,
             COUNT(*)::int AS view_count,
             MAX(v.viewed_at) AS last_view
      FROM public.profile_views v
      JOIN public.profiles p ON p.id = v.viewer_id
      LEFT JOIN public.builder_details bd ON bd.profile_id = p.id
      WHERE v.viewed_profile_id = p_user AND v.viewed_at >= v_since AND v.viewer_id IS NOT NULL
      GROUP BY p.id, p.display_name, p.username, p.avatar_url, bd.title
      ORDER BY view_count DESC, last_view DESC LIMIT 20
    ) t;

  SELECT COUNT(*) INTO v_repeat FROM (
    SELECT viewer_id FROM public.profile_views
    WHERE viewed_profile_id = p_user AND viewed_at >= v_since AND viewer_id IS NOT NULL
    GROUP BY viewer_id HAVING COUNT(*) > 1
  ) r;

  RETURN jsonb_build_object(
    'by_title', COALESCE(v_by_title,'[]'::jsonb),
    'by_location', COALESCE(v_by_location,'[]'::jsonb),
    'top_viewers', COALESCE(v_top_viewers,'[]'::jsonb),
    'repeat_viewers', v_repeat
  );
END $$;

REVOKE EXECUTE ON FUNCTION public.get_viewer_breakdown(uuid, integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_viewer_breakdown(uuid, integer) TO authenticated;


CREATE OR REPLACE FUNCTION public.get_hiring_analytics(p_company uuid, p_days integer DEFAULT 30)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_since timestamptz := now() - (p_days || ' days')::interval;
  v_owner uuid;
  v_jobs_active int; v_jobs_closed int;
  v_apps_total int;
  v_pro_apps int; v_free_apps int;
  v_by_status jsonb;
  v_by_seniority jsonb;
  v_top_skills jsonb;
  v_by_location jsonb;
  v_avg_xp numeric;
  v_avg_time_to_first interval;
  v_jobs_perf jsonb;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT owner_profile_id INTO v_owner FROM public.companies WHERE id = p_company;
  IF v_owner IS NULL THEN RAISE EXCEPTION 'Company not found'; END IF;
  IF v_owner <> auth.uid() AND NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  SELECT
    COUNT(*) FILTER (WHERE status = 'open'),
    COUNT(*) FILTER (WHERE status <> 'open')
    INTO v_jobs_active, v_jobs_closed
    FROM public.jobs WHERE posted_by = v_owner;

  SELECT COUNT(*),
         COUNT(*) FILTER (WHERE COALESCE(pr.subscription_plan,'free') IN ('pro','og_pro')),
         COUNT(*) FILTER (WHERE COALESCE(pr.subscription_plan,'free') = 'free')
    INTO v_apps_total, v_pro_apps, v_free_apps
  FROM public.job_applications a
  JOIN public.jobs j ON j.id = a.job_id
  LEFT JOIN public.profiles pr ON pr.id = a.applicant_id
  WHERE j.posted_by = v_owner AND a.applied_at >= v_since;

  SELECT jsonb_object_agg(status, n)
    INTO v_by_status
    FROM (
      SELECT a.status, COUNT(*)::int AS n
      FROM public.job_applications a
      JOIN public.jobs j ON j.id = a.job_id
      WHERE j.posted_by = v_owner AND a.applied_at >= v_since
      GROUP BY a.status
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_by_seniority
    FROM (
      SELECT COALESCE(bd.experience_level::text,'Unknown') AS label, COUNT(*)::int AS n
      FROM public.job_applications a
      JOIN public.jobs j ON j.id = a.job_id
      JOIN public.profiles pr ON pr.id = a.applicant_id
      LEFT JOIN public.builder_details bd ON bd.profile_id = pr.id
      WHERE j.posted_by = v_owner AND a.applied_at >= v_since
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_by_location
    FROM (
      SELECT COALESCE(NULLIF(pr.location,''),'Unknown') AS label, COUNT(*)::int AS n
      FROM public.job_applications a
      JOIN public.jobs j ON j.id = a.job_id
      JOIN public.profiles pr ON pr.id = a.applicant_id
      WHERE j.posted_by = v_owner AND a.applied_at >= v_since
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    ) t;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_top_skills
    FROM (
      SELECT skill AS label, COUNT(*)::int AS n
      FROM public.job_applications a
      JOIN public.jobs j ON j.id = a.job_id
      JOIN public.builder_details bd ON bd.profile_id = a.applicant_id
      LEFT JOIN LATERAL unnest(COALESCE(bd.skills, ARRAY[]::text[])) AS skill ON TRUE
      WHERE j.posted_by = v_owner AND a.applied_at >= v_since AND skill IS NOT NULL
      GROUP BY 1 ORDER BY 2 DESC LIMIT 20
    ) t;

  SELECT AVG(pr.total_xp)::numeric
    INTO v_avg_xp
    FROM public.job_applications a
    JOIN public.jobs j ON j.id = a.job_id
    JOIN public.profiles pr ON pr.id = a.applicant_id
    WHERE j.posted_by = v_owner AND a.applied_at >= v_since;

  SELECT AVG(first_app - j.created_at)
    INTO v_avg_time_to_first
    FROM public.jobs j
    LEFT JOIN LATERAL (
      SELECT MIN(a.applied_at) AS first_app
      FROM public.job_applications a WHERE a.job_id = j.id
    ) fa ON TRUE
    WHERE j.posted_by = v_owner AND j.created_at >= v_since AND first_app IS NOT NULL;

  SELECT jsonb_agg(row_to_json(t))
    INTO v_jobs_perf
    FROM (
      SELECT j.id, j.title, j.status, j.created_at,
        (SELECT COUNT(*)::int FROM public.job_applications a WHERE a.job_id = j.id) AS applications,
        (SELECT COUNT(*)::int FROM public.saved_jobs s WHERE s.job_id = j.id) AS saves
      FROM public.jobs j
      WHERE j.posted_by = v_owner
      ORDER BY j.created_at DESC LIMIT 20
    ) t;

  RETURN jsonb_build_object(
    'jobs_active', v_jobs_active,
    'jobs_closed', v_jobs_closed,
    'applications_total', v_apps_total,
    'applications_pro', v_pro_apps,
    'applications_free', v_free_apps,
    'by_status', COALESCE(v_by_status, '{}'::jsonb),
    'by_seniority', COALESCE(v_by_seniority,'[]'::jsonb),
    'by_location', COALESCE(v_by_location,'[]'::jsonb),
    'top_skills', COALESCE(v_top_skills,'[]'::jsonb),
    'avg_applicant_xp', COALESCE(v_avg_xp, 0),
    'avg_hours_to_first_app', COALESCE(EXTRACT(EPOCH FROM v_avg_time_to_first) / 3600.0, 0),
    'jobs', COALESCE(v_jobs_perf,'[]'::jsonb)
  );
END $$;

REVOKE EXECUTE ON FUNCTION public.get_hiring_analytics(uuid, integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_hiring_analytics(uuid, integer) TO authenticated;
