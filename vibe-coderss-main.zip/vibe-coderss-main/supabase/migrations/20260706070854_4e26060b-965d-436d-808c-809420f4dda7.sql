-- OG Members table for early access founding members
CREATE TABLE public.og_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  full_name text NOT NULL,
  email text NOT NULL UNIQUE,
  username text UNIQUE,
  city text,
  state text,
  builder_type text,
  primary_tool text,
  other_tools text[],
  what_building text,
  linkedin_url text,
  twitter_url text,
  github_url text,
  og_number integer UNIQUE,
  og_status text NOT NULL DEFAULT 'pending',
  free_pro_granted boolean NOT NULL DEFAULT false,
  free_pro_until timestamptz,
  show_on_wall boolean NOT NULL DEFAULT true,
  wall_tagline text,
  referral_source text,
  ip_address text,
  user_agent text,
  signed_up_at timestamptz NOT NULL DEFAULT now(),
  activated_at timestamptz,
  CONSTRAINT og_number_range CHECK (og_number IS NULL OR (og_number >= 1 AND og_number <= 97))
);

GRANT SELECT, INSERT ON public.og_members TO anon;
GRANT SELECT, INSERT, UPDATE ON public.og_members TO authenticated;
GRANT ALL ON public.og_members TO service_role;

ALTER TABLE public.og_members ENABLE ROW LEVEL SECURITY;

-- Anyone can insert (public signup)
CREATE POLICY "og_public_insert" ON public.og_members
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);

-- Public read for wall entries (only exposes rows explicitly opted-in)
CREATE POLICY "og_wall_read" ON public.og_members
  FOR SELECT TO anon, authenticated
  USING (show_on_wall = true);

-- Users can read their own row
CREATE POLICY "og_own_read" ON public.og_members
  FOR SELECT TO authenticated
  USING (profile_id = auth.uid());

-- Admins can read all
CREATE POLICY "og_admin_read" ON public.og_members
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can update
CREATE POLICY "og_admin_update" ON public.og_members
  FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

-- Auto-assign OG number trigger (starts from 4, reserving 1-3 for founders)
CREATE OR REPLACE FUNCTION public.assign_og_number()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  next_number integer;
BEGIN
  IF NEW.og_number IS NOT NULL THEN
    RETURN NEW;
  END IF;
  SELECT COALESCE(MAX(og_number), 3) + 1 INTO next_number FROM public.og_members;
  IF next_number > 97 THEN
    RAISE EXCEPTION 'OG spots are full';
  END IF;
  NEW.og_number := next_number;
  RETURN NEW;
END;
$$;

CREATE TRIGGER auto_assign_og_number
  BEFORE INSERT ON public.og_members
  FOR EACH ROW
  EXECUTE FUNCTION public.assign_og_number();

-- Seed 3 founder rows (edit later via admin)
INSERT INTO public.og_members (full_name, email, og_number, og_status, free_pro_granted, show_on_wall, wall_tagline, builder_type, primary_tool)
VALUES
  ('Founder One', 'founder1@vibecode.xyz', 1, 'activated', true, true, 'Chief Vibe Architect · Built VibeCode', 'founder', 'lovable'),
  ('Founder Two', 'founder2@vibecode.xyz', 2, 'activated', true, true, 'Chief Vibe Officer · Growing the Community', 'founder', 'other'),
  ('Founder Three', 'founder3@vibecode.xyz', 3, 'activated', true, true, 'Head of Builder Growth · First 100 Members', 'founder', 'other');

-- Public view for remaining spots count
CREATE OR REPLACE VIEW public.og_spots_remaining AS
  SELECT (97 - COUNT(*))::int AS remaining, COUNT(*)::int AS taken
  FROM public.og_members;

GRANT SELECT ON public.og_spots_remaining TO anon, authenticated;

-- Waitlist table (activated when 97 OG spots are filled)
CREATE TABLE public.og_waitlist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  name text,
  joined_at timestamptz NOT NULL DEFAULT now()
);

GRANT INSERT ON public.og_waitlist TO anon, authenticated;
GRANT SELECT ON public.og_waitlist TO authenticated;
GRANT ALL ON public.og_waitlist TO service_role;

ALTER TABLE public.og_waitlist ENABLE ROW LEVEL SECURITY;

CREATE POLICY "waitlist_public_insert" ON public.og_waitlist
  FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "waitlist_admin_read" ON public.og_waitlist
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role));