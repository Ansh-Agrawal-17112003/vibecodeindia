
-- =========================================================
-- PART 1: Extend profiles
-- =========================================================
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS subscription_plan text DEFAULT 'free',
  ADD COLUMN IF NOT EXISTS subscription_status text DEFAULT 'inactive',
  ADD COLUMN IF NOT EXISTS pro_until timestamptz,
  ADD COLUMN IF NOT EXISTS is_verified boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_og_member boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS og_number integer,
  ADD COLUMN IF NOT EXISTS is_boosted boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS boost_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS boost_expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS monthly_boosts_used integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS monthly_boosts_limit integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS boost_reset_date date DEFAULT (date_trunc('month', now()))::date,
  ADD COLUMN IF NOT EXISTS total_profile_views integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS weekly_profile_views integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS search_appearances_week integer DEFAULT 0;

-- =========================================================
-- PART 2: profile_views
-- =========================================================
CREATE TABLE IF NOT EXISTS public.profile_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  viewed_profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  viewer_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  viewer_title text,
  source text DEFAULT 'direct',
  viewed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_profile_views_viewed ON public.profile_views(viewed_profile_id, viewed_at DESC);

GRANT SELECT, INSERT ON public.profile_views TO authenticated;
GRANT ALL ON public.profile_views TO service_role;
ALTER TABLE public.profile_views ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "views_own_read" ON public.profile_views;
CREATE POLICY "views_own_read" ON public.profile_views
  FOR SELECT TO authenticated
  USING (viewed_profile_id = auth.uid());

DROP POLICY IF EXISTS "views_insert_auth" ON public.profile_views;
CREATE POLICY "views_insert_auth" ON public.profile_views
  FOR INSERT TO authenticated
  WITH CHECK (viewer_id = auth.uid() OR viewer_id IS NULL);

-- =========================================================
-- PART 3: search_appearances
-- =========================================================
CREATE TABLE IF NOT EXISTS public.search_appearances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  search_query text,
  position_shown integer,
  was_clicked boolean DEFAULT false,
  appeared_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_search_app_profile ON public.search_appearances(profile_id, appeared_at DESC);

GRANT SELECT, INSERT ON public.search_appearances TO authenticated;
GRANT ALL ON public.search_appearances TO service_role;
ALTER TABLE public.search_appearances ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "search_app_own_read" ON public.search_appearances;
CREATE POLICY "search_app_own_read" ON public.search_appearances
  FOR SELECT TO authenticated
  USING (profile_id = auth.uid());

DROP POLICY IF EXISTS "search_app_insert_auth" ON public.search_appearances;
CREATE POLICY "search_app_insert_auth" ON public.search_appearances
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- =========================================================
-- PART 4: post_feed_scores
-- =========================================================
CREATE TABLE IF NOT EXISTS public.post_feed_scores (
  post_id uuid PRIMARY KEY REFERENCES public.posts(id) ON DELETE CASCADE,
  recency_score double precision DEFAULT 0,
  engagement_score double precision DEFAULT 0,
  boost_score double precision DEFAULT 0,
  total_score double precision DEFAULT 0,
  last_calculated timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_feed_scores_total ON public.post_feed_scores(total_score DESC);

GRANT SELECT ON public.post_feed_scores TO anon, authenticated;
GRANT ALL ON public.post_feed_scores TO service_role;
ALTER TABLE public.post_feed_scores ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "scores_public_read" ON public.post_feed_scores;
CREATE POLICY "scores_public_read" ON public.post_feed_scores
  FOR SELECT TO anon, authenticated
  USING (true);

-- =========================================================
-- PART 5: job_applications priority
-- =========================================================
ALTER TABLE public.job_applications
  ADD COLUMN IF NOT EXISTS application_priority integer DEFAULT 0;

CREATE OR REPLACE FUNCTION public.set_application_priority()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  SELECT CASE COALESCE(subscription_plan,'free')
    WHEN 'og_pro' THEN 3
    WHEN 'pro'    THEN 2
    ELSE 0
  END
  INTO NEW.application_priority
  FROM public.profiles WHERE id = NEW.applicant_id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS priority_on_apply ON public.job_applications;
CREATE TRIGGER priority_on_apply
  BEFORE INSERT ON public.job_applications
  FOR EACH ROW EXECUTE FUNCTION public.set_application_priority();

-- =========================================================
-- PART 6: helper functions
-- =========================================================
CREATE OR REPLACE FUNCTION public.calculate_post_score(p_post_id uuid)
RETURNS double precision
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_author uuid;
  v_created timestamptz;
  v_reaction_like int := 0;
  v_comment_count int := 0;
  v_repost_count int := 0;
  v_author_plan text;
  v_author_boosted boolean;
  v_hours_old double precision;
  v_recency double precision;
  v_engagement double precision;
  v_boost double precision;
  v_total double precision;
BEGIN
  SELECT author_id, created_at,
         COALESCE((reaction_counts->>'like')::int,0) + COALESCE((reaction_counts->>'fire')::int,0) + COALESCE((reaction_counts->>'celebrate')::int,0) + COALESCE((reaction_counts->>'insightful')::int,0),
         COALESCE(comment_count,0),
         COALESCE(repost_count,0)
    INTO v_author, v_created, v_reaction_like, v_comment_count, v_repost_count
    FROM public.posts WHERE id = p_post_id;

  IF v_author IS NULL THEN RETURN 0; END IF;

  SELECT COALESCE(subscription_plan,'free'), COALESCE(is_boosted,false)
    INTO v_author_plan, v_author_boosted
    FROM public.profiles WHERE id = v_author;

  v_hours_old := EXTRACT(EPOCH FROM (now() - v_created)) / 3600.0;
  v_recency := 100.0 * exp(-0.1 * v_hours_old);
  v_engagement := v_reaction_like + (v_comment_count * 2) + (v_repost_count * 3);
  v_boost := CASE v_author_plan
    WHEN 'og_pro' THEN 50
    WHEN 'pro' THEN 25
    ELSE 0
  END;
  IF v_author_boosted THEN v_boost := v_boost + 40; END IF;

  v_total := (v_recency * 0.40) + (v_engagement * 0.45) + (v_boost * 0.15);

  INSERT INTO public.post_feed_scores(post_id, recency_score, engagement_score, boost_score, total_score, last_calculated)
  VALUES (p_post_id, v_recency, v_engagement, v_boost, v_total, now())
  ON CONFLICT (post_id) DO UPDATE SET
    recency_score = EXCLUDED.recency_score,
    engagement_score = EXCLUDED.engagement_score,
    boost_score = EXCLUDED.boost_score,
    total_score = EXCLUDED.total_score,
    last_calculated = now();

  RETURN v_total;
END;
$$;

CREATE OR REPLACE FUNCTION public.activate_profile_boost(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_used int; v_limit int; v_reset date; v_boosted boolean; v_expires timestamptz;
BEGIN
  IF auth.uid() IS NULL OR auth.uid() <> p_user_id THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  SELECT monthly_boosts_used, monthly_boosts_limit, boost_reset_date, is_boosted, boost_expires_at
    INTO v_used, v_limit, v_reset, v_boosted, v_expires
    FROM public.profiles WHERE id = p_user_id;

  IF v_reset < (date_trunc('month', now()))::date THEN
    UPDATE public.profiles
      SET monthly_boosts_used = 0,
          boost_reset_date = (date_trunc('month', now()))::date
      WHERE id = p_user_id;
    v_used := 0;
  END IF;

  IF COALESCE(v_limit,0) <= 0 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Boost is a Pro feature');
  END IF;

  IF v_used >= v_limit THEN
    RETURN jsonb_build_object('success', false, 'error', 'Monthly boost limit reached',
      'resets_on', (date_trunc('month', now() + interval '1 month'))::text);
  END IF;

  IF v_boosted AND v_expires > now() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Boost already active',
      'expires_at', v_expires::text);
  END IF;

  UPDATE public.profiles SET
    is_boosted = true,
    boost_started_at = now(),
    boost_expires_at = now() + interval '7 days',
    monthly_boosts_used = monthly_boosts_used + 1
  WHERE id = p_user_id;

  RETURN jsonb_build_object(
    'success', true,
    'expires_at', (now() + interval '7 days')::text,
    'boosts_remaining', v_limit - v_used - 1
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.expire_boosts()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.profiles SET
    is_boosted = false,
    boost_started_at = NULL,
    boost_expires_at = NULL
  WHERE is_boosted = true AND boost_expires_at < now();
END;
$$;

CREATE OR REPLACE FUNCTION public.increment_profile_views(p_profile_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.profiles
    SET total_profile_views = COALESCE(total_profile_views,0) + 1,
        weekly_profile_views = COALESCE(weekly_profile_views,0) + 1
    WHERE id = p_profile_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.activate_og_pro_benefits(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_new_balance int;
BEGIN
  UPDATE public.profiles SET
    subscription_plan = 'og_pro',
    subscription_status = 'active',
    pro_until = '2027-08-04 00:00:00+00',
    is_verified = true,
    is_og_member = true,
    monthly_boosts_limit = GREATEST(COALESCE(monthly_boosts_limit,0), 2),
    vibecoin_balance = COALESCE(vibecoin_balance,0) + 500
  WHERE id = p_user_id
  RETURNING vibecoin_balance INTO v_new_balance;

  IF v_new_balance IS NOT NULL THEN
    INSERT INTO public.vibecoin_transactions(profile_id, type, amount, reason)
    VALUES (p_user_id, 'earned', 500, 'og_founding_member_bonus');
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_ranked_builders(
  p_tools text[] DEFAULT NULL,
  p_location text DEFAULT NULL,
  p_availability text DEFAULT NULL
)
RETURNS SETOF public.profiles
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT p.*
  FROM public.profiles p
  WHERE (p_location IS NULL OR p.city ILIKE '%' || p_location || '%' OR p.state ILIKE '%' || p_location || '%')
  ORDER BY
    CASE COALESCE(p.subscription_plan,'free')
      WHEN 'og_pro' THEN 4
      WHEN 'pro'    THEN 3
      ELSE 0
    END DESC,
    COALESCE(p.is_boosted,false) DESC,
    COALESCE(p.total_xp,0) DESC;
END;
$$;

-- =========================================================
-- PART 7: Backfill from existing OG + subscriptions data
-- =========================================================
UPDATE public.profiles p SET
  subscription_plan = 'og_pro',
  subscription_status = 'active',
  is_verified = true,
  is_og_member = true,
  pro_until = COALESCE(p.og_founder_until, '2027-08-04 00:00:00+00'),
  monthly_boosts_limit = GREATEST(COALESCE(monthly_boosts_limit,0), 2)
WHERE p.is_og_founder = true;

-- Sync og_number from og_members table where available
UPDATE public.profiles p SET og_number = om.og_number
FROM public.og_members om
WHERE om.profile_id = p.id AND om.og_number IS NOT NULL AND p.og_number IS NULL;

-- Mark existing pro subscribers (non-OG) as 'pro'
UPDATE public.profiles p SET
  subscription_plan = 'pro',
  subscription_status = s.status,
  pro_until = s.current_period_end,
  monthly_boosts_limit = GREATEST(COALESCE(monthly_boosts_limit,0), 1)
FROM public.subscriptions s
WHERE s.profile_id = p.id
  AND s.plan = 'pro'
  AND s.status = 'active'
  AND COALESCE(p.is_og_member, false) = false;
