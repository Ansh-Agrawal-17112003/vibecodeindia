CREATE TABLE public.og_claim_stats (
  id boolean PRIMARY KEY DEFAULT true,
  taken integer NOT NULL DEFAULT 0,
  remaining integer NOT NULL DEFAULT 100,
  next_number integer NOT NULL DEFAULT 1,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT og_claim_stats_singleton CHECK (id = true)
);

GRANT SELECT ON public.og_claim_stats TO anon, authenticated;
GRANT ALL ON public.og_claim_stats TO service_role;

ALTER TABLE public.og_claim_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read OG claim stats"
  ON public.og_claim_stats
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE OR REPLACE FUNCTION public.refresh_og_claim_stats_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  claimed_count integer;
  next_claim_number integer;
BEGIN
  SELECT COUNT(og_number)::int, COALESCE(MAX(og_number), 0)::int + 1
  INTO claimed_count, next_claim_number
  FROM public.og_members
  WHERE og_number IS NOT NULL;

  IF next_claim_number < 4 THEN
    next_claim_number := 4;
  END IF;

  INSERT INTO public.og_claim_stats (id, taken, remaining, next_number, updated_at)
  VALUES (
    true,
    claimed_count,
    GREATEST(0, 100 - claimed_count),
    LEAST(100, next_claim_number),
    now()
  )
  ON CONFLICT (id) DO UPDATE
  SET
    taken = EXCLUDED.taken,
    remaining = EXCLUDED.remaining,
    next_number = EXCLUDED.next_number,
    updated_at = EXCLUDED.updated_at;

  RETURN NULL;
END;
$$;

REVOKE ALL ON FUNCTION public.refresh_og_claim_stats_trigger() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS refresh_og_claim_stats_on_members ON public.og_members;
CREATE TRIGGER refresh_og_claim_stats_on_members
  AFTER INSERT OR UPDATE OR DELETE ON public.og_members
  FOR EACH STATEMENT
  EXECUTE FUNCTION public.refresh_og_claim_stats_trigger();

WITH stats AS (
  SELECT
    COUNT(og_number)::int AS claimed_count,
    GREATEST(4, COALESCE(MAX(og_number), 0)::int + 1) AS next_claim_number
  FROM public.og_members
  WHERE og_number IS NOT NULL
)
INSERT INTO public.og_claim_stats (id, taken, remaining, next_number, updated_at)
SELECT
  true,
  claimed_count,
  GREATEST(0, 100 - claimed_count),
  LEAST(100, next_claim_number),
  now()
FROM stats
ON CONFLICT (id) DO UPDATE
SET
  taken = EXCLUDED.taken,
  remaining = EXCLUDED.remaining,
  next_number = EXCLUDED.next_number,
  updated_at = EXCLUDED.updated_at;

CREATE OR REPLACE VIEW public.og_spots_remaining
WITH (security_invoker = on)
AS
SELECT remaining, taken, next_number
FROM public.og_claim_stats
WHERE id = true;

GRANT SELECT ON public.og_spots_remaining TO anon, authenticated;