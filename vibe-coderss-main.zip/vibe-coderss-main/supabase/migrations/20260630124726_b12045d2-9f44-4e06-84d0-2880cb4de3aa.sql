
-- 1. Remove self-insert on notifications (server/triggers use SECURITY DEFINER)
DROP POLICY IF EXISTS "self insert notifs" ON public.notifications;

-- 2. Remove self-insert on user_roles (privilege escalation)
DROP POLICY IF EXISTS "Users add own roles" ON public.user_roles;

-- 3. Storage DELETE policies for payment-screenshots (owner or admin)
CREATE POLICY "Users delete own payment screenshots"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'payment-screenshots'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Admins delete payment screenshots"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'payment-screenshots'
  AND public.has_role(auth.uid(), 'admin')
);

-- 4. Revoke EXECUTE on trigger-only SECURITY DEFINER functions from client roles
REVOKE EXECUTE ON FUNCTION public.bump_follow_counts() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.bump_project_upvotes() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.activate_subscription_on_verify() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.after_message_insert() FROM PUBLIC, anon, authenticated;
