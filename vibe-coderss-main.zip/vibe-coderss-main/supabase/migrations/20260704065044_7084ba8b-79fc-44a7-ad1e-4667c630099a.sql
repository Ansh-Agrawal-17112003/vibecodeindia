
-- 1) Trigger-only SECURITY DEFINER functions: revoke EXECUTE from
--    authenticated (and PUBLIC) as well. Triggers do not require caller
--    EXECUTE privileges to run.
REVOKE EXECUTE ON FUNCTION public.bump_post_like_count() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.bump_post_comment_count() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.bump_repost_count() FROM PUBLIC, anon, authenticated;

-- 2) Companies: hide owner_profile_id from anonymous readers.
--    Authenticated users (including the owner via "Owner writes company")
--    can still read it.
REVOKE SELECT (owner_profile_id) ON public.companies FROM anon;
