
-- 1. Payment OTPs: split policies to prevent self-approval via UPDATE
DROP POLICY IF EXISTS "own otps" ON public.payment_otps;

CREATE POLICY "payment_otps_select_own"
  ON public.payment_otps FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "payment_otps_insert_own"
  ON public.payment_otps FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "payment_otps_delete_own"
  ON public.payment_otps FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Admins may update (verification handled via SECURITY DEFINER / admin flows)
CREATE POLICY "payment_otps_admin_update"
  ON public.payment_otps FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

-- 2. Revoke anon EXECUTE on trigger-only SECURITY DEFINER function
REVOKE EXECUTE ON FUNCTION public.sync_profile_roles_from_user_roles() FROM PUBLIC, anon;
