
-- Extend posts.kind allowed values to include new entity types
ALTER TABLE public.posts DROP CONSTRAINT IF EXISTS posts_kind_check;
ALTER TABLE public.posts ADD CONSTRAINT posts_kind_check
  CHECK (kind = ANY (ARRAY['text','image','project','repost','job','service','community','prompt','workflow','tool','template']));

-- ============================================================
-- 1) PROMPTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.prompts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  model text,
  category text,
  body text NOT NULL,
  preview text,
  upvote_count integer NOT NULL DEFAULT 0,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.prompts TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.prompts TO authenticated;
GRANT ALL ON public.prompts TO service_role;
ALTER TABLE public.prompts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "prompts_public_read" ON public.prompts FOR SELECT USING (true);
CREATE POLICY "prompts_owner_insert" ON public.prompts FOR INSERT TO authenticated WITH CHECK (auth.uid() = author_id);
CREATE POLICY "prompts_owner_update" ON public.prompts FOR UPDATE TO authenticated USING (auth.uid() = author_id);
CREATE POLICY "prompts_owner_delete" ON public.prompts FOR DELETE TO authenticated USING (auth.uid() = author_id);
CREATE TRIGGER trg_prompts_touch BEFORE UPDATE ON public.prompts FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ============================================================
-- 2) WORKFLOWS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.workflows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  category text,
  description text NOT NULL,
  tools text[] NOT NULL DEFAULT '{}',
  cover_image_url text,
  upvote_count integer NOT NULL DEFAULT 0,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.workflows TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.workflows TO authenticated;
GRANT ALL ON public.workflows TO service_role;
ALTER TABLE public.workflows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "workflows_public_read" ON public.workflows FOR SELECT USING (true);
CREATE POLICY "workflows_owner_insert" ON public.workflows FOR INSERT TO authenticated WITH CHECK (auth.uid() = author_id);
CREATE POLICY "workflows_owner_update" ON public.workflows FOR UPDATE TO authenticated USING (auth.uid() = author_id);
CREATE POLICY "workflows_owner_delete" ON public.workflows FOR DELETE TO authenticated USING (auth.uid() = author_id);
CREATE TRIGGER trg_workflows_touch BEFORE UPDATE ON public.workflows FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ============================================================
-- 3) AI TOOLS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.ai_tools (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submitted_by uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  tagline text NOT NULL,
  url text NOT NULL,
  category text,
  pricing text,
  description text,
  logo_url text,
  upvote_count integer NOT NULL DEFAULT 0,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ai_tools TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ai_tools TO authenticated;
GRANT ALL ON public.ai_tools TO service_role;
ALTER TABLE public.ai_tools ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ai_tools_public_read" ON public.ai_tools FOR SELECT USING (true);
CREATE POLICY "ai_tools_owner_insert" ON public.ai_tools FOR INSERT TO authenticated WITH CHECK (auth.uid() = submitted_by);
CREATE POLICY "ai_tools_owner_update" ON public.ai_tools FOR UPDATE TO authenticated USING (auth.uid() = submitted_by);
CREATE POLICY "ai_tools_owner_delete" ON public.ai_tools FOR DELETE TO authenticated USING (auth.uid() = submitted_by);
CREATE TRIGGER trg_ai_tools_touch BEFORE UPDATE ON public.ai_tools FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ============================================================
-- 4) TEMPLATES
-- ============================================================
CREATE TABLE IF NOT EXISTS public.templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  description text,
  framework text,
  category text,
  stack text[] NOT NULL DEFAULT '{}',
  price_label text DEFAULT 'Free',
  cover_image_url text,
  downloads integer NOT NULL DEFAULT 0,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.templates TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.templates TO authenticated;
GRANT ALL ON public.templates TO service_role;
ALTER TABLE public.templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "templates_public_read" ON public.templates FOR SELECT USING (true);
CREATE POLICY "templates_owner_insert" ON public.templates FOR INSERT TO authenticated WITH CHECK (auth.uid() = author_id);
CREATE POLICY "templates_owner_update" ON public.templates FOR UPDATE TO authenticated USING (auth.uid() = author_id);
CREATE POLICY "templates_owner_delete" ON public.templates FOR DELETE TO authenticated USING (auth.uid() = author_id);
CREATE TRIGGER trg_templates_touch BEFORE UPDATE ON public.templates FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ============================================================
-- Extend auto-post trigger to cover new entity types
-- ============================================================
CREATE OR REPLACE FUNCTION public.auto_post_entity_to_feed()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _author uuid;
  _kind text;
  _body text;
  _project uuid := NULL;
  _is_demo boolean := false;
BEGIN
  IF TG_TABLE_NAME = 'projects' THEN
    _author := NEW.builder_id; _kind := 'project';
    _body := 'Shipped a new project: ' || NEW.title;
    _project := NEW.id;
    _is_demo := COALESCE(NEW.is_demo, false);
  ELSIF TG_TABLE_NAME = 'jobs' THEN
    _author := NEW.posted_by; _kind := 'job';
    _body := 'Posted a new job: ' || NEW.title;
  ELSIF TG_TABLE_NAME = 'services' THEN
    _author := NEW.builder_id; _kind := 'service';
    _body := 'Launched a new service: ' || NEW.title;
  ELSIF TG_TABLE_NAME = 'communities' THEN
    _author := NEW.created_by; _kind := 'community';
    _body := 'Started a new community: ' || NEW.name;
    _is_demo := COALESCE(NEW.is_demo, false);
  ELSIF TG_TABLE_NAME = 'prompts' THEN
    _author := NEW.author_id; _kind := 'prompt';
    _body := 'Dropped a new prompt: ' || NEW.title;
    _is_demo := COALESCE(NEW.is_demo, false);
  ELSIF TG_TABLE_NAME = 'workflows' THEN
    _author := NEW.author_id; _kind := 'workflow';
    _body := 'Shared a new workflow: ' || NEW.title;
    _is_demo := COALESCE(NEW.is_demo, false);
  ELSIF TG_TABLE_NAME = 'ai_tools' THEN
    _author := NEW.submitted_by; _kind := 'tool';
    _body := 'Added a new AI tool: ' || NEW.name;
    _is_demo := COALESCE(NEW.is_demo, false);
  ELSIF TG_TABLE_NAME = 'templates' THEN
    _author := NEW.author_id; _kind := 'template';
    _body := 'Shipped a new template: ' || NEW.title;
    _is_demo := COALESCE(NEW.is_demo, false);
  ELSE
    RETURN NEW;
  END IF;

  IF _author IS NULL OR _is_demo THEN
    RETURN NEW;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = _author) THEN
    RETURN NEW;
  END IF;

  INSERT INTO public.posts (author_id, kind, body, image_urls, project_id, ref_table, ref_id)
  VALUES (_author, _kind, _body, '{}', _project, TG_TABLE_NAME::text, NEW.id);
  RETURN NEW;
END $$;

-- Attach triggers to new entity tables
DROP TRIGGER IF EXISTS trg_autopost_prompts   ON public.prompts;
DROP TRIGGER IF EXISTS trg_autopost_workflows ON public.workflows;
DROP TRIGGER IF EXISTS trg_autopost_ai_tools  ON public.ai_tools;
DROP TRIGGER IF EXISTS trg_autopost_templates ON public.templates;
CREATE TRIGGER trg_autopost_prompts   AFTER INSERT ON public.prompts   FOR EACH ROW EXECUTE FUNCTION public.auto_post_entity_to_feed();
CREATE TRIGGER trg_autopost_workflows AFTER INSERT ON public.workflows FOR EACH ROW EXECUTE FUNCTION public.auto_post_entity_to_feed();
CREATE TRIGGER trg_autopost_ai_tools  AFTER INSERT ON public.ai_tools  FOR EACH ROW EXECUTE FUNCTION public.auto_post_entity_to_feed();
CREATE TRIGGER trg_autopost_templates AFTER INSERT ON public.templates FOR EACH ROW EXECUTE FUNCTION public.auto_post_entity_to_feed();

-- Realtime
ALTER TABLE public.prompts   REPLICA IDENTITY FULL;
ALTER TABLE public.workflows REPLICA IDENTITY FULL;
ALTER TABLE public.ai_tools  REPLICA IDENTITY FULL;
ALTER TABLE public.templates REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.prompts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.workflows;
ALTER PUBLICATION supabase_realtime ADD TABLE public.ai_tools;
ALTER PUBLICATION supabase_realtime ADD TABLE public.templates;
