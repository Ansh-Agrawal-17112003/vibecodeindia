
CREATE OR REPLACE FUNCTION public.admin_list_early_access_readiness()
RETURNS TABLE(
  email text,
  signed_up_at timestamptz,
  has_account boolean,
  user_id uuid,
  username text,
  display_name text,
  avatar_url text,
  is_og_founder boolean,
  og_founder_until timestamptz,
  plan text,
  subscription_end timestamptz,
  vibecoin_balance integer,
  last_login_date date
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  RETURN QUERY
  SELECT
    lower(e.email)                       AS email,
    e.created_at                         AS signed_up_at,
    (u.id IS NOT NULL)                   AS has_account,
    u.id                                 AS user_id,
    p.username                           AS username,
    p.display_name                       AS display_name,
    p.avatar_url                         AS avatar_url,
    COALESCE(p.is_og_founder, false)     AS is_og_founder,
    p.og_founder_until                   AS og_founder_until,
    COALESCE(s.plan, 'free')             AS plan,
    s.current_period_end                 AS subscription_end,
    COALESCE(p.vibecoin_balance, 0)      AS vibecoin_balance,
    p.last_login_date                    AS last_login_date
  FROM public.early_access_signups e
  LEFT JOIN auth.users u ON lower(u.email) = lower(e.email)
  LEFT JOIN public.profiles p ON p.id = u.id
  LEFT JOIN public.subscriptions s ON s.profile_id = u.id
  ORDER BY e.created_at DESC;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.admin_list_early_access_readiness() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_list_early_access_readiness() TO authenticated;
