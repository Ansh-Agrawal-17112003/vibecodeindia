-- 1. Profiles: stream chat token
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS stream_chat_token TEXT;

-- 2. Communities table
CREATE TABLE IF NOT EXISTS public.communities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  icon TEXT,
  description TEXT NOT NULL,
  category TEXT,
  banner_url TEXT,
  icon_url TEXT,
  member_count INTEGER NOT NULL DEFAULT 0,
  online_count INTEGER NOT NULL DEFAULT 0,
  posts_this_week INTEGER NOT NULL DEFAULT 0,
  hue INTEGER NOT NULL DEFAULT 200,
  rules TEXT,
  welcome_message TEXT,
  privacy TEXT NOT NULL DEFAULT 'public' CHECK (privacy IN ('public','private')),
  is_official BOOLEAN NOT NULL DEFAULT false,
  status TEXT NOT NULL DEFAULT 'approved' CHECK (status IN ('pending','approved','rejected')),
  stream_channel_id TEXT,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.communities TO anon, authenticated;
GRANT INSERT, UPDATE ON public.communities TO authenticated;
GRANT ALL ON public.communities TO service_role;
ALTER TABLE public.communities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view approved communities"
  ON public.communities FOR SELECT USING (status = 'approved' OR created_by = auth.uid());
CREATE POLICY "Authenticated users can create pending communities"
  ON public.communities FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by AND status = 'pending' AND is_official = false);
CREATE POLICY "Creator or platform admin can update community"
  ON public.communities FOR UPDATE TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS trg_touch_communities ON public.communities;
CREATE TRIGGER trg_touch_communities BEFORE UPDATE ON public.communities
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 3. Community members
CREATE TABLE IF NOT EXISTS public.community_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id UUID NOT NULL REFERENCES public.communities(id) ON DELETE CASCADE,
  profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member','contributor','moderator','admin')),
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  muted_until TIMESTAMPTZ,
  banned BOOLEAN NOT NULL DEFAULT false,
  UNIQUE (community_id, profile_id)
);
GRANT SELECT ON public.community_members TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.community_members TO authenticated;
GRANT ALL ON public.community_members TO service_role;
ALTER TABLE public.community_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view community members"
  ON public.community_members FOR SELECT USING (true);
CREATE POLICY "Users can join a community themselves"
  ON public.community_members FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = profile_id);
CREATE POLICY "Users can leave themselves"
  ON public.community_members FOR DELETE TO authenticated
  USING (auth.uid() = profile_id);
CREATE POLICY "Community mods/admins can update roles"
  ON public.community_members FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.community_members cm
      WHERE cm.community_id = community_members.community_id
        AND cm.profile_id = auth.uid()
        AND cm.role IN ('moderator','admin')
    )
  );

-- 4. Community channels (topic sub-rooms)
CREATE TABLE IF NOT EXISTS public.community_channels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id UUID NOT NULL REFERENCES public.communities(id) ON DELETE CASCADE,
  slug TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  stream_channel_id TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (community_id, slug)
);
GRANT SELECT ON public.community_channels TO anon, authenticated;
GRANT ALL ON public.community_channels TO service_role;
ALTER TABLE public.community_channels ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view community channels"
  ON public.community_channels FOR SELECT USING (true);

-- 5. Community invites
CREATE TABLE IF NOT EXISTS public.community_invites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id UUID NOT NULL REFERENCES public.communities(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  uses INTEGER NOT NULL DEFAULT 0,
  max_uses INTEGER,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.community_invites TO anon, authenticated;
GRANT INSERT ON public.community_invites TO authenticated;
GRANT ALL ON public.community_invites TO service_role;
ALTER TABLE public.community_invites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view invite by token"
  ON public.community_invites FOR SELECT USING (true);
CREATE POLICY "Authenticated members can create invites"
  ON public.community_invites FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by AND
    EXISTS (
      SELECT 1 FROM public.community_members cm
      WHERE cm.community_id = community_invites.community_id
        AND cm.profile_id = auth.uid()
    )
  );

-- 6. Member count trigger
CREATE OR REPLACE FUNCTION public.bump_community_member_count()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.communities SET member_count = member_count + 1 WHERE id = NEW.community_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.communities SET member_count = GREATEST(member_count - 1, 0) WHERE id = OLD.community_id;
  END IF;
  RETURN NULL;
END $$;
REVOKE EXECUTE ON FUNCTION public.bump_community_member_count() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_bump_community_member_count ON public.community_members;
CREATE TRIGGER trg_bump_community_member_count
  AFTER INSERT OR DELETE ON public.community_members
  FOR EACH ROW EXECUTE FUNCTION public.bump_community_member_count();