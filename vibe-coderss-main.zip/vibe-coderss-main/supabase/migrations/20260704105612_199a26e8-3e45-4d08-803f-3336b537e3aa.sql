
-- Tighten community_members self-insert policy to prevent bypassing
-- privacy (private/invite-only) or payment (paid) restrictions.

DROP POLICY IF EXISTS "Users can join a community themselves" ON public.community_members;

CREATE POLICY "Users can join a community themselves"
ON public.community_members
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = profile_id
  AND role = 'member'
  AND banned = false
  AND EXISTS (
    SELECT 1 FROM public.communities c
    WHERE c.id = community_id
      AND c.status = 'approved'
      AND (
        -- Case 1: Free + public community => instant active join
        (
          COALESCE(c.pricing_type, 'free') = 'free'
          AND COALESCE(c.privacy, 'public') = 'public'
          AND community_members.status = 'active'
        )
        -- Case 2: Paid community => only pending_payment self-insert allowed
        OR (
          COALESCE(c.pricing_type, 'free') <> 'free'
          AND community_members.status = 'pending_payment'
        )
        -- Case 3: Private/invite-only free community => require a valid invite to exist
        OR (
          COALESCE(c.pricing_type, 'free') = 'free'
          AND COALESCE(c.privacy, 'public') <> 'public'
          AND community_members.status = 'active'
          AND EXISTS (
            SELECT 1 FROM public.community_invites i
            WHERE i.community_id = c.id
              AND (i.expires_at IS NULL OR i.expires_at > now())
              AND (i.max_uses IS NULL OR i.uses < i.max_uses)
          )
        )
        -- Case 4: The creator can always join their own community
        OR c.created_by = auth.uid()
      )
  )
);
