
ALTER TABLE public.profiles DROP COLUMN IF EXISTS stream_chat_token;

DROP POLICY IF EXISTS "Anyone can view invite by token" ON public.community_invites;

CREATE OR REPLACE FUNCTION public.get_community_invite(_token text)
RETURNS TABLE(id uuid, community_id uuid, token text, uses integer, max_uses integer, expires_at timestamptz, created_by uuid, created_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id, community_id, token, uses, max_uses, expires_at, created_by, created_at
  FROM public.community_invites
  WHERE token = _token
  LIMIT 1;
$$;
REVOKE ALL ON FUNCTION public.get_community_invite(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_community_invite(text) TO anon, authenticated;

REVOKE SELECT (banned, muted_until) ON public.community_members FROM anon, authenticated;

DROP POLICY IF EXISTS "msg attach read authenticated" ON storage.objects;
CREATE POLICY "msg attach read participants"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'message-attachments' AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR EXISTS (
      SELECT 1 FROM public.messages m
      WHERE m.recipient_id = auth.uid()
        AND m.attachment_url LIKE '%' || name
    )
  )
);

CREATE OR REPLACE FUNCTION public.get_public_platform_settings()
RETURNS TABLE(key text, value text)
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT key, value FROM public.platform_settings WHERE key IN ('free_search_limit');
$$;

CREATE POLICY "Public can read allowlisted settings"
ON public.platform_settings FOR SELECT
TO anon, authenticated
USING (key IN ('free_search_limit'));
