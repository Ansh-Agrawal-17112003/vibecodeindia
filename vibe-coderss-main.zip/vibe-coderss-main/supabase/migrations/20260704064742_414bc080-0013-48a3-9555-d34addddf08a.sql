
-- 1) Communities: enforce privacy on SELECT
DROP POLICY IF EXISTS "Anyone can view approved communities" ON public.communities;

CREATE POLICY "View communities respecting privacy"
ON public.communities
FOR SELECT
TO anon, authenticated
USING (
  (status = 'approved' AND COALESCE(privacy, 'public') = 'public')
  OR created_by = auth.uid()
  OR public.is_community_member(id, auth.uid())
  OR public.has_role(auth.uid(), 'admin'::public.app_role)
);

-- 2) Community channels: gate on parent community visibility/membership
DROP POLICY IF EXISTS "Anyone can view community channels" ON public.community_channels;

CREATE POLICY "View channels of visible or joined communities"
ON public.community_channels
FOR SELECT
TO anon, authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.communities c
    WHERE c.id = community_channels.community_id
      AND (
        (c.status = 'approved' AND COALESCE(c.privacy, 'public') = 'public')
        OR c.created_by = auth.uid()
        OR public.is_community_member(c.id, auth.uid())
        OR public.has_role(auth.uid(), 'admin'::public.app_role)
      )
  )
);

-- 3) Revoke anon/public EXECUTE on trigger-only SECURITY DEFINER functions.
--    Trigger functions do not need EXECUTE for API callers; the trigger system
--    invokes them regardless of role privileges.
REVOKE EXECUTE ON FUNCTION public.bump_post_like_count() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.bump_post_comment_count() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.bump_repost_count() FROM PUBLIC, anon;
