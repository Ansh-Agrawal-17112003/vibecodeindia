
REVOKE EXECUTE ON FUNCTION public.get_profile_analytics(uuid, integer) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.get_viewer_breakdown(uuid, integer) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.get_content_analytics(uuid, integer) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.get_hiring_analytics(uuid, integer) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.guard_companies_plan() FROM PUBLIC, anon;
