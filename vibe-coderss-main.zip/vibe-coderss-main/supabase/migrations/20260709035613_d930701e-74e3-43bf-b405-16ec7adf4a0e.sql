CREATE OR REPLACE FUNCTION public.refresh_og_claim_stats_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  visible_count integer;
  next_claim_number integer;
BEGIN
  SELECT COUNT(*)::int
  INTO visible_count
  FROM public.og_members
  WHERE og_number IS NOT NULL AND show_on_wall = true;

  -- Next spot = visible + 1 (hidden/suspended slots stay as memorial gaps,
  -- new signups continue the visible sequence).
  next_claim_number := visible_count + 1;
  IF next_claim_number < 4 THEN
    next_claim_number := 4;
  END IF;

  INSERT INTO public.og_claim_stats (id, taken, remaining, next_number, updated_at)
  VALUES (
    true,
    visible_count,
    GREATEST(0, 100 - visible_count),
    LEAST(100, next_claim_number),
    now()
  )
  ON CONFLICT (id) DO UPDATE
  SET
    taken = EXCLUDED.taken,
    remaining = EXCLUDED.remaining,
    next_number = EXCLUDED.next_number,
    updated_at = EXCLUDED.updated_at;

  RETURN NULL;
END;
$function$;

-- Refresh the current stats row immediately.
UPDATE public.og_claim_stats
SET
  taken = (SELECT COUNT(*)::int FROM public.og_members WHERE og_number IS NOT NULL AND show_on_wall = true),
  remaining = GREATEST(0, 100 - (SELECT COUNT(*)::int FROM public.og_members WHERE og_number IS NOT NULL AND show_on_wall = true)),
  next_number = LEAST(100, GREATEST(4, (SELECT COUNT(*)::int FROM public.og_members WHERE og_number IS NOT NULL AND show_on_wall = true) + 1)),
  updated_at = now()
WHERE id = true;