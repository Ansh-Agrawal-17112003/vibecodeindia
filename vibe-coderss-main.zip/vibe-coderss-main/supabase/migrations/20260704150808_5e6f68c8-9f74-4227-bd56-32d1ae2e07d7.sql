-- Make role checks safe for policies that read user_roles.
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

REVOKE ALL ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO service_role;

-- Remove the old admin-only profile roles guard everywhere, including older trigger/function names.
DROP TRIGGER IF EXISTS guard_profiles_roles_column ON public.profiles;
DROP TRIGGER IF EXISTS trg_guard_profiles_roles_column ON public.profiles;
DROP FUNCTION IF EXISTS public.guard_profiles_roles_column() CASCADE;

-- Allow users to manage only their own public product roles during onboarding.
-- Admin and super_admin roles remain admin-controlled only.
DROP POLICY IF EXISTS "Users can insert own builder or hirer roles" ON public.user_roles;
CREATE POLICY "Users can insert own builder or hirer roles"
ON public.user_roles
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id
  AND role IN ('builder'::public.app_role, 'hirer'::public.app_role)
);

DROP POLICY IF EXISTS "Users can update own builder or hirer roles" ON public.user_roles;
CREATE POLICY "Users can update own builder or hirer roles"
ON public.user_roles
FOR UPDATE
TO authenticated
USING (
  auth.uid() = user_id
  AND role IN ('builder'::public.app_role, 'hirer'::public.app_role)
)
WITH CHECK (
  auth.uid() = user_id
  AND role IN ('builder'::public.app_role, 'hirer'::public.app_role)
);

DROP POLICY IF EXISTS "Users can delete own builder or hirer roles" ON public.user_roles;
CREATE POLICY "Users can delete own builder or hirer roles"
ON public.user_roles
FOR DELETE
TO authenticated
USING (
  auth.uid() = user_id
  AND role IN ('builder'::public.app_role, 'hirer'::public.app_role)
);

-- Keep the legacy profiles.roles array in sync for UI surfaces that still display it.
CREATE OR REPLACE FUNCTION public.sync_profile_roles_from_user_roles()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _uid uuid := COALESCE(NEW.user_id, OLD.user_id);
  _roles text[];
BEGIN
  SELECT COALESCE(array_agg(role::text ORDER BY role::text), ARRAY[]::text[])
    INTO _roles
  FROM public.user_roles
  WHERE user_id = _uid
    AND role IN ('builder'::public.app_role, 'hirer'::public.app_role);

  UPDATE public.profiles
     SET roles = _roles,
         updated_at = now()
   WHERE id = _uid;

  RETURN NULL;
END;
$$;

REVOKE ALL ON FUNCTION public.sync_profile_roles_from_user_roles() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.sync_profile_roles_from_user_roles() TO service_role;

DROP TRIGGER IF EXISTS trg_sync_profile_roles_from_user_roles ON public.user_roles;
CREATE TRIGGER trg_sync_profile_roles_from_user_roles
AFTER INSERT OR UPDATE OR DELETE ON public.user_roles
FOR EACH ROW
EXECUTE FUNCTION public.sync_profile_roles_from_user_roles();