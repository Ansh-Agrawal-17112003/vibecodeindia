update public.mirror_outbox
   set attempts = 0, last_error = null
 where sent_at is null and last_error is not null;