CREATE OR REPLACE FUNCTION public.is_community_admin(_community_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.community_members
    WHERE community_id = _community_id
      AND profile_id = _user_id
      AND role = 'admin'
  );
$$;

DROP POLICY IF EXISTS "Community mods/admins can update roles" ON public.community_members;

CREATE POLICY "Community admins can update member roles"
ON public.community_members
FOR UPDATE
TO authenticated
USING (
  public.is_community_admin(community_id, auth.uid())
  AND profile_id <> auth.uid()
)
WITH CHECK (
  public.is_community_admin(community_id, auth.uid())
  AND profile_id <> auth.uid()
  AND role IN ('member', 'moderator')
);