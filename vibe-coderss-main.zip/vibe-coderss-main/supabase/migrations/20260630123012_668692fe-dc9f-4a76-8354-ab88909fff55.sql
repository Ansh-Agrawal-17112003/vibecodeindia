-- Tighten notification insert policy
DROP POLICY "system insert notifs" ON public.notifications;
CREATE POLICY "self insert notifs" ON public.notifications FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Restrict SECURITY DEFINER function execution
REVOKE EXECUTE ON FUNCTION public.get_or_create_conversation(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_or_create_conversation(UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.after_message_insert() FROM PUBLIC, anon, authenticated;