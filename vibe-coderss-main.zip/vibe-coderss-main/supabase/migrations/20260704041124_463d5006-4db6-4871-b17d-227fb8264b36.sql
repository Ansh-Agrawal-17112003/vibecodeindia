CREATE OR REPLACE FUNCTION public.validate_message_attachment_ownership()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  _path text;
  _folder text;
BEGIN
  IF NEW.attachment_url IS NULL OR NEW.attachment_url = '' THEN
    RETURN NEW;
  END IF;

  -- Extract the object path after '/message-attachments/' and strip any query string
  _path := split_part(split_part(NEW.attachment_url, '/message-attachments/', 2), '?', 1);

  IF _path IS NULL OR _path = '' THEN
    RAISE EXCEPTION 'Invalid attachment_url: not a message-attachments path';
  END IF;

  _folder := split_part(_path, '/', 1);

  IF _folder <> NEW.sender_id::text THEN
    RAISE EXCEPTION 'attachment_url must point to a file in the sender''s own folder';
  END IF;

  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_validate_message_attachment ON public.messages;
CREATE TRIGGER trg_validate_message_attachment
  BEFORE INSERT OR UPDATE OF attachment_url ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.validate_message_attachment_ownership();

REVOKE EXECUTE ON FUNCTION public.validate_message_attachment_ownership() FROM PUBLIC, anon, authenticated;