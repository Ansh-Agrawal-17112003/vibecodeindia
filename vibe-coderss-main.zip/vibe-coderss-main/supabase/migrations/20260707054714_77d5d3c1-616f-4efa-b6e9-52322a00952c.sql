-- Restore Data API grants on og_members (RLS still enforces row-level access)
GRANT SELECT, INSERT ON public.og_members TO anon;
GRANT SELECT, INSERT, UPDATE ON public.og_members TO authenticated;
GRANT ALL ON public.og_members TO service_role;

-- Ensure the public view and spots-remaining view are readable
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_views WHERE schemaname='public' AND viewname='og_wall_public') THEN
    EXECUTE 'GRANT SELECT ON public.og_wall_public TO anon, authenticated';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_views WHERE schemaname='public' AND viewname='og_spots_remaining') THEN
    EXECUTE 'GRANT SELECT ON public.og_spots_remaining TO anon, authenticated';
  END IF;
END $$;