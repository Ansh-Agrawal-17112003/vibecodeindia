UPDATE public.og_members SET username = 'kk' WHERE og_number = 3 AND username IS NULL;
UPDATE public.og_members SET username = 'tanmay' WHERE og_number = 1 AND username IS NULL;
UPDATE public.og_members SET username = 'rishita' WHERE og_number = 2 AND username IS NULL;