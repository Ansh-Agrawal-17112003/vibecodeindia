
CREATE TABLE IF NOT EXISTS public.mirror_config (
  key text PRIMARY KEY,
  value text NOT NULL
);
GRANT ALL ON public.mirror_config TO service_role;
ALTER TABLE public.mirror_config ENABLE ROW LEVEL SECURITY;
-- No policies: service-role only.

INSERT INTO public.mirror_config (key, value)
VALUES ('cron_secret','l2trIpmM5eunLfweHQEmu2NF8M56cfOOzuAtbE6CL-7E6-pK6fesqSNKQkFKtScj')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- Rewrite cron jobs to read secret from the config table
DO $$
DECLARE j record;
BEGIN
  FOR j IN SELECT jobid FROM cron.job WHERE jobname IN ('mirror-drain-30s','mirror-drain-30s-b') LOOP
    PERFORM cron.unschedule(j.jobid);
  END LOOP;
END $$;

SELECT cron.schedule(
  'mirror-drain-30s',
  '* * * * *',
  $$
  SELECT net.http_post(
    url := 'https://project--f48ce3b8-96de-426c-a0e7-9141f9297d2e-dev.lovable.app/api/public/mirror-drain',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'x-mirror-secret', (SELECT value FROM public.mirror_config WHERE key='cron_secret')
    ),
    body := '{}'::jsonb,
    timeout_milliseconds := 25000
  );
  $$
);

SELECT cron.schedule(
  'mirror-drain-30s-b',
  '* * * * *',
  $$
  SELECT pg_sleep(30);
  SELECT net.http_post(
    url := 'https://project--f48ce3b8-96de-426c-a0e7-9141f9297d2e-dev.lovable.app/api/public/mirror-drain',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'x-mirror-secret', (SELECT value FROM public.mirror_config WHERE key='cron_secret')
    ),
    body := '{}'::jsonb,
    timeout_milliseconds := 25000
  );
  $$
);
