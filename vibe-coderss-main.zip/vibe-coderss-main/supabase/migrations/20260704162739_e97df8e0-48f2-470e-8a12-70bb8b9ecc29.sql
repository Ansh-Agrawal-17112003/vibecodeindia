
-- Add edited_at and edit/delete policies for messages and post_comments

ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS edited_at timestamptz;
ALTER TABLE public.post_comments ADD COLUMN IF NOT EXISTS edited_at timestamptz;

-- Sender can update body/edited_at within 15 minutes
DROP POLICY IF EXISTS "sender edit msgs" ON public.messages;
CREATE POLICY "sender edit msgs" ON public.messages
  FOR UPDATE TO authenticated
  USING (auth.uid() = sender_id AND created_at > now() - interval '15 minutes')
  WITH CHECK (auth.uid() = sender_id);

-- Sender can delete their own message
DROP POLICY IF EXISTS "sender delete msgs" ON public.messages;
CREATE POLICY "sender delete msgs" ON public.messages
  FOR DELETE TO authenticated
  USING (auth.uid() = sender_id);

-- Author can edit own comment within 30 minutes
DROP POLICY IF EXISTS "comments_self_edit" ON public.post_comments;
CREATE POLICY "comments_self_edit" ON public.post_comments
  FOR UPDATE TO authenticated
  USING (auth.uid() = author_id AND created_at > now() - interval '30 minutes')
  WITH CHECK (auth.uid() = author_id);

-- Auto-touch edited_at on body change
CREATE OR REPLACE FUNCTION public.touch_edited_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.body IS DISTINCT FROM OLD.body THEN
    NEW.edited_at = now();
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS messages_touch_edited ON public.messages;
CREATE TRIGGER messages_touch_edited BEFORE UPDATE ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.touch_edited_at();

DROP TRIGGER IF EXISTS post_comments_touch_edited ON public.post_comments;
CREATE TRIGGER post_comments_touch_edited BEFORE UPDATE ON public.post_comments
  FOR EACH ROW EXECUTE FUNCTION public.touch_edited_at();
