CREATE TABLE public.early_access_signups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  source TEXT DEFAULT 'welcome_modal',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT INSERT ON public.early_access_signups TO anon, authenticated;
GRANT ALL ON public.early_access_signups TO service_role;
ALTER TABLE public.early_access_signups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone can subscribe" ON public.early_access_signups FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "admins can read" ON public.early_access_signups FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));