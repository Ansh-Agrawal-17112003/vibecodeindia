-- Revoke direct EXECUTE on internal trigger functions from all client roles.
-- Triggers still fire because triggers run with the trigger owner's rights, not the caller's.
REVOKE EXECUTE ON FUNCTION public.activate_subscription_on_verify() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.bump_follow_counts() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.bump_project_upvotes() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.after_message_insert() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;

-- Also lock down platform_settings direct table access. Admin-only policy stays;
-- ensure no lingering table-level grants to anon/authenticated so the only
-- read path is the public SECURITY DEFINER helper get_public_platform_settings().
REVOKE ALL ON TABLE public.platform_settings FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.platform_settings TO authenticated;
-- (RLS still limits authenticated SELECT/UPDATE to admins via existing policies.)