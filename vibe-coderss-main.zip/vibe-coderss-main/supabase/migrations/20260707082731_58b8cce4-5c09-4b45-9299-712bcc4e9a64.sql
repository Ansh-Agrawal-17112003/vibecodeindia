ALTER TABLE public.og_members
  DROP CONSTRAINT IF EXISTS og_number_range;

ALTER TABLE public.og_members
  ADD CONSTRAINT og_number_range CHECK (og_number IS NULL OR (og_number >= 1 AND og_number <= 100));

CREATE OR REPLACE VIEW public.og_spots_remaining AS
SELECT
  GREATEST(0, 100 - COUNT(og_number))::int AS remaining,
  COUNT(og_number)::int AS taken,
  LEAST(100, COUNT(og_number) + 1)::int AS next_number
FROM public.og_members;

GRANT SELECT ON public.og_spots_remaining TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.assign_og_number()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  next_number integer;
BEGIN
  IF NEW.og_number IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT COALESCE(MAX(og_number), 0) + 1 INTO next_number
  FROM public.og_members;

  IF next_number < 4 THEN
    next_number := 4;
  END IF;

  IF next_number > 100 THEN
    RAISE EXCEPTION 'OG spots are full';
  END IF;

  NEW.og_number := next_number;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.assign_og_number() FROM PUBLIC, anon, authenticated;