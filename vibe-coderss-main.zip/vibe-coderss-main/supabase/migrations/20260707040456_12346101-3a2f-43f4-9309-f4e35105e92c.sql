
-- 1. og_members: restrict anon column access to safe public fields only
REVOKE SELECT ON public.og_members FROM anon;
GRANT SELECT (id, username, wall_tagline, og_number, builder_type, primary_tool, show_on_wall, signed_up_at) ON public.og_members TO anon;
-- authenticated retains full row access (subject to RLS)
GRANT SELECT ON public.og_members TO authenticated;

-- og_waitlist: no anon read (only admin policy exists), keep as-is but ensure no anon SELECT grant
REVOKE SELECT ON public.og_waitlist FROM anon;

-- 2. communities: hide stream_channel_id from anon; authenticated keeps full access
REVOKE SELECT ON public.communities FROM anon;
GRANT SELECT (id, slug, name, icon, description, category, banner_url, icon_url, member_count, online_count, posts_this_week, hue, rules, welcome_message, privacy, is_official, status, created_by, created_at, updated_at, pricing_type, price_inr, trial_days, is_demo) ON public.communities TO anon;

-- 3. Message attachment storage policy: strict path equality instead of LIKE
DROP POLICY IF EXISTS "msg attach read participants" ON storage.objects;
CREATE POLICY "msg attach read participants" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'message-attachments'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR EXISTS (
        SELECT 1 FROM public.messages m
        WHERE m.recipient_id = auth.uid()
          AND split_part(split_part(m.attachment_url, '/message-attachments/', 2), '?', 1) = objects.name
      )
    )
  );

-- 4. Tighten always-true INSERT policies with minimal email validation
DROP POLICY IF EXISTS og_public_insert ON public.og_members;
CREATE POLICY og_public_insert ON public.og_members
  FOR INSERT TO anon, authenticated
  WITH CHECK (email IS NOT NULL AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$');

DROP POLICY IF EXISTS waitlist_public_insert ON public.og_waitlist;
CREATE POLICY waitlist_public_insert ON public.og_waitlist
  FOR INSERT TO anon, authenticated
  WITH CHECK (email IS NOT NULL AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$');

-- 5. Revoke EXECUTE on SECURITY DEFINER functions from public/anon; grant only where needed
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated;

REVOKE EXECUTE ON FUNCTION public._notif_name(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public._notif_push(uuid, uuid, text, text, text, text) FROM PUBLIC, anon, authenticated;

REVOKE EXECUTE ON FUNCTION public.is_community_admin(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_community_admin(uuid, uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.is_community_member(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_community_member(uuid, uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.check_daily_login() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.check_daily_login() TO authenticated;

REVOKE EXECUTE ON FUNCTION public.join_community_by_invite(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.join_community_by_invite(uuid, text) TO authenticated;

-- get_community_invite may be viewed by anon on invite landing pages
REVOKE EXECUTE ON FUNCTION public.get_community_invite(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_community_invite(text) TO anon, authenticated;
