
-- 1) Enhance activate_og_pro_benefits: also stamp og_number + OG founder markers.
CREATE OR REPLACE FUNCTION public.activate_og_pro_benefits(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_new_balance int;
  v_og_number int;
  v_city text;
  v_username text;
  v_now timestamptz := now();
BEGIN
  SELECT om.og_number, om.city, om.username
  INTO v_og_number, v_city, v_username
  FROM public.og_members om
  WHERE om.profile_id = p_user_id
  ORDER BY om.og_number NULLS LAST
  LIMIT 1;

  UPDATE public.profiles SET
    subscription_plan     = 'og_pro',
    subscription_status   = 'active',
    pro_until             = TIMESTAMPTZ '2027-08-04 00:00:00+00',
    is_verified           = true,
    is_og_member          = true,
    og_number             = COALESCE(og_number, v_og_number),
    is_og_founder         = true,
    og_founder_since      = COALESCE(og_founder_since, v_now),
    og_founder_until      = GREATEST(COALESCE(og_founder_until, v_now), v_now + interval '1 year'),
    monthly_boosts_limit  = GREATEST(COALESCE(monthly_boosts_limit,0), 2),
    location              = COALESCE(NULLIF(location,''), v_city),
    username              = COALESCE(NULLIF(username,''), v_username),
    vibecoin_balance      = COALESCE(vibecoin_balance,0) + 500
  WHERE id = p_user_id
  RETURNING vibecoin_balance INTO v_new_balance;

  IF v_new_balance IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.vibecoin_transactions
      WHERE profile_id = p_user_id AND reason = 'og_founding_member_bonus'
    ) THEN
      INSERT INTO public.vibecoin_transactions(profile_id, type, amount, reason)
      VALUES (p_user_id, 'earned', 500, 'og_founding_member_bonus');
    END IF;
  END IF;
END;
$$;

-- 2) Auto-link on new profile creation.
CREATE OR REPLACE FUNCTION public.link_og_member_on_profile_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_email text;
  v_og_id uuid;
BEGIN
  SELECT lower(email) INTO v_email FROM auth.users WHERE id = NEW.id;
  IF v_email IS NULL THEN RETURN NEW; END IF;

  SELECT id INTO v_og_id
  FROM public.og_members
  WHERE lower(email) = v_email
    AND (profile_id IS NULL OR profile_id = NEW.id)
  ORDER BY og_number NULLS LAST
  LIMIT 1;

  IF v_og_id IS NULL THEN RETURN NEW; END IF;

  UPDATE public.og_members
    SET profile_id  = NEW.id,
        activated_at = COALESCE(activated_at, now())
    WHERE id = v_og_id;

  PERFORM public.activate_og_pro_benefits(NEW.id);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_link_og_member_on_profile_insert ON public.profiles;
CREATE TRIGGER trg_link_og_member_on_profile_insert
AFTER INSERT ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.link_og_member_on_profile_insert();

-- 3) Backfill existing profiles whose auth email matches an og_members row.
DO $backfill$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT p.id AS profile_id, om.id AS og_id
    FROM public.profiles p
    JOIN auth.users u ON u.id = p.id
    JOIN public.og_members om ON lower(om.email) = lower(u.email)
    WHERE om.profile_id IS DISTINCT FROM p.id
  LOOP
    UPDATE public.og_members
      SET profile_id = r.profile_id,
          activated_at = COALESCE(activated_at, now())
      WHERE id = r.og_id;
    PERFORM public.activate_og_pro_benefits(r.profile_id);
  END LOOP;
END;
$backfill$;

-- 4) Manually pin Tanmay Purwar (OG #1) to his existing profile.
UPDATE public.og_members
   SET profile_id = '06964a47-1b9f-4743-900b-a6ff41010c41'::uuid,
       activated_at = COALESCE(activated_at, now())
 WHERE og_number = 1;

SELECT public.activate_og_pro_benefits('06964a47-1b9f-4743-900b-a6ff41010c41'::uuid);
