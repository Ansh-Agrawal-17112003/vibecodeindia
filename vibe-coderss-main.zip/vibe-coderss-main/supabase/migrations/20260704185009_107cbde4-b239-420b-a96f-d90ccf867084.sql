
REVOKE EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) FROM PUBLIC, anon, authenticated;
