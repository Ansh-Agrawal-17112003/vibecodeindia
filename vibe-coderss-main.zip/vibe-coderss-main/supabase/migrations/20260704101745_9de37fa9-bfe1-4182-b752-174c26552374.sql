-- 1. Extend posts.kind allowed values
ALTER TABLE public.posts DROP CONSTRAINT IF EXISTS posts_kind_check;
ALTER TABLE public.posts ADD CONSTRAINT posts_kind_check
  CHECK (kind = ANY (ARRAY['text','image','project','repost','job','service','community']));

-- 2. Add generic entity reference columns
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS ref_table text;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS ref_id uuid;
CREATE INDEX IF NOT EXISTS posts_ref_idx ON public.posts (ref_table, ref_id);

-- 3. Auto-post trigger function (runs as definer so RLS on posts is not an issue)
CREATE OR REPLACE FUNCTION public.auto_post_entity_to_feed()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _author uuid;
  _kind text;
  _body text;
  _project uuid := NULL;
  _is_demo boolean := false;
BEGIN
  IF TG_TABLE_NAME = 'projects' THEN
    _author := NEW.builder_id;
    _kind := 'project';
    _body := 'Shipped a new project: ' || NEW.title;
    _project := NEW.id;
    _is_demo := COALESCE(NEW.is_demo, false);
  ELSIF TG_TABLE_NAME = 'jobs' THEN
    _author := NEW.posted_by;
    _kind := 'job';
    _body := 'Posted a new job: ' || NEW.title;
  ELSIF TG_TABLE_NAME = 'services' THEN
    _author := NEW.builder_id;
    _kind := 'service';
    _body := 'Launched a new service: ' || NEW.title;
  ELSIF TG_TABLE_NAME = 'communities' THEN
    _author := NEW.created_by;
    _kind := 'community';
    _body := 'Started a new community: ' || NEW.name;
    _is_demo := COALESCE(NEW.is_demo, false);
  ELSE
    RETURN NEW;
  END IF;

  IF _author IS NULL OR _is_demo THEN
    RETURN NEW;
  END IF;

  -- Ensure a profile row exists (should always, but be defensive)
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = _author) THEN
    RETURN NEW;
  END IF;

  INSERT INTO public.posts (author_id, kind, body, image_urls, project_id, ref_table, ref_id)
  VALUES (_author, _kind, _body, '{}', _project, TG_TABLE_NAME::text, NEW.id);

  RETURN NEW;
END $$;

-- 4. Attach trigger to each entity table
DROP TRIGGER IF EXISTS trg_autopost_projects   ON public.projects;
DROP TRIGGER IF EXISTS trg_autopost_jobs       ON public.jobs;
DROP TRIGGER IF EXISTS trg_autopost_services   ON public.services;
DROP TRIGGER IF EXISTS trg_autopost_communities ON public.communities;

CREATE TRIGGER trg_autopost_projects   AFTER INSERT ON public.projects   FOR EACH ROW EXECUTE FUNCTION public.auto_post_entity_to_feed();
CREATE TRIGGER trg_autopost_jobs       AFTER INSERT ON public.jobs       FOR EACH ROW EXECUTE FUNCTION public.auto_post_entity_to_feed();
CREATE TRIGGER trg_autopost_services   AFTER INSERT ON public.services   FOR EACH ROW EXECUTE FUNCTION public.auto_post_entity_to_feed();
CREATE TRIGGER trg_autopost_communities AFTER INSERT ON public.communities FOR EACH ROW EXECUTE FUNCTION public.auto_post_entity_to_feed();

-- 5. Enable Realtime on all four tables (idempotent)
DO $$
DECLARE
  t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['projects','jobs','services','communities'] LOOP
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = t
    ) THEN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    END IF;
  END LOOP;
END $$;

-- 6. Ensure REPLICA IDENTITY FULL so realtime UPDATE payloads carry old values
ALTER TABLE public.projects    REPLICA IDENTITY FULL;
ALTER TABLE public.jobs        REPLICA IDENTITY FULL;
ALTER TABLE public.services    REPLICA IDENTITY FULL;
ALTER TABLE public.communities REPLICA IDENTITY FULL;