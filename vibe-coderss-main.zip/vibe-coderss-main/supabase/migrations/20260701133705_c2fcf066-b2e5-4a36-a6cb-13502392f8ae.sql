
DROP POLICY IF EXISTS "Authenticated read settings" ON public.platform_settings;

CREATE POLICY "Admins read settings"
ON public.platform_settings
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE OR REPLACE FUNCTION public.get_public_platform_settings()
RETURNS TABLE(key text, value text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT key, value
  FROM public.platform_settings
  WHERE key IN ('free_search_limit');
$$;

REVOKE ALL ON FUNCTION public.get_public_platform_settings() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_public_platform_settings() TO authenticated;
