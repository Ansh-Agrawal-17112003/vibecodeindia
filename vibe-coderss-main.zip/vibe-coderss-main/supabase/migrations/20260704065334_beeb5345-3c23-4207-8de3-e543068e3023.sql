
-- Communities: guard status + is_official from non-admin edits
CREATE OR REPLACE FUNCTION public.guard_communities_admin_fields()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    RAISE EXCEPTION 'Only admins can change community status';
  END IF;
  IF NEW.is_official IS DISTINCT FROM OLD.is_official THEN
    RAISE EXCEPTION 'Only admins can change is_official';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_guard_communities_admin_fields ON public.communities;
CREATE TRIGGER trg_guard_communities_admin_fields
BEFORE UPDATE ON public.communities
FOR EACH ROW EXECUTE FUNCTION public.guard_communities_admin_fields();

-- Job applications: applicants cannot change status
CREATE OR REPLACE FUNCTION public.guard_job_applications_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _is_poster boolean;
BEGIN
  IF public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    SELECT EXISTS (
      SELECT 1 FROM public.jobs j
      WHERE j.id = NEW.job_id AND j.posted_by = auth.uid()
    ) INTO _is_poster;
    IF NOT _is_poster THEN
      RAISE EXCEPTION 'Only the job poster or an admin can change application status';
    END IF;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_guard_job_applications_status ON public.job_applications;
CREATE TRIGGER trg_guard_job_applications_status
BEFORE UPDATE ON public.job_applications
FOR EACH ROW EXECUTE FUNCTION public.guard_job_applications_status();

-- Builder details: only admins may set verified
CREATE OR REPLACE FUNCTION public.guard_builder_details_verified()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'INSERT' THEN
    NEW.verified := false;
    RETURN NEW;
  END IF;
  IF NEW.verified IS DISTINCT FROM OLD.verified THEN
    RAISE EXCEPTION 'Only admins can change verified status';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_guard_builder_details_verified ON public.builder_details;
CREATE TRIGGER trg_guard_builder_details_verified
BEFORE INSERT OR UPDATE ON public.builder_details
FOR EACH ROW EXECUTE FUNCTION public.guard_builder_details_verified();

-- Companies: only admins may set verified
CREATE OR REPLACE FUNCTION public.guard_companies_verified()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'INSERT' THEN
    NEW.verified := false;
    RETURN NEW;
  END IF;
  IF NEW.verified IS DISTINCT FROM OLD.verified THEN
    RAISE EXCEPTION 'Only admins can change verified status';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_guard_companies_verified ON public.companies;
CREATE TRIGGER trg_guard_companies_verified
BEFORE INSERT OR UPDATE ON public.companies
FOR EACH ROW EXECUTE FUNCTION public.guard_companies_verified();

-- These guard functions are triggers; do not expose EXECUTE to API roles.
REVOKE EXECUTE ON FUNCTION public.guard_communities_admin_fields() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.guard_job_applications_status() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.guard_builder_details_verified() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.guard_companies_verified() FROM PUBLIC, anon, authenticated;
