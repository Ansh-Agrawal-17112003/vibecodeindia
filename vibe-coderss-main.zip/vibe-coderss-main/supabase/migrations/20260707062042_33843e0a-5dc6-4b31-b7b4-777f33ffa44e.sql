-- 1) Reset table-level privileges for anon/authenticated
REVOKE ALL ON public.og_members FROM anon, authenticated;

-- 2) Anon: only SELECT on safe wall-visible columns; INSERT limited to safe signup columns
GRANT SELECT (username, wall_tagline, og_number, builder_type, primary_tool, show_on_wall, signed_up_at)
  ON public.og_members TO anon;
GRANT INSERT (full_name, email, username, city, state, builder_type, primary_tool, other_tools,
              what_building, linkedin_url, twitter_url, github_url, show_on_wall, wall_tagline,
              referral_source)
  ON public.og_members TO anon;

-- 3) Authenticated: full SELECT (needed for own_read + admin_read), INSERT on safe columns, UPDATE for admins on all cols
GRANT SELECT ON public.og_members TO authenticated;
GRANT INSERT (full_name, email, username, city, state, builder_type, primary_tool, other_tools,
              what_building, linkedin_url, twitter_url, github_url, show_on_wall, wall_tagline,
              referral_source, profile_id)
  ON public.og_members TO authenticated;
GRANT UPDATE ON public.og_members TO authenticated;

-- 4) Restrict the wall_read policy to anon only (authenticated users use og_own_read / og_admin_read)
DROP POLICY IF EXISTS og_wall_read ON public.og_members;
DROP POLICY IF EXISTS "Anon can read wall-visible OG members via view" ON public.og_members;
CREATE POLICY og_wall_read_anon ON public.og_members
  FOR SELECT TO anon
  USING (show_on_wall = true);

-- 5) Tighten insert policy: enforce server-controlled defaults at the RLS layer
DROP POLICY IF EXISTS og_public_insert ON public.og_members;
CREATE POLICY og_public_insert ON public.og_members
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    email IS NOT NULL
    AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND COALESCE(og_status, 'pending') = 'pending'
    AND COALESCE(free_pro_granted, false) = false
    AND free_pro_until IS NULL
    AND og_number IS NULL
    AND activated_at IS NULL
    AND ip_address IS NULL
    AND user_agent IS NULL
    AND (
      (auth.uid() IS NULL AND profile_id IS NULL)
      OR (auth.uid() IS NOT NULL AND (profile_id IS NULL OR profile_id = auth.uid()))
    )
  );

GRANT ALL ON public.og_members TO service_role;
