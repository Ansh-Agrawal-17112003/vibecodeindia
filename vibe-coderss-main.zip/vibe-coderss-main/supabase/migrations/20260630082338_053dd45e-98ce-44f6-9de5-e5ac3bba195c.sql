
-- ENUMS
CREATE TYPE public.app_role AS ENUM ('builder','hirer','admin');
CREATE TYPE public.availability_status AS ENUM ('available','open_to_work','unavailable');
CREATE TYPE public.builder_type AS ENUM ('freelancer','agency','student','founder');
CREATE TYPE public.experience_level AS ENUM ('junior','mid','senior','lead');
CREATE TYPE public.job_type AS ENUM ('full-time','part-time','freelance','internship');
CREATE TYPE public.remote_type AS ENUM ('remote','hybrid','onsite');
CREATE TYPE public.job_status AS ENUM ('active','closed');
CREATE TYPE public.application_status AS ENUM ('applied','reviewed','shortlisted','rejected','hired');
CREATE TYPE public.upvote_target AS ENUM ('project','prompt','workflow');

-- PROFILES
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE,
  display_name TEXT,
  avatar_url TEXT,
  banner_url TEXT,
  bio TEXT,
  location TEXT,
  roles TEXT[] NOT NULL DEFAULT '{}',
  availability_status public.availability_status DEFAULT 'available',
  follower_count INT NOT NULL DEFAULT 0,
  following_count INT NOT NULL DEFAULT 0,
  onboarded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.profiles TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Profiles are public" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

-- USER ROLES (security checks)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users add own roles" ON public.user_roles FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users remove own roles" ON public.user_roles FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- BUILDER DETAILS
CREATE TABLE public.builder_details (
  profile_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  title TEXT,
  skills TEXT[] NOT NULL DEFAULT '{}',
  ai_tools TEXT[] NOT NULL DEFAULT '{}',
  github_url TEXT,
  linkedin_url TEXT,
  website_url TEXT,
  experience_level public.experience_level,
  builder_type public.builder_type,
  verified BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.builder_details TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.builder_details TO authenticated;
GRANT ALL ON public.builder_details TO service_role;
ALTER TABLE public.builder_details ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Builder details public" ON public.builder_details FOR SELECT USING (true);
CREATE POLICY "Owner writes builder details" ON public.builder_details FOR ALL TO authenticated USING (auth.uid() = profile_id) WITH CHECK (auth.uid() = profile_id);

-- COMPANIES
CREATE TABLE public.companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  logo_url TEXT,
  website TEXT,
  industry TEXT,
  employee_count TEXT,
  location TEXT,
  description TEXT,
  verified BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.companies TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.companies TO authenticated;
GRANT ALL ON public.companies TO service_role;
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Companies public" ON public.companies FOR SELECT USING (true);
CREATE POLICY "Owner writes company" ON public.companies FOR ALL TO authenticated USING (auth.uid() = owner_profile_id) WITH CHECK (auth.uid() = owner_profile_id);

-- PROJECTS
CREATE TABLE public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  builder_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  cover_image_url TEXT,
  problem_solved TEXT,
  solution TEXT,
  tools_used TEXT[] NOT NULL DEFAULT '{}',
  industry TEXT,
  live_demo_url TEXT,
  github_url TEXT,
  case_study TEXT,
  tags TEXT[] NOT NULL DEFAULT '{}',
  upvote_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.projects TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.projects TO authenticated;
GRANT ALL ON public.projects TO service_role;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Projects public" ON public.projects FOR SELECT USING (true);
CREATE POLICY "Owner writes project" ON public.projects FOR ALL TO authenticated USING (auth.uid() = builder_id) WITH CHECK (auth.uid() = builder_id);

-- SERVICES
CREATE TABLE public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  builder_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  cover_image_url TEXT,
  category TEXT,
  packages JSONB NOT NULL DEFAULT '[]',
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.services TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.services TO authenticated;
GRANT ALL ON public.services TO service_role;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Services public" ON public.services FOR SELECT USING (true);
CREATE POLICY "Owner writes service" ON public.services FOR ALL TO authenticated USING (auth.uid() = builder_id) WITH CHECK (auth.uid() = builder_id);

-- JOBS
CREATE TABLE public.jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  posted_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  company_id UUID REFERENCES public.companies(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT,
  requirements TEXT[] NOT NULL DEFAULT '{}',
  nice_to_have TEXT[] NOT NULL DEFAULT '{}',
  job_type public.job_type NOT NULL DEFAULT 'full-time',
  location TEXT,
  remote_type public.remote_type NOT NULL DEFAULT 'remote',
  salary_min INT,
  salary_max INT,
  tools_required TEXT[] NOT NULL DEFAULT '{}',
  experience_level public.experience_level,
  status public.job_status NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.jobs TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.jobs TO authenticated;
GRANT ALL ON public.jobs TO service_role;
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Active jobs public" ON public.jobs FOR SELECT USING (status = 'active' OR auth.uid() = posted_by);
CREATE POLICY "Hirers post jobs" ON public.jobs FOR INSERT TO authenticated WITH CHECK (auth.uid() = posted_by AND public.has_role(auth.uid(),'hirer'));
CREATE POLICY "Poster updates job" ON public.jobs FOR UPDATE TO authenticated USING (auth.uid() = posted_by) WITH CHECK (auth.uid() = posted_by);
CREATE POLICY "Poster deletes job" ON public.jobs FOR DELETE TO authenticated USING (auth.uid() = posted_by);

-- JOB APPLICATIONS
CREATE TABLE public.job_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  applicant_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  resume_url TEXT,
  cover_note TEXT,
  status public.application_status NOT NULL DEFAULT 'applied',
  applied_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (job_id, applicant_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.job_applications TO authenticated;
GRANT ALL ON public.job_applications TO service_role;
ALTER TABLE public.job_applications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Applicant sees own apps" ON public.job_applications FOR SELECT TO authenticated USING (auth.uid() = applicant_id);
CREATE POLICY "Poster sees apps to their jobs" ON public.job_applications FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.jobs j WHERE j.id = job_id AND j.posted_by = auth.uid()));
CREATE POLICY "Applicant inserts own app" ON public.job_applications FOR INSERT TO authenticated WITH CHECK (auth.uid() = applicant_id);
CREATE POLICY "Applicant updates own app" ON public.job_applications FOR UPDATE TO authenticated USING (auth.uid() = applicant_id) WITH CHECK (auth.uid() = applicant_id);
CREATE POLICY "Poster updates app status" ON public.job_applications FOR UPDATE TO authenticated USING (EXISTS (SELECT 1 FROM public.jobs j WHERE j.id = job_id AND j.posted_by = auth.uid())) WITH CHECK (EXISTS (SELECT 1 FROM public.jobs j WHERE j.id = job_id AND j.posted_by = auth.uid()));

-- FOLLOWS
CREATE TABLE public.follows (
  follower_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (follower_id, following_id),
  CHECK (follower_id <> following_id)
);
GRANT SELECT ON public.follows TO anon;
GRANT SELECT, INSERT, DELETE ON public.follows TO authenticated;
GRANT ALL ON public.follows TO service_role;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Follows public" ON public.follows FOR SELECT USING (true);
CREATE POLICY "User follows" ON public.follows FOR INSERT TO authenticated WITH CHECK (auth.uid() = follower_id);
CREATE POLICY "User unfollows" ON public.follows FOR DELETE TO authenticated USING (auth.uid() = follower_id);

-- REVIEWS
CREATE TABLE public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reviewer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reviewed_profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  reviewed_service_id UUID REFERENCES public.services(id) ON DELETE CASCADE,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (reviewed_profile_id IS NOT NULL OR reviewed_service_id IS NOT NULL),
  CHECK (reviewer_id <> reviewed_profile_id OR reviewed_profile_id IS NULL)
);
GRANT SELECT ON public.reviews TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reviews TO authenticated;
GRANT ALL ON public.reviews TO service_role;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Reviews public" ON public.reviews FOR SELECT USING (true);
CREATE POLICY "User writes review" ON public.reviews FOR INSERT TO authenticated WITH CHECK (auth.uid() = reviewer_id);
CREATE POLICY "Reviewer edits review" ON public.reviews FOR UPDATE TO authenticated USING (auth.uid() = reviewer_id) WITH CHECK (auth.uid() = reviewer_id);
CREATE POLICY "Reviewer deletes review" ON public.reviews FOR DELETE TO authenticated USING (auth.uid() = reviewer_id);

-- SAVED JOBS
CREATE TABLE public.saved_jobs (
  profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (profile_id, job_id)
);
GRANT SELECT, INSERT, DELETE ON public.saved_jobs TO authenticated;
GRANT ALL ON public.saved_jobs TO service_role;
ALTER TABLE public.saved_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "User sees own saved jobs" ON public.saved_jobs FOR SELECT TO authenticated USING (auth.uid() = profile_id);
CREATE POLICY "User saves jobs" ON public.saved_jobs FOR INSERT TO authenticated WITH CHECK (auth.uid() = profile_id);
CREATE POLICY "User unsaves jobs" ON public.saved_jobs FOR DELETE TO authenticated USING (auth.uid() = profile_id);

-- UPVOTES
CREATE TABLE public.upvotes (
  profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  target_type public.upvote_target NOT NULL,
  target_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (profile_id, target_type, target_id)
);
GRANT SELECT ON public.upvotes TO anon;
GRANT SELECT, INSERT, DELETE ON public.upvotes TO authenticated;
GRANT ALL ON public.upvotes TO service_role;
ALTER TABLE public.upvotes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Upvotes public" ON public.upvotes FOR SELECT USING (true);
CREATE POLICY "User upvotes" ON public.upvotes FOR INSERT TO authenticated WITH CHECK (auth.uid() = profile_id);
CREATE POLICY "User removes upvote" ON public.upvotes FOR DELETE TO authenticated USING (auth.uid() = profile_id);

-- TRIGGERS
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email,'@',1)),
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.bump_follow_counts()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.profiles SET follower_count = follower_count + 1 WHERE id = NEW.following_id;
    UPDATE public.profiles SET following_count = following_count + 1 WHERE id = NEW.follower_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.profiles SET follower_count = GREATEST(follower_count - 1,0) WHERE id = OLD.following_id;
    UPDATE public.profiles SET following_count = GREATEST(following_count - 1,0) WHERE id = OLD.follower_id;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER follows_count_trg AFTER INSERT OR DELETE ON public.follows FOR EACH ROW EXECUTE FUNCTION public.bump_follow_counts();

CREATE OR REPLACE FUNCTION public.bump_project_upvotes()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.target_type = 'project' THEN
    UPDATE public.projects SET upvote_count = upvote_count + 1 WHERE id = NEW.target_id;
  ELSIF TG_OP = 'DELETE' AND OLD.target_type = 'project' THEN
    UPDATE public.projects SET upvote_count = GREATEST(upvote_count - 1,0) WHERE id = OLD.target_id;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER upvotes_count_trg AFTER INSERT OR DELETE ON public.upvotes FOR EACH ROW EXECUTE FUNCTION public.bump_project_upvotes();

-- STORAGE policies for resumes (private bucket; created via tool separately)
