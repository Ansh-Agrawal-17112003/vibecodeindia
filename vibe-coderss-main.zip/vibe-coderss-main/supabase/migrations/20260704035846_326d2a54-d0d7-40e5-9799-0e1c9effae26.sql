ALTER TABLE public.founder_emails ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.founder_emails FROM anon, authenticated;
GRANT ALL ON public.founder_emails TO service_role;
GRANT SELECT ON public.founder_emails TO authenticated;
CREATE POLICY "Admins can read founder emails"
ON public.founder_emails
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin'));

REVOKE EXECUTE ON FUNCTION public.is_community_admin(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_community_admin(uuid, uuid) TO authenticated, service_role;