
GRANT ALL ON public.og_members TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.og_members TO authenticated;
GRANT SELECT, INSERT ON public.og_members TO anon;
