GRANT SELECT ON public.og_members TO anon, authenticated;

DROP POLICY IF EXISTS "Public can view wall-visible OG members" ON public.og_members;
CREATE POLICY "Public can view wall-visible OG members"
  ON public.og_members
  FOR SELECT
  TO anon, authenticated
  USING (show_on_wall = true);