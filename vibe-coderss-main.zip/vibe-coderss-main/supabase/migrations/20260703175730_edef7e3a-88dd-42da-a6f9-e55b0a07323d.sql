
-- 1) Replace weak LIKE-based storage policy with an anchored match
DROP POLICY IF EXISTS "msg attach read participants" ON storage.objects;

CREATE POLICY "msg attach read participants"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'message-attachments'
  AND (
    (storage.foldername(name))[1] = (auth.uid())::text
    OR EXISTS (
      SELECT 1 FROM public.messages m
      WHERE m.recipient_id = auth.uid()
        AND m.attachment_url LIKE '%/message-attachments/' || objects.name || '?%'
    )
  )
);

-- 2) Revoke public/anon EXECUTE on SECURITY DEFINER functions; keep authenticated + service_role
REVOKE EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) FROM PUBLIC, anon;
GRANT  EXECUTE ON FUNCTION public.award_vibecoins(text, integer, text, uuid) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) FROM PUBLIC, anon;
GRANT  EXECUTE ON FUNCTION public.award_xp(text, integer, uuid, text) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.check_daily_login() FROM PUBLIC, anon;
GRANT  EXECUTE ON FUNCTION public.check_daily_login() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.is_community_member(uuid, uuid) FROM PUBLIC, anon;
GRANT  EXECUTE ON FUNCTION public.is_community_member(uuid, uuid) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.get_community_invite(text) FROM PUBLIC, anon;
GRANT  EXECUTE ON FUNCTION public.get_community_invite(text) TO authenticated, service_role;

-- Trigger-only SECURITY DEFINER functions: no runtime EXECUTE needed
REVOKE EXECUTE ON FUNCTION public.bump_project_upvotes() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.activate_subscription_on_verify() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.bump_follow_counts() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.after_message_insert() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.bump_community_member_count() FROM PUBLIC, anon;
