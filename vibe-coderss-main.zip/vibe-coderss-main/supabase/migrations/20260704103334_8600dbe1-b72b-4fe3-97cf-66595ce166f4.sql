
REVOKE EXECUTE ON FUNCTION public._notif_name(uuid) FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public._notif_push(uuid, uuid, text, text, text, text) FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.notify_on_follow() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.notify_on_post_like() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.notify_on_post_comment() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.notify_on_post_insert() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.notify_on_upvote() FROM anon, authenticated, PUBLIC;
